{
	"containerName": "hybris",
	"usecase": "muletest",
	"prefix": "some/test/folder/nkjwfwe"
}
