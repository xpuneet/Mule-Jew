{
	"enumerationResults": {
		"prefix": "export/brsm-product-feed/",
		"blobs": {
			"blob": {
				"name": "export/brsm-product-feed/Delta_20221031_074305.xml.gz",
				"properties": {
					"last-Modified": "Mon, 31 Oct 2022 07:43:05 GMT",
					"etag": "0x8DABB138C18581C",
					"content-Length": "1684",
					"content-Type": "application/octet-stream",
					"content-Encoding": null,
					"content-Language": null,
					"content-MD5": "ldNZCD/s20KS16NYGKQ97w==",
					"cache-Control": null,
					"content-Disposition": null,
					"blobType": "BlockBlob",
					"accessTier": "Hot",
					"accessTierInferred": "true",
					"leaseStatus": "unlocked",
					"leaseState": "available",
					"serverEncrypted": "true"
				},
				"metadata": null
			},
			"blob": {
				"name": "export/brsm-product-feed/ProductCatalog_20221030.zip",
				"properties": {
					"last-Modified": "Sat, 29 Oct 2022 05:53:29 GMT",
					"etag": "0x8DAB971E77796A3",
					"content-Length": "367990",
					"content-Type": "application/octet-stream",
					"content-Encoding": null,
					"content-Language": null,
					"content-MD5": null,
					"cache-Control": null,
					"content-Disposition": null,
					"blobType": "BlockBlob",
					"accessTier": "Hot",
					"accessTierInferred": "true",
					"leaseStatus": "unlocked",
					"leaseState": "available",
					"serverEncrypted": "true"
				},
				"metadata": null
			},
			"blob": {
				"name": "export",
				"properties": {
					"last-Modified": "Sat, 29 Oct 2022 05:53:29 GMT",
					"etag": "0x8DAB971E77796A3",
					"content-Length": "367990",
					"content-Type": "application/octet-stream",
					"content-Encoding": null,
					"content-Language": null,
					"content-MD5": null,
					"cache-Control": null,
					"content-Disposition": null,
					"blobType": "BlockBlob",
					"accessTier": "Hot",
					"accessTierInferred": "true",
					"leaseStatus": "unlocked",
					"leaseState": "available",
					"serverEncrypted": "true"
				},
				"metadata": null
			},
			"blob": {
				"name": "export/ProductCatalog_20221030.zip",
				"properties": {
					"last-Modified": "Sat, 29 Oct 2022 05:53:29 GMT",
					"etag": "0x8DAB971E77796A3",
					"content-Length": "367990",
					"content-Type": "application/octet-stream",
					"content-Encoding": null,
					"content-Language": null,
					"content-MD5": null,
					"cache-Control": null,
					"content-Disposition": null,
					"blobType": "BlockBlob",
					"accessTier": "Hot",
					"accessTierInferred": "true",
					"leaseStatus": "unlocked",
					"leaseState": "available",
					"serverEncrypted": "true"
				},
				"metadata": null
			}
		},
		"nextMarker": null
	}
}