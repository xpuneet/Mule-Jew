%dw 2.0
output multipart/form-data
boundary='---Qmxvb21yZWFjaEZvcm1Cb3VuZGFyeQ'
---
{
	parts: {
		fileData: {
			headers: {
				"Content-Type": "application/octet-stream",
				"Content-Disposition": {
					"name": "fileData",
					"filename": vars.blobName
				}
			},
			content: vars.fileData
		}
	}
}