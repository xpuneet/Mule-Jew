%dw 2.0
output application/json
---
if((!isEmpty(vars.gmcStatus)) and (vars.rakutenStatus != 201) and (vars.brand == "jewson"))
"GMC google online products feed and Rakuten google online products feed"
else if((vars.rakutenStatus != 201) and (vars.brand == "jewson"))
"Rakuten google online products feed"
else if(!isEmpty(vars.gmcStatus))
"GMC google online products feed"
else 
null