%dw 2.0
fun loggerVariables(transactionCorrelationId,sessionCorrelationId,id,priorityLevel,message)= {
	transactionCorrelationId: transactionCorrelationId,
	sessionCorrelationId: sessionCorrelationId,
	messageCorrelationId : id default "",
	priorityLevel: priorityLevel,
	message : message
}
