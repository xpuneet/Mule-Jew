%dw 2.0
output application/json
indent=false,skipNullOn = "everywhere"
---
{
errorType: error.errorType.asString default error.errorType,
errorDescription: error.description,
status: vars.httpStatus
}