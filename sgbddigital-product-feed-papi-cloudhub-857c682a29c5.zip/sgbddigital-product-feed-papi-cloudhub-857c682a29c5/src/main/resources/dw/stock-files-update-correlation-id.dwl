%dw 2.0 
output application/json
--- 
vars.correlation  update {
        case .messageCorrelationId ->  vars.azureEnv
}