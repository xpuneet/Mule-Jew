%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "Received response from icon-sfp-sapi, No. of Files present are " ++ sizeOf(payload)
 }