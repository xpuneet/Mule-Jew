%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "Starting READ operation in icon-sftp-sapi"
}