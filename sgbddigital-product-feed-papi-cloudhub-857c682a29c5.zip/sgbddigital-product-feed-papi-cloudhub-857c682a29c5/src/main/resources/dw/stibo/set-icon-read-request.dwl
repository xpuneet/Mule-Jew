%dw 2.0
output application/json skipNullOn = "everywhere"
---
{
	headers: vars.correlation ++ {
		filePath: vars.path,
		fileName: payload
	}
}
