%dw 2.0
output application/json skipNullOn = "everywhere"
---
{
	method: "GET",
	path: p('https.icon.stock.getFileListPath'),
	headers: vars.correlation ++ {
		filePath: vars.path,
		fileFilter: p('stibo.filter')
	}
}
