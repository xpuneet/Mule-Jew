%dw 2.0
import update from dw::util::Values
import substringBeforeLast from dw::core::Strings
output application/json
---
vars.correlation update "sessionCorrelationId" with "$(vars.correlation.sessionCorrelationId substringBeforeLast("-"))"