%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "START :: Flow : $(flow.name)"
}