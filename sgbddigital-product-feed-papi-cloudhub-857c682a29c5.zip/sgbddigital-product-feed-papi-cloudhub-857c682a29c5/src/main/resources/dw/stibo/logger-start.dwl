%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "LIST icon-sftp-sapi path : $(vars.path)"
}