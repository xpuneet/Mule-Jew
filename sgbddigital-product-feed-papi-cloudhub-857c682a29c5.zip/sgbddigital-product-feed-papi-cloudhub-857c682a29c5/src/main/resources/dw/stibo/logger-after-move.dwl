%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "MOVE operation is successful :: Path : $(vars.icon.headers.archivePath)"
}