%dw 2.0
output application/java
---
vars.correlation ++ {
	messageCorrelationId: "iteration=$(vars.counter)/$(vars.total)_file=$(payload)"
}