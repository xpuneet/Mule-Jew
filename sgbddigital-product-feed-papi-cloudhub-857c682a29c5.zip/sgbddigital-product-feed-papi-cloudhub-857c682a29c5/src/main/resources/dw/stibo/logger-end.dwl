%dw 2.0
output application/java
var errorFiles = vars.errorFiles default []
var success = "total successful files : $(vars.total - sizeOf(errorFiles))"
var failure = "total unsuccessful files : $(sizeOf(errorFiles))"
var failedFiles = if(!isEmpty(errorFiles))" :: failed files : $(write(errorFiles,'application/java'))" else ""
---
{
	priorityLevel: "INFO",
	message : "Completed processing files from path : $(vars.path) :: $(success) :: $(failure)$(failedFiles)"
}