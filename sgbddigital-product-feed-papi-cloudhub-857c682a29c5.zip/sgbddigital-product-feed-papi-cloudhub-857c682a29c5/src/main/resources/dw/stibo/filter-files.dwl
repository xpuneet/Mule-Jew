%dw 2.0
output application/json
---
(flatten(payload.fileList)) filter ($ matches  (p('stibo.regex')))