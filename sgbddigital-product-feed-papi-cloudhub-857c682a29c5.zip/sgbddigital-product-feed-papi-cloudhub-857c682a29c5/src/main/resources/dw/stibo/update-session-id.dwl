%dw 2.0
import update from dw::util::Values
output application/json
---
vars.correlation update "sessionCorrelationId" with "$(vars.correlation.sessionCorrelationId)-$(upper(payload))"