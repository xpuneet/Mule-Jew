%dw 2.0
output application/json  indent = false
var headers = p('stibo.headers') splitBy ","
var allCsvValues= payload map(p,pi) -> p pluck $
---
allCsvValues map (o, oi) -> {
	(o map (i, ii) -> 
   (headers[ii]): i)
}