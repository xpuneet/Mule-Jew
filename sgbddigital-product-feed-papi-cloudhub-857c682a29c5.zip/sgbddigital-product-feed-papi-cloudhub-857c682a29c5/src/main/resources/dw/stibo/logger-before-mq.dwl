%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "Transforming & Publishing file content to MQ"
}