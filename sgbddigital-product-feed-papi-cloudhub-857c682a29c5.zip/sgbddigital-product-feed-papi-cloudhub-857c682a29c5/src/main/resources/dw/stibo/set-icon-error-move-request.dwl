%dw 2.0
output application/json skipNullOn = "everywhere"
---
{
	method: "PUT",
	path: p('https.icon.stock.moveFilePath'),
	headers: vars.correlation ++ {
		filePath: vars.path,
		archivePath: vars.path ++ p('stibo.error'),
		fileName: vars.file
	}
}
