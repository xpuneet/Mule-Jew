%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "READ operation is successful :: File size : $(attributes.headers.size) Bytes"
}