%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "Total files to be processed : $(sizeOf(payload))"
}