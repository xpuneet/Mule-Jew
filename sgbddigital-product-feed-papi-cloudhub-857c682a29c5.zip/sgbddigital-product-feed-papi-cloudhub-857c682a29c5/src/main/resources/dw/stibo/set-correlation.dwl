%dw 2.0
output application/java
---
{
	transactionCorrelationId: correlationId,
	sessionCorrelationId: "$(now() as String {format:'dd.MM.YY_HH:mm:ss'})-Icon2MQStiboFiles",
	source: p('icon.source')
}