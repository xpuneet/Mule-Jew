%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "END :: Flow : $(flow.name)"
}