%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message : "Publish operation is successful :: MQ : $(p('stibo.mq.name')) :: MessageId : $(attributes.messageId) "
}