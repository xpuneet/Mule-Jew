output application/json 
var property= "stibo." ++ payload ++ ".path"
---
p(property)