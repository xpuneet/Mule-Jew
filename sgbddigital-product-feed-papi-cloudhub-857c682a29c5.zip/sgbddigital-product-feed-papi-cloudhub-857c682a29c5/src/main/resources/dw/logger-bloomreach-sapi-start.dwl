%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "Received DELETE blob response. Uploading blob to Bloomreach SFTP: " ++ vars.blobName
 }