%dw 2.0
output application/java
---
splitBy(payload,"/")[1]