%dw 2.0
output application/json
---
rows: payload map (
	row: $ pluck $
)