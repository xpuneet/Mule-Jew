%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "Received POST blob response. Sending DELETE request to azure-blob-storage-sapi for blob - "  ++ vars.blobName
 }