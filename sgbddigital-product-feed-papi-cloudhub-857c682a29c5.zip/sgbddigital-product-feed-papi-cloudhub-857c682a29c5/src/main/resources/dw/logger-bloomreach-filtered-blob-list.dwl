%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message: "Received GET response from azure-blob-storage-sapi. Files picked up for processing are " ++ write(payload,"application/java")
}