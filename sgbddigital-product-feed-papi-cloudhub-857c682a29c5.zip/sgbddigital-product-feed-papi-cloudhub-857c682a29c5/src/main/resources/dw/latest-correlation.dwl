%dw 2.0
output application/java
---
{
	transactionCorrelationId: vars.correlation.transactionCorrelationId,
	sessionCorrelationId: vars.correlation.sessionCorrelationId,
	messageCorrelationId : vars.filename
}