%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "Received GET blob response. Sending POST request to azure-blob-storage-sapi to archive blob - " ++ vars.blobName
 }