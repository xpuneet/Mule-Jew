%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "Sending GET blob request to azure-blob-storage-sapi for blob - " ++ vars.blobName
 }