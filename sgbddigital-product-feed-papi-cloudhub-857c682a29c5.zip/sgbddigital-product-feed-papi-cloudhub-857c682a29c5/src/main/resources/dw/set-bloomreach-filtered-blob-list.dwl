%dw 2.0
import * from dw::core::Strings
output application/json  indent = false, skipNullOn = "everywhere"
---
payload.enumerationResults.blobs.*blob.name filter (
	($ contains (Mule::p('bloomreach.prefix') ++ "/Delta_")) or 
	($ contains (Mule::p('bloomreach.prefix') ++ "/ProductCatalog_"))
)
map () -> ($ substringAfterLast "/")