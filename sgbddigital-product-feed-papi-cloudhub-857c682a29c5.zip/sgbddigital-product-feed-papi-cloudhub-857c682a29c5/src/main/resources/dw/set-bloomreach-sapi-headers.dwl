vars.correlation ++ {
	fileName: vars.blobName,
	'Content-Type': "multipart/form-data; boundary=---Qmxvb21yZWFjaEZvcm1Cb3VuZGFyeQ"
}