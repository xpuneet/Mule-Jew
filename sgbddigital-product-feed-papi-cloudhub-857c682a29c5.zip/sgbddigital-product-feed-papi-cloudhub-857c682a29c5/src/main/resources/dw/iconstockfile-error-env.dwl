%dw 2.0
output application/java
---
if (vars.iconEnv contains("QA_02")) "QA_02"
else if (vars.iconEnv contains("QA_03")) "QA_03"
else "live"