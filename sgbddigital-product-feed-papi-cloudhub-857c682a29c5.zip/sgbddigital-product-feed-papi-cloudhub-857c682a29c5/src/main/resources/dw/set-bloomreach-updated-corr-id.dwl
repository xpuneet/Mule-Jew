%dw 2.0
output application/java
---
vars.correlation ++ {messageCorrelationId: payload as String}