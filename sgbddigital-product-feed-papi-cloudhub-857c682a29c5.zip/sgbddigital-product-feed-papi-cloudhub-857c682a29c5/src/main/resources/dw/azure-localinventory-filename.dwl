%dw 2.0
output application/json
var fileName= (vars.filename splitBy  ".")[0]
---
fileName ++ "_" ++ now() as DateTime as String { format: 'yyyyMMddhhmmss'} ++ ".txt"