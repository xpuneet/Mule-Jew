%dw 2.0
output application/json
indent=false,skipNullOn = "everywhere"
---
error.muleMessage.payload