%dw 2.0
output application/java
---
{
	"containerName": Mule::p('bloomreach.containerName'),
	"usecase": Mule::p('bloomreach.usecase'),
	"prefix": Mule::p('bloomreach.prefix'),
	"subFolder":Mule::p('bloomreach.prefix')
}