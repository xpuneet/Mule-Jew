%dw 2.0
output application/java
---
if((upper(payload) contains "ICON") and (p('mule.env') == "live"))
  p('iconenv.live')
else if(upper(((payload) splitBy "/")[2]) == "QA_02")
  p('iconenv.qa02')
else if(upper(((payload) splitBy "/")[2]) == "QA_03")
  p('iconenv.qa03')
else
  p('iconenv.qa02')