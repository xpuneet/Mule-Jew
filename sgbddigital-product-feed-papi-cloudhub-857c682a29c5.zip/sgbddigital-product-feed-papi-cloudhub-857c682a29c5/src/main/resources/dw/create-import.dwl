%dw 2.0
output application/json
---
{
  "check_divisions": true,
  "description": p('description'),
  "element": p('element'),
  "email_address": p('email_address'),
  "export_results": true,
  "header": vars.header,
  "overwrite_conflicts": true,
  "rsid_list": [
		p('secure::rsidList')
      ]
}
