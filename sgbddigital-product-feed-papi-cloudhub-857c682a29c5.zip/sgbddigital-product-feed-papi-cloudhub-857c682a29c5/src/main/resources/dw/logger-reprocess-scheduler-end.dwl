%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "Reprocessing scheduled run completed"
 }