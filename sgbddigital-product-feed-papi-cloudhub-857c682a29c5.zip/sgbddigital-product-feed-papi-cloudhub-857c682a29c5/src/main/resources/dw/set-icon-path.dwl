%dw 2.0
output application/java
---
p('icon.file.path') splitBy ","