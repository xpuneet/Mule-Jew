%dw 2.0
output application/json
---
payload.enumerationResults.blobs.*blob map (item, index) -> {
    "Name": splitBy(item.name,"/")[1] as String
}