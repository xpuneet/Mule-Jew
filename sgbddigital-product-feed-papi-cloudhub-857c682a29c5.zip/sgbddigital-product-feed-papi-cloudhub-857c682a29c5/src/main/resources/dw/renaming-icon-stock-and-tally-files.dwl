%dw 2.0
output application/java
var time = (now() as DateTime {format:"yyyyMMdd'T'HHmmssSSSZ"}>>"UTC") as String {format: "yyyyMMddHHmmSS"}
var fileName = vars.fileName
var stocktime = vars.fileName[7 to 20]
var stockbranch = vars.fileName[22 to 25]
var tallytime = vars.fileName[7 to 20]
---
if(lower(fileName matches /(products\-\d{14}.csv)/)) 
fileName replace 'products' with 'products.master'
else if(fileName matches /(HybStk\_\d{14}_\d{4}\.csv)/) 'stock.master-' ++ stocktime ++ '-' ++ stockbranch ++ '.csv'
else if(fileName matches /(HybStk\_\d{14}\_Delta\.csv)/) 'stock.master-' ++ stocktime ++ '.csv'
else if(fileName matches /(assets\.master(-FULL)?\-(\d{14}|\d{8}-\d{8})\.csv)/) fileName 
else if(fileName matches /(Term\-GDWEBNAT\-\d{14}\.csv)/) 'prices.gibbsd-' ++ time ++ '.csv'
else if(fileName matches /(Term\-GBWEBNAT\-\d{14}\.csv)/) 'prices.georgeboyd-' ++ time ++ '.csv'
else if(fileName matches /(Term\-IWEBNAT\-\d{14}\.csv)/) 'prices.minster-' ++ time ++ '.csv'
else if(fileName matches /(Term\-JWEBNAT\-\d{14}\.csv)/) 'prices.jewson-' ++ time ++ '.csv'
else if(fileName matches /(Term\-GWEBNAT\-\d{14}\.csv)/) 'prices.graham-' ++ time ++ '.csv'
else if( fileName matches /(HybTal\_\d{14}_Full\.csv)/) 'tallies.master-' ++ tallytime ++ '.csv'
else if( fileName matches /(HybTal\_\d{14}_Delta\.csv)/) 'tallies.master-' ++ tallytime ++ '.csv'
else 'filename-' ++ time ++ '.csv' as String