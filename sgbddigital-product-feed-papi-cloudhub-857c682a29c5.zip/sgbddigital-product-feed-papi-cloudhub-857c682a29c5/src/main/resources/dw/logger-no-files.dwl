%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "No file to process in " ++ vars.env ++ " error folder"
 }