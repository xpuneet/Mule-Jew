%dw 2.0
output application/java
---
{
	"containerName": p('azure.containerName'),
	"usecase": p('azure.usecase'),
	"subFolder": p('azure.subFolder'),
	"filename": p('azure.product_feed_filename')
}