%dw 2.0
output application/java
var filename = ["gibbsanddandy","jewson"]
var sizevar = (filename) -> sizeOf(splitBy(filename,"/"))
var splitVar = (filename) -> splitBy(filename,"/")
fun splitfun(astring) = (if (filename contains trim(splitBy(splitVar(astring)[1],"_")[0])) "true" else "false")
---
payload.enumerationResults.blobs.*blob map ($) filter (splitfun($.name) and splitBy(splitVar($.name)[1],".")[1] == "csv" and splitBy(splitVar($.name)[1],"_")[1] == "local-inventory-feed-incremental")