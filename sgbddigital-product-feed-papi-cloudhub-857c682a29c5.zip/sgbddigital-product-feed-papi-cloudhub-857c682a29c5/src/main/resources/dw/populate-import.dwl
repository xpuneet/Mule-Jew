%dw 2.0
output application/json
---
{
	"job_id": vars.jobId,
	"page": vars.counter,
	"rows": payload map (row: $ pluck $)
}