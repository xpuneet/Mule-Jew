%dw 2.0
output application/java
---
{
	"containerName": Mule::p('bloomreach.containerName'),
	"usecase": Mule::p('bloomreach.usecase'),
	'subFolder': Mule::p('bloomreach.archiveSubFolder')
}