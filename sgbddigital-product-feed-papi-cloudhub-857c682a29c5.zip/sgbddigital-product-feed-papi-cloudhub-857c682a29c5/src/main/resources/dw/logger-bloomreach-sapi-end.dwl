%dw 2.0
output application/java
---
{
	priorityLevel: "INFO",
	message: 
		if ( isEmpty(payload.errorType) ) 
			"Blob uploaded to Bloomreach SFTP: " ++ vars.blobName 
		else 
			"Blob data not sent to Bloomreach"
}