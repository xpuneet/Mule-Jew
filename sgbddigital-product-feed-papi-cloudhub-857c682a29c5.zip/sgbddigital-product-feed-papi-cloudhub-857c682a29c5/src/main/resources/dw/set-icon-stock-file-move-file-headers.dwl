%dw 2.0 
output application/java
---
{
"source" : p('icon.source'),
"filePath": vars.iconEnv,
"transactionCorrelationId" : vars.correlation.transactionCorrelationId,
"fileName" : payload,
"archivePath" : vars.iconEnv ++ p('icon.file.archive')
}