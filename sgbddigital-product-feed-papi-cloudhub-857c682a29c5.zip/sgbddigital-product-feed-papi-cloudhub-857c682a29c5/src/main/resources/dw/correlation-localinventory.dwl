%dw 2.0 
output application/java 
--- 
{
	transactionCorrelationId: uuid(),
	sessionCorrelationId: now() default "",
	messageCorrelationId : "Scheduler triggered for " ++ p('api.name')
}