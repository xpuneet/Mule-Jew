%dw 2.0 
output application/java
---
{
	"subFolder" : p('azure.stockFile.subFolder'),
	"containerName" : p('azure.stockFile.containerName'),
	"usecase" : p('azure.stockFile.useCase')
}