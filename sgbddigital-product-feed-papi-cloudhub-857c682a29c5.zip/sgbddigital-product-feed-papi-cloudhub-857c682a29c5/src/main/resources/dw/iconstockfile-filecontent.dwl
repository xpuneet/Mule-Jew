%dw 2.0
output application/csv
---
if(sizeOf(payload) != 0)
 payload
else 
  []