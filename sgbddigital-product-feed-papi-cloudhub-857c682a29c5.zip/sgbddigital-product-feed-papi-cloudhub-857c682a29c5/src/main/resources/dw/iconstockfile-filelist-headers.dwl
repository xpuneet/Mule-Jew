%dw 2.0 
output application/java 
 ---
 {
	"source" : p('icon.source'),
	"transactionCorrelationId" : vars.correlation.transactionCorrelationId,
	"sessionCorrelationId" : vars.correlation.sessionCorrelationId,
	"filePath" : vars.iconEnv
}