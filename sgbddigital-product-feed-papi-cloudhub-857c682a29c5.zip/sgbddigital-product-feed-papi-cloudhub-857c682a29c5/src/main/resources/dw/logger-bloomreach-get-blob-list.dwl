%dw 2.0 
 output application/java 
 --- 
 { 
     priorityLevel: "INFO", 
     message : "Sending GET blobs list request to azure-blob-storage-sapi"
 }