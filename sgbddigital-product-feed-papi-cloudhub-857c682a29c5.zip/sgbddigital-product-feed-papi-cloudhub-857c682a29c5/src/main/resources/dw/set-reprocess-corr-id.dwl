%dw 2.0 
output application/java 
--- 
{
	transactionCorrelationId: uuid(),
	sessionCorrelationId: now() default "",
	messageCorrelationId : "Scheduler triggered to Re-process files present in the error folder for " ++ p('api.name')
}