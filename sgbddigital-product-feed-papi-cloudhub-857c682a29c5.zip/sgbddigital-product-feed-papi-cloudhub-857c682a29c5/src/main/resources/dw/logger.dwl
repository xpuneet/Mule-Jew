%dw 2.0
output application/json indent=false,skipNullOn = "everywhere"
---
{
"applicationName" : p('api.name'),
"applicationVersion" : p('api.version'),
"environment" : p('env'),
"timeStamp": now(),
"sessionCorrelationId" : vars.correlation.sessionCorrelationId,
"transactionCorrelationId" : vars.correlation.transactionCorrelationId,
"messageCorrelationId" : vars.correlation.messageCorrelationId,
"priority" : vars.loggerVariables.priorityLevel,
"message" : vars.loggerVariables.message
}