%dw 2.0
output application/json
---
p('filename') splitBy ","
