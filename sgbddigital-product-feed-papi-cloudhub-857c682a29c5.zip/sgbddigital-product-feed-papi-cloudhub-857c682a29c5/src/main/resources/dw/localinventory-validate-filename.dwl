%dw 2.0
output application/json
---
payload.enumerationResults.blobs.*blob
map (
$.name
) 