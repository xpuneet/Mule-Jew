%dw 2.0
output application/json
import * from dw::core::Strings
var filetype = substringAfter(vars.filename,".")
var file= vars.filename replace  /\..*/ with("")
var today = now() as String {format: "ddMMyyyy"} 
---
file ++ "-" ++ today ++ "." ++ filetype
