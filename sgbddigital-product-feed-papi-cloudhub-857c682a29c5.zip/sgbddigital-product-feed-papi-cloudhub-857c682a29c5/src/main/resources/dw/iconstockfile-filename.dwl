%dw 2.0
output application/java
---
vars.iconStockReadFileHeaders.fileName