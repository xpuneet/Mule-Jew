%dw 2.0
output application/json skipNullOn = "everywhere"
var fileList = payload.fileList[0]
---
fileList map (item,index) -> 
    if((item) matches  /(Term\-(J|GD|G|I|GB)(WEBNAT\-\d{14}\.csv))|(Hyb(Tal|Stk)\_\d{14}\_(Delta|Full|\d{4})\.csv)|(products\-\d{14}.csv)|(assets\.master(-FULL)?\-(\d{14}|\d{8}-\d{8})\.csv)/)
      (item)
    else
      null