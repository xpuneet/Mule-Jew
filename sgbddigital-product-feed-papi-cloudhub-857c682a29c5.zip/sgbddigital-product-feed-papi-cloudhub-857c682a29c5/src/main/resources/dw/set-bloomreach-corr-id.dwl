%dw 2.0 
output application/java 
--- 
{
	transactionCorrelationId: uuid(),
	sessionCorrelationId: now(),
	messageCorrelationId : "Scheduler triggered for azure to bloomreach transfer flow " ++ p('api.name')
}