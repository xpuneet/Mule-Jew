%dw 2.0
output application/java
---
{
"containerName": p('azure.containerName'),
"usecase": p('azure.usecase'),
"prefix": p('azure.prefix') ++ "/" ++ p('azure.gmc_filename')
}