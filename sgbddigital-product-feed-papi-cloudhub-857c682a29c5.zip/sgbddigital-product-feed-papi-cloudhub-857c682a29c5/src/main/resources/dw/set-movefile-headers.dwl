%dw 2.0 
output application/java
---
{
"source": p('icon.source'),
"filePath" : vars.iconEnv ++ p('icon.file.error'),
"transactionCorrelationId": vars.correlation.transactionCorrelationId,
"fileName": payload,
"archivePath": vars.iconEnv
}