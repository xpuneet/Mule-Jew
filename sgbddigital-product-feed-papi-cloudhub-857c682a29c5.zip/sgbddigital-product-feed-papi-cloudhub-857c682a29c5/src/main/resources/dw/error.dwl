%dw 2.0
output application/json
indent=false,skipNullOn = "everywhere"
---
if((error.errorMessage != null) and (vars.httpStatus != 504)){
  errorType: error.errorType.asString default error.errorType,
  errorDescription: if(typeOf(error.errorMessage.payload) as String == "String") 
    error.errorMessage.payload
    else if(typeOf(error.errorMessage.payload) as String == "Binary")
    error.description
    else error.errorMessage.payload.errorDescription default error.description,
  status: vars.httpStatus
}
else
{
  errorType: error.errorType.asString default error.errorType,
  errorDescription: error.description,
  status: vars.httpStatus
}
