%dw 2.0
output application/java
---
(payload.parts.file.headers."Content-Type" splitBy(/[;]/))[0]