﻿namespace STUK.ProductService.Contracts.Models
{
    public class Product
    {
        public string ProductCode { get; set; }
        public string ProductShortDescription { get; set; }
        public string ProductFullDescription { get; set; }
        public string Pac2Code { get; set; }
        public string Pac2Description { get; set; }
        public string SupplierName { get; set; }
        public ProductUnit SellingUnit { get; set; }
        public ProductUnit UnitOfSale { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public ProductPrice Price { get; set; }
        public ProductStock Stock { get; set; }
        public List<ProductAsset> Assets { get; set; }
        public ProductError Error {  get; set; }
    }
}
