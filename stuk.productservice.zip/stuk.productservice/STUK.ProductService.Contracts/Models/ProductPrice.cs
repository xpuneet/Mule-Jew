﻿namespace STUK.ProductService.Contracts.Models
{
    public class ProductPrice
    {
        public string ProductCode { get; set; }
        public ProductUnit Unit { get; set; }
        public decimal Retail { get; set; }
        public decimal Customer { get; set; }
        public decimal Discount { get; set; }

        public DateTime LastUpdatedOn { get; set; }
    }
}
