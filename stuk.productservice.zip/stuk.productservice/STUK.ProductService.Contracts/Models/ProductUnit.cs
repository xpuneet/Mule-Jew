﻿namespace STUK.ProductService.Contracts.Models
{
    public class ProductUnit
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
