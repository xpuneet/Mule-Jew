﻿namespace STUK.ProductService.Contracts.Models
{
    public class ProductStock
    {
        public string ProductCode { get; set; }
        public decimal Branch { get; set; }
        public decimal Company { get; set; }

        public DateTime LastUpdatedOn { get; set; }
    }
}
