﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.ProductService.Contracts.Models
{
    public class ProductError
    {
        public string Code { get; set; }
        public string Message { get; set; }

    }
}
