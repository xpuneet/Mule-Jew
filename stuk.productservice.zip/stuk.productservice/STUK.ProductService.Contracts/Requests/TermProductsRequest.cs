﻿using Microsoft.AspNetCore.Mvc;

namespace STUK.ProductService.Contracts.Requests
{
    public class TermProductsRequest
    {
        public string? AccountCode { get; set; }
        public DateTime? LastUpdatedTimestamp { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        /// <summary>
        /// name of application/client consuming the API
        /// </summary>
        [FromHeader]
        public string Source { get; set; }

    }
}
