﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.ProductService.Contracts.Requests
{
    public class UpdateCacheRequest
    {
        /// <summary>
        /// Remove existing cache entries
        /// </summary>
        public bool ClearCache { get; set; }
        /// <summary>
        /// Cache entries expiry time in minutes.
        /// Requires a non zero value
        /// </summary>
        [Range(1, int.MaxValue, ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        [FromBody]
        public int CacheExpiryMinutes { get; set; }

        /// <summary>
        /// name of application/client consuming the API
        /// </summary>
        [FromHeader]
        public string? Source { get; set; }

    }
}
