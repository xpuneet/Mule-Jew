﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace STUK.ProductService.Contracts.Requests
{
    public class ProductRequest
    {
        /// <summary>
        /// Required if AccountCode is not provided
        /// </summary>
        public int BranchNumber { get; set; }
        /// <summary>
        /// Required if BranchNumber is not provided
        /// </summary>
        public string? AccountCode { get; set; }

        /// <summary>
        /// Comma (,) separated list of product codes
        /// </summary>
        [Required]
        public string ProductCodes { get; set; }

        /// <summary>
        /// name of application/client consuming the API
        /// </summary>
        [FromHeader]
        public string Source {  get; set; }

        [JsonIgnore]
        public string[] ProductCodeList
        {
            get
            {
                if (ProductCodes != null)
                {
                    return ProductCodes.Split(',');
                }

                return new string[0];
            }
        }
    }
}
