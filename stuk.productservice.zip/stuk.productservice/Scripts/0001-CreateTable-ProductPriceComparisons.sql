﻿CREATE TABLE [dbo].[ProductPriceComparisons](	
	[AccountCode] [NVARCHAR](30) NOT NULL,
	[ProductCode] [NVARCHAR](30) NOT NULL,
	[ResultCode] [SMALLINT] NOT NULL,
	[ResultDescription] [VARCHAR](MAX) NOT NULL,
    [IgnoredDifferences] [VARCHAR](MAX) NULL,
	[DatabasePrice] [NVARCHAR](MAX) NULL,
	[ErpPrice] [NVARCHAR](MAX) NULL,
	[CreatedTimestamp] [DATETIME] NOT NULL,
	[RequestOperationId] [VARCHAR](100) NOT NULL,
	[AdditionalInfo] VARCHAR(MAX) NULL,
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description' ,@value=N'Flag based value for comparison result. DifferentRetail = 1,
DifferentCustomer = 2,
DifferentDiscount = 4,
DifferentUnitCode = 8,
InvalidDiscountFromDatabase = 16,
NotFoundInDatabase = 32,
NotFoundInErp = 64,
EprLoadFailed = 128' 
    ,@level0type=N'SCHEMA', @level0name=N'dbo'
    ,@level1type=N'TABLE', @level1name=N'ProductPriceComparisons'
    ,@level2type=N'COLUMN',@level2name=N'ResultCode'
GO