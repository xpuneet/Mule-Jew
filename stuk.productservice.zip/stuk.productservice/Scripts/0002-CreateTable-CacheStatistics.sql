﻿CREATE TABLE [dbo].[CacheStatistics](	
	[StatisticsKey] VARCHAR(250) NOT NULL,
	[RequestCount] BIGINT NOT NULL,
	[CacheHitRate] FLOAT NOT NULL,
	[MaxCacheEntries] INT NOT NULL,
    [DateCreated] DATETIME NOT NULL,
	[DateLastUpdated] DATETIME NOT NULL,
	[AdditionalInfo] VARCHAR(MAX) NULL,
	CONSTRAINT PK_CacheStatistics PRIMARY KEY (StatisticsKey)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO