﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using STUK.ProductService.TestHarness;
using STUK.ProductService.TestHarness.Data;
using STUK.ProductService.TestHarness.TestRunner;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((hostContext, services) => 
    {
        var configSettings = new ConfigSettings();
        hostContext.Configuration.Bind(configSettings);

        services.AddOptions();
        services.AddDistributedMemoryCache();
        services.AddClientCredentialsTokenManagement()
        .AddClient(ProductServiceTestRunner.IdentityServerClient, client =>
        {
            client.TokenEndpoint = configSettings.AccessTokenUrl;

            client.ClientId = configSettings.AccessTokenClientId;
            client.ClientSecret = configSettings.AccessTokenClientSecret;
            client.Scope = configSettings.AccessTokenScope;
            client.ClientCredentialStyle = IdentityModel.Client.ClientCredentialStyle.PostBody;
        });

        services.AddClientCredentialsHttpClient(ProductServiceTestRunner.ProductApiClient, ProductServiceTestRunner.IdentityServerClient, client =>
        {
            client.BaseAddress = new Uri(configSettings.ProductServiceBaseAddress);
        });

        services.AddTransient<ProductServiceTestRunner>();
        services.AddSingleton<IDataProvider, CsvDataProvider>();
        services.AddSingleton<ConfigSettings>(c => configSettings);
    })
    .Build();

var testRunner = host.Services.GetRequiredService<ProductServiceTestRunner>();
await testRunner.RunTestsAsync();
