﻿using CsvHelper;
using System.Globalization;

namespace STUK.ProductService.TestHarness.Data
{
    public class CsvDataProvider : IDataProvider
    {
        private readonly ConfigSettings _configSettings;

        public CsvDataProvider(ConfigSettings configSettings)
        {
            _configSettings = configSettings;
        }
        public List<Product> GetData()
        {
            using (var reader = new StreamReader(_configSettings.DataFilePathName))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Product>();
                return records.ToList();
            }
        }
    }
}
