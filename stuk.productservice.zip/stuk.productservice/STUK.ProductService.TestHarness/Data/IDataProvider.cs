﻿namespace STUK.ProductService.TestHarness.Data
{
    public interface IDataProvider
    {
        List<Product> GetData();
    }
}
