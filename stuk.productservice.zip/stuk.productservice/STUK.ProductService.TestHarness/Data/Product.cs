﻿namespace STUK.ProductService.TestHarness.Data
{
    public class Product
    {
        public string AccountCode { get; set; }
        public string ProductCode { get; set; }
        /// <summary>
        /// BranchNumber is used in Source header to help trace price comparison
        /// Use any valid branch number if not testing specific branch. Don't pass 0 as it ICON API returns invalid prices for comparison
        /// Only matters for ICON product API
        /// </summary>
        public int BranchNumber { get; set; }
        public bool? Exclude { get; set; }
    }
}
