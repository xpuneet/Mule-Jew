﻿namespace STUK.ProductService.TestHarness.TestRunner
{
    public class PriceApiCall
    {
        public int CallIndex { get; set; }
        public string AccountCode { get; set; }
        public int BranchNumber { get; set; }
        public IEnumerable<string> ProductCodes { get; set; }
    }
}
