﻿using Duende.AccessTokenManagement;
using Microsoft.Extensions.Logging;
using STUK.ProductService.TestHarness.Data;
using System.Diagnostics;
using System.Web;

namespace STUK.ProductService.TestHarness.TestRunner
{
    internal class ProductServiceTestRunner
    {
        private const string TimestampFormat = "yyyy/MM/dd hh:mm:ss.fff";

        public static string IdentityServerClient = "IdentityServerClient";
        public static string ProductApiClient = "ProductApiClient";
        private readonly IDataProvider _dataProvider;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IClientCredentialsTokenManagementService _tokenManagementService;
        private readonly ConfigSettings _configSettings;
        private readonly ILogger<ProductServiceTestRunner> _logger;

        public ProductServiceTestRunner(IDataProvider dataProvider, IHttpClientFactory httpClientFactory, IClientCredentialsTokenManagementService tokenManagementService, ConfigSettings configSettings, ILogger<ProductServiceTestRunner> logger)
        {
            _dataProvider = dataProvider;
            _httpClientFactory = httpClientFactory;
            _tokenManagementService = tokenManagementService;
            _configSettings = configSettings;
            _logger = logger;
        }

        public async Task RunTestsAsync(CancellationToken cancellationToken = default)
        {
            var products = _dataProvider.GetData();
            var productsToTest = products.Where(p => p.Exclude.GetValueOrDefault() == false);

            var priceCalls = new List<PriceApiCall>();

            var productsByAccountId = productsToTest.ToLookup(p => new { p.AccountCode, p.BranchNumber }, p => p.ProductCode);

            int priceCallOrder = 1;
            foreach (var accountProducts in productsByAccountId)
            {
                foreach (var productChunk in accountProducts.Chunk(_configSettings.ProductsPerRequest))
                {
                    priceCalls.Add(new PriceApiCall
                    {
                        CallIndex = priceCallOrder,
                        AccountCode = accountProducts.Key.AccountCode,
                        BranchNumber = accountProducts.Key.BranchNumber,
                        ProductCodes = productChunk
                    });

                    priceCallOrder++;
                }
            }

            var sourceTemplate = $"{Path.GetFileNameWithoutExtension(_configSettings.DataFilePathName)}-run{_configSettings.TestRunCounter}-branch-<BranchNumber>";

            Console.WriteLine($"Products price test run...");
            Console.WriteLine($"\t- Data file: {_configSettings.DataFilePathName}");
            Console.WriteLine($"\t- Number of accounts: {productsByAccountId.Count}");
            Console.WriteLine($"\t- Total products: {products.Count}");
            Console.WriteLine($"\t- Total products to test: {productsToTest?.Count()}");
            Console.WriteLine($"\t- Max ProductsPerRequest: {_configSettings.ProductsPerRequest}");
            Console.WriteLine($"\t- Request Delay Interval (ms): {_configSettings.RequestDelayInterval}");
            Console.WriteLine($"\t- Parallel Run: {_configSettings.ParallelRunEnabled}");
            Console.WriteLine($"\t- Max Parallel Runs: {_configSettings.ParallelRunMaxCount}");
            Console.WriteLine($"\t- Product API: {_configSettings.ProductServiceBaseAddress}");
            Console.WriteLine($"\t- Source: {sourceTemplate}");

            Console.Write($"{Environment.NewLine}Run tests? - Yes to continue: ");
            var runTestsChoice = Console.ReadLine();

            if (runTestsChoice?.Equals("yes", StringComparison.OrdinalIgnoreCase) == false) 
            {
                return;    
            }            

            Console.Write($"{Environment.NewLine}Source: {sourceTemplate} - enter new to override: ");
            var sourceOverride = Console.ReadLine();

            // Identity token management is done automatically as per httpClient configuration
            // This is just to get the token and cache it so that token acquisition does not skew first API call timings
            _ = await _tokenManagementService.GetAccessTokenAsync(IdentityServerClient);

            Console.WriteLine($"{Environment.NewLine}{DateTime.Now.ToString(TimestampFormat)} - Starting tests...{Environment.NewLine}");
            
            var swTestRun = Stopwatch.StartNew();

            if (_configSettings.ParallelRunEnabled)
            {
                Console.WriteLine($"* Note: individual call response time may not be true due to parallelism. Context switch during wait may skew the timings. {Environment.NewLine}");
                await Parallel.ForEachAsync(priceCalls, new ParallelOptions { MaxDegreeOfParallelism = _configSettings.ParallelRunMaxCount }, async (priceApiCall, token) => {
                    await CallProductPriceEndpointAsync(priceApiCall, priceCalls.Count, sourceTemplate, sourceOverride, token);
                });
            }
            else
            {
                foreach (var priceApiCall in priceCalls)
                {
                    await CallProductPriceEndpointAsync(priceApiCall, priceCalls.Count, sourceTemplate, sourceOverride, cancellationToken);

                    await Task.Delay(_configSettings.RequestDelayInterval);
                }
            }

            swTestRun.Stop();

            Console.WriteLine($"{Environment.NewLine}{DateTime.Now.ToString(TimestampFormat)} - All done successfully! TimeTaken: {swTestRun.Elapsed.ToString()}");
            Console.WriteLine($"Press any key to exit..."); 
            Console.ReadKey();
        }

        private async Task CallProductPriceEndpointAsync(PriceApiCall priceApiCall, int totalCalls, string sourceTemplate, string sourceOverride, CancellationToken cancellationToken)
        {
            using (var productApiClient = _httpClientFactory.CreateClient(ProductApiClient))
            {
                var source = string.IsNullOrEmpty(sourceOverride) ? sourceTemplate.Replace("<BranchNumber>", priceApiCall.BranchNumber.ToString()) : sourceOverride;
                productApiClient.DefaultRequestHeaders.Add("Source", source);

                var productCodes = string.Join(",", priceApiCall.ProductCodes);

                var uriBuilder = new UriBuilder($"{productApiClient.BaseAddress.AbsoluteUri.TrimEnd('/')}/products");
                var queryString = HttpUtility.ParseQueryString(uriBuilder.Query);
                queryString["AccountCode"] = priceApiCall.AccountCode;
                queryString["ProductCodes"] = productCodes;
                queryString["BranchNumber"] = priceApiCall.BranchNumber.ToString();

                uriBuilder.Query = queryString.ToString();
                var getPricesUrl = uriBuilder.ToString();

                var callLogMessage = $"{DateTime.Now.ToString(TimestampFormat)} - {priceApiCall.CallIndex}/{totalCalls}\t - Source: {source}\t - AccountCode: {priceApiCall.AccountCode}, ProductCount: {priceApiCall.ProductCodes.Count()}";

                var swApiCall = Stopwatch.StartNew();

                var response = await productApiClient.GetAsync(getPricesUrl, cancellationToken);
                var contents = await response.Content.ReadAsStringAsync();
                var responseStatus = response.StatusCode;

                swApiCall.Stop();

                var timeTaken = swApiCall.ElapsedMilliseconds;
                
                Console.WriteLine($"{callLogMessage}...\tResponseStatus: {responseStatus}, TimeTaken (ms): {timeTaken}");
            }
        }
    }
}
