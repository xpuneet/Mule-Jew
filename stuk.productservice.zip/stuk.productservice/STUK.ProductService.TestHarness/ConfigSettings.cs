﻿namespace STUK.ProductService.TestHarness
{
    public class ConfigSettings
    {
        public string AccessTokenUrl { get; set; }
        public string AccessTokenClientId { get; set; }
        public string AccessTokenClientSecret { get; set; }
        public string AccessTokenScope { get; set; }
        public string ProductServiceBaseAddress { get; set; }

        public string DataFilePathName {  get; set; }
        public int ProductsPerRequest { get; set; }
        public int RequestDelayInterval { get; set; }

        public string TestRunCounter {  get; set; }

        public bool ParallelRunEnabled { get; set; }
        public int ParallelRunMaxCount { get; set; }
    }
}
