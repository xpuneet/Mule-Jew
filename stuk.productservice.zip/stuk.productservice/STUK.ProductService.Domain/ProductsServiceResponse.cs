﻿using STUK.ProductService.Contracts.Models;

namespace STUK.ProductService.Domain
{
    public class ProductsServiceResponse : ServiceResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public List<Product> Result { get; set; }

        public static ProductsServiceResponse Ok(List<Product> result)
        {
            return new ProductsServiceResponse
            {
                Success = true,
                Result = result
            };
        }

        public static ProductsServiceResponse Error(string message)
        {
            return new ProductsServiceResponse
            {
                Success = false,
                Message = message
            };
        }
    }
}
