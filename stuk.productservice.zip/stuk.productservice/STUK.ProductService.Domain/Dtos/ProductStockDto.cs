﻿namespace STUK.ProductService.Domain.Dtos
{
    public class ProductStockDto
    {
        public string ProductCode { get; set; }
        public decimal Branch { get; set; }
        public decimal Company { get; set; }
    }
}
