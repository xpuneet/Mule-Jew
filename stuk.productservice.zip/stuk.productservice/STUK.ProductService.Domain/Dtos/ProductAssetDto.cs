﻿namespace STUK.ProductService.Domain.Dtos
{
    public class ProductAssetDto
    {
        public string AssetId { get; set; }
        public string InternalAssetId { get; set; }
        public string Title { get; set; }
        public string AssetType { get; set; }
        public DateTime LastUpdatedOn { get; set; }
    }
}
