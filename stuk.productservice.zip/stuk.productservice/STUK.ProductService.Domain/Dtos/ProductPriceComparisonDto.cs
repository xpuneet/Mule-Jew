﻿namespace STUK.ProductService.Domain.Dtos
{
    public class ProductPriceComparisonDto
    {
        public string AccountCode { get; set; }
        public string ProductCode { get; set; }
        public ProductPriceComparisonResults ResultCode { get; set; }
        public string ResultDescription { get { return ResultCode.ToString(); } }
        public string IgnoredDifferences { get; set; }
        public string DatabasePrice { get; set; }
        public string ErpPrice {  get; set; }
        public DateTime CreatedTimestamp { get; set; }
        public string RequestOperationId { get; set; }
        public string AdditionalInfo { get; set; }
    }
}
