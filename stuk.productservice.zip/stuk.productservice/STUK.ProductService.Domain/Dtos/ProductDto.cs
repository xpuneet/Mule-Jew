﻿namespace STUK.ProductService.Domain.Dtos
{
    public class ProductDto
    {
        public string ProductCode { get; set; }
        public string ProductShortDescription { get; set; }
        public string ProductFullDescription { get; set; }
        public string Pac2Code { get; set; }
        public string Pac2Description { get; set; }
        public string SupplierName { get; set; }
        public string SellingUnitCode { get; set; }
        public string UnitOfSaleCode { get; set; }
        public DateTime LastUpdatedOn { get; set; }

        public ProductPriceDto Price { get; set; }

        public List<ProductAssetDto> Assets { get; set; }
    }
}
