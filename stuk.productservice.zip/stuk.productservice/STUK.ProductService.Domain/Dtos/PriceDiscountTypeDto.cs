﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace STUK.ProductService.Domain.Dtos
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PriceDiscountTypeDto
    {
        NotRecognised = 0,
        P = 1, // Fixed
        V = 2, // Variable
    }
}
