﻿namespace STUK.ProductService.Domain.Dtos
{
    public class ConversionUnitDto
    {
        public string UnitName { get; set; }
        public string UnitCode { get; set; }
        public decimal UnitFactor { get; set; }
    }
}
