﻿namespace STUK.ProductService.Domain.Dtos
{
    public class ProductPriceComparisonAddInfoDto
    {
        public int BranchNumber { get; set; }
        public string Source { get; set; }
        public int ProductCount { get; set; }
        public DateTime ErpCallStartTime { get; set; }
        public long ErpCallTimeTaken { get; set; }
    }
}
