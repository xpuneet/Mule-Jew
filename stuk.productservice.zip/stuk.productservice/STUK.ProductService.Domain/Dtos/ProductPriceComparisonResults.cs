﻿namespace STUK.ProductService.Domain.Dtos
{
    [Flags]
    public enum ProductPriceComparisonResults
    {
        NoDifference                = 0,
        DifferentRetail             = 1 << 0, // 0b_00000001 // 1
        DifferentCustomer           = 1 << 1, // 0b_00000010 // 2
        DifferentDiscount           = 1 << 2, // 0b_00000100 // 4
        DifferentUnitCode           = 1 << 3, // 0b_00001000 // 8
        InvalidDiscountFromDatabase = 1 << 4, // 0b_00010000 // 16
        NotFoundInDatabase          = 1 << 5, // 0b_00100000 // 32
        NotFoundInErp               = 1 << 6, // 0b_01000000 // 64
        EprLoadFailed               = 1 << 7, // 0b_10000000 // 128
    }
}
