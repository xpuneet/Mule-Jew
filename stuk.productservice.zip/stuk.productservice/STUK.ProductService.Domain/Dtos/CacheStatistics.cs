﻿namespace STUK.ProductService.Domain.Dtos
{
    public class CacheStatistics
    {
        public string StatisticsKey { get; set; }
        public long RequestCount { get; set; }
        public double CacheHitRate { get; set; }
        public int MaxCacheEntries { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateLastUpdated { get; set; }
        public string AdditionalInfo { get; set; }

        public bool IsNew { get; set; }
    }
}
