﻿namespace STUK.ProductService.Domain.Dtos
{
    public class ProductPriceDto
    {
        public string ProductCode { get; set; }
        public string ProductDescription { get; set; }
        public string UnitCode { get; set; }
        public string UnitDescription { get; set; }
        public decimal Retail { get; set; }
        public decimal Customer { get; set; }
        public decimal Discount { get; set; }
        public PriceDiscountTypeDto? DiscountType { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public string ConvertedUnits { get; set; } = string.Empty;
        public List<ConversionUnitDto> ConversionUnits { get; set; }

        internal static class ColumnNames
        {
            internal const string ProductCode = "partnumber";
            internal const string ProductDescription = "description";
            internal const string Retail = "listPrice";
            internal const string Customer = "nettPrice";
            internal const string Discount = "discount";
            internal const string DiscountType = "priceDisc";
            internal const string UnitCode = "unit";
            internal const string LastUpdatedOn = "TrmProd_lastUpdate";
            internal static List<string> UnitsOfConversion = new List<string> 
            {
                "Sale_Unit",
                "Unit_Of_Sale",
                "Unit_Of_Buy",
                "Unit_Of_Price",
                "Unit_Of_Cost",
                "Unit_Of_Stock",
                "Unit_Of_Alt1",
                "Unit_Of_Alt2",
                "Unit_Of_Alt3",
                "Unit_Of_Alt4",
                "Unit_Of_Alt5",
                "Unit_Of_Alt6"
            };
        }
    }
}
