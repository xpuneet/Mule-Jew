﻿namespace STUK.ProductService.Domain.Exceptions
{
    public class AccountNotFoundException : Exception
    {
        public AccountNotFoundException(string accountCode)
        {
            AccountCode = accountCode;
        }

        public AccountNotFoundException(string accountCode, Exception inner) : base($"Account code '{accountCode} not found", inner)
        {
            AccountCode = accountCode;
        }

        public string AccountCode { get; private set; }
    }
}
