﻿using STUK.ProductService.Contracts.Requests;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Extensions;
using System.Text.RegularExpressions;

namespace STUK.ProductService.Domain.Validation
{
    public static class RequestValidations
    {
        public static bool IsValid(this ProductRequest request, Settings settings, out string failureMessage) 
        {
            if (string.IsNullOrEmpty(request.AccountCode) && request.BranchNumber == default(int))
            {
                return ValidationFailed(RequestValidationMessages.AccountCodeAndBranchNumberMissing, out failureMessage);
            }

            if (string.IsNullOrEmpty(request.AccountCode) && request.BranchNumber > 9999)
            {
                return ValidationFailed(RequestValidationMessages.InvalidBranchNumber, out failureMessage);
            }

            if (string.IsNullOrEmpty(request.AccountCode) == false && Regex.IsMatch(request.AccountCode, settings.AccountCodeValidationRegex) == false)
            {
                return ValidationFailed(RequestValidationMessages.InvalidAccountCode, out failureMessage);
            }

            var requestedProductList = request.ProductCodeList;

            if (requestedProductList.Length > settings.MaxProductsAllowed)
            {
                return ValidationFailed(string.Format(RequestValidationMessages.TooManyProductCodes, settings.MaxProductsAllowed), out failureMessage);
            }

            var invalidProductCodes = requestedProductList.Where(pc => Regex.IsMatch(pc, settings.ProductCodeValidationRegex) == false).ToArray();

            if (invalidProductCodes.Any())
            {
                return ValidationFailed(string.Format(RequestValidationMessages.InvalidProductCodes, invalidProductCodes.JoinStrings()), out failureMessage);
            }

            failureMessage = string.Empty;
            return true;
        }

        public static bool IsValid(this TermProductsRequest request, Settings settings, out string failureMessage)
        {
            if (string.IsNullOrEmpty(request.AccountCode))
            {
                return ValidationFailed(RequestValidationMessages.AccountCodeRequired, out failureMessage);
            }

            if (string.IsNullOrEmpty(request.AccountCode) == false && Regex.IsMatch(request.AccountCode, settings.AccountCodeValidationRegex) == false)
            {
                return ValidationFailed(RequestValidationMessages.InvalidAccountCode, out failureMessage);
            }

            if (request.LastUpdatedTimestamp.HasValue == false)
            {
                return ValidationFailed(RequestValidationMessages.ProductLastUpdatedTimestampRequired, out failureMessage);
            }

            if (request.LastUpdatedTimestamp.GetValueOrDefault() >= DateTime.Now)
            {
                return ValidationFailed(RequestValidationMessages.ProductLastUpdatedTimestampInFuture, out failureMessage);
            }

            if (request.LastUpdatedTimestamp.GetValueOrDefault() < settings.TermProductsMinLastUpdateDate)
            {
                return ValidationFailed(string.Format(RequestValidationMessages.ProductLastUpdatedTimestampTooOld, settings.TermProductsMinLastUpdateDate), out failureMessage);
            }

            if (request.PageNumber < 1)
            {
                return ValidationFailed(RequestValidationMessages.InvalidPageNumber, out failureMessage);
            }

            if (request.PageSize < 1 || request.PageSize > settings.TermProductsMaxPageSize)
            {
                return ValidationFailed(string.Format(RequestValidationMessages.InvalidPageSize, settings.TermProductsMaxPageSize), out failureMessage);
            }

            failureMessage = string.Empty;
            return true;
        }

        private static bool ValidationFailed(string validationMessage, out string failureMessage)
        {
            failureMessage = validationMessage;
            return false;
        }
    }
}
