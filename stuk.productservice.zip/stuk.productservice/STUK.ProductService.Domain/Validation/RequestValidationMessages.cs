﻿namespace STUK.ProductService.Domain.Validation
{
    internal static class RequestValidationMessages
    {
        public const string AccountCodeRequired = "AccountCode is required";
        public const string AccountCodeAndBranchNumberMissing = "AccountCode or BranchNumber must be provided";
        public const string TooManyProductCodes = "Too many product codes specified. Max {0} products allowed";
        public const string InvalidBranchNumber = "Invalid BranchNumber. Allowed range is 1 to 9999";
        public const string InvalidAccountCode = "Invalid AccountCode";
        public const string AccountCodeNotFound = "Customer/account code {0} not found";
        public const string InvalidProductCodes = "Invalid product codes: {0}";
        public const string ProductLastUpdatedTimestampRequired = "ProductLastUpdatedTimestamp is required";
        public const string ProductLastUpdatedTimestampInFuture = "Invalid ProductLastUpdatedTimestamp. Future date is not allowed";
        public const string ProductLastUpdatedTimestampTooOld = "Invalid ProductLastUpdatedTimestamp. Minimum allowed date is {0}";
        public const string InvalidPageNumber = "PageNumber must be 1 or greater";
        public const string InvalidPageSize = "Invalid PageSize, must be between 1 to {0}";
    }
}
