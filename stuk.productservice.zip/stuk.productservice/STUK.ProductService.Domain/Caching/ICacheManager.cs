﻿using STUK.ProductService.Domain.Dtos;

namespace STUK.ProductService.Domain.Caching
{
    public interface ICacheManager
    {
        CachedPricesResponse GetProductPrices(string accountCode, IEnumerable<string> productCodes);
        void SetProductPrices(string accountCode, IEnumerable<ProductPriceDto> productPrices);
        void UpdateCache(bool clearCache, int cacheExpiryMinutes);
    }
}
