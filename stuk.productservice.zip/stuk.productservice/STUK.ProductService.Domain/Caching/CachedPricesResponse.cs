﻿using STUK.ProductService.Domain.Dtos;

namespace STUK.ProductService.Domain.Caching
{
    public class CachedPricesResponse
    {
        public List<ProductPriceDto> CachedPrices { get; set; } = new List<ProductPriceDto>();
        public List<string> NotCachedProductCodes { get; set; } = new List<string>();
    }
}
