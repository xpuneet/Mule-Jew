﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Dtos;
using STUK.ProductService.Domain.Repositories;

namespace STUK.ProductService.Domain.Caching
{
    public class InMemoryCacheManager : ICacheManager
    {
        private const string _cacheKeyTemplate = "{0}-{1}";
        private const string _priceCacheExpiryMinutesName = "PriceCacheExpiryMinutes";
        private static object _updatePriceCache = new Object();
        private static object _priceCacheStatsKey = new Object();
        private readonly IMemoryCache _cache;
        private readonly Settings _settings;
        private readonly IProductRepository _productRepository;
        private readonly ILogger<InMemoryCacheManager> _logger;

        public InMemoryCacheManager(IMemoryCache cache, IOptions<Settings> settingsOptions, IProductRepository productRepository, ILogger<InMemoryCacheManager> logger)
        {
            _cache = cache;
            _settings = settingsOptions.Value;
            _productRepository = productRepository;
            _logger = logger;
        }

        public CachedPricesResponse GetProductPrices(string accountCode, IEnumerable<string> productCodes)
        {
            var response = new CachedPricesResponse();

            foreach (var productCode in productCodes)
            {
                var cachedPrice = _cache.Get<ProductPriceDto>(string.Format(_cacheKeyTemplate, accountCode, productCode));

                if (cachedPrice != null)
                {
                    response.CachedPrices.Add(cachedPrice);
                }
                else
                {
                    response.NotCachedProductCodes.Add(productCode);
                }
            }

            _ = Task.Run(() => UpdatePriceCacheStatisticsAsync(productCodes.Count(), response.CachedPrices.Count));

            return response;
        }

        public void SetProductPrices(string accountCode, IEnumerable<ProductPriceDto> productPrices)
        {
            var cacheEntryOptions = new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now.AddMinutes(GetPriceCacheExpiryMinutes()),
                Size = 1
            };

            foreach (var price in productPrices)
            {
                lock (_updatePriceCache)
                {
                    _cache.Set<ProductPriceDto>(string.Format(_cacheKeyTemplate, accountCode, price.ProductCode), price, cacheEntryOptions);
                }
            }
        }

        public void UpdateCache(bool clearCache, int cacheExpiryMinutes) 
        {
            lock (_updatePriceCache)
            {
                if (clearCache)
                {
                    ((MemoryCache)_cache).Clear();
                }

                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    Priority = CacheItemPriority.NeverRemove,
                    Size = 1
                };

                _cache.Set<int>(_priceCacheExpiryMinutesName, cacheExpiryMinutes, cacheEntryOptions);
            }
        }

        private int GetPriceCacheExpiryMinutes()
        {
            var cacheExpiryMins = _cache.Get<int?>(_priceCacheExpiryMinutesName) ?? (int)_settings.PriceCacheExpiryTime.TotalMinutes;

            return cacheExpiryMins;
        }

        private async Task UpdatePriceCacheStatisticsAsync(int productCount, int cacheHitCount)
        {
            try
            {
                string cacheStatsKeyName = "CacheStatsKeyName";
                string cacheStatsKey;
                var currentTimestamp = DateTime.Now;

                lock (_priceCacheStatsKey)
                {
                    cacheStatsKey = _cache.Get<string>(cacheStatsKeyName);
                    if (cacheStatsKey == null)
                    {
                        var instanceName = Environment.GetEnvironmentVariable("WEBSITE_INSTANCE_ID") ?? "local"; // Azure VM instance name or local
                        cacheStatsKey = $"PriceCache-{currentTimestamp.ToString("yyyyMMddhhmmss")}-{instanceName}";

                        _cache.Set<string>(cacheStatsKeyName, cacheStatsKey, new MemoryCacheEntryOptions { Priority = CacheItemPriority.NeverRemove, Size = 1 });
                    }
                }

                var cacheStats = await _productRepository.GetCacheStatistics(cacheStatsKey) ?? new CacheStatistics { StatisticsKey = cacheStatsKey, IsNew = true, DateCreated = currentTimestamp, AdditionalInfo = string.Empty };

                var currentRequestCacheHitRate = (float)cacheHitCount / productCount;
                var newRequestCount = cacheStats.RequestCount + 1;
                var currentCacheCount = ((MemoryCache)_cache).Count;

                cacheStats.CacheHitRate = Math.Round((cacheStats.CacheHitRate * cacheStats.RequestCount + currentRequestCacheHitRate) / newRequestCount, 4);
                cacheStats.RequestCount = newRequestCount;
                cacheStats.DateLastUpdated = currentTimestamp;
                cacheStats.MaxCacheEntries = Math.Max(cacheStats.MaxCacheEntries, currentCacheCount);
                cacheStats.AdditionalInfo = JsonConvert.SerializeObject(new { CurrentCacheCount = currentCacheCount, CacheDuration = TimeSpan.FromMinutes(GetPriceCacheExpiryMinutes())});

                _productRepository.SaveCacheStatistics(cacheStats);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update price cache stats");
            }
        }
    }
}
