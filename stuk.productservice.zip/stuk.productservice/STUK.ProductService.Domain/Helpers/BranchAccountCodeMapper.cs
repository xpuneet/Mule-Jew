﻿using STUK.ProductService.Domain.Config;
using System.Text.RegularExpressions;

namespace STUK.ProductService.Domain.Helpers
{
    public static class BranchAccountCodeMapper
    {
        public static string RemapAccountCode(string accountCode, int branchNumber, Settings settings)
        {
            if (string.IsNullOrEmpty(accountCode) == false)
            {
                return accountCode;
            }

            foreach (var mapping in settings.BranchToAccountCodeMappings.Keys)
            {
                if (Regex.IsMatch(branchNumber.ToString(), mapping))
                {
                    var replacement = settings.BranchToAccountCodeMappings[mapping];
                    accountCode = Regex.Replace(branchNumber.ToString(), mapping, replacement);

                    return accountCode;
                }
            }

            return $"{branchNumber}-NoMap";
        }
    }
}
