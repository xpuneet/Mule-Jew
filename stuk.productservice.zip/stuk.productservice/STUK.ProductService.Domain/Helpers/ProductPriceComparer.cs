﻿using Newtonsoft.Json;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Dtos;

namespace STUK.ProductService.Domain.Helpers
{
    public class ProductPriceComparer
    {
        public static IEnumerable<ProductPriceComparisonDto> ComparePrices(string accountCode, IEnumerable<string> productCodes, IEnumerable<ProductPriceDto> pricesFromDb, IEnumerable<ProductPriceDto> pricesFromErp, Settings settings, string traceIdentifier, ProductPriceComparisonAddInfoDto additionalInfo)
        {
            var priceComparisons = new List<ProductPriceComparisonDto>();

            var comparisonTimestamp = DateTime.Now;

            foreach (var productCode in productCodes)
            {
                var result = ProductPriceComparisonResults.NoDifference;

                var priceFromDb = pricesFromDb.FirstOrDefault(p => p.ProductCode == productCode);
                var priceFromErp = pricesFromErp?.FirstOrDefault(p => p.ProductCode == productCode);

                var erpLoadFailed = pricesFromErp == null;

                result |= erpLoadFailed ? ProductPriceComparisonResults.EprLoadFailed : result;

                if (priceFromDb != null && priceFromErp != null)
                {
                    result |= IsDifferent(priceFromDb.Retail, priceFromErp.Retail)      ? ProductPriceComparisonResults.DifferentRetail             : result;
                    result |= IsDifferent(priceFromDb.Customer, priceFromErp.Customer)  ? ProductPriceComparisonResults.DifferentCustomer           : result;
                    result |= IsDifferent(priceFromDb.Discount, priceFromErp.Discount)  ? ProductPriceComparisonResults.DifferentDiscount           : result;
                    result |= IsDifferent(priceFromDb.UnitCode, priceFromErp.UnitCode)  ? ProductPriceComparisonResults.DifferentUnitCode           : result;
                    result |= IsInvalidDiscount(priceFromDb)                            ? ProductPriceComparisonResults.InvalidDiscountFromDatabase : result;
                }
                else
                {
                    result |= priceFromDb   == null ? ProductPriceComparisonResults.NotFoundInDatabase : result;
                    result |= priceFromErp  == null && erpLoadFailed == false ? ProductPriceComparisonResults.NotFoundInErp : result;
                }

                // Remove ignored differences (if any)
                settings.PriceComparisonIgnoreDifferences?.ForEach(d => result &= ~d);

                if (result != ProductPriceComparisonResults.NoDifference || settings.PriceComparisonLogMatch)
                {
                    priceComparisons.Add(new ProductPriceComparisonDto
                    {
                        AccountCode = accountCode,
                        ProductCode = productCode,
                        ResultCode = result,
                        DatabasePrice = JsonConvert.SerializeObject(priceFromDb),
                        IgnoredDifferences = string.Join(", ", settings.PriceComparisonIgnoreDifferences ?? new List<ProductPriceComparisonResults>()),
                        ErpPrice = JsonConvert.SerializeObject(priceFromErp),
                        CreatedTimestamp = comparisonTimestamp,
                        RequestOperationId = traceIdentifier,
                        AdditionalInfo = JsonConvert.SerializeObject(additionalInfo)
                    });
                }
            }

            return priceComparisons;
        }

        private static bool IsDifferent(decimal value1, decimal value2)
        {
            return value1.CompareTo(value2) != 0;
        }

        private static bool IsDifferent(string value1, string value2)
        {
            return value1.ToLower().Equals(value2.ToLower()) == false;
        }

        private static bool IsInvalidDiscount(ProductPriceDto productPrice)
        {
            var calculatedDiscount = (productPrice.Retail-productPrice.Customer)/productPrice.Retail*100;

            return IsDifferent(Math.Round(calculatedDiscount,2), productPrice.Discount);
        }
    }
}
