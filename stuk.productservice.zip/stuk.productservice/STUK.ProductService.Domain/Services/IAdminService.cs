﻿using STUK.ProductService.Contracts.Requests;

namespace STUK.ProductService.Domain.Services
{
    public interface IAdminService
    {
        public Task<ServiceResponse> UpdateCache(UpdateCacheRequest request);
    }
}
