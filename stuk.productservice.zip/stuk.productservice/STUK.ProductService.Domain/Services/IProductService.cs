﻿using STUK.ProductService.Contracts.Requests;

namespace STUK.ProductService.Domain.Services
{
    public interface IProductService
    {
        public Task<ProductsServiceResponse> GetProductDetails(ProductRequest request);
        public Task<ProductsServiceResponse> GetTermProducts(TermProductsRequest request);
    }
}
