﻿using AutoMapper;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.ProductService.Contracts.Models;
using STUK.ProductService.Contracts.Requests;
using STUK.ProductService.Domain.Caching;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Dtos;
using STUK.ProductService.Domain.Exceptions;
using STUK.ProductService.Domain.Extensions;
using STUK.ProductService.Domain.Helpers;
using STUK.ProductService.Domain.Repositories;
using STUK.ProductService.Domain.Validation;
using System.Diagnostics;

namespace STUK.ProductService.Domain.Services
{
    public class AdminService : IAdminService
    {
        private readonly ICacheManager _cacheManager;
        private readonly ILogger<AdminService> _logger;

        public AdminService(ICacheManager cacheManager, ILogger<AdminService> logger)
        {
            _cacheManager = cacheManager;
            _logger = logger;
        }

        public async Task<ServiceResponse> UpdateCache(UpdateCacheRequest request)
        {
            try
            {
                _cacheManager.UpdateCache(request.ClearCache, request.CacheExpiryMinutes);

                _logger.LogInformation("Cache updated successfully!");
                return ServiceResponse.Ok();
            }
            catch (Exception ex)
            {
                var message = $"Unable to update cache - {ex.Message}";

                _logger.LogWarning(message);
                return ServiceResponse.Error(message);
            }
        }
    }
}
