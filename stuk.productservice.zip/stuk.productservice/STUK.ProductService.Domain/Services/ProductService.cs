﻿using AutoMapper;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.ProductService.Contracts.Models;
using STUK.ProductService.Contracts.Requests;
using STUK.ProductService.Domain.Caching;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Dtos;
using STUK.ProductService.Domain.Exceptions;
using STUK.ProductService.Domain.Extensions;
using STUK.ProductService.Domain.Helpers;
using STUK.ProductService.Domain.Repositories;
using STUK.ProductService.Domain.Validation;
using System.Diagnostics;

namespace STUK.ProductService.Domain.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly IErpRepository _erpRepository;
        private readonly IMapper _mapper;
        private readonly Settings _settings;
        private readonly ICacheManager _cacheManager;
        private readonly ILogger<ProductService> _logger;

        public ProductService(IProductRepository productRepository, IErpRepository erpRepository, IMapper mapper, IOptions<Settings> settingsOptions, ICacheManager cacheManager, ILogger<ProductService> logger)
        {
            _productRepository = productRepository;
            _erpRepository = erpRepository;
            _mapper = mapper;
            _settings = settingsOptions.Value;
            _cacheManager = cacheManager;
            _logger = logger;
        }

        public async Task<ProductsServiceResponse> GetProductDetails(ProductRequest request)
        {
            if (request.IsValid(_settings, out string failureMessage) == false)
            {
                return ProductsServiceResponse.Error(failureMessage);
            }

            request.AccountCode = BranchAccountCodeMapper.RemapAccountCode(request.AccountCode, request.BranchNumber, _settings);

            IEnumerable<ProductPriceDto> pricesFound = null;
            try
            {
                pricesFound = await GetProductsPrice(request);
            }
            catch (AccountNotFoundException ex)
            {
                return ProductsServiceResponse.Error(string.Format(RequestValidationMessages.AccountCodeNotFound, ex.AccountCode));
            }

            var stocksFound = new List<ProductStockDto>();

            var productList = new List<Product>();

            foreach (var productCode in request.ProductCodeList)
            {
                var productPrice = pricesFound?.FirstOrDefault(pp => pp.ProductCode == productCode);
                var productStock = stocksFound.FirstOrDefault(ps => ps.ProductCode == productCode);

                productList.Add(new Product
                {
                    ProductCode = productCode,
                    ProductFullDescription = productPrice?.ProductDescription, //?? productStock?.ProductDescription
                    Price = _mapper.Map<ProductPrice>(productPrice),
                    Stock = _mapper.Map<ProductStock>(productStock),
                    Error = (productPrice == null && productStock == null) ? new ProductError { Code = "404", Message = "Product not found" } : null
                });
            }

            return ProductsServiceResponse.Ok(productList);
        }

        public async Task<ProductsServiceResponse> GetTermProducts(TermProductsRequest request)
        {
            if (request.IsValid(_settings, out string failureMessage) == false)
            {
                return ProductsServiceResponse.Error(failureMessage);
            }

            var termProductDtos = await _productRepository.GetTermProducts(request);

            var productPrices = termProductDtos.Select(p => p.Price);
            ConvertProductPriceUnits(request.AccountCode, productPrices);

            var termProducts = _mapper.Map<List<Product>>(termProductDtos);

            return ProductsServiceResponse.Ok(termProducts);
        }

        private async Task<IEnumerable<ProductPriceDto>> GetProductsPrice(ProductRequest request)
        {
            if (_settings.PriceCacheEnabled == false) 
            { 
                return await LoadProductsPrice(request.AccountCode, request.ProductCodeList, request.BranchNumber, request.Source);
            }

            var cachedPricesResponse = _cacheManager.GetProductPrices(request.AccountCode, request.ProductCodeList);
            var productPrices = cachedPricesResponse.CachedPrices;

            if (cachedPricesResponse.NotCachedProductCodes.Any())
            {
                var pricesFromDb = await LoadProductsPrice(request.AccountCode, cachedPricesResponse.NotCachedProductCodes, request.BranchNumber, request.Source);
                productPrices.AddRange(pricesFromDb);
                _cacheManager.SetProductPrices(request.AccountCode, pricesFromDb);
            }

            return productPrices;
        }

        private async Task<IEnumerable<ProductPriceDto>> LoadProductsPrice(string accountCode, IEnumerable<string> productCodeList, int branchNumber, string source)
        {
            var productsPriceList = await _productRepository.GetProductsPrice(accountCode, productCodeList);

            // Convert units
            ConvertProductPriceUnits(accountCode, productsPriceList);

            if (_settings.PriceComparisonEnabled && _settings.PriceComparisonAccountCodes.Contains(accountCode))
            {
                var traceIdentifier = GetTelemetryOperationId();
                _ = Task.Run(() => ComparePrices(accountCode, productCodeList, branchNumber, productsPriceList, traceIdentifier, source));
            }

            return productsPriceList;
        }

        private void ConvertProductPriceUnits(string accountCode, IEnumerable<ProductPriceDto> productsPriceList)
        {
            // Convert units
            string saleUnitName = "Sale_Unit";
            string unitOfSaleName = "Unit_Of_Sale";

            foreach (var productPrice in productsPriceList)
            {
                var startingUnit = productPrice.DiscountType.GetValueOrDefault() == PriceDiscountTypeDto.P
                                    ? productPrice.ConversionUnits.FirstOrDefault(u => u.UnitCode.Equals(productPrice.UnitCode, StringComparison.OrdinalIgnoreCase))
                                    : productPrice.ConversionUnits.FirstOrDefault(u => u.UnitName.Equals(saleUnitName, StringComparison.OrdinalIgnoreCase));

                var termUnit = productPrice.ConversionUnits.FirstOrDefault(u => u.UnitCode.Equals(productPrice.UnitCode, StringComparison.OrdinalIgnoreCase));
                var unitOfSale = productPrice.ConversionUnits.FirstOrDefault(u => u.UnitName.Equals(unitOfSaleName, StringComparison.OrdinalIgnoreCase));

                if (termUnit == null || startingUnit == null || unitOfSale == null)
                {
                    var message = $"Unable to check/perform unit conversion. AccountCode:{accountCode}, ProductCode: {productPrice.ProductCode}. Term unit '{productPrice.UnitCode}' and/or '{saleUnitName}' and/or {unitOfSaleName} do not exist in conversion units";
                    _logger.LogError(message);

                    continue;
                }

                // convert from term/sale unit to term unit and then to unit of sale 
                productPrice.Retail = ConvertPrice(productPrice.Retail, startingUnit, termUnit, unitOfSale);
                productPrice.Customer = ConvertPrice(productPrice.Customer, startingUnit, termUnit, unitOfSale);
                productPrice.UnitCode = unitOfSale.UnitCode;
                productPrice.ConvertedUnits = $"{startingUnit.UnitCode}->{termUnit.UnitCode}->{unitOfSale.UnitCode}";
            }
        }

        private static decimal ConvertPrice(decimal price, ConversionUnitDto sourceUnit, ConversionUnitDto interimUnit, ConversionUnitDto targetUnit)
        {
            var interimPrice = Decimal.Round(price / sourceUnit.UnitFactor * interimUnit.UnitFactor, 2, MidpointRounding.AwayFromZero);
            var convertedPrice = Decimal.Round(interimPrice / interimUnit.UnitFactor * targetUnit.UnitFactor, 2, MidpointRounding.AwayFromZero);

            return convertedPrice;
        }

        private async void ComparePrices(string accountCode, IEnumerable<string> productCodes, int branchNumber, IEnumerable<ProductPriceDto> pricesFromDb, string traceIdentifier, string source)
        {            
            try
            {
                var additionalInfo = new ProductPriceComparisonAddInfoDto
                {
                    BranchNumber = branchNumber,
                    Source = source,
                    ProductCount = productCodes.Count(),
                    ErpCallStartTime = DateTime.Now
                };

                var swErpCall = Stopwatch.StartNew();
                
                var pricesFromErp = await _erpRepository.GetProductsPrice(accountCode, productCodes, branchNumber);
                
                swErpCall.Stop();
                additionalInfo.ErpCallTimeTaken = swErpCall.ElapsedMilliseconds;

                var priceComparisons = ProductPriceComparer.ComparePrices(accountCode, productCodes, pricesFromDb, pricesFromErp, _settings, traceIdentifier, additionalInfo);
                
                if (priceComparisons.Any()) 
                {
                    _productRepository.SaveProductPriceComparisons(priceComparisons);
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Error performing price comparison. AccountCode: { accountCode }, ProductCodes: '{ productCodes.JoinStrings() }', Message: { ex.Message }", ex);
            }
        }

        private string GetTelemetryOperationId()
        {
            var operationId = default(string);
            try
            {
                var telemetry = new RequestTelemetry();

                TelemetryConfiguration
                    .CreateDefault()
                    .TelemetryInitializers
                    .OfType<OperationCorrelationTelemetryInitializer>()
                    .Single()
                    .Initialize(telemetry);

                operationId = telemetry.Context.Operation.Id;

            }
            catch (Exception ex)
            {
                operationId = $"local-{Guid.NewGuid}";

                _logger.LogError($"Failed to get Telemetry operationId, using locally generated Id: { operationId }. Error: { ex.Message }");
            }

            return operationId;
        }
    }
}
