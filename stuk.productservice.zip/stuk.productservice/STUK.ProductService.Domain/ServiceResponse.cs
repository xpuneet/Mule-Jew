﻿namespace STUK.ProductService.Domain
{
    public class ServiceResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }

        public static ServiceResponse Ok()
        {
            return new ServiceResponse
            {
                Success = true
            };
        }

        public static ServiceResponse Error(string message)
        {
            return new ServiceResponse
            {
                Success = false,
                Message = message
            };
        }
    }
}
