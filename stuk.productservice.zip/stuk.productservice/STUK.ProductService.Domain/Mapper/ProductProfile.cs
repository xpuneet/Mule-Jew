﻿using AutoMapper;
using STUK.ProductService.Contracts.Models;
using STUK.ProductService.Domain.Dtos;

namespace STUK.ProductService.Domain.Mapper
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<ProductPriceDto, ProductPrice>()
                .ForPath(dest => dest.Unit.Code, options => options.MapFrom(source => source.UnitCode))
                .ForPath(dest => dest.Unit.Description, options => options.MapFrom(source => source.UnitDescription));

            CreateMap<ProductStockDto, ProductStock>();

            CreateMap<ProductDto, Product>()
                .ForPath(dest => dest.SellingUnit.Code, options => options.MapFrom(source => source.SellingUnitCode))
                .ForPath(dest => dest.UnitOfSale.Code, options => options.MapFrom(source => source.UnitOfSaleCode));

            CreateMap<ProductAssetDto, ProductAsset>();
        }
    }
}
