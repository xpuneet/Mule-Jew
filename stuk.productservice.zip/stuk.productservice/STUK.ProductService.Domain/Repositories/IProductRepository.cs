﻿using STUK.ProductService.Contracts.Requests;
using STUK.ProductService.Domain.Dtos;

namespace STUK.ProductService.Domain.Repositories
{
    public interface IProductRepository
    {
        Task<IEnumerable<ProductPriceDto>> GetProductsPrice(string accountCode, IEnumerable<string> productCodeList);
        Task<IEnumerable<ProductStockDto>> GetProductsStock(string accountCode, string productCodes);
        Task<IEnumerable<ProductDto>> GetTermProducts(TermProductsRequest request);

        void SaveProductPriceComparisons(IEnumerable<ProductPriceComparisonDto> comparisons);

        Task<CacheStatistics> GetCacheStatistics(string statsKey);
        void SaveCacheStatistics(CacheStatistics priceCacheStats);
    }
}
