﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace STUK.ProductService.Domain.Repositories.DbContexts
{
    public class DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public DbContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("ProductServiceProductDB"); // ConnectionString from appsettings or AzureKeyVault (if integrated)
        }
        public IDbConnection CreateConnection() => new SqlConnection(_connectionString);
    }
}
