﻿using STUK.ProductService.Domain.Dtos;

namespace STUK.ProductService.Domain.Repositories
{
    public interface IErpRepository
    {
        Task<IEnumerable<ProductPriceDto>> GetProductsPrice(string accountCode, IEnumerable<string> productCodeList, int branchNumber);
    }
}
