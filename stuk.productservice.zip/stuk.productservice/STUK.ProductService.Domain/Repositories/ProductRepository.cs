﻿using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using STUK.ProductService.Contracts.Requests;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Dtos;
using STUK.ProductService.Domain.Exceptions;
using STUK.ProductService.Domain.Extensions;
using STUK.ProductService.Domain.Repositories.DbContexts;
using System.Data;
using System.Diagnostics;
using System.Text.Json.Nodes;

namespace STUK.ProductService.Domain.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly DbContext _dbContext;
        private readonly Settings _settings;
        private ILogger<ProductRepository> _logger;

        public ProductRepository(DbContext dbContext, IOptions<Settings> settingsOptions, ILogger<ProductRepository> logger)
        {
            _dbContext = dbContext;
            _settings = settingsOptions.Value;
            _logger = logger;
        }

        public async Task<IEnumerable<ProductPriceDto>> GetProductsPrice(string accountCode, IEnumerable<string> productCodeList)
        {
            try
            {
                var productPrices = new List<ProductPriceDto>();

                using (var sqlConnection = _dbContext.CreateConnection())
                {
                    sqlConnection.Open();

                    using (var sqlCommand = sqlConnection.CreateCommand())
                    {
                        sqlCommand.CommandTimeout = _settings.SqlCommandTimeoutSeconds;
                        sqlCommand.CommandText = "GetProductPrices";
                        sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;

                        sqlCommand.Parameters.Add(new SqlParameter("@Customer", accountCode));
                        sqlCommand.Parameters.Add(new SqlParameter("@PartNumbers", productCodeList.Distinct().JoinStrings()));

                        using (var sqlDataReader = sqlCommand.ExecuteReader())
                        {
                            while (sqlDataReader.Read())
                            {
                                var productPrice = new ProductPriceDto
                                {
                                    ProductCode = sqlDataReader.GetString(ProductPriceDto.ColumnNames.ProductCode),
                                    ProductDescription = sqlDataReader.GetString(ProductPriceDto.ColumnNames.ProductDescription),
                                    UnitCode = sqlDataReader.GetString(ProductPriceDto.ColumnNames.UnitCode),
                                    Customer = sqlDataReader.GetDecimal(ProductPriceDto.ColumnNames.Customer),
                                    Retail = sqlDataReader.GetDecimal(ProductPriceDto.ColumnNames.Retail),
                                    Discount = sqlDataReader.GetDecimal(ProductPriceDto.ColumnNames.Discount),
                                    DiscountType = GetPriceDiscountType(sqlDataReader.GetString(ProductPriceDto.ColumnNames.DiscountType)),
                                    LastUpdatedOn = sqlDataReader.GetDateTime(ProductPriceDto.ColumnNames.LastUpdatedOn),
                                };

                                productPrice.ConversionUnits = new List<ConversionUnitDto>();

                                foreach (var conversionUnitCol in ProductPriceDto.ColumnNames.UnitsOfConversion)
                                {
                                    var conversionUnit = new ConversionUnitDto
                                    {
                                        UnitName = conversionUnitCol,
                                        UnitCode = sqlDataReader.GetString(conversionUnitCol),
                                        UnitFactor = sqlDataReader.GetDecimal($"{conversionUnitCol}_Factor")
                                    };

                                    productPrice.ConversionUnits.Add(conversionUnit);
                                }

                                productPrices.Add(productPrice);
                            }
                        }
                    }
                }

                return productPrices;
            }
            catch (SqlException sqlException)
            {
                if (sqlException.Message.Replace(" ", "").Equals($"customer{accountCode}notfound", StringComparison.OrdinalIgnoreCase))
                {
                    throw new AccountNotFoundException(accountCode, sqlException);
                }

                throw;
            }
        }

        private PriceDiscountTypeDto? GetPriceDiscountType(string discountType)
        { 
            if (!string.IsNullOrEmpty(discountType)) 
            {
                Enum.TryParse<PriceDiscountTypeDto>(discountType, out PriceDiscountTypeDto result);

                return result;
            }

            return null;
        }

        public async Task<IEnumerable<ProductStockDto>> GetProductsStock(string accountCode, string productCodes)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<ProductDto>> GetTermProducts(TermProductsRequest request)
        {
            var storedProcedureName = "GetProductChanges";
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@Customer", dbType: System.Data.DbType.String, value: request.AccountCode);
            parameters.Add("@PageNumber", dbType: System.Data.DbType.Int16, value: request.PageNumber);
            parameters.Add("@PageSize", dbType: System.Data.DbType.Int16, value: request.PageSize);
            parameters.Add("@lastUpdateTimestamp", dbType: System.Data.DbType.String, value: request.LastUpdatedTimestamp.Value.ToString("yyyy-MM-dd hh:mm:ss"));

            var dbQueryTimer = Stopwatch.StartNew();

            using (var connection = _dbContext.CreateConnection())
            {
                var productsWithAssets = connection.Query(storedProcedureName, parameters, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: _settings.SqlCommandTimeoutSeconds);
                dbQueryTimer.Stop();

                var dataParseTimer = Stopwatch.StartNew();
                var products = new List<ProductDto>();

                foreach (var productWithAssets in productsWithAssets.GroupBy(pwa => pwa.productCode))
                {
                    var firstProduct = productWithAssets.First();
                    var firstProductFields = new Dictionary<string, object>(firstProduct as IDictionary<string, object>, StringComparer.OrdinalIgnoreCase);

                    var product = new ProductDto();              
                    product.ProductCode = firstProduct.productCode;
                    product.ProductFullDescription = firstProduct.productFullDescription;
                    product.ProductShortDescription = firstProduct.productShortDescription;
                    product.Pac2Code = firstProduct.pac2Code;
                    product.Pac2Description = firstProduct.pac2Description;
                    product.SupplierName = firstProduct.supplierName;
                    product.SellingUnitCode = firstProduct.Sale_Unit;
                    product.UnitOfSaleCode = firstProduct.Unit_Of_Sale;
                    product.LastUpdatedOn = firstProduct.Product_lastUpdate;

                    product.Price = new ProductPriceDto();
                    product.Price.ProductCode = firstProduct.productCode;
                    product.Price.ProductDescription = firstProduct.productFullDescription;
                    product.Price.UnitCode = firstProductFields[ProductPriceDto.ColumnNames.UnitCode].ToString();
                    product.Price.LastUpdatedOn = DateTime.Parse(firstProductFields[ProductPriceDto.ColumnNames.LastUpdatedOn].ToString());
                    product.Price.Customer = Decimal.Parse(firstProductFields[ProductPriceDto.ColumnNames.Customer].ToString());
                    product.Price.Retail = Decimal.Parse(firstProductFields[ProductPriceDto.ColumnNames.Retail].ToString());
                    product.Price.Discount = Decimal.Parse(firstProductFields[ProductPriceDto.ColumnNames.Discount].ToString());
                    product.Price.DiscountType = GetPriceDiscountType(firstProductFields[ProductPriceDto.ColumnNames.Discount].ToString());

                    product.Price.ConversionUnits = new List<ConversionUnitDto>();
                    foreach (var unitOfConversion in ProductPriceDto.ColumnNames.UnitsOfConversion)
                    {
                        var cUnit = new ConversionUnitDto
                        {
                            UnitName = unitOfConversion,
                            UnitCode = firstProductFields[unitOfConversion].ToString(),
                            UnitFactor = Decimal.Parse(firstProductFields[$"{unitOfConversion}_Factor"].ToString())
                        };
                        product.Price.ConversionUnits.Add(cUnit);
                    }

                    product.Assets = new List<ProductAssetDto>();

                    foreach (var asset in productWithAssets.Where(a => string.IsNullOrEmpty(a.assetId) == false))
                    {
                        product.Assets.Add(new ProductAssetDto
                        {
                            AssetId = asset.assetId,
                            InternalAssetId = asset.InternalAssetId,
                            Title = asset.title,
                            AssetType = asset.AssetType,
                            LastUpdatedOn = asset.Asset_lastUpdate
                        });
                    }

                    products.Add(product);
                }

                dataParseTimer.Stop();

                var retrievalInfo = new 
                { 
                    AccountCode = request.AccountCode,
                    PageNumber = request.PageNumber,
                    PageSize = request.PageSize,
                    LastUpdateTimestamp = request.LastUpdatedTimestamp,
                    QueryTimeMS = dbQueryTimer.ElapsedMilliseconds,
                    ParseTimeMS = dataParseTimer.ElapsedMilliseconds,
                    Products = products.Count,
                    Assets = productsWithAssets.Count(),
                    Source = request.Source
                };

                _logger.LogInformation($"TermProducts retrieval info: {JsonConvert.SerializeObject(retrievalInfo)}");
                
                return products;
            }            
        }

        public void SaveProductPriceComparisons(IEnumerable<ProductPriceComparisonDto> comparisons)
        {
            string comparisonsQuery = "INSERT INTO ProductPriceComparisons (AccountCode, ProductCode, ResultCode, ResultDescription, IgnoredDifferences, DatabasePrice, ErpPrice, CreatedTimestamp, RequestOperationId, AdditionalInfo) VALUES (@AccountCode, @ProductCode, @ResultCode, @ResultDescription, @IgnoredDifferences, @DatabasePrice, @ErpPrice, @CreatedTimestamp, @RequestOperationId, @AdditionalInfo)";
            using (var connection = _dbContext.CreateConnection())
            {
                connection.Execute(comparisonsQuery, comparisons);
            }
        }

        public async Task<CacheStatistics> GetCacheStatistics(string statsKey)
        {
            string sql = "SELECT StatisticsKey, RequestCount, CacheHitRate, MaxCacheEntries, DateCreated, DateLastUpdated, AdditionalInfo FROM CacheStatistics WHERE StatisticsKey = @StatsKey";

            using (var connection = _dbContext.CreateConnection())
            {
                var result = await connection.QueryFirstOrDefaultAsync<CacheStatistics>(sql, new { StatsKey = new DbString { Value = statsKey }});

                return result;
            }
        }

        public void SaveCacheStatistics(CacheStatistics priceCacheStats)
        {
            var insertQuery = "INSERT INTO CacheStatistics (StatisticsKey, RequestCount, CacheHitRate, MaxCacheEntries, DateCreated, DateLastUpdated, AdditionalInfo) VALUES (@StatisticsKey, @RequestCount, @CacheHitRate, @MaxCacheEntries, @DateCreated, @DateLastUpdated, @AdditionalInfo);";
            var updateQuery = "UPDATE CacheStatistics SET RequestCount = @RequestCount, CacheHitRate = @CacheHitRate, MaxCacheEntries = @MaxCacheEntries, DateLastUpdated = @DateLastUpdated, AdditionalInfo = @AdditionalInfo WHERE StatisticsKey = @StatisticsKey;";

            using (var connection = _dbContext.CreateConnection())
            {
                connection.Execute(priceCacheStats.IsNew ? insertQuery : updateQuery, priceCacheStats);
            }
        }
    }
}
