﻿using Duende.AccessTokenManagement;
using IdentityModel.Client;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using STUK.ProductService.Domain.Dtos;
using STUK.ProductService.Domain.Extensions;
using System.Text;

namespace STUK.ProductService.Domain.Repositories
{
    public class ErpByMulesoftRepository : IErpRepository
    {
        public static string IdentityServerClient = "MulesoftIdentityServerClient";
        public static string ProductApiClient = "MulesoftProductApiClient";

        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IClientCredentialsTokenManagementService _tokenManagementService;
        private readonly ILogger<ErpByMulesoftRepository> _logger;

        public ErpByMulesoftRepository(IHttpClientFactory httpClientFactory, IClientCredentialsTokenManagementService tokenManagementService, ILogger<ErpByMulesoftRepository> logger)
        {
            _httpClientFactory = httpClientFactory;
            _tokenManagementService = tokenManagementService;
            _logger = logger;
        }

        public async Task<IEnumerable<ProductPriceDto>> GetProductsPrice(string accountCode, IEnumerable<string> productCodeList, int branchNumber)
        {
            var productApiClient = _httpClientFactory.CreateClient(ProductApiClient);

            var token = await _tokenManagementService.GetAccessTokenAsync(IdentityServerClient);

            productApiClient.SetBearerToken(token.AccessToken);

            var productsJSON = JsonConvert.SerializeObject(new { product = productCodeList });
            var requestContent = new StringContent(productsJSON, Encoding.UTF8, "application/json");

            var requestUri = productApiClient.BaseAddress.Host.EndsWith("/") ? string.Empty : "/";
            requestUri += $"product-eapi/v2/product/price?account={accountCode}&branch={branchNumber}";
            
            var apiResponse = await productApiClient.PostAsync(requestUri, requestContent);            
            var responseContent = await apiResponse.Content.ReadAsStringAsync();

            if (apiResponse.IsSuccessStatusCode == false)
            {
                _logger.LogError($"Error loading prices from ERP system for AccountCode: {accountCode}, ProductCodes: { productCodeList.JoinStrings() }, BranchNumber: {branchNumber}. Response: {responseContent}");
                return null;
            }

            var prices = JsonConvert.DeserializeObject<List<dynamic>>(responseContent);

            var productsPrice = new List<ProductPriceDto>();
            foreach (var price in prices) 
            {
                productsPrice.Add(new ProductPriceDto 
                { 
                    ProductCode = price.ProductCode,
                    UnitCode = price.Unit.Code,
                    UnitDescription = price.Unit.Short,
                    Retail = price.Retail,
                    Customer = price.Customer,
                    Discount = price.Discount
                });
            }

            return productsPrice;
        }
    }
}
