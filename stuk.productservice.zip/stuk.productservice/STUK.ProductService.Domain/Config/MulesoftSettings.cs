﻿namespace STUK.ProductService.Domain.Config
{
    public class MulesoftSettings
    {
        public string AccessTokenUrl { get; set; }
        public string AccessTokenClientId { get; set; }
        public string AccessTokenClientSecret { get; set; }
        public string AccessTokenClientName { get; set; }
        public string ProductApiBaseUrl { get; set; }
        public string RequestSource { get; set; }
        public string RequestEnvironment { get; set; }
        public int RequestTimeoutSeconds { get; set; }
    }
}
