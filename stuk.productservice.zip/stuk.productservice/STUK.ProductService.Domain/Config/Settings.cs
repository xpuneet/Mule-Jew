﻿using STUK.ProductService.Domain.Caching;
using STUK.ProductService.Domain.Dtos;

namespace STUK.ProductService.Domain.Config
{
    public class Settings
    {
        public int MaxProductsAllowed { get; set; }
        public string AccountCodeValidationRegex { get; set; }
        public string ProductCodeValidationRegex { get; set; }
        public Dictionary<string, string> BranchToAccountCodeMappings { get; set; }

        public bool PriceCacheEnabled { get; set; }
        public TimeSpan PriceCacheExpiryTime { get; set; }

        public int SqlCommandTimeoutSeconds { get; set; }
        public bool PriceComparisonEnabled { get; set; }
        public List<string> PriceComparisonAccountCodes { get; set; }
        public List<ProductPriceComparisonResults> PriceComparisonIgnoreDifferences { get; set; }
        public bool PriceComparisonLogMatch { get; set; }

        public int TermProductsMaxPageSize { get; set; }
        public DateTime TermProductsMinLastUpdateDate { get; set; }
    }
}
