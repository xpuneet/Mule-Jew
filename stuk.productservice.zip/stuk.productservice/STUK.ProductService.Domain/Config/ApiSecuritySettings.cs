﻿namespace STUK.ProductService.Domain.Config
{
    public class ApiSecuritySettings
    {
        public static class AuthenticationSchemes 
        {
            public const string Reader = "Reader";
            public const string Admin = "Admin";
        }

        public string OpenIdAuthority { get; set; }
        public Dictionary<string, string> SchemeToScopeMappings { get; set; }
    }
}
