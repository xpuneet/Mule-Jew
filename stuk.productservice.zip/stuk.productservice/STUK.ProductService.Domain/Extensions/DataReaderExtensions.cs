﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace STUK.ProductService.Domain.Extensions
{
    public static class DataReaderExtensions
    {
        public static string GetString(this IDataReader dataReader, string columnName)
        {
            if (dataReader[columnName] == DBNull.Value)
            {
                return null;
            }

            return dataReader[columnName].ToString();
        }

        public static int GetInt(this IDataReader dataReader, string columnName)
        {
            return int.Parse(dataReader[columnName].ToString());
        }

        public static int? GetNullableInt(this IDataReader dataReader, string columnName)
        {
            if (dataReader[columnName] == DBNull.Value)
            {
                return null;
            }

            return dataReader.GetInt(columnName);
        }

        public static decimal GetDecimal(this IDataReader dataReader, string columnName)
        {
            return decimal.Parse(dataReader[columnName].ToString());
        }

        public static decimal? GetNullableDecimal(this IDataReader dataReader, string columnName)
        {
            if (dataReader[columnName] == DBNull.Value)
            {
                return null;
            }

            return dataReader.GetDecimal(columnName);
        }

        public static DateTime? GetNullableDateTime(this IDataReader dataReader, string columnName)
        {
            if (dataReader[columnName] == DBNull.Value)
            {
                return null;
            }

            return dataReader.GetDateTime(columnName);
        }

        public static DateTime GetDateTime(this IDataReader dataReader, string columnName)
        {
            return DateTime.Parse(dataReader[columnName].ToString());
        }

        public static bool? GetNullableBool(this IDataReader dataReader, string columnName)
        {
            if (dataReader[columnName] == DBNull.Value)
            {
                return null;
            }

            return dataReader.GetBool(columnName);
        }

        public static bool GetBool(this IDataReader dataReader, string columnName)
        {
            if (int.TryParse(dataReader[columnName].ToString(), out int result))
            {
                return result > 0;
            }

            return bool.Parse(dataReader[columnName].ToString());
        }
    }
}
