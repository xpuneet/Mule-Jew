﻿namespace STUK.ProductService.Domain.Extensions
{
    public static class StringExtensions
    {
        public static string? JoinStrings(this IEnumerable<string> values)
        {
            return values?.JoinStrings(",");
        }
        public static string? JoinStrings(this IEnumerable<string> values, string separator)
        {
            if (values == null) return null;

            return string.Join(separator, values);
        }
    }
}
