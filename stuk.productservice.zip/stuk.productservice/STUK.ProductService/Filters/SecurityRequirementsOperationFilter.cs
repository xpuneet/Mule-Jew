﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.OpenApi.Models;
using STUK.ProductService.Domain.Config;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace STUK.ProductService.Filters
{
    internal class SecurityRequirementsOperationFilter : IOperationFilter
    {
        private readonly IConfiguration _configuration;

        public SecurityRequirementsOperationFilter(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (context != null && operation != null)
            {
                // AuthenticationSchemes map to scopes
                // for class level authentication schemes
                var requiredScopesByClass = context.MethodInfo.DeclaringType
                        .GetCustomAttributes(true)
                        .OfType<AuthorizeAttribute>()
                        .Select(attr => attr.AuthenticationSchemes)
                        .Distinct();

                //  for method level authentication scheme
                var requiredScopesByMethod = context.MethodInfo
                        .GetCustomAttributes(true)
                        .OfType<AuthorizeAttribute>()
                        .Select(attr => attr.AuthenticationSchemes)
                        .Distinct();

                bool requireAuth = false;
                string id = "";
                var apiSecuritySettings = _configuration.GetSection("ApiSecuritySettings").Get<ApiSecuritySettings>();
                foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
                {
                    if (requiredScopesByMethod.Contains(scheme) || requiredScopesByClass.Contains(scheme))
                    {
                        requireAuth = true;
                        id = $"Bearer:{apiSecuritySettings.SchemeToScopeMappings[scheme]}";

                        break;
                    }
                }

                if (requireAuth && !string.IsNullOrEmpty(id))
                {
                    var unauthorizedResponseKey = "401";
                    if (!operation.Responses.ContainsKey(unauthorizedResponseKey))
                    {
                        operation.Responses.Add(unauthorizedResponseKey, new OpenApiResponse { Description = "Unauthorized" });
                    }

                    operation.Security = new List<OpenApiSecurityRequirement>
                    {
                        new OpenApiSecurityRequirement
                        {
                            {
                                new OpenApiSecurityScheme
                                {
                                    Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = id }
                                },
                                new[] { "SwaggerDifferentAuthScheme" }
                            }
                        }
                    };
                }
            }
        }
    }
}
