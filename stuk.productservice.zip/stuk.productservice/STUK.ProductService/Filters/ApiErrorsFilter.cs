﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using System.Net;

namespace STUK.ProductService.Filters
{
    public class ApiErrorsFilter : IExceptionFilter
    {
        private readonly ILogger<ApiErrorsFilter> _logger;
        private ProblemDetailsFactory _problemDetailsFactory;

        public ApiErrorsFilter(ILogger<ApiErrorsFilter> logger, ProblemDetailsFactory problemDetailsFactory)
        { 
            _logger = logger;
            _problemDetailsFactory = problemDetailsFactory; 
        }

        public void OnException(ExceptionContext context)
        {
            var exception = context.Exception;
            var httpContext = context.HttpContext;

            var problemDetails = _problemDetailsFactory.CreateProblemDetails(httpContext, statusCode: 500, title: HttpStatusCode.InternalServerError.ToString(), detail: exception.Message);

            context.Result = new ObjectResult(problemDetails)
            {
                StatusCode = problemDetails.Status,
            };

            _logger.LogError(exception, "ProductService exception");

            context.ExceptionHandled = true;
        }

    }
}
