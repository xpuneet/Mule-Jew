using Azure.Identity;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using STUK.ProductService;
using STUK.ProductService.Domain.Caching;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Mapper;
using STUK.ProductService.Domain.Repositories;
using STUK.ProductService.Domain.Repositories.DbContexts;
using STUK.ProductService.Domain.Services;
using STUK.ProductService.Filters;
using STUK.ProductService.HealthChecks;
using STUK.ProductService.Logging;

var builder = WebApplication.CreateBuilder(args);

// Read/overwrite configuration values from AzureKeyValut
var azureKeyVaultUri = builder.Configuration["AzureKeyVaultUri"];

if (string.IsNullOrEmpty(azureKeyVaultUri) == false)
{
    builder.Configuration.AddAzureKeyVault(new Uri(azureKeyVaultUri), new DefaultAzureCredential());
}

// Add services to the container.

builder.Services.AddControllers(options =>
    {
        options.Filters.Add<ApiErrorsFilter>();
    });

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddApplicationInsightsTelemetry();

var apiSecuritySettings = builder.Configuration.GetSection("ApiSecuritySettings").Get<ApiSecuritySettings>();
var authenticationBuilder = builder.Services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;

    });
foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
{
    authenticationBuilder.AddJwtBearer(scheme, options =>
    {
        options.Authority = apiSecuritySettings.OpenIdAuthority;
        options.RequireHttpsMetadata = false;
        options.Audience = apiSecuritySettings.SchemeToScopeMappings[scheme];
    });
}

builder.Services.AddAuthorization(options =>
{
    foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
    {
        options.AddPolicy(scheme, p =>
        {
            p.RequireAuthenticatedUser();
            p.AuthenticationSchemes = new List<string>{ scheme };
        });
    }
});

RegisterServices(builder);

builder.Services.AddSwaggerGen(s =>
{
    s.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "STUK ProductService Api",
        Version = "v1",
        Description = "The purpose of this API is to provide product details like prices and stock"
    });

    foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
    {
        s.AddSecurityDefinition($"Bearer:{apiSecuritySettings.SchemeToScopeMappings[scheme]}", new OpenApiSecurityScheme
        {
            Description = @"JWT Authorization header using the Bearer scheme.<br/>
                                    Enter 'Bearer' [space] and then your token in the text input below.<br/>
                                    Example: 'Bearer 12345abcdef'<br/>",
            Name = "Authorization",
            In = ParameterLocation.Header,
            Type = SecuritySchemeType.ApiKey,
            Scheme = "Bearer"
        });
    }
    s.OperationFilter<SecurityRequirementsOperationFilter>();
    List<string> xmlFiles = Directory.GetFiles(AppContext.BaseDirectory, "*.xml", SearchOption.TopDirectoryOnly).ToList();
    xmlFiles.ForEach(xmlFile => s.IncludeXmlComments(xmlFile));

    s.EnableAnnotations();
});

var app = builder.Build();

var generateSwagger = Convert.ToBoolean(builder.Configuration["AllowSwagger"]);
if (generateSwagger)
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        var apiName = "STUK ProductService Api v1";
        c.SwaggerEndpoint("../swagger/v1/swagger.json", apiName);
        c.DocumentTitle = apiName;
    });

}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.MapHealthChecks();

app.Run();

static void RegisterServices(WebApplicationBuilder builder)
{
    var mulesoftSettings = builder.Configuration.GetSection("ProductServiceMulesoftSettings").Get<MulesoftSettings>();

    builder.Services.AddMemoryCache();
    builder.Services.AddDistributedMemoryCache();
    builder.Services.AddClientCredentialsTokenManagement()
    .AddClient(ErpByMulesoftRepository.IdentityServerClient, client =>
    {
        client.TokenEndpoint = mulesoftSettings.AccessTokenUrl;

        client.ClientId = mulesoftSettings.AccessTokenClientId;
        client.ClientSecret = mulesoftSettings.AccessTokenClientSecret;
        client.HttpClientName = mulesoftSettings.AccessTokenClientName;
    });

    builder.Services.AddHttpClient(ErpByMulesoftRepository.ProductApiClient, httpClient =>
    {
        httpClient.BaseAddress = new Uri(mulesoftSettings.ProductApiBaseUrl);

        httpClient.DefaultRequestHeaders.Add("Source", mulesoftSettings.RequestSource);
        httpClient.DefaultRequestHeaders.Add("x-environment-id", mulesoftSettings.RequestEnvironment);
        httpClient.Timeout = TimeSpan.FromSeconds(mulesoftSettings.RequestTimeoutSeconds);
    }).AddHttpMessageHandler<HttpClientLoggingHandler>();

    builder.Services.AddSingleton<DbContext>(); 
    builder.Services.AddAutoMapper(typeof(ProductProfile));
    builder.Services.AddSingleton<IAdminService, AdminService>();
    builder.Services.AddSingleton<IProductService, ProductService>();
    builder.Services.AddSingleton<IProductRepository, ProductRepository>();
    builder.Services.AddSingleton<IErpRepository, ErpByMulesoftRepository>();
    builder.Services.AddSingleton<ICacheManager, InMemoryCacheManager>();
    builder.Services.AddSingleton<ITelemetryInitializer, HeaderTelemetryInitializer>();
    builder.Services.AddTransient<HttpClientLoggingHandler>();

    builder.Services.Configure<Settings>(builder.Configuration.GetSection("Settings"));

    builder.Services.ConfigureHealthChecks(builder.Configuration);
}
