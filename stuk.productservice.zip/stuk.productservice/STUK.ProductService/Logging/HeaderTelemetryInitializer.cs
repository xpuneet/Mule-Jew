﻿using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;

namespace STUK.ProductService.Logging
{
    public class HeaderTelemetryInitializer : ITelemetryInitializer
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public HeaderTelemetryInitializer(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public void Initialize(ITelemetry telemetry)
        {
            var requestTelemetry = telemetry as RequestTelemetry;

            // Is this a TrackRequest() ?
            if (requestTelemetry == null) return;

            var context = _httpContextAccessor.HttpContext;
            if (context == null) return;

            if (context.Request != null)
            {
                foreach (var header in context.Request.Headers)
                {
                    telemetry.Context.Properties.Add($"request-header-{header.Key}", header.Value);
                }
            }

            if (context.Response != null)
            {
                foreach (var header in context.Response.Headers)
                {
                    telemetry.Context.Properties.Add($"response-header-{header.Key}", header.Value);
                }
            }
        }
    }
}
