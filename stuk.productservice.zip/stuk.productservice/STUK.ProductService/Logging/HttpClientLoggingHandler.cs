﻿namespace STUK.ProductService.Logging
{
    public class HttpClientLoggingHandler : DelegatingHandler
    {
        private readonly ILogger<HttpClientLoggingHandler> _logger;
        public HttpClientLoggingHandler(ILogger<HttpClientLoggingHandler> logger)
        {
            _logger = logger;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var requestLog = request.ToString();

            if (request.Content != null)
            {
                requestLog += " RequestContent: " + await request.Content.ReadAsStringAsync();
            }
            _logger.LogInformation($"=>=> {requestLog}");

            HttpResponseMessage response = await base.SendAsync(request, cancellationToken);

            var responseLog = response.ToString();

            if (response.Content != null)
            {
                responseLog += " ResponseContent: " + await response.Content.ReadAsStringAsync();
            }
            _logger.LogInformation($"<=<= {responseLog}");

            return response;
        }
    }
}
