using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using STUK.ProductService.Contracts.Models;
using STUK.ProductService.Contracts.Requests;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Services;
using System.Net;

namespace STUK.ProductService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.Reader)]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;
        private readonly ILogger<ProductsController> _logger;

        public ProductsController(IProductService productService, ILogger<ProductsController> logger)
        {
            _productService = productService;
            _logger = logger;
        }

        /// <summary>
        /// Provides product details for given list of product codes
        /// </summary>
        /// <returns>list of requested products with price and stock information</returns>
        /// <response code="200">returns list of products when all products are found</response>
        /// <response code="206">returns list of products when one or more products are not found, with error details for missing products</response>
        /// <response code="400">if request is not valid (both AccountCode and BranchNumber are not provided or too many products are requested)</response>
        /// <response code="401">if a valid authorization token is not provided in request header</response>
        /// <response code="500">if there is any internal server error</response>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(List<Product>), StatusCodes.Status206PartialContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<ActionResult<List<Product>>> Product([FromQuery] ProductRequest request)
        {
            var response = await _productService.GetProductDetails(request);

            if (response.Success) 
            {
                if (response.Result.Any(p => p.Error != null)) 
                {
                    return StatusCode(StatusCodes.Status206PartialContent, response.Result);
                }

                return Ok(response.Result);
            }

            return BadRequest(GetProblemDetails(HttpStatusCode.BadRequest, response.Message));            
        }

        /// <summary>
        /// Provides list of products, only with terms for a given account/customer updated after a given timestamp
        /// </summary>
        /// <param name="source">name of application/client consuming the API</param>
        /// <returns>list of requested products</returns>
        /// <response code="200">returns list of products</response>
        /// <response code="400">if request is not valid</response>
        /// <response code="401">if a valid authorization token is not provided in request header</response>
        /// <response code="500">if there is any internal server error</response>
        [HttpGet]
        [Route("TermProducts")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<ActionResult<List<Product>>> TermProducts([FromQuery] TermProductsRequest request)
        {
            var response = await _productService.GetTermProducts(request);

            if (response.Success)
            {
                if (response.Result.Any(p => p.Error != null))
                {
                    return StatusCode(StatusCodes.Status206PartialContent, response.Result);
                }

                return Ok(response.Result);
            }

            return BadRequest(GetProblemDetails(HttpStatusCode.BadRequest, response.Message));
        }

        private ProblemDetails GetProblemDetails(HttpStatusCode httpStatusCode, string detail = null, string instance = null)
        {
            string title = httpStatusCode.ToString();
            int statusCode = (int)httpStatusCode;
            string logText = $"{title}{(string.IsNullOrEmpty(detail) ? string.Empty : ("\r\n" + detail))}";

            if (statusCode <= 400)
            {
                _logger.LogWarning(logText);
            }
            else if (statusCode <= 500)
            {
                // Internal Server Error is logged in ApiErrorsFilter
            }
            else
            {
                _logger.LogCritical(logText);
            }

            return new ProblemDetails()
            {
                Type = "https://tools.ietf.org/html/rfc7231#section-6.6.1",
                Title = title,
                Detail = detail,
                Instance = instance,
                Status = statusCode,
            };
        }
    }
}
