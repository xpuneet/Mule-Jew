﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using STUK.ProductService.Contracts.Requests;
using STUK.ProductService.Domain.Config;
using STUK.ProductService.Domain.Services;

namespace STUK.ProductService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.Admin)]
    public class AdminController : ControllerBase
    {
        private readonly IAdminService _adminService;

        public AdminController(IAdminService adminService)
        {
            _adminService = adminService;
        }

        /// <summary>
        /// Update cache to remove existing cache entries and/or set cache expiry time for new cache entries
        /// </summary>
        /// <param name="source">name of application/client consuming the API</param>
        /// <response code="200">when cache is updated successfully</response>
        /// <response code="400">when cache expiry time is invalid</response>
        /// <response code="401">if a valid authorization token is not provided in request header</response>
        /// <response code="500">when api fails to update cache</response>
        [HttpPatch]
        [Route("Cache")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdateCacheAsync([FromBody] UpdateCacheRequest request, [FromHeader] string source = null)
        {
            if (!string.IsNullOrEmpty(source))
            {
                request.Source = source;
            }

            var response = await _adminService.UpdateCache(request);
            if (response.Success)
            {
                return Ok();
            }
            else
            {
                return StatusCode(500, response.Message);
            }
        }
    }
}
