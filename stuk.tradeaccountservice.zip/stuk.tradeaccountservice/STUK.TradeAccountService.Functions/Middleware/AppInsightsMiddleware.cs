﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Middleware;

namespace STUK.TradeAccountService.Functions.Middleware
{
    public class AppInsightsMiddleware : IFunctionsWorkerMiddleware
    {
        private readonly TelemetryClient _telemetryClient;

        public AppInsightsMiddleware(TelemetryClient telemetryClient)
        {
            _telemetryClient = telemetryClient;
        }

        public async Task Invoke(FunctionContext context, FunctionExecutionDelegate next)
        {
            var functionName = context.FunctionDefinition.Name;

            var traceContext = context.TraceContext;
            var operationId = traceContext?.TraceParent ?? context.InvocationId;
            var operationName = functionName;

            var requestTelemetry = new RequestTelemetry
            {
                Name = functionName,
                Id = context.InvocationId,
            };

            requestTelemetry.Context.Operation.Name = operationName;

            var startTime = DateTimeOffset.UtcNow;
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            using var operation = _telemetryClient.StartOperation(requestTelemetry);

            try
            {
                await next(context);

                stopwatch.Stop();
                operation.Telemetry.Success = true;
                operation.Telemetry.Duration = stopwatch.Elapsed;
                operation.Telemetry.Timestamp = startTime;
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                operation.Telemetry.Success = false;
                operation.Telemetry.Duration = stopwatch.Elapsed;
                operation.Telemetry.Timestamp = startTime;

                var exceptionTelemetry = new ExceptionTelemetry(ex);
                exceptionTelemetry.Context.Operation.Name = operationName;
                _telemetryClient.TrackException(exceptionTelemetry);

                throw;
            }
        }
    }
}
