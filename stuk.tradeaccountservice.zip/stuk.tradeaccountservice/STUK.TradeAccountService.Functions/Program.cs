using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.Azure.Functions.Worker.Builder;
using Azure.Storage.Blobs;
using Azure.Storage.Files.DataLake;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using STUK.APIs.Common.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Logging;
using STUK.IconIntegration.DependencyInjection;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.DependencyInjection;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Common.Salesforce.DependencyInjection;
using STUK.TradeAccountService.Functions.Middleware;

var builder = FunctionsApplication.CreateBuilder(args);
// Add services to the container.
var configurationBuilder = new ConfigurationBuilder();
configurationBuilder.AddConfiguration(builder.Configuration);

var keyVaultUrl = builder.Configuration["KeyVaultUrl"] ?? throw new InvalidOperationException("Keyvault url is missing.");
builder.Configuration.AddAzureKeyVault(
    new Uri(keyVaultUrl),
    new DefaultAzureCredential(),
    new CustomKeyVaultSecretManager()
);

builder.Services.AddIconIntegration(configurationBuilder);

builder.ConfigureFunctionsWebApplication();

builder.Services.AddCommonLogging();
builder.Services.AddSingleton<IAppInsightsLoggerHelper, AppInsightsLoggerHelper>();
builder.Services.AddHttpClient();
var blobStorageConnection = builder.Configuration["BlobStorageConnection"];
if (!string.IsNullOrWhiteSpace(blobStorageConnection))
{
    builder.Services.AddSingleton(new BlobServiceClient(blobStorageConnection));
}
else
{
    var blobStorageAccountName = builder.Configuration["BlobStorageConnection:accountName"];
    if (string.IsNullOrWhiteSpace(blobStorageAccountName)
        || blobStorageAccountName.Any(character => !char.IsAsciiLetterOrDigit(character)))
    {
        throw new InvalidOperationException(
            "BlobStorageConnection or a valid BlobStorageConnection__accountName must be configured.");
    }

    var managedIdentityClientId = builder.Configuration["BlobStorageConnection:clientId"]
        ?? builder.Configuration["AZURE_CLIENT_ID"];
    var credentialOptions = new DefaultAzureCredentialOptions();
    if (!string.IsNullOrWhiteSpace(managedIdentityClientId))
    {
        credentialOptions.ManagedIdentityClientId = managedIdentityClientId;
    }

    builder.Services.AddSingleton(
        new BlobServiceClient(
            new Uri($"https://{blobStorageAccountName}.blob.core.windows.net"),
            new DefaultAzureCredential(credentialOptions)));
}

var connectionString = builder.Configuration["ConnectionStrings:TradeAccountServiceDb"]
            ?? builder.Configuration["TradeAccountServiceDb"];
var docConnectionString = builder.Configuration["ConnectionStrings:OrderServiceDb"]
            ?? builder.Configuration["OrderServiceDb"];
builder.Services.AddSharedDatabase(connectionString!, "AccountDb");
builder.Services.AddSharedDatabase(docConnectionString!, "OrderDb");
var fileTransferConnectionString = builder.Configuration["ConnectionStrings:FileTransferDb"]
            ?? builder.Configuration["FileTransferDb"];
if (!string.IsNullOrWhiteSpace(fileTransferConnectionString))
{
    builder.Services.AddSharedDatabase(fileTransferConnectionString, "FileTransferDb");
}

builder.Services.Configure<TradeAcnSyncOptions>(builder.Configuration.GetSection(TradeAcnSyncOptions.SectionName));
builder.Services.AddScoped<IStatementBlobProcessorService, StatementBlobProcessorService>();
builder.Services.AddScoped<IconService>();
builder.Services.AddScoped<IPaymentReferenceSyncService, PaymentReferenceSyncService>();
builder.Services.AddScoped<IBlobService, BlobService>();
builder.Services.AddScoped<IColumbusFilesService, ColumbusFilesService>();

// Workday to Concur
builder.Services.AddWorkdayConcur(builder.Configuration);

// HX Consolidated Sales
builder.Services.AddScoped<IHxConsolidatedInvoiceParser, HxConsolidatedInvoiceParser>();
builder.Services.AddScoped<IHxInvoiceMapper, HxInvoiceMapper>();
builder.Services.AddScoped<IConsolidatedSalesFileDataService, ConsolidatedSalesFileDataService>();
builder.Services.AddScoped<IConsolidatedSalesExportDataService, ConsolidatedSalesExportDataService>();
builder.Services.AddScoped<IPhocasConsXrefFileGenerator, PhocasConsXrefFileGenerator>();
builder.Services.AddScoped<IPhocasBlobStagingClient, PhocasBlobStagingClient>();
builder.Services.AddScoped<IPhocasExportStagingService, PhocasExportStagingService>();
builder.Services.AddScoped<IDataLakeCompletionTokenGenerator, DataLakeCompletionTokenGenerator>();
builder.Services.AddScoped<IDataLakeExportClient, DataLakeExportClient>();
builder.Services.AddScoped<IDataLakeExportService, DataLakeExportService>();
builder.Services.AddScoped<IConsolidatedInvoiceDataService, ConsolidatedInvoiceDataService>();
builder.Services.AddScoped<IConsolidatedSalesIngestionService, ConsolidatedSalesIngestionService>();
builder.Services.AddScoped<IConsolidatedSalesBlobSource, ConsolidatedSalesBlobSource>();
builder.Services.AddScoped<ISalesforceSyncDataService, SalesforceSyncDataService>();
builder.Services.AddScoped<IInvoiceReconciliationDataService, InvoiceReconciliationDataService>();
builder.Services.AddScoped<IInvoiceReconciliationService, InvoiceReconciliationService>();
builder.Services.Configure<ConsolidatedSalesIngestionOptions>(builder.Configuration.GetSection(ConsolidatedSalesIngestionOptions.SectionName));
builder.Services.Configure<ConsolidatedSalesReconciliationOptions>(builder.Configuration.GetSection(ConsolidatedSalesReconciliationOptions.SectionName));
builder.Services
    .AddOptions<ColumbusOptions>()
    .Bind(builder.Configuration.GetSection(ColumbusOptions.SectionName))
    .Validate(
        options => options.SalesforceCooloffHours >= 0
            && (!options.EnableSalesforceCooloff || options.SalesforceCooloffHours > 0),
        "SalesforceCooloffHours must be greater than zero when EnableSalesforceCooloff is enabled, and cannot be negative.")
    .ValidateOnStart();
builder.Services.Configure<PhocasBlobStagingOptions>(builder.Configuration.GetSection(PhocasBlobStagingOptions.SectionName));
builder.Services.Configure<ConsolidatedSalesDataLakeOptions>(builder.Configuration.GetSection(ConsolidatedSalesDataLakeOptions.SectionName));
builder.Services.AddSingleton<Func<DataLakeServiceClient>>(serviceProvider => () =>
{
    var options = serviceProvider
        .GetRequiredService<Microsoft.Extensions.Options.IOptions<ConsolidatedSalesDataLakeOptions>>()
        .Value;
    return new DataLakeServiceClient(new Uri(options.ServiceUri), new DefaultAzureCredential());
});
builder.Services.AddSalesforceIntegration(builder.Configuration);

builder.UseMiddleware<AppInsightsMiddleware>();
builder.Build().Run();

internal sealed class CustomKeyVaultSecretManager : KeyVaultSecretManager
{
    public override string GetKey(KeyVaultSecret secret)
    {
        var key = secret.Name.Replace("--", ConfigurationPath.KeyDelimiter);
        if (key.Equals("IconSettings:K8-XI-AuthToken", StringComparison.OrdinalIgnoreCase))
        {
            key = "IconSettings:K8_XI_AuthToken";
        }
        return key;
    }
}
