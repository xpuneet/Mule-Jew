using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Contracts.Interfaces;

namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Starts scheduled matching of consolidated components to existing invoice headers
    /// </summary>
    public class InvoiceReconciliationFunction
    {
        private readonly ILogger<InvoiceReconciliationFunction> _logger;
        private readonly IInvoiceReconciliationService _reconciliationService;

        /// <summary>
        /// Initialises a new instance of the <see cref="InvoiceReconciliationFunction"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="reconciliationService">Existing-invoice reconciliation service</param>
        /// <exception cref="ArgumentNullException"></exception>
        public InvoiceReconciliationFunction(ILogger<InvoiceReconciliationFunction> logger, IInvoiceReconciliationService reconciliationService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _reconciliationService = reconciliationService ?? throw new ArgumentNullException(nameof(reconciliationService));
        }

        /// <summary>
        /// Delegates scheduled existing-invoice reconciliation work to the reconciliation service
        /// </summary>
        /// <param name="timerInfo">The configured timer information</param>
        /// <param name="context">The current Function invocation context</param>
        /// <returns>A task representing the asynchronous operation</returns>
        [Function(nameof(InvoiceReconciliationFunction))]
        public async Task RunAsync([TimerTrigger("%ConsolidatedSalesReconciliationCron%")] TimerInfo timerInfo, FunctionContext context)
        {
            ArgumentNullException.ThrowIfNull(timerInfo);
            ArgumentNullException.ThrowIfNull(context);

            _logger.LogInformation(
                "{FunctionName} started scheduled existing-invoice reconciliation. IsPastDue={IsPastDue}",
                context.FunctionDefinition.Name,
                timerInfo.IsPastDue);

            await _reconciliationService.RunAsync(
                context.InvocationId,
                context.CancellationToken);

            _logger.LogInformation(
                "{FunctionName} completed scheduled existing-invoice reconciliation",
                context.FunctionDefinition.Name);
        }
    }
}
