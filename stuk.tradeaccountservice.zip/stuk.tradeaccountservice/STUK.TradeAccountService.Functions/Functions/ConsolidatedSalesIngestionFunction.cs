using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Contracts.Interfaces;

namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Starts scheduled HX consolidated sales ingestion
    /// </summary>
    public class ConsolidatedSalesIngestionFunction
    {
        private readonly ILogger<ConsolidatedSalesIngestionFunction> _logger;
        private readonly IConsolidatedSalesIngestionService _ingestionService;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesIngestionFunction"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="ingestionService">Ingestion Service</param>
        /// <exception cref="ArgumentNullException"></exception>
        public ConsolidatedSalesIngestionFunction(ILogger<ConsolidatedSalesIngestionFunction> logger, IConsolidatedSalesIngestionService ingestionService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _ingestionService = ingestionService ?? throw new ArgumentNullException(nameof(ingestionService));
        }

        /// <summary>
        /// Delegates scheduled ingestion work to the consolidated sales ingestion service
        /// </summary>
        /// <param name="timerInfo">The configured timer information</param>
        /// <param name="context">The current Function invocation context</param>
        /// <returns>A task representing the asynchronous operation</returns>
        [Function(nameof(ConsolidatedSalesIngestionFunction))]
        public async Task RunAsync([TimerTrigger("%ConsolidatedSalesIngestionCron%")] TimerInfo timerInfo, FunctionContext context)
        {
            ArgumentNullException.ThrowIfNull(timerInfo);
            ArgumentNullException.ThrowIfNull(context);

            _logger.LogInformation(
                "{FunctionName} started scheduled ingestion. IsPastDue={IsPastDue}",
                context.FunctionDefinition.Name,
                timerInfo.IsPastDue);

            await _ingestionService.RunAsync(
                context.InvocationId,
                context.CancellationToken);

            _logger.LogInformation(
                "{FunctionName} completed scheduled ingestion",
                context.FunctionDefinition.Name);
        }
    }
}
