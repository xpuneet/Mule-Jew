using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Threading.Channels;

namespace STUK.TradeAccountService.Functions.Functions
{
    public class StatementProcessorFunction
    {
        private readonly ILogger<StatementProcessorFunction> _logger;
        private readonly TradeAcnSyncOptions _options;
        private readonly IStatementBlobProcessorService _processorService;

        public StatementProcessorFunction(ILogger<StatementProcessorFunction> logger, IOptions<TradeAcnSyncOptions> options, IStatementBlobProcessorService processorService)
        {
            _logger = logger;
            _options = options.Value;
            _processorService = processorService;
        }

        [Function(nameof(StatementProcessorFunction))]
        public async Task RunAsync([BlobTrigger("%ContainerName%/%DirectoryPath%/{name}", Connection = "BlobStorageConnection")]
        BlobClient blobClient,
        string name,
        FunctionContext context)
        {
            // Process only XML        
            if (!name.EndsWith(".xml", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("{FuncName} blob trigger fired and skipping non-XML file: {FileName}", context.FunctionDefinition.Name, name);
                return;
            }

            _logger.LogInformation("{FuncName} blob trigger fired for blob: {Blobname}.", context.FunctionDefinition.Name, name);
            var ct = context.CancellationToken;
            int batchSize = _options.StatementBatchSize;
            try
            {
                var downloadResult = await blobClient.DownloadStreamingAsync(cancellationToken: ct);
                await using var stream = downloadResult.Value.Content;

                // Bounded channel: parser (producer) runs ahead of the DB writer (consumer)
                // by at most 2 batches, keeping memory bounded while hiding I/O latency.
                var channel = Channel.CreateBounded<List<StatementHeaderData>>(
                    new BoundedChannelOptions(capacity: 2)
                    {
                        SingleWriter = true,
                        SingleReader = true
                    });

                var totalHeaders = 0;
                
                //Producer: parse XML and write completed batches to the channel
                var producer = Task.Run(async () =>
                {
                    try
                    {
                        var batch = new List<StatementHeaderData>(batchSize);
                        await foreach (var doc in StatementXmlParser.ParseAsync(stream, ct))
                        {
                            batch.Add(doc);
                            if (batch.Count >= batchSize)
                            {
                                await channel.Writer.WriteAsync(batch, ct);
                                batch = new List<StatementHeaderData>(batchSize);
                            }
                        }

                        if (batch.Count > 0)
                            await channel.Writer.WriteAsync(batch, ct);
                    }
                    finally
                    {
                        // Always complete the channel so the consumer can finish
                        channel.Writer.Complete();
                    }
                }, ct);

                //Consumer: read batches from the channel and upsert to SQL
                var batchNumber = 0;
                await foreach (var batch in channel.Reader.ReadAllAsync(ct))
                {
                    batchNumber++;
                    var meta = StatementXmlParser.BuildMetadata(batch, createdBy: "FunctionApp");
                    await _processorService.UpsertBatchAsync(batch, meta);
                    totalHeaders += batch.Count;
                    
                    _logger.LogInformation(
                        "Blob {BlobName}: upserted batch {Batch} � {H} header(s).",
                        name, batchNumber, batch.Count);
                }
                // Propagate any parser exception
                await producer;

                _logger.LogInformation("{FuncName} successfully processed blob: {BlobName}, Total statements=: {TotalHeaders}", context.FunctionDefinition.Name, name, totalHeaders);
                await blobClient.DeleteIfExistsAsync(snapshotsOption: DeleteSnapshotsOption.IncludeSnapshots);
                _logger.LogInformation("{FuncName} successfully deleted blob: {BlobName}", context.FunctionDefinition.Name, name);
            }
            catch (InvalidDataException ex)
            {
                _logger.LogError(ex,
                    "{FuncName} Invalid XML structure in blob {BlobName}: {Message}", context.FunctionDefinition.Name, name, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{FuncName} Unexpected error processing blob {BlobName}", context.FunctionDefinition.Name, name);
                throw;
            }
        }
    }
}
