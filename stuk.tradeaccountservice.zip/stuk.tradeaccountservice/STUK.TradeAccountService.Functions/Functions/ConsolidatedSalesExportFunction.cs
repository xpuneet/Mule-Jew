using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;

namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Starts the scheduled Salesforce-to-Phocas and Data Lake export workflow
    /// </summary>
    public class ConsolidatedSalesExportFunction
    {
        private readonly ILogger<ConsolidatedSalesExportFunction> _logger;
        private readonly IConsolidatedSalesExportOrchestrationService _orchestrationService;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesExportFunction"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="orchestrationService">Consolidated Sales export orchestration service</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public ConsolidatedSalesExportFunction(
            ILogger<ConsolidatedSalesExportFunction> logger,
            IConsolidatedSalesExportOrchestrationService orchestrationService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _orchestrationService = orchestrationService ?? throw new ArgumentNullException(nameof(orchestrationService));
        }

        /// <summary>
        /// Delegates scheduled export work to the orchestration service
        /// </summary>
        /// <param name="timerInfo">The configured timer information</param>
        /// <param name="context">The current Function invocation context</param>
        /// <returns>A task representing the asynchronous operation</returns>
        [Function(nameof(ConsolidatedSalesExportFunction))]
        public async Task RunAsync(
            [TimerTrigger("%ConsolidatedSalesExportCron%")] TimerInfo timerInfo,
            FunctionContext context)
        {
            ArgumentNullException.ThrowIfNull(timerInfo);
            ArgumentNullException.ThrowIfNull(context);

            _logger.LogInformation(
                "{FunctionName} started scheduled Consolidated Sales export. IsPastDue={IsPastDue}",
                context.FunctionDefinition.Name,
                timerInfo.IsPastDue);

            await _orchestrationService.RunAsync(
                context.InvocationId,
                context.CancellationToken);

            _logger.LogInformation(
                "{FunctionName} completed scheduled Consolidated Sales export",
                context.FunctionDefinition.Name);
        }
    }
}
