using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Contracts.Interfaces;

namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Starts scheduled Workday-to-Concur processing
    /// </summary>
    public class WorkdayConcurTimerFunction
    {
        private readonly ILogger<WorkdayConcurTimerFunction> _logger;
        private readonly IWorkdayConcurOrchestrationService _orchestrationService;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurTimerFunction"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="orchestrationService">Workday-to-Concur orchestration service</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayConcurTimerFunction(ILogger<WorkdayConcurTimerFunction> logger, IWorkdayConcurOrchestrationService orchestrationService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _orchestrationService = orchestrationService ?? throw new ArgumentNullException(nameof(orchestrationService));
        }

        /// <summary>
        /// Delegates scheduled processing to the Workday-to-Concur orchestration service
        /// </summary>
        /// <param name="timerInfo">The configured timer information</param>
        /// <param name="context">The current Function invocation context</param>
        /// <returns>A task representing the asynchronous operation</returns>
        [Function(nameof(WorkdayConcurTimerFunction))]
        public async Task RunAsync([TimerTrigger("%WorkdayConcur:Cron%")] TimerInfo timerInfo, FunctionContext context)
        {
            ArgumentNullException.ThrowIfNull(timerInfo);
            ArgumentNullException.ThrowIfNull(context);

            _logger.LogInformation(
                "{FunctionName} started scheduled Workday-to-Concur processing. IsPastDue={IsPastDue}",
                context.FunctionDefinition.Name,
                timerInfo.IsPastDue);

            await _orchestrationService.RunAsync(context.InvocationId, context.CancellationToken);

            _logger.LogInformation(
                "{FunctionName} completed scheduled Workday-to-Concur processing",
                context.FunctionDefinition.Name);
        }
    }
}
