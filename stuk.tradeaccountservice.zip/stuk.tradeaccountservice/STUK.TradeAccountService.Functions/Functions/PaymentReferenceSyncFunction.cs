﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.IconIntegration.IconClient;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Collections.Concurrent;
using System.IO;
using System.Threading.Channels;

namespace STUK.TradeAccountService.Functions.Functions
{
    public class PaymentReferenceSyncFunction
    {
        private readonly IPaymentReferenceSyncService _payReferenceService;
        private readonly IconService _iconService;
        private readonly TradeAcnSyncOptions _options;
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;

        public PaymentReferenceSyncFunction(
            IPaymentReferenceSyncService payReferenceService,
            IconService iconService,
            IOptions<TradeAcnSyncOptions> options,
            IAppInsightsLoggerHelper appInsightsLoggerHelper)
        {
            _payReferenceService = payReferenceService;
            _iconService = iconService;
            _options = options.Value;
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
        }

        [Function(nameof(PaymentReferenceSyncFunction))]
        public async Task RunAsync([TimerTrigger("%PaymentReferenceSyncCron%")] TimerInfo timerInfo,
            FunctionContext context)
        {
            var ct = context.CancellationToken;

            _appInsightsLoggerHelper.LogInformation($"PaymentReferenceSyncFunction started at {DateTime.UtcNow}. IsPastDue={timerInfo.IsPastDue}");
            try
            {
                // Fetch pending payments
                var pending = await _payReferenceService.GetPendingPaymentsAsync(ct);
                if (pending == null || pending.Count() == 0)
                {
                    _appInsightsLoggerHelper.LogInformation("PaymentReferenceSyncFunction finds no pending payments reference. Run complete.");
                    return;
                }

                int batchSize = _options.PaymentRefBatchSize;
                _appInsightsLoggerHelper.LogInformation($"PaymentReferenceSyncFunction processing {pending.Count()} pending payments with parallelism {_options.PaymentRefMaxDegreeOfParallelism}, batchSize {batchSize}.");

                // Bounded channel: producers (parallel Icon API calls) write results,
                // consumer batches and flushes to DB so completed results survive mid-run crashes.
                var channel = Channel.CreateBounded<UpdatePaymentReference>(
                    new BoundedChannelOptions(capacity: batchSize * 2)
                    {
                        SingleWriter = false,
                        SingleReader = true
                    });

                var totalUpdated = 0;

                // Producer: parallel Icon API calls write results into the channel
                var producer = Task.Run(async () =>
                {
                    try
                    {
                        var options = new ParallelOptions
                        {
                            MaxDegreeOfParallelism = _options.PaymentRefMaxDegreeOfParallelism,
                            CancellationToken = ct
                        };

                        await Parallel.ForEachAsync(pending, options,
                            async (payment, token) =>
                            {
                                await Task.Delay(Random.Shared.Next(_options.PaymentRefMaxDelayPerThread), token);
                                var result = await CallIconAsync(payment, token);
                                if (result is not null)
                                    await channel.Writer.WriteAsync(result, token);
                            });
                    }
                    finally
                    {
                        channel.Writer.Complete();
                    }
                }, ct);

                // Consumer: batch results from channel and flush to DB
                var batch = new List<UpdatePaymentReference>(batchSize);
                var batchNumber = 0;

                await foreach (var result in channel.Reader.ReadAllAsync(ct))
                {
                    batch.Add(result);
                    if (batch.Count >= batchSize)
                    {
                        batchNumber++;
                        await _payReferenceService.UpdatePendingPaymentsAsync(batch, ct);
                        totalUpdated += batch.Count;
                        _appInsightsLoggerHelper.LogInformation($"PaymentReferenceSyncFunction flushed batch {batchNumber} ({batch.Count} results).");
                        batch = new List<UpdatePaymentReference>(batchSize);
                    }
                }

                // Flush remaining
                if (batch.Count > 0)
                {
                    batchNumber++;
                    await _payReferenceService.UpdatePendingPaymentsAsync(batch, ct);
                    totalUpdated += batch.Count;
                    _appInsightsLoggerHelper.LogInformation($"PaymentReferenceSyncFunction flushed final batch {batchNumber} ({batch.Count} results).");
                }

                // Propagate any producer exception
                await producer;

                if (totalUpdated == 0)
                {
                    _appInsightsLoggerHelper.LogWarning("PaymentReferenceSyncFunction gets no results to write back (all ICON API calls failed)");
                    return;
                }

                _appInsightsLoggerHelper.LogInformation($"PaymentReferenceSyncFunction completed at {DateTime.UtcNow}. Updated {totalUpdated} of {pending.Count()} payments reference in {batchNumber} batch(es).");
            }

            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"PaymentReferenceSyncFunction failed at {DateTime.UtcNow}. Message: {ex.Message}");
            }           
        }

        private async Task<UpdatePaymentReference?> CallIconAsync(
        PendingPaymentReference payReference,
        CancellationToken ct)
        {
            var erpResult = await _iconService.MakeAccountPaymentAsync(payReference, ct);
            //Transient failure; don't update the row
            if (!erpResult.IsDefinitive)
            {
                return null;
            }
            //Client error; mark as BadRequest
            if(erpResult.Response is null && erpResult.StatusCode is >= 400 and < 501)
            {
                return new UpdatePaymentReference
                {
                    PaymentId = payReference.PaymentId,
                    ErpStatus = "BadRequest",
                    ErpReason = erpResult.ErrorMessage
                };
            }
            //Successful response
            var item = erpResult.Response?.Body?.Payment?.FirstOrDefault();

            if (item is null)
            {
                _appInsightsLoggerHelper.LogWarning(
                    $"PaymentReferenceSyncFunction Icon API returned no results for PaymentId {payReference.PaymentId}.Skipping, Rows remains pending");
                return null;
            }

            return new UpdatePaymentReference
            {
                PaymentId = payReference.PaymentId,
                ErpPaymentReference = item.Status ? item.Reference : null,
                ErpStatus = item.Status ? "Success" : "Failed",
                ErpReason = item.Reason
            };
        }
    }
}
