namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Represents an authorised request to replay one durable Consolidated Sales destination
    /// </summary>
    public class ConsolidatedSalesDestinationReplayRequest
    {
        /// <summary>
        /// Gets or sets the operational reason recorded for the replay
        /// </summary>
        public string Reason { get; set; } = string.Empty;
    }
}
