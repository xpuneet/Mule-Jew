using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;

namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Starts scheduled delivery of committed Consolidated Sales invoices to Salesforce
    /// </summary>
    public class SalesforceSyncFunction
    {
        private readonly ILogger<SalesforceSyncFunction> _logger;
        private readonly ISalesforceSyncService _syncService;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceSyncFunction"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="syncService">Salesforce synchronisation service</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceSyncFunction(
            ILogger<SalesforceSyncFunction> logger,
            ISalesforceSyncService syncService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _syncService = syncService ?? throw new ArgumentNullException(nameof(syncService));
        }

        /// <summary>
        /// Delegates scheduled Salesforce work to the synchronisation service
        /// </summary>
        /// <param name="timerInfo">The configured timer information</param>
        /// <param name="context">The current Function invocation context</param>
        /// <returns>A task representing the asynchronous operation</returns>
        [Function(nameof(SalesforceSyncFunction))]
        public async Task RunAsync(
            [TimerTrigger("%ConsolidatedSalesSalesforceSyncCron%")] TimerInfo timerInfo,
            FunctionContext context)
        {
            ArgumentNullException.ThrowIfNull(timerInfo);
            ArgumentNullException.ThrowIfNull(context);

            _logger.LogInformation(
                "{FunctionName} started scheduled Salesforce synchronisation. IsPastDue={IsPastDue}",
                context.FunctionDefinition.Name,
                timerInfo.IsPastDue);

            await _syncService.RunAsync(
                context.InvocationId,
                context.CancellationToken);

            _logger.LogInformation(
                "{FunctionName} completed scheduled Salesforce synchronisation",
                context.FunctionDefinition.Name);
        }
    }
}
