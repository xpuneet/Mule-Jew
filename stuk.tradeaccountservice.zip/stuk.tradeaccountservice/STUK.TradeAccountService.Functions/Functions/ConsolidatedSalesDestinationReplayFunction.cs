using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using System.Text.Json;

namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Provides controlled destination-only recovery for Consolidated Sales exports
    /// </summary>
    public class ConsolidatedSalesDestinationReplayFunction
    {
        private const int MaximumReasonLength = 500;
        private static readonly JsonSerializerOptions RequestJsonOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };
        private readonly ILogger<ConsolidatedSalesDestinationReplayFunction> _logger;
        private readonly IConsolidatedSalesExportOrchestrationService _orchestrationService;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesDestinationReplayFunction"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="orchestrationService">Consolidated Sales export orchestration service</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public ConsolidatedSalesDestinationReplayFunction(ILogger<ConsolidatedSalesDestinationReplayFunction> logger, IConsolidatedSalesExportOrchestrationService orchestrationService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _orchestrationService = orchestrationService ?? throw new ArgumentNullException(nameof(orchestrationService));
        }

        /// <summary>
        /// Requeues one failed destination and starts destination processing against its existing snapshot
        /// </summary>
        /// <param name="request">The authorised HTTP request containing the operational reason</param>
        /// <param name="exportDestinationId">The durable destination work identifier</param>
        /// <param name="context">The current Function invocation context</param>
        /// <returns>An accepted response when the replay has been queued</returns>
        [Function(nameof(ConsolidatedSalesDestinationReplayFunction))]
        public async Task<IActionResult> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post", Route = "consolidated-sales/export/destinations/{exportDestinationId:guid}/replay")]
            HttpRequest request,
            Guid exportDestinationId,
            FunctionContext context)
        {
            ArgumentNullException.ThrowIfNull(request);
            ArgumentNullException.ThrowIfNull(context);

            ConsolidatedSalesDestinationReplayRequest? replayRequest;
            try
            {
                replayRequest = await JsonSerializer.DeserializeAsync<ConsolidatedSalesDestinationReplayRequest>(
                    request.Body,
                    RequestJsonOptions,
                    cancellationToken: context.CancellationToken);
            }
            catch (JsonException)
            {
                return new BadRequestObjectResult("The replay request must contain valid JSON.");
            }

            var reason = replayRequest?.Reason?.Trim();
            if (string.IsNullOrWhiteSpace(reason) || reason.Length > MaximumReasonLength)
            {
                return new BadRequestObjectResult($"A replay reason between 1 and {MaximumReasonLength} characters is required.");
            }

            await _orchestrationService.ReplayDestinationAsync(
                exportDestinationId,
                reason,
                context.CancellationToken);

            await _orchestrationService.RunDestinationsAsync(
                context.InvocationId,
                exportDestinationId,
                context.CancellationToken);

            _logger.LogWarning(
                "Controlled Consolidated Sales replay queued by function invocation {InvocationId} for destination work {ExportDestinationId}; reason: {ReplayReason}",
                context.InvocationId,
                exportDestinationId,
                reason);

            return new AcceptedResult();
        }
    }
}
