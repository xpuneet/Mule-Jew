using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Functions.Functions;

public class ColumbusBlobCleanup
{
    private readonly IBlobService _blobService;
    private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
    private readonly IConfiguration _configuration;
    private readonly IColumbusFilesService _columbusFilesService;

    public ColumbusBlobCleanup(
        IBlobService blobService,
        IColumbusFilesService columbusFilesService,
        IAppInsightsLoggerHelper appInsightsLoggerHelper,
        IConfiguration configuration)
    {
        _blobService = blobService;
        _appInsightsLoggerHelper = appInsightsLoggerHelper;
        _configuration = configuration;
        _columbusFilesService = columbusFilesService;
    }

    [Function("ColumbusBlobCleanup")]
    public async Task Run([TimerTrigger("%ColumbusBlobCleanUpCron%")] TimerInfo myTimer)
    {

        _appInsightsLoggerHelper.LogInformation("Columbus Blob Cleanup started.");

        try
        {
            // ? Validate configuration (fail fast)
            string storageAccount = _configuration["ColumbusFilesStorageAccount"]
                ?? throw new ArgumentNullException("ColumbusFilesStorageAccount", "Storage Account cannot be null");

            string invoiceContainer = _configuration["InvoiceContainerName"]
                ?? throw new ArgumentNullException("InvoiceContainerName", "Invoice Container Name cannot be null");

            string statementContainer = _configuration["StatementContainerName"]
                ?? throw new ArgumentNullException("StatementContainerName", "Statement Container Name cannot be null");

            int retentionDays = _configuration.GetValue<int?>("RetentionNoOfDays")
                ?? throw new ArgumentNullException("RetentionNoOfDays", "Retention No Of Days cannot be null");

            if (retentionDays <= 0)
                throw new ArgumentOutOfRangeException(nameof(retentionDays), "Retention days must be greater than 0");

            _appInsightsLoggerHelper.LogInformation(
                $"Configuration loaded successfully. StorageAccount: {storageAccount}, RetentionDays: {retentionDays}");


            await RunColumbusCleanup(storageAccount, invoiceContainer, retentionDays, "Invoice");
            await RunColumbusCleanup(storageAccount, statementContainer, retentionDays, "Statement");
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Fatal error during Columbus Blob Cleanup execution.");
            throw; // Let Azure Functions mark the run as failed
        }
        finally
        {

            _appInsightsLoggerHelper.LogInformation(
                $"Columbus Blob Cleanup completed ");
        }
    }

    private async Task RunColumbusCleanup(string storageAccount, string container, int retentionDays, string label)
    {
        _appInsightsLoggerHelper.LogInformation($"Starting cleanup for {label} container '{container}'.");

        try
        {
            var cleanupResult = await _blobService.DeleteBlobsBeforeRetentionAsync(
                storageAccount,
                container,
                retentionDays);

            _appInsightsLoggerHelper.LogInformation(
                $"{label} blob cleanup completed. Deleted: {cleanupResult.Deleted}, Retained: {cleanupResult.Retained}, Skipped: {cleanupResult.Skipped}, Failed: {cleanupResult.Failed}");
            foreach(var blob in cleanupResult.DeletedBlobs)
            {
                    DocumentMetadataUpdate metadata = new DocumentMetadataUpdate();
                    string blobnameWithoutExtension = blob.Replace(".pdf", "");
                    string blobname = blobnameWithoutExtension.Substring(blobnameWithoutExtension.LastIndexOf('/') + 1);
                try
                {
                    var parts = blobname.Split('_');
                    string accountCode = parts[0];
                    string branchNo = parts[1];

                    if (label == "Invoice")
                    {

                        var invoiceDate = DateOnly.ParseExact(parts[3], "ddMMyyyy");
                        var dateTime = invoiceDate.ToDateTime(TimeOnly.MinValue);
                        metadata.DocType = DocumentType.Invoice;
                        metadata.CustomerAccount = accountCode;
                        metadata.BranchCode = branchNo;
                        metadata.StandardInvoiceNo = parts[2];
                        metadata.InvoiceDateTime = dateTime;
                    }
                    else if (label == "Statement")
                    {
                        var statementDate = DateOnly.ParseExact(parts[2], "ddMMyyyy");
                        var dateTime = statementDate.ToDateTime(TimeOnly.MinValue);
                        metadata.DocType = DocumentType.Statement;
                        metadata.AccountCode = accountCode;
                        metadata.OwningBranch = branchNo;
                        metadata.StatementDate = dateTime;
                    }
                    int recordsUpdated = await _columbusFilesService.UpdateDocumentMetadata(metadata, null);
                }
                catch (Exception ex)
                {
                    _appInsightsLoggerHelper.LogError(
                  ex,
                  $"Failed to update database after delete for file {blob}");
                }

            }
            try
            {
                var directoriesDeleted = await _blobService.DeleteEmptyDirectoriesBeforeRetentionAsync(
                    storageAccount,
                    container,
                    retentionDays);

                _appInsightsLoggerHelper.LogInformation(
                    $"{label} directory cleanup completed. Deleted directories: {directoriesDeleted}");
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"{label} directory cleanup failed, but blob cleanup succeeded.");
            }
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(
                ex,
                $"Error during {label} cleanup for container '{container}'.");
        }
    }
}