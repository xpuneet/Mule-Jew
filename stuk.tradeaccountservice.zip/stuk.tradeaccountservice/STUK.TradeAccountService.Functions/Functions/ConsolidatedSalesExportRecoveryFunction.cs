using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;

namespace STUK.TradeAccountService.Functions.Functions
{
    /// <summary>
    /// Wakes eligible Consolidated Sales export retry and recovery work
    /// </summary>
    public class ConsolidatedSalesExportRecoveryFunction
    {
        private readonly ILogger<ConsolidatedSalesExportRecoveryFunction> _logger;
        private readonly IConsolidatedSalesExportOrchestrationService _orchestrationService;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesExportRecoveryFunction"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="orchestrationService">Consolidated Sales export orchestration service</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public ConsolidatedSalesExportRecoveryFunction(
            ILogger<ConsolidatedSalesExportRecoveryFunction> logger,
            IConsolidatedSalesExportOrchestrationService orchestrationService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _orchestrationService = orchestrationService ?? throw new ArgumentNullException(nameof(orchestrationService));
        }

        /// <summary>
        /// Delegates eligible retry and recovery work to the orchestration service
        /// </summary>
        /// <param name="timerInfo">The configured timer information</param>
        /// <param name="context">The current Function invocation context</param>
        /// <returns>A task representing the asynchronous operation</returns>
        [Function(nameof(ConsolidatedSalesExportRecoveryFunction))]
        public async Task RunAsync(
            [TimerTrigger("%ConsolidatedSalesExportRecoveryCron%")] TimerInfo timerInfo,
            FunctionContext context)
        {
            ArgumentNullException.ThrowIfNull(timerInfo);
            ArgumentNullException.ThrowIfNull(context);

            _logger.LogInformation(
                "{FunctionName} started Consolidated Sales export recovery. IsPastDue={IsPastDue}",
                context.FunctionDefinition.Name,
                timerInfo.IsPastDue);

            await _orchestrationService.RunRecoveryAsync(
                context.InvocationId,
                context.CancellationToken);

            _logger.LogInformation(
                "{FunctionName} completed Consolidated Sales export recovery",
                context.FunctionDefinition.Name);
        }
    }
}
