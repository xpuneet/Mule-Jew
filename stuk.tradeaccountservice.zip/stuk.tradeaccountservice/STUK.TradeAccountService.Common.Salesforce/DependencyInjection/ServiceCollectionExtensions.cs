using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Services;

namespace STUK.TradeAccountService.Common.Salesforce.DependencyInjection
{
    /// <summary>
    /// Registers Salesforce integration dependencies
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Adds the direct Salesforce REST API implementation and External Client App authentication
        /// </summary>
        /// <param name="services">The application service collection</param>
        /// <param name="configuration">The application configuration</param>
        /// <returns>The application service collection</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static IServiceCollection AddSalesforceIntegration(this IServiceCollection services, IConfiguration configuration)
        {
            ArgumentNullException.ThrowIfNull(services);
            ArgumentNullException.ThrowIfNull(configuration);

            services.Configure<SalesforceOptions>(configuration.GetSection(SalesforceOptions.SectionName));
            services.Configure<SalesforceSyncOptions>(configuration.GetSection(SalesforceSyncOptions.SectionName));
            services.AddSingleton(TimeProvider.System);
            services.AddSingleton<ISalesforceRetryDelay, SalesforceRetryDelay>();
            services.AddSingleton<ISalesforceExportRetryPolicy, SalesforceExportRetryPolicy>();
            services.AddSingleton<ISalesforceSigningCertificateProvider, SalesforceSigningCertificateProvider>();
            services.AddHttpClient<ISalesforceAccessTokenProvider, SalesforceAccessTokenProvider>(ConfigureHttpClient);
            services.AddHttpClient<ISalesforceApiClient, SalesforceApiClient>(ConfigureHttpClient);
            services.AddScoped<ISalesforceInvoiceMapper, SalesforceInvoiceMapper>();
            services.AddScoped<ISalesforceProductService, SalesforceProductService>();
            services.AddScoped<ISalesforceOrderService, SalesforceOrderService>();
            services.AddScoped<ISalesforceSyncService, SalesforceSyncService>();
            services.AddScoped<ISalesforceConsXrefRowMapper, SalesforceConsXrefRowMapper>();
            services.AddScoped<IConsolidatedSalesExportExtractionService, ConsolidatedSalesExportExtractionService>();
            services.AddScoped<IConsolidatedSalesExportOrchestrationService, ConsolidatedSalesExportOrchestrationService>();

            return services;
        }

        private static void ConfigureHttpClient(IServiceProvider serviceProvider, HttpClient httpClient)
        {
            var options = serviceProvider.GetRequiredService<IOptions<SalesforceOptions>>().Value;
            httpClient.Timeout = TimeSpan.FromSeconds(options.RequestTimeoutSeconds);
        }
    }
}
