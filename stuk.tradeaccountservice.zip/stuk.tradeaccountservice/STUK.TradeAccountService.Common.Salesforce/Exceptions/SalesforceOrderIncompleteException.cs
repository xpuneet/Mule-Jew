namespace STUK.TradeAccountService.Common.Salesforce
{
    /// <summary>
    /// Represents a Salesforce Order that must remain Draft because its OrderItem count is incomplete
    /// </summary>
    public class SalesforceOrderIncompleteException : Exception
    {
        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceOrderIncompleteException"/> class
        /// </summary>
        /// <param name="invoiceNumber">Consolidated invoice number</param>
        /// <param name="expectedLineCount">Canonical line count</param>
        /// <param name="actualLineCount">Salesforce OrderItem count</param>
        public SalesforceOrderIncompleteException(string invoiceNumber, int expectedLineCount, int actualLineCount)
            : base($"Salesforce Order {invoiceNumber} remains Draft because it contains {actualLineCount} of {expectedLineCount} expected OrderItems.")
        {
        }
    }
}
