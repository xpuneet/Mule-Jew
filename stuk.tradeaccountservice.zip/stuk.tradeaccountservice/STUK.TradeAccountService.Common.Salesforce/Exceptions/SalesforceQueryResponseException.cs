namespace STUK.TradeAccountService.Common.Salesforce.Exceptions
{
    /// <summary>
    /// Represents an incomplete or internally inconsistent Salesforce SOQL response
    /// </summary>
    public class SalesforceQueryResponseException : Exception
    {
        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceQueryResponseException"/> class
        /// </summary>
        /// <param name="message">The safe response-validation failure detail</param>
        public SalesforceQueryResponseException(string message) : base(message)
        {
        }
    }
}
