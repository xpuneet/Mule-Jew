using STUK.TradeAccountService.Common.Salesforce.Models;
using System.Net;

namespace STUK.TradeAccountService.Common.Salesforce
{
    /// <summary>
    /// Represents a rejected Salesforce OAuth or REST API request
    /// </summary>
    public class SalesforceApiException : Exception
    {
        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceApiException"/> class
        /// </summary>
        /// <param name="message">The application-safe error summary</param>
        /// <param name="statusCode">The Salesforce HTTP status code</param>
        /// <param name="errors">The structured errors returned by Salesforce</param>
        public SalesforceApiException(string message, HttpStatusCode statusCode, IReadOnlyList<SalesforceError>? errors = null) : base(message)
        {
            StatusCode = statusCode;
            Errors = errors ?? [];
        }

        /// <summary>
        /// Gets the Salesforce HTTP status code
        /// </summary>
        public HttpStatusCode StatusCode { get; }

        /// <summary>
        /// Gets the structured Salesforce errors
        /// </summary>
        public IReadOnlyList<SalesforceError> Errors { get; }
    }
}
