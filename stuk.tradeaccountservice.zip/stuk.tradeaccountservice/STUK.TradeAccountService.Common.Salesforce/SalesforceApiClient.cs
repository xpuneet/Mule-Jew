using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Exceptions;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce
{
    /// <summary>
    /// Calls the official Salesforce REST APIs using an External Client App access token
    /// </summary>
    public class SalesforceApiClient : ISalesforceApiClient
    {
        private const int QueryTransientRetryCount = 3;
        private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };

        private readonly HttpClient _httpClient;
        private readonly ISalesforceAccessTokenProvider _accessTokenProvider;
        private readonly ISalesforceRetryDelay _retryDelay;
        private readonly SalesforceOptions _options;
        private SalesforceAccessToken? _accessToken;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceApiClient"/> class
        /// </summary>
        /// <param name="httpClient">HTTP client used for Salesforce REST requests</param>
        /// <param name="accessTokenProvider">Provider for an External Client App access token</param>
        /// <param name="options">Salesforce runtime settings</param>
        /// <param name="retryDelay">Delay policy for transient SOQL request retries</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceApiClient(
            HttpClient httpClient,
            ISalesforceAccessTokenProvider accessTokenProvider,
            IOptions<SalesforceOptions> options,
            ISalesforceRetryDelay retryDelay)
        {
            ArgumentNullException.ThrowIfNull(httpClient);
            ArgumentNullException.ThrowIfNull(accessTokenProvider);
            ArgumentNullException.ThrowIfNull(options);
            ArgumentNullException.ThrowIfNull(retryDelay);

            _httpClient = httpClient;
            _accessTokenProvider = accessTokenProvider;
            _options = options.Value;
            _retryDelay = retryDelay;

        }

        /// <inheritdoc />
        public async IAsyncEnumerable<SalesforceQueryResult<TRecord>> QueryPagesAsync<TRecord>(string soql, [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(soql);

            var requestPath = $"/services/data/{GetApiVersion()}/query?q={Uri.EscapeDataString(soql)}";

            while (!string.IsNullOrWhiteSpace(requestPath))
            {
                using var response = await SendAsync(
                    HttpMethod.Get,
                    requestPath,
                    null,
                    true,
                    cancellationToken);
                await ThrowIfUnsuccessfulAsync(response, cancellationToken);

                var result = await response.Content.ReadFromJsonAsync<SalesforceQueryResult<TRecord>>(
                    JsonOptions,
                    cancellationToken)
                    ?? throw new SalesforceQueryResponseException("Salesforce returned an empty query response.");

                requestPath = result.Done
                    ? null
                    : GetValidatedQueryContinuationPath(result.NextRecordsUrl);

                if (!result.Done && string.IsNullOrWhiteSpace(requestPath))
                {
                    throw new SalesforceQueryResponseException("Salesforce returned an incomplete paged query response.");
                }

                yield return result;
            }
        }

        /// <inheritdoc />
        public async Task<IReadOnlyList<TRecord>> QueryAllAsync<TRecord>(string soql, CancellationToken cancellationToken = default)
        {
            var records = new List<TRecord>();

            await foreach (var page in QueryPagesAsync<TRecord>(soql, cancellationToken))
            {
                records.AddRange(page.Records);
            }

            return records;
        }

        /// <inheritdoc />
        public async Task<SalesforceUpsertResult> UpsertAsync<TRequest>(string objectName, string externalIdField, string externalIdValue, TRequest request, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(objectName);
            ArgumentException.ThrowIfNullOrWhiteSpace(externalIdField);
            ArgumentException.ThrowIfNullOrWhiteSpace(externalIdValue);
            ArgumentNullException.ThrowIfNull(request);

            var requestPath = string.Join(
                '/',
                "/services/data",
                GetApiVersion(),
                "sobjects",
                Uri.EscapeDataString(objectName),
                Uri.EscapeDataString(externalIdField),
                Uri.EscapeDataString(externalIdValue));

            using var response = await SendAsync(
                HttpMethod.Patch,
                requestPath,
                () => JsonContent.Create(request, options: JsonOptions),
                false,
                cancellationToken);

            await ThrowIfUnsuccessfulAsync(response, cancellationToken);

            if (response.StatusCode == HttpStatusCode.NoContent)
            {
                return new SalesforceUpsertResult
                {
                    Success = true,
                    Created = false
                };
            }

            return await response.Content.ReadFromJsonAsync<SalesforceUpsertResult>(JsonOptions, cancellationToken) ?? throw new InvalidOperationException("Salesforce returned an empty upsert response.");
        }

        private async Task<HttpResponseMessage> SendAsync(
            HttpMethod method,
            string requestPath,
            Func<HttpContent?>? contentFactory,
            bool retryTransientFailures,
            CancellationToken cancellationToken)
        {
            var authenticationRetries = 0;
            var transientRetries = 0;

            while (true)
            {
                try
                {
                    using var request = await CreateRequestAsync(method, requestPath, cancellationToken);
                    request.Content = contentFactory?.Invoke();

                    var response = await _httpClient.SendAsync(request, cancellationToken);

                    if (response.StatusCode == HttpStatusCode.Unauthorized && authenticationRetries == 0)
                    {
                        response.Dispose();
                        _accessToken = null;
                        authenticationRetries++;
                        continue;
                    }

                    if (retryTransientFailures
                        && IsTransient(response.StatusCode)
                        && transientRetries < QueryTransientRetryCount)
                    {
                        transientRetries++;
                        var delay = _retryDelay.Calculate(transientRetries, response.Headers.RetryAfter);
                        response.Dispose();
                        await _retryDelay.WaitAsync(delay, cancellationToken);
                        continue;
                    }

                    return response;
                }
                catch (HttpRequestException) when (retryTransientFailures && transientRetries < QueryTransientRetryCount)
                {
                    transientRetries++;
                    await WaitBeforeRetryAsync(transientRetries, cancellationToken);
                }
                catch (OperationCanceledException) when (
                    !cancellationToken.IsCancellationRequested
                    && retryTransientFailures
                    && transientRetries < QueryTransientRetryCount)
                {
                    transientRetries++;
                    await WaitBeforeRetryAsync(transientRetries, cancellationToken);
                }
            }
        }

        private Task WaitBeforeRetryAsync(int retryNumber, CancellationToken cancellationToken)
        {
            var delay = _retryDelay.Calculate(retryNumber, null);
            return _retryDelay.WaitAsync(delay, cancellationToken);
        }

        private static bool IsTransient(HttpStatusCode statusCode)
        {
            return statusCode is HttpStatusCode.RequestTimeout
                or HttpStatusCode.TooManyRequests
                or HttpStatusCode.InternalServerError
                or HttpStatusCode.BadGateway
                or HttpStatusCode.ServiceUnavailable
                or HttpStatusCode.GatewayTimeout;
        }

        private async Task<HttpRequestMessage> CreateRequestAsync(HttpMethod method, string requestPath, CancellationToken cancellationToken)
        {
            _accessToken ??= await _accessTokenProvider.GetAccessTokenAsync(cancellationToken);
            if (!Uri.TryCreate(_accessToken.InstanceUrl, UriKind.Absolute, out var instanceUri)
                || !string.Equals(instanceUri.Scheme, Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("Salesforce returned an invalid HTTPS instance URL.");
            }

            var requestUri = new Uri(instanceUri, requestPath);
            var request = new HttpRequestMessage(method, requestUri);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken.AccessToken);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return request;
        }

        private string GetApiVersion()
        {
            if (string.IsNullOrWhiteSpace(_options.ApiVersion))
            {
                throw new InvalidOperationException("Salesforce ApiVersion is not configured.");
            }

            return _options.ApiVersion.Trim('/');
        }

        private string? GetValidatedQueryContinuationPath(string? nextRecordsUrl)
        {
            if (string.IsNullOrWhiteSpace(nextRecordsUrl))
            {
                return null;
            }

            var expectedPathPrefix = $"/services/data/{GetApiVersion()}/query/";

            if (!Uri.TryCreate(nextRecordsUrl, UriKind.Relative, out _)
                || !nextRecordsUrl.StartsWith(expectedPathPrefix, StringComparison.Ordinal)
                || nextRecordsUrl.Contains('#', StringComparison.Ordinal))
            {
                throw new SalesforceQueryResponseException(
                    "Salesforce returned an invalid query continuation URL.");
            }

            return nextRecordsUrl;
        }

        private static async Task ThrowIfUnsuccessfulAsync(HttpResponseMessage response, CancellationToken cancellationToken)
        {
            if (response.IsSuccessStatusCode)
            {
                return;
            }

            IReadOnlyList<SalesforceError> errors = [];

            try
            {
                errors = await response.Content.ReadFromJsonAsync<List<SalesforceError>>(JsonOptions, cancellationToken) ?? [];
            }
            catch (JsonException)
            {
                // Some Salesforce gateway failures do not return the standard JSON error shape.
            }

            throw new SalesforceApiException("Salesforce rejected the REST API request.", response.StatusCode, errors);
        }
    }
}
