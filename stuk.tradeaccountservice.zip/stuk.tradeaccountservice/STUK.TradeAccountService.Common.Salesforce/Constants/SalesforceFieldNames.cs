namespace STUK.TradeAccountService.Common.Salesforce.Constants
{
    /// <summary>
    /// Defines the Salesforce field API names used by the integration
    /// </summary>
    internal static class SalesforceFieldNames
    {
        public const string AccountCode = "Account_Code__c";
        public const string AccountNumber = "Account_Number__c";
        public const string AccountRelationship = "Account";
        public const string BuyerLocationCode = "Buyer_Location_Code__c";
        public const string BuyersOrderNumber = "Buyers_Order_Number__c";
        public const string CodeForDelivery = "Code_For_Delivery__c";
        public const string ContractNumber = "Contract_Number__c";
        public const string CreditTerms = "Credit_Terms__c";
        public const string DeliveryMethod = "Delivery_Method__c";
        public const string DeliveryNoteLineNumber = "Delivery_Note_Line_Number__c";
        public const string DeliveryNoteNumber = "Delivery_Note_Number__c";
        public const string Description = "Description";
        public const string DespatchDate = "Despatch_Date__c";
        public const string EffectiveDate = "EffectiveDate";
        public const string ExternalId = "External_ID__c";
        public const string GrossPaymentTotal = "Gross_Payment_Total__c";
        public const string HouseType = "House_Type__c";
        public const string Id = "Id";
        public const string InvoiceDate = "Invoice_Date__c";
        public const string InvoiceNumber = "Invoice_Number__c";
        public const string IsActive = "IsActive";
        public const string IsSpecialProduct = "Is_Special_Product__c";
        public const string ItemCount = "ItemCount";
        public const string JobAddressLine = "Job_Address_Line__c";
        public const string JobCity = "Job_City__c";
        public const string JobNumber = "Job_Number__c";
        public const string JobPostCode = "Job_Post_Code__c";
        public const string JobState = "Job_State__c";
        public const string JobStreet = "Job_Street__c";
        public const string LineNumber = "Line_Number__c";
        public const string Name = "Name";
        public const string Operative = "Operative__c";
        public const string OrderAuthorised = "Order_Authorised__c";
        public const string OrderCategory = "Order_Category__c";
        public const string OrderLineNumber = "Order_Line_Number__c";
        public const string OrderProductTotal = "Order_Product_Total__c";
        public const string OrderReference = "Order_Reference__c";
        public const string OrderRelationship = "Order";
        public const string OrderType = "Order_Type__c";
        public const string OriginOrderLineItemNumber = "Origin_Order_Line_Item_Number__c";
        public const string PartAnalysisCode = "Part_Analysis_Code__c";
        public const string PercentageDiscount = "Percentage_Discount__c";
        public const string PlotNumber = "Plot_Number__c";
        public const string PricebookId = "Pricebook2Id";
        public const string PricebookEntryRelationship = "PricebookEntry";
        public const string PriceUomCode = "Price_UOM_Code__c";
        public const string PriceUomDescription = "Price_UOM_Description__c";
        public const string ProductCode = "ProductCode";
        public const string ProductGroup = "Product_Group__c";
        public const string ProductRelationship = "Product2";
        public const string Quantity = "Quantity";
        public const string QuantityUomCode = "Quantity_UOM_Code__c";
        public const string QuantityUomDescription = "Quantity_UOM_Description__c";
        public const string SiteCode = "Site_Code__c";
        public const string Status = "Status";
        public const string TaxPointDate = "Tax_Point_Date__c";
        public const string TaxableTotal = "Taxable_Total__c";
        public const string TaxRate = "Tax_Rate__c";
        public const string TaxRateCode = "Tax_Rate_Code__c";
        public const string TaxTotal = "Tax_Total__c";
        public const string TaxValue = "Tax_Value__c";
        public const string Type = "Type";
        public const string UnitPrice = "UnitPrice";
        public const string VehicleRegistration = "Vehicle_Registration__c";
    }
}
