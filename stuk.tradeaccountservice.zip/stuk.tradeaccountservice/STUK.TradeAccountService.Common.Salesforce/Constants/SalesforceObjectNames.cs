namespace STUK.TradeAccountService.Common.Salesforce.Constants
{
    /// <summary>
    /// Defines the Salesforce object API names used by the integration
    /// </summary>
    internal static class SalesforceObjectNames
    {
        public const string Order = "Order";
        public const string OrderItem = "OrderItem";
        public const string PricebookEntry = "PricebookEntry";
        public const string Product2 = "Product2";
    }
}
