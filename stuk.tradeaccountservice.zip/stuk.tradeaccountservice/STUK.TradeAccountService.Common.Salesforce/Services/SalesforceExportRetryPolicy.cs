using STUK.TradeAccountService.Common.Salesforce.Exceptions;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using System.Net;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Applies bounded durable retry rules to Salesforce export extraction failures
    /// </summary>
    public class SalesforceExportRetryPolicy : ISalesforceExportRetryPolicy
    {
        internal const int MaximumExtractionRetryCount = 5;
        private const int BaseDelaySeconds = 60;
        private const int MaximumDelaySeconds = 900;
        private const int JitterSeconds = 30;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceExportRetryPolicy"/>
        /// </summary>
        /// <param name="timeProvider">The processing clock</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public SalesforceExportRetryPolicy(TimeProvider timeProvider)
        {
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public int MaximumAttemptCount => MaximumExtractionRetryCount;

        /// <inheritdoc />
        public bool CanHandle(Exception exception)
        {
            ArgumentNullException.ThrowIfNull(exception);
            return exception is SalesforceApiException
                or SalesforceQueryResponseException
                or HttpRequestException
                or OperationCanceledException
                or JsonException;
        }

        /// <inheritdoc />
        public bool IsTransient(Exception exception)
        {
            ArgumentNullException.ThrowIfNull(exception);

            return exception switch
            {
                SalesforceApiException apiException => IsTransient(apiException.StatusCode),
                SalesforceQueryResponseException => true,
                HttpRequestException => true,
                OperationCanceledException => true,
                JsonException => true,
                _ => false
            };
        }

        /// <inheritdoc />
        public string GetCategory(Exception exception)
        {
            ArgumentNullException.ThrowIfNull(exception);

            return exception switch
            {
                SalesforceApiException apiException when apiException.StatusCode == HttpStatusCode.TooManyRequests => "SalesforceRateLimit",
                SalesforceApiException apiException when IsTransient(apiException.StatusCode) => "SalesforceUnavailable",
                SalesforceApiException => "SalesforceRequestRejected",
                SalesforceQueryResponseException => "SalesforceInvalidResponse",
                HttpRequestException => "SalesforceNetwork",
                OperationCanceledException => "SalesforceTimeout",
                JsonException => "SalesforceInvalidResponse",
                _ => "SalesforceExtraction"
            };
        }

        /// <inheritdoc />
        public DateTimeOffset CalculateNextAttemptOn(int attemptNumber)
        {
            if (attemptNumber <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(attemptNumber), "Attempt number must be greater than zero.");
            }

            var exponent = Math.Min(attemptNumber - 1, 30);
            var exponentialSeconds = BaseDelaySeconds * Math.Pow(2, exponent);
            var jitterSeconds = Random.Shared.Next(0, JitterSeconds + 1);

            var delaySeconds = Math.Min(MaximumDelaySeconds, exponentialSeconds + jitterSeconds);

            return _timeProvider.GetUtcNow().AddSeconds(delaySeconds);
        }

        private static bool IsTransient(HttpStatusCode statusCode)
        {
            return statusCode is HttpStatusCode.RequestTimeout
                or HttpStatusCode.TooManyRequests
                or HttpStatusCode.InternalServerError
                or HttpStatusCode.BadGateway
                or HttpStatusCode.ServiceUnavailable
                or HttpStatusCode.GatewayTimeout;
        }

    }
}
