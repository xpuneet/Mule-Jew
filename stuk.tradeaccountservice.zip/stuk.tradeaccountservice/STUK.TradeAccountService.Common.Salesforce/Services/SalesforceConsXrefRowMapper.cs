using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Maps the legacy Salesforce ConsXref query response into durable export rows
    /// </summary>
    public class SalesforceConsXrefRowMapper : ISalesforceConsXrefRowMapper
    {
        /// <inheritdoc />
        public ConsolidatedSalesExportRow Map(SalesforceConsXrefOrderItem source)
        {
            ArgumentNullException.ThrowIfNull(source);

            return new ConsolidatedSalesExportRow
            {
                AccountNumber = source.Order?.Account?.AccountNumber,
                InvoiceNumber = source.Order?.InvoiceNumber,
                InvoiceDate = source.Order?.InvoiceDate,
                DeliveryNoteNumber = source.DeliveryNoteNumber,
                DeliveryNoteLineNumber = source.DeliveryNoteLineNumber?.ToString("0", CultureInfo.InvariantCulture),
                DespatchDate = source.DespatchDate,
                ProductCode = source.Product?.ProductCode,
                Quantity = source.Quantity,
                TotalPrice = source.TotalPrice
            };
        }
    }
}
