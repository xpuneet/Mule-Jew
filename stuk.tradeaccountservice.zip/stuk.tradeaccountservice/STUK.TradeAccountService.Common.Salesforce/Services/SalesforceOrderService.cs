using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Constants;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Creates and finalises Salesforce Orders and OrderItems for Consolidated Sales invoices
    /// </summary>
    public class SalesforceOrderService : ISalesforceOrderService
    {
        private const string ActivatedStatus = "Activated";
        private const string DraftStatus = "Draft";

        private readonly ISalesforceApiClient _salesforceApiClient;
        private readonly SalesforceOptions _options;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceOrderService"/> class
        /// </summary>
        /// <param name="salesforceApiClient">Client used for Salesforce REST operations</param>
        /// <param name="options">Salesforce runtime settings</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceOrderService(ISalesforceApiClient salesforceApiClient, IOptions<SalesforceOptions> options)
        {
            ArgumentNullException.ThrowIfNull(salesforceApiClient);
            ArgumentNullException.ThrowIfNull(options);

            _salesforceApiClient = salesforceApiClient;
            _options = options.Value;
        }

        /// <inheritdoc />
        public async Task<SalesforceUpsertResult> UpsertDraftOrderAsync(SalesforceOrderProjection order, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(order);

            var invoiceNumber = RequiredValue(order.InvoiceNumber, "The consolidated invoice number is required for Salesforce Order synchronisation.");
            var accountExternalId = RequiredValue(order.AccountExternalId, $"The account external identifier is required for invoice {invoiceNumber}.");
            var pricebookId = RequiredValue(_options.PricebookId, "Salesforce PricebookId is not configured.");

            var existingId = await GetExistingRecordIdAsync(
                SalesforceObjectNames.Order,
                SalesforceFieldNames.InvoiceNumber,
                invoiceNumber,
                cancellationToken);
            var result = await _salesforceApiClient.UpsertAsync(
                SalesforceObjectNames.Order,
                SalesforceFieldNames.InvoiceNumber,
                invoiceNumber,
                new SalesforceOrderRequest
                {
                    Account = new SalesforceAccountReference
                    {
                        AccountNumber = accountExternalId
                    },
                    PricebookId = pricebookId,
                    EffectiveDate = order.EffectiveDate,
                    Status = DraftStatus,
                    OrderType = order.OrderType,
                    CreditTerms = order.CreditTerms,
                    InvoiceDate = order.InvoiceDate,
                    InvoiceNumber = invoiceNumber,
                    TaxPointDate = order.TaxPointDate,
                    AccountCode = accountExternalId,
                    TaxTotal = order.TaxTotal,
                    TaxableTotal = order.TaxableTotal,
                    GrossPaymentTotal = order.GrossPaymentTotal
                },
                cancellationToken);

            return await WithRequiredIdAsync(
                result,
                existingId,
                SalesforceObjectNames.Order,
                SalesforceFieldNames.InvoiceNumber,
                invoiceNumber,
                cancellationToken);
        }

        /// <inheritdoc />
        public async Task<SalesforceUpsertResult> UpsertOrderItemAsync(SalesforceOrderItemProjection orderItem, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(orderItem);

            var externalId = RequiredValue(orderItem.ExternalId, "The deterministic external identifier is required for Salesforce OrderItem synchronisation.");
            var invoiceNumber = RequiredValue(orderItem.InvoiceNumber, $"The consolidated invoice number is required for OrderItem {externalId}.");
            var productCode = RequiredValue(orderItem.ProductCode, $"The product code is required for OrderItem {externalId}.");

            var existingId = await GetExistingRecordIdAsync(
                SalesforceObjectNames.OrderItem,
                SalesforceFieldNames.ExternalId,
                externalId,
                cancellationToken);
            var result = await _salesforceApiClient.UpsertAsync(
                SalesforceObjectNames.OrderItem,
                SalesforceFieldNames.ExternalId,
                externalId,
                MapOrderItem(orderItem, invoiceNumber, productCode),
                cancellationToken);

            return await WithRequiredIdAsync(
                result,
                existingId,
                SalesforceObjectNames.OrderItem,
                SalesforceFieldNames.ExternalId,
                externalId,
                cancellationToken);
        }

        private async Task<string?> GetExistingRecordIdAsync(
            string objectName,
            string externalIdField,
            string externalIdValue,
            CancellationToken cancellationToken)
        {
            var records = await _salesforceApiClient.QueryAllAsync<SalesforceRecord>(
                $"SELECT {SalesforceFieldNames.Id} FROM {objectName} WHERE {externalIdField} = '{EscapeSoqlValue(externalIdValue)}'",
                cancellationToken);

            return records.SingleOrDefault()?.Id;
        }

        private async Task<SalesforceUpsertResult> WithRequiredIdAsync(
            SalesforceUpsertResult result,
            string? existingId,
            string objectName,
            string externalIdField,
            string externalId,
            CancellationToken cancellationToken)
        {
            result.Id ??= existingId;

            if (result.Success && string.IsNullOrWhiteSpace(result.Id))
            {
                result.Id = await GetExistingRecordIdAsync(
                    objectName,
                    externalIdField,
                    externalId,
                    cancellationToken);
            }

            if (!result.Success || string.IsNullOrWhiteSpace(result.Id))
            {
                throw new InvalidOperationException($"Salesforce did not return the {objectName} identifier for {externalId}.");
            }

            return result;
        }

        /// <inheritdoc />
        public async Task<SalesforceOrderFinalisationResult> FinaliseOrderAsync(string invoiceNumber, int expectedLineCount, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(invoiceNumber);

            if (expectedLineCount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(expectedLineCount), "The expected line count must be positive.");
            }

            var actualLineCount = await GetOrderItemCountAsync(invoiceNumber, cancellationToken);

            if (actualLineCount != expectedLineCount)
            {
                return new SalesforceOrderFinalisationResult
                {
                    ExpectedLineCount = expectedLineCount,
                    ActualLineCount = actualLineCount,
                    Activated = false
                };
            }

            await ActivateOrderAsync(invoiceNumber, cancellationToken);

            return new SalesforceOrderFinalisationResult
            {
                ExpectedLineCount = expectedLineCount,
                ActualLineCount = actualLineCount,
                Activated = true
            };
        }

        private async Task<int> GetOrderItemCountAsync(string invoiceNumber, CancellationToken cancellationToken)
        {
            var escapedInvoiceNumber = EscapeSoqlValue(invoiceNumber);
            var counts = await _salesforceApiClient.QueryAllAsync<SalesforceOrderItemCount>(
                $"SELECT COUNT({SalesforceFieldNames.Id}) {SalesforceFieldNames.ItemCount} "
                + $"FROM {SalesforceObjectNames.OrderItem} "
                + $"WHERE {SalesforceFieldNames.OrderRelationship}.{SalesforceFieldNames.InvoiceNumber} = '{escapedInvoiceNumber}'",
                cancellationToken);

            return counts.SingleOrDefault()?.ItemCount ?? 0;
        }

        private Task<SalesforceUpsertResult> ActivateOrderAsync(string invoiceNumber, CancellationToken cancellationToken)
        {
            return _salesforceApiClient.UpsertAsync(
                SalesforceObjectNames.Order,
                SalesforceFieldNames.InvoiceNumber,
                invoiceNumber,
                new SalesforceOrderStatusRequest
                {
                    Status = ActivatedStatus
                },
                cancellationToken);
        }

        private static SalesforceOrderItemRequest MapOrderItem(SalesforceOrderItemProjection source, string invoiceNumber, string productCode)
        {
            return new SalesforceOrderItemRequest
            {
                ExternalId = source.ExternalId,
                Quantity = source.Quantity,
                UnitPrice = source.UnitPrice,
                Product = new SalesforceProductReference { ExternalId = productCode },
                PricebookEntry = new SalesforcePricebookEntryReference { ExternalId = productCode },
                Order = new SalesforceOrderReference { InvoiceNumber = invoiceNumber },
                Description = source.Description,
                BuyerLocationCode = source.BuyerLocationCode,
                BuyersOrderNumber = source.BuyersOrderNumber,
                CodeForDelivery = source.CodeForDelivery,
                ContractNumber = source.ContractNumber,
                DeliveryMethod = source.DeliveryMethod,
                DeliveryNoteLineNumber = source.DeliveryNoteLineNumber,
                DeliveryNoteNumber = source.DeliveryNoteNumber,
                DespatchDate = source.DespatchDate,
                HouseType = source.HouseType,
                IsSpecialProduct = source.IsSpecialProduct,
                JobAddressLine = source.JobAddressLine,
                JobCity = source.JobCity,
                JobNumber = source.JobNumber,
                JobState = source.JobState,
                JobStreet = source.JobStreet,
                Operative = source.Operative,
                OrderAuthorised = source.OrderAuthorised,
                OrderCategory = source.OrderCategory,
                OrderLineNumber = source.OrderLineNumber,
                OrderReference = source.OrderReference,
                OrderType = source.OrderType,
                PartAnalysisCode = source.PartAnalysisCode,
                PlotNumber = source.PlotNumber,
                PriceUomCode = source.PriceUomCode,
                PriceUomDescription = source.PriceUomDescription,
                ProductGroup = source.ProductGroup,
                QuantityUomCode = source.QuantityUomCode,
                QuantityUomDescription = source.QuantityUomDescription,
                SiteCode = source.SiteCode,
                TaxRateCode = source.TaxRateCode,
                TaxRate = source.TaxRate,
                TaxValue = source.TaxValue,
                VehicleRegistration = source.VehicleRegistration,
                JobPostcode = source.JobPostcode,
                OriginalOrderLineNumber = source.OriginalOrderLineNumber,
                OrderProductTotal = source.OrderProductTotal,
                PercentageDiscount = source.PercentageDiscount,
                LineNumber = source.LineNumber
            };
        }

        private static string RequiredValue(string? value, string message)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidOperationException(message);
            }

            return value;
        }

        private static string EscapeSoqlValue(string value)
        {
            return value
                .Replace("\\", "\\\\", StringComparison.Ordinal)
                .Replace("'", "\\'", StringComparison.Ordinal);
        }
    }
}
