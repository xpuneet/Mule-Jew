using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Loads the Salesforce signing certificate supplied through secure environment configuration
    /// </summary>
    /// <remarks>
    /// The private certificate is required to sign the OAuth JWT assertion sent to Salesforce
    /// Salesforce validates that signature using the corresponding public certificate registered
    /// against the External Client App before issuing an access token
    /// </remarks>
    public class SalesforceSigningCertificateProvider : ISalesforceSigningCertificateProvider
    {
        private readonly SalesforceOptions _options;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceSigningCertificateProvider"/> class
        /// </summary>
        /// <param name="options">Salesforce runtime settings</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceSigningCertificateProvider(IOptions<SalesforceOptions> options)
        {
            ArgumentNullException.ThrowIfNull(options);
            _options = options.Value;
        }

        /// <inheritdoc />
        public X509Certificate2 GetCertificate()
        {
            if (string.IsNullOrWhiteSpace(_options.SigningCertificateBase64))
            {
                throw new InvalidOperationException("The Salesforce signing certificate is not configured.");
            }

            try
            {
                var certificateBytes = Convert.FromBase64String(_options.SigningCertificateBase64);
                var certificate = new X509Certificate2(certificateBytes, _options.SigningCertificatePassword, X509KeyStorageFlags.EphemeralKeySet);

                if (!certificate.HasPrivateKey)
                {
                    certificate.Dispose();
                    throw new InvalidOperationException("The Salesforce signing certificate does not contain a private key.");
                }

                return certificate;
            }
            catch (FormatException exception)
            {
                throw new InvalidOperationException("The Salesforce signing certificate is not valid Base64.", exception);
            }
            catch (CryptographicException exception)
            {
                throw new InvalidOperationException("The Salesforce signing certificate could not be loaded.", exception);
            }
        }
    }
}
