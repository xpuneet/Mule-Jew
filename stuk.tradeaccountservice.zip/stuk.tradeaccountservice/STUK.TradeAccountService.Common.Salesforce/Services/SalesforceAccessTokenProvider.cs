using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Json;
using System.Security.Claims;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Authenticates with Salesforce using the External Client App JWT bearer flow
    /// </summary>
    public class SalesforceAccessTokenProvider : ISalesforceAccessTokenProvider
    {
        private const string JwtBearerGrantType = "urn:ietf:params:oauth:grant-type:jwt-bearer";
        private static readonly TimeSpan AssertionLifetime = TimeSpan.FromMinutes(3);

        private readonly HttpClient _httpClient;
        private readonly ISalesforceSigningCertificateProvider _certificateProvider;
        private readonly SalesforceOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceAccessTokenProvider"/> class
        /// </summary>
        /// <param name="httpClient">HTTP client used for the OAuth token request</param>
        /// <param name="certificateProvider">Provider for the JWT signing certificate</param>
        /// <param name="options">Salesforce runtime settings</param>
        /// <param name="timeProvider">Provider for the current time</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceAccessTokenProvider(HttpClient httpClient, ISalesforceSigningCertificateProvider certificateProvider, IOptions<SalesforceOptions> options, TimeProvider timeProvider)
        {
            ArgumentNullException.ThrowIfNull(httpClient);
            ArgumentNullException.ThrowIfNull(certificateProvider);
            ArgumentNullException.ThrowIfNull(options);
            ArgumentNullException.ThrowIfNull(timeProvider);

            _httpClient = httpClient;
            _certificateProvider = certificateProvider;
            _options = options.Value;
            _timeProvider = timeProvider;
        }

        /// <inheritdoc />
        public async Task<SalesforceAccessToken> GetAccessTokenAsync(CancellationToken cancellationToken = default)
        {
            ValidateOptions();

            var assertion = CreateAssertion();
            using var content = new FormUrlEncodedContent(
            [
                new KeyValuePair<string, string>("grant_type", JwtBearerGrantType),
                new KeyValuePair<string, string>("assertion", assertion)
            ]);
            using var response = await _httpClient.PostAsync(_options.TokenEndpoint, content, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                throw new SalesforceApiException("Salesforce rejected the External Client App token request.", response.StatusCode);
            }

            var token = await response.Content.ReadFromJsonAsync<SalesforceAccessToken>(cancellationToken) ?? throw new InvalidOperationException("Salesforce returned an empty access-token response.");

            if (string.IsNullOrWhiteSpace(token.AccessToken) || string.IsNullOrWhiteSpace(token.InstanceUrl))
            {
                throw new InvalidOperationException("Salesforce returned an incomplete access-token response.");
            }

            return token;
        }

        private string CreateAssertion()
        {
            using var certificate = _certificateProvider.GetCertificate();
            var now = _timeProvider.GetUtcNow();

            var signingCredentials = new X509SigningCredentials(
                certificate,
                SecurityAlgorithms.RsaSha256);

            var token = new JwtSecurityToken(
                issuer: _options.ClientId,
                audience: _options.Audience,
                claims: [new Claim(JwtRegisteredClaimNames.Sub, _options.Username)],
                notBefore: now.UtcDateTime,
                expires: now.Add(AssertionLifetime).UtcDateTime,
                signingCredentials: signingCredentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private void ValidateOptions()
        {
            RequiredValue(_options.TokenEndpoint, nameof(_options.TokenEndpoint));
            RequiredValue(_options.Audience, nameof(_options.Audience));
            RequiredValue(_options.ClientId, nameof(_options.ClientId));
            RequiredValue(_options.Username, nameof(_options.Username));

            if (!Uri.TryCreate(_options.TokenEndpoint, UriKind.Absolute, out var tokenEndpoint)
                || !string.Equals(tokenEndpoint.Scheme, Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("Salesforce TokenEndpoint must be an absolute HTTPS URI.");
            }
        }

        private static void RequiredValue(string? value, string propertyName)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidOperationException($"Salesforce {propertyName} is not configured.");
            }
        }
    }
}
