using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Coordinates idempotent weekly registration, SQL claiming and Salesforce extraction
    /// </summary>
    public class ConsolidatedSalesExportOrchestrationService : IConsolidatedSalesExportOrchestrationService
    {
        private const int MaximumWorkItemsPerRun = 1;
        private const int LeaseDurationSeconds = 900;
        private const int LeaseRenewalIntervalSeconds = 60;
        private readonly ILogger<ConsolidatedSalesExportOrchestrationService> _logger;
        private readonly IConsolidatedSalesExportDataService _exportDataService;
        private readonly IConsolidatedSalesExportExtractionService _extractionService;
        private readonly IPhocasExportStagingService _phocasExportStagingService;
        private readonly IDataLakeExportService _dataLakeExportService;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesExportOrchestrationService"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="exportDataService">The durable export persistence service</param>
        /// <param name="extractionService">The Salesforce snapshot extraction service</param>
        /// <param name="phocasExportStagingService">The Phocas destination staging service</param>
        /// <param name="dataLakeExportService">The Data Lake destination delivery service</param>
        /// <param name="timeProvider">Provider for UTC processing timestamps and timers</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public ConsolidatedSalesExportOrchestrationService(
            ILogger<ConsolidatedSalesExportOrchestrationService> logger,
            IConsolidatedSalesExportDataService exportDataService,
            IConsolidatedSalesExportExtractionService extractionService,
            IPhocasExportStagingService phocasExportStagingService,
            IDataLakeExportService dataLakeExportService,
            TimeProvider timeProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _exportDataService = exportDataService ?? throw new ArgumentNullException(nameof(exportDataService));
            _extractionService = extractionService ?? throw new ArgumentNullException(nameof(extractionService));
            _phocasExportStagingService = phocasExportStagingService ?? throw new ArgumentNullException(nameof(phocasExportStagingService));
            _dataLakeExportService = dataLakeExportService ?? throw new ArgumentNullException(nameof(dataLakeExportService));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task RunAsync(string leaseOwner, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);
            var scheduleTimeZone = GetScheduleTimeZone();
            cancellationToken.ThrowIfCancellationRequested();

            var now = _timeProvider.GetUtcNow();
            var scheduledFor = GetLatestScheduledTime(now, scheduleTimeZone);
            var localScheduledFor = TimeZoneInfo.ConvertTime(scheduledFor, scheduleTimeZone);

            var registration = new ConsolidatedSalesExportRunRegistration
            {
                LogicalRunKey = $"ConsXref:{localScheduledFor:yyyy-MM-dd}",
                CorrelationId = Guid.NewGuid(),
                ExportYear = localScheduledFor.Year,
                ExtractFromDate = new DateOnly(localScheduledFor.Year, 1, 1),
                ScheduledFor = scheduledFor,
                Now = now
            };
            ConsolidatedSalesExportRun registeredRun;

            try
            {
                registeredRun = await _exportDataService.CreateRunAsync(registration, cancellationToken);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                _logger.LogError(
                    exception,
                    "Consolidated Sales SQL run registration failed for logical run {LogicalRunKey} and correlation {CorrelationId}",
                    registration.LogicalRunKey,
                    registration.CorrelationId);
                throw;
            }

            _logger.LogInformation(
                "Consolidated Sales export run {ExportRunId} registered for logical run {LogicalRunKey}, correlation {CorrelationId}, status {Status} and scheduled time {ScheduledFor}",
                registeredRun.Id,
                registeredRun.LogicalRunKey,
                registeredRun.CorrelationId,
                registeredRun.Status,
                registeredRun.ScheduledFor);

            await RunEligibleExtractionAsync(leaseOwner, cancellationToken);
            await RunDestinationsAsync(leaseOwner, cancellationToken: cancellationToken);
        }

        /// <inheritdoc />
        public async Task RunRecoveryAsync(string leaseOwner, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);

            await RunEligibleExtractionAsync(leaseOwner, cancellationToken);
            await RunDestinationsAsync(leaseOwner, cancellationToken: cancellationToken);
        }

        /// <inheritdoc />
        public async Task RunDestinationsAsync(string leaseOwner, Guid? exportDestinationId = null, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);

            try
            {
                await _phocasExportStagingService.RunAsync(leaseOwner, exportDestinationId, cancellationToken);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                _logger.LogError(exception, "Phocas destination processing could not start");
            }

            try
            {
                await _dataLakeExportService.RunAsync(leaseOwner, exportDestinationId, cancellationToken);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                _logger.LogError(exception, "Data Lake destination processing could not start");
            }
        }

        /// <inheritdoc />
        public async Task ReplayDestinationAsync(Guid exportDestinationId, string reason, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(reason);

            _logger.LogWarning(
                "Controlled Consolidated Sales destination replay requested for destination work {ExportDestinationId}; reason: {ReplayReason}",
                exportDestinationId,
                reason);

            await _exportDataService.RequeueDestinationAsync(
                exportDestinationId,
                reason,
                _timeProvider.GetUtcNow(),
                cancellationToken);

            _logger.LogInformation(
                "Controlled Consolidated Sales destination replay queued for destination work {ExportDestinationId}",
                exportDestinationId);
        }

        private async Task RunEligibleExtractionAsync(string leaseOwner, CancellationToken cancellationToken)
        {
            for (var workItemNumber = 0; workItemNumber < MaximumWorkItemsPerRun; workItemNumber++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var exportRun = await _exportDataService.ClaimNextRunAsync(
                    leaseOwner,
                    LeaseDurationSeconds,
                    SalesforceExportRetryPolicy.MaximumExtractionRetryCount,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                if (exportRun is null)
                {
                    break;
                }

                _logger.LogInformation(
                    "Consolidated Sales export {ExportRunId} claimed for Salesforce extraction with correlation {CorrelationId} and attempt {AttemptCount}",
                    exportRun.Id,
                    exportRun.CorrelationId,
                    exportRun.ExtractionAttemptCount);

                try
                {
                    await ProcessWithLeaseRenewalAsync(exportRun, cancellationToken);
                }
                catch (Exception exception) when (exception is not OperationCanceledException)
                {
                    _logger.LogError(
                        exception,
                        "Consolidated Sales export extraction failed for run {ExportRunId} and correlation {CorrelationId}",
                        exportRun.Id,
                        exportRun.CorrelationId);
                }
            }
        }

        private async Task ProcessWithLeaseRenewalAsync(ConsolidatedSalesExportRun exportRun, CancellationToken cancellationToken)
        {
            using var processingCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            var processingTask = _extractionService.ExtractAsync(exportRun, processingCancellation.Token);
            var renewalTask = RenewLeaseUntilCancelledAsync(exportRun, processingCancellation.Token);
            var renewalCompletedFirst = false;

            try
            {
                var firstCompletedTask = await Task.WhenAny(processingTask, renewalTask);
                if (firstCompletedTask == renewalTask)
                {
                    renewalCompletedFirst = true;
                    await renewalTask;
                }

                await processingTask;
            }
            finally
            {
                await processingCancellation.CancelAsync();

                try
                {
                    await renewalTask;
                }
                catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                {
                    // Expected after extraction completes or a lease renewal fails.
                }
                catch when (renewalCompletedFirst)
                {
                    // The renewal failure was already observed and remains the primary exception.
                }

                if (!processingTask.IsCompleted)
                {
                    try
                    {
                        await processingTask;
                    }
                    catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                    {
                        // Extraction must stop when its SQL lease can no longer be renewed.
                    }
                }
            }
        }

        private async Task RenewLeaseUntilCancelledAsync(ConsolidatedSalesExportRun exportRun, CancellationToken cancellationToken)
        {
            var claimToken = exportRun.ClaimToken ?? throw new InvalidOperationException($"Claimed export run {exportRun.Id} has no claim token.");
            var renewalInterval = TimeSpan.FromSeconds(LeaseRenewalIntervalSeconds);

            while (true)
            {
                await Task.Delay(renewalInterval, _timeProvider, cancellationToken);
                await _exportDataService.RenewRunLeaseAsync(
                    exportRun.Id,
                    claimToken,
                    LeaseDurationSeconds,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);
            }
        }

        private static TimeZoneInfo GetScheduleTimeZone()
        {
            try
            {
                return TimeZoneInfo.FindSystemTimeZoneById(ConsolidatedSalesExportSchedule.TimeZoneId);
            }
            catch (TimeZoneNotFoundException exception)
            {
                throw new InvalidOperationException(
                    string.Format(CultureInfo.InvariantCulture, "The export schedule time zone '{0}' was not found.", ConsolidatedSalesExportSchedule.TimeZoneId),
                    exception);
            }
            catch (InvalidTimeZoneException exception)
            {
                throw new InvalidOperationException(
                    string.Format(CultureInfo.InvariantCulture, "The export schedule time zone '{0}' is invalid.", ConsolidatedSalesExportSchedule.TimeZoneId),
                    exception);
            }
        }

        private DateTimeOffset GetLatestScheduledTime(DateTimeOffset utcNow, TimeZoneInfo scheduleTimeZone)
        {
            var localNow = TimeZoneInfo.ConvertTime(utcNow, scheduleTimeZone);
            var daysSinceMonday = ((int)localNow.DayOfWeek - (int)DayOfWeek.Monday + 7) % 7;
            var scheduledDate = localNow.Date.AddDays(-daysSinceMonday);
            var localScheduledDateTime = new DateTime(
                scheduledDate.Year,
                scheduledDate.Month,
                scheduledDate.Day,
                ConsolidatedSalesExportSchedule.ScheduledHour,
                ConsolidatedSalesExportSchedule.ScheduledMinute,
                0,
                DateTimeKind.Unspecified);

            if (localNow.DateTime < localScheduledDateTime)
            {
                localScheduledDateTime = localScheduledDateTime.AddDays(-7);
            }

            var scheduledUtc = TimeZoneInfo.ConvertTimeToUtc(localScheduledDateTime, scheduleTimeZone);
            return new DateTimeOffset(scheduledUtc, TimeSpan.Zero);
        }
    }
}
