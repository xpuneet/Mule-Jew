using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using System.Net.Http.Headers;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Applies Salesforce Retry-After or bounded exponential backoff with jitter
    /// </summary>
    public class SalesforceRetryDelay : ISalesforceRetryDelay
    {
        private const int BaseDelaySeconds = 2;
        private const int MaximumDelaySeconds = 30;
        private const int JitterMilliseconds = 500;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceRetryDelay"/>
        /// </summary>
        /// <param name="timeProvider">The processing clock and timer provider</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public SalesforceRetryDelay(TimeProvider timeProvider)
        {
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public TimeSpan Calculate(int retryNumber, RetryConditionHeaderValue? retryAfter)
        {
            if (retryNumber <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(retryNumber), "Retry number must be greater than zero.");
            }

            var serverDelay = GetServerDelay(retryAfter);
            if (serverDelay is not null)
            {
                return serverDelay.Value;
            }

            var exponent = Math.Min(retryNumber - 1, 30);
            var exponentialMilliseconds = BaseDelaySeconds * 1000d * Math.Pow(2, exponent);
            var jitterMilliseconds = Random.Shared.Next(0, JitterMilliseconds + 1);
            var boundedMilliseconds = Math.Min(
                MaximumDelaySeconds * 1000d,
                exponentialMilliseconds + jitterMilliseconds);
            return TimeSpan.FromMilliseconds(boundedMilliseconds);
        }

        /// <inheritdoc />
        public Task WaitAsync(TimeSpan delay, CancellationToken cancellationToken)
        {
            return Task.Delay(delay, _timeProvider, cancellationToken);
        }

        private TimeSpan? GetServerDelay(RetryConditionHeaderValue? retryAfter)
        {
            if (retryAfter?.Delta is { } delta)
            {
                return delta > TimeSpan.Zero ? delta : TimeSpan.Zero;
            }

            if (retryAfter?.Date is { } date)
            {
                var delay = date - _timeProvider.GetUtcNow();
                return delay > TimeSpan.Zero ? delay : TimeSpan.Zero;
            }

            return null;
        }

    }
}
