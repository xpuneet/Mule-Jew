using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Constants;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Ensures Product2 and PricebookEntry prerequisites exist before OrderItem synchronisation
    /// </summary>
    public class SalesforceProductService : ISalesforceProductService
    {
        private const int QueryBatchSize = 100;

        private readonly ISalesforceApiClient _salesforceApiClient;
        private readonly SalesforceOptions _options;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceProductService"/> class
        /// </summary>
        /// <param name="salesforceApiClient">Client used for Salesforce REST operations</param>
        /// <param name="options">Salesforce runtime settings</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceProductService(ISalesforceApiClient salesforceApiClient, IOptions<SalesforceOptions> options)
        {
            ArgumentNullException.ThrowIfNull(salesforceApiClient);
            ArgumentNullException.ThrowIfNull(options);

            _salesforceApiClient = salesforceApiClient;
            _options = options.Value;
        }

        /// <inheritdoc />
        public async Task<IReadOnlyDictionary<string, SalesforceProductPrerequisite>> EnsureProductsAsync(IReadOnlyCollection<string> productCodes, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(productCodes);

            if (productCodes.Any(string.IsNullOrWhiteSpace))
            {
                throw new ArgumentException("Product codes cannot contain an empty value.", nameof(productCodes));
            }

            if (string.IsNullOrWhiteSpace(_options.PricebookId))
            {
                throw new InvalidOperationException("Salesforce PricebookId is not configured.");
            }

            var requiredCodes = productCodes
                .Distinct(StringComparer.Ordinal)
                .ToArray();

            if (requiredCodes.Length == 0)
            {
                return new Dictionary<string, SalesforceProductPrerequisite>(StringComparer.Ordinal);
            }

            var existingProducts = await GetExistingProductsAsync(requiredCodes, cancellationToken);

            foreach (var productCode in requiredCodes.Except(existingProducts.Keys, StringComparer.Ordinal))
            {
                existingProducts[productCode] = await CreateProductAsync(productCode, cancellationToken);
            }

            var existingPricebookEntries = await GetExistingPricebookEntriesAsync(
                requiredCodes,
                cancellationToken);

            foreach (var productCode in requiredCodes.Except(existingPricebookEntries.Keys, StringComparer.Ordinal))
            {
                existingPricebookEntries[productCode] = await CreatePricebookEntryAsync(productCode, cancellationToken);
            }

            return requiredCodes.ToDictionary(
                productCode => productCode,
                productCode => new SalesforceProductPrerequisite
                {
                    ExternalId = productCode,
                    ProductId = existingProducts[productCode],
                    PricebookEntryId = existingPricebookEntries[productCode]
                },
                StringComparer.Ordinal);
        }

        private async Task<Dictionary<string, string>> GetExistingProductsAsync(IReadOnlyList<string> productCodes, CancellationToken cancellationToken)
        {
            var result = new Dictionary<string, string>(StringComparer.Ordinal);

            foreach (var productCodeBatch in productCodes.Chunk(QueryBatchSize))
            {
                var products = await _salesforceApiClient.QueryAllAsync<SalesforceProduct>(
                    $"SELECT {SalesforceFieldNames.Id}, {SalesforceFieldNames.ExternalId} "
                    + $"FROM {SalesforceObjectNames.Product2} "
                    + $"WHERE {SalesforceFieldNames.ExternalId} IN ({BuildSoqlValues(productCodeBatch)})",
                    cancellationToken);

                foreach (var product in products)
                {
                    result[product.ExternalId] = product.Id;
                }
            }

            return result;
        }

        private async Task<Dictionary<string, string>> GetExistingPricebookEntriesAsync(IReadOnlyList<string> productCodes, CancellationToken cancellationToken)
        {
            var result = new Dictionary<string, string>(StringComparer.Ordinal);
            var pricebookId = EscapeSoqlValue(_options.PricebookId);

            foreach (var productCodeBatch in productCodes.Chunk(QueryBatchSize))
            {
                var entries = await _salesforceApiClient.QueryAllAsync<SalesforcePricebookEntry>(
                    $"SELECT {SalesforceFieldNames.Id}, {SalesforceFieldNames.ExternalId} "
                    + $"FROM {SalesforceObjectNames.PricebookEntry} "
                    + $"WHERE {SalesforceFieldNames.PricebookId} = '{pricebookId}' "
                    + $"AND {SalesforceFieldNames.ExternalId} IN ({BuildSoqlValues(productCodeBatch)})",
                    cancellationToken);

                foreach (var entry in entries)
                {
                    result[entry.ExternalId] = entry.Id;
                }
            }

            return result;
        }

        private async Task<string> CreateProductAsync(string productCode, CancellationToken cancellationToken)
        {
            var result = await _salesforceApiClient.UpsertAsync(
                SalesforceObjectNames.Product2,
                SalesforceFieldNames.ExternalId,
                productCode,
                new SalesforceProductRequest
                {
                    Name = productCode,
                    ProductCode = productCode,
                    ExternalId = productCode,
                    IsActive = true
                },
                cancellationToken);

            return await ResolveUpsertIdAsync(
                result,
                SalesforceObjectNames.Product2,
                productCode,
                cancellationToken);
        }

        private async Task<string> CreatePricebookEntryAsync(string productCode, CancellationToken cancellationToken)
        {
            var result = await _salesforceApiClient.UpsertAsync(
                SalesforceObjectNames.PricebookEntry,
                SalesforceFieldNames.ExternalId,
                productCode,
                new SalesforcePricebookEntryRequest
                {
                    PricebookId = _options.PricebookId,
                    UnitPrice = 0m,
                    IsActive = true,
                    ExternalId = productCode,
                    Product = new SalesforceProductReference
                    {
                        ExternalId = productCode
                    }
                },
                cancellationToken);

            return await ResolveUpsertIdAsync(
                result,
                SalesforceObjectNames.PricebookEntry,
                productCode,
                cancellationToken);
        }

        private async Task<string> ResolveUpsertIdAsync(
            SalesforceUpsertResult result,
            string objectName,
            string externalId,
            CancellationToken cancellationToken)
        {
            if (!result.Success)
            {
                throw new InvalidOperationException($"Salesforce did not return the {objectName} identifier for {externalId}.");
            }

            if (!string.IsNullOrWhiteSpace(result.Id))
            {
                return result.Id;
            }

            var records = await _salesforceApiClient.QueryAllAsync<SalesforceRecord>(
                $"SELECT {SalesforceFieldNames.Id} FROM {objectName} "
                + $"WHERE {SalesforceFieldNames.ExternalId} = '{EscapeSoqlValue(externalId)}'",
                cancellationToken);
            var existingId = records.SingleOrDefault()?.Id;

            if (string.IsNullOrWhiteSpace(existingId))
            {
                throw new InvalidOperationException($"Salesforce did not return the {objectName} identifier for {externalId}.");
            }

            return existingId;
        }

        private static string BuildSoqlValues(IEnumerable<string> values)
        {
            return string.Join(",", values.Select(value => $"'{EscapeSoqlValue(value)}'"));
        }

        private static string EscapeSoqlValue(string value)
        {
            return value
                .Replace("\\", "\\\\", StringComparison.Ordinal)
                .Replace("'", "\\'", StringComparison.Ordinal);
        }
    }
}
