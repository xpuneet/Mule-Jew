using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using System.Net;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Coordinates durable SQL work with the Salesforce projection services
    /// </summary>
    public class SalesforceSyncService : ISalesforceSyncService
    {
        private const string CompletedLineStatus = "Completed";
        private const int MaximumErrorMessageLength = 2000;

        private readonly ILogger<SalesforceSyncService> _logger;
        private readonly ISalesforceSyncDataService _dataService;
        private readonly ISalesforceInvoiceMapper _invoiceMapper;
        private readonly ISalesforceProductService _productService;
        private readonly ISalesforceOrderService _orderService;
        private readonly SalesforceSyncOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceSyncService"/> class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="dataService">Durable Salesforce work data service</param>
        /// <param name="invoiceMapper">Canonical invoice mapper</param>
        /// <param name="productService">Salesforce product prerequisite service</param>
        /// <param name="orderService">Salesforce Order service</param>
        /// <param name="options">Salesforce synchronisation worker settings</param>
        /// <param name="timeProvider">Provider for UTC processing timestamps</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceSyncService(
            ILogger<SalesforceSyncService> logger,
            ISalesforceSyncDataService dataService,
            ISalesforceInvoiceMapper invoiceMapper,
            ISalesforceProductService productService,
            ISalesforceOrderService orderService,
            IOptions<SalesforceSyncOptions> options,
            TimeProvider timeProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _dataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
            _invoiceMapper = invoiceMapper ?? throw new ArgumentNullException(nameof(invoiceMapper));
            _productService = productService ?? throw new ArgumentNullException(nameof(productService));
            _orderService = orderService ?? throw new ArgumentNullException(nameof(orderService));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task RunAsync(string leaseOwner, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);
            ValidateOptions();

            for (var workItemNumber = 0; workItemNumber < _options.MaximumWorkItemsPerRun; workItemNumber++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var work = await _dataService.ClaimNextAsync(
                    leaseOwner,
                    _options.LeaseDurationSeconds,
                    _options.MaximumRetryCount,
                    GetUtcNow(),
                    cancellationToken);

                if (work is null)
                {
                    return;
                }

                try
                {
                    await ProcessWithLeaseRenewalAsync(work, cancellationToken);
                }
                catch (Exception exception) when (exception is not OperationCanceledException)
                {
                    _logger.LogError(
                        exception,
                        "Salesforce lease processing failed for work {SalesforceWorkId}",
                        work.Id);
                }
            }
        }

        private async Task ProcessWithLeaseRenewalAsync(
            ConsolidatedSalesforceWork work,
            CancellationToken cancellationToken)
        {
            using var processingCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            var processingTask = ProcessClaimedWorkAsync(work, processingCancellation.Token);
            var renewalTask = RenewLeaseUntilCancelledAsync(work, processingCancellation.Token);
            var renewalCompletedFirst = false;

            try
            {
                var firstCompletedTask = await Task.WhenAny(processingTask, renewalTask);
                if (firstCompletedTask == renewalTask)
                {
                    renewalCompletedFirst = true;
                    await renewalTask;
                }

                await processingTask;
            }
            finally
            {
                await processingCancellation.CancelAsync();

                try
                {
                    await renewalTask;
                }
                catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                {
                    // Expected after Salesforce processing completes or a lease renewal fails.
                }
                catch when (renewalCompletedFirst)
                {
                    // The renewal failure was already observed and must remain the primary exception.
                }

                if (!processingTask.IsCompleted)
                {
                    try
                    {
                        await processingTask;
                    }
                    catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                    {
                        // Processing must stop when its lease can no longer be renewed.
                    }
                }
            }
        }

        private async Task RenewLeaseUntilCancelledAsync(
            ConsolidatedSalesforceWork work,
            CancellationToken cancellationToken)
        {
            var claimToken = work.ClaimToken
                ?? throw new InvalidOperationException($"Claimed Salesforce work {work.Id} has no claim token");
            var renewalInterval = TimeSpan.FromSeconds(_options.LeaseRenewalIntervalSeconds);

            while (true)
            {
                await Task.Delay(renewalInterval, cancellationToken);
                await _dataService.RenewLeaseAsync(
                    work.Id,
                    claimToken,
                    _options.LeaseDurationSeconds,
                    GetUtcNow(),
                    cancellationToken);
            }
        }

        private async Task ProcessClaimedWorkAsync(ConsolidatedSalesforceWork work, CancellationToken cancellationToken)
        {
            if (!work.ClaimToken.HasValue)
            {
                throw new InvalidOperationException($"Claimed Salesforce work {work.Id} has no claim token.");
            }

            var claimToken = work.ClaimToken.Value;

            try
            {
                var details = await _dataService.GetDetailsAsync(work.Id, claimToken, cancellationToken)
                    ?? throw new InvalidOperationException($"Claimed Salesforce work {work.Id} has no canonical invoice details.");
                var projection = _invoiceMapper.Map(details.Invoice);

                await RenewLeaseAsync(work.Id, claimToken, cancellationToken);
                var orderResult = await ExecuteAuditedAsync(
                    work,
                    "UpsertDraftOrder",
                    projection.Order.InvoiceNumber,
                    projection.Order,
                    token => _orderService.UpsertDraftOrderAsync(projection.Order, token),
                    cancellationToken);

                await RenewLeaseAsync(work.Id, claimToken, cancellationToken);
                var prerequisites = await ExecuteAuditedAsync(
                    work,
                    "EnsureProducts",
                    projection.Order.InvoiceNumber,
                    projection.RequiredProductCodes,
                    token => _productService.EnsureProductsAsync(projection.RequiredProductCodes, token),
                    cancellationToken);

                foreach (var item in projection.Items)
                {
                    var lineState = details.Lines.SingleOrDefault(line =>
                        string.Equals(line.SalesforceExternalId, item.ExternalId, StringComparison.Ordinal))
                        ?? throw new InvalidOperationException($"Salesforce line state was not found for {item.ExternalId}.");

                    if (string.Equals(lineState.SalesforceLineStatus, CompletedLineStatus, StringComparison.Ordinal))
                    {
                        continue;
                    }

                    if (!prerequisites.TryGetValue(item.ProductCode, out var prerequisite))
                    {
                        throw new InvalidOperationException($"Salesforce product prerequisites were not resolved for {item.ProductCode}.");
                    }

                    await RenewLeaseAsync(work.Id, claimToken, cancellationToken);

                    try
                    {
                        var itemResult = await ExecuteAuditedAsync(
                            work,
                            "UpsertOrderItem",
                            item.ExternalId,
                            item,
                            token => _orderService.UpsertOrderItemAsync(item, token),
                            cancellationToken);

                        await _dataService.CompleteLineAsync(
                            work.Id,
                            claimToken,
                            item.ExternalId,
                            prerequisite.ProductId,
                            prerequisite.PricebookEntryId,
                            itemResult.Id!,
                            GetUtcNow(),
                            cancellationToken);
                    }
                    catch (Exception exception) when (exception is not OperationCanceledException)
                    {
                        await _dataService.FailLineAsync(
                            work.Id,
                            claimToken,
                            item.ExternalId,
                            TruncateErrorMessage(exception.Message),
                            GetUtcNow(),
                            cancellationToken);
                        throw;
                    }
                }

                await RenewLeaseAsync(work.Id, claimToken, cancellationToken);
                var finalisation = await ExecuteAuditedAsync(
                    work,
                    "FinaliseOrder",
                    projection.Order.InvoiceNumber,
                    new { projection.Order.InvoiceNumber, projection.Order.ExpectedLineCount },
                    token => _orderService.FinaliseOrderAsync(
                        projection.Order.InvoiceNumber,
                        projection.Order.ExpectedLineCount,
                        token),
                    cancellationToken);

                if (!finalisation.Activated)
                {
                    throw new SalesforceOrderIncompleteException(
                        projection.Order.InvoiceNumber,
                        finalisation.ExpectedLineCount,
                        finalisation.ActualLineCount);
                }

                await _dataService.CompleteWorkAsync(
                    work.Id,
                    claimToken,
                    orderResult.Id!,
                    finalisation.ActualLineCount,
                    GetUtcNow(),
                    cancellationToken);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                await _dataService.FailWorkAsync(
                    work.Id,
                    claimToken,
                    ClassifyFailure(exception),
                    TruncateErrorMessage(exception.Message),
                    GetUtcNow().AddSeconds(_options.RetryDelaySeconds),
                    _options.MaximumRetryCount,
                    GetUtcNow(),
                    cancellationToken);

                _logger.LogError(
                    exception,
                    "Salesforce synchronisation failed for work {SalesforceWorkId} and invoice {InvoiceNumber}",
                    work.Id,
                    work.ConsolidatedInvoiceNumber);
            }
        }

        private async Task<T> ExecuteAuditedAsync<T>(
            ConsolidatedSalesforceWork work,
            string operation,
            string? entityKey,
            object request,
            Func<CancellationToken, Task<T>> action,
            CancellationToken cancellationToken)
        {
            var startedOn = GetUtcNow();

            try
            {
                var result = await action(cancellationToken);
                await InsertAttemptAsync(work, operation, entityKey, request, result, null, startedOn, cancellationToken);
                return result;
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                await InsertAttemptAsync(work, operation, entityKey, request, null, exception, startedOn, cancellationToken);
                throw;
            }
        }

        private Task InsertAttemptAsync(
            ConsolidatedSalesforceWork work,
            string operation,
            string? entityKey,
            object request,
            object? response,
            Exception? exception,
            DateTimeOffset startedOn,
            CancellationToken cancellationToken)
        {
            return _dataService.InsertAttemptAsync(
                new ConsolidatedSalesforceAttempt
                {
                    SalesforceWorkId = work.Id,
                    CorrelationId = work.CorrelationId,
                    Operation = operation,
                    EntityKey = entityKey,
                    AttemptNumber = work.AttemptCount,
                    Outcome = exception is null ? "Succeeded" : "Failed",
                    HttpStatusCode = exception is SalesforceApiException apiException ? (int)apiException.StatusCode : null,
                    RequestPayload = JsonSerializer.Serialize(request),
                    ResponsePayload = response is null ? null : JsonSerializer.Serialize(response),
                    ErrorCategory = exception is null ? null : ClassifyFailure(exception),
                    ErrorMessage = exception is null ? null : TruncateErrorMessage(exception.Message),
                    StartedOn = startedOn,
                    CompletedOn = GetUtcNow()
                },
                cancellationToken);
        }

        private Task RenewLeaseAsync(Guid workId, Guid claimToken, CancellationToken cancellationToken)
        {
            return _dataService.RenewLeaseAsync(
                workId,
                claimToken,
                _options.LeaseDurationSeconds,
                GetUtcNow(),
                cancellationToken);
        }

        private void ValidateOptions()
        {
            if (_options.MaximumWorkItemsPerRun <= 0)
            {
                throw new InvalidOperationException("The Salesforce maximum work items per run must be greater than zero.");
            }

            if (_options.LeaseDurationSeconds <= 0)
            {
                throw new InvalidOperationException("The Salesforce lease duration must be greater than zero.");
            }

            if (_options.LeaseRenewalIntervalSeconds <= 0)
            {
                throw new InvalidOperationException("The Salesforce lease renewal interval must be greater than zero");
            }

            if (_options.LeaseRenewalIntervalSeconds >= _options.LeaseDurationSeconds)
            {
                throw new InvalidOperationException("The Salesforce lease renewal interval must be shorter than the lease duration");
            }

            if (_options.RetryDelaySeconds <= 0)
            {
                throw new InvalidOperationException("The Salesforce retry delay must be greater than zero.");
            }

            if (_options.MaximumRetryCount <= 0)
            {
                throw new InvalidOperationException("The Salesforce maximum retry count must be greater than zero.");
            }
        }

        private static string ClassifyFailure(Exception exception)
        {
            if (exception is SalesforceOrderIncompleteException)
            {
                return "LineCountMismatch";
            }

            if (exception is SalesforceApiException apiException)
            {
                return apiException.StatusCode is HttpStatusCode.RequestTimeout
                    or HttpStatusCode.TooManyRequests
                    or >= HttpStatusCode.InternalServerError
                    ? "TransientSalesforce"
                    : "SalesforceRejected";
            }

            if (exception is HttpRequestException or TimeoutException)
            {
                return "TransientHttp";
            }

            if (exception is InvalidOperationException or ArgumentException)
            {
                return "InvalidDataOrConfiguration";
            }

            return "Unexpected";
        }

        private DateTimeOffset GetUtcNow()
        {
            return _timeProvider.GetUtcNow();
        }

        private static string TruncateErrorMessage(string errorMessage)
        {
            return errorMessage.Length <= MaximumErrorMessageLength
                ? errorMessage
                : errorMessage[..MaximumErrorMessageLength];
        }
    }
}
