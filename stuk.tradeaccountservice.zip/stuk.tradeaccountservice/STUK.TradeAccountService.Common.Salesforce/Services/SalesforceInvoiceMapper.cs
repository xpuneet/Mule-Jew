using System.Globalization;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Maps canonical consolidated invoices into Salesforce projections
    /// </summary>
    public class SalesforceInvoiceMapper : ISalesforceInvoiceMapper
    {
        private const string DraftStatus = "Draft";
        private const string InvoiceOrderType = "Invoice";
        private const string TextProductCode = "TEXT";
        private const int JobPostcodeMaxLength = 8;
        private const decimal SalesforceLineNumberMaximum = 99999m;

        /// <inheritdoc />
        public SalesforceInvoiceProjection Map(ConsolidatedSalesInvoice source)
        {
            ArgumentNullException.ThrowIfNull(source);

            var invoiceNumber = RequiredValue(source.ConsolidatedInvoiceNumber, "The consolidated invoice number is required for Salesforce mapping.");

            var accountExternalId = RequiredValue(source.CustomerAccountCode, "The customer account code is required for Salesforce mapping.");

            var items = source.Lines
                .Select(line => MapItem(line, invoiceNumber))
                .ToList();

            return new SalesforceInvoiceProjection
            {
                Order = MapOrder(source, invoiceNumber, accountExternalId),
                Items = items,
                RequiredProductCodes = items
                    .Select(item => item.ProductCode)
                    .Distinct(StringComparer.Ordinal)
                    .ToList()
            };
        }

        private static SalesforceOrderProjection MapOrder(ConsolidatedSalesInvoice source, string invoiceNumber, string accountExternalId)
        {
            return new SalesforceOrderProjection
            {
                AccountExternalId = accountExternalId,
                InvoiceNumber = invoiceNumber,
                Status = DraftStatus,
                OrderType = InvoiceOrderType,
                EffectiveDate = source.InvoiceDate,
                InvoiceDate = source.InvoiceDate,
                TaxPointDate = source.TaxPointDate,
                CreditTerms = source.CreditTermsDescription,
                TaxableTotal = source.TaxableTotal,
                TaxTotal = source.TaxTotal,
                GrossPaymentTotal = source.GrossPaymentTotal,
                ExpectedLineCount = source.ExpectedLineCount
            };
        }

        private static SalesforceOrderItemProjection MapItem(ConsolidatedSalesInvoiceLine source, string invoiceNumber)
        {
            var externalId = RequiredValue(source.SalesforceExternalId, $"The Salesforce external identifier is required for invoice {invoiceNumber}.");

            var productCode = source.IsTextLine ? TextProductCode : RequiredValue(source.ProductCode, $"The product code is required for Salesforce line {externalId}.");
            var isSpecialProduct = source.IsSpecialProduct
                ?? throw new InvalidOperationException($"The special product indicator is required for Salesforce line {externalId}.");

            return new SalesforceOrderItemProjection
            {
                ExternalId = externalId,
                InvoiceNumber = invoiceNumber,
                ProductCode = productCode,
                LineNumber = source.SourceLineNumber,
                OrderLineNumber = ParseOptionalLineNumber(source.OrderLineNumber, "order line number", externalId),
                OriginalOrderLineNumber = ParseOptionalLineNumber(source.OriginalOrderLineNumber, "original order line item number", externalId),
                DeliveryNoteNumber = source.DeliveryNoteNumber,
                DeliveryNoteLineNumber = ParseOptionalLineNumber(source.DeliveryNoteLineNumber, "delivery note line number", externalId),
                BuyersOrderNumber = source.BuyersOrderNumber,
                OrderReference = source.SuppliersOrderReference,
                DespatchDate = source.SupplierDespatchDate,
                CodeForDelivery = source.SupplierCodeForDelivery,
                OrderType = source.OrderTypeDescription,
                OrderCategory = source.OrderCategoryDescription,
                DeliveryMethod = source.DeliveryMethodDescription,
                PartAnalysisCode = source.SupplierPartAnalysisCode,
                IsSpecialProduct = isSpecialProduct,
                Description = RemoveCommas(source.ProductDescription),
                Quantity = source.IsTextLine ? 1m : source.Quantity,
                QuantityUomCode = source.QuantityUomCode,
                QuantityUomDescription = source.QuantityUomDescription,
                UnitPrice = source.IsTextLine ? 0m : source.UnitPrice,
                PriceUomCode = source.PriceUomCode,
                PriceUomDescription = source.PriceUomDescription,
                PercentageDiscount = source.PercentageDiscount,
                TaxRateCode = source.TaxRateCode,
                TaxRate = source.TaxRate,
                TaxValue = source.TaxValue,
                OrderProductTotal = source.LineTotal,
                JobNumber = source.JobNumber,
                JobAddressLine = source.JobAddressLine1,
                JobStreet = source.JobStreet,
                JobCity = source.JobCity,
                JobState = source.JobState,
                JobPostcode = Truncate(source.JobPostcode, JobPostcodeMaxLength),
                ContractNumber = source.ContractNumber,
                BuyerLocationCode = source.BuyerLocation,
                Operative = source.Operative,
                SiteCode = source.SiteCode,
                PlotNumber = source.PlotNumber,
                VehicleRegistration = source.VehicleRegistration,
                HouseType = source.HouseType,
                ProductGroup = source.ProductGroup,
                OrderAuthorised = string.Equals(source.OrderAuthorised, "Yes", StringComparison.Ordinal)
            };
        }

        private static string? RemoveCommas(string? value)
        {
            return value?.Replace(",", string.Empty, StringComparison.Ordinal);
        }

        private static string? Truncate(string? value, int maximumLength)
        {
            return value?.Length > maximumLength
                ? value[..maximumLength]
                : value;
        }

        private static decimal? ParseOptionalLineNumber(string? value, string fieldName, string externalId)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            if (!decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out var result)
                || result > SalesforceLineNumberMaximum)
            {
                throw new InvalidOperationException(
                    $"The {fieldName} for Salesforce line {externalId} must be a number no greater than {SalesforceLineNumberMaximum}.");
            }

            return result;
        }

        private static string RequiredValue(string? value, string message)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidOperationException(message);
            }

            return value;
        }
    }
}
