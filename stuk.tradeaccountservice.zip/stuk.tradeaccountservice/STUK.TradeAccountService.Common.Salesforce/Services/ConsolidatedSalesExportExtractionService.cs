using Microsoft.Extensions.Logging;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Exceptions;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Salesforce.Services
{
    /// <summary>
    /// Streams the legacy ConsXref SOQL result into a complete durable export snapshot
    /// </summary>
    public class ConsolidatedSalesExportExtractionService : IConsolidatedSalesExportExtractionService
    {
        private const string LegacySelect = "SELECT Order.Account.Account_Number__c, Order.Invoice_Number__c, Order.Invoice_Date__c, Delivery_Note_Number__c, Delivery_Note_Line_Number__c, Despatch_Date__c, Product2.productCode, Quantity, Order_Product_Total__c FROM OrderItem WHERE Order.Invoice_Date__c >= ";

        private static readonly JsonSerializerOptions SnapshotJsonOptions = new()
        {
            PropertyNamingPolicy = null
        };

        private readonly ISalesforceApiClient _salesforceApiClient;
        private readonly ILogger<ConsolidatedSalesExportExtractionService> _logger;
        private readonly ISalesforceConsXrefRowMapper _rowMapper;
        private readonly IConsolidatedSalesExportDataService _exportDataService;
        private readonly ISalesforceExportRetryPolicy _retryPolicy;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesExportExtractionService"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="salesforceApiClient">The direct Salesforce REST client</param>
        /// <param name="rowMapper">The Salesforce ConsXref row mapper</param>
        /// <param name="exportDataService">The durable export persistence service</param>
        /// <param name="retryPolicy">The durable extraction failure and retry policy</param>
        /// <param name="timeProvider">The processing clock</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public ConsolidatedSalesExportExtractionService(
            ILogger<ConsolidatedSalesExportExtractionService> logger,
            ISalesforceApiClient salesforceApiClient,
            ISalesforceConsXrefRowMapper rowMapper,
            IConsolidatedSalesExportDataService exportDataService,
            ISalesforceExportRetryPolicy retryPolicy,
            TimeProvider timeProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _salesforceApiClient = salesforceApiClient ?? throw new ArgumentNullException(nameof(salesforceApiClient));
            _rowMapper = rowMapper ?? throw new ArgumentNullException(nameof(rowMapper));
            _exportDataService = exportDataService ?? throw new ArgumentNullException(nameof(exportDataService));
            _retryPolicy = retryPolicy ?? throw new ArgumentNullException(nameof(retryPolicy));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportExtractionResult> ExtractAsync(
            ConsolidatedSalesExportRun exportRun,
            CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(exportRun);

            if (!string.Equals(exportRun.Status, "Extracting", StringComparison.Ordinal)
                || exportRun.ClaimToken is null)
            {
                throw new InvalidOperationException("The export run must be claimed for extraction.");
            }

            cancellationToken.ThrowIfCancellationRequested();
            var claimToken = exportRun.ClaimToken.Value;

            _logger.LogInformation(
                "Consolidated Sales Salesforce extraction started for export {ExportRunId}, correlation {CorrelationId}, logical run {LogicalRunKey} and attempt {AttemptCount}",
                exportRun.Id,
                exportRun.CorrelationId,
                exportRun.LogicalRunKey,
                exportRun.ExtractionAttemptCount);

            try
            {
                return await ExtractSnapshotAsync(exportRun, claimToken, cancellationToken);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception exception) when (_retryPolicy.CanHandle(exception))
            {
                var isTransient = _retryPolicy.IsTransient(exception);
                DateTimeOffset? nextAttemptOn = isTransient
                    ? _retryPolicy.CalculateNextAttemptOn(exportRun.ExtractionAttemptCount)
                    : null;
                var errorMessage = exception.Message.Length <= 2000
                    ? exception.Message
                    : exception.Message[..2000];

                await _exportDataService.FailExtractionAsync(
                    exportRun.Id,
                    claimToken,
                    _retryPolicy.GetCategory(exception),
                    errorMessage,
                    isTransient,
                    nextAttemptOn,
                    _retryPolicy.MaximumAttemptCount,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                _logger.LogError(
                    exception,
                    "Consolidated Sales Salesforce extraction failed for export {ExportRunId}, correlation {CorrelationId}, category {ErrorCategory}, transient {IsTransient} and next attempt {NextAttemptOn}",
                    exportRun.Id,
                    exportRun.CorrelationId,
                    _retryPolicy.GetCategory(exception),
                    isTransient,
                    nextAttemptOn);

                throw;
            }
        }

        private async Task<ConsolidatedSalesExportExtractionResult> ExtractSnapshotAsync(
            ConsolidatedSalesExportRun exportRun,
            Guid claimToken,
            CancellationToken cancellationToken)
        {

            var startedOn = _timeProvider.GetUtcNow();
            var soql = BuildSoql(exportRun.ExtractFromDate);
            var queryHash = SHA256.HashData(Encoding.UTF8.GetBytes(soql));
            var pageNumber = 0;
            long rowCount = 0;
            int? expectedTotalSize = null;

            await foreach (var page in _salesforceApiClient.QueryPagesAsync<SalesforceConsXrefOrderItem>(
                soql,
                cancellationToken))
            {
                cancellationToken.ThrowIfCancellationRequested();
                pageNumber++;

                if (expectedTotalSize is null)
                {
                    expectedTotalSize = page.TotalSize;
                }
                else if (expectedTotalSize.Value != page.TotalSize)
                {
                    throw new SalesforceQueryResponseException("Salesforce changed the total result size between query pages.");
                }

                var mappedRows = page.Records.Select(_rowMapper.Map).ToArray();
                var rowsJson = JsonSerializer.Serialize(mappedRows, SnapshotJsonOptions);
                var pageHash = SHA256.HashData(Encoding.UTF8.GetBytes(rowsJson));

                try
                {
                    await _exportDataService.AppendPageAsync(
                        exportRun.Id,
                        claimToken,
                        pageNumber,
                        rowCount + 1,
                        pageHash,
                        !page.Done,
                        rowsJson,
                        _timeProvider.GetUtcNow(),
                        cancellationToken);
                }
                catch (Exception exception) when (exception is not OperationCanceledException)
                {
                    _logger.LogError(
                        exception,
                        "Consolidated Sales SQL snapshot persistence failed for export {ExportRunId}, correlation {CorrelationId} and page {PageNumber}",
                        exportRun.Id,
                        exportRun.CorrelationId,
                        pageNumber);
                    throw;
                }

                rowCount += mappedRows.LongLength;

                _logger.LogInformation(
                    "Consolidated Sales Salesforce page {PageNumber} persisted for export {ExportRunId}, correlation {CorrelationId}; snapshot row count is {RowCount}",
                    pageNumber,
                    exportRun.Id,
                    exportRun.CorrelationId,
                    rowCount);
            }

            if (pageNumber == 0 || expectedTotalSize is null)
            {
                throw new SalesforceQueryResponseException("Salesforce returned no query page.");
            }

            if (rowCount != expectedTotalSize.Value)
            {
                throw new SalesforceQueryResponseException($"Salesforce reported {expectedTotalSize.Value.ToString(CultureInfo.InvariantCulture)} records but returned {rowCount.ToString(CultureInfo.InvariantCulture)}.");
            }

            var completedOn = _timeProvider.GetUtcNow();

            try
            {
                await _exportDataService.CompleteExtractionAsync(
                    exportRun.Id,
                    claimToken,
                    pageNumber,
                    rowCount,
                    queryHash,
                    completedOn,
                    cancellationToken);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                _logger.LogError(
                    exception,
                    "Consolidated Sales SQL snapshot completion failed for export {ExportRunId} and correlation {CorrelationId}",
                    exportRun.Id,
                    exportRun.CorrelationId);
                throw;
            }

            _logger.LogInformation(
                "Consolidated Sales Salesforce extraction completed for export {ExportRunId}, correlation {CorrelationId}, with {PageCount} pages and {RowCount} rows in {DurationMs} ms",
                exportRun.Id,
                exportRun.CorrelationId,
                pageNumber,
                rowCount,
                (completedOn - startedOn).TotalMilliseconds);

            return new ConsolidatedSalesExportExtractionResult
            {
                ExportRunId = exportRun.Id,
                CorrelationId = exportRun.CorrelationId,
                PageCount = pageNumber,
                RowCount = rowCount,
                Duration = completedOn - startedOn
            };
        }

        private static string BuildSoql(DateOnly extractFromDate)
        {
            return LegacySelect + extractFromDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }
    }
}
