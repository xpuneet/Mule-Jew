namespace STUK.TradeAccountService.Common.Salesforce.Config
{
    /// <summary>
    /// Defines the fixed weekly schedule used to preserve the legacy Consolidated Sales export contract
    /// </summary>
    public static class ConsolidatedSalesExportSchedule
    {
        /// <summary>
        /// Gets the local scheduled hour
        /// </summary>
        public const int ScheduledHour = 0;

        /// <summary>
        /// Gets the local scheduled minute
        /// </summary>
        public const int ScheduledMinute = 30;

        /// <summary>
        /// Gets the time zone used to derive the weekly logical run
        /// </summary>
        public const string TimeZoneId = "Europe/London";
    }
}
