namespace STUK.TradeAccountService.Common.Salesforce.Config
{
    /// <summary>
    /// Provides bounded worker and durable retry settings for Salesforce synchronisation
    /// </summary>
    public class SalesforceSyncOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "ConsolidatedSales:SalesforceSync";

        /// <summary>
        /// Gets or sets the maximum work items claimed during one Function invocation
        /// </summary>
        public int MaximumWorkItemsPerRun { get; set; } = 1;

        /// <summary>
        /// Gets or sets the duration of each SQL processing lease in seconds
        /// </summary>
        public int LeaseDurationSeconds { get; set; } = 240;

        /// <summary>
        /// Gets or sets how frequently the active SQL lease is renewed in seconds
        /// </summary>
        public int LeaseRenewalIntervalSeconds { get; set; } = 60;

        /// <summary>
        /// Gets or sets the delay before failed work becomes eligible for another attempt
        /// </summary>
        public int RetryDelaySeconds { get; set; } = 2;

        /// <summary>
        /// Gets or sets the maximum durable Salesforce work attempts
        /// </summary>
        public int MaximumRetryCount { get; set; } = 2;
    }
}
