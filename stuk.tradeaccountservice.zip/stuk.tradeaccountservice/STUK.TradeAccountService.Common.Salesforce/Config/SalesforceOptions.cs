namespace STUK.TradeAccountService.Common.Salesforce.Config
{
    /// <summary>
    /// Provides the runtime settings for Salesforce authentication and REST API access
    /// </summary>
    public class SalesforceOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "Salesforce";

        /// <summary>
        /// Gets or sets the Salesforce OAuth token endpoint
        /// </summary>
        public string TokenEndpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce audience used in the signed JWT assertion
        /// </summary>
        public string Audience { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the External Client App consumer key
        /// </summary>
        public string ClientId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the dedicated Salesforce integration username
        /// </summary>
        public string Username { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Base64-encoded PKCS12 certificate supplied through secure configuration
        /// </summary>
        public string SigningCertificateBase64 { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the optional password for the signing certificate
        /// </summary>
        public string? SigningCertificatePassword { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce REST API version including its leading v
        /// </summary>
        public string ApiVersion { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce Pricebook identifier used for Consolidated Sales
        /// </summary>
        public string PricebookId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the timeout applied to Salesforce HTTP requests in seconds
        /// </summary>
        public int RequestTimeoutSeconds { get; set; } = 60;
    }
}
