using System.Security.Cryptography.X509Certificates;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Provides the private-key certificate used to sign Salesforce JWT assertions
    /// </summary>
    public interface ISalesforceSigningCertificateProvider
    {
        /// <summary>
        /// Gets the configured Salesforce JWT signing certificate
        /// </summary>
        /// <returns>The certificate containing the private signing key</returns>
        /// <exception cref="InvalidOperationException">Thrown when the configured certificate is missing or invalid</exception>
        X509Certificate2 GetCertificate();
    }
}
