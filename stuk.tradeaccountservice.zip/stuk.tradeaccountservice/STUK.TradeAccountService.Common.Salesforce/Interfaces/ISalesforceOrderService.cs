using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Provides the Salesforce Order and OrderItem operations used by Consolidated Sales synchronisation
    /// </summary>
    public interface ISalesforceOrderService
    {
        /// <summary>
        /// Creates or updates a Salesforce Order in Draft status using the consolidated invoice number
        /// </summary>
        /// <param name="order">The mapped Salesforce Order values</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>The result of the Salesforce Order upsert</returns>
        /// <exception cref="ArgumentNullException">Thrown when the order is null</exception>
        /// <exception cref="InvalidOperationException">Thrown when required Order configuration or identity values are missing</exception>
        /// <exception cref="SalesforceApiException">Thrown when Salesforce rejects the request</exception>
        Task<SalesforceUpsertResult> UpsertDraftOrderAsync(
            SalesforceOrderProjection order,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Creates or updates a Salesforce OrderItem using its deterministic external identifier
        /// </summary>
        /// <param name="orderItem">The mapped Salesforce OrderItem values</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>The result of the Salesforce OrderItem upsert</returns>
        /// <exception cref="ArgumentNullException">Thrown when the order item is null</exception>
        /// <exception cref="InvalidOperationException">Thrown when required OrderItem identity values are missing</exception>
        /// <exception cref="SalesforceApiException">Thrown when Salesforce rejects the request</exception>
        Task<SalesforceUpsertResult> UpsertOrderItemAsync(
            SalesforceOrderItemProjection orderItem,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Activates a Salesforce Order only when its persisted OrderItem count equals the canonical expected count
        /// </summary>
        /// <param name="invoiceNumber">The consolidated invoice number</param>
        /// <param name="expectedLineCount">The canonical number of invoice lines required before activation</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>The Order finalisation result including the expected and actual line counts</returns>
        /// <exception cref="ArgumentException">Thrown when the consolidated invoice number is empty</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the expected line count is not positive</exception>
        /// <exception cref="SalesforceApiException">Thrown when Salesforce rejects the request</exception>
        Task<SalesforceOrderFinalisationResult> FinaliseOrderAsync(
            string invoiceNumber,
            int expectedLineCount,
            CancellationToken cancellationToken = default);
    }
}
