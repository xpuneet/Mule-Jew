namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Classifies durable Salesforce extraction failures and calculates their next attempt
    /// </summary>
    public interface ISalesforceExportRetryPolicy
    {
        /// <summary>
        /// Gets the maximum number of durable extraction attempts
        /// </summary>
        int MaximumAttemptCount { get; }

        /// <summary>
        /// Determines whether the exception belongs to the Salesforce extraction boundary
        /// </summary>
        /// <param name="exception">The extraction exception</param>
        /// <returns>True when the failure should be persisted by the extraction workflow</returns>
        bool CanHandle(Exception exception);

        /// <summary>
        /// Determines whether the failure may succeed on a later attempt
        /// </summary>
        /// <param name="exception">The extraction exception</param>
        /// <returns>True for a transient failure; otherwise false</returns>
        bool IsTransient(Exception exception);

        /// <summary>
        /// Gets the operational category persisted for the failure
        /// </summary>
        /// <param name="exception">The extraction exception</param>
        /// <returns>A stable failure category</returns>
        string GetCategory(Exception exception);

        /// <summary>
        /// Calculates the UTC time for the next durable extraction attempt
        /// </summary>
        /// <param name="attemptNumber">The attempt that has just failed</param>
        /// <returns>The next eligible attempt time</returns>
        DateTimeOffset CalculateNextAttemptOn(int attemptNumber);
    }
}
