namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Coordinates bounded delivery of committed Consolidated Sales invoices to Salesforce
    /// </summary>
    public interface ISalesforceSyncService
    {
        /// <summary>
        /// Claims and processes the configured maximum number of eligible Salesforce work items
        /// </summary>
        /// <param name="leaseOwner">The Function invocation identifier owning each SQL lease</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        /// <exception cref="ArgumentException">Thrown when the lease owner is empty</exception>
        /// <exception cref="InvalidOperationException">Thrown when required worker configuration is invalid</exception>
        Task RunAsync(string leaseOwner, CancellationToken cancellationToken = default);
    }
}
