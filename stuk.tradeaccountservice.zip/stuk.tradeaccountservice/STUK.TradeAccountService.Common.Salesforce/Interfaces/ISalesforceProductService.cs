using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Ensures the Salesforce product and pricebook prerequisites required by invoice lines
    /// </summary>
    public interface ISalesforceProductService
    {
        /// <summary>
        /// Ensures every supplied product code has an active Product2 and PricebookEntry
        /// </summary>
        /// <param name="productCodes">Distinct product external identifiers required by an invoice</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>The resolved Salesforce identifiers keyed by product external identifier</returns>
        /// <exception cref="ArgumentNullException">Thrown when product codes are not supplied</exception>
        /// <exception cref="ArgumentException">Thrown when a product code is empty</exception>
        /// <exception cref="InvalidOperationException">Thrown when the Salesforce pricebook is not configured</exception>
        Task<IReadOnlyDictionary<string, SalesforceProductPrerequisite>> EnsureProductsAsync(
            IReadOnlyCollection<string> productCodes,
            CancellationToken cancellationToken = default);
    }
}
