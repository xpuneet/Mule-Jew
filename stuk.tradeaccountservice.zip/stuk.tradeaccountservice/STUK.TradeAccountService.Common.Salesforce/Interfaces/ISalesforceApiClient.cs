using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Provides the official Salesforce REST operations required by Consolidated Sales synchronisation
    /// </summary>
    public interface ISalesforceApiClient
    {
        /// <summary>
        /// Executes a SOQL query and streams each Salesforce result page in order
        /// </summary>
        /// <typeparam name="TRecord">The Salesforce response record type</typeparam>
        /// <param name="soql">The complete SOQL query</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>The ordered Salesforce result pages</returns>
        /// <exception cref="ArgumentException">Thrown when the SOQL query is empty</exception>
        /// <exception cref="SalesforceApiException">Thrown when Salesforce rejects the request</exception>
        IAsyncEnumerable<SalesforceQueryResult<TRecord>> QueryPagesAsync<TRecord>(
            string soql,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Executes a SOQL query and follows all Salesforce result pages
        /// </summary>
        /// <typeparam name="TRecord">The Salesforce response record type</typeparam>
        /// <param name="soql">The complete SOQL query</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>All records returned by Salesforce</returns>
        /// <exception cref="ArgumentException">Thrown when the SOQL query is empty</exception>
        /// <exception cref="SalesforceApiException">Thrown when Salesforce rejects the request</exception>
        Task<IReadOnlyList<TRecord>> QueryAllAsync<TRecord>(
            string soql,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Creates or updates a Salesforce object using an external identifier
        /// </summary>
        /// <typeparam name="TRequest">The Salesforce request payload type</typeparam>
        /// <param name="objectName">The Salesforce object API name</param>
        /// <param name="externalIdField">The external-id field API name</param>
        /// <param name="externalIdValue">The external-id value</param>
        /// <param name="request">The object values to create or update</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>The result of the Salesforce upsert</returns>
        /// <exception cref="ArgumentException">Thrown when an object identity value is empty</exception>
        /// <exception cref="ArgumentNullException">Thrown when the request is null</exception>
        /// <exception cref="SalesforceApiException">Thrown when Salesforce rejects the request</exception>
        Task<SalesforceUpsertResult> UpsertAsync<TRequest>(
            string objectName,
            string externalIdField,
            string externalIdValue,
            TRequest request,
            CancellationToken cancellationToken = default);
    }
}
