using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Maps the legacy Salesforce OrderItem query shape into one durable ConsXref row
    /// </summary>
    public interface ISalesforceConsXrefRowMapper
    {
        /// <summary>
        /// Maps one Salesforce OrderItem result into the durable export row contract
        /// </summary>
        /// <param name="source">The Salesforce OrderItem query result</param>
        /// <returns>The mapped export row without its run-level sequence</returns>
        /// <exception cref="ArgumentNullException">Thrown when the source row is not supplied</exception>
        ConsolidatedSalesExportRow Map(SalesforceConsXrefOrderItem source);
    }
}
