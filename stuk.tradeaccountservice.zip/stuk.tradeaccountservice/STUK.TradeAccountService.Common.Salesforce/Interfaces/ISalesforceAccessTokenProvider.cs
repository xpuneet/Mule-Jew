using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Exchanges a signed External Client App JWT assertion for a Salesforce access token
    /// </summary>
    public interface ISalesforceAccessTokenProvider
    {
        /// <summary>
        /// Gets a Salesforce access token using the OAuth 2.0 JWT bearer flow
        /// </summary>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>The access token and Salesforce instance URL</returns>
        /// <exception cref="InvalidOperationException">Thrown when required authentication configuration is missing</exception>
        /// <exception cref="SalesforceApiException">Thrown when Salesforce rejects the token request</exception>
        Task<SalesforceAccessToken> GetAccessTokenAsync(CancellationToken cancellationToken = default);
    }
}
