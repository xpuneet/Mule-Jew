using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Extracts and durably stages the complete legacy ConsXref dataset from Salesforce
    /// </summary>
    public interface IConsolidatedSalesExportExtractionService
    {
        /// <summary>
        /// Executes the legacy current-year SOQL query for a claimed export run
        /// </summary>
        /// <param name="exportRun">The claimed durable export run</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The completed extraction counts and timing</returns>
        /// <exception cref="ArgumentNullException">Thrown when the export run is not supplied</exception>
        /// <exception cref="InvalidOperationException">Thrown when the run is not claimed or Salesforce returns inconsistent paging metadata</exception>
        Task<ConsolidatedSalesExportExtractionResult> ExtractAsync(
            ConsolidatedSalesExportRun exportRun,
            CancellationToken cancellationToken = default);
    }
}
