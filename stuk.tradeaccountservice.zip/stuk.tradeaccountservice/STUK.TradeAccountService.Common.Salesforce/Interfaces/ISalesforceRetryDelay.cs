using System.Net.Http.Headers;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Calculates and waits for bounded Salesforce SOQL retry delays
    /// </summary>
    public interface ISalesforceRetryDelay
    {
        /// <summary>
        /// Calculates a retry delay using Retry-After or exponential backoff with jitter
        /// </summary>
        /// <param name="retryNumber">The one-based retry number</param>
        /// <param name="retryAfter">The optional Salesforce Retry-After header</param>
        /// <returns>The delay before the next request</returns>
        TimeSpan Calculate(int retryNumber, RetryConditionHeaderValue? retryAfter);

        /// <summary>
        /// Asynchronously waits for a calculated retry delay
        /// </summary>
        /// <param name="delay">The delay before the next request</param>
        /// <param name="cancellationToken">A token used to cancel the wait</param>
        Task WaitAsync(TimeSpan delay, CancellationToken cancellationToken);
    }
}
