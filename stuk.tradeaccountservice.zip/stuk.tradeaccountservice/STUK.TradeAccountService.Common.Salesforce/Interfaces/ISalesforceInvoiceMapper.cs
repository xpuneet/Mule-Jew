using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Models;

namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Maps a canonical consolidated invoice into the data required for Salesforce synchronisation
    /// </summary>
    public interface ISalesforceInvoiceMapper
    {
        /// <summary>
        /// Maps a canonical consolidated invoice into its Salesforce Order and OrderItem projection
        /// </summary>
        /// <param name="source">The committed canonical consolidated invoice</param>
        /// <returns>The data required to synchronise the invoice with Salesforce</returns>
        /// <exception cref="ArgumentNullException">Thrown when the source invoice is null</exception>
        /// <exception cref="InvalidOperationException">Thrown when a required business identity is missing</exception>
        SalesforceInvoiceProjection Map(ConsolidatedSalesInvoice source);
    }
}
