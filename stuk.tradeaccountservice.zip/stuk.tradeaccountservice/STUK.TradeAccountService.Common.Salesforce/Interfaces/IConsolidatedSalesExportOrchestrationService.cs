namespace STUK.TradeAccountService.Common.Salesforce.Interfaces
{
    /// <summary>
    /// Coordinates scheduled and replayed Consolidated Sales export work
    /// </summary>
    public interface IConsolidatedSalesExportOrchestrationService
    {
        /// <summary>
        /// Registers the current weekly logical run and processes eligible Salesforce extraction work
        /// </summary>
        /// <param name="leaseOwner">The Function invocation identifier owning each SQL lease</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        /// <exception cref="ArgumentException">Thrown when the lease owner is empty</exception>
        /// <exception cref="InvalidOperationException">Thrown when required worker configuration is invalid</exception>
        Task RunAsync(string leaseOwner, CancellationToken cancellationToken = default);

        /// <summary>
        /// Processes eligible extraction and destination recovery work without registering a new weekly run
        /// </summary>
        /// <param name="leaseOwner">The worker identity used for extraction and destination leases</param>
        /// <param name="cancellationToken">Token used to cancel processing</param>
        /// <returns>A task representing the asynchronous operation</returns>
        /// <exception cref="ArgumentException">Thrown when the lease owner is empty</exception>
        Task RunRecoveryAsync(string leaseOwner, CancellationToken cancellationToken = default);

        /// <summary>
        /// Processes eligible durable destination work without registering or extracting a Salesforce snapshot
        /// </summary>
        /// <param name="leaseOwner">The worker identity used for destination leases</param>
        /// <param name="exportDestinationId">The optional destination identifier for a controlled targeted replay</param>
        /// <param name="cancellationToken">Token used to cancel processing</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task RunDestinationsAsync(string leaseOwner, Guid? exportDestinationId = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Requeues one existing destination while retaining its completed Salesforce snapshot
        /// </summary>
        /// <param name="exportDestinationId">The destination work identifier approved for replay</param>
        /// <param name="reason">The approved operational replay reason</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        /// <exception cref="ArgumentException">Thrown when the reason is empty</exception>
        Task ReplayDestinationAsync(Guid exportDestinationId, string reason, CancellationToken cancellationToken = default);
    }
}
