using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the values used to create a missing Salesforce Product2 record
    /// </summary>
    public class SalesforceProductRequest
    {
        /// <summary>
        /// Gets or sets the Salesforce product name
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Name)]
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce product code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ProductCode)]
        public string ProductCode { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce external identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ExternalId)]
        public string ExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets whether the Salesforce product is active
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.IsActive)]
        public bool IsActive { get; set; }
    }
}
