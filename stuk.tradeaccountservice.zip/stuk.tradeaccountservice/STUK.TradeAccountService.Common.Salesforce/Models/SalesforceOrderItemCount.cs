using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the aggregate Salesforce OrderItem count for an invoice
    /// </summary>
    public class SalesforceOrderItemCount
    {
        /// <summary>
        /// Gets or sets the number of Salesforce OrderItems returned by the aggregate query
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ItemCount)]
        public int ItemCount { get; set; }
    }
}
