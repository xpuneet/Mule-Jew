using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents an existing Salesforce Product2 record required by Consolidated Sales
    /// </summary>
    public class SalesforceProduct
    {
        /// <summary>
        /// Gets or sets the Salesforce record identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Id)]
        public string Id { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the STARK product code stored as the Salesforce external identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ExternalId)]
        public string ExternalId { get; set; } = string.Empty;
    }
}
