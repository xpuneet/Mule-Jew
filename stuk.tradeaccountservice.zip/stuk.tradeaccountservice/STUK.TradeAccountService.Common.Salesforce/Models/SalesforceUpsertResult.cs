using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the outcome of a Salesforce external-id upsert
    /// </summary>
    public class SalesforceUpsertResult
    {
        /// <summary>
        /// Gets or sets the Salesforce record identifier when returned
        /// </summary>
        [JsonPropertyName("id")]
        public string? Id { get; set; }

        /// <summary>
        /// Gets or sets whether the upsert succeeded
        /// </summary>
        [JsonPropertyName("success")]
        public bool Success { get; set; }

        /// <summary>
        /// Gets or sets whether Salesforce created a new record
        /// </summary>
        [JsonPropertyName("created")]
        public bool Created { get; set; }
    }
}
