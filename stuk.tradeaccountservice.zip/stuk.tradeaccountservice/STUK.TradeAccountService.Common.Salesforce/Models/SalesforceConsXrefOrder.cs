using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the Salesforce Order values selected by the legacy ConsXref query
    /// </summary>
    public class SalesforceConsXrefOrder
    {
        /// <summary>
        /// Gets or sets the related Salesforce account values
        /// </summary>
        [JsonPropertyName("Account")]
        public SalesforceConsXrefAccount? Account { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce invoice number
        /// </summary>
        [JsonPropertyName("Invoice_Number__c")]
        public string? InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce invoice date
        /// </summary>
        [JsonPropertyName("Invoice_Date__c")]
        public DateOnly? InvoiceDate { get; set; }
    }
}
