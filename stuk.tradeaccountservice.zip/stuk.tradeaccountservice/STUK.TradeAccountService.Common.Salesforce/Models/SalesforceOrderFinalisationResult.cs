namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the outcome of checking whether a Salesforce Order is complete enough to activate
    /// </summary>
    public class SalesforceOrderFinalisationResult
    {
        /// <summary>
        /// Gets or sets the canonical number of invoice lines expected in Salesforce
        /// </summary>
        public int ExpectedLineCount { get; set; }

        /// <summary>
        /// Gets or sets the number of OrderItems currently persisted in Salesforce
        /// </summary>
        public int ActualLineCount { get; set; }

        /// <summary>
        /// Gets or sets whether the Salesforce Order was activated
        /// </summary>
        public bool Activated { get; set; }
    }
}
