using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the values used to create a missing Salesforce PricebookEntry
    /// </summary>
    public class SalesforcePricebookEntryRequest
    {
        /// <summary>
        /// Gets or sets the Salesforce Pricebook identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PricebookId)]
        public string PricebookId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the initial price required when creating the pricebook entry
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.UnitPrice)]
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets whether the Salesforce pricebook entry is active
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.IsActive)]
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce external identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ExternalId)]
        public string ExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the related Product2 identified by its external identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ProductRelationship)]
        public SalesforceProductReference Product { get; set; } = new();
    }
}
