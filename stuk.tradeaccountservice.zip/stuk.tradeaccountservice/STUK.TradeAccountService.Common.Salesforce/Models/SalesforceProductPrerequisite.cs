namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the resolved Salesforce prerequisite identifiers for one product code
    /// </summary>
    public class SalesforceProductPrerequisite
    {
        /// <summary>
        /// Gets or sets the product external identifier
        /// </summary>
        public string ExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce Product2 identifier
        /// </summary>
        public string ProductId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce PricebookEntry identifier
        /// </summary>
        public string PricebookEntryId { get; set; } = string.Empty;
    }
}
