using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the access details returned by the Salesforce OAuth token endpoint
    /// </summary>
    public class SalesforceAccessToken
    {
        /// <summary>
        /// Gets or sets the bearer access token
        /// </summary>
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce instance URL used for subsequent REST calls
        /// </summary>
        [JsonPropertyName("instance_url")]
        public string InstanceUrl { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the returned OAuth token type
        /// </summary>
        [JsonPropertyName("token_type")]
        public string TokenType { get; set; } = string.Empty;
    }
}
