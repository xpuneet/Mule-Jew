using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the Salesforce Account values selected by the legacy ConsXref query
    /// </summary>
    public class SalesforceConsXrefAccount
    {
        /// <summary>
        /// Gets or sets the external STARK account number
        /// </summary>
        [JsonPropertyName("Account_Number__c")]
        public string? AccountNumber { get; set; }
    }
}
