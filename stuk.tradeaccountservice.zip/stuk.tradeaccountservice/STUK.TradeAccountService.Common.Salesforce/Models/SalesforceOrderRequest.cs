using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the Salesforce fields used to create or update a Consolidated Sales Order
    /// </summary>
    public class SalesforceOrderRequest
    {
        /// <summary>
        /// Gets or sets the related Salesforce Account
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.AccountRelationship)]
        public SalesforceAccountReference Account { get; set; } = new();

        /// <summary>
        /// Gets or sets the Salesforce Pricebook identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PricebookId)]
        public string PricebookId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Order effective date
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.EffectiveDate)]
        public DateOnly? EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce Order status
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Status)]
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce Order type
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Type)]
        public string OrderType { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the credit terms
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.CreditTerms)]
        public string? CreditTerms { get; set; }

        /// <summary>
        /// Gets or sets the invoice date
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.InvoiceDate)]
        public DateOnly? InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets the consolidated invoice number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.InvoiceNumber)]
        public string InvoiceNumber { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the tax point date
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.TaxPointDate)]
        public DateOnly? TaxPointDate { get; set; }

        /// <summary>
        /// Gets or sets the customer account code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.AccountCode)]
        public string AccountCode { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the invoice tax total
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.TaxTotal)]
        public decimal? TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets the invoice taxable total
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.TaxableTotal)]
        public decimal? TaxableTotal { get; set; }

        /// <summary>
        /// Gets or sets the invoice gross payment total
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.GrossPaymentTotal)]
        public decimal? GrossPaymentTotal { get; set; }
    }
}
