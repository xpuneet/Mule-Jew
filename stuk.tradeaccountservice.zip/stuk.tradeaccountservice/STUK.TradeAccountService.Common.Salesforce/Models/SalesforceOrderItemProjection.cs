namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the values mapped to a Salesforce OrderItem
    /// </summary>
    public class SalesforceOrderItemProjection
    {
        /// <summary>
        /// Gets or sets the deterministic OrderItem external identifier
        /// </summary>
        public string ExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the parent Order invoice number
        /// </summary>
        public string InvoiceNumber { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the product and pricebook-entry external identifier
        /// </summary>
        public string ProductCode { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the line number
        /// </summary>
        public string? LineNumber { get; set; }

        /// <summary>
        /// Gets or sets the order line number
        /// </summary>
        public decimal? OrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the original order line item number
        /// </summary>
        public decimal? OriginalOrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note line number
        /// </summary>
        public decimal? DeliveryNoteLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the buyer order number
        /// </summary>
        public string? BuyersOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier order reference
        /// </summary>
        public string? OrderReference { get; set; }

        /// <summary>
        /// Gets or sets the despatch date
        /// </summary>
        public DateOnly? DespatchDate { get; set; }

        /// <summary>
        /// Gets or sets the supplier delivery code
        /// </summary>
        public string? CodeForDelivery { get; set; }

        /// <summary>
        /// Gets or sets the order type code
        /// </summary>
        public string? OrderType { get; set; }

        /// <summary>
        /// Gets or sets the order category code
        /// </summary>
        public string? OrderCategory { get; set; }

        /// <summary>
        /// Gets or sets the delivery method code
        /// </summary>
        public string? DeliveryMethod { get; set; }

        /// <summary>
        /// Gets or sets the supplier part analysis code
        /// </summary>
        public string? PartAnalysisCode { get; set; }

        /// <summary>
        /// Gets or sets whether this is a special product
        /// </summary>
        public bool? IsSpecialProduct { get; set; }

        /// <summary>
        /// Gets or sets the product description
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Gets or sets the quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure code
        /// </summary>
        public string? QuantityUomCode { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure description
        /// </summary>
        public string? QuantityUomDescription { get; set; }

        /// <summary>
        /// Gets or sets the unit price
        /// </summary>
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure code
        /// </summary>
        public string? PriceUomCode { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure description
        /// </summary>
        public string? PriceUomDescription { get; set; }

        /// <summary>
        /// Gets or sets the percentage discount
        /// </summary>
        public decimal? PercentageDiscount { get; set; }

        /// <summary>
        /// Gets or sets the tax rate code
        /// </summary>
        public string? TaxRateCode { get; set; }

        /// <summary>
        /// Gets or sets the tax rate
        /// </summary>
        public decimal? TaxRate { get; set; }

        /// <summary>
        /// Gets or sets the tax value
        /// </summary>
        public decimal? TaxValue { get; set; }

        /// <summary>
        /// Gets or sets the order product total
        /// </summary>
        public decimal? OrderProductTotal { get; set; }

        /// <summary>
        /// Gets or sets the job number
        /// </summary>
        public string? JobNumber { get; set; }

        /// <summary>
        /// Gets or sets the job address line
        /// </summary>
        public string? JobAddressLine { get; set; }

        /// <summary>
        /// Gets or sets the job street
        /// </summary>
        public string? JobStreet { get; set; }

        /// <summary>
        /// Gets or sets the job city
        /// </summary>
        public string? JobCity { get; set; }

        /// <summary>
        /// Gets or sets the job state
        /// </summary>
        public string? JobState { get; set; }

        /// <summary>
        /// Gets or sets the complete job postcode pending confirmed Salesforce field limits
        /// </summary>
        public string? JobPostcode { get; set; }

        /// <summary>
        /// Gets or sets the contract number
        /// </summary>
        public string? ContractNumber { get; set; }

        /// <summary>
        /// Gets or sets the buyer location code
        /// </summary>
        public string? BuyerLocationCode { get; set; }

        /// <summary>
        /// Gets or sets the operative
        /// </summary>
        public string? Operative { get; set; }

        /// <summary>
        /// Gets or sets the site code
        /// </summary>
        public string? SiteCode { get; set; }

        /// <summary>
        /// Gets or sets the plot number
        /// </summary>
        public string? PlotNumber { get; set; }

        /// <summary>
        /// Gets or sets the vehicle registration
        /// </summary>
        public string? VehicleRegistration { get; set; }

        /// <summary>
        /// Gets or sets the house type
        /// </summary>
        public string? HouseType { get; set; }

        /// <summary>
        /// Gets or sets the product group
        /// </summary>
        public string? ProductGroup { get; set; }

        /// <summary>
        /// Gets or sets whether the order was authorised
        /// </summary>
        public bool OrderAuthorised { get; set; }
    }
}
