using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the Salesforce fields used to create or update a Consolidated Sales OrderItem
    /// </summary>
    public class SalesforceOrderItemRequest
    {
        /// <summary>
        /// Gets or sets the deterministic Salesforce OrderItem external identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ExternalId)]
        public string ExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the invoiced quantity
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Quantity)]
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Gets or sets the invoiced unit price
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.UnitPrice)]
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets the related Salesforce Product2
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ProductRelationship)]
        public SalesforceProductReference Product { get; set; } = new();

        /// <summary>
        /// Gets or sets the related Salesforce PricebookEntry
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PricebookEntryRelationship)]
        public SalesforcePricebookEntryReference PricebookEntry { get; set; } = new();

        /// <summary>
        /// Gets or sets the related Salesforce Order
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OrderRelationship)]
        public SalesforceOrderReference Order { get; set; } = new();

        /// <summary>
        /// Gets or sets the product or text-line description
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Description)]
        public string? Description { get; set; }

        /// <summary>
        /// Gets or sets the buyer location code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.BuyerLocationCode)]
        public string? BuyerLocationCode { get; set; }

        /// <summary>
        /// Gets or sets the buyer order number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.BuyersOrderNumber)]
        public string? BuyersOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier delivery code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.CodeForDelivery)]
        public string? CodeForDelivery { get; set; }

        /// <summary>
        /// Gets or sets the contract number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ContractNumber)]
        public string? ContractNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery method code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.DeliveryMethod)]
        public string? DeliveryMethod { get; set; }

        /// <summary>
        /// Gets or sets the delivery note line number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.DeliveryNoteLineNumber)]
        public decimal? DeliveryNoteLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.DeliveryNoteNumber)]
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier despatch date
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.DespatchDate)]
        public DateOnly? DespatchDate { get; set; }

        /// <summary>
        /// Gets or sets the house type
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.HouseType)]
        public string? HouseType { get; set; }

        /// <summary>
        /// Gets or sets whether the line represents a special product
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.IsSpecialProduct)]
        public bool? IsSpecialProduct { get; set; }

        /// <summary>
        /// Gets or sets the joined job-address lines
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.JobAddressLine)]
        public string? JobAddressLine { get; set; }

        /// <summary>
        /// Gets or sets the job city
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.JobCity)]
        public string? JobCity { get; set; }

        /// <summary>
        /// Gets or sets the job number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.JobNumber)]
        public string? JobNumber { get; set; }

        /// <summary>
        /// Gets or sets the job state or county
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.JobState)]
        public string? JobState { get; set; }

        /// <summary>
        /// Gets or sets the job street
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.JobStreet)]
        public string? JobStreet { get; set; }

        /// <summary>
        /// Gets or sets the operative reference
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Operative)]
        public string? Operative { get; set; }

        /// <summary>
        /// Gets or sets whether the source order was authorised
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OrderAuthorised)]
        public bool OrderAuthorised { get; set; }

        /// <summary>
        /// Gets or sets the order category code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OrderCategory)]
        public string? OrderCategory { get; set; }

        /// <summary>
        /// Gets or sets the source order line number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OrderLineNumber)]
        public decimal? OrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier order reference
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OrderReference)]
        public string? OrderReference { get; set; }

        /// <summary>
        /// Gets or sets the order type code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OrderType)]
        public string? OrderType { get; set; }

        /// <summary>
        /// Gets or sets the supplier part-analysis code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PartAnalysisCode)]
        public string? PartAnalysisCode { get; set; }

        /// <summary>
        /// Gets or sets the plot number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PlotNumber)]
        public string? PlotNumber { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PriceUomCode)]
        public string? PriceUomCode { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure description
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PriceUomDescription)]
        public string? PriceUomDescription { get; set; }

        /// <summary>
        /// Gets or sets the product group
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ProductGroup)]
        public string? ProductGroup { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.QuantityUomCode)]
        public string? QuantityUomCode { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure description
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.QuantityUomDescription)]
        public string? QuantityUomDescription { get; set; }

        /// <summary>
        /// Gets or sets the site code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.SiteCode)]
        public string? SiteCode { get; set; }

        /// <summary>
        /// Gets or sets the tax rate code
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.TaxRateCode)]
        public string? TaxRateCode { get; set; }

        /// <summary>
        /// Gets or sets the tax rate
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.TaxRate)]
        public decimal? TaxRate { get; set; }

        /// <summary>
        /// Gets or sets the tax value
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.TaxValue)]
        public decimal? TaxValue { get; set; }

        /// <summary>
        /// Gets or sets the vehicle registration
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.VehicleRegistration)]
        public string? VehicleRegistration { get; set; }

        /// <summary>
        /// Gets or sets the job postcode limited to the Salesforce-supported length
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.JobPostCode)]
        public string? JobPostcode { get; set; }

        /// <summary>
        /// Gets or sets the original order line item number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OriginOrderLineItemNumber)]
        public decimal? OriginalOrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the OrderItem line total
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.OrderProductTotal)]
        public decimal? OrderProductTotal { get; set; }

        /// <summary>
        /// Gets or sets the percentage discount
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.PercentageDiscount)]
        public decimal? PercentageDiscount { get; set; }

        /// <summary>
        /// Gets or sets the preserved source line number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.LineNumber)]
        public string? LineNumber { get; set; }
    }
}
