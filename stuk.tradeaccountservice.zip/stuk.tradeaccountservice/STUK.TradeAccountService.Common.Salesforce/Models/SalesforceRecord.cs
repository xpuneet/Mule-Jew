using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the Salesforce identifier returned for an existing record
    /// </summary>
    public class SalesforceRecord
    {
        /// <summary>
        /// Gets or sets the Salesforce record identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Id)]
        public string Id { get; set; } = string.Empty;
    }
}
