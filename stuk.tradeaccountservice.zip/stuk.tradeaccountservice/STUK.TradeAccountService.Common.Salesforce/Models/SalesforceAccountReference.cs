using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Identifies a Salesforce Account relationship using its account number
    /// </summary>
    public class SalesforceAccountReference
    {
        /// <summary>
        /// Gets or sets the related Salesforce Account number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.AccountNumber)]
        public string AccountNumber { get; set; } = string.Empty;
    }
}
