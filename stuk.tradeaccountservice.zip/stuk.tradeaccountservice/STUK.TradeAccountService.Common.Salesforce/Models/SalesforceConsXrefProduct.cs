using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the Salesforce Product2 values selected by the legacy ConsXref query
    /// </summary>
    public class SalesforceConsXrefProduct
    {
        /// <summary>
        /// Gets or sets the Salesforce product code
        /// </summary>
        [JsonPropertyName("ProductCode")]
        public string? ProductCode { get; set; }
    }
}
