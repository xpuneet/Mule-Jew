namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the values mapped to a Salesforce Order
    /// </summary>
    public class SalesforceOrderProjection
    {
        /// <summary>
        /// Gets or sets the account external identifier used for the Account relationship
        /// </summary>
        public string AccountExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the consolidated invoice number used as the Order external identifier
        /// </summary>
        public string InvoiceNumber { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce Order status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce Order type
        /// </summary>
        public string OrderType { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the effective date
        /// </summary>
        public DateOnly? EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets the invoice date
        /// </summary>
        public DateOnly? InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets the tax point date
        /// </summary>
        public DateOnly? TaxPointDate { get; set; }

        /// <summary>
        /// Gets or sets the credit terms
        /// </summary>
        public string? CreditTerms { get; set; }

        /// <summary>
        /// Gets or sets the taxable total
        /// </summary>
        public decimal? TaxableTotal { get; set; }

        /// <summary>
        /// Gets or sets the tax total
        /// </summary>
        public decimal? TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets the gross payment total
        /// </summary>
        public decimal? GrossPaymentTotal { get; set; }

        /// <summary>
        /// Gets or sets the canonical line count required before Order activation
        /// </summary>
        public int ExpectedLineCount { get; set; }
    }
}
