using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents an error returned by a Salesforce REST operation
    /// </summary>
    public class SalesforceError
    {
        /// <summary>
        /// Gets or sets the Salesforce error code
        /// </summary>
        [JsonPropertyName("errorCode")]
        public string? ErrorCode { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce error message
        /// </summary>
        [JsonPropertyName("message")]
        public string? Message { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce fields associated with the error
        /// </summary>
        [JsonPropertyName("fields")]
        public List<string> Fields { get; set; } = [];
    }
}
