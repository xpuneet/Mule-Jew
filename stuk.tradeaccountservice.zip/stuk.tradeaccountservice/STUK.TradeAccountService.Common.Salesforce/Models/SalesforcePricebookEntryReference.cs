using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Identifies a Salesforce PricebookEntry relationship using its external identifier
    /// </summary>
    public class SalesforcePricebookEntryReference
    {
        /// <summary>
        /// Gets or sets the related PricebookEntry external identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ExternalId)]
        public string ExternalId { get; set; } = string.Empty;
    }
}
