using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents one page returned by a Salesforce SOQL query
    /// </summary>
    /// <typeparam name="TRecord">The Salesforce record type</typeparam>
    public class SalesforceQueryResult<TRecord>
    {
        /// <summary>
        /// Gets or sets the total number of records in the complete query result
        /// </summary>
        [JsonPropertyName("totalSize")]
        public int TotalSize { get; set; }

        /// <summary>
        /// Gets or sets whether this is the final result page
        /// </summary>
        [JsonPropertyName("done")]
        public bool Done { get; set; }

        /// <summary>
        /// Gets or sets the relative URL for the next result page
        /// </summary>
        [JsonPropertyName("nextRecordsUrl")]
        public string? NextRecordsUrl { get; set; }

        /// <summary>
        /// Gets or sets the records contained in this result page
        /// </summary>
        [JsonPropertyName("records")]
        public List<TRecord> Records { get; set; } = [];
    }
}
