using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents one Salesforce OrderItem returned by the legacy ConsXref query
    /// </summary>
    public class SalesforceConsXrefOrderItem
    {
        /// <summary>
        /// Gets or sets the related Salesforce Order values
        /// </summary>
        [JsonPropertyName("Order")]
        public SalesforceConsXrefOrder? Order { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        [JsonPropertyName("Delivery_Note_Number__c")]
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the numeric delivery note line number
        /// </summary>
        [JsonPropertyName("Delivery_Note_Line_Number__c")]
        public decimal? DeliveryNoteLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the despatch date
        /// </summary>
        [JsonPropertyName("Despatch_Date__c")]
        public DateOnly? DespatchDate { get; set; }

        /// <summary>
        /// Gets or sets the related Salesforce Product2 values
        /// </summary>
        [JsonPropertyName("Product2")]
        public SalesforceConsXrefProduct? Product { get; set; }

        /// <summary>
        /// Gets or sets the ordered quantity
        /// </summary>
        [JsonPropertyName("Quantity")]
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce order-product total
        /// </summary>
        [JsonPropertyName("Order_Product_Total__c")]
        public decimal? TotalPrice { get; set; }
    }
}
