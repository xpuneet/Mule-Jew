using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents a Salesforce Order status update
    /// </summary>
    public class SalesforceOrderStatusRequest
    {
        /// <summary>
        /// Gets or sets the Salesforce Order status
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.Status)]
        public string Status { get; set; } = string.Empty;
    }
}
