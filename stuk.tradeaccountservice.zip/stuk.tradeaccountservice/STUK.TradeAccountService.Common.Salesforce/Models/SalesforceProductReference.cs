using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Identifies a Salesforce Product2 relationship using its external identifier
    /// </summary>
    public class SalesforceProductReference
    {
        /// <summary>
        /// Gets or sets the related Product2 external identifier
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.ExternalId)]
        public string ExternalId { get; set; } = string.Empty;
    }
}
