namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Represents the complete canonical projection required for Salesforce synchronisation
    /// </summary>
    public class SalesforceInvoiceProjection
    {
        /// <summary>
        /// Gets or sets the Salesforce Order values
        /// </summary>
        public SalesforceOrderProjection Order { get; set; } = new();

        /// <summary>
        /// Gets or sets the Salesforce OrderItem values
        /// </summary>
        public List<SalesforceOrderItemProjection> Items { get; set; } = [];

        /// <summary>
        /// Gets or sets the distinct product external identifiers required by the invoice
        /// </summary>
        public List<string> RequiredProductCodes { get; set; } = [];
    }
}
