using System.Text.Json.Serialization;
using STUK.TradeAccountService.Common.Salesforce.Constants;

namespace STUK.TradeAccountService.Common.Salesforce.Models
{
    /// <summary>
    /// Identifies a Salesforce Order relationship using its invoice number
    /// </summary>
    public class SalesforceOrderReference
    {
        /// <summary>
        /// Gets or sets the related Salesforce Order invoice number
        /// </summary>
        [JsonPropertyName(SalesforceFieldNames.InvoiceNumber)]
        public string InvoiceNumber { get; set; } = string.Empty;
    }
}
