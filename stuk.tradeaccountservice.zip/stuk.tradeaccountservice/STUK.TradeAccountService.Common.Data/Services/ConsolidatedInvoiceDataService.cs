using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides stored-procedure access to canonical Consolidated Sales invoices
    /// </summary>
    public class ConsolidatedInvoiceDataService : IConsolidatedInvoiceDataService
    {
        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };

        private readonly IDbExecutor _dbExecutor;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedInvoiceDataService"/>
        /// </summary>
        /// <param name="dbExecutor">The keyed Trade Account Service database executor</param>
        /// <exception cref="ArgumentNullException"></exception>
        public ConsolidatedInvoiceDataService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesCommitResult> CommitAsync(
            Guid sourceItemId,
            Guid claimToken,
            ConsolidatedSalesInvoice invoice,
            DateTimeOffset salesforceCooloffStartedOn,
            int salesforceCooloffHours,
            DateTimeOffset salesforceEligibleOn,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var invoiceJson = JsonSerializer.Serialize(invoice);
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesCommitResult>(StoredProcedures.CommitConsolidatedSalesInvoice, new
            {
                sourceItemId,
                claimToken,
                invoiceJson,
                salesforceCooloffStartedOn,
                salesforceCooloffHours,
                salesforceEligibleOn,
                now
            })
                ?? throw new InvalidOperationException("The invoice commit did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesInvoice?> GetByNumberAsync(string consolidatedInvoiceNumber, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var json = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetConsolidatedSalesInvoiceByNumber, new { consolidatedInvoiceNumber });
            return string.IsNullOrWhiteSpace(json) ? null : JsonSerializer.Deserialize<ConsolidatedSalesInvoice>(json, JsonOptions);
        }

    }
}
