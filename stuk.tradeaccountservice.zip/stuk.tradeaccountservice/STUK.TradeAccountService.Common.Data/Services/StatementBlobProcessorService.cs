﻿using Dapper;
using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Data;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class StatementBlobProcessorService : IStatementBlobProcessorService
    {
        private readonly IDbExecutor _dbExecutor;
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;

        public StatementBlobProcessorService([FromKeyedServices("OrderDb")] IDbExecutor dbExecutor, IAppInsightsLoggerHelper appInsightsLoggerHelper)
        {
            _dbExecutor = dbExecutor;
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
        }

        public async Task UpsertBatchAsync(
            IReadOnlyList<StatementHeaderData> documents,
            IReadOnlyList<StatementMetadataData> metadata)
        {
            _appInsightsLoggerHelper.LogInformation($"UpsertBatchAsync Started",
               $"Upserted batch: {documents.Count} header(s).");

            if (documents.Count == 0) {
                _appInsightsLoggerHelper.LogWarning($"UpsertBatchAsync completed with 0 Documents",
               $"Upserted batch: {documents.Count} header(s).");
                return;
            } 

            var headersTvp = BuildHeadersTvp(documents);
            var metaTvp = BuildMetadataTvp(metadata);

            var parameters = new DynamicParameters();
            parameters.Add("@Headers", headersTvp, DbType.Object, ParameterDirection.Input);
            parameters.Add("@Metadata", metaTvp, DbType.Object, ParameterDirection.Input);

            await _dbExecutor.ExecuteAsync(
                StoredProcedures.InsertStatementFromBlob,
                parameters);

            _appInsightsLoggerHelper.LogInformation($"UpsertBatchAsync Completed",
                $"Upserted batch: {documents.Count} header(s).");
        }

        //TVP builders
        private static DataTable BuildHeadersTvp(IReadOnlyList<StatementHeaderData> documents)
        {
            var dt = new DataTable();
            dt.Columns.Add("AccountCode", typeof(string));
            dt.Columns.Add("OwningBranch", typeof(string));
            dt.Columns.Add("StatementDate", typeof(DateTime));
            dt.Columns.Add("StatementMonth", typeof(string));
            dt.Columns.Add("EndOfNextMonth", typeof(DateTime));
            dt.Columns.Add("CurrencyCode", typeof(string));
            dt.Columns.Add("LineCount", typeof(int));
            dt.Columns.Add("TotalVAT", typeof(decimal));
            dt.Columns.Add("SetDiscountTotal", typeof(decimal));
            dt.Columns.Add("StatementTotal", typeof(decimal));
            dt.Columns.Add("StatementDiscountTotal", typeof(decimal));
            dt.Columns.Add("QueriedBalance", typeof(decimal));
            dt.Columns.Add("BalanceAfterQueries", typeof(decimal));
            dt.Columns.Add("VatThisPeriod", typeof(decimal));

            foreach (var h in documents)
            {
                dt.Rows.Add(
                    h.AccountCode,
                    NullIfEmpty(h.OwningBranch),
                    h.StatementDate,
                    NullIfEmpty(h.StatementMonth),
                    h.EndOfNextMonth.HasValue ? h.EndOfNextMonth : DBNull.Value,
                    h.CurrencyCode,
                    h.LineCount.HasValue ? h.LineCount : DBNull.Value,
                    h.TotalVAT.HasValue ? h.TotalVAT : DBNull.Value,
                    h.SettDiscountTotal.HasValue ? h.SettDiscountTotal : DBNull.Value,
                    h.StatementTotal.HasValue ? h.StatementTotal : DBNull.Value,
                    h.StatementDiscountTotal.HasValue ? h.StatementDiscountTotal : DBNull.Value,
                    h.QueriedBalance.HasValue ? h.QueriedBalance : DBNull.Value,
                    h.BalanceAfterQueries.HasValue ? h.BalanceAfterQueries : DBNull.Value,
                    h.VATThisPeriod.HasValue ? h.VATThisPeriod : DBNull.Value
                );
            }

            dt.SetTypeName(DbDataType.udt_StatementHeader);
            return dt;
        }

        private static DataTable BuildMetadataTvp(IReadOnlyList<StatementMetadataData> metadata)
        {
            var dt = new DataTable();
            dt.Columns.Add("AccountCode", typeof(string));
            dt.Columns.Add("StatementDate", typeof(DateTime));
            dt.Columns.Add("OriginalFileName", typeof(string));
            dt.Columns.Add("Extension", typeof(string));
            dt.Columns.Add("CalculatedFileName", typeof(string));
            dt.Columns.Add("ContentMd5", typeof(string));
            dt.Columns.Add("ContentLength", typeof(long));
            dt.Columns.Add("BlobUri", typeof(string));
            dt.Columns.Add("CreatedBy", typeof(string));

            foreach (var m in metadata)
            {
                dt.Rows.Add(
                    m.AccountCode,
                    m.StatementDate,
                    NullIfEmpty(m.OriginalFileName),
                    NullIfEmpty(m.Extension),
                    NullIfEmpty(m.CalculatedFileName),
                    NullIfEmpty(m.ContentMd5),
                    m.ContentLength > 0 ? m.ContentLength : DBNull.Value,
                    NullIfEmpty(m.BlobUri),
                    NullIfEmpty(m.CreatedBy)
                );
            }

            dt.SetTypeName(DbDataType.udt_StatementMetadata);
            return dt;
        }

        private static object NullIfEmpty(string? value) =>
            string.IsNullOrEmpty(value) ? DBNull.Value : value;
    }
}
