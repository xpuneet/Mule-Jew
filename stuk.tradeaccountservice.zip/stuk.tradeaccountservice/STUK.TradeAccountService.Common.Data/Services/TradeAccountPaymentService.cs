﻿using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Utilities;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class TradeAccountPaymentService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor,
        IAppInsightsLoggerHelper appInsightsLoggerHelper) : ITradeAccountPaymentService
    {
        private readonly IDbExecutor _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));

        public async Task<CreatePaymentResponse?> CreatePayementreferenceAsync(CreatePaymentRequest request, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"CreatePayementreferenceAsync started at {DateTime.Now} for AccountCode {request.AccountCode}.");
            var dynamicParams = SqlParameterHelper.GetNonNullParameters(request!);
            var result = await _dbExecutor.ExecuteSingleAsync<CreatePaymentResponse>(StoredProcedures.InsertPaymentInfo, dynamicParams);
            if (result?.Success == true)
            {
                _appInsightsLoggerHelper.LogInformation($"CreatePayementreferenceAsync completed at {DateTime.Now}.", $"Message: {result.Message} payment id: {result.PaymentId}");
                return result;
            }
            else
            {
                _appInsightsLoggerHelper.LogWarning($"CreatePayementreferenceAsync {result?.Message?.ToLower() ?? "Failed"}.", $"{result?.ErrorMessage ?? "CreatePayementreferenceAsync failed"} at {DateTime.Now}.");
                return result;
            }
        }
        public async Task<Payment?> GetPayementReferenceByRefCodeAsync(Guid paymentRef, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetPayementReferenceByRefCodeAsync started at {DateTime.Now} with {paymentRef}.");
            var result = await _dbExecutor.ExecuteSingleAsync<Payment>(StoredProcedures.GetPaymentsByReference, new { paymentRef });
            _appInsightsLoggerHelper.LogInformation($"GetPayementReferenceByRefCodeAsync found account {result?.AccountCode} at {DateTime.Now} for {paymentRef}.");
            return result;
        }
    }
}
