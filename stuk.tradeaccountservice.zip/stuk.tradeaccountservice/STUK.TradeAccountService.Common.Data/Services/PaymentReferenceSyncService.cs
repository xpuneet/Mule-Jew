﻿using Dapper;
using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Data;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class PaymentReferenceSyncService : IPaymentReferenceSyncService
    {
        private readonly IDbExecutor _dbExecutor;
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;

        public PaymentReferenceSyncService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor, IAppInsightsLoggerHelper appInsightsLoggerHelper)
        {
            _dbExecutor = dbExecutor;
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
        }

        public async Task<IEnumerable<PendingPaymentReference>> GetPendingPaymentsAsync(CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetPendingPaymentsAsync started at {DateTime.UtcNow}");

            var rows = await _dbExecutor.ExecuteListAsync<PendingPaymentReference>(
                StoredProcedures.GetPendingPaymentsReference, new {});

           _appInsightsLoggerHelper.LogInformation($"GetPendingPaymentsAsync completed successfully at {DateTime.UtcNow}", $"Fetched {rows.Count()} pending payments.");
            return rows;
        }

        public async Task UpdatePendingPaymentsAsync(IEnumerable<UpdatePaymentReference> results, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"UpdatePendingPaymentsAsync started at {DateTime.UtcNow} with {results.Count()} results");
            
            var table = BuildResultsTable(results);
            var parameters = new DynamicParameters();
            parameters.Add("@Results", table, DbType.Object, ParameterDirection.Input);

            await _dbExecutor.ExecuteAsync(
                StoredProcedures.UpdatePendingPaymentsReference,
                parameters);

            _appInsightsLoggerHelper.LogInformation($"UpdatePendingPaymentsAsync completed successfully at {DateTime.UtcNow}", $"Applied {table.Rows.Count} results." );
        }

        private static DataTable BuildResultsTable(IEnumerable<UpdatePaymentReference> results)
        {
            var dt = new DataTable();
            dt.Columns.Add("paymentId", typeof(long));
            dt.Columns.Add("erpPaymentReference", typeof(string));
            dt.Columns.Add("erpStatus", typeof(string));
            dt.Columns.Add("erpReason", typeof(string));

            foreach (var r in results)
            {
                dt.Rows.Add(
                    r.PaymentId,
                    (object?)r.ErpPaymentReference ?? DBNull.Value,
                    r.ErpStatus,
                    (object?)r.ErpReason ?? DBNull.Value);
            }

            dt.SetTypeName(DbDataType.udt_ErpPaymentReference);
            return dt;
        }
    }
}
