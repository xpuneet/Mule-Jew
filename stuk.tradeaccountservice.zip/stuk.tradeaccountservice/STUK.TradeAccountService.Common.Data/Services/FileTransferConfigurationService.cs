using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Reads the established managed-transfer action and connection records
    /// </summary>
    public class FileTransferConfigurationService : IFileTransferConfigurationService
    {
        private readonly IDbExecutor _dbExecutor;

        /// <summary>
        /// Initialises a new instance of the <see cref="FileTransferConfigurationService"/>
        /// </summary>
        /// <param name="dbExecutor">The keyed File Transfer Database executor</param>
        /// <exception cref="ArgumentNullException">Thrown when the database executor is not supplied</exception>
        public FileTransferConfigurationService([FromKeyedServices("FileTransferDb")] IDbExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurTm1TransferConfiguration> GetTm1PickupAsync(string integrationKeyId, string actionName, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(integrationKeyId);
            ArgumentException.ThrowIfNullOrWhiteSpace(actionName);
            cancellationToken.ThrowIfCancellationRequested();

            var action = await _dbExecutor.ExecuteSingleAsync<FileTransferActionConfiguration>(StoredProcedures.GetFileTransferConnectionByIntegrationKey, new
            {
                integrationKey = integrationKeyId,
                actionName
            });

            action = action ?? throw new InvalidOperationException($"No File Transfer action exists for integration '{integrationKeyId}' and action '{actionName}'");

            cancellationToken.ThrowIfCancellationRequested();

            var sftp = await _dbExecutor.ExecuteSingleAsync<SynapseSftpConfiguration>(StoredProcedures.GetSftpConnectionConfigBySourceId, new
            {
                sourceId = action.SourceId
            });

            cancellationToken.ThrowIfCancellationRequested();

            var blob = await _dbExecutor.ExecuteSingleAsync<FileTransferBlobConfiguration>(StoredProcedures.GetBlobConnectionConfigByDestinationId, new
            {
                destinationId = action.DestinationId
            });

            return new WorkdayConcurTm1TransferConfiguration
            {
                Action = action,
                Sftp = sftp ?? throw new InvalidOperationException($"No SFTP connection exists for File Transfer source '{action.SourceId}'"),
                Blob = blob ?? throw new InvalidOperationException($"No Blob connection exists for File Transfer destination '{action.DestinationId}'")
            };
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurDeliveryTransferConfiguration> GetConcurDeliveryAsync(string integrationKeyId, string actionName, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(integrationKeyId);
            ArgumentException.ThrowIfNullOrWhiteSpace(actionName);
            cancellationToken.ThrowIfCancellationRequested();

            var action = await GetActionAsync(integrationKeyId, actionName);

            cancellationToken.ThrowIfCancellationRequested();

            var blob = await _dbExecutor.ExecuteSingleAsync<FileTransferBlobConfiguration>(StoredProcedures.GetBlobConnectionConfigBySourceId, new
            {
                sourceId = action.SourceId
            });

            cancellationToken.ThrowIfCancellationRequested();

            var sftp = await _dbExecutor.ExecuteSingleAsync<SynapseSftpConfiguration>(StoredProcedures.GetSftpConnectionConfigByDestinationId, new
            {
                destinationId = action.DestinationId
            });

            return new WorkdayConcurDeliveryTransferConfiguration
            {
                Action = action,
                Blob = blob ?? throw new InvalidOperationException($"No Blob connection exists for File Transfer source '{action.SourceId}'"),
                Sftp = sftp ?? throw new InvalidOperationException($"No SFTP connection exists for File Transfer destination '{action.DestinationId}'")
            };
        }

        private async Task<FileTransferActionConfiguration> GetActionAsync(string integrationKeyId, string actionName)
        {
            var action = await _dbExecutor.ExecuteSingleAsync<FileTransferActionConfiguration>(StoredProcedures.GetFileTransferConnectionByIntegrationKey, new
            {
                integrationKey = integrationKeyId,
                actionName
            });

            return action ?? throw new InvalidOperationException($"No File Transfer action exists for integration '{integrationKeyId}' and action '{actionName}'");
        }
    }
}
