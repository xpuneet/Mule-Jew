﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class StatementService([FromKeyedServices("OrderDb")] IDbExecutor dbExecutor, IOptions<DownloadSettings> settings,
        IAppInsightsLoggerHelper appInsightsLoggerHelper) : IStatementService
    {
        private readonly IDbExecutor _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        private readonly DocumentTypeDownloadSettings _typeSettings = settings.Value["Statement"];
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));

        public async Task<StatementSearchResponse?> SearchStatementsAsync(StatementSearchRequest searchParams, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"SearchStatementsAsync started at {DateTime.Now}.");

            var minAgeHours = _typeSettings.DownloadDelayHours;
            var statementDateFrom = ToDateTimeNullable(searchParams.StatementDateFrom);
            var statementDateTo = ToDateTimeNullable(searchParams.StatementDateTo);

            var jsonString = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetStatementsByAccountCode, new
            {
                searchParams.AccountCode,
                statementDateFrom,
                statementDateTo,
                minAgeHours,
                searchParams.PageNumber,
                searchParams.PageSize
            });

            if (string.IsNullOrEmpty(jsonString))
            {
                _appInsightsLoggerHelper.LogWarning($"SearchStatements completed with empty json at {DateTime.Now}.");
                return new();
            }
            var result = JsonSerializer.Deserialize<StatementSearchResponse>(jsonString);

            _appInsightsLoggerHelper.LogInformation($"SearchStatements completed successfully at {DateTime.Now}.");
            return result;
        }

        private DateTime? ToDateTimeNullable(DateOnly? dateOnly)
        {
            return dateOnly?.ToDateTime(TimeOnly.MinValue);
        }
    }
}
