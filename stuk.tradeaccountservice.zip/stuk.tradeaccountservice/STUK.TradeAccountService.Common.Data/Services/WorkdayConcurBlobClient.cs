using Azure;
using Azure.Storage.Blobs.Models;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Validates Blob identity, size and freshness after a managed transfer
    /// </summary>
    public class WorkdayConcurBlobClient : IWorkdayConcurBlobClient
    {
        private readonly IWorkdayConcurBlobServiceClientFactory _clientFactory;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurBlobClient"/>
        /// </summary>
        /// <param name="clientFactory">Authenticated Blob service client factory</param>
        /// <exception cref="ArgumentNullException">Thrown when the client factory is not supplied</exception>
        public WorkdayConcurBlobClient(IWorkdayConcurBlobServiceClientFactory clientFactory)
        {
            _clientFactory = clientFactory ?? throw new ArgumentNullException(nameof(clientFactory));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileIdentity> GetRequiredFreshFileAsync(Uri serviceEndpoint, string containerName, string blobName, DateTimeOffset notBefore, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(serviceEndpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(containerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(blobName);

            var blob = _clientFactory.Create(serviceEndpoint)
                .GetBlobContainerClient(containerName)
                .GetBlobClient(blobName);

            BlobProperties properties;

            try
            {
                properties = (await blob.GetPropertiesAsync(cancellationToken: cancellationToken)).Value;
            }
            catch (RequestFailedException exception) when (exception.Status == 404)
            {
                throw new FileNotFoundException($"Required Workday-to-Concur Blob '{containerName}/{blobName}' was not found", exception);
            }

            if (properties.ContentLength <= 0)
            {
                throw new InvalidDataException($"Required Workday-to-Concur Blob '{containerName}/{blobName}' is empty");
            }

            if (properties.LastModified < notBefore)
            {
                throw new InvalidDataException($"Required Workday-to-Concur Blob '{containerName}/{blobName}' predates the current pickup");
            }

            return new WorkdayConcurFileIdentity
            {
                Path = $"{containerName}/{blobName}",
                ContentLength = properties.ContentLength,
                ETag = properties.ETag.ToString(),
                LastModifiedOn = properties.LastModified
            };
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileIdentity> UploadAsync(Uri serviceEndpoint, string containerName, string blobName, Stream content, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(serviceEndpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(containerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(blobName);
            ArgumentNullException.ThrowIfNull(content);

            if (!content.CanSeek)
            {
                throw new ArgumentException("Blob upload content must be seekable", nameof(content));
            }

            var contentLength = content.Length - content.Position;
            if (contentLength <= 0)
            {
                throw new ArgumentException("Blob upload content must not be empty", nameof(content));
            }

            var blob = _clientFactory.Create(serviceEndpoint)
                .GetBlobContainerClient(containerName)
                .GetBlobClient(blobName);

            var response = await blob.UploadAsync(
                content,
                new BlobUploadOptions
                {
                    HttpHeaders = new BlobHttpHeaders
                    {
                        ContentType = "application/octet-stream"
                    }
                },
                cancellationToken);

            return new WorkdayConcurFileIdentity
            {
                Path = $"{containerName}/{blobName}",
                ContentLength = contentLength,
                ETag = response.Value.ETag.ToString(),
                LastModifiedOn = response.Value.LastModified
            };
        }

        /// <inheritdoc />
        public async Task<IReadOnlyCollection<WorkdayConcurFileIdentity>> ListFilesAsync(Uri serviceEndpoint, string containerName, string folderPath, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(serviceEndpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(containerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(folderPath);

            var normalisedFolderPath = folderPath.Trim().Trim('/');
            if (string.IsNullOrWhiteSpace(normalisedFolderPath))
            {
                throw new ArgumentException("A Blob folder path is required", nameof(folderPath));
            }

            var prefix = $"{normalisedFolderPath}/";
            var container = _clientFactory.Create(serviceEndpoint).GetBlobContainerClient(containerName);
            var files = new List<WorkdayConcurFileIdentity>();

            await foreach (var blob in container.GetBlobsAsync(BlobTraits.Metadata, BlobStates.None, prefix, cancellationToken))
            {
                if (IsDirectory(blob))
                {
                    continue;
                }

                files.Add(new WorkdayConcurFileIdentity
                {
                    Path = $"{containerName}/{blob.Name}",
                    ContentLength = blob.Properties.ContentLength ?? 0,
                    ETag = blob.Properties.ETag?.ToString() ?? string.Empty,
                    LastModifiedOn = blob.Properties.LastModified ?? default
                });
            }

            return files;
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileIdentity?> GetFileAsync(Uri serviceEndpoint, string containerName, string blobName, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(serviceEndpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(containerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(blobName);

            var blob = _clientFactory.Create(serviceEndpoint)
                .GetBlobContainerClient(containerName)
                .GetBlobClient(blobName);

            BlobProperties properties;

            try
            {
                properties = (await blob.GetPropertiesAsync(cancellationToken: cancellationToken)).Value;
            }
            catch (RequestFailedException exception) when (exception.Status == 404)
            {
                return null;
            }

            return new WorkdayConcurFileIdentity
            {
                Path = $"{containerName}/{blobName}",
                ContentLength = properties.ContentLength,
                ETag = properties.ETag.ToString(),
                LastModifiedOn = properties.LastModified
            };
        }

        /// <inheritdoc />
        public async Task<Stream> OpenReadAsync(Uri serviceEndpoint, string containerName, string blobName, string eTag, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(serviceEndpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(containerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(blobName);
            ArgumentException.ThrowIfNullOrWhiteSpace(eTag);

            var blob = _clientFactory.Create(serviceEndpoint)
                .GetBlobContainerClient(containerName)
                .GetBlobClient(blobName);

            var response = await blob.DownloadStreamingAsync(
                new BlobDownloadOptions
                {
                    Conditions = new BlobRequestConditions
                    {
                        IfMatch = new ETag(eTag)
                    }
                },
                cancellationToken);

            return response.Value.Content;
        }

        private static bool IsDirectory(BlobItem blob)
        {
            return blob.Name.EndsWith('/') || blob.Metadata.TryGetValue("hdi_isfolder", out var value) && bool.TryParse(value, out var isDirectory) && isDirectory;
        }
    }
}