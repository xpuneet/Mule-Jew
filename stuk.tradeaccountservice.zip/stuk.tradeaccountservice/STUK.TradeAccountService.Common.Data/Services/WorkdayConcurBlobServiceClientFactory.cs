using Azure.Core;
using Azure.Storage.Blobs;
using STUK.TradeAccountService.Common.Contracts.Interfaces;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Creates Blob service clients using the Function workload credential
    /// </summary>
    public class WorkdayConcurBlobServiceClientFactory : IWorkdayConcurBlobServiceClientFactory
    {
        private readonly TokenCredential _credential;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurBlobServiceClientFactory"/>
        /// </summary>
        /// <param name="credential">Azure workload credential</param>
        /// <exception cref="ArgumentNullException">Thrown when the credential is not supplied</exception>
        public WorkdayConcurBlobServiceClientFactory(TokenCredential credential)
        {
            _credential = credential ?? throw new ArgumentNullException(nameof(credential));
        }

        /// <inheritdoc />
        public BlobServiceClient Create(Uri serviceEndpoint)
        {
            ArgumentNullException.ThrowIfNull(serviceEndpoint);
            return new BlobServiceClient(serviceEndpoint, _credential);
        }
    }
}
