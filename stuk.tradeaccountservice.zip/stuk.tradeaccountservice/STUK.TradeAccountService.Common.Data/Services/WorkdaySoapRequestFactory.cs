using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using System.Globalization;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Creates the three source-derived Workday Get_Workers SOAP request shapes
    /// </summary>
    public class WorkdaySoapRequestFactory : IWorkdaySoapRequestFactory
    {
        private const string SoapNamespace = "http://schemas.xmlsoap.org/soap/envelope/";
        private const string WorkdayNamespace = "urn:com.workday/bsvc";
        private const string SecurityNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
        private const string PasswordTextType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText";
        private const string IntegrationFieldProvider = "INT029ConcurFields";
        private const string WorkdayVersion = "v40.0";
        private const string EmployeeIdType = "Employee_ID";
        private const string IntegrationSystemIdType = "Integration_System_ID";
        private const string PacificTimeZoneIana = "America/Los_Angeles";
        private const string PacificTimeZoneWindows = "Pacific Standard Time";
        private const string WorkdayDateTimeFormat = "yyyy-MM-dd'T'HH:mm:ss";

        private static readonly TimeZoneInfo PacificTimeZone = FindPacificTimeZone();
        private readonly WorkdayConcurOptions _options;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdaySoapRequestFactory"/>
        /// </summary>
        /// <param name="options">Workday-to-Concur integration settings</param>
        /// <exception cref="ArgumentNullException">Thrown when the settings are not supplied</exception>
        public WorkdaySoapRequestFactory(IOptions<WorkdayConcurOptions> options)
        {
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
        }

        /// <inheritdoc />
        public string CreateEffectiveWorkerRequest(DateTimeOffset from, DateTimeOffset through, int page, int pageSize)
        {
            Validate(from, through, page, pageSize);

            return CreateEnvelope(
                new XElement(WorkdayName("Get_Workers_Request"),
                    new XAttribute(WorkdayName("version"), WorkdayVersion),
                    CreateDateCriteria(
                        "Effective_From",
                        "Effective_Through",
                        FormatWorkdayBoundary(from),
                        FormatWorkdayBoundary(through),
                        includeProvider: true),
                    CreateFullResponseGroup(),
                    CreateResponseFilter(page, pageSize)));
        }

        /// <inheritdoc />
        public string CreateUpdatedWorkerRequest(DateTimeOffset from, DateTimeOffset through, int page, int pageSize)
        {
            Validate(from, through, page, pageSize);

            return CreateEnvelope(
                new XElement(WorkdayName("Get_Workers_Request"),
                    new XAttribute(WorkdayName("version"), WorkdayVersion),
                    CreateDateCriteria(
                        "Updated_From",
                        "Updated_Through",
                        FormatWorkdayBoundary(from),
                        FormatWorkdayBoundary(through),
                        includeProvider: false),
                    CreateReferenceOnlyResponseGroup(),
                    CreateResponseFilter(page, pageSize)));
        }

        /// <inheritdoc />
        public string CreateWorkerDetailRequest(IReadOnlyCollection<string> employeeIds, int page, int pageSize)
        {
            ArgumentNullException.ThrowIfNull(employeeIds);
            ValidateCredentialsAndPaging(page, pageSize);

            if (employeeIds.Count == 0 || employeeIds.Any(string.IsNullOrWhiteSpace))
            {
                throw new ArgumentException("At least one valid Workday employee identifier is required.", nameof(employeeIds));
            }

            return CreateEnvelope(
                new XElement(WorkdayName("Get_Workers_Request"),
                    new XAttribute(WorkdayName("version"), WorkdayVersion),
                    new XElement(WorkdayName("Request_References"),
                        employeeIds.Select(employeeId =>
                            new XElement(WorkdayName("Worker_Reference"),
                                new XElement(WorkdayName("ID"),
                                    new XAttribute(WorkdayName("type"), EmployeeIdType),
                                    employeeId)))),
                    CreateProviderCriteria(),
                    CreateFullResponseGroup(),
                    CreateResponseFilter(page, pageSize)));
        }

        private string CreateEnvelope(XElement requestBody)
        {
            XNamespace soap = SoapNamespace;
            XNamespace workday = WorkdayNamespace;
            XNamespace security = SecurityNamespace;

            var document = new XDocument(
                new XElement(soap + "Envelope",
                    new XAttribute(XNamespace.Xmlns + "soapenv", soap),
                    new XAttribute(XNamespace.Xmlns + "wd", workday),
                    new XAttribute(XNamespace.Xmlns + "wsse", security),
                    new XElement(soap + "Header",
                        new XElement(security + "Security",
                            new XAttribute(soap + "mustUnderstand", "1"),
                            new XElement(security + "UsernameToken",
                                new XElement(security + "Username", _options.WorkdayUsername),
                                new XElement(security + "Password",
                                    new XAttribute("Type", PasswordTextType),
                                    _options.WorkdayPassword)))),
                    new XElement(soap + "Body", requestBody)));

            return document.ToString(SaveOptions.DisableFormatting);
        }

        private static XElement CreateDateCriteria(string fromElement, string throughElement, string from, string through, bool includeProvider)
        {
            var requestCriteria = new XElement(WorkdayName("Request_Criteria"),
                new XElement(WorkdayName("Transaction_Log_Criteria_Data"),
                    new XElement(WorkdayName("Transaction_Date_Range_Data"),
                        new XElement(WorkdayName(fromElement), from),
                        new XElement(WorkdayName(throughElement), through))));

            if (includeProvider)
            {
                requestCriteria.Add(CreateProviderFieldCriteria());
            }

            return requestCriteria;
        }

        private static XElement CreateProviderCriteria()
        {
            return new XElement(WorkdayName("Request_Criteria"), CreateProviderFieldCriteria());
        }

        private static XElement CreateProviderFieldCriteria()
        {
            return new XElement(WorkdayName("Field_And_Parameter_Criteria_Data"),
                new XElement(WorkdayName("Provider_Reference"),
                    new XAttribute(WorkdayName("Descriptor"), IntegrationFieldProvider),
                    new XElement(WorkdayName("ID"),
                        new XAttribute(WorkdayName("type"), IntegrationSystemIdType),
                        IntegrationFieldProvider)));
        }

        private static XElement CreateFullResponseGroup()
        {
            return new XElement(WorkdayName("Response_Group"),
                CreateBooleanElement("Include_Reference", true),
                CreateBooleanElement("Include_Personal_Information", true),
                CreateBooleanElement("Show_All_Personal_Information", true),
                CreateBooleanElement("Include_Employee_Contract_Data", true),
                CreateBooleanElement("Include_Organizations", true),
                CreateBooleanElement("Include_Management_Chain_Data", true),
                CreateBooleanElement("Include_Compensation", true),
                CreateBooleanElement("Include_Employment_Information", true));
        }

        private static XElement CreateReferenceOnlyResponseGroup()
        {
            return new XElement(WorkdayName("Response_Group"),
                CreateBooleanElement("Include_Reference", true),
                CreateBooleanElement("Include_Personal_Information", false),
                CreateBooleanElement("Show_All_Personal_Information", false),
                CreateBooleanElement("Include_Employee_Contract_Data", false),
                CreateBooleanElement("Include_Organizations", false),
                CreateBooleanElement("Include_Management_Chain_Data", false),
                CreateBooleanElement("Include_Compensation", false),
                CreateBooleanElement("Include_Employment_Information", false));
        }

        private static XElement CreateResponseFilter(int page, int pageSize)
        {
            return new XElement(WorkdayName("Response_Filter"),
                new XElement(WorkdayName("Page"), page),
                new XElement(WorkdayName("Count"), pageSize));
        }

        private static XElement CreateBooleanElement(string name, bool value)
        {
            return new XElement(WorkdayName(name), value.ToString().ToLowerInvariant());
        }

        private static XName WorkdayName(string localName)
        {
            return XName.Get(localName, WorkdayNamespace);
        }

        private static string FormatWorkdayBoundary(DateTimeOffset value)
        {
            return TimeZoneInfo.ConvertTime(value, PacificTimeZone).ToString(WorkdayDateTimeFormat, CultureInfo.InvariantCulture);
        }

        private static TimeZoneInfo FindPacificTimeZone()
        {
            if (TimeZoneInfo.TryFindSystemTimeZoneById(PacificTimeZoneIana, out var timeZone))
            {
                return timeZone;
            }

            return TimeZoneInfo.FindSystemTimeZoneById(PacificTimeZoneWindows);
        }

        private void Validate(DateTimeOffset from, DateTimeOffset through, int page, int pageSize)
        {
            if (through < from)
            {
                throw new ArgumentException("The Workday integration window cannot end before it starts.", nameof(through));
            }

            ValidateCredentialsAndPaging(page, pageSize);
        }

        private void ValidateCredentialsAndPaging(int page, int pageSize)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.WorkdayUsername);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.WorkdayPassword);

            if (page <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(page), "The Workday page must be greater than zero.");
            }

            if (pageSize <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(pageSize), "The Workday page size must be greater than zero.");
            }
        }
    }
}
