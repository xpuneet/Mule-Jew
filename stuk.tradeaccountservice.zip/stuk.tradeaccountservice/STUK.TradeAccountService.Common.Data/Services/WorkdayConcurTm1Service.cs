using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Starts the managed TM1 SFTP-to-Blob pipeline and validates input/TM1.csv
    /// </summary>
    public class WorkdayConcurTm1Service : IWorkdayConcurTm1Service
    {
        private const string ExpectedPipelineName = "SFTP_To_Blob";
        private const string ExpectedSourceFolder = "/prod/tm1serv/Exports";
        private const string ExpectedFileName = "TM1.csv";
        private const string ExpectedDestinationFolder = "input";
        private const string InProgressStatus = "InProgress";
        private const string ValidationFailedStatus = "ValidationFailed";

        private readonly IFileTransferConfigurationService _configurationService;
        private readonly ISynapsePipelineClient _synapseClient;
        private readonly IWorkdayConcurBlobClient _blobClient;
        private readonly WorkdayConcurOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurTm1Service"/>
        /// </summary>
        /// <param name="configurationService">Managed transfer configuration service</param>
        /// <param name="synapseClient">Azure Synapse pipeline client</param>
        /// <param name="blobClient">Destination Blob validation client</param>
        /// <param name="options">Workday-to-Concur settings</param>
        /// <param name="timeProvider">Provides deterministic UTC timestamps</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayConcurTm1Service(
            IFileTransferConfigurationService configurationService,
            ISynapsePipelineClient synapseClient,
            IWorkdayConcurBlobClient blobClient,
            IOptions<WorkdayConcurOptions> options,
            TimeProvider timeProvider)
        {
            _configurationService = configurationService ?? throw new ArgumentNullException(nameof(configurationService));
            _synapseClient = synapseClient ?? throw new ArgumentNullException(nameof(synapseClient));
            _blobClient = blobClient ?? throw new ArgumentNullException(nameof(blobClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurTm1Checkpoint> StartAsync(Guid correlationId, CancellationToken cancellationToken = default)
        {
            if (correlationId == Guid.Empty)
            {
                throw new ArgumentException("A Workday-to-Concur correlation identifier is required", nameof(correlationId));
            }

            ValidateOptions();

            var configuration = await _configurationService.GetTm1PickupAsync(
                _options.Tm1PickupIntegrationKeyId,
                _options.Tm1PickupActionName,
                cancellationToken);

            ValidateTransferConfiguration(configuration);

            var startedOn = _timeProvider.GetUtcNow();
            var parameters = CreateParameters(configuration, correlationId);

            var runId = await _synapseClient.StartAsync(configuration.Action.PipeLineName, parameters, cancellationToken);

            return new WorkdayConcurTm1Checkpoint
            {
                SynapseRunId = runId,
                StartedOn = startedOn,
                BlobServiceEndpoint = configuration.Blob.ServiceEndPoint,
                DestinationContainer = _options.ConcurBlobContainerName,
                DestinationBlobName = $"{ExpectedDestinationFolder}/{ExpectedFileName}",
                Status = InProgressStatus
            };
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurTm1Checkpoint> CompleteAsync(WorkdayConcurTm1Checkpoint checkpoint, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(checkpoint);
            ValidateCheckpoint(checkpoint);

            var run = await _synapseClient.WaitForCompletionAsync(checkpoint.SynapseRunId, cancellationToken);

            if (!string.Equals(run.Status, "Succeeded", StringComparison.OrdinalIgnoreCase))
            {
                checkpoint.Status = run.Status;
                checkpoint.CompletedOn = _timeProvider.GetUtcNow();
                checkpoint.FailureMessage = string.IsNullOrWhiteSpace(run.Message)
                    ? $"Synapse TM1 pickup ended with status '{run.Status}'"
                    : run.Message;
                return checkpoint;
            }

            try
            {
                checkpoint.File = await _blobClient.GetRequiredFreshFileAsync(
                    new Uri(checkpoint.BlobServiceEndpoint, UriKind.Absolute),
                    checkpoint.DestinationContainer,
                    checkpoint.DestinationBlobName,
                    checkpoint.StartedOn,
                    cancellationToken);

                checkpoint.Status = "Succeeded";
                checkpoint.CompletedOn = _timeProvider.GetUtcNow();
                checkpoint.FailureMessage = null;
            }
            catch (Exception exception) when (exception is FileNotFoundException or InvalidDataException)
            {
                checkpoint.Status = ValidationFailedStatus;
                checkpoint.CompletedOn = _timeProvider.GetUtcNow();
                checkpoint.FailureMessage = exception.Message;
            }

            return checkpoint;
        }

        private IReadOnlyDictionary<string, object?> CreateParameters(WorkdayConcurTm1TransferConfiguration configuration, Guid correlationId)
        {
            var action = configuration.Action;
            return new Dictionary<string, object?>
            {
                ["Id"] = correlationId.ToString("D"),
                ["CorrelationID"] = correlationId.ToString("D"),
                ["SourceHost"] = configuration.Sftp.IpAddress,
                ["SourceUsername"] = configuration.Sftp.Username,
                ["SourcePassword"] = configuration.Sftp.PasswordKey,
                ["SourceFilePath"] = ExpectedSourceFolder,
                ["FileStartFilter"] = ExpectedFileName,
                ["FileEndFilter"] = ExpectedFileName,
                ["FileContainsFilter"] = ExpectedFileName,
                ["DestinationStorageAccountEndPoint"] = configuration.Blob.ServiceEndPoint,
                ["DestinationFilePath"] = GetExpectedDestinationPath(),
                ["DestinationFileFormat"] = ExpectedFileName,
                ["ArchivePath"] = action.SourceArchivePath,
                ["IsArchive"] = action.SourceArchive ?? false,
                ["ErrorPath"] = action.SourceErrorPath,
                ["SourceDelete"] = action.SourceDelete ?? false,
                ["TriggeredByFnApp"] = "stuk.tradeaccountservice",
                ["TriggeredBySchedulerName"] = "WorkdayConcurTimerFunction",
                ["IsErrorArchiveFileNameChange"] = false,
                ["ErrorArchiveFileName"] = null,
                ["IsArchiveBlankFiles"] = false,
                ["IsTokenRequired"] = false,
                ["TokenName"] = null,
                ["TokenFilePath"] = null,
                ["FileAction"] = _options.Tm1PickupActionName
            };
        }

        private void ValidateOptions()
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.Tm1PickupIntegrationKeyId);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.Tm1PickupActionName);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurBlobContainerName);
        }

        private void ValidateTransferConfiguration(WorkdayConcurTm1TransferConfiguration configuration)
        {
            ArgumentNullException.ThrowIfNull(configuration);

            var action = configuration.Action ?? throw new InvalidOperationException("The TM1 File Transfer action is missing");
            var sftp = configuration.Sftp ?? throw new InvalidOperationException("The TM1 SFTP configuration is missing");
            var blob = configuration.Blob ?? throw new InvalidOperationException("The TM1 Blob configuration is missing");

            if (!string.Equals(action.PipeLineName, ExpectedPipelineName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"TM1 pickup must use the managed '{ExpectedPipelineName}' pipeline");
            }

            if (!NormalisePath(action.SourceFolderPath).Equals(ExpectedSourceFolder, StringComparison.OrdinalIgnoreCase)
                || !string.Equals(action.SourceFileNameFormat, ExpectedFileName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("TM1 pickup must select only '/prod/tm1serv/Exports/TM1.csv'");
            }

            if (!NormalisePath(action.DestinationFolderPath).Equals(GetExpectedDestinationPath(), StringComparison.OrdinalIgnoreCase)
                || !string.Equals(action.DestinationFileNameFormat, ExpectedFileName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"TM1 pickup must write only '{GetExpectedDestinationPath()}/{ExpectedFileName}'");
            }

            ArgumentException.ThrowIfNullOrWhiteSpace(sftp.IpAddress);
            ArgumentException.ThrowIfNullOrWhiteSpace(sftp.Username);
            ArgumentException.ThrowIfNullOrWhiteSpace(sftp.PasswordKey);
            if (!Uri.TryCreate(blob.ServiceEndPoint, UriKind.Absolute, out var endpoint) || endpoint.Scheme != Uri.UriSchemeHttps)
            {
                throw new InvalidOperationException("The TM1 destination Blob service endpoint must be an absolute HTTPS URI");
            }
        }

        private static void ValidateCheckpoint(WorkdayConcurTm1Checkpoint checkpoint)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.SynapseRunId);
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.BlobServiceEndpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.DestinationContainer);
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.DestinationBlobName);
        }

        private static string NormalisePath(string? path)
        {
            return (path ?? string.Empty).Trim().TrimEnd('/');
        }

        private string GetExpectedDestinationPath()
        {
            return $"{_options.ConcurBlobContainerName.Trim().Trim('/')}/{ExpectedDestinationFolder}";
        }
    }
}
