using Azure;
using Azure.Storage.Files.DataLake;
using Azure.Storage.Files.DataLake.Models;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Writes complete ConsXref datasets and completion tokens directly to ADLS Gen2
    /// </summary>
    public class DataLakeExportClient : IDataLakeExportClient
    {
        private readonly Func<DataLakeServiceClient> _dataLakeServiceClientFactory;

        /// <summary>
        /// Initialises a new instance of the <see cref="DataLakeExportClient"/>
        /// </summary>
        /// <param name="dataLakeServiceClientFactory">Creates the workload-identity authenticated ADLS Gen2 client when delivery starts</param>
        /// <exception cref="ArgumentNullException">Thrown when the Data Lake client factory is not supplied</exception>
        public DataLakeExportClient(Func<DataLakeServiceClient> dataLakeServiceClientFactory)
        {
            _dataLakeServiceClientFactory = dataLakeServiceClientFactory ?? throw new ArgumentNullException(nameof(dataLakeServiceClientFactory));
        }

        /// <inheritdoc />
        public async Task<DataLakeExportWriteResult> WriteAsync(
            DataLakeExportWriteRequest request,
            Stream datasetContent,
            CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(request);
            ArgumentNullException.ThrowIfNull(datasetContent);
            Validate(request, datasetContent);

            var fileSystem = _dataLakeServiceClientFactory().GetFileSystemClient(request.FileSystem);
            var datasetPath = CombinePath(request.DatasetDirectory, request.DatasetFileName);
            var tokenPath = CombinePath(request.TokenDirectory, request.TokenFileName);
            var dataset = fileSystem.GetFileClient(datasetPath);
            var datasetAlreadyExists = false;
            var existing = await TryGetPropertiesAsync(dataset, cancellationToken);

            if (existing is not null)
            {
                ValidateMatchingDataset(request, datasetPath, existing);
                datasetAlreadyExists = true;
            }
            else
            {
                datasetContent.Position = 0;
                var metadata = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                {
                    ["CorrelationID"] = request.CorrelationId.ToString("D", CultureInfo.InvariantCulture),
                    ["ExportRunID"] = request.ExportRunId.ToString("D", CultureInfo.InvariantCulture),
                    ["ExportDestinationID"] = request.ExportDestinationId.ToString("D", CultureInfo.InvariantCulture),
                    ["ContentHash"] = request.ContentHash,
                    ["RowCount"] = request.RowCount.ToString(CultureInfo.InvariantCulture)
                };

                try
                {
                    await dataset.UploadAsync(
                        datasetContent,
                        new DataLakeFileUploadOptions
                        {
                            Conditions = new DataLakeRequestConditions { IfNoneMatch = ETag.All },
                            Metadata = metadata
                        },
                        cancellationToken);
                }
                catch (RequestFailedException exception) when (exception.Status is 409 or 412)
                {
                    existing = await TryGetPropertiesAsync(dataset, cancellationToken);
                    if (existing is null)
                    {
                        throw;
                    }

                    ValidateMatchingDataset(request, datasetPath, existing);
                    datasetAlreadyExists = true;
                }
            }

            var token = fileSystem.GetFileClient(tokenPath);
            var existingToken = await TryGetPropertiesAsync(token, cancellationToken);
            if (!IsMatchingToken(request, existingToken))
            {
                await using var tokenContent = new MemoryStream(request.TokenContent, writable: false);
                await token.UploadAsync(
                    tokenContent,
                    new DataLakeFileUploadOptions
                    {
                        Metadata = CreateCorrelationMetadata(request)
                    },
                    cancellationToken);
            }

            return new DataLakeExportWriteResult
            {
                DatasetPath = $"{request.FileSystem}/{datasetPath}",
                TokenPath = $"{request.FileSystem}/{tokenPath}",
                DatasetAlreadyExists = datasetAlreadyExists
            };
        }

        private static Dictionary<string, string> CreateCorrelationMetadata(DataLakeExportWriteRequest request)
        {
            return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                ["CorrelationID"] = request.CorrelationId.ToString("D", CultureInfo.InvariantCulture),
                ["ExportRunID"] = request.ExportRunId.ToString("D", CultureInfo.InvariantCulture),
                ["ExportDestinationID"] = request.ExportDestinationId.ToString("D", CultureInfo.InvariantCulture),
                ["ContentHash"] = request.ContentHash,
                ["RowCount"] = request.RowCount.ToString(CultureInfo.InvariantCulture)
            };
        }

        private static bool IsMatchingToken(DataLakeExportWriteRequest request, PathProperties? properties)
        {
            if (properties is null || properties.ContentLength != request.TokenContent.LongLength)
            {
                return false;
            }

            return properties.Metadata.TryGetValue("ExportRunID", out var runId)
                && string.Equals(runId, request.ExportRunId.ToString("D", CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase)
                && properties.Metadata.TryGetValue("ExportDestinationID", out var destinationId)
                && string.Equals(destinationId, request.ExportDestinationId.ToString("D", CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
        }

        private static async Task<PathProperties?> TryGetPropertiesAsync(
            DataLakeFileClient file,
            CancellationToken cancellationToken)
        {
            try
            {
                return (await file.GetPropertiesAsync(cancellationToken: cancellationToken)).Value;
            }
            catch (RequestFailedException exception) when (exception.Status == 404)
            {
                return null;
            }
        }

        private static void ValidateMatchingDataset(
            DataLakeExportWriteRequest request,
            string datasetPath,
            PathProperties properties)
        {
            var matchesRun = properties.Metadata.TryGetValue("ExportRunID", out var runId)
                && string.Equals(runId, request.ExportRunId.ToString("D", CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
            var matchesDestination = properties.Metadata.TryGetValue("ExportDestinationID", out var destinationId)
                && string.Equals(destinationId, request.ExportDestinationId.ToString("D", CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
            var matchesHash = properties.Metadata.TryGetValue("ContentHash", out var hash)
                && string.Equals(hash, request.ContentHash, StringComparison.OrdinalIgnoreCase);

            if (!matchesRun || !matchesDestination || !matchesHash || properties.ContentLength != request.ContentLength)
            {
                throw new InvalidDataException($"The Data Lake dataset '{datasetPath}' is occupied by different export content.");
            }
        }

        private static string CombinePath(string directory, string fileName)
        {
            return $"{directory.Trim().Trim('/')}/{fileName.Trim().Trim('/')}";
        }

        private static void Validate(DataLakeExportWriteRequest request, Stream datasetContent)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(request.FileSystem);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.DatasetDirectory);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.DatasetFileName);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.TokenDirectory);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.TokenFileName);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.ContentHash);

            if (request.ExportRunId == Guid.Empty || request.ExportDestinationId == Guid.Empty || request.CorrelationId == Guid.Empty)
            {
                throw new ArgumentException("The export, destination and correlation identifiers are required.", nameof(request));
            }

            if (request.ContentLength < 0 || request.RowCount < 0 || request.TokenContent.Length == 0)
            {
                throw new ArgumentException("The dataset evidence and completion token are required.", nameof(request));
            }

            if (!datasetContent.CanRead || !datasetContent.CanSeek || datasetContent.Length != request.ContentLength)
            {
                throw new InvalidDataException("The generated dataset stream does not match its content evidence.");
            }
        }
    }
}
