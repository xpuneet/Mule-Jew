using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides stored-procedure access to durable Workday-to-Concur run state
    /// </summary>
    public class WorkdayConcurStateService : IWorkdayConcurStateService
    {
        private readonly IDbExecutor _dbExecutor;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurStateService"/>
        /// </summary>
        /// <param name="dbExecutor">The keyed Trade Account Service database executor</param>
        /// <exception cref="ArgumentNullException">Thrown when the database executor is not supplied</exception>
        public WorkdayConcurStateService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurRun?> CreateOrResumeRunAsync(Guid correlationId, string leaseOwner, DateTimeOffset extractThrough, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<WorkdayConcurRun>(StoredProcedures.CreateWorkdayConcurRun, new
            {
                correlationId,
                leaseOwner,
                extractThrough,
                leaseDurationSeconds,
                now
            });
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurRun?> GetIncompleteRunAsync(CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<WorkdayConcurRun>(StoredProcedures.GetIncompleteWorkdayConcurRun, new { });
        }

        /// <inheritdoc />
        public async Task RenewLeaseAsync(Guid runId, Guid claimToken, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(StoredProcedures.RenewWorkdayConcurRunLease, new
            {
                runId,
                claimToken,
                leaseDurationSeconds,
                now
            });
        }

        /// <inheritdoc />
        public async Task UpdateStageAsync(
            Guid runId,
            Guid claimToken,
            WorkdayConcurRunStage expectedStage,
            WorkdayConcurRunStage newStage,
            string? fileStateJson = null,
            string? tm1SynapseRunId = null,
            string? transformSynapseRunId = null,
            string? deliverySynapseRunId = null,
            string? housekeepingSynapseRunId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(
                StoredProcedures.UpdateWorkdayConcurRunStage,
                new
                {
                    runId,
                    claimToken,
                    expectedStage = expectedStage.ToString(),
                    newStage = newStage.ToString(),
                    fileStateJson,
                    tm1SynapseRunId,
                    transformSynapseRunId,
                    deliverySynapseRunId,
                    housekeepingSynapseRunId,
                    now
                });
        }

        /// <inheritdoc />
        public async Task FailRunAsync(
            Guid runId,
            Guid claimToken,
            string errorCategory,
            string errorMessage,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(errorCategory);
            ArgumentException.ThrowIfNullOrWhiteSpace(errorMessage);
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(
                StoredProcedures.FailWorkdayConcurRun,
                new { runId, claimToken, errorCategory, errorMessage, now });
        }

        /// <inheritdoc />
        public async Task ReleaseLeaseAsync(Guid runId, Guid claimToken, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(StoredProcedures.ReleaseWorkdayConcurRunLease, new
            {
                runId,
                claimToken,
                now
            });
        }

        /// <inheritdoc />
        public async Task CompleteNoDataRunAsync(Guid runId, Guid claimToken, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(StoredProcedures.CompleteWorkdayConcurNoDataRun, new
            {
                runId,
                claimToken,
                now
            });
        }

        /// <inheritdoc />
        public async Task CommitRunAsync(Guid runId, Guid claimToken, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(StoredProcedures.CommitWorkdayConcurRun, new
            {
                runId,
                claimToken,
                now
            });
        }
    }
}
