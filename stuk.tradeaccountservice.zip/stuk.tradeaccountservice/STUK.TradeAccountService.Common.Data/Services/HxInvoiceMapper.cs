using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Maps HX consolidated invoice data into the canonical Consolidated Sales model
    /// </summary>
    public class HxInvoiceMapper : IHxInvoiceMapper
    {
        private const string TextProductCode = "TEXT";

        /// <inheritdoc />
        public ConsolidatedSalesInvoice Map(HxInvoiceDto source, Guid correlationId)
        {
            ArgumentNullException.ThrowIfNull(source);

            var invoiceNumber = RequiredValue(
                source.References.SuppliersInvoiceNumber,
                "The HX supplier invoice number is required to map a consolidated invoice.");

            var mappedLines = source.Lines
                .Select((line, index) => MapLine(line, invoiceNumber, index + 1))
                .ToList();

            EnsureUniqueLineIdentities(mappedLines);

            return new ConsolidatedSalesInvoice
            {
                CorrelationId = correlationId,
                ConsolidatedInvoiceNumber = invoiceNumber,
                InvoiceTypeCode = source.Header.InvoiceType?.Code,
                InvoiceTypeDescription = source.Header.InvoiceType?.Description,
                InvoiceDate = source.InvoiceDate,
                TaxPointDate = source.TaxPointDate,
                BuyersOrderNumber = source.References.BuyersOrderNumber,
                SourceSuppliersInvoiceNumber = source.References.SuppliersInvoiceNumber,
                DeliveryNoteNumber = source.References.DeliveryNoteNumber,
                SuppliersOrderReference = source.References.SuppliersOrderReference,
                CustomerAccountCode = source.InvoiceTo?.AccountCode,
                DocumentBrandCode = source.Consolidated?.DocumentBrand?.Code,
                DocumentBrandDescription = source.Consolidated?.DocumentBrand?.Description,
                SupplierBranchCode = source.Consolidated?.SupplierBranch?.Code,
                SupplierBranchDescription = source.Consolidated?.SupplierBranch?.Description,
                CurrencyCode = source.Header.Currency?.Code,
                CurrencyDescription = source.Header.Currency?.Description,
                CreditTermsCode = source.Consolidated?.CreditTerms?.Code,
                CreditTermsDescription = source.Consolidated?.CreditTerms?.Description,
                ExpectedLineCount = mappedLines.Count,
                NumberOfTaxRates = source.Totals?.NumberOfTaxRates,
                LineValueTotal = source.Totals?.LineValueTotal,
                TaxableTotal = source.Totals?.TaxableTotal,
                TaxTotal = source.Totals?.TaxTotal,
                NetPaymentTotal = source.Totals?.NetPaymentTotal,
                GrossPaymentTotal = source.Totals?.GrossPaymentTotal,
                Parties = MapParties(source),
                Components = MapComponents(source.Lines),
                Lines = mappedLines,
                TaxSubTotals = source.TaxSubTotals.Select(MapTaxSubTotal).ToList()
            };
        }

        private static List<ConsolidatedSalesInvoiceParty> MapParties(HxInvoiceDto source)
        {
            var parties = new List<ConsolidatedSalesInvoiceParty>();
            AddParty(parties, "Supplier", source.Supplier);
            AddParty(parties, "Buyer", source.Buyer);
            AddParty(parties, "InvoiceTo", source.InvoiceTo);
            return parties;
        }

        private static void AddParty(List<ConsolidatedSalesInvoiceParty> parties, string role, HxPartyDto? source)
        {
            if (source is null)
            {
                return;
            }

            parties.Add(new ConsolidatedSalesInvoiceParty
            {
                PartyRole = role,
                AccountCode = source.AccountCode,
                PartyName = source.Name,
                AddressLinesJson = SerialiseAddressLines(source.Address?.AddressLines),
                AddressLine1 = AddressLine(source.Address, 0),
                AddressLine2 = AddressLine(source.Address, 1),
                AddressLine3 = AddressLine(source.Address, 2),
                AddressLine4 = AddressLine(source.Address, 3),
                Street = source.Address?.Street,
                City = source.Address?.City,
                State = source.Address?.State,
                Postcode = source.Address?.PostCode
            });
        }

        private static List<ConsolidatedSalesInvoiceComponent> MapComponents(IEnumerable<HxInvoiceLineDto> lines)
        {
            return lines
                .Where(line => !string.IsNullOrWhiteSpace(line.References.DeliveryNoteNumber))
                .GroupBy(line => line.References.DeliveryNoteNumber!, StringComparer.Ordinal)
                .Select(group =>
                {
                    var first = group.First();
                    var (branchCode, invoiceNumber) = SplitDeliveryNoteNumber(group.Key);

                    return new ConsolidatedSalesInvoiceComponent
                    {
                        ComponentReferenceKey = group.Key,
                        StandardInvoiceNumber = invoiceNumber,
                        BranchCode = branchCode,
                        DeliveryNoteNumber = group.Key,
                        BuyersOrderNumber = first.Consolidated?.BuyersOrderNumber,
                        SuppliersOrderReference = first.Consolidated?.SuppliersOrderReference
                    };
                })
                .ToList();
        }

        private static ConsolidatedSalesInvoiceLine MapLine(HxInvoiceLineDto source, string invoiceNumber, int sequence)
        {
            var sourceLineNumber = RequiredValue(source.LineNumber, $"HX invoice line {sequence} does not contain a line number.");
            var customerInformation = source.Consolidated?.CustomerInformation;
            var jobAddress = customerInformation?.JobAddress;
            var isTextLine = source.Consolidated?.DocumentTextLine == true;

            return new ConsolidatedSalesInvoiceLine
            {
                ComponentReferenceKey = NullIfWhiteSpace(source.References.DeliveryNoteNumber),
                LineIdentity = sourceLineNumber,
                SalesforceExternalId = string.Concat(invoiceNumber, sourceLineNumber),
                LineSequence = sequence,
                SourceLineNumber = source.LineNumber,
                PreserveLineNumber = source.PreserveLineNumber,
                SourceAction = source.Action,
                OrderLineNumber = source.References.OrderLineNumber,
                OriginalOrderLineNumber = source.Consolidated?.OriginalOrderLineNumber,
                DeliveryNoteNumber = source.References.DeliveryNoteNumber,
                DeliveryNoteLineNumber = source.References.DeliveryNoteLineNumber,
                BuyersOrderNumber = source.Consolidated?.BuyersOrderNumber,
                SuppliersOrderReference = source.Consolidated?.SuppliersOrderReference,
                SupplierDespatchDate = source.Consolidated?.SupplierDespatchDate,
                SupplierCodeForDelivery = source.Consolidated?.SupplierCodeForDelivery,
                OrderTypeCode = source.Consolidated?.SupplierOrderFlags?.OrderType?.Code,
                OrderTypeDescription = source.Consolidated?.SupplierOrderFlags?.OrderType?.Description,
                OrderCategoryCode = source.Consolidated?.SupplierOrderFlags?.OrderCategory?.Code,
                OrderCategoryDescription = source.Consolidated?.SupplierOrderFlags?.OrderCategory?.Description,
                DeliveryMethodCode = source.Consolidated?.SupplierOrderFlags?.DeliveryMethod?.Code,
                DeliveryMethodDescription = source.Consolidated?.SupplierOrderFlags?.DeliveryMethod?.Description,
                SupplierPartAnalysisCode = source.Consolidated?.SupplierPartAnalysisCode,
                IsSpecialProduct = source.Consolidated?.SpecialProduct,
                IsTextLine = isTextLine,
                ProductCode = isTextLine ? TextProductCode : source.Product?.SuppliersProductCode,
                ProductDescription = source.Product?.Description,
                Quantity = isTextLine ? 1 : source.Quantity?.Amount,
                QuantityUomCode = source.Quantity?.UomCode,
                QuantityUomDescription = source.Quantity?.UomDescription,
                UnitPrice = isTextLine ? 0 : source.Price?.UnitPrice,
                PriceUomCode = source.Price?.UomCode,
                PriceUomDescription = source.Price?.UnitPrice?.ToString(CultureInfo.InvariantCulture),
                PercentageDiscount = source.PercentageDiscount,
                TaxRateCode = source.Tax?.TaxRate?.Code,
                TaxRate = source.Tax?.TaxRate?.Value,
                TaxValue = source.Tax?.TaxValue,
                LineTotal = source.LineTotal,
                JobNumber = customerInformation?.JobNumber,
                ContractNumber = customerInformation?.ContractNumber,
                BuyerLocation = customerInformation?.BuyerLocation,
                Operative = customerInformation?.Operative,
                SiteCode = customerInformation?.SiteCode,
                PlotNumber = customerInformation?.PlotNumber,
                VehicleRegistration = customerInformation?.VehicleRegistration,
                HouseType = customerInformation?.HouseType,
                ProductGroup = customerInformation?.ProductGroup,
                OrderAuthorised = customerInformation?.OrderAuthorised,
                JobAddressLinesJson = SerialiseAddressLines(jobAddress?.AddressLines),
                JobAddressLine1 = AddressLine(jobAddress, 0),
                JobAddressLine2 = AddressLine(jobAddress, 1),
                JobAddressLine3 = AddressLine(jobAddress, 2),
                JobAddressLine4 = AddressLine(jobAddress, 3),
                JobStreet = jobAddress?.Street,
                JobCity = jobAddress?.City,
                JobState = jobAddress?.State,
                JobPostcode = jobAddress?.PostCode
            };
        }

        private static ConsolidatedSalesTaxSubTotal MapTaxSubTotal(HxTaxSubTotalDto source)
        {
            return new ConsolidatedSalesTaxSubTotal
            {
                TaxRateCode = source.TaxRate?.Code,
                TaxRate = source.TaxRate?.Value,
                NumberOfLinesAtRate = source.NumberOfLinesAtRate,
                TotalValueAtRate = source.TotalValueAtRate,
                TaxableValueAtRate = source.TaxableValueAtRate,
                TaxAtRate = source.TaxAtRate,
                NetPaymentAtRate = source.NetPaymentAtRate,
                GrossPaymentAtRate = source.GrossPaymentAtRate
            };
        }

        private static (string? BranchCode, string StandardInvoiceNumber) SplitDeliveryNoteNumber(string deliveryNoteNumber)
        {
            var separatorIndex = deliveryNoteNumber.IndexOf('/');
            return separatorIndex > 0 && separatorIndex < deliveryNoteNumber.Length - 1
                ? (deliveryNoteNumber[..separatorIndex], deliveryNoteNumber[(separatorIndex + 1)..])
                : (null, deliveryNoteNumber);
        }

        private static string? AddressLine(HxAddressDto? address, int index)
        {
            return address is not null && address.AddressLines.Count > index
                ? address.AddressLines[index]
                : null;
        }

        private static string? SerialiseAddressLines(List<string>? addressLines)
        {
            return addressLines is { Count: > 0 }
                ? JsonSerializer.Serialize(addressLines)
                : null;
        }

        private static string RequiredValue(string? value, string message)
        {
            return !string.IsNullOrWhiteSpace(value)
                ? value
                : throw new InvalidDataException(message);
        }

        private static string? NullIfWhiteSpace(string? value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value;
        }

        private static void EnsureUniqueLineIdentities(IEnumerable<ConsolidatedSalesInvoiceLine> lines)
        {
            if (lines.GroupBy(line => line.LineIdentity, StringComparer.Ordinal).Any(group => group.Count() > 1))
            {
                throw new InvalidDataException("HX line numbers must be unique within a consolidated invoice.");
            }
        }
    }
}
