﻿using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Xml;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public static class StatementXmlParser
    {
        private static readonly XNamespace Ns = "http://xml.kerridgecs.net/K809/k8Statement";
        private static readonly XNamespace NsExt = "http://xml.kerridgecs.net/K809/k8StatementExtensions";

        public static async IAsyncEnumerable<StatementHeaderData> ParseAsync(
            Stream xmlStream,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            using var reader = XmlReader.Create(xmlStream, new XmlReaderSettings { Async = true });

            // Navigate into the <body> element
            var foundBody = false;
            while (await reader.ReadAsync())
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (reader.NodeType == XmlNodeType.Element &&
                    reader.LocalName == "body" &&
                    reader.NamespaceURI == Ns.NamespaceName)
                {
                    foundBody = true;
                    break;
                }
            }

            if (!foundBody)
                throw new InvalidOperationException("XML does not contain a <body> element.");

            // Stream through <Statement> elements one at a time
            while (await reader.ReadAsync())
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (reader.NodeType == XmlNodeType.Element &&
                    reader.LocalName == "Statement" &&
                    reader.NamespaceURI == Ns.NamespaceName)
                {
                    var statementEl = (XElement)await XNode.ReadFromAsync(reader, cancellationToken);
                    yield return ParseStatement(statementEl);
                }
            }
        }

        private static StatementHeaderData ParseStatement(XElement statementEl)
        {
            var head = statementEl.Element(Ns + "StatementHead")
                ?? throw new InvalidOperationException("Statement is missing <StatementHead>.");
            var trailer = statementEl.Element(Ns + "StatementTrailer");
            var trailerExt = trailer?.Element(Ns + "Extensions")?.Element(NsExt + "HXStatementTrailer");

            var accountEl = head.Element(Ns + "Account");
            var currencyEl = head.Element(Ns + "StatementCurrency")?.Element(Ns + "Currency");

            var header = new StatementHeaderData
            {
                AccountCode = accountEl?.Attribute("code")?.Value
                    ?? throw new InvalidOperationException("Statement is missing Account code."),
                OwningBranch = accountEl?.Element(Ns + "OwningBranch")?.Value,
                StatementDate = ParseDate(head.Element(Ns + "StatementDate")?.Value),
                StatementMonth = head.Element(Ns + "StatementMonth")?.Value,
                EndOfNextMonth = ParseDateNullable(head.Element(Ns + "EndOfNextMonth")?.Value),
                CurrencyCode = currencyEl?.Attribute("code")?.Value ?? throw new InvalidOperationException("Statement is missing Currency code."),
                LineCount = ParseIntNullable(trailer?.Element(Ns + "LineCount")?.Value),
                TotalVAT = ParseDecimalNullable(trailer?.Element(Ns + "TotalVAT")?.Value),
                SettDiscountTotal = ParseDecimalNullable(trailer?.Element(Ns + "SettDiscountTotal")?.Value),
                StatementTotal = ParseDecimalNullable(trailer?.Element(Ns + "StatementTotal")?.Value),
                StatementDiscountTotal = ParseDecimalNullable(trailer?.Element(Ns + "StatementDiscountTotal")?.Value),
                QueriedBalance = ParseDecimalNullable(trailerExt?.Element(NsExt + "QueriedBalance")?.Value),
                BalanceAfterQueries = ParseDecimalNullable(trailerExt?.Element(NsExt + "BalanceAfterQueries")?.Value),
                VATThisPeriod = ParseDecimalNullable(trailerExt?.Element(NsExt + "VATThisPeriod")?.Value)
            };

            return header;
        }

        private static DateTime ParseDate(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new InvalidOperationException("Required date value is missing or empty.");
            return DateTime.Parse(value, CultureInfo.InvariantCulture);
        }

        private static DateTime? ParseDateNullable(string? value) =>
            string.IsNullOrWhiteSpace(value) ? null : DateTime.Parse(value, CultureInfo.InvariantCulture);

        private static decimal? ParseDecimalNullable(string? value) =>
            string.IsNullOrWhiteSpace(value) ? null : decimal.Parse(value, CultureInfo.InvariantCulture);

        private static int? ParseIntNullable(string? value) =>
            string.IsNullOrWhiteSpace(value) ? null : int.Parse(value, CultureInfo.InvariantCulture);

        public static List<StatementMetadataData> BuildMetadata(
            List<StatementHeaderData> batch,
            string? originalFileName = null,
            string? extension = null,
            string? contentMd5 = null,
            long? contentLength = null,
            string? blobUri = null,
            string? createdBy = null) =>
               [.. batch.Select(d => new StatementMetadataData
               {
                   AccountCode = d.AccountCode,
                   StatementDate = d.StatementDate,
                   OriginalFileName = originalFileName,
                   Extension = extension,
                   CalculatedFileName = originalFileName,
                   ContentMd5 = contentMd5,
                   ContentLength = contentLength,
                   BlobUri = blobUri,
                   CreatedBy = createdBy
               })];
    }
}
