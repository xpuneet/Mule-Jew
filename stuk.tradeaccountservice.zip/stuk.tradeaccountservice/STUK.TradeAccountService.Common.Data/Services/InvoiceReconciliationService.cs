using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Coordinates delayed matching of consolidated components to existing invoice headers
    /// </summary>
    public class InvoiceReconciliationService : IInvoiceReconciliationService
    {
        private const int TerminalFailureRetryCount = 1;
        private const int MaximumErrorMessageLength = 2000;

        private readonly ILogger<InvoiceReconciliationService> _logger;
        private readonly IInvoiceReconciliationDataService _dataService;
        private readonly ConsolidatedSalesReconciliationOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="InvoiceReconciliationService"/> class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="dataService">Durable reconciliation data service</param>
        /// <param name="options">Reconciliation worker settings</param>
        /// <param name="timeProvider">Provider for UTC processing timestamps</param>
        /// <exception cref="ArgumentNullException"></exception>
        public InvoiceReconciliationService(ILogger<InvoiceReconciliationService> logger, IInvoiceReconciliationDataService dataService, IOptions<ConsolidatedSalesReconciliationOptions> options, TimeProvider timeProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _dataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task RunAsync(string leaseOwner, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);
            ValidateOptions();

            for (var workItemNumber = 0; workItemNumber < _options.MaximumWorkItemsPerRun; workItemNumber++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var work = await _dataService.ClaimNextAsync(
                    leaseOwner,
                    _options.LeaseDurationSeconds,
                    _options.MaximumRetryCount,
                    GetUtcNow(),
                    cancellationToken);

                if (work is null)
                {
                    return;
                }

                await ProcessClaimedWorkAsync(work, cancellationToken);
            }
        }

        private async Task ProcessClaimedWorkAsync(ConsolidatedSalesReconciliationWork work, CancellationToken cancellationToken)
        {
            if (!work.ClaimToken.HasValue)
            {
                throw new InvalidOperationException($"Claimed reconciliation work {work.Id} has no claim token");
            }

            var claimToken = work.ClaimToken.Value;

            if (string.IsNullOrWhiteSpace(work.StandardInvoiceNumber) || string.IsNullOrWhiteSpace(work.BranchCode))
            {
                await RecordTerminalFailureAsync(
                    work,
                    claimToken,
                    "InvalidMatchKey",
                    "The HX component does not contain both a standard invoice number and branch code",
                    cancellationToken);
                return;
            }

            InvoiceReconciliationMatchResult result;

            try
            {
                result = await _dataService.MatchAndUpdateInvoiceAsync(
                    work.StandardInvoiceNumber,
                    work.BranchCode,
                    work.ConsolidatedInvoiceNumber,
                    work.ConsolidatedInvoiceDate,
                    cancellationToken);

                if (result.MatchCount == 1 && result.MatchedInvoiceHeaderId.HasValue)
                {
                    await _dataService.CompleteAsync(
                        work.Id,
                        claimToken,
                        result.MatchedInvoiceHeaderId.Value,
                        GetUtcNow(),
                        cancellationToken);
                }
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                await _dataService.FailAsync(
                    work.Id,
                    claimToken,
                    "ReconciliationFailure",
                    TruncateErrorMessage(exception.Message),
                    GetUtcNow().AddSeconds(_options.FailureRetryDelaySeconds),
                    _options.MaximumRetryCount,
                    GetUtcNow(),
                    cancellationToken);

                _logger.LogError(
                    exception,
                    "Existing-invoice reconciliation failed for work {ReconciliationWorkId}, invoice {StandardInvoiceNumber} and branch {BranchCode}",
                    work.Id,
                    work.StandardInvoiceNumber,
                    work.BranchCode);
                return;
            }

            if (result.MatchCount == 1 && result.MatchedInvoiceHeaderId.HasValue)
            {
                return;
            }

            if (result.MatchCount == 0)
            {
                await _dataService.DeferAsync(
                    work.Id,
                    claimToken,
                    GetUtcNow().AddSeconds(_options.NoMatchRetryDelaySeconds),
                    $"Invoice {work.StandardInvoiceNumber} for branch {work.BranchCode} has not arrived",
                    GetUtcNow(),
                    cancellationToken);
                return;
            }

            await RecordTerminalFailureAsync(
                work,
                claimToken,
                "AmbiguousInvoiceMatch",
                $"Invoice {work.StandardInvoiceNumber} for branch {work.BranchCode} matched {result.MatchCount} invoice headers",
                cancellationToken);
        }

        private async Task RecordTerminalFailureAsync(ConsolidatedSalesReconciliationWork work, Guid claimToken, string errorCategory, string errorMessage, CancellationToken cancellationToken)
        {
            await _dataService.FailAsync(
                work.Id,
                claimToken,
                errorCategory,
                errorMessage,
                null,
                TerminalFailureRetryCount,
                GetUtcNow(),
                cancellationToken);

            _logger.LogError("Existing-invoice reconciliation cannot continue for work {ReconciliationWorkId}: {ErrorMessage}", work.Id, errorMessage);
        }

        private void ValidateOptions()
        {
            if (_options.MaximumWorkItemsPerRun <= 0)
            {
                throw new InvalidOperationException("The reconciliation maximum work items per run must be greater than zero");
            }

            if (_options.LeaseDurationSeconds <= 0)
            {
                throw new InvalidOperationException("The reconciliation lease duration must be greater than zero");
            }

            if (_options.NoMatchRetryDelaySeconds <= 0)
            {
                throw new InvalidOperationException("The reconciliation no-match retry delay must be greater than zero");
            }

            if (_options.FailureRetryDelaySeconds <= 0)
            {
                throw new InvalidOperationException("The reconciliation failure retry delay must be greater than zero");
            }

            if (_options.MaximumRetryCount <= 0)
            {
                throw new InvalidOperationException("The reconciliation maximum retry count must be greater than zero");
            }
        }

        private DateTimeOffset GetUtcNow()
        {
            return _timeProvider.GetUtcNow();
        }

        private static string TruncateErrorMessage(string errorMessage)
        {
            return errorMessage.Length <= MaximumErrorMessageLength
                ? errorMessage
                : errorMessage[..MaximumErrorMessageLength];
        }
    }
}
