namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Represents the known Workday fault raised when an identifier is not a valid Employee_ID
    /// </summary>
    internal sealed class WorkdayInvalidEmployeeIdException : IOException
    {
        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayInvalidEmployeeIdException"/>
        /// </summary>
        /// <param name="employeeId">Employee identifier rejected by Workday</param>
        /// <param name="message">Workday fault message</param>
        public WorkdayInvalidEmployeeIdException(string employeeId, string message) : base($"Workday rejected Employee_ID '{employeeId}': {message}")
        {
            EmployeeId = employeeId;
        }

        /// <summary>
        /// Gets the employee identifier rejected by Workday
        /// </summary>
        public string EmployeeId { get; }
    }
}
