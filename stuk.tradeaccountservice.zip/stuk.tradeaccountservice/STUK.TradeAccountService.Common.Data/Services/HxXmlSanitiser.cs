using System.Text;

namespace STUK.TradeAccountService.Common.Data.Services
{
    internal static class HxXmlSanitiser
    {
        private const int BufferSize = 64 * 1024;
        private const int MaximumEntityLength = 32;

        public static async Task SanitiseAsync(Stream source, Stream destination, CancellationToken cancellationToken)
        {
            var encoding = await DetectEncodingAsync(source, cancellationToken);

            using var reader = new StreamReader(source, encoding, detectEncodingFromByteOrderMarks: true, bufferSize: BufferSize, leaveOpen: true);

            await using var writer = new StreamWriter(destination, EncodingWithoutPreamble(encoding), bufferSize: BufferSize, leaveOpen: true);

            var input = new char[BufferSize];
            var output = new StringBuilder(BufferSize + 128);
            var entity = new StringBuilder();
            char? pendingHighSurrogate = null;
            var pendingLessThan = false;

            while (true)
            {
                var read = await reader.ReadAsync(input.AsMemory(), cancellationToken);
                if (read == 0)
                {
                    break;
                }

                for (var index = 0; index < read; index++)
                {
                    var value = input[index];

                    if (pendingLessThan)
                    {
                        output.Append(IsMarkupStart(value) ? '<' : "&lt;");
                        pendingLessThan = false;
                    }

                    if (entity.Length > 0 || value == '&')
                    {
                        ProcessEntityCharacter(value, entity, output, ref pendingLessThan);
                        continue;
                    }

                    if (value == '<')
                    {
                        pendingLessThan = true;
                        continue;
                    }

                    AppendValidXmlCharacter(value, output, ref pendingHighSurrogate);
                }

                if (output.Length >= BufferSize)
                {
                    await writer.WriteAsync(output.ToString().AsMemory(), cancellationToken);
                    output.Clear();
                }
            }

            if (entity.Length > 0)
            {
                output.Append("&amp;").Append(entity, 1, entity.Length - 1);
            }

            if (pendingLessThan)
            {
                output.Append("&lt;");
            }

            pendingHighSurrogate = null;

            if (output.Length > 0)
            {
                await writer.WriteAsync(output.ToString().AsMemory(), cancellationToken);
            }

            await writer.FlushAsync(cancellationToken);
        }

        private static void ProcessEntityCharacter(
            char value,
            StringBuilder entity,
            StringBuilder output,
            ref bool pendingLessThan)
        {
            if (value == '&' && entity.Length == 0)
            {
                entity.Append(value);
                return;
            }

            if (value == ';')
            {
                var entityValue = entity.ToString(1, entity.Length - 1);
                output.Append(IsValidEntity(entityValue) ? "&" : "&amp;")
                    .Append(entityValue)
                    .Append(';');

                entity.Clear();
                return;
            }

            if (value == '&' || value == '<' || char.IsWhiteSpace(value) || entity.Length >= MaximumEntityLength)
            {
                output.Append("&amp;").Append(entity, 1, entity.Length - 1);
                entity.Clear();

                if (value == '&')
                {
                    entity.Append(value);
                }
                else if (value == '<')
                {
                    pendingLessThan = true;
                }
                else
                {
                    output.Append(value);
                }

                return;
            }

            entity.Append(value);
        }

        private static bool IsValidEntity(string value)
        {
            if (value is "amp" or "lt" or "gt" or "apos" or "quot")
            {
                return true;
            }

            if (value.StartsWith("#x", StringComparison.Ordinal))
            {
                return value.Length > 2 && value[2..].All(Uri.IsHexDigit);
            }

            return value.StartsWith('#') && value.Length > 1 && value[1..].All(char.IsDigit);
        }

        private static bool IsMarkupStart(char value)
        {
            return value is '/' or '?' or '!' or '_' or ':' || char.IsLetter(value);
        }

        private static void AppendValidXmlCharacter(char value, StringBuilder output, ref char? pendingHighSurrogate)
        {
            if (pendingHighSurrogate.HasValue)
            {
                if (char.IsLowSurrogate(value))
                {
                    output.Append(pendingHighSurrogate.Value).Append(value);
                    pendingHighSurrogate = null;
                    return;
                }

                pendingHighSurrogate = null;
            }

            if (char.IsHighSurrogate(value))
            {
                pendingHighSurrogate = value;
                return;
            }

            if (char.IsLowSurrogate(value))
            {
                return;
            }

            if (value is '\t' or '\n' or '\r' || value >= 0x20 && value <= 0xD7FF || value >= 0xE000 && value <= 0xFFFD)
            {
                output.Append(value);
            }
        }

        private static async Task<Encoding> DetectEncodingAsync(Stream source, CancellationToken cancellationToken)
        {
            var originalPosition = source.Position;
            var buffer = new byte[512];

            var read = await source.ReadAsync(buffer.AsMemory(), cancellationToken);
            source.Position = originalPosition;

            if (read >= 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF)
            {
                return Encoding.UTF8;
            }

            if (read >= 2 && buffer[0] == 0xFF && buffer[1] == 0xFE)
            {
                return Encoding.Unicode;
            }

            if (read >= 2 && buffer[0] == 0xFE && buffer[1] == 0xFF)
            {
                return Encoding.BigEndianUnicode;
            }

            var declaration = Encoding.ASCII.GetString(buffer, 0, read);
            var encodingMarker = "encoding=";

            var markerIndex = declaration.IndexOf(encodingMarker, StringComparison.OrdinalIgnoreCase);
            if (markerIndex >= 0)
            {
                var quoteIndex = markerIndex + encodingMarker.Length;
                while (quoteIndex < declaration.Length && char.IsWhiteSpace(declaration[quoteIndex]))
                {
                    quoteIndex++;
                }

                if (quoteIndex < declaration.Length && declaration[quoteIndex] is '\'' or '"')
                {
                    var quote = declaration[quoteIndex];
                    var endQuoteIndex = declaration.IndexOf(quote, quoteIndex + 1);
                    if (endQuoteIndex > quoteIndex)
                    {
                        return ResolveEncoding(declaration[(quoteIndex + 1)..endQuoteIndex]);
                    }
                }
            }

            return Encoding.UTF8;
        }

        private static Encoding ResolveEncoding(string name) => name.ToUpperInvariant() switch
        {
            "UTF-8" or "UTF8" => Encoding.UTF8,
            "ISO-8859-1" or "ISO8859-1" or "LATIN1" => Encoding.Latin1,
            "UTF-16" or "UTF-16LE" => Encoding.Unicode,
            "UTF-16BE" => Encoding.BigEndianUnicode,
            _ => throw new NotSupportedException($"The XML encoding '{name}' is not supported by the sanitisation fallback.")
        };

        private static Encoding EncodingWithoutPreamble(Encoding encoding)
        {
            if (encoding.CodePage == Encoding.UTF8.CodePage)
            {
                return new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);
            }

            return encoding;
        }
    }
}
