﻿using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using STUK.APIs.Common.Interfaces;
using System.Security.Cryptography;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class ColumbusWebService : IColumbusWebService
    {
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
        private readonly HttpClient _httpClient;
        private readonly string _endpointUrl;
        private readonly int _maxRetryAttempts;
        private readonly int _retryDelaySeconds;

        private static readonly XNamespace ColumbusNs = "http://www.macro4.com/webservices/columbus";

        public ColumbusWebService(
            IAppInsightsLoggerHelper appInsightsLoggerHelper,
            HttpClient httpClient,
            IConfiguration configuration)
        {
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
            _httpClient = httpClient;
            _endpointUrl = configuration.GetValue<string>("Columbus:ColumbusEndpointUrl", "https://columbus.starkbuild.co.uk/retrievalwebservice.cxr");
            _maxRetryAttempts = configuration.GetValue<int>("Columbus:MaxRetryAttempts", 3);
            _retryDelaySeconds = configuration.GetValue<int>("Columbus:RetryDelaySeconds", 5);
        }
        private async Task<HttpResponseMessage> PostWithRetryAsync(StringContent content, string operationName)
        {
            int attempt = 0;
            while (true)
            {
                attempt++;
                try
                {
                    _appInsightsLoggerHelper.LogInformation($"{operationName} - Sending request. Attempt: {attempt}/{_maxRetryAttempts}, Endpoint: {_endpointUrl}");

                    var response = await _httpClient.PostAsync(_endpointUrl, content);


                    bool shouldRetry =
                        response.StatusCode == HttpStatusCode.GatewayTimeout ||
                        response.StatusCode == HttpStatusCode.RequestTimeout ||
                        response.StatusCode == HttpStatusCode.InternalServerError ||
                        response.StatusCode == HttpStatusCode.BadGateway ||
                        response.StatusCode == HttpStatusCode.ServiceUnavailable ||
                        response.StatusCode == HttpStatusCode.TooManyRequests;

                    if (shouldRetry)
                    {
                        if ( attempt>= _maxRetryAttempts)
                        {
                            _appInsightsLoggerHelper.LogWarning($"{operationName} Failed with Status Code {response.StatusCode} after {attempt} attempt(s). Max retries reached. StatusCode: {(int)response.StatusCode}");
                            response.EnsureSuccessStatusCode();
                        }

                        _appInsightsLoggerHelper.LogWarning($"{operationName} - Failed with Status Code {response.StatusCode} on attempt {attempt}. Retrying in {_retryDelaySeconds}s. StatusCode: {(int)response.StatusCode}");
                        await Task.Delay(TimeSpan.FromSeconds(_retryDelaySeconds));
                        content = CloneContent(content);
                        continue;
                    }

                    response.EnsureSuccessStatusCode();
                    _appInsightsLoggerHelper.LogInformation($"{operationName} - Request succeeded. Attempt: {attempt}, StatusCode: {(int)response.StatusCode}");
                    return response;
                }
                catch (HttpRequestException ex) when (attempt < _maxRetryAttempts)
                {
                    _appInsightsLoggerHelper.LogWarning($"{operationName} - HttpRequestException on attempt {attempt}. Retrying in {_retryDelaySeconds}s. Error: {ex.Message}");
                    await Task.Delay(TimeSpan.FromSeconds(_retryDelaySeconds));
                    content = CloneContent(content);
                }
            }
        }

        private static StringContent CloneContent(StringContent original)
        {
            var body = original.ReadAsStringAsync().GetAwaiter().GetResult();
            var cloned = new StringContent(body, Encoding.UTF8, "application/soap+xml");
            foreach (var header in original.Headers)
                if (!cloned.Headers.Contains(header.Key))
                    cloned.Headers.TryAddWithoutValidation(header.Key, header.Value);
            return cloned;
        }

        public async Task<ColumbusOpenSessionResult> OpenSessionAsync(string username, string password)
        {
            _appInsightsLoggerHelper.LogInformation($"Opening Columbus session. Username: {username}");
            try
            {
                var soapBody = $"""
<?xml version="1.0" encoding="utf-8"?>
<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                 xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
  <soap12:Body>
    <OpenSession xmlns="http://www.macro4.com/webservices/columbus">
      <req>
        <Username>{username}</Username>
        <Password>{password}</Password>
      </req>
    </OpenSession>
  </soap12:Body>
</soap12:Envelope>
""";
                var content = new StringContent(soapBody, Encoding.UTF8, "application/soap+xml");
                content.Headers.Add("SOAPAction", "http://www.macro4.com/webservices/columbus/OpenSession");

                var response = await PostWithRetryAsync(content, nameof(OpenSessionAsync));
                var xmlText = await response.Content.ReadAsStringAsync();
                var doc = XDocument.Parse(xmlText);

                var result = doc.Descendants(ColumbusNs + "OpenSessionResult").FirstOrDefault()
                    ?? throw new InvalidOperationException("OpenSessionResult element not found in response.");

                var errorNumber = int.Parse(result.Element(ColumbusNs + "ErrorNumber")?.Value ?? "0");
                var errorMessage = errorNumber != 0 ? result.Element(ColumbusNs + "ErrorMessage")?.Value : null;
                var sessionId = result.Element(ColumbusNs + "SessionId")?.Value
                    ?? throw new InvalidOperationException("SessionId missing from response.");

                if (errorNumber != 0)
                    _appInsightsLoggerHelper.LogWarning($"OpenSession returned an error. ErrorNumber: {errorNumber}, ErrorMessage: {errorMessage}");
                else
                    _appInsightsLoggerHelper.LogInformation($"Columbus session opened successfully. SessionId: {sessionId}");

                var firstArchive = result.Descendants(ColumbusNs + "Archive").FirstOrDefault();
                ColumbusArchiveInfo? archive = null;
                if (firstArchive != null)
                {
                    archive = new ColumbusArchiveInfo
                    {
                        ArchiveId = int.Parse(firstArchive.Element(ColumbusNs + "ArchiveId")?.Value ?? "0"),
                        Title = firstArchive.Element(ColumbusNs + "Title")?.Value,
                        Filename = firstArchive.Element(ColumbusNs + "Filename")?.Value,
                        Role = firstArchive.Element(ColumbusNs + "Role")?.Value
                    };
                    _appInsightsLoggerHelper.LogInformation($"Archive info retrieved. ArchiveId: {archive.ArchiveId}, Title: {archive.Title}, Role: {archive.Role}");
                }
                else
                {
                    _appInsightsLoggerHelper.LogWarning($"No archive found in OpenSession response. SessionId: {sessionId}");
                }

                return new ColumbusOpenSessionResult
                {
                    SessionId = sessionId,
                    ErrorNumber = errorNumber,
                    ErrorMessage = errorMessage,
                    Archive = archive
                };
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to open Columbus session. Username: {username}");
                throw;
            }
        }

        public async Task<int> CloseSessionAsync(string sessionId)
        {
            _appInsightsLoggerHelper.LogInformation($"Closing Columbus session. SessionId: {sessionId}");
            try
            {
                var soapBody = $"""
<?xml version="1.0" encoding="utf-8"?>
<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                 xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
  <soap12:Body>
    <CloseSession xmlns="http://www.macro4.com/webservices/columbus">
      <req>
        <SessionId>{sessionId}</SessionId>
      </req>
    </CloseSession>
  </soap12:Body>
</soap12:Envelope>
""";
                var content = new StringContent(soapBody, Encoding.UTF8, "application/soap+xml");
                content.Headers.Add("SOAPAction", "http://www.macro4.com/webservices/columbus/CloseSession");

                var response = await PostWithRetryAsync(content, nameof(CloseSessionAsync));
                var xmlText = await response.Content.ReadAsStringAsync();
                var doc = XDocument.Parse(xmlText);

                var result = doc.Descendants(ColumbusNs + "CloseSessionResult").FirstOrDefault()
                    ?? throw new InvalidOperationException("CloseSessionResult element not found in response.");

                var errorNumber = int.Parse(result.Element(ColumbusNs + "ErrorNumber")?.Value ?? "0");

                if (errorNumber != 0)
                    _appInsightsLoggerHelper.LogWarning($"CloseSession returned an error. SessionId: {sessionId}, ErrorNumber: {errorNumber}");
                else
                    _appInsightsLoggerHelper.LogInformation($"Columbus session closed successfully. SessionId: {sessionId}");

                return errorNumber;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to close Columbus session. SessionId: {sessionId}");
                throw;
            }
        }
        
        public async Task<(int ErrorNumber, string? ErrorMessage)> BeginSearchOperationAsync(
            string sessionId, int archiveId, int maxMatches,string docType,
            string accountCode, string branchNo, string? documentNo,
            string startDate, string endDate, string? continueSearch = null)
        {
            _appInsightsLoggerHelper.LogInformation($"Beginning Columbus search operation. SessionId: {sessionId}, AccountCode: {accountCode}, BranchNo: {branchNo}, DocumentNo: {documentNo}, DateRange: {startDate}-{endDate}");
            try
            {
                var continueSearchValue = continueSearch ?? string.Empty;
                string soapBody;
                if (docType == "INV")
                {
                    soapBody = $"""
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <BeginSearchOperation xmlns:col="http://www.macro4.com/webservices/columbus">
      <req>
        <SessionId>{System.Security.SecurityElement.Escape(sessionId)}</SessionId>
        <SearchRequestInfo>
          <ArchiveId>{archiveId}</ArchiveId>
          <MaxMatches>{maxMatches}</MaxMatches>
          <ContinueSearch>{continueSearchValue}</ContinueSearch>
          <MatchIndexes>
<MatchIndex>
  <FieldName>Doc</FieldName>
  <FirstValue>{docType}</FirstValue>
  <OperatorType>EQUALS</OperatorType>
</MatchIndex>
            <MatchIndex>
              <FieldName>acc no</FieldName>
              <FirstValue>{accountCode}</FirstValue>
              <OperatorType>EQUALS</OperatorType>
            </MatchIndex>
            <MatchIndex>
              <FieldName>Brn</FieldName>
              <FirstValue>{branchNo}</FirstValue>
              <OperatorType>EQUALS</OperatorType>
            </MatchIndex>
            <MatchIndex>
              <FieldName>doc no</FieldName>
              <FirstValue>{documentNo}</FirstValue>
              <OperatorType>EQUALS</OperatorType>
            </MatchIndex>
            <MatchIndex>
              <FieldName>date1</FieldName>
              <FirstValue>{startDate}</FirstValue>
              <SecondValue>{endDate}</SecondValue>
              <OperatorType>RANGE</OperatorType>
            </MatchIndex>
          </MatchIndexes>
          <TopOrBottomNHits>
            <FieldShortname>DAT</FieldShortname>
            <SortDirection>TOP</SortDirection>
          </TopOrBottomNHits>
        </SearchRequestInfo>
        <ReturnParsedFieldValues>TRUE</ReturnParsedFieldValues>
      </req>
    </BeginSearchOperation>
  </soap:Body>
</soap:Envelope>
""";
                }
                else
                {
                    soapBody = $"""
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <BeginSearchOperation xmlns:col="http://www.macro4.com/webservices/columbus">
      <req>
        <SessionId>{System.Security.SecurityElement.Escape(sessionId)}</SessionId>
        <SearchRequestInfo>
          <ArchiveId>{archiveId}</ArchiveId>
          <MaxMatches>{maxMatches}</MaxMatches>
          <ContinueSearch>{continueSearchValue}</ContinueSearch>
          <MatchIndexes>
<MatchIndex>
  <FieldName>Doc</FieldName>
  <FirstValue>{docType}</FirstValue>
  <OperatorType>EQUALS</OperatorType>
</MatchIndex>
            <MatchIndex>
              <FieldName>acc no</FieldName>
              <FirstValue>{accountCode}</FirstValue>
              <OperatorType>EQUALS</OperatorType>
            </MatchIndex>
            <MatchIndex>
              <FieldName>Brn</FieldName>
              <FirstValue>{branchNo}</FirstValue>
              <OperatorType>EQUALS</OperatorType>
            </MatchIndex>
            <MatchIndex>
              <FieldName>date1</FieldName>
              <FirstValue>{startDate}</FirstValue>
              <SecondValue>{endDate}</SecondValue>
              <OperatorType>RANGE</OperatorType>
            </MatchIndex>
          </MatchIndexes>
          <TopOrBottomNHits>
            <FieldShortname>DAT</FieldShortname>
            <SortDirection>TOP</SortDirection>
          </TopOrBottomNHits>
        </SearchRequestInfo>
        <ReturnParsedFieldValues>TRUE</ReturnParsedFieldValues>
      </req>
    </BeginSearchOperation>
  </soap:Body>
</soap:Envelope>
""";
                }
                    var content = new StringContent(soapBody, Encoding.UTF8, "application/soap+xml");
                content.Headers.Add("SOAPAction", "http://www.macro4.com/webservices/columbus/BeginSearchOperation");

                var response = await PostWithRetryAsync(content, nameof(BeginSearchOperationAsync));
                var xmlText = await response.Content.ReadAsStringAsync();
                var columbusNs = XNamespace.Get("http://www.macro4.com/webservices/columbus");
                var doc = XDocument.Parse(xmlText);

                var result = doc.Descendants(columbusNs + "BeginSearchOperationResult").FirstOrDefault()
                    ?? throw new InvalidOperationException("BeginSearchOperationResult element not found in response.");

                var errorNumber = int.Parse(result.Element(columbusNs + "ErrorNumber")?.Value ?? "0");
                var errorMessage = errorNumber != 0 ? result.Element(columbusNs + "ErrorMessage")?.Value : null;

                if (errorNumber != 0)
                    _appInsightsLoggerHelper.LogWarning($"BeginSearchOperation returned an error. SessionId: {sessionId}, ErrorNumber: {errorNumber}, ErrorMessage: {errorMessage}");
                else
                    _appInsightsLoggerHelper.LogInformation($"BeginSearchOperation completed successfully. SessionId: {sessionId}");

                return (errorNumber, errorMessage);
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to begin Columbus search operation. SessionId: {sessionId}, DocumentNo: {documentNo}");
                throw;
            }
        }

        public async Task<ColumbusSearchResult> GetSearchResultsAsync(string sessionId)
        {
            _appInsightsLoggerHelper.LogInformation($"Getting Columbus search results. SessionId: {sessionId}");
            try
            {
                var soapBody = $"""
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetSearchResults xmlns:col="http://www.macro4.com/webservices/columbus">
      <req>
        <SessionId>{sessionId}</SessionId>
        <ItemRange>
          <From>1</From>
          <To>-1</To>
        </ItemRange>
      </req>
    </GetSearchResults>
  </soap:Body>
</soap:Envelope>
""";
                var content = new StringContent(soapBody, Encoding.UTF8, "application/soap+xml");
                content.Headers.Add("SOAPAction", "http://www.macro4.com/webservices/columbus/GetSearchResults");

                var response = await PostWithRetryAsync(content, nameof(GetSearchResultsAsync));
                var xmlText = await response.Content.ReadAsStringAsync();
                var columbusNs = XNamespace.Get("http://www.macro4.com/webservices/columbus");
                var doc = XDocument.Parse(xmlText);

                var result = doc.Descendants(columbusNs + "GetSearchResultsResult").FirstOrDefault()
                    ?? throw new InvalidOperationException("GetSearchResultsResult element not found in response.");

                var errorNumber = int.Parse(result.Element(columbusNs + "ErrorNumber")?.Value ?? "0");
                var errorMessage = errorNumber != 0 ? result.Element(columbusNs + "ErrorMessage")?.Value : null;
                var totalDocuments = int.Parse(
                    result.Element(columbusNs + "ItemRange")?.Element(columbusNs + "Number")?.Value ?? "0");
                var operationStatus = result.Element(columbusNs + "OperationStatus")?.Value ?? string.Empty;
                var operationErrorNumber = int.Parse(result.Element(columbusNs + "OperationErrorNumber")?.Value ?? "0");

                if (errorNumber != 0)
                    _appInsightsLoggerHelper.LogWarning($"GetSearchResults returned an error. SessionId: {sessionId}, ErrorNumber: {errorNumber}, ErrorMessage: {errorMessage}");
                else
                    _appInsightsLoggerHelper.LogInformation($"GetSearchResults completed successfully. SessionId: {sessionId}, TotalDocuments: {totalDocuments}, OperationStatus: {operationStatus}");

                if (operationErrorNumber != 0)
                    _appInsightsLoggerHelper.LogWarning($"GetSearchResults operation error. SessionId: {sessionId}, OperationErrorNumber: {operationErrorNumber}, OperationStatus: {operationStatus}");

                return new ColumbusSearchResult
                {
                    ErrorNumber = errorNumber,
                    ErrorMessage = errorMessage,
                    ContinueSearch = result.Element(columbusNs + "ContinueSearch")?.Value,
                    TotalDocuments = totalDocuments,
                    OperationStatus = operationStatus,
                    OperationErrorNumber = operationErrorNumber
                };
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to get Columbus search results. SessionId: {sessionId}");
                throw;
            }
        }

        public async Task<(int ErrorNumber, string? ErrorMessage)> BeginPageOperationAsync(
            string sessionId, int matchlistEntryNumber)
        {
            _appInsightsLoggerHelper.LogInformation($"Beginning Columbus page operation. SessionId: {sessionId}, MatchlistEntryNumber: {matchlistEntryNumber}");
            try
            {
                var soapBody = $"""
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <BeginPageOperation xmlns:col="http://www.macro4.com/webservices/columbus">
      <req>
        <SessionId>{System.Security.SecurityElement.Escape(sessionId)}</SessionId>
        <PageRequestInfo>
          <MatchlistEntryNumber>{matchlistEntryNumber}</MatchlistEntryNumber>
          <NumberOfPages>-1</NumberOfPages>
          <ResultPageType>PDF</ResultPageType>
          <UsageReason>VIEW</UsageReason>
        </PageRequestInfo>
      </req>
    </BeginPageOperation>
  </soap:Body>
</soap:Envelope>
""";
                var content = new StringContent(soapBody, Encoding.UTF8, "application/soap+xml");
                content.Headers.Add("SOAPAction", "http://www.macro4.com/webservices/columbus/BeginPageOperation");

                var response = await PostWithRetryAsync(content, nameof(BeginPageOperationAsync));
                var xmlText = await response.Content.ReadAsStringAsync();
                var columbusNs = XNamespace.Get("http://www.macro4.com/webservices/columbus");
                var doc = XDocument.Parse(xmlText);

                var result = doc.Descendants(columbusNs + "BeginPageOperationResult").FirstOrDefault()
                    ?? throw new InvalidOperationException("BeginPageOperationResult element not found in response.");

                var errorNumber = int.Parse(result.Element(columbusNs + "ErrorNumber")?.Value ?? "0");
                var errorMessage = errorNumber != 0 ? result.Element(columbusNs + "ErrorMessage")?.Value : null;

                if (errorNumber != 0)
                    _appInsightsLoggerHelper.LogWarning($"BeginPageOperation returned an error. SessionId: {sessionId}, MatchlistEntryNumber: {matchlistEntryNumber}, ErrorNumber: {errorNumber}, ErrorMessage: {errorMessage}");
                else
                    _appInsightsLoggerHelper.LogInformation($"BeginPageOperation completed successfully. SessionId: {sessionId}, MatchlistEntryNumber: {matchlistEntryNumber}");

                return (errorNumber, errorMessage);
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to begin Columbus page operation. SessionId: {sessionId}, MatchlistEntryNumber: {matchlistEntryNumber}");
                throw;
            }
        }

        public async Task<ColumbusPageResponse> GetPageResultsAndUploadToBlobAsync(
            string sessionId, string accountCode, string branchNo, string? documentNo,
            int pageNo, int totalPages, string date,
            string storageAccountUrl, string containerName)
        {
            _appInsightsLoggerHelper.LogInformation($"Getting page results and uploading to blob. SessionId: {sessionId}, AccountCode: {accountCode}, DocumentNo: {documentNo}, Page: {pageNo}/{totalPages}");
            try
            {
                var xmlText = await FetchPageResultsXmlAsync(sessionId);
                var columbusNs = XNamespace.Get("http://www.macro4.com/webservices/columbus");
                var doc = XDocument.Parse(xmlText);

                var result = doc.Descendants(columbusNs + "GetPageResultsResult").FirstOrDefault()
                    ?? throw new InvalidOperationException("GetPageResultsResult element not found in response.");

                var errorNumber = int.Parse(result.Element(columbusNs + "ErrorNumber")?.Value ?? "0");
                var errorMessage = errorNumber != 0
                    ? result.Element(columbusNs + "ErrorMessage")?.Value
                      ?? $"GetPageResults failed with error number {errorNumber}."
                    : null;

                var operationStatus = result.Element(columbusNs + "OperationStatus")?.Value ?? string.Empty;
                var operationErrorNumber = int.Parse(result.Element(columbusNs + "OperationErrorNumber")?.Value ?? "0");

                if (errorNumber != 0)
                {
                    _appInsightsLoggerHelper.LogWarning($"GetPageResults returned an error. SessionId: {sessionId}, DocumentNo: {documentNo}, Page: {pageNo}, ErrorNumber: {errorNumber}, ErrorMessage: {errorMessage}");
                    return new ColumbusPageResponse
                    {
                        ErrorNumber = errorNumber,
                        ErrorMessage = errorMessage,
                        OperationStatus = operationStatus,
                        OperationErrorNumber = operationErrorNumber
                    };
                }

                var part = result.Descendants(columbusNs + "Part").FirstOrDefault()
                    ?? throw new InvalidOperationException("Part element not found in PageResults.");

                var base64Value = part.Element(columbusNs + "Value")?.Value
                    ?? throw new InvalidOperationException("Value (base64) element not found in Part.");
                var fileInfo = part.Element(columbusNs + "ExternalDataFileInfoRecord");

                string extension = ".pdf";

                if (fileInfo == null)
                {
                    _appInsightsLoggerHelper.LogWarning(
                          "ExternalDataFileInfoRecord is missing in XML response.");
                }
                var fileBytes = Convert.FromBase64String(base64Value.Trim());

                _appInsightsLoggerHelper.LogInformation($"Page content decoded. SessionId: {sessionId}, DocumentNo: {documentNo}, Page: {pageNo}, Extension: {extension}, DecodedFileSize: {fileBytes.Length}");

                var fileName = BuildFileName(accountCode, branchNo, documentNo,date, extension);
                var blobPath = BuildBlobPath(fileName);

                var blobUrl = await UploadToBlobAsync(fileBytes, blobPath, storageAccountUrl, containerName, "application/pdf");
                _appInsightsLoggerHelper.LogInformation($"Page results processed and uploaded successfully. SessionId: {sessionId}, DocumentNo: {documentNo}, Page: {pageNo}/{totalPages}, BlobUrl: {blobUrl}");
                if (fileInfo != null)
                {
                    return new ColumbusPageResponse
                    {
                        ErrorNumber = errorNumber,
                        ErrorMessage = null,
                        OperationStatus = operationStatus,
                        OperationErrorNumber = operationErrorNumber,
                        BlobUrl = blobPath,
                        Extension = extension,
                        CalculatedFileName = fileName,
                        ContentMd5= GenerateMd5(base64Value),
                        Size = int.Parse(fileInfo.Element(columbusNs + "Size")?.Value ?? "0"),
                        SourceFileName = fileInfo.Element(columbusNs + "FileName")?.Value ?? string.Empty,
                        FileSize = long.Parse(fileInfo.Element(columbusNs + "FileSize")?.Value ?? "0"),
                        FileTime = fileInfo.Element(columbusNs + "FileTime")?.Value ?? string.Empty,
                        CreationTime = fileInfo.Element(columbusNs + "CreationTime")?.Value ?? string.Empty,
                        FileAttributes = int.Parse(fileInfo.Element(columbusNs + "FileAttributes")?.Value ?? "0"),
                        NumberOfBlocks = int.Parse(fileInfo.Element(columbusNs + "NumberOfBlocks")?.Value ?? "0")
                    };
                }
                else
                {
                    long size = Convert.FromBase64String(base64Value).Length;

                    return new ColumbusPageResponse
                    {
                        ErrorNumber = errorNumber,
                        ErrorMessage = null,
                        OperationStatus = operationStatus,
                        OperationErrorNumber = operationErrorNumber,
                        BlobUrl = blobPath,
                        ContentMd5 = GenerateMd5(base64Value),
                        Extension = extension,
                        CalculatedFileName = fileName,
                        Size = size,
                        SourceFileName = null,
                        FileSize = size,
                        FileTime = null,
                        CreationTime = null,
                        FileAttributes = null,
                        NumberOfBlocks = null
                    };
                }
                  
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to get page results or upload to blob. SessionId: {sessionId}, DocumentNo: {documentNo}, Page: {pageNo}");
                throw;
            }
        }

        private  string GenerateMd5(string input)
        {
            using (var md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert to hex string
                return Convert.ToHexString(hashBytes).ToLowerInvariant();
            }
        }

        private async Task<string> FetchPageResultsXmlAsync(string sessionId)
        {
            _appInsightsLoggerHelper.LogInformation($"Fetching page results XML. SessionId: {sessionId}");
            try
            {
                var soapBody = $"""
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetPageResults xmlns:col="http://www.macro4.com/webservices/columbus">
      <req>
        <SessionId>{sessionId}</SessionId>
        <Timeout>10000</Timeout>
        <ByteRange>
          <From>0</From>
          <To>20000000</To>
        </ByteRange>
      </req>
    </GetPageResults>
  </soap:Body>
</soap:Envelope>
""";
                var content = new StringContent(soapBody, Encoding.UTF8, "application/soap+xml");
                content.Headers.Add("SOAPAction", "http://www.macro4.com/webservices/columbus/GetPageResults");

                var response = await PostWithRetryAsync(content, nameof(FetchPageResultsXmlAsync));
                var xmlText = await response.Content.ReadAsStringAsync();

                _appInsightsLoggerHelper.LogInformation($"Page results XML fetched successfully. SessionId: {sessionId}, ResponseLength: {xmlText.Length}");
                return xmlText;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to fetch page results XML. SessionId: {sessionId}");
                throw;
            }
        }


        private string BuildFileName(
            string accountCode, string branchNo, string? documentNo,
            string date, string extension)
        {
            if (string.IsNullOrWhiteSpace(accountCode)) throw new ArgumentException("AccountCode is required.", nameof(accountCode));
            if (string.IsNullOrWhiteSpace(branchNo)) throw new ArgumentException("BranchNo is required.", nameof(branchNo));
            if (string.IsNullOrWhiteSpace(extension)) throw new ArgumentException("Extension is required.", nameof(extension));

            string? fileName;
            if (documentNo == null)
            {
                fileName = $"{accountCode}_{branchNo}_{date.Replace("/", "")}{extension}";
            }
            else
            {
                fileName = $"{accountCode}_{branchNo}_{documentNo}_{date.Replace("/", "")}{extension}";
            }

            _appInsightsLoggerHelper.LogInformation($"Built file name. FileName: {fileName}, AccountCode: {accountCode}, BranchNo: {branchNo}, DocumentNo: {documentNo}");
            return fileName;
        }

        private string BuildBlobPath( string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName)) throw new ArgumentException("FileName is required.", nameof(fileName));
            string today = DateTime.Today.ToString("yyyy/MM/dd");
            var blobPath = $"{today}/{fileName}";

            _appInsightsLoggerHelper.LogInformation($"Built blob path. BlobPath: {blobPath}, Date: {today}, FileName: {fileName}");
            return blobPath;
        }

        private async Task<string> UploadToBlobAsync(
            byte[] fileBytes, string blobPath,
            string storageAccountUrl, string containerName, string contentType)
        {
            if (fileBytes == null || fileBytes.Length == 0) throw new ArgumentException("FileBytes cannot be null or empty.", nameof(fileBytes));
            if (string.IsNullOrWhiteSpace(blobPath)) throw new ArgumentException("BlobPath is required.", nameof(blobPath));
            if (string.IsNullOrWhiteSpace(storageAccountUrl)) throw new ArgumentException("StorageAccountUrl is required.", nameof(storageAccountUrl));
            if (string.IsNullOrWhiteSpace(containerName)) throw new ArgumentException("ContainerName is required.", nameof(containerName));

            _appInsightsLoggerHelper.LogInformation($"Connecting to Azure Blob Storage. StorageAccountUrl: {storageAccountUrl}, Container: {containerName}, BlobPath: {blobPath}, ContentType: {contentType}, FileSize: {fileBytes.Length}");

            try
            {
                var blobServiceClient = new BlobServiceClient(new Uri(storageAccountUrl), new DefaultAzureCredential());
                var containerClient = blobServiceClient.GetBlobContainerClient(containerName);

                _appInsightsLoggerHelper.LogInformation($"Ensuring blob container exists. Container: {containerName}");
                await containerClient.CreateIfNotExistsAsync(PublicAccessType.None);

                var blobClient = containerClient.GetBlobClient(blobPath);

                _appInsightsLoggerHelper.LogInformation($"Uploading file to blob. BlobPath: {blobPath}, FileSize: {fileBytes.Length}");
                using var stream = new MemoryStream(fileBytes);
                await blobClient.UploadAsync(stream, new BlobUploadOptions
                {
                    HttpHeaders = new BlobHttpHeaders { ContentType = contentType }
                });

                var blobUrl = blobClient.Uri.ToString();
                _appInsightsLoggerHelper.LogInformation($"File uploaded to blob successfully. BlobUrl: {blobUrl}, BlobPath: {blobPath}, FileSize: {fileBytes.Length}");
                return blobUrl;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to upload file to Azure Blob Storage. StorageAccountUrl: {storageAccountUrl}, Container: {containerName}, BlobPath: {blobPath}, FileSize: {fileBytes.Length}");
                throw;
            }
        }
    }
}