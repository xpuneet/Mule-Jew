using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides the application boundary for Workday-to-Concur orchestration
    /// </summary>
    public class WorkdayConcurOrchestrationService : IWorkdayConcurOrchestrationService
    {
        private const string SynapseInProgressStatus = "InProgress";
        private const string SynapseSucceededStatus = "Succeeded";

        private readonly ILogger<WorkdayConcurOrchestrationService> _logger;
        private readonly WorkdayConcurOptions _options;
        private readonly IWorkdayConcurStateService _stateService;
        private readonly IWorkdayConcurTm1Service _tm1Service;
        private readonly IWorkdayWorkersClient _workersClient;
        private readonly IWorkdayConcurCsvService _csvService;
        private readonly IWorkdayConcurTransformationService _transformationService;
        private readonly IWorkdayConcurDeliveryService _deliveryService;
        private readonly IWorkdayConcurHousekeepingService _housekeepingService;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurOrchestrationService"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="options">Workday-to-Concur feature settings</param>
        /// <param name="stateService">Durable Workday-to-Concur run-state service</param>
        /// <param name="tm1Service">Managed TM1 pickup service</param>
        /// <param name="workersClient">Direct Workday employee client</param>
        /// <param name="csvService">Concur employee CSV staging service</param>
        /// <param name="transformationService">Mule-free Concur transformation service</param>
        /// <param name="deliveryService">Encrypted Synapse Concur delivery service</param>
        /// <param name="housekeepingService">Post-delivery Synapse Blob housekeeping service</param>
        /// <param name="timeProvider">Provides the current UTC time</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayConcurOrchestrationService(
            ILogger<WorkdayConcurOrchestrationService> logger,
            IOptions<WorkdayConcurOptions> options,
            IWorkdayConcurStateService stateService,
            IWorkdayConcurTm1Service tm1Service,
            IWorkdayWorkersClient workersClient,
            IWorkdayConcurCsvService csvService,
            IWorkdayConcurTransformationService transformationService,
            IWorkdayConcurDeliveryService deliveryService,
            IWorkdayConcurHousekeepingService housekeepingService,
            TimeProvider timeProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _stateService = stateService ?? throw new ArgumentNullException(nameof(stateService));
            _tm1Service = tm1Service ?? throw new ArgumentNullException(nameof(tm1Service));
            _workersClient = workersClient ?? throw new ArgumentNullException(nameof(workersClient));
            _csvService = csvService ?? throw new ArgumentNullException(nameof(csvService));
            _transformationService = transformationService ?? throw new ArgumentNullException(nameof(transformationService));
            _deliveryService = deliveryService ?? throw new ArgumentNullException(nameof(deliveryService));
            _housekeepingService = housekeepingService ?? throw new ArgumentNullException(nameof(housekeepingService));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task RunAsync(string correlationId, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(correlationId);
            cancellationToken.ThrowIfCancellationRequested();

            if (!_options.Enabled)
            {
                _logger.LogInformation("Workday-to-Concur processing is disabled for invocation {CorrelationId}", correlationId);

                return;
            }

            if (_options.LeaseDurationSeconds <= 0)
            {
                throw new InvalidOperationException("Workday-to-Concur lease duration must be greater than zero");
            }

            if (_options.LeaseRenewalIntervalSeconds <= 0)
            {
                throw new InvalidOperationException("Workday-to-Concur lease renewal interval must be greater than zero");
            }

            if (_options.LeaseRenewalIntervalSeconds >= _options.LeaseDurationSeconds)
            {
                throw new InvalidOperationException("Workday-to-Concur lease renewal interval must be shorter than the lease duration");
            }

            if (!Guid.TryParse(correlationId, out var parsedCorrelationId))
            {
                throw new ArgumentException("The correlation identifier must be a GUID", nameof(correlationId));
            }

            var now = _timeProvider.GetUtcNow();

            WorkdayConcurRun? run = await _stateService.CreateOrResumeRunAsync(
                parsedCorrelationId,
                correlationId,
                now,
                _options.LeaseDurationSeconds,
                now,
                cancellationToken);

            if (run is null)
            {
                _logger.LogInformation(
                    "Workday-to-Concur invocation {CorrelationId} did not acquire the current integration run",
                    correlationId);
                return;
            }

            if (!run.ClaimToken.HasValue)
            {
                throw new InvalidOperationException($"Workday-to-Concur run {run.RunId} was returned without a claim token");
            }

            await ProcessWithLeaseRenewalAsync(run, run.ClaimToken.Value, cancellationToken);
        }

        private async Task ProcessWithLeaseRenewalAsync(WorkdayConcurRun run, Guid claimToken, CancellationToken cancellationToken)
        {
            using var processingCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            var processingTask = ProcessClaimedRunAsync(run, claimToken, processingCancellation.Token);
            var renewalTask = RenewLeaseUntilCancelledAsync(run.RunId, claimToken, processingCancellation.Token);
            var renewalCompletedFirst = false;

            try
            {
                var firstCompletedTask = await Task.WhenAny(processingTask, renewalTask);
                if (firstCompletedTask == renewalTask)
                {
                    renewalCompletedFirst = true;
                    await renewalTask;
                }

                await processingTask;
            }
            finally
            {
                await processingCancellation.CancelAsync();

                try
                {
                    await renewalTask;
                }
                catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                {
                    // Expected after processing completes or a lease renewal failure stops processing.
                }
                catch when (renewalCompletedFirst)
                {
                    // The renewal failure was already observed and must remain the primary exception.
                }

                if (!processingTask.IsCompleted)
                {
                    try
                    {
                        await processingTask;
                    }
                    catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                    {
                        // Processing must stop when its lease can no longer be renewed.
                    }
                }
            }
        }

        private async Task RenewLeaseUntilCancelledAsync(Guid runId, Guid claimToken, CancellationToken cancellationToken)
        {
            var renewalInterval = TimeSpan.FromSeconds(_options.LeaseRenewalIntervalSeconds);

            while (true)
            {
                await Task.Delay(renewalInterval, _timeProvider, cancellationToken);
                await _stateService.RenewLeaseAsync(
                    runId,
                    claimToken,
                    _options.LeaseDurationSeconds,
                    now: _timeProvider.GetUtcNow(),
                    cancellationToken: cancellationToken);
            }
        }

        private async Task ProcessClaimedRunAsync(WorkdayConcurRun run, Guid claimToken, CancellationToken cancellationToken)
        {

            var failureCategory = "Tm1Pickup";
            try
            {
                _logger.LogInformation(
                    "Workday-to-Concur run {RunId} acquired for frozen window {ExtractFrom} to {ExtractThrough} at stage {CurrentStage}",
                    run.RunId,
                    run.ExtractFrom,
                    run.ExtractThrough,
                    run.CurrentStage);

                var checkpoint = DeserialiseCheckpoint(run.FileStateJson);

                await ProcessTm1Async(run, claimToken, checkpoint, cancellationToken);

                failureCategory = "WorkdayEmployeeInput";

                var shouldContinue = await ProcessWorkdayAsync(run, claimToken, checkpoint, cancellationToken);
                if (!shouldContinue)
                {
                    return;
                }

                failureCategory = "ConcurTransformation";

                await ProcessTransformationAsync(run, claimToken, checkpoint, cancellationToken);

                failureCategory = "ConcurDelivery";

                await ProcessDeliveryAsync(run, claimToken, checkpoint, cancellationToken);

                failureCategory = "ConcurHousekeeping";

                await ProcessHousekeepingAsync(run, claimToken, checkpoint, cancellationToken);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception exception)
            {
                await _stateService.FailRunAsync(
                    run.RunId,
                    claimToken,
                    failureCategory,
                    TruncateError(exception.Message),
                    _timeProvider.GetUtcNow(),
                    cancellationToken);
                throw;
            }
        }

        private async Task ProcessTm1Async(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            if (run.CurrentStage.Equals(WorkdayConcurRunStage.Pending.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                await _stateService.UpdateStageAsync(
                    run.RunId,
                    claimToken,
                    WorkdayConcurRunStage.Pending,
                    WorkdayConcurRunStage.CollectingInputs,
                    now: _timeProvider.GetUtcNow(),
                    cancellationToken: cancellationToken);
                run.CurrentStage = WorkdayConcurRunStage.CollectingInputs.ToString();
            }

            if (!run.CurrentStage.Equals(WorkdayConcurRunStage.CollectingInputs.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            if (checkpoint.Tm1 is not null && string.Equals(checkpoint.Tm1.Status, "Succeeded", StringComparison.OrdinalIgnoreCase))
            {
                if (checkpoint.Tm1.File is null)
                {
                    throw new InvalidDataException("The successful TM1 checkpoint does not contain Blob identity evidence");
                }

                return;
            }

            if (checkpoint.Tm1 is null || !string.Equals(checkpoint.Tm1.Status, "InProgress", StringComparison.OrdinalIgnoreCase))
            {
                checkpoint.Tm1 = await _tm1Service.StartAsync(run.CorrelationId, cancellationToken);
                await SaveInputCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }
            else if (!string.Equals(checkpoint.Tm1.SynapseRunId, run.Tm1SynapseRunId, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("The persisted TM1 checkpoint does not match the run's Synapse identifier");
            }

            checkpoint.Tm1 = await _tm1Service.CompleteAsync(checkpoint.Tm1, cancellationToken);
            await SaveInputCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

            if (!string.Equals(checkpoint.Tm1.Status, "Succeeded", StringComparison.OrdinalIgnoreCase) || checkpoint.Tm1.File is null)
            {
                throw new InvalidOperationException(checkpoint.Tm1.FailureMessage ?? $"TM1 pickup ended with status '{checkpoint.Tm1.Status}'");
            }
        }

        private async Task<bool> ProcessWorkdayAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            if (!run.CurrentStage.Equals(WorkdayConcurRunStage.CollectingInputs.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (checkpoint.WorkdayEmployeeFile is not null)
            {
                if (!checkpoint.WorkdayEmployeeCount.HasValue || checkpoint.WorkdayEmployeeCount <= 0)
                {
                    throw new InvalidDataException("The staged Workday employee checkpoint does not contain a valid employee count");
                }

                return true;
            }

            var workers = await _workersClient.GetWorkersAsync(run.ExtractFrom, run.ExtractThrough, cancellationToken);
            if (workers.Count == 0)
            {
                await _stateService.CompleteNoDataRunAsync(run.RunId, claimToken, _timeProvider.GetUtcNow(), cancellationToken);
                return false;
            }

            checkpoint.WorkdayEmployeeFile = await _csvService.StageAsync(workers, cancellationToken);
            checkpoint.WorkdayEmployeeCount = workers.Count;
            await SaveInputCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

            return true;
        }

        private async Task ProcessTransformationAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            if (run.CurrentStage.Equals(WorkdayConcurRunStage.CollectingInputs.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                await _stateService.UpdateStageAsync(
                    run.RunId,
                    claimToken,
                    WorkdayConcurRunStage.CollectingInputs,
                    WorkdayConcurRunStage.Transforming,
                    JsonSerializer.Serialize(checkpoint),
                    checkpoint.Tm1?.SynapseRunId,
                    now: _timeProvider.GetUtcNow(),
                    cancellationToken: cancellationToken);
                run.CurrentStage = WorkdayConcurRunStage.Transforming.ToString();
            }

            if (!run.CurrentStage.Equals(WorkdayConcurRunStage.Transforming.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            if (checkpoint.Transformation is not null
                && string.Equals(checkpoint.Transformation.Status, SynapseSucceededStatus, StringComparison.OrdinalIgnoreCase)
                && checkpoint.Transformation.OutputFiles.Count > 0)
            {
                await AdvanceToDeliveryAsync(run, claimToken, checkpoint, cancellationToken);
                return;
            }

            if (checkpoint.Transformation is null || !string.Equals(checkpoint.Transformation.Status, SynapseInProgressStatus, StringComparison.OrdinalIgnoreCase))
            {
                checkpoint.Transformation = await _transformationService.StartAsync(run.CorrelationId, cancellationToken);
                await SaveTransformationCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }
            else if (!string.Equals(checkpoint.Transformation.SynapseRunId, run.TransformSynapseRunId, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("The persisted transformation checkpoint does not match the run's Synapse identifier");
            }

            var transformation = checkpoint.Transformation ?? throw new InvalidDataException("The transformation checkpoint was not created");

            checkpoint.Transformation = await _transformationService.CompleteAsync(transformation, cancellationToken);
            await SaveTransformationCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

            if (!string.Equals(checkpoint.Transformation.Status, SynapseSucceededStatus, StringComparison.OrdinalIgnoreCase) || checkpoint.Transformation.OutputFiles.Count == 0)
            {
                throw new InvalidOperationException(checkpoint.Transformation.FailureMessage ?? $"Concur transformation ended with status '{checkpoint.Transformation.Status}'");
            }

            await AdvanceToDeliveryAsync(run, claimToken, checkpoint, cancellationToken);
        }

        private async Task AdvanceToDeliveryAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            var transformation = checkpoint.Transformation ?? throw new InvalidDataException("The completed transformation checkpoint is missing");

            await _stateService.UpdateStageAsync(
                run.RunId,
                claimToken,
                WorkdayConcurRunStage.Transforming,
                WorkdayConcurRunStage.Delivering,
                JsonSerializer.Serialize(checkpoint),
                checkpoint.Tm1?.SynapseRunId,
                transformation.SynapseRunId,
                now: _timeProvider.GetUtcNow(),
                cancellationToken: cancellationToken);
            run.CurrentStage = WorkdayConcurRunStage.Delivering.ToString();
        }

        private async Task ProcessDeliveryAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            if (!run.CurrentStage.Equals(WorkdayConcurRunStage.Delivering.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            var transformation = checkpoint.Transformation ?? throw new InvalidDataException("The Concur delivery has no completed transformation checkpoint");
            if (transformation.OutputFiles.Count == 0)
            {
                throw new InvalidDataException("The Concur delivery has no selected output files");
            }

            if (checkpoint.Delivery is not null && checkpoint.Delivery.Status == WorkdayConcurDeliveryStatus.Succeeded)
            {
                await AdvanceToMovingFilesAsync(run, claimToken, checkpoint, cancellationToken);
                return;
            }

            if (checkpoint.Delivery is null)
            {
                checkpoint.Delivery = await _deliveryService.PrepareAsync(run.CorrelationId, transformation.OutputFiles, cancellationToken);
                await SaveDeliveryCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }

            if (checkpoint.Delivery.Status == WorkdayConcurDeliveryStatus.Staged)
            {
                checkpoint.Delivery.Status = WorkdayConcurDeliveryStatus.Starting;
                await SaveDeliveryCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

                checkpoint.Delivery = await _deliveryService.StartAsync(run.CorrelationId, checkpoint.Delivery, cancellationToken);
                await SaveDeliveryCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }
            else if (checkpoint.Delivery.Status == WorkdayConcurDeliveryStatus.Starting)
            {
                throw new InvalidOperationException("A failed or ambiguous Concur delivery requires reconciliation before it can be retried");
            }
            else if (checkpoint.Delivery.Status != WorkdayConcurDeliveryStatus.InProgress)
            {
                throw new InvalidOperationException("A failed or ambiguous Concur delivery requires reconciliation before it can be retried");
            }

            if (!string.IsNullOrWhiteSpace(run.DeliverySynapseRunId)
                && !string.Equals(checkpoint.Delivery.SynapseRunId, run.DeliverySynapseRunId, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("The persisted delivery checkpoint does not match the run's Synapse identifier");
            }

            var delivery = checkpoint.Delivery ?? throw new InvalidDataException("The delivery checkpoint was not created");

            checkpoint.Delivery = await _deliveryService.CompleteAsync(delivery, cancellationToken);
            await SaveDeliveryCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

            if (checkpoint.Delivery.Status != WorkdayConcurDeliveryStatus.Succeeded)
            {
                throw new InvalidOperationException(checkpoint.Delivery.FailureMessage ?? $"Concur delivery ended with status '{checkpoint.Delivery.Status}'");
            }

            await AdvanceToMovingFilesAsync(run, claimToken, checkpoint, cancellationToken);
        }

        private async Task AdvanceToMovingFilesAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            var delivery = checkpoint.Delivery ?? throw new InvalidDataException("The completed Concur delivery checkpoint is missing");

            await _stateService.UpdateStageAsync(
                run.RunId,
                claimToken,
                WorkdayConcurRunStage.Delivering,
                WorkdayConcurRunStage.MovingFiles,
                JsonSerializer.Serialize(checkpoint),
                checkpoint.Tm1?.SynapseRunId,
                checkpoint.Transformation?.SynapseRunId,
                delivery.SynapseRunId,
                now: _timeProvider.GetUtcNow(),
                cancellationToken: cancellationToken);
            run.CurrentStage = WorkdayConcurRunStage.MovingFiles.ToString();
        }

        private async Task ProcessHousekeepingAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            if (!run.CurrentStage.Equals(WorkdayConcurRunStage.MovingFiles.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            var transformation = checkpoint.Transformation ?? throw new InvalidDataException("File housekeeping has no completed transformation checkpoint");
            if (transformation.OutputFiles.Count == 0)
            {
                throw new InvalidDataException("File housekeeping has no delivered output files");
            }

            if (checkpoint.Housekeeping is null)
            {
                checkpoint.Housekeeping = await _housekeepingService.PrepareAsync(transformation.OutputFiles, cancellationToken);
                await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }

            foreach (var move in checkpoint.Housekeeping.Moves)
            {
                await CompleteMoveAsync(run, claimToken, checkpoint, move, cancellationToken);
            }

            checkpoint.Housekeeping.Status = WorkdayConcurHousekeepingStatus.Succeeded;
            checkpoint.Housekeeping.CompletedOn = _timeProvider.GetUtcNow();
            await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

            await _stateService.CommitRunAsync(run.RunId, claimToken, _timeProvider.GetUtcNow(), cancellationToken);
        }

        private async Task CompleteMoveAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, WorkdayConcurFileMove move, CancellationToken cancellationToken)
        {
            if (move.CopyStatus != WorkdayConcurFileMoveStatus.Succeeded)
            {
                await CompleteCopyAsync(run, claimToken, checkpoint, move, cancellationToken);
            }

            if (move.DeleteStatus != WorkdayConcurFileMoveStatus.Succeeded)
            {
                await CompleteDeleteAsync(run, claimToken, checkpoint, move, cancellationToken);
            }
        }

        private async Task CompleteCopyAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, WorkdayConcurFileMove move, CancellationToken cancellationToken)
        {
            if (move.CopyStatus != WorkdayConcurFileMoveStatus.InProgress)
            {
                move.CopyStatus = WorkdayConcurFileMoveStatus.Starting;
                move.CopySynapseRunId = null;
                move.CopyStartedOn = null;
                move.FailureMessage = null;
                await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

                await _housekeepingService.StartCopyAsync(run.CorrelationId, move, cancellationToken);
                await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }
            else
            {
                ValidateHousekeepingRunId(run, move.CopySynapseRunId);
            }

            if (move.CopyStatus == WorkdayConcurFileMoveStatus.InProgress)
            {
                await _housekeepingService.CompleteCopyAsync(move, cancellationToken);
                await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }

            if (move.CopyStatus != WorkdayConcurFileMoveStatus.Succeeded)
            {
                throw new InvalidOperationException(move.FailureMessage ?? $"Synapse Blob copy ended with status '{move.CopyStatus}'");
            }
        }

        private async Task CompleteDeleteAsync(WorkdayConcurRun run, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, WorkdayConcurFileMove move, CancellationToken cancellationToken)
        {
            if (move.DeleteStatus != WorkdayConcurFileMoveStatus.InProgress)
            {
                move.DeleteStatus = WorkdayConcurFileMoveStatus.Starting;
                move.DeleteSynapseRunId = null;
                move.DeleteStartedOn = null;
                move.FailureMessage = null;
                await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);

                await _housekeepingService.StartDeleteAsync(run.CorrelationId, move, cancellationToken);
                await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }
            else
            {
                ValidateHousekeepingRunId(run, move.DeleteSynapseRunId);
            }

            if (move.DeleteStatus == WorkdayConcurFileMoveStatus.InProgress)
            {
                await _housekeepingService.CompleteDeleteAsync(move, cancellationToken);
                await SaveHousekeepingCheckpointAsync(run.RunId, claimToken, checkpoint, cancellationToken);
            }

            if (move.DeleteStatus != WorkdayConcurFileMoveStatus.Succeeded)
            {
                throw new InvalidOperationException(move.FailureMessage ?? $"Synapse Blob delete ended with status '{move.DeleteStatus}'");
            }
        }

        private static void ValidateHousekeepingRunId(WorkdayConcurRun run, string? checkpointRunId)
        {
            if (!string.Equals(checkpointRunId, run.HousekeepingSynapseRunId, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("The persisted housekeeping checkpoint does not match the run's Synapse identifier");
            }
        }

        private Task SaveInputCheckpointAsync(Guid runId, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            return _stateService.UpdateStageAsync(
                runId,
                claimToken,
                WorkdayConcurRunStage.CollectingInputs,
                WorkdayConcurRunStage.CollectingInputs,
                JsonSerializer.Serialize(checkpoint),
                checkpoint.Tm1?.SynapseRunId,
                now: _timeProvider.GetUtcNow(),
                cancellationToken: cancellationToken);
        }

        private Task SaveTransformationCheckpointAsync(Guid runId, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            return _stateService.UpdateStageAsync(
                runId,
                claimToken,
                WorkdayConcurRunStage.Transforming,
                WorkdayConcurRunStage.Transforming,
                JsonSerializer.Serialize(checkpoint),
                checkpoint.Tm1?.SynapseRunId,
                checkpoint.Transformation?.SynapseRunId,
                now: _timeProvider.GetUtcNow(),
                cancellationToken: cancellationToken);
        }

        private Task SaveDeliveryCheckpointAsync(Guid runId, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            return _stateService.UpdateStageAsync(
                runId,
                claimToken,
                WorkdayConcurRunStage.Delivering,
                WorkdayConcurRunStage.Delivering,
                JsonSerializer.Serialize(checkpoint),
                checkpoint.Tm1?.SynapseRunId,
                checkpoint.Transformation?.SynapseRunId,
                checkpoint.Delivery?.SynapseRunId,
                now: _timeProvider.GetUtcNow(),
                cancellationToken: cancellationToken);
        }

        private Task SaveHousekeepingCheckpointAsync(Guid runId, Guid claimToken, WorkdayConcurRunCheckpoint checkpoint, CancellationToken cancellationToken)
        {
            return _stateService.UpdateStageAsync(
                runId,
                claimToken,
                WorkdayConcurRunStage.MovingFiles,
                WorkdayConcurRunStage.MovingFiles,
                JsonSerializer.Serialize(checkpoint),
                checkpoint.Tm1?.SynapseRunId,
                checkpoint.Transformation?.SynapseRunId,
                checkpoint.Delivery?.SynapseRunId,
                GetCurrentHousekeepingRunId(checkpoint.Housekeeping),
                now: _timeProvider.GetUtcNow(),
                cancellationToken: cancellationToken);
        }

        private static string? GetCurrentHousekeepingRunId(WorkdayConcurHousekeepingCheckpoint? checkpoint)
        {
            if (checkpoint is null)
            {
                return null;
            }

            var currentMove = checkpoint.Moves.FirstOrDefault(move => move.DeleteStatus == WorkdayConcurFileMoveStatus.InProgress)
                ?? checkpoint.Moves.FirstOrDefault(move => move.CopyStatus == WorkdayConcurFileMoveStatus.InProgress);

            return currentMove?.DeleteSynapseRunId ?? currentMove?.CopySynapseRunId;
        }

        private static WorkdayConcurRunCheckpoint DeserialiseCheckpoint(string? fileStateJson)
        {
            return string.IsNullOrWhiteSpace(fileStateJson)
                ? new WorkdayConcurRunCheckpoint()
                : JsonSerializer.Deserialize<WorkdayConcurRunCheckpoint>(fileStateJson)
                    ?? throw new InvalidDataException("The persisted run checkpoint is empty");
        }

        private static string TruncateError(string message)
        {
            return message.Length <= 2000 ? message : message[..2000];
        }
    }
}
