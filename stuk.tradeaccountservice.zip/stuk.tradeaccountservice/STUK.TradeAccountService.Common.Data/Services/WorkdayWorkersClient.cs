using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Net;
using System.Text;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Retrieves effective and updated employees directly from Workday SOAP v40.0
    /// </summary>
    public class WorkdayWorkersClient : IWorkdayWorkersClient
    {
        private const string SoapMediaType = "text/xml";
        private const int InitialPage = 1;

        private readonly HttpClient _httpClient;
        private readonly IWorkdaySoapRequestFactory _requestFactory;
        private readonly IWorkdayWorkerResponseParser _responseParser;
        private readonly WorkdayConcurOptions _options;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayWorkersClient"/>
        /// </summary>
        /// <param name="httpClient">HTTP client configured for the Workday endpoint</param>
        /// <param name="requestFactory">Factory for the source-derived Workday SOAP requests</param>
        /// <param name="responseParser">Parser for Workday Get_Workers responses</param>
        /// <param name="options">Workday-to-Concur integration settings</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayWorkersClient(HttpClient httpClient, IWorkdaySoapRequestFactory requestFactory, IWorkdayWorkerResponseParser responseParser, IOptions<WorkdayConcurOptions> options)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _requestFactory = requestFactory ?? throw new ArgumentNullException(nameof(requestFactory));
            _responseParser = responseParser ?? throw new ArgumentNullException(nameof(responseParser));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
        }

        /// <inheritdoc />
        public async Task<IReadOnlyList<WorkdayWorker>> GetWorkersAsync(DateTimeOffset from, DateTimeOffset through, CancellationToken cancellationToken = default)
        {
            ValidateOptions();

            if (through < from)
            {
                throw new ArgumentException("The Workday integration window cannot end before it starts.", nameof(through));
            }

            var employeeIds = new List<string>();
            var knownEmployeeIds = new HashSet<string>(StringComparer.Ordinal);

            await AddReferencePagesAsync(
                page => _requestFactory.CreateEffectiveWorkerRequest(from, through, page, _options.WorkdayPageSize),
                employeeIds,
                knownEmployeeIds,
                cancellationToken);

            await AddReferencePagesAsync(
                page => _requestFactory.CreateUpdatedWorkerRequest(from, through, page, _options.WorkdayPageSize),
                employeeIds,
                knownEmployeeIds,
                cancellationToken);

            var workers = new List<WorkdayWorker>();
            foreach (var employeeIdBatch in employeeIds.Chunk(_options.WorkdayDetailBatchSize))
            {
                await AddWorkerDetailPagesAsync(employeeIdBatch, workers, cancellationToken);
            }

            return workers;
        }

        private async Task AddReferencePagesAsync(Func<int, string> requestFactory, ICollection<string> employeeIds, ISet<string> knownEmployeeIds, CancellationToken cancellationToken)
        {
            var pageNumber = InitialPage;

            while (true)
            {
                var responseXml = await SendAsync(requestFactory(pageNumber), cancellationToken);
                var page = _responseParser.ParseReferencePage(responseXml);

                foreach (var employeeId in page.EmployeeIds)
                {
                    if (knownEmployeeIds.Add(employeeId))
                    {
                        employeeIds.Add(employeeId);
                    }
                }

                if (pageNumber >= page.TotalPages)
                {
                    return;
                }

                pageNumber++;
            }
        }

        private async Task AddWorkerDetailPagesAsync(IReadOnlyCollection<string> employeeIds, ICollection<WorkdayWorker> workers, CancellationToken cancellationToken)
        {
            var remainingEmployeeIds = employeeIds.ToList();
            var pageNumber = InitialPage;

            while (remainingEmployeeIds.Count > 0)
            {
                WorkdayWorkerPage page;
                try
                {
                    var requestXml = _requestFactory.CreateWorkerDetailRequest(
                        remainingEmployeeIds,
                        pageNumber,
                        _options.WorkdayPageSize);
                    var responseXml = await SendAsync(requestXml, cancellationToken);
                    page = _responseParser.ParseWorkerPage(responseXml);
                }
                catch (WorkdayInvalidEmployeeIdException exception)
                    when (remainingEmployeeIds.Remove(exception.EmployeeId))
                {
                    continue;
                }

                foreach (var worker in page.Workers)
                {
                    workers.Add(worker);
                }

                if (pageNumber >= page.TotalPages)
                {
                    return;
                }

                pageNumber++;
            }
        }

        private async Task<string> SendAsync(string requestXml, CancellationToken cancellationToken)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, string.Empty)
            {
                Content = new StringContent(requestXml, Encoding.UTF8, SoapMediaType)
            };

            using var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            var responseXml = await response.Content.ReadAsStringAsync(cancellationToken);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                if (!string.IsNullOrWhiteSpace(responseXml))
                {
                    _responseParser.ParseReferencePage(responseXml);
                }

                throw new HttpRequestException(
                    $"Workday returned HTTP {(int)response.StatusCode} ({response.ReasonPhrase}).",
                    null,
                    response.StatusCode);
            }

            return responseXml;
        }

        private void ValidateOptions()
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.WorkdayEndpoint);

            if (_httpClient.BaseAddress is null)
            {
                throw new InvalidOperationException("The Workday HTTP client does not have a base address.");
            }

            if (_httpClient.BaseAddress.Scheme != Uri.UriSchemeHttps)
            {
                throw new InvalidOperationException("The Workday HTTP client base address must use HTTPS.");
            }

            if (_options.WorkdayPageSize <= 0
                || _options.WorkdayDetailBatchSize <= 0
                || _options.WorkdayRequestTimeoutSeconds <= 0)
            {
                throw new InvalidOperationException(
                    "The Workday page size, detail batch size and request timeout must be greater than zero.");
            }
        }
    }
}
