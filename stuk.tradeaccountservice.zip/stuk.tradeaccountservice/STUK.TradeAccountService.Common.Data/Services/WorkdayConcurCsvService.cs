using Microsoft.Extensions.Options;
using System.Text;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Reproduces the Mule Workday employee mapping and stages SG_CONCUR_DAILY.csv
    /// </summary>
    public class WorkdayConcurCsvService : IWorkdayConcurCsvService
    {
        private const string EmployeeBlobName = "input/SG_CONCUR_DAILY.csv";

        private static readonly string[] Headers =
        {
            "EMPLID", "SGID", "EMAIL", "NAME", "PREF_FIRST_NAME", "FIRST_NAME", "LAST_NAME", "JOBTITLE",
            "GRADE", "COST CENTRE", "COST CODE", "STRUCTURE", "COMPANY", "BRAND", "COMPCAR FLG", "PL ACCT",
            "LEDGER CODE", "LINE MANAGER1", "LM1 NAME", "LM1 GRADE", "LINE MANAGER2", "LM2 NAME", "LM2 GRADE",
            "TERMINATION DT", "IS APPROVE"
        };

        private readonly IWorkdayConcurBlobClient _blobClient;
        private readonly WorkdayConcurOptions _options;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurCsvService"/>
        /// </summary>
        /// <param name="blobClient">Authenticated Blob writer</param>
        /// <param name="options">Workday-to-Concur integration settings</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayConcurCsvService(IWorkdayConcurBlobClient blobClient, IOptions<WorkdayConcurOptions> options)
        {
            _blobClient = blobClient ?? throw new ArgumentNullException(nameof(blobClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileIdentity> StageAsync(IReadOnlyCollection<WorkdayWorker> workers, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(workers);
            if (workers.Count == 0)
            {
                throw new ArgumentException("At least one Workday worker is required", nameof(workers));
            }

            ValidateOptions();

            await using var content = CreateCsv(workers);
            return await _blobClient.UploadAsync(
                new Uri(_options.ConcurBlobServiceEndpoint, UriKind.Absolute),
                _options.ConcurBlobContainerName,
                EmployeeBlobName,
                content,
                cancellationToken);
        }

        private MemoryStream CreateCsv(IEnumerable<WorkdayWorker> workers)
        {
            var content = new MemoryStream();
            using (var writer = new StreamWriter(content, new UTF8Encoding(false), leaveOpen: true))
            {
                writer.NewLine = "\n";
                writer.WriteLine(string.Join(',', Headers));

                foreach (var worker in workers)
                {
                    writer.WriteLine(string.Join(',', Map(worker).Select(EscapeCsv)));
                }
            }

            content.Position = 0;
            return content;
        }

        private string[] Map(WorkdayWorker worker)
        {
            ArgumentNullException.ThrowIfNull(worker);

            var firstName = RemoveCommas(worker.PreferredFirstName);
            var lastName = RemoveCommas(worker.PreferredLastName);
            return new[]
            {
                RemoveCommas(worker.EmployeeId),
                FindOverride(worker, "UPN"),
                RemoveCommas(worker.PrimaryWorkEmail),
                string.IsNullOrEmpty(worker.PreferredFirstName) || string.IsNullOrEmpty(worker.PreferredLastName)
                    ? string.Empty
                    : RemoveCommas($"{worker.PreferredFirstName} {worker.PreferredLastName}"),
                firstName,
                firstName,
                lastName,
                RemoveCommas(worker.PositionTitle),
                FindOverride(worker, "Compensation Grade Number"),
                RemoveCommas(worker.OrganizationName),
                FindOverride(worker, "Cost Center Code"),
                string.Empty,
                string.Empty,
                string.Empty,
                MapCompanyCar(worker),
                FindCustomId(worker, "SUK_Purchase_Ledger_Code_UK"),
                _options.ConcurLedgerCode,
                FindOverride(worker, "Manager1"),
                string.Empty,
                string.Empty,
                FindOverride(worker, "Manager2"),
                string.Empty,
                string.Empty,
                RemoveCommas(worker.TerminationDate),
                worker.FirstIntegrationFieldOverrideValue is null
                    ? _options.ConcurApprovalDefault
                    : RemoveCommas(worker.FirstIntegrationFieldOverrideValue)
            };
        }

        private static string FindOverride(WorkdayWorker worker, string identifier)
        {
            return RemoveCommas(worker.IntegrationFieldOverrides
                .FirstOrDefault(value => value.Key.Contains(identifier, StringComparison.Ordinal))
                .Value);
        }

        private static string FindCustomId(WorkdayWorker worker, string identifier)
        {
            return RemoveCommas(worker.CustomIds
                .FirstOrDefault(value => value.Key.Contains(identifier, StringComparison.Ordinal))
                .Value);
        }

        private static string MapCompanyCar(WorkdayWorker worker)
        {
            return FindOverrideValue(worker, "COMPCAR_FLG") switch
            {
                "Company Car" => "True",
                "No Company Car" => "False",
                _ => string.Empty
            };
        }

        private static string FindOverrideValue(WorkdayWorker worker, string identifier)
        {
            return worker.IntegrationFieldOverrides
                .FirstOrDefault(value => value.Key.Contains(identifier, StringComparison.Ordinal))
                .Value ?? string.Empty;
        }

        private static string RemoveCommas(string? value)
        {
            return (value ?? string.Empty).Replace(",", string.Empty, StringComparison.Ordinal);
        }

        private static string EscapeCsv(string value)
        {
            return value.IndexOfAny(new[] { '"', '\r', '\n' }) < 0
                ? value
                : $"\"{value.Replace("\"", "\"\"", StringComparison.Ordinal)}\"";
        }

        private void ValidateOptions()
        {
            if (!Uri.TryCreate(_options.ConcurBlobServiceEndpoint, UriKind.Absolute, out var endpoint)
                || endpoint.Scheme != Uri.UriSchemeHttps)
            {
                throw new InvalidOperationException("The Concur Blob service endpoint must be an absolute HTTPS URI");
            }

            if (string.IsNullOrWhiteSpace(_options.ConcurBlobContainerName))
            {
                throw new InvalidOperationException("The Concur Blob container name is required");
            }

            if (string.IsNullOrWhiteSpace(_options.ConcurLedgerCode))
            {
                throw new InvalidOperationException("The Concur ledger code is required");
            }

            if (string.IsNullOrWhiteSpace(_options.ConcurApprovalDefault))
            {
                throw new InvalidOperationException("The Concur approval default is required");
            }
        }
    }
}
