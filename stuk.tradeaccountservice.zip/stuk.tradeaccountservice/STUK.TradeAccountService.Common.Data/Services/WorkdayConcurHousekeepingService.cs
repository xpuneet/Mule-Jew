using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Coordinates restart-safe post-delivery Blob moves through existing Synapse pipelines
    /// </summary>
    public class WorkdayConcurHousekeepingService : IWorkdayConcurHousekeepingService
    {
        private const string ArchiveFolder = "archive";
        private const string CollectedFolder = "collected";
        private const string CopyPipelineName = "Blob_Archive_With_Delete";
        private const string DeletePipelineName = "Blob_Delete";
        private const string InputFolder = "input";
        private const string SucceededStatus = "Succeeded";
        private const string TriggerName = "WorkdayConcurTimerFunction";
        private const string TriggerSource = "stuk.tradeaccountservice";

        private readonly ISynapsePipelineClient _synapseClient;
        private readonly IWorkdayConcurBlobClient _blobClient;
        private readonly WorkdayConcurOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurHousekeepingService"/>
        /// </summary>
        /// <param name="synapseClient">Client for the existing Synapse pipelines</param>
        /// <param name="blobClient">Client used to select and validate Blob identities</param>
        /// <param name="options">Workday-to-Concur settings</param>
        /// <param name="timeProvider">Provides the current UTC time</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayConcurHousekeepingService(ISynapsePipelineClient synapseClient, IWorkdayConcurBlobClient blobClient, IOptions<WorkdayConcurOptions> options, TimeProvider timeProvider)
        {
            _synapseClient = synapseClient ?? throw new ArgumentNullException(nameof(synapseClient));
            _blobClient = blobClient ?? throw new ArgumentNullException(nameof(blobClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurHousekeepingCheckpoint> PrepareAsync(IReadOnlyCollection<WorkdayConcurFileIdentity> outputFiles, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(outputFiles);
            if (outputFiles.Count == 0)
            {
                throw new ArgumentException("At least one delivered Concur output is required", nameof(outputFiles));
            }

            ValidateOptions();

            var endpoint = new Uri(_options.ConcurBlobServiceEndpoint, UriKind.Absolute);
            var inputFiles = await _blobClient.ListFilesAsync(endpoint, _options.ConcurBlobContainerName, InputFolder, cancellationToken);
            var moves = new List<WorkdayConcurFileMove>();

            foreach (var outputFile in outputFiles)
            {
                moves.Add(CreateMove(outputFile, CollectedFolder));
            }

            foreach (var inputFile in inputFiles)
            {
                moves.Add(CreateMove(inputFile, ArchiveFolder));
            }

            return new WorkdayConcurHousekeepingCheckpoint
            {
                BlobServiceEndpoint = endpoint.AbsoluteUri,
                Moves = moves,
                Status = WorkdayConcurHousekeepingStatus.InProgress
            };
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileMove> StartCopyAsync(Guid correlationId, WorkdayConcurFileMove move, CancellationToken cancellationToken = default)
        {
            ValidateMove(move);
            if (move.CopyStatus != WorkdayConcurFileMoveStatus.Starting)
            {
                throw new InvalidOperationException("The file move must be marked as copy-starting before Synapse is invoked");
            }

            var currentSource = await GetFileAsync(move.SourcePath, move.SourceFileName, cancellationToken);
            if (currentSource is null)
            {
                var existingDestination = await GetFileAsync(move.DestinationPath, move.DestinationFileName, cancellationToken);
                if (existingDestination is not null && existingDestination.ContentLength == move.SourceFile.ContentLength)
                {
                    move.DestinationFile = existingDestination;
                    move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
                    move.FailureMessage = null;
                    return move;
                }

                throw new FileNotFoundException($"Source Blob '{move.SourcePath}/{move.SourceFileName}' was not found");
            }

            ValidateSourceIdentity(move, currentSource);

            move.CopySynapseRunId = await _synapseClient.StartAsync(CopyPipelineName, CreateCopyParameters(correlationId, move), cancellationToken);
            move.CopyStartedOn = _timeProvider.GetUtcNow();
            move.CopyStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.FailureMessage = null;

            return move;
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileMove> CompleteCopyAsync(WorkdayConcurFileMove move, CancellationToken cancellationToken = default)
        {
            ValidateMove(move);
            if (move.CopyStatus != WorkdayConcurFileMoveStatus.InProgress)
            {
                throw new InvalidOperationException("The file move does not contain an in-progress Synapse copy");
            }

            ArgumentException.ThrowIfNullOrWhiteSpace(move.CopySynapseRunId);

            var result = await _synapseClient.WaitForCompletionAsync(move.CopySynapseRunId, cancellationToken);
            if (!string.Equals(result.Status, SucceededStatus, StringComparison.OrdinalIgnoreCase))
            {
                move.CopyStatus = ParseTerminalStatus(result.Status);
                move.FailureMessage = result.Message ?? $"Synapse Blob copy ended with status '{result.Status}'";
                return move;
            }

            var destination = await GetFileAsync(move.DestinationPath, move.DestinationFileName, cancellationToken);
            if (destination is null || destination.ContentLength != move.SourceFile.ContentLength)
            {
                move.CopyStatus = WorkdayConcurFileMoveStatus.ValidationFailed;
                move.FailureMessage = $"Copied Blob '{move.DestinationPath}/{move.DestinationFileName}' does not match the source length";
                return move;
            }

            move.DestinationFile = destination;
            move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
            move.FailureMessage = null;

            return move;
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileMove> StartDeleteAsync(Guid correlationId, WorkdayConcurFileMove move, CancellationToken cancellationToken = default)
        {
            ValidateMove(move);
            if (move.CopyStatus != WorkdayConcurFileMoveStatus.Succeeded || move.DestinationFile is null)
            {
                throw new InvalidOperationException("The source cannot be deleted until its copied Blob has been validated");
            }

            if (move.DeleteStatus != WorkdayConcurFileMoveStatus.Starting)
            {
                throw new InvalidOperationException("The file move must be marked as delete-starting before Synapse is invoked");
            }

            var currentSource = await GetFileAsync(move.SourcePath, move.SourceFileName, cancellationToken);
            if (currentSource is null)
            {
                move.DeleteStatus = WorkdayConcurFileMoveStatus.Succeeded;
                move.FailureMessage = null;
                return move;
            }

            ValidateSourceIdentity(move, currentSource);

            move.DeleteSynapseRunId = await _synapseClient.StartAsync(DeletePipelineName, CreateDeleteParameters(correlationId, move), cancellationToken);
            move.DeleteStartedOn = _timeProvider.GetUtcNow();
            move.DeleteStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.FailureMessage = null;

            return move;
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurFileMove> CompleteDeleteAsync(WorkdayConcurFileMove move, CancellationToken cancellationToken = default)
        {
            ValidateMove(move);

            if (move.DeleteStatus != WorkdayConcurFileMoveStatus.InProgress)
            {
                throw new InvalidOperationException("The file move does not contain an in-progress Synapse delete");
            }

            ArgumentException.ThrowIfNullOrWhiteSpace(move.DeleteSynapseRunId);

            var result = await _synapseClient.WaitForCompletionAsync(move.DeleteSynapseRunId, cancellationToken);
            var source = await GetFileAsync(move.SourcePath, move.SourceFileName, cancellationToken);

            if (source is null)
            {
                move.DeleteStatus = WorkdayConcurFileMoveStatus.Succeeded;
                move.FailureMessage = null;
                return move;
            }

            if (!string.Equals(result.Status, SucceededStatus, StringComparison.OrdinalIgnoreCase))
            {
                move.DeleteStatus = ParseTerminalStatus(result.Status);
                move.FailureMessage = result.Message ?? $"Synapse Blob delete ended with status '{result.Status}'";
                return move;
            }

            move.DeleteStatus = WorkdayConcurFileMoveStatus.ValidationFailed;
            move.FailureMessage = $"Source Blob '{move.SourcePath}/{move.SourceFileName}' still exists after Synapse reported success";

            return move;
        }

        private WorkdayConcurFileMove CreateMove(WorkdayConcurFileIdentity sourceFile, string destinationFolder)
        {
            var source = ParsePath(sourceFile.Path);

            if (!string.Equals(source.Container, _options.ConcurBlobContainerName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException($"Workday-to-Concur Blob '{sourceFile.Path}' is outside container '{_options.ConcurBlobContainerName}'");
            }

            return new WorkdayConcurFileMove
            {
                SourceFile = sourceFile,
                SourcePath = $"{source.Container}/{source.Folder}",
                SourceFileName = source.FileName,
                DestinationPath = $"{source.Container}/{destinationFolder}",
                DestinationFileName = CreateTimestampedFileName(source.FileName),
                CopyStatus = WorkdayConcurFileMoveStatus.Pending,
                DeleteStatus = WorkdayConcurFileMoveStatus.Pending
            };
        }

        private static void ValidateSourceIdentity(WorkdayConcurFileMove move, WorkdayConcurFileIdentity current)
        {
            if (!string.Equals(current.ETag, move.SourceFile.ETag, StringComparison.Ordinal) || current.ContentLength != move.SourceFile.ContentLength)
            {
                throw new InvalidDataException($"Source Blob '{move.SourcePath}/{move.SourceFileName}' changed after it was selected");
            }
        }

        private Task<WorkdayConcurFileIdentity?> GetFileAsync(string path, string fileName, CancellationToken cancellationToken)
        {
            var location = ParseLocation(path);
            return _blobClient.GetFileAsync(new Uri(_options.ConcurBlobServiceEndpoint, UriKind.Absolute), location.Container, $"{location.Folder}/{fileName}", cancellationToken);
        }

        private IReadOnlyDictionary<string, object?> CreateCopyParameters(Guid correlationId, WorkdayConcurFileMove move)
        {
            return new Dictionary<string, object?>
            {
                ["SourcePath"] = move.SourcePath,
                ["FileName"] = move.SourceFileName,
                ["DestinationPath"] = move.DestinationPath,
                ["SourceStorageAccountEndPoint"] = _options.ConcurBlobServiceEndpoint,
                ["IsErrorArchiveFileNameChange"] = true,
                ["ErrorArchiveFileName"] = move.DestinationFileName,
                ["TriggeredByFnApp"] = TriggerSource,
                ["TriggeredBySchedulerName"] = TriggerName,
                ["Id"] = correlationId.ToString("D"),
                ["CorrelationID"] = correlationId.ToString("D"),
                ["RetryCount"] = "0"
            };
        }

        private IReadOnlyDictionary<string, object?> CreateDeleteParameters(Guid correlationId, WorkdayConcurFileMove move)
        {
            return new Dictionary<string, object?>
            {
                ["SourcePath"] = move.SourcePath,
                ["FileName"] = move.SourceFileName,
                ["SourceStorageAccountEndPoint"] = _options.ConcurBlobServiceEndpoint,
                ["TriggeredByFnApp"] = TriggerSource,
                ["TriggeredBySchedulerName"] = TriggerName,
                ["Id"] = correlationId.ToString("D"),
                ["CorrelationID"] = correlationId.ToString("D")
            };
        }

        private static WorkdayConcurFileMoveStatus ParseTerminalStatus(string status)
        {
            if (Enum.TryParse<WorkdayConcurFileMoveStatus>(status, ignoreCase: true, out var parsed)
                && parsed is WorkdayConcurFileMoveStatus.Failed or WorkdayConcurFileMoveStatus.Cancelled)
            {
                return parsed;
            }

            throw new InvalidDataException($"Synapse returned unsupported terminal housekeeping status '{status}'");
        }

        private string CreateTimestampedFileName(string fileName)
        {
            var extension = Path.GetExtension(fileName);
            var name = Path.GetFileNameWithoutExtension(fileName);

            if (string.IsNullOrWhiteSpace(extension) || string.IsNullOrWhiteSpace(name))
            {
                throw new InvalidDataException($"Blob filename '{fileName}' does not contain a name and extension");
            }

            return $"{name}_{_timeProvider.GetUtcNow():yyyyMMddhhmmssfff}{extension}";
        }

        private void ValidateOptions()
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurBlobContainerName);

            if (!Uri.TryCreate(_options.ConcurBlobServiceEndpoint, UriKind.Absolute, out var endpoint) || endpoint.Scheme != Uri.UriSchemeHttps)
            {
                throw new InvalidOperationException("The Concur Blob service endpoint must be an absolute HTTPS URI");
            }
        }

        private static void ValidateMove(WorkdayConcurFileMove move)
        {
            ArgumentNullException.ThrowIfNull(move);
            ArgumentException.ThrowIfNullOrWhiteSpace(move.SourcePath);
            ArgumentException.ThrowIfNullOrWhiteSpace(move.SourceFileName);
            ArgumentException.ThrowIfNullOrWhiteSpace(move.DestinationPath);
            ArgumentException.ThrowIfNullOrWhiteSpace(move.DestinationFileName);
            ArgumentException.ThrowIfNullOrWhiteSpace(move.SourceFile.ETag);

            if (move.SourceFile.ContentLength <= 0)
            {
                throw new InvalidDataException("The selected source Blob is empty");
            }
        }

        private static BlobPath ParsePath(string path)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(path);

            var normalised = path.Trim('/');
            var firstSeparator = normalised.IndexOf('/');
            var lastSeparator = normalised.LastIndexOf('/');
            if (firstSeparator <= 0 || lastSeparator <= firstSeparator || lastSeparator == normalised.Length - 1)
            {
                throw new InvalidDataException($"Blob path '{path}' must contain a container, folder and filename");
            }

            return new BlobPath(normalised[..firstSeparator], normalised[(firstSeparator + 1)..lastSeparator], normalised[(lastSeparator + 1)..]);
        }

        private static BlobLocation ParseLocation(string path)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(path);

            var normalised = path.Trim('/');
            var separator = normalised.IndexOf('/');
            if (separator <= 0 || separator == normalised.Length - 1)
            {
                throw new InvalidDataException($"Blob location '{path}' must contain a container and folder");
            }

            return new BlobLocation(normalised[..separator], normalised[(separator + 1)..]);
        }

        private sealed record BlobPath(string Container, string Folder, string FileName);

        private sealed record BlobLocation(string Container, string Folder);
    }
}
