using Azure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Generates and delivers eligible Consolidated Sales snapshots to Data Lake
    /// </summary>
    public class DataLakeExportService : IDataLakeExportService
    {
        private const string Destination = "DataLake";
        private const string DatasetDirectory = "data/reception/ecs_conxref";
        private const string TokenDirectory = "operational/dl_5oprl_monitor_job_token/token_name=DL_F5_ECS_CONSXREF_DATA";
        private const string TokenFileName = "DL_F5_ECS_CONSXREF_DATA";
        private const int MaximumWorkItemsPerRun = 1;
        private const int LeaseDurationSeconds = 900;
        private const int LeaseRenewalIntervalSeconds = 60;
        private const int RetryDelaySeconds = 300;
        private const int MaximumRetryCount = 5;
        private readonly ILogger<DataLakeExportService> _logger;
        private readonly IConsolidatedSalesExportDataService _exportDataService;
        private readonly IPhocasConsXrefFileGenerator _fileGenerator;
        private readonly IDataLakeCompletionTokenGenerator _tokenGenerator;
        private readonly IDataLakeExportClient _dataLakeExportClient;
        private readonly ConsolidatedSalesDataLakeOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="DataLakeExportService"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="exportDataService">The durable export persistence service</param>
        /// <param name="fileGenerator">The shared legacy-compatible ConsXref generator</param>
        /// <param name="tokenGenerator">The completion-token generator</param>
        /// <param name="dataLakeExportClient">The direct ADLS Gen2 client</param>
        /// <param name="options">The Data Lake destination settings</param>
        /// <param name="timeProvider">Provider for processing timestamps and lease timers</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public DataLakeExportService(
            ILogger<DataLakeExportService> logger,
            IConsolidatedSalesExportDataService exportDataService,
            IPhocasConsXrefFileGenerator fileGenerator,
            IDataLakeCompletionTokenGenerator tokenGenerator,
            IDataLakeExportClient dataLakeExportClient,
            IOptions<ConsolidatedSalesDataLakeOptions> options,
            TimeProvider timeProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _exportDataService = exportDataService ?? throw new ArgumentNullException(nameof(exportDataService));
            _fileGenerator = fileGenerator ?? throw new ArgumentNullException(nameof(fileGenerator));
            _tokenGenerator = tokenGenerator ?? throw new ArgumentNullException(nameof(tokenGenerator));
            _dataLakeExportClient = dataLakeExportClient ?? throw new ArgumentNullException(nameof(dataLakeExportClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task RunAsync(string leaseOwner, Guid? exportDestinationId = null, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);
            ValidateOptions();

            for (var itemNumber = 0; itemNumber < MaximumWorkItemsPerRun; itemNumber++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var work = await _exportDataService.ClaimNextDestinationAsync(
                    Destination,
                    leaseOwner,
                    LeaseDurationSeconds,
                    MaximumRetryCount,
                    exportDestinationId,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                if (work is null)
                {
                    break;
                }

                await ProcessWithLeaseRenewalAsync(work, cancellationToken);
            }
        }

        private async Task ProcessWithLeaseRenewalAsync(
            ConsolidatedSalesExportDestinationWork work,
            CancellationToken cancellationToken)
        {
            using var processingCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            var renewalTask = RenewLeaseUntilCancelledAsync(work, processingCancellation.Token);
            var processingTask = ProcessAsync(work, processingCancellation.Token);
            var renewalCompletedFirst = false;

            try
            {
                var firstCompletedTask = await Task.WhenAny(processingTask, renewalTask);
                if (firstCompletedTask == renewalTask)
                {
                    renewalCompletedFirst = true;
                    await renewalTask;
                }

                await processingTask;
            }
            finally
            {
                await processingCancellation.CancelAsync();
                try
                {
                    await renewalTask;
                }
                catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                {
                    // Expected after delivery completes or a lease renewal fails.
                }
                catch when (renewalCompletedFirst)
                {
                    // The renewal failure was already observed and remains the primary exception.
                }

                if (!processingTask.IsCompleted)
                {
                    try
                    {
                        await processingTask;
                    }
                    catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                    {
                        // Delivery must stop when its SQL lease can no longer be renewed.
                    }
                }
            }
        }

        private async Task ProcessAsync(ConsolidatedSalesExportDestinationWork work, CancellationToken cancellationToken)
        {
            var claimToken = ValidateClaimedWork(work);

            _logger.LogInformation(
                "Data Lake delivery started for destination work {ExportDestinationId}, export {ExportRunId}, correlation {CorrelationId} and attempt {AttemptCount}",
                work.Id,
                work.ExportRunId,
                work.CorrelationId,
                work.AttemptCount);

            try
            {
                await using var content = new FileStream(
                    Path.Combine(Path.GetTempPath(), $"datalake-{Guid.NewGuid():N}.tmp"),
                    FileMode.CreateNew,
                    FileAccess.ReadWrite,
                    FileShare.None,
                    81920,
                    FileOptions.Asynchronous | FileOptions.SequentialScan | FileOptions.DeleteOnClose);

                var generated = await _fileGenerator.GenerateAsync(work.ExportRunId, work.ExportYear, content, cancellationToken);
                if (generated.RowCount != work.ExtractedRowCount)
                {
                    throw new InvalidDataException("The generated Data Lake row count does not match the completed Salesforce snapshot.");
                }

                var completedOn = _timeProvider.GetUtcNow();
                var stableTimestamp = work.CreatedOn.ToUniversalTime();
                var datasetFileName = string.Format(
                    CultureInfo.InvariantCulture,
                    "{0}_ConsXref{1}.csv",
                    work.ExportYear,
                    stableTimestamp.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture));
                var tokenContent = _tokenGenerator.Generate(completedOn, TokenFileName);
                var result = await _dataLakeExportClient.WriteAsync(
                    new DataLakeExportWriteRequest
                    {
                        FileSystem = _options.FileSystem,
                        DatasetDirectory = DatasetDirectory,
                        DatasetFileName = datasetFileName,
                        TokenDirectory = TokenDirectory,
                        TokenFileName = TokenFileName,
                        TokenContent = tokenContent,
                        ContentLength = generated.ByteCount,
                        RowCount = generated.RowCount,
                        ContentHash = generated.ContentHash,
                        ExportRunId = work.ExportRunId,
                        ExportDestinationId = work.Id,
                        CorrelationId = work.CorrelationId
                    },
                    content,
                    cancellationToken);

                await _exportDataService.CompleteDestinationAsync(
                    work.Id,
                    claimToken,
                    datasetFileName,
                    result.DatasetPath,
                    generated.ContentHash,
                    generated.RowCount,
                    generated.ByteCount,
                    null,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                _logger.LogInformation(
                    "Data Lake delivery completed for destination work {ExportDestinationId}, export {ExportRunId}, correlation {CorrelationId}, dataset {FileName}, path {FilePath}, rows {RowCount}, bytes {ByteCount} and hash {ContentHash}",
                    work.Id,
                    work.ExportRunId,
                    work.CorrelationId,
                    datasetFileName,
                    result.DatasetPath,
                    generated.RowCount,
                    generated.ByteCount,
                    generated.ContentHash);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception exception)
            {
                var isPermanent = exception is InvalidDataException or ArgumentException or InvalidOperationException;
                var errorCategory = GetErrorCategory(exception);
                DateTimeOffset? nextAttemptOn = isPermanent
                    ? null
                    : _timeProvider.GetUtcNow().AddSeconds(RetryDelaySeconds);
                var message = exception.Message.Length <= 2000 ? exception.Message : exception.Message[..2000];
                await _exportDataService.FailDestinationAsync(
                    work.Id,
                    claimToken,
                    errorCategory,
                    message,
                    nextAttemptOn,
                    isPermanent ? work.RetryCycleAttemptCount : MaximumRetryCount,
                    null,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                _logger.LogError(
                    exception,
                    "Data Lake delivery failed for destination work {ExportDestinationId}, export {ExportRunId}, correlation {CorrelationId}, category {ErrorCategory}, permanent {IsPermanent} and next attempt {NextAttemptOn}",
                    work.Id,
                    work.ExportRunId,
                    work.CorrelationId,
                    errorCategory,
                    isPermanent,
                    nextAttemptOn);
            }
        }

        private async Task RenewLeaseUntilCancelledAsync(
            ConsolidatedSalesExportDestinationWork work,
            CancellationToken cancellationToken)
        {
            var claimToken = work.ClaimToken ?? throw new InvalidOperationException($"Claimed Data Lake destination {work.Id} has no claim token.");
            while (true)
            {
                await Task.Delay(TimeSpan.FromSeconds(LeaseRenewalIntervalSeconds), _timeProvider, cancellationToken);
                await _exportDataService.RenewDestinationLeaseAsync(
                    work.Id,
                    claimToken,
                    LeaseDurationSeconds,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);
            }
        }

        private static Guid ValidateClaimedWork(ConsolidatedSalesExportDestinationWork work)
        {
            if (!string.Equals(work.Destination, Destination, StringComparison.Ordinal)
                || !string.Equals(work.Status, "Claimed", StringComparison.Ordinal)
                || work.ClaimToken is null
                || work.ExtractedRowCount is null
                || work.CreatedOn == default)
            {
                throw new InvalidOperationException("The Data Lake destination must reference a completed snapshot and hold an active claim.");
            }

            return work.ClaimToken.Value;
        }

        private static string GetErrorCategory(Exception exception)
        {
            return exception switch
            {
                InvalidDataException => "InvalidFileContract",
                ArgumentException or InvalidOperationException => "InvalidConfiguration",
                RequestFailedException or HttpRequestException or IOException => "DataLakeUnavailable",
                _ => "DataLakeDelivery"
            };
        }

        private void ValidateOptions()
        {
            if (!Uri.TryCreate(_options.ServiceUri, UriKind.Absolute, out var serviceUri)
                || !string.Equals(serviceUri.Scheme, Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase)
                || string.IsNullOrWhiteSpace(_options.FileSystem))
            {
                throw new InvalidOperationException("The HTTPS Data Lake service endpoint and filesystem must be configured.");
            }

        }
    }
}
