using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Starts and observes the Mule-free Synapse transformation and selects its output files
    /// </summary>
    public class WorkdayConcurTransformationService : IWorkdayConcurTransformationService
    {
        private const string CorrelationParameterName = "transactionCorrelationId";
        private const string InProgressStatus = "InProgress";
        private const string OutputFolderPath = "output";
        private const string SucceededStatus = "Succeeded";
        private const string ValidationFailedStatus = "ValidationFailed";

        private readonly IConcurSynapsePipelineClient _synapseClient;
        private readonly IWorkdayConcurBlobClient _blobClient;
        private readonly WorkdayConcurOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurTransformationService"/>
        /// </summary>
        /// <param name="synapseClient">Azure Synapse pipeline client</param>
        /// <param name="blobClient">Concur Blob output client</param>
        /// <param name="options">Workday-to-Concur settings</param>
        /// <param name="timeProvider">Provides deterministic UTC timestamps</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayConcurTransformationService(IConcurSynapsePipelineClient synapseClient, IWorkdayConcurBlobClient blobClient, IOptions<WorkdayConcurOptions> options, TimeProvider timeProvider)
        {
            _synapseClient = synapseClient ?? throw new ArgumentNullException(nameof(synapseClient));
            _blobClient = blobClient ?? throw new ArgumentNullException(nameof(blobClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurTransformationCheckpoint> StartAsync(Guid correlationId, CancellationToken cancellationToken = default)
        {
            if (correlationId == Guid.Empty)
            {
                throw new ArgumentException("A Workday-to-Concur correlation identifier is required", nameof(correlationId));
            }

            ValidateOptions();

            var parameters = new Dictionary<string, object?>
            {
                [CorrelationParameterName] = correlationId.ToString("D")
            };

            var runId = await _synapseClient.StartAsync(_options.ConcurTransformationPipelineName, parameters, cancellationToken);

            return new WorkdayConcurTransformationCheckpoint
            {
                SynapseRunId = runId,
                StartedOn = _timeProvider.GetUtcNow(),
                Status = InProgressStatus
            };
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurTransformationCheckpoint> CompleteAsync(WorkdayConcurTransformationCheckpoint checkpoint, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(checkpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.SynapseRunId);
            ValidateOptions();

            var run = await _synapseClient.WaitForCompletionAsync(checkpoint.SynapseRunId, cancellationToken);

            if (!string.Equals(run.Status, SucceededStatus, StringComparison.OrdinalIgnoreCase))
            {
                checkpoint.Status = run.Status;
                checkpoint.CompletedOn = _timeProvider.GetUtcNow();
                checkpoint.FailureMessage = string.IsNullOrWhiteSpace(run.Message)
                    ? $"Synapse Concur transformation ended with status '{run.Status}'"
                    : run.Message;

                return checkpoint;
            }

            var outputFiles = await _blobClient.ListFilesAsync(
                new Uri(_options.ConcurBlobServiceEndpoint, UriKind.Absolute),
                _options.ConcurBlobContainerName,
                OutputFolderPath,
                cancellationToken);

            if (outputFiles.Count == 0)
            {
                checkpoint.Status = ValidationFailedStatus;
                checkpoint.CompletedOn = _timeProvider.GetUtcNow();
                checkpoint.FailureMessage = "The successful Synapse Concur transformation produced no files under 'output'";
                return checkpoint;
            }

            checkpoint.OutputFiles = outputFiles;
            checkpoint.Status = SucceededStatus;
            checkpoint.CompletedOn = _timeProvider.GetUtcNow();
            checkpoint.FailureMessage = null;
            return checkpoint;
        }

        private void ValidateOptions()
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurTransformationPipelineName);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurBlobContainerName);

            if (!Uri.TryCreate(_options.ConcurBlobServiceEndpoint, UriKind.Absolute, out var endpoint) || endpoint.Scheme != Uri.UriSchemeHttps)
            {
                throw new InvalidOperationException("The Concur Blob service endpoint must be an absolute HTTPS URI");
            }
        }
    }
}
