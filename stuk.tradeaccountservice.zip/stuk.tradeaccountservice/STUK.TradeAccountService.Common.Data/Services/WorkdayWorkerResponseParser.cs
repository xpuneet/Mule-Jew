using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Xml;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Parses Workday Get_Workers SOAP responses for the Concur integration
    /// </summary>
    public class WorkdayWorkerResponseParser : IWorkdayWorkerResponseParser
    {
        private const string WorkdayNamespace = "urn:com.workday/bsvc";
        private const string EmployeeIdType = "Employee_ID";
        private const string WorkEmailType = "WORK";

        /// <inheritdoc />
        public WorkdayWorkerReferencePage ParseReferencePage(string responseXml)
        {
            var response = ParseResponse(responseXml);
            var page = ParsePaging(response);
            var employeeIds = response
                .Descendants(WorkdayName("Worker"))
                .Select(worker => FindId(worker.Element(WorkdayName("Worker_Reference")), EmployeeIdType))
                .Where(employeeId => !string.IsNullOrWhiteSpace(employeeId))
                .Cast<string>()
                .ToArray();

            return new WorkdayWorkerReferencePage
            {
                EmployeeIds = employeeIds,
                Page = page.Page,
                TotalPages = page.TotalPages
            };
        }

        /// <inheritdoc />
        public WorkdayWorkerPage ParseWorkerPage(string responseXml)
        {
            var response = ParseResponse(responseXml);
            var page = ParsePaging(response);
            var workers = response
                .Descendants(WorkdayName("Worker"))
                .Select(ParseWorker)
                .ToArray();

            return new WorkdayWorkerPage
            {
                Workers = workers,
                Page = page.Page,
                TotalPages = page.TotalPages
            };
        }

        private static WorkdayWorker ParseWorker(XElement workerElement)
        {
            var workerData = workerElement.Element(WorkdayName("Worker_Data")) ?? throw new InvalidDataException("The Workday worker response does not contain Worker_Data.");
            var employeeId = ElementValue(workerData, "Worker_ID");

            if (string.IsNullOrWhiteSpace(employeeId))
            {
                throw new InvalidDataException("The Workday worker response contains a worker without Worker_ID.");
            }

            return new WorkdayWorker
            {
                EmployeeId = employeeId,
                PrimaryWorkEmail = FindPrimaryWorkEmail(workerData),
                PreferredFirstName = DescendantValue(workerData, "Preferred_Name_Data", "First_Name"),
                PreferredLastName = DescendantValue(workerData, "Preferred_Name_Data", "Last_Name"),
                PositionTitle = DescendantValue(workerData, "Position_Data", "Position_Title"),
                OrganizationName = DescendantValue(workerData, "Worker_Organization_Data", "Organization_Name"),
                TerminationDate = DescendantValue(workerData, "Worker_Status_Data", "Termination_Date"),
                FirstIntegrationFieldOverrideValue = workerData
                    .Elements(WorkdayName("Integration_Field_Override_Data"))
                    .Select(field => ElementValue(field, "Value"))
                    .FirstOrDefault(),
                IntegrationFieldOverrides = ParseIntegrationFieldOverrides(workerData),
                CustomIds = ParseCustomIds(workerData)
            };
        }

        private static IReadOnlyDictionary<string, string> ParseIntegrationFieldOverrides(XElement workerData)
        {
            var values = new Dictionary<string, string>(StringComparer.Ordinal);

            foreach (var field in workerData.Elements(WorkdayName("Integration_Field_Override_Data")))
            {
                var value = ElementValue(field, "Value");
                var identifiers = field
                    .Element(WorkdayName("Field_Reference"))?
                    .Elements(WorkdayName("ID"))
                    .Select(identifier => identifier.Value)
                    .Where(identifier => !string.IsNullOrWhiteSpace(identifier))
                    ?? Enumerable.Empty<string>();

                foreach (var identifier in identifiers)
                {
                    values.TryAdd(identifier, value);
                }
            }

            return values;
        }

        private static IReadOnlyDictionary<string, string> ParseCustomIds(XElement workerData)
        {
            var values = new Dictionary<string, string>(StringComparer.Ordinal);

            foreach (var customId in workerData.Descendants(WorkdayName("Custom_ID")))
            {
                var data = customId.Element(WorkdayName("Custom_ID_Data"));
                var value = data is null ? string.Empty : ElementValue(data, "ID");
                var identifiers = data?
                    .Element(WorkdayName("ID_Type_Reference"))?
                    .Elements(WorkdayName("ID"))
                    .Select(identifier => identifier.Value)
                    .Where(identifier => !string.IsNullOrWhiteSpace(identifier))
                    ?? Enumerable.Empty<string>();

                foreach (var identifier in identifiers)
                {
                    values.TryAdd(identifier, value);
                }
            }

            return values;
        }

        private static string FindPrimaryWorkEmail(XElement workerData)
        {
            var email = workerData
                .Descendants(WorkdayName("Email_Address_Data"))
                .FirstOrDefault(emailData => IsPrimaryWorkUsage(emailData));

            return email is null ? string.Empty : ElementValue(email, "Email_Address");
        }

        private static bool IsPrimaryWorkUsage(XElement emailData)
        {
            return emailData
                .Elements(WorkdayName("Usage_Data"))
                .SelectMany(usage => usage.Elements(WorkdayName("Type_Data")))
                .Any(typeData => string.Equals(
                        typeData.Attribute(WorkdayName("Primary"))?.Value,
                        "1",
                        StringComparison.Ordinal)
                    && typeData
                        .Descendants(WorkdayName("ID"))
                        .Any(identifier => string.Equals(identifier.Value, WorkEmailType, StringComparison.Ordinal)));
        }

        private static string DescendantValue(XElement parent, string containerName, string valueName)
        {
            return parent
                .Descendants(WorkdayName(containerName))
                .Select(container => container.Descendants(WorkdayName(valueName)).FirstOrDefault()?.Value)
                .FirstOrDefault(value => value is not null)
                ?? string.Empty;
        }

        private static string ElementValue(XElement parent, string elementName)
        {
            return parent.Element(WorkdayName(elementName))?.Value ?? string.Empty;
        }

        private static string? FindId(XElement? reference, string type)
        {
            return reference?
                .Elements(WorkdayName("ID"))
                .FirstOrDefault(identifier => string.Equals(
                    identifier.Attribute(WorkdayName("type"))?.Value,
                    type,
                    StringComparison.Ordinal))?
                .Value;
        }

        private static (int Page, int TotalPages) ParsePaging(XElement response)
        {
            var results = response.Element(WorkdayName("Response_Results")) ?? throw new InvalidDataException("The Workday response does not contain Response_Results.");
            var page = ParseInteger(results, "Page");
            var totalPages = ParseInteger(results, "Total_Pages");

            if (page < 0 || totalPages < 0 || (totalPages > 0 && page == 0) || page > totalPages)
            {
                throw new InvalidDataException("The Workday response contains invalid paging metadata.");
            }

            return (page, totalPages);
        }

        private static int ParseInteger(XElement parent, string elementName)
        {
            var value = ElementValue(parent, elementName);
            return int.TryParse(value, out var parsed) ? parsed : throw new InvalidDataException($"The Workday response contains an invalid {elementName} value.");
        }

        private static XElement ParseResponse(string responseXml)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(responseXml);

            XDocument document;
            try
            {
                using var stringReader = new StringReader(responseXml);
                using var xmlReader = XmlReader.Create(stringReader, new XmlReaderSettings
                {
                    DtdProcessing = DtdProcessing.Prohibit,
                    XmlResolver = null
                });
                document = XDocument.Load(xmlReader, LoadOptions.None);
            }
            catch (XmlException exception)
            {
                throw new InvalidDataException("Workday returned invalid XML.", exception);
            }

            var fault = document.Descendants().FirstOrDefault(element => element.Name.LocalName == "Fault");
            if (fault is not null)
            {
                var messages = fault
                    .Descendants()
                    .Where(element => element.Name.LocalName is "faultstring" or "Text" or "Message")
                    .Select(element => element.Value)
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .ToArray();
                var message = messages.FirstOrDefault(value => ExtractInvalidEmployeeId(value) is not null)
                    ?? messages.FirstOrDefault();
                var invalidEmployeeId = ExtractInvalidEmployeeId(message);
                if (invalidEmployeeId is not null)
                {
                    throw new WorkdayInvalidEmployeeIdException(invalidEmployeeId, message!);
                }

                throw new InvalidDataException($"Workday returned a SOAP fault{(string.IsNullOrWhiteSpace(message) ? string.Empty : $": {message}")}");
            }

            return document.Descendants(WorkdayName("Get_Workers_Response")).SingleOrDefault()
                ?? throw new InvalidDataException("The SOAP response does not contain a Workday Get_Workers_Response.");
        }

        private static XName WorkdayName(string localName)
        {
            return XName.Get(localName, WorkdayNamespace);
        }

        private static string? ExtractInvalidEmployeeId(string? message)
        {
            const string prefix = "Invalid ID value.  '";
            const string suffix = "' is not a valid ID value for type = 'Employee_ID'";

            if (string.IsNullOrWhiteSpace(message))
            {
                return null;
            }

            var start = message.IndexOf(prefix, StringComparison.Ordinal);
            if (start < 0)
            {
                return null;
            }

            start += prefix.Length;
            var end = message.IndexOf(suffix, start, StringComparison.Ordinal);
            return end > start ? message[start..end] : null;
        }
    }
}
