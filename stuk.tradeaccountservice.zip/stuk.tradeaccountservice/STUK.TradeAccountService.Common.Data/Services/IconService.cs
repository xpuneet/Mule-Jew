﻿using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.IconIntegration.IconClient;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class IconService
    {
        private readonly IIconHttpClient _iconHttpClient;
        private readonly TradeAcnSyncOptions _options;
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;

        public IconService(IIconHttpClient iconHttpClient, IOptions<TradeAcnSyncOptions> options, IAppInsightsLoggerHelper appInsightsLoggerHelper)
        {
            _iconHttpClient = iconHttpClient;
            _options = options.Value;
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
        }

        public async Task<ErpApiResult> MakeAccountPaymentAsync(PendingPaymentReference pendingReference, CancellationToken cancellationToken)
        {
            IconMakeAccountPaymentRequest request;
            try
            {
                request = new IconMakeAccountPaymentRequest
                {
                    Account = pendingReference.AccountCode,
                    Branch = Convert.ToDouble(pendingReference.BranchId),
                    Description = pendingReference.Description,
                    Till = 1,
                    Payments = new Payments
                    {
                        Payment =
                    [
                        new IconIntegration.IconClient.Payment
                        {
                            Reference = pendingReference.ApiPaymentReference.ToString(),
                            Type = pendingReference.PaymentType.ToString(),
                            Value = Convert.ToDouble(pendingReference.PaymentAmount)
                        }
                    ]
                    }
                };
            }catch(Exception ex)
            {
                _appInsightsLoggerHelper.LogWarning(
                        $"MakeAccountPaymentAsync ICON request object creation failed account: {pendingReference.AccountCode} paymentid: {pendingReference.PaymentId} message: {ex.Message}.");
                return new ErpApiResult
                {
                    IsDefinitive = true,
                    StatusCode = 400,
                    ErrorMessage = "ICON request object creation failed"
                };
            }
            
            for (int attempt = 1; attempt <= _options.IconApiMaxRetries; attempt++)
            {
                try
                {
                    var response = await _iconHttpClient.POST_AccountPaymentAsync(request, _iconHttpClient.IconSettings.K8_XI_AuthToken, cancellationToken);
                    return new ErpApiResult
                    {
                        IsDefinitive = true,
                        Response = response,
                        StatusCode = 200
                    };
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    _appInsightsLoggerHelper.LogWarning($"MakeAccountPaymentAsync ICON API call cancelled at {DateTime.UtcNow}.");
                    throw;
                }
                catch(ApiException ex) when (attempt < _options.IconApiMaxRetries)
                {
                    //skip, already handled by package
                    if ((int) ex.StatusCode is >= 400 and < 501)
                    {
                        _appInsightsLoggerHelper.LogError(ex,
                        $"MakeAccountPaymentAsync ICON API call failed bad request status code {ex.StatusCode} for account {pendingReference.AccountCode} branch {pendingReference.BranchId} type {pendingReference.PaymentType} paymentid {pendingReference.PaymentId}.");
                        return new ErpApiResult
                        {
                            IsDefinitive = true,
                            StatusCode = ex.StatusCode,
                            ErrorMessage = (ex.Response == null) ? "(null)" : ex.Response[..(ex.Response.Length >= 512 ? 512 : ex.Response.Length)]
                        };
                    }
                    _appInsightsLoggerHelper.LogWarning($"MakeAccountPaymentAsync ICON API call failed on attempt {attempt}/{_options.IconApiMaxRetries} Statuscode {ex.StatusCode} paymentid {pendingReference.PaymentId}. Retrying."
                        , ex.Message);
                    await DelayRetryAsync(attempt, cancellationToken);
                }
                catch (Exception ex) when (attempt < _options.IconApiMaxRetries)
                {
                    _appInsightsLoggerHelper.LogWarning($"MakeAccountPaymentAsync ICON API call failed on attempt {attempt}/{_options.IconApiMaxRetries} paymentid {pendingReference.PaymentId}. Retrying."
                        ,ex.Message);
                    await DelayRetryAsync(attempt, cancellationToken);
                }
                catch (Exception ex)
                {
                    _appInsightsLoggerHelper.LogError(ex,
                        $"MakeAccountPaymentAsync ICON API call failed after {_options.IconApiMaxRetries} attempts for account {pendingReference.AccountCode} branch {pendingReference.BranchId} type {pendingReference.PaymentType} paymentid {pendingReference.PaymentId}.");
                    //Transient failure
                    return new ErpApiResult
                    {
                        IsDefinitive = false,
                        ErrorMessage = $"ICON API call failed after {_options.IconApiMaxRetries} attempts"
                    };
                }
            }
            //Transient failure
            return new ErpApiResult
            {
                IsDefinitive = false,
                ErrorMessage = "All retries exhausted"
            };
        }

        private static Task DelayRetryAsync(int attempt, CancellationToken ct)
        {
            var delay = TimeSpan.FromSeconds(Math.Min(Math.Pow(2, attempt), 30));
            return Task.Delay(delay, ct);
        }
    }
}
