using STUK.TradeAccountService.Common.Contracts.Interfaces;
using System.Globalization;
using System.Text;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Generates the recovered five-field Data Lake completion-token contract
    /// </summary>
    public class DataLakeCompletionTokenGenerator : IDataLakeCompletionTokenGenerator
    {
        /// <inheritdoc />
        public byte[] Generate(DateTimeOffset completedOn, string tokenFileName)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(tokenFileName);
            var utc = completedOn.ToUniversalTime();
            var processedYear = ISOWeek.GetYear(utc.DateTime);
            var processedDate = string.Create(
                CultureInfo.InvariantCulture,
                $"{processedYear:D4}-{utc:MM-dd}");
            var content = string.Join(
                '|',
                utc.ToString("yyyy-MM-dd hh:mm:ss", CultureInfo.InvariantCulture),
                "reception_completed",
                "1",
                processedDate,
                tokenFileName) + "\n";

            return new UTF8Encoding(false).GetBytes(content);
        }
    }
}
