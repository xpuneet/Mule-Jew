﻿using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class TradeAccountsService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor,
        IAppInsightsLoggerHelper appInsightsLoggerHelper) : ITradeAccountsService
    {
        private readonly IDbExecutor _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));

        public async Task<AccountResponse?> GetAccountByAccountCodeAsync(string accountCode, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetAccountByAccountCodeAsync started at {DateTime.Now} with accountcode {accountCode}.");
            var jsonString = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetAccountDetailsByAccountCode, new { accountCode });
            if (string.IsNullOrEmpty(jsonString))
            {
                _appInsightsLoggerHelper.LogWarning($"GetAccountByAccountCode completed with 0 record at {DateTime.Now} with accountcode {accountCode}.");
                return new();
            }
            var result = JsonSerializer.Deserialize<AccountResponse>(jsonString);
            _appInsightsLoggerHelper.LogInformation($"GetAccountByAccountCodeAsync completed at {DateTime.Now} with accountcode {accountCode}.");
            return result;
        }

        public async Task<AccountSearchResponse?> SearchAccountBySessionAsync(string sessionId, int pageNumber, int pageSize, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"SearchAccountBySessionAsync started at {DateTime.Now}.");
            var jsonString = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetAccountsDetailsBySessionId, new { sessionId, pageNumber, pageSize });
            if (string.IsNullOrEmpty(jsonString))
            {
                _appInsightsLoggerHelper.LogWarning($"SearchAccountBySessionAsync completed with empty json at {DateTime.Now}.");
                return new();
            }
            var result = JsonSerializer.Deserialize<AccountSearchResponse>(jsonString);
            _appInsightsLoggerHelper.LogInformation($"SearchAccountBySessionAsync completed at {DateTime.Now}.");
            return result;
        }

        public Task LinkUnlinkAccountAsync(string accountCode, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public async Task<AccountValidateResponse?> ValidateAccountAsync(string accountCode, string postCode, string brand, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"ValidateAccountAsync started at {DateTime.Now} with accountcode {accountCode} postCode {postCode} brand {brand}.");
            var jsonString = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetValidateAccount, new { accountCode, postCode, brand });
            if (string.IsNullOrEmpty(jsonString) || jsonString.Trim() == "{}")
            {
                _appInsightsLoggerHelper.LogWarning($"ValidateAccountAsync completed with no record at {DateTime.Now} with accountcode {accountCode}.");
                return null;
            }
            var result = JsonSerializer.Deserialize<AccountValidateResponse>(jsonString);
            _appInsightsLoggerHelper.LogInformation($"ValidateAccountAsync completed at {DateTime.Now}.");
            return result;
        }

        public async Task<CreditLimitResponse?> GetCreditLimitByAccountCodeAsync(string accountCode, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetCreditLimitByAccountCodeAsync started at {DateTime.Now} with accountcode {accountCode}.");
            var result = await _dbExecutor.ExecuteSingleAsync<CreditLimitResponse>(StoredProcedures.GetAccountCreditLimit, new { accountCode });
            if (!string.IsNullOrWhiteSpace(result?.ErrorCode))
            {
                _appInsightsLoggerHelper.LogWarning("GetCreditLimitByAccountCodeAsync completed with error.", $"Accountcode {accountCode} and error {result.ErrorCode}.");
            }
            else
            {
                _appInsightsLoggerHelper.LogInformation($"GetCreditLimitByAccountCode completed successfully at {DateTime.Now}.");
            } 
            return result;
        }
    }
}
