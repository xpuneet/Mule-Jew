﻿using Azure.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Services;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Data.Services
{ 
public class ColumbusFilesService : IColumbusFilesService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly IBlobService _blobService;
        private readonly string _storageAccount;
        private readonly int _maxDegreeOfParallelism;
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
        private readonly IDbExecutor _dbExecutor;

        public ColumbusFilesService(
            [FromKeyedServices("OrderDb")] IDbExecutor dbExecutor,
            IAppInsightsLoggerHelper appInsightsLoggerHelper,
            IServiceScopeFactory scopeFactory,
            IBlobService blobService,
            IConfiguration configuration)
        {
            _scopeFactory = scopeFactory;
            _blobService = blobService;
            _storageAccount = configuration["ColumbusFilesStorageAccount"]
                ?? throw new InvalidOperationException("ColumbusFilesStorageAccount:StorageAccount is not configured.");
            _maxDegreeOfParallelism = configuration.GetValue<int>("Columbus:MaxDegreeOfParallelism", 1);
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
            _dbExecutor = dbExecutor;
        }

        public async Task UploadColumbusFileAsync(string metaDataFileName,string columbusStagingContainer)
        {
            if (string.IsNullOrWhiteSpace(metaDataFileName))
            {
                _appInsightsLoggerHelper.LogWarning("Metadata file name is empty.");
                return;
            }

            try
            {
                var archiveXml = await _blobService.ReadArchiveXmlAsync(
                    _storageAccount,
                    columbusStagingContainer,
                    metaDataFileName);

                if (archiveXml?.Input?.MultiDocumentFile == null)
                {
                    _appInsightsLoggerHelper.LogWarning($"Invalid or missing metadata structure in {metaDataFileName}.");
                    return;
                }

                var multiDocumentFile = archiveXml.Input.MultiDocumentFile;
                var document = multiDocumentFile.Documents?.FirstOrDefault();

                if (document == null)
                {
                    _appInsightsLoggerHelper.LogWarning($"No documents found in metadata file {metaDataFileName}.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(document.TypeName))
                {
                    _appInsightsLoggerHelper.LogWarning($"Document type missing for source file {multiDocumentFile.File}.");
                    return;
                }
                if (multiDocumentFile.File == null)
                {
                    throw new Exception("File Name is Null In MetaData");
                }
                var docType = ParseDocumentType(document.TypeName, multiDocumentFile.File);

                var sqlDate = ParseXmlDate(document.GetIndex("DAT"), document.TypeName);
                if (sqlDate == null)
                {
                    throw new Exception($"Expected Date format : dd/MM/yyyy , Provided Value :{document.GetIndex("DAT")}");
                }
                var fileMetaData = await PrepareDocumentMetadata(document, multiDocumentFile.File, columbusStagingContainer, docType, sqlDate);

                string today = DateTime.Today.ToString("yyyy/MM/dd");
                fileMetaData.BlobUri = $"{today}/{fileMetaData.CalculatedFileName}";

                string destinationPath = $"{document.TypeName.ToLowerInvariant()}/{today}";
                if (fileMetaData.CalculatedFileName == null)
                {
                    throw new Exception("Calculated File Name is Null");
                }
                int recordCount = await GetDocumentRecordCount(fileMetaData);
                if (recordCount == 1)
                {
                    bool copyResult = await _blobService.CopyBlobAsync(
                        _storageAccount,
                        columbusStagingContainer,
                        multiDocumentFile.File,
                        destinationPath,
                        fileMetaData.CalculatedFileName);

                    if (!copyResult)
                    {
                        _appInsightsLoggerHelper.LogError(new Exception("Copy failed"), $"Failed copying source file {multiDocumentFile.File}.");
                        return;
                    }

                    int recordsUpdated = await UpdateDocumentMetadata(fileMetaData, $"{document.TypeName.ToLowerInvariant()}/{today}");
                    if (recordsUpdated == 1)
                    {
                        await DeleteBlobIfExists(multiDocumentFile.File, columbusStagingContainer, $"source file {multiDocumentFile.File}");
                        await DeleteBlobIfExists(metaDataFileName, columbusStagingContainer, $"metadata file {metaDataFileName}");
                    }
                    else
                    {
                        _appInsightsLoggerHelper.LogError(new Exception("No Records in DataBase"), $"Failed updating db for source file {multiDocumentFile.File}.");
                        return;
                    }
                    _appInsightsLoggerHelper.LogInformation($"Successfully processed Columbus file {metaDataFileName}.");
                }
                else
                {
                    _appInsightsLoggerHelper.LogError(new Exception($"No Records in DataBase for source file {multiDocumentFile.File}"), $"No records Exists for source file {multiDocumentFile.File}.");
                    return;
                }

            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed processing Columbus file {metaDataFileName}");
                throw;
            }
        }

        private DocumentType ParseDocumentType(string typeName, string sourceFile)
        {
            if (!Enum.TryParse<DocumentType>(typeName, true, out var docType))
            {
                var message = $"Unsupported document type: {typeName} for file {sourceFile}";
                //_appInsightsLoggerHelper.LogError(new Exception(message), message);
                throw new InvalidOperationException(message);
            }
            return docType;
        }

        private DateTime? ParseXmlDate(string? dateStr, string docType)
        {
            if (string.IsNullOrWhiteSpace(dateStr))
            {
                _appInsightsLoggerHelper.LogWarning($"No DAT value found in XML for DocType: {docType}");
                return null;
            }

            if (!DateTime.TryParseExact(dateStr, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedDate))
            {
                _appInsightsLoggerHelper.LogWarning($"Invalid DAT format: {dateStr}, DocType: {docType}");
                return null;
            }

            return parsedDate;
        }

        private async Task<DocumentMetadataUpdate> PrepareDocumentMetadata(
            ArchiveDocument document,
            string sourceFile,
            string columbusStagingContainer,
            DocumentType docType,
            DateTime? sqlDate)
        {
            string accountNo = document.GetIndex("ACC") ?? string.Empty;
            string branch = document.GetIndex("BNC") ?? string.Empty;
            string dateStr = document.GetIndex("DAT") ?? string.Empty;

            var fileMetaData = await _blobService.GetDocumentMetadataAsync(_storageAccount,$"{columbusStagingContainer}/{sourceFile}", docType);

            fileMetaData.AccountCode = accountNo;
            fileMetaData.CustomerAccount = accountNo;
            fileMetaData.DocType = docType;
            fileMetaData.OriginalFileName =sourceFile;
            switch (docType)
            {
                case DocumentType.Statement:
                    fileMetaData.OwningBranch = branch;
                    fileMetaData.StatementDate = sqlDate;
                    fileMetaData.CalculatedFileName = $"{accountNo}_{branch}_{dateStr.Replace("/", "")}{fileMetaData.Extension}";
                    break;

                case DocumentType.Invoice:
                    fileMetaData.BranchCode = branch;
                    fileMetaData.StandardInvoiceNo = document.GetIndex("DNO") ?? string.Empty;
                    fileMetaData.InvoiceDateTime = sqlDate;
                    fileMetaData.CalculatedFileName = $"{accountNo}_{branch}_{fileMetaData.StandardInvoiceNo}_{dateStr.Replace("/", "")}{fileMetaData.Extension}";
                    break;
            }

            return fileMetaData;
        }

        private async Task DeleteBlobIfExists(string blobName, string containerName,string description)
        {
            var deleted = await _blobService.DeleteBlobAsync(_storageAccount, containerName, blobName);
            if (!deleted)
            {
                _appInsightsLoggerHelper.LogError(new Exception("Delete failed"), $"Failed to delete {description}.");
            }
            _appInsightsLoggerHelper.LogInformation($"Deleted {blobName}");

        }

        public async Task<int> UpdateDocumentMetadata(DocumentMetadataUpdate request,string? relativeContainerPath)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            _appInsightsLoggerHelper.LogInformation($"Updating document metadata. DocType: {request.DocType}");

            try
            {
                var parameters = new
                {
                    DocType = request.DocType.ToString(),
                    request.OriginalFileName,
                    request.Extension,
                    request.CalculatedFileName,
                    request.ContentMd5,
                    request.ContentLength,
                    request.BlobUri,
                    request.IsSynchronized,
                    request.OwningBranch,
                    request.StatementDate,
                    request.AccountCode,
                    request.BranchCode,
                    request.InvoiceDateTime,
                    request.CustomerAccount,
                    request.StandardInvoiceNo
                };
                var rowsUpdated = await _dbExecutor.ExecuteWithOutputAsync(
                    "UpdateColumbusDocumentMetadata",
                    "@RowsUpdated",
                    parameters);

                _appInsightsLoggerHelper.LogInformation($"Document metadata updated successfully. DocType: {request.DocType}, RowsUpdated: {rowsUpdated}");

                return rowsUpdated;
            }
            catch (Exception)
            {if (relativeContainerPath != null)
                {
                    try
                    {
                        await DeleteBlobIfExists(
                            $"{request.CalculatedFileName}",
                            relativeContainerPath,
                            $"uploaded file {request.CalculatedFileName} due to data not found in database"
                        );
                    }
                    catch (Exception cleanupEx)
                    {
                        _appInsightsLoggerHelper.LogError(cleanupEx, "Failed to delete blob during Cleanup");
                    }
                }
                throw; 
            }
        }
        public async Task<int> GetDocumentRecordCount(DocumentMetadataUpdate request)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            _appInsightsLoggerHelper.LogInformation($"Checking document record count. DocType: {request.DocType}");

            string storedProcName;
            object parameters;

            switch (request.DocType.ToString())
            {
                case "Statement":
                    storedProcName = "CheckColumbusStatementHeaderExists";
                    parameters = new
                    {
                        request.OwningBranch,
                        request.StatementDate,
                        request.AccountCode
                    };
                    break;

                case "Invoice":
                    storedProcName = "CheckColumbusInvoiceHeaderExists";
                    parameters = new
                    {
                        request.BranchCode,
                        request.InvoiceDateTime,
                        request.CustomerAccount,
                        request.StandardInvoiceNo
                    };
                    break;

                default:
                    throw new ArgumentException($"Invalid document type provided: {request.DocType}", nameof(request.DocType));
            }

            var recordCount = await _dbExecutor.ExecuteWithOutputAsync(
                storedProcName,
                "@RecordCount",
                parameters);

            _appInsightsLoggerHelper.LogInformation(
                $"Record count check completed. DocType: {request.DocType}, RecordCount: {recordCount}");

            return recordCount;
        }
    }
}