﻿using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class PreferredBranchService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor,
        IAppInsightsLoggerHelper appInsightsLoggerHelper) : IPreferredBranchService
    {
        private readonly IDbExecutor _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));

        public async Task<PreferredBranchData?> GetPreferredBranchAsync(string accountCode, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetPreferredBranchAsync started at {DateTime.Now} with accountcode {accountCode}.");
            var result = await _dbExecutor.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                new { accountCode });
            _appInsightsLoggerHelper.LogInformation($"GetPreferredBranchAsync completed at {DateTime.Now} with accountcode {accountCode} and fetched result {result}.");
            return result;
        }

        public async Task<PreferredBranchData?> SetPreferredBranchAsync(string accountCode, string? preferredBranch, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"SetPreferredBranchAsync started at {DateTime.Now} with accountcode {accountCode} and preferredBranch {preferredBranch}.");
            var result = await _dbExecutor.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                new { accountCode, preferredBranch, doUpdate = 1 });
            _appInsightsLoggerHelper.LogInformation($"SetPreferredBranchAsync completed at {DateTime.Now} with accountcode {accountCode},preferredBranch {preferredBranch} and fetched result {result}.");
            return result;
        }
    }
}
