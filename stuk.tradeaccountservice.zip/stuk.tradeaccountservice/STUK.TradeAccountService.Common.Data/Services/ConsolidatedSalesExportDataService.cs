using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides stored-procedure access to Consolidated Sales export state
    /// </summary>
    public class ConsolidatedSalesExportDataService : IConsolidatedSalesExportDataService
    {
        private readonly IDbExecutor _dbExecutor;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesExportDataService"/>
        /// </summary>
        /// <param name="dbExecutor">The keyed Trade Account Service database executor</param>
        /// <exception cref="ArgumentNullException">Thrown when the database executor is not supplied</exception>
        public ConsolidatedSalesExportDataService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportRun> CreateRunAsync(ConsolidatedSalesExportRunRegistration registration, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesExportRun>(
                StoredProcedures.CreateConsolidatedSalesExportRun,
                registration)
                ?? throw new InvalidOperationException("The export-run registration did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportRun?> ClaimNextRunAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesExportRun>(StoredProcedures.ClaimNextConsolidatedSalesExportRun, new { leaseOwner, leaseDurationSeconds, maximumRetryCount, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesLeaseResult> RenewRunLeaseAsync(
            Guid exportRunId,
            Guid claimToken,
            int leaseDurationSeconds,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(
                StoredProcedures.RenewConsolidatedSalesExportRunLease,
                new { exportRunId, claimToken, leaseDurationSeconds, now })
                ?? throw new InvalidOperationException("The export-run lease renewal did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportPage> AppendPageAsync(
            Guid exportRunId,
            Guid claimToken,
            int pageNumber,
            long firstRowSequence,
            byte[] pageHash,
            bool hasMore,
            string rowsJson,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesExportPage>(StoredProcedures.AppendConsolidatedSalesExportPage, new
            {
                exportRunId,
                claimToken,
                pageNumber,
                firstRowSequence,
                pageHash,
                hasMore,
                rowsJson,
                now
            })
                ?? throw new InvalidOperationException("The export page append did not return a result");
        }

        /// <inheritdoc />
        public async Task CompleteExtractionAsync(
            Guid exportRunId,
            Guid claimToken,
            int expectedPageCount,
            long expectedRowCount,
            byte[] queryHash,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _dbExecutor.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesExportExtraction, new { exportRunId, claimToken, expectedPageCount, expectedRowCount, queryHash, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportFailureResult> FailExtractionAsync(
            Guid exportRunId,
            Guid claimToken,
            string errorCategory,
            string errorMessage,
            bool isTransient,
            DateTimeOffset? nextAttemptOn,
            int maximumRetryCount,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesExportFailureResult>(StoredProcedures.FailConsolidatedSalesExportExtraction, new
            {
                exportRunId,
                claimToken,
                errorCategory,
                errorMessage,
                isTransient,
                nextAttemptOn,
                maximumRetryCount,
                now
            })
                ?? throw new InvalidOperationException("The extraction failure did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportDestinationWork?> ClaimNextDestinationAsync(
            string destination,
            string leaseOwner,
            int leaseDurationSeconds,
            int maximumRetryCount,
            Guid? exportDestinationId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesExportDestinationWork>(StoredProcedures.ClaimNextConsolidatedSalesExportDestination, new { destination, leaseOwner, leaseDurationSeconds, maximumRetryCount, exportDestinationId, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesLeaseResult> RenewDestinationLeaseAsync(
            Guid exportDestinationId,
            Guid claimToken,
            int leaseDurationSeconds,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(
                StoredProcedures.RenewConsolidatedSalesExportDestinationLease,
                new { exportDestinationId, claimToken, leaseDurationSeconds, now })
                ?? throw new InvalidOperationException("The destination lease renewal did not return a result");
        }

        /// <inheritdoc />
        public async Task CompleteDestinationAsync(
            Guid exportDestinationId,
            Guid claimToken,
            string fileName,
            string filePath,
            string contentHash,
            long fileRowCount,
            long fileByteCount,
            string? externalExecutionId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesExportDestination, new
            {
                exportDestinationId,
                claimToken,
                fileName,
                filePath,
                contentHash,
                fileRowCount,
                fileByteCount,
                externalExecutionId,
                now
            });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportDestinationFailureResult> FailDestinationAsync(
            Guid exportDestinationId,
            Guid claimToken,
            string errorCategory,
            string errorMessage,
            DateTimeOffset? nextAttemptOn,
            int maximumRetryCount,
            string? externalExecutionId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesExportDestinationFailureResult>(StoredProcedures.FailConsolidatedSalesExportDestination, new
            {
                exportDestinationId,
                claimToken,
                errorCategory,
                errorMessage,
                nextAttemptOn,
                maximumRetryCount,
                externalExecutionId,
                now
            }) ?? throw new InvalidOperationException("The destination failure did not return a result");
        }

        /// <inheritdoc />
        public async Task RequeueDestinationAsync(Guid exportDestinationId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _dbExecutor.ExecuteAsync(StoredProcedures.RequeueConsolidatedSalesExportDestination, new { exportDestinationId, reason, now });
        }

        /// <inheritdoc />
        public async Task<IReadOnlyCollection<ConsolidatedSalesExportRow>> GetRowsAsync(Guid exportRunId, long afterRowSequence, int pageSize, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var rows = await _dbExecutor.ExecuteListAsync<ConsolidatedSalesExportRow>(StoredProcedures.GetConsolidatedSalesExportRows, new { exportRunId, afterRowSequence, pageSize });

            return rows.ToArray();
        }
    }
}
