using Org.BouncyCastle.Bcpg;
using PgpCore;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Reproduces the Concur SAPI OpenPGP encryption contract without MuleSoft
    /// </summary>
    public class ConcurPgpEncryptionService : IConcurPgpEncryptionService
    {
        private const string InternalFileName = "stream";

        /// <inheritdoc />
        public async Task EncryptAsync(Stream source, Stream destination, string publicKey, string keyId, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(source);
            ArgumentNullException.ThrowIfNull(destination);
            ArgumentException.ThrowIfNullOrWhiteSpace(publicKey);
            ArgumentException.ThrowIfNullOrWhiteSpace(keyId);

            if (!source.CanRead)
            {
                throw new ArgumentException("The PGP source stream must be readable", nameof(source));
            }

            if (!destination.CanWrite)
            {
                throw new ArgumentException("The PGP destination stream must be writable", nameof(destination));
            }

            cancellationToken.ThrowIfCancellationRequested();

            var encryptionKeys = new EncryptionKeys(publicKey);
            var expectedKeyId = ParseKeyId(keyId);

            if (!ContainsKey(encryptionKeys, expectedKeyId))
            {
                throw new InvalidDataException($"The configured Concur PGP keyring does not contain key '{NormaliseKeyId(keyId)}'");
            }

            encryptionKeys.UseEncryptionKey(expectedKeyId);

            using var pgp = new PGP(encryptionKeys)
            {
                CompressionAlgorithm = CompressionAlgorithmTag.Zip,
                FileType = PgpCore.Enums.PGPFileType.Binary,
                SymmetricKeyAlgorithm = SymmetricKeyAlgorithmTag.Aes256
            };

            await pgp.EncryptAsync(
                source,
                destination,
                armor: true,
                withIntegrityCheck: true,
                name: InternalFileName,
                headers: null,
                oldFormat: false);

            cancellationToken.ThrowIfCancellationRequested();
        }

        private static bool ContainsKey(EncryptionKeys encryptionKeys, long expectedKeyId)
        {
            return encryptionKeys.MasterKey.KeyId == expectedKeyId || encryptionKeys.EncryptKeys.Any(key => key.KeyId == expectedKeyId);
        }

        private static long ParseKeyId(string keyId)
        {
            var normalisedKeyId = NormaliseKeyId(keyId);
            if (!ulong.TryParse(normalisedKeyId, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out var parsedKeyId))
            {
                throw new ArgumentException("The Concur PGP key identifier must be hexadecimal", nameof(keyId));
            }

            return unchecked((long)parsedKeyId);
        }

        private static string NormaliseKeyId(string keyId)
        {
            var normalisedKeyId = keyId.Trim();

            return normalisedKeyId.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                ? normalisedKeyId[2..]
                : normalisedKeyId;
        }
    }
}
