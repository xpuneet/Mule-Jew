using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Streams the completed Salesforce snapshot in the legacy Phocas ConsXref layout
    /// </summary>
    public class PhocasConsXrefFileGenerator : IPhocasConsXrefFileGenerator
    {
        private const char Separator = '\t';
        private const string LineSeparator = "\r\n";
        private const int SnapshotPageSize = 1000;

        private static readonly Encoding FileEncoding = new UTF8Encoding(false);

        private readonly IConsolidatedSalesExportDataService _exportDataService;

        /// <summary>
        /// Initialises a new instance of the <see cref="PhocasConsXrefFileGenerator"/>
        /// </summary>
        /// <param name="exportDataService">The completed export snapshot data service</param>
        /// <exception cref="ArgumentNullException">Thrown when the data service is not supplied</exception>
        public PhocasConsXrefFileGenerator(IConsolidatedSalesExportDataService exportDataService)
        {
            _exportDataService = exportDataService ?? throw new ArgumentNullException(nameof(exportDataService));
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesExportFileResult> GenerateAsync(Guid exportRunId, int exportYear, Stream destination, CancellationToken cancellationToken = default)
        {
            if (exportRunId == Guid.Empty)
            {
                throw new ArgumentException("The export run identifier is required.", nameof(exportRunId));
            }

            if (exportYear is < 2000 or > 9999)
            {
                throw new ArgumentOutOfRangeException(nameof(exportYear), "The export year is outside the supported range.");
            }

            ArgumentNullException.ThrowIfNull(destination);
            if (!destination.CanWrite)
            {
                throw new ArgumentException("The Phocas destination stream must be writable.", nameof(destination));
            }

            cancellationToken.ThrowIfCancellationRequested();

            using var contentHash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);

            long rowCount = 0;
            long byteCount = 0;
            long afterRowSequence = 0;

            while (true)
            {
                var rows = await _exportDataService.GetRowsAsync(
                    exportRunId,
                    afterRowSequence,
                    SnapshotPageSize,
                    cancellationToken);

                if (rows.Count == 0)
                {
                    break;
                }

                foreach (var row in rows)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    rowCount++;

                    if (row.RowSequence != rowCount)
                    {
                        throw new InvalidDataException($"The completed export snapshot expected row sequence {rowCount.ToString(CultureInfo.InvariantCulture)} but received {row.RowSequence.ToString(CultureInfo.InvariantCulture)}.");
                    }

                    var line = FormatRow(row);
                    var lineBytes = FileEncoding.GetBytes(line);
                    contentHash.AppendData(lineBytes);
                    await destination.WriteAsync(lineBytes, cancellationToken);
                    byteCount += lineBytes.LongLength;
                    afterRowSequence = row.RowSequence;
                }

                if (rows.Count < SnapshotPageSize)
                {
                    break;
                }
            }

            await destination.FlushAsync(cancellationToken);

            return new ConsolidatedSalesExportFileResult
            {
                FileName = $"{exportYear.ToString(CultureInfo.InvariantCulture)}_ConsXref.txt",
                RowCount = rowCount,
                ByteCount = byteCount,
                ContentHash = Convert.ToHexString(contentHash.GetHashAndReset()).ToLowerInvariant()
            };
        }

        private static string FormatRow(ConsolidatedSalesExportRow row)
        {
            return string.Join(
                Separator,
                FormatText(row.AccountNumber),
                FormatText(row.InvoiceNumber),
                FormatDate(row.InvoiceDate),
                FormatText(row.DeliveryNoteNumber),
                FormatDeliveryNoteLine(row.DeliveryNoteLineNumber),
                FormatDate(row.DespatchDate),
                FormatText(row.ProductCode),
                FormatQuantity(row.Quantity),
                FormatTotalPrice(row.TotalPrice))
                + LineSeparator;
        }

        private static string FormatText(string? value)
        {
            return value ?? string.Empty;
        }

        private static string FormatDate(DateOnly? value)
        {
            return value?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string FormatDeliveryNoteLine(string? value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            if (!decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out var number))
            {
                throw new InvalidDataException($"Delivery note line number '{value}' is not numeric.");
            }

            return number.ToString("0", CultureInfo.InvariantCulture);
        }

        private static string FormatQuantity(decimal? value)
        {
            return value?.ToString("0.0###", CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string FormatTotalPrice(decimal? value)
        {
            return value?.ToString("0.##################", CultureInfo.InvariantCulture) ?? string.Empty;
        }
    }
}
