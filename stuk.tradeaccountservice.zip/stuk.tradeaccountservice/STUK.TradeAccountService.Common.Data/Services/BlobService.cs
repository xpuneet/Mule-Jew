using Azure;
using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class BlobService : IBlobService
    {
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;

        public BlobService(IAppInsightsLoggerHelper appInsightsLoggerHelper)
        {
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
        }

        public async Task<List<string>> GetBlobFilesEndingWithAsync(
            string storageAccountName,
            string containerName,
            string endsWith)
        {
            try
            {
                var credential = new DefaultAzureCredential();

                var containerClient = new BlobContainerClient(
                    new Uri($"https://{storageAccountName}.blob.core.windows.net/{containerName}"),
                    credential);

                var files = new List<string>();

                await foreach (BlobItem blob in containerClient.GetBlobsAsync())
                {
                    if (blob.Name.EndsWith(endsWith, StringComparison.OrdinalIgnoreCase))
                    {
                        files.Add(blob.Name);
                    }
                }

                _appInsightsLoggerHelper.LogInformation(
                    $"Found {files.Count} blob(s) ending with '{endsWith}' in container {containerName}.");

                return files;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Failed retrieving blobs ending with '{endsWith}' from container {containerName}");

                throw;
            }
        }

        public async Task<Stream?> GetBlobAsync(
            string storageAccountName,
            string containerName,
            string blobName)
        {
            try
            {
                var credential = new DefaultAzureCredential();

                var blobClient = new BlobClient(
                    new Uri($"https://{storageAccountName}.blob.core.windows.net/{containerName}/{blobName}"),
                    credential);

                if (!await blobClient.ExistsAsync())
                {
                    _appInsightsLoggerHelper.LogWarning(
                        $"Blob {blobName} was not found in container {containerName}.");

                    return null;
                }

                var response = await blobClient.DownloadAsync();

                return response.Value.Content;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Failed retrieving blob {blobName} from container {containerName}");

                throw;
            }
        }

        public async Task<ColumbusMetaDataFile?> ReadArchiveXmlAsync(
            string storageAccountName,
            string containerName,
            string blobName)
        {
            try
            {
                var stream = await GetBlobAsync(
                    storageAccountName,
                    containerName,
                    blobName);

                if (stream == null)
                {
                    return null;
                }

                var serializer = new XmlSerializer(typeof(ColumbusMetaDataFile));

                using (stream)
                {
                    return serializer.Deserialize(stream) as ColumbusMetaDataFile;
                }
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Failed reading archive XML {blobName}");

                throw;
            }
        }

        public async Task<bool> CopyBlobAsync(
            string storageAccountName,
            string sourceContainer,
            string sourceBlobName,
            string targetContainer,
            string targetBlobName)
        {
            try
            {
                var credential = new DefaultAzureCredential();

                var sourceBlob = new BlobClient(
                    new Uri($"https://{storageAccountName}.blob.core.windows.net/{sourceContainer}/{sourceBlobName}"),
                    credential);

                if (!await sourceBlob.ExistsAsync())
                {
                    _appInsightsLoggerHelper.LogWarning(
                        $"Source blob {sourceBlobName} was not found in container {sourceContainer}.");

                    return false;
                }

                var targetBlob = new BlobClient(
                    new Uri($"https://{storageAccountName}.blob.core.windows.net/{targetContainer}/{targetBlobName}"),
                    credential);

                await targetBlob.StartCopyFromUriAsync(sourceBlob.Uri);

                BlobProperties properties;

                do
                {
                    await Task.Delay(500);
                    properties = await targetBlob.GetPropertiesAsync();
                }
                while (properties.CopyStatus == CopyStatus.Pending);

                if (properties.CopyStatus == CopyStatus.Success)
                {
                    _appInsightsLoggerHelper.LogInformation(
                        $"Successfully copied blob {sourceBlobName} from {sourceContainer} to {targetContainer}/{targetBlobName}.");

                    return true;
                }

                _appInsightsLoggerHelper.LogError(
                    new Exception(properties.CopyStatusDescription ?? "Blob copy failed."),
                    $"Failed copying blob {sourceBlobName}. Copy status: {properties.CopyStatus}");

                return false;
            }
            catch (RequestFailedException ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Azure Storage error while copying blob {sourceBlobName} from {sourceContainer} to {targetContainer}/{targetBlobName}");

                return false;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Unexpected error while copying blob {sourceBlobName} from {sourceContainer} to {targetContainer}/{targetBlobName}");

                return false;
            }
        }

        public async Task<bool> DeleteBlobAsync(
            string storageAccountName,
            string containerName,
            string blobName)
        {
            try
            {
                var credential = new DefaultAzureCredential();

                var blobClient = new BlobClient(
                    new Uri($"https://{storageAccountName}.blob.core.windows.net/{containerName}/{blobName}"),
                    credential);

                var response = await blobClient.DeleteIfExistsAsync();

                if (response.Value)
                {
                    _appInsightsLoggerHelper.LogInformation(
                        $"Successfully deleted blob {blobName} from container {containerName}.");
                }
                else
                {
                    _appInsightsLoggerHelper.LogWarning(
                        $"Blob {blobName} was not found in container {containerName}.");
                }

                return response.Value;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Failed deleting blob {blobName} from container {containerName}");

                return false;
            }
        }
        public async Task<DocumentMetadataUpdate> GetDocumentMetadataAsync(string storageAccountName, string blobUri, DocumentType docType)
        {
            if (string.IsNullOrWhiteSpace(blobUri))
            {
                _appInsightsLoggerHelper.LogWarning($"No blob URI provided for DocType {docType}.");
                throw new ArgumentNullException(nameof(blobUri));
            }
            blobUri=$"https://{storageAccountName}.blob.core.windows.net/{blobUri}";
            _appInsightsLoggerHelper.LogInformation($"Fetching blob metadata for DocType: {docType}, BlobUri: {blobUri}");

            try
            {
                var blobClient = new BlobClient(new Uri(blobUri), new DefaultAzureCredential());
                BlobProperties properties = await blobClient.GetPropertiesAsync();

                var doc = new DocumentMetadataUpdate
                {
                    DocType = docType,
                    ContentLength = properties.ContentLength,
                    ContentMd5 = properties.ContentHash != null ? Convert.ToBase64String(properties.ContentHash) : null,
                    Extension = Path.GetExtension(blobClient.Name)
                };

                _appInsightsLoggerHelper.LogInformation($"Blob metadata retrieved successfully for DocType: {docType}, Size: {doc.ContentLength}");
                return doc;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                _appInsightsLoggerHelper.LogWarning($"Blob not found. DocType: {docType}, BlobUri: {blobUri}");
                throw;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed fetching blob metadata. DocType: {docType}, BlobUri: {blobUri}");
                throw;
            }
        }

        public async Task<BlobCleanupResult> DeleteBlobsBeforeRetentionAsync(
       string storageAccountName,
       string containerName,
       int retentionDays)
        {
            if (retentionDays < 0)
                throw new ArgumentOutOfRangeException(nameof(retentionDays), "Retention days must be zero or greater.");

            var result = new BlobCleanupResult();
            var cutoffDate = DateTime.UtcNow.Date.AddDays(-retentionDays);

            _appInsightsLoggerHelper.LogInformation(
                $"Starting blob cleanup in container '{containerName}'. Retention: {retentionDays} day(s). Cutoff date (exclusive): {cutoffDate:yyyy-MM-dd}.");

            try
            {
                var credential = new DefaultAzureCredential();

                var containerClient = new BlobContainerClient(
                    new Uri($"https://{storageAccountName}.blob.core.windows.net/{containerName}"),
                    credential);

                await foreach (BlobItem blob in containerClient.GetBlobsAsync())
                {
                    if (!TryParseDateFromBlobPath(blob.Name, out var blobDate))
                    {
                        _appInsightsLoggerHelper.LogInformation($"Skipping blob with unrecognised path format: '{blob.Name}'.");
                        result.Skipped++;
                        continue;
                    }

                    if (blobDate >= cutoffDate)
                    {
                        result.Retained++;
                        continue;
                    }

                    try
                    {
                        var blobClient = containerClient.GetBlobClient(blob.Name);
                        var deleted = await blobClient.DeleteIfExistsAsync();

                        if (deleted.Value)
                        {
                            _appInsightsLoggerHelper.LogInformation(
                                $"Deleted blob '{blob.Name}' (date: {blobDate:yyyy-MM-dd}, cutoff: {cutoffDate:yyyy-MM-dd}).");
                            result.Deleted++;
                            result.DeletedBlobs.Add(blob.Name);
                        }
                        else
                        {
                            _appInsightsLoggerHelper.LogWarning(
                                $"Blob '{blob.Name}' was listed but no longer exists. Skipping.");
                            result.Skipped++;
                        }
                    }
                    catch (RequestFailedException ex)
                    {
                        _appInsightsLoggerHelper.LogError(
                            ex,
                            $"Azure Storage error while deleting blob '{blob.Name}' (HTTP {ex.Status}). Continuing cleanup.");
                        result.Failed++;
                    }
                    catch (Exception ex)
                    {
                        _appInsightsLoggerHelper.LogError(
                            ex,
                            $"Unexpected error while deleting blob '{blob.Name}'. Continuing cleanup.");
                        result.Failed++;
                    }
                }

                _appInsightsLoggerHelper.LogInformation(
                    $"Blob cleanup complete for container '{containerName}'. Deleted: {result.Deleted}, Retained: {result.Retained}, Skipped: {result.Skipped}, Failed: {result.Failed}.");

                return result;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Fatal error during blob cleanup for container '{containerName}'.");
                throw;
            }
        }

        public async Task<int> DeleteEmptyDirectoriesBeforeRetentionAsync(
            string storageAccountName,
            string containerName,
            int retentionDays,
            CancellationToken cancellationToken = default)
        {
            if (retentionDays < 0)
                throw new ArgumentOutOfRangeException(nameof(retentionDays), "Retention days must be zero or greater.");

            var cutoffDate = DateTime.UtcNow.Date.AddDays(-retentionDays);
            var deletedCount = 0;

            _appInsightsLoggerHelper.LogInformation(
                $"Starting empty directory cleanup in container '{containerName}'. Cutoff date: {cutoffDate:yyyy-MM-dd}.");

            try
            {
                var credential = new DefaultAzureCredential();

                var containerClient = new BlobContainerClient(
                    new Uri($"https://{storageAccountName}.blob.core.windows.net/{containerName}"),
                    credential);

                await foreach (var yearItem in containerClient.GetBlobsByHierarchyAsync(
                    BlobTraits.None, BlobStates.None, "/", null, cancellationToken))
                {
                    if (!yearItem.IsPrefix) continue;

                    var monthHasContents = false;

                    await foreach (var monthItem in containerClient.GetBlobsByHierarchyAsync(
                        BlobTraits.None, BlobStates.None, "/", yearItem.Prefix, cancellationToken))
                    {
                        if (!monthItem.IsPrefix) continue;

                        var dayHasContents = false;

                        await foreach (var dayItem in containerClient.GetBlobsByHierarchyAsync(
                            BlobTraits.None, BlobStates.None, "/", monthItem.Prefix, cancellationToken))
                        {
                            if (!dayItem.IsPrefix) continue;

                            if (!TryParseDateFromBlobPath(dayItem.Prefix + "placeholder", out var dirDate))
                                continue;

                            if (dirDate >= cutoffDate)
                            {
                                dayHasContents = true;
                                continue;
                            }

                            var dayIsEmpty = true;

                            await foreach (var child in containerClient.GetBlobsByHierarchyAsync(
                                BlobTraits.None, BlobStates.None, "/", dayItem.Prefix, cancellationToken))
                            {
                                dayIsEmpty = false;
                                break;
                            }

                            if (!dayIsEmpty)
                            {
                                _appInsightsLoggerHelper.LogInformation(
                                    $"Skipping non-empty day directory '{dayItem.Prefix}'.");
                                dayHasContents = true;
                                continue;
                            }

                            try
                            {
                                var dayDirClient = containerClient.GetBlobClient(dayItem.Prefix.TrimEnd('/'));

                                await dayDirClient.DeleteIfExistsAsync(
                                    conditions: null,
                                    cancellationToken: cancellationToken);

                                _appInsightsLoggerHelper.LogInformation(
                                    $"Deleted empty day directory '{dayItem.Prefix}' (date: {dirDate:yyyy-MM-dd}).");
                                deletedCount++;
                            }
                            catch (RequestFailedException ex)
                            {
                                _appInsightsLoggerHelper.LogError(
                                    ex,
                                    $"Azure Storage error deleting day directory '{dayItem.Prefix}' (HTTP {ex.Status}).");
                                dayHasContents = true;
                            }
                            catch (Exception ex)
                            {
                                _appInsightsLoggerHelper.LogError(
                                    ex,
                                    $"Unexpected error deleting day directory '{dayItem.Prefix}'.");
                                dayHasContents = true;
                            }
                        }

                        if (dayHasContents)
                        {
                            _appInsightsLoggerHelper.LogInformation(
                                $"Skipping month directory '{monthItem.Prefix}' � still has contents.");
                            monthHasContents = true;
                            continue;
                        }

                        try
                        {
                            var monthDirClient = containerClient.GetBlobClient(monthItem.Prefix.TrimEnd('/'));

                            await monthDirClient.DeleteIfExistsAsync(
                                conditions: null,
                                cancellationToken: cancellationToken);

                            _appInsightsLoggerHelper.LogInformation(
                                $"Deleted empty month directory '{monthItem.Prefix}'.");
                            deletedCount++;
                        }
                        catch (RequestFailedException ex)
                        {
                            _appInsightsLoggerHelper.LogError(
                                ex,
                                $"Azure Storage error deleting month directory '{monthItem.Prefix}' (HTTP {ex.Status}).");
                            monthHasContents = true;
                        }
                        catch (Exception ex)
                        {
                            _appInsightsLoggerHelper.LogError(
                                ex,
                                $"Unexpected error deleting month directory '{monthItem.Prefix}'.");
                            monthHasContents = true;
                        }
                    }

                    if (monthHasContents)
                    {
                        _appInsightsLoggerHelper.LogInformation(
                            $"Skipping year directory '{yearItem.Prefix}' � still has contents.");
                        continue;
                    }

                    try
                    {
                        var yearDirClient = containerClient.GetBlobClient(yearItem.Prefix.TrimEnd('/'));

                        await yearDirClient.DeleteIfExistsAsync(
                            conditions: null,
                            cancellationToken: cancellationToken);

                        _appInsightsLoggerHelper.LogInformation(
                            $"Deleted empty year directory '{yearItem.Prefix}'.");
                        deletedCount++;
                    }
                    catch (RequestFailedException ex)
                    {
                        _appInsightsLoggerHelper.LogError(
                            ex,
                            $"Azure Storage error deleting year directory '{yearItem.Prefix}' (HTTP {ex.Status}).");
                    }
                    catch (Exception ex)
                    {
                        _appInsightsLoggerHelper.LogError(
                            ex,
                            $"Unexpected error deleting year directory '{yearItem.Prefix}'.");
                    }
                }

                _appInsightsLoggerHelper.LogInformation(
                    $"Directory cleanup complete for container '{containerName}'. Deleted {deletedCount} empty directory/ies.");

                return deletedCount;
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(
                    ex,
                    $"Fatal error during directory cleanup for container '{containerName}'.");
                throw;
            }
        }

        private static bool TryParseDateFromBlobPath(string blobName, out DateTime date)
        {
            date = default;

            var parts = blobName.Split('/');

            if (parts.Length < 4)
                return false;

            var datePart = $"{parts[0]}/{parts[1]}/{parts[2]}";

            return DateTime.TryParseExact(
                datePart,
                "yyyy/MM/dd",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None,
                out date);
        }
    }
}