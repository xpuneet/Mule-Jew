﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Data.Services;

public class ColumbusStatementDownloadService : IColumbusStatementDownloadService
{
    private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
    private readonly IColumbusWebService _columbusWebService;
    private readonly IDbExecutor _dbExecutor;
    private readonly string _username;
    private readonly string _password;
    private readonly int _maxMatches;
    private readonly string _docType = "SNS";
    private readonly string _storageAccountUrl;
    private readonly string _containerName;
    private readonly int _maxDegreeOfParallelism;
    private readonly int _maxPollingAttempts;
    private readonly int _retryDelaySeconds;

    public ColumbusStatementDownloadService(
        IAppInsightsLoggerHelper appInsightsLoggerHelper,
        [FromKeyedServices("OrderDb")] IDbExecutor dbExecutor,
        IColumbusWebService columbusWebService,
        IConfiguration configuration)
    {
        _appInsightsLoggerHelper = appInsightsLoggerHelper;
        _columbusWebService = columbusWebService;
        _dbExecutor = dbExecutor;
        _maxPollingAttempts = configuration.GetValue<int>("Columbus:MaxRetryAttempts");
        _retryDelaySeconds = configuration.GetValue<int>("Columbus:RetryDelaySeconds");
        _username = configuration["Columbus:Username"]
            ?? throw new InvalidOperationException("Columbus:Username is not configured.");
        _password = configuration["Columbus:Password"]
            ?? throw new InvalidOperationException("Columbus:Password is not configured.");
        _maxMatches = configuration.GetValue<int>("Columbus:MaxMatches", 200);
        _storageAccountUrl = configuration["BlobStorage:StorageAccountUrl"]
            ?? throw new InvalidOperationException("BlobStorage:StorageAccountUrl is not configured.");
        _containerName = configuration["BlobStorage:StatementContainerName"].NullIfEmpty() ?? configuration["DownloadSettings:Statement:ContainerName"].NullIfEmpty()
            ?? throw new InvalidOperationException("BlobStorage containerName is not configured for statement.");
        _maxDegreeOfParallelism = configuration.GetValue<int>("Columbus:MaxDegreeOfParallelism", 1);
    }

    public async Task DownloadAndSyncStatementsAsync()
    {
        IEnumerable<ColumbusStatementHeader> unsynchronizedStatements;
        try
        {
            unsynchronizedStatements = await SearchUnSynchronizedStatementDocuments();
            _appInsightsLoggerHelper.LogInformation($"Fetched unsynchronized Statements. Count: {unsynchronizedStatements?.Count() ?? 0}");
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Failed to fetch unsynchronized Statements. Aborting.");
            return;
        }

        if (unsynchronizedStatements==null || !unsynchronizedStatements.Any())
        {
            _appInsightsLoggerHelper.LogInformation("No unsynchronized Statements found.");
            return;
        }

        await Parallel.ForEachAsync(
            unsynchronizedStatements,
            new ParallelOptions { MaxDegreeOfParallelism = _maxDegreeOfParallelism },
            async (Statement, _) => await ProcessStatementAsync(Statement));
    }

    public async Task<IEnumerable<ColumbusStatementHeader>> SearchUnSynchronizedStatementDocuments()
    {
        _appInsightsLoggerHelper.LogInformation("Fetching unsynchronized Statement documents.");
        try
        {
            var result = await _dbExecutor.ExecuteListAsync<ColumbusStatementHeader>(
                StoredProcedures.GetUnsynchronizedStatements,
                new { });

            _appInsightsLoggerHelper.LogInformation($"Fetched unsynchronized Statement documents successfully. Count: {result?.Count()}");
            return result ?? Enumerable.Empty<ColumbusStatementHeader>();
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Failed to fetch unsynchronized Statement documents.");
            throw;
        }
    }

    public async Task<int> UpdateStatementHeader(ColumbusStatementHeaderMetadataRequest request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        _appInsightsLoggerHelper.LogInformation(
            $"Updating Statement header. StatementheaderId: {request.StatementHeaderId}");

        try
        {
            var rowsUpdated = await _dbExecutor.ExecuteWithOutputAsync(
                StoredProcedures.UpdateStatementHeaderMetadata,
                "@RowsUpdated",
                request);

            _appInsightsLoggerHelper.LogInformation(
                $"Statement header metadata updated successfully. RowsUpdated: {rowsUpdated}");

            return rowsUpdated;
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex,
                $"Failed to update Statement header metadata. StatementheaderId: {request.StatementHeaderId}");
            throw;
        }
    }
    private async Task ProcessStatementAsync(ColumbusStatementHeader Statement)
    {
        string accountCode = Statement.AccountCode;
        string branchNo = Statement.OwningBranch;
        string? startDate = Statement.StatementDate.ToString("dd/MM/yyyy");
        string? endDate = Statement.StatementDate.ToString("dd/MM/yyyy");

        _appInsightsLoggerHelper.LogInformation($"Processing Statement. StatementheaderId: {Statement.StatementHeaderId}, AccountCode: {accountCode}, BranchNo: {branchNo},  Date: {startDate}");

        if (string.IsNullOrWhiteSpace(startDate) || string.IsNullOrWhiteSpace(endDate))
        {
            _appInsightsLoggerHelper.LogWarning($"Statement skipped — StatementDateTime is null. StatementheaderId: {Statement.StatementHeaderId}");
            return;
        }

        ColumbusOpenSessionResult openResponse;
        try
        {
            openResponse = await _columbusWebService.OpenSessionAsync(_username, _password);
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, $"Failed to open Columbus session. StatementheaderId: {Statement.StatementHeaderId}");
            return;
        }

        if (openResponse.ErrorNumber != 0)
        {
            _appInsightsLoggerHelper.LogWarning($"OpenSession returned an error. Skipping Statement. StatementheaderId: {Statement.StatementHeaderId}, ErrorNumber: {openResponse.ErrorNumber}, ErrorMessage: {openResponse.ErrorMessage}");
            return;
        }

        if (openResponse.Archive == null)
        {
            _appInsightsLoggerHelper.LogWarning($"OpenSession returned no archive. Skipping Statement. StatementheaderId: {Statement.StatementHeaderId}");
            return;
        }
        string sessionId = openResponse.SessionId;
        int archiveId = openResponse.Archive.ArchiveId;
        _appInsightsLoggerHelper.LogInformation($"Columbus session opened. SessionId: {sessionId}, ArchiveId: {archiveId}, StatementheaderId: {Statement.StatementHeaderId}");

        try
        {
            await RunSearchAndDownloadLoopAsync(Statement, sessionId, archiveId);
        }
        finally
        {
            try
            {
                await _columbusWebService.CloseSessionAsync(sessionId);
                _appInsightsLoggerHelper.LogInformation($"Columbus session closed. SessionId: {sessionId}, StatementheaderId: {Statement.StatementHeaderId}");
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to close Columbus session. SessionId: {sessionId}, StatementheaderId: {Statement.StatementHeaderId}");
            }
        }
    }

    private async Task RunSearchAndDownloadLoopAsync(
   ColumbusStatementHeader Statement,
   string sessionId,
   int archiveId
        )
    {
        string? continueSearch = null;
        do
        {
            _appInsightsLoggerHelper.LogInformation($"Beginning search operation. SessionId: {sessionId}, StatementheaderId: {Statement.StatementHeaderId}, ContinueSearch: {continueSearch ?? "null"}");
            var (beginSearchErrorNumber, beginSearchErrorMessage) = await _columbusWebService.BeginSearchOperationAsync(
            sessionId, archiveId, _maxMatches, _docType, Statement.AccountCode, Statement.OwningBranch, null, Statement.StatementDate.ToString("dd/MM/yyyy"), Statement.StatementDate.ToString("dd/MM/yyyy"), continueSearch);
            if (beginSearchErrorNumber != 0)
            {
                _appInsightsLoggerHelper.LogWarning($"BeginSearchOperation failed. Aborting search loop. StatementheaderId: {Statement.StatementHeaderId}, ErrorNumber: {beginSearchErrorNumber}, ErrorMessage: {beginSearchErrorMessage}");
                return;
            }
            ColumbusSearchResult? searchResult = await PollSearchResultsAsync(sessionId, Statement.StatementHeaderId);
            if (searchResult == null)
                return;
            continueSearch = searchResult.ContinueSearch;
            int totalPages = searchResult.TotalDocuments;
            _appInsightsLoggerHelper.LogInformation($"Search results retrieved. StatementheaderId: {Statement.StatementHeaderId}, TotalPages: {totalPages}, ContinueSearch: {continueSearch ?? "null"}");
            if (totalPages == 0)
            {
                _appInsightsLoggerHelper.LogWarning($"No documents found for Statement. StatementheaderId: {Statement.StatementHeaderId}");
                break;
            }
            for (int page = 1; page <= totalPages; page++)
            {
                await ProcessPageAsync(Statement, sessionId, page, totalPages);
            }
        } while (!string.IsNullOrEmpty(continueSearch));
    }
    private async Task<ColumbusSearchResult?> PollSearchResultsAsync(string sessionId, long StatementheaderId)
    {

        for (int attempt = 1; attempt <= _maxPollingAttempts; attempt++)
        {
            ColumbusSearchResult searchResult;
            try
            {
                searchResult = await _columbusWebService.GetSearchResultsAsync(sessionId);
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to get search results. SessionId: {sessionId}, StatementheaderId: {StatementheaderId}, Attempt: {attempt}/{_maxPollingAttempts}");
                return null;
            }
            if (searchResult.OperationStatus == "ACTIVE")
            {
                if (attempt == _maxPollingAttempts)
                {
                    _appInsightsLoggerHelper.LogWarning($"Search operation still ACTIVE after {_maxPollingAttempts} attempt(s). Aborting. SessionId: {sessionId}, StatementheaderId: {StatementheaderId}");
                    return null;
                }
                _appInsightsLoggerHelper.LogInformation($"Search operation ACTIVE on attempt {attempt}/{_maxPollingAttempts}. Retrying. SessionId: {sessionId}, StatementheaderId: {StatementheaderId}");
                await Task.Delay(TimeSpan.FromSeconds(_retryDelaySeconds));
                continue;
            }
            _appInsightsLoggerHelper.LogInformation($"Search operation completed. SessionId: {sessionId}, StatementheaderId: {StatementheaderId}, Attempt: {attempt}, OperationStatus: {searchResult.OperationStatus}");
            return searchResult;
        }
        return null;
    }

    private async Task ProcessPageAsync(
   ColumbusStatementHeader Statement,
   string sessionId,
   int page,
   int totalPages)
    {
        _appInsightsLoggerHelper.LogInformation($"Beginning page operation. StatementheaderId: {Statement.StatementHeaderId}, Page: {page}/{totalPages}");
        var (beginPageErrorNumber, beginPageErrorMessage) = await _columbusWebService.BeginPageOperationAsync(sessionId, page);
        if (beginPageErrorNumber != 0)
        {
            _appInsightsLoggerHelper.LogWarning($"BeginPageOperation failed. Skipping page. StatementheaderId: {Statement.StatementHeaderId}, Page: {page}, ErrorNumber: {beginPageErrorNumber}, ErrorMessage: {beginPageErrorMessage}");
            return;
        }
        ColumbusPageResponse? uploadResponse = await PollPageResultsAsync(Statement, sessionId, page, totalPages);
        if (uploadResponse == null)
            return;
        if (uploadResponse.ErrorNumber != 0)
        {
            _appInsightsLoggerHelper.LogWarning($"GetPageResultsAndUploadToBlob returned an error. Skipping update. StatementheaderId: {Statement.StatementHeaderId}, Page: {page}, ErrorNumber: {uploadResponse.ErrorNumber}, ErrorMessage: {uploadResponse.ErrorMessage}");
            return;
        }
        _appInsightsLoggerHelper.LogInformation($"Page uploaded to blob successfully. StatementheaderId: {Statement.StatementHeaderId}, BlobUrl: {uploadResponse.BlobUrl}, FileName: {uploadResponse.CalculatedFileName}");
        await UpdateStatementHeaderAsync(Statement, uploadResponse);
    }

    private async Task<ColumbusPageResponse?> PollPageResultsAsync(
      ColumbusStatementHeader Statement,
      string sessionId,
      int page,
      int totalPages)
    {
        for (int attempt = 1; attempt <= _maxPollingAttempts; attempt++)
        {
            ColumbusPageResponse uploadResponse;
            try
            {
                uploadResponse = await _columbusWebService.GetPageResultsAndUploadToBlobAsync(
                sessionId, Statement.AccountCode, Statement.OwningBranch,null,page, totalPages, Statement.StatementDate.ToString("dd/MM/yyyy"),
                _storageAccountUrl, _containerName);
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to get page results or upload to blob. StatementheaderId: {Statement.StatementHeaderId}, Page: {page}, Attempt: {attempt}/{_maxPollingAttempts}");
                return null;
            }
            if (uploadResponse.OperationStatus == "ACTIVE")
            {
                if (attempt == _maxPollingAttempts)
                {
                    _appInsightsLoggerHelper.LogWarning($"Page operation still ACTIVE after {_maxPollingAttempts} attempt(s). Aborting. StatementheaderId: {Statement.StatementHeaderId}, Page: {page}");
                    return null;
                }
                _appInsightsLoggerHelper.LogInformation($"Page operation ACTIVE on attempt {attempt}/{_maxPollingAttempts}. Retrying in {_retryDelaySeconds}s. StatementheaderId: {Statement.StatementHeaderId}, Page: {page}");
                await Task.Delay(TimeSpan.FromSeconds(_retryDelaySeconds));
                continue;
            }
            _appInsightsLoggerHelper.LogInformation($"Page operation completed. StatementheaderId: {Statement.StatementHeaderId}, Page: {page}, Attempt: {attempt}, OperationStatus: {uploadResponse.OperationStatus}");
            return uploadResponse;
        }
        return null;
    }

    private async Task UpdateStatementHeaderAsync(ColumbusStatementHeader Statement, ColumbusPageResponse uploadResponse)
    {
        try
        {
            DateTimeOffset? createdOn = null;

            if (DateTimeOffset.TryParseExact(
                    uploadResponse.CreationTime,
                    "HH:mm  dd/MM/yyyy",
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out var parsedDate))
            {
                createdOn = parsedDate;
            }
            else
            {
                _appInsightsLoggerHelper.LogWarning(
                    $"Could not parse CreationTime. Setting to null. Invoice HeaderId: {Statement.StatementHeaderId}, RawCreationTime: '{uploadResponse.CreationTime}'");
            }
            
            var request = new ColumbusStatementHeaderMetadataRequest
            {
                StatementHeaderId = Statement.StatementHeaderId,
                OriginalFileName = uploadResponse.SourceFileName ?? string.Empty,
                Extension = uploadResponse.Extension ?? string.Empty,
                CalculatedFileName = uploadResponse.CalculatedFileName ?? string.Empty,
                ContentMd5 = uploadResponse.ContentMd5,
                ContentLength = uploadResponse.FileSize,
                BlobUri = uploadResponse.BlobUrl ?? string.Empty,
                CreatedOn = createdOn,
                IsSynchronized = true
            };
           int rowsUpdated= await UpdateStatementHeader(request);
            if(rowsUpdated == 0)
            {
                _appInsightsLoggerHelper.LogError(new Exception($"No Records Found for StatementheaderId {Statement.StatementHeaderId}"), $"No Records Found for StatementheaderId {Statement.StatementHeaderId}");
            }
            _appInsightsLoggerHelper.LogInformation($"Statement header updated successfully. StatementheaderId: {Statement.StatementHeaderId}, FileName: {uploadResponse.CalculatedFileName}");
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, $"Failed to update Statement header. StatementheaderId: {Statement.StatementHeaderId}, BlobUrl: {uploadResponse.BlobUrl}");
        }
    }

         public async Task<ColumbusStatementHeaderMetadataRequest?> DownloadStatementByStatementHeaderIdAsync(long statementHeaderId)
    {
        try
        {
            var statement = await GetStatementByStatementHeaderId(statementHeaderId);

            if (statement == null || statement?.StatementHeaderId == null)
            {
                _appInsightsLoggerHelper.LogInformation($"No statement found with Id {statementHeaderId}.");
                return null;
            }

            _appInsightsLoggerHelper.LogInformation($"Fetched statement details with id {statementHeaderId}");

            await ProcessStatementAsync(statement);

            var statementMetaData = await GetStatementHeaderMetadataByStatementHeaderId(statementHeaderId);

            return statementMetaData;
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, $"Failed processing statement {statementHeaderId}");
            throw;
        }
    }

    public async Task<ColumbusStatementHeaderMetadataRequest?> GetStatementHeaderMetadataByStatementHeaderId(long statementHeaderId)
    {
        _appInsightsLoggerHelper.LogInformation($"Fetching Statement Metadata with Header Id {statementHeaderId}");
        try
        {
            var result = await _dbExecutor.ExecuteSingleAsync<ColumbusStatementHeaderMetadataRequest>(
                StoredProcedures.GetStatementHeaderMetaDataByStatementHeaderId,
                new { statementHeaderId = statementHeaderId });

            _appInsightsLoggerHelper.LogInformation($"Fetched Statement Header Metadata details successfully for id {statementHeaderId}");
            return result;
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Failed to fetch Statement Header Metadata details .");
            throw;
        }
    }

    public async Task<ColumbusStatementHeader?> GetStatementByStatementHeaderId(long statementHeaderId)
    {
        _appInsightsLoggerHelper.LogInformation($"Fetching Statement Header Id {statementHeaderId}");
        try
        {
            var result = await _dbExecutor.ExecuteSingleAsync<ColumbusStatementHeader>(
                StoredProcedures.GetStatementHeaderByStatementHeaderId,
                new { statementHeaderId = statementHeaderId });

            _appInsightsLoggerHelper.LogInformation($"Fetched Statement Header details successfully for id {statementHeaderId}");
            return result;
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Failed to fetch Statement Header details .");
            throw;
        }
    }
    public bool DownloadStatementByStatementHeaderId(long statementHeaderId)
    {
        _ = DownloadStatementByStatementHeaderIdAsync(statementHeaderId);

        return true;
    }
}

file static class StringExtensions
{
    internal static string? NullIfEmpty(this string? value) =>
        string.IsNullOrEmpty(value) ? null : value;
}
