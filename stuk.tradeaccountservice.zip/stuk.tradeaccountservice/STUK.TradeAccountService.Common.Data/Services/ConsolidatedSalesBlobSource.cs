using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Runtime.CompilerServices;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides access to staged HX consolidated sales files in Blob Storage
    /// </summary>
    public class ConsolidatedSalesBlobSource : IConsolidatedSalesBlobSource
    {
        private const string ProcessedSuffix = "-ok";
        private const string CorrelationIdMetadataName = "CorrelationID";
        private const int CopyStatusPollingDelayMilliseconds = 500;

        private readonly ILogger<ConsolidatedSalesBlobSource> _logger;
        private readonly BlobServiceClient _blobServiceClient;
        private readonly ConsolidatedSalesIngestionOptions _options;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesBlobSource"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="blobServiceClient">Blob service client</param>
        /// <param name="options"><see cref="ConsolidatedSalesIngestionOptions"/></param>
        /// <exception cref="ArgumentNullException"></exception>
        public ConsolidatedSalesBlobSource(ILogger<ConsolidatedSalesBlobSource> logger, BlobServiceClient blobServiceClient, IOptions<ConsolidatedSalesIngestionOptions> options)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _blobServiceClient = blobServiceClient ?? throw new ArgumentNullException(nameof(blobServiceClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
        }

        /// <inheritdoc />
        public async IAsyncEnumerable<ConsolidatedSalesSourceRegistration> DiscoverAsync([EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            ValidateOptions();

            var containerClient = _blobServiceClient.GetBlobContainerClient(_options.ContainerName);

            await foreach (var blob in containerClient.GetBlobsAsync(BlobTraits.Metadata, BlobStates.None, prefix: _options.ReadyPrefix, cancellationToken: cancellationToken))
            {
                if (!blob.Name.EndsWith(_options.FileSuffix, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                ConsolidatedSalesSourceRegistration registration;
                try
                {
                    registration = CreateRegistration(blob);
                }
                catch (InvalidOperationException exception)
                {
                    _logger.LogError(
                        exception,
                        "Rejected staged HX Blob {BlobContainer}/{BlobPath}; the file remains unprocessed for operational correction",
                        _options.ContainerName,
                        blob.Name);
                    continue;
                }

                yield return registration;
            }
        }

        private ConsolidatedSalesSourceRegistration CreateRegistration(BlobItem blob)
        {
            var contentLength = blob.Properties.ContentLength ?? throw new InvalidOperationException($"Blob {blob.Name} did not provide a content length");

            return new ConsolidatedSalesSourceRegistration
            {
                CorrelationId = ReadCorrelationId(blob),
                SourceSystem = _options.SourceSystem,
                BlobContainer = _options.ContainerName,
                BlobPath = blob.Name,
                SourceFileName = Path.GetFileName(blob.Name),
                ContentLength = contentLength,
                BlobLastModifiedOn = blob.Properties.LastModified ?? throw new InvalidOperationException($"Blob {blob.Name} did not provide a last-modified time"),
                ContentChecksum = blob.Properties.ContentHash is { Length: > 0 } contentHash ? Convert.ToBase64String(contentHash) : null,
                ETag = blob.Properties.ETag?.ToString() ?? throw new InvalidOperationException($"Blob {blob.Name} did not provide an entity tag")
            };
        }

        private Guid ReadCorrelationId(BlobItem blob)
        {
            if (blob.Metadata.TryGetValue(CorrelationIdMetadataName, out var value) && Guid.TryParse(value, out var correlationId))
            {
                return correlationId;
            }

            var generatedCorrelationId = Guid.NewGuid();
            _logger.LogWarning(
                "Staged HX Blob {BlobPath} did not provide a valid {MetadataName}; generated correlation identifier {CorrelationId}",
                blob.Name,
                CorrelationIdMetadataName,
                generatedCorrelationId);

            return generatedCorrelationId;
        }

        /// <inheritdoc />
        public async Task<Stream> OpenReadAsync(
            string containerName,
            string blobPath,
            string expectedETag,
            CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(containerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(blobPath);
            ArgumentException.ThrowIfNullOrWhiteSpace(expectedETag);

            var blobClient = _blobServiceClient
                .GetBlobContainerClient(containerName)
                .GetBlobClient(blobPath);

            var download = await blobClient.DownloadStreamingAsync(new BlobDownloadOptions
            {
                Conditions = new BlobRequestConditions
                {
                    IfMatch = new ETag(expectedETag)
                }
            }, cancellationToken);

            return download.Value.Content;
        }

        /// <inheritdoc />
        public async Task RenameAsProcessedAsync(
            string containerName,
            string blobPath,
            long expectedContentLength,
            string expectedETag,
            CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(containerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(blobPath);
            ArgumentException.ThrowIfNullOrWhiteSpace(expectedETag);

            if (expectedContentLength < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(expectedContentLength), "The expected content length cannot be negative");
            }

            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            var sourceBlob = containerClient.GetBlobClient(blobPath);
            var processedBlob = containerClient.GetBlobClient($"{blobPath}{ProcessedSuffix}");
            var sourceETag = new ETag(expectedETag);

            await processedBlob.StartCopyFromUriAsync(sourceBlob.Uri, new BlobCopyFromUriOptions
            {
                SourceConditions = new BlobRequestConditions
                {
                    IfMatch = sourceETag
                }
            }, cancellationToken);

            BlobProperties processedProperties;
            do
            {
                await Task.Delay(CopyStatusPollingDelayMilliseconds, cancellationToken);
                processedProperties = (await processedBlob.GetPropertiesAsync(cancellationToken: cancellationToken)).Value;
            }
            while (processedProperties.CopyStatus == CopyStatus.Pending);

            if (processedProperties.CopyStatus != CopyStatus.Success)
            {
                throw new InvalidOperationException($"Blob copy did not complete successfully: {processedProperties.CopyStatusDescription}");
            }

            if (processedProperties.ContentLength != expectedContentLength)
            {
                throw new InvalidOperationException("The processed Blob length does not match the source-file length");
            }

            if (expectedContentLength > 0)
            {
                await using var processedDownload = (await processedBlob.DownloadStreamingAsync(new BlobDownloadOptions
                {
                    Conditions = new BlobRequestConditions
                    {
                        IfMatch = processedProperties.ETag
                    }
                }, cancellationToken)).Value.Content;

                var verificationBuffer = new byte[1];
                var bytesRead = await processedDownload.ReadAsync(verificationBuffer, cancellationToken);
                if (bytesRead != 1)
                {
                    throw new InvalidOperationException("The processed Blob could not be read after copying");
                }
            }

            await sourceBlob.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, new BlobRequestConditions
            {
                IfMatch = sourceETag
            }, cancellationToken: cancellationToken);
        }

        private void ValidateOptions()
        {
            if (string.IsNullOrWhiteSpace(_options.ContainerName))
            {
                throw new InvalidOperationException("The consolidated sales Blob container must be configured");
            }

            if (string.IsNullOrWhiteSpace(_options.FileSuffix))
            {
                throw new InvalidOperationException("The consolidated sales file suffix must be configured");
            }

            if (string.IsNullOrWhiteSpace(_options.ReadyPrefix))
            {
                throw new InvalidOperationException("The consolidated sales Blob ready prefix must be configured");
            }

            if (string.IsNullOrWhiteSpace(_options.SourceSystem))
            {
                throw new InvalidOperationException("The consolidated sales source system must be configured");
            }
        }
    }
}
