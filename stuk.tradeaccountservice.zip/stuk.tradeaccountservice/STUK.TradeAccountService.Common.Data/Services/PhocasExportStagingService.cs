using Azure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Generates and atomically stages claimed Phocas export work for the existing Blob-triggered transfer
    /// </summary>
    public class PhocasExportStagingService : IPhocasExportStagingService
    {
        private const string Destination = "Phocas";
        private const int MaximumWorkItemsPerRun = 1;
        private const int LeaseDurationSeconds = 900;
        private const int LeaseRenewalIntervalSeconds = 60;
        private const int RetryDelaySeconds = 300;
        private const int MaximumRetryCount = 5;
        private readonly ILogger<PhocasExportStagingService> _logger;
        private readonly IConsolidatedSalesExportDataService _exportDataService;
        private readonly IPhocasConsXrefFileGenerator _fileGenerator;
        private readonly IPhocasBlobStagingClient _blobStagingClient;
        private readonly PhocasBlobStagingOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="PhocasExportStagingService"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="exportDataService">The durable export persistence service</param>
        /// <param name="fileGenerator">The legacy-compatible ConsXref file generator</param>
        /// <param name="blobStagingClient">The atomic Blob staging client</param>
        /// <param name="options">The Phocas staging settings</param>
        /// <param name="timeProvider">Provider for processing timestamps and lease timers</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public PhocasExportStagingService(
            ILogger<PhocasExportStagingService> logger,
            IConsolidatedSalesExportDataService exportDataService,
            IPhocasConsXrefFileGenerator fileGenerator,
            IPhocasBlobStagingClient blobStagingClient,
            IOptions<PhocasBlobStagingOptions> options,
            TimeProvider timeProvider)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _exportDataService = exportDataService ?? throw new ArgumentNullException(nameof(exportDataService));
            _fileGenerator = fileGenerator ?? throw new ArgumentNullException(nameof(fileGenerator));
            _blobStagingClient = blobStagingClient ?? throw new ArgumentNullException(nameof(blobStagingClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task RunAsync(string leaseOwner, Guid? exportDestinationId = null, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);
            ValidateOptions();

            for (var itemNumber = 0; itemNumber < MaximumWorkItemsPerRun; itemNumber++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var work = await _exportDataService.ClaimNextDestinationAsync(
                    Destination,
                    leaseOwner,
                    LeaseDurationSeconds,
                    MaximumRetryCount,
                    exportDestinationId,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                if (work is null)
                {
                    break;
                }

                await ProcessWithLeaseRenewalAsync(work, cancellationToken);
            }
        }

        private async Task ProcessWithLeaseRenewalAsync(ConsolidatedSalesExportDestinationWork work, CancellationToken cancellationToken)
        {
            using var processingCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            var renewalTask = RenewLeaseUntilCancelledAsync(work, processingCancellation.Token);
            var processingTask = ProcessAsync(work, processingCancellation.Token);
            var renewalCompletedFirst = false;

            try
            {
                var firstCompletedTask = await Task.WhenAny(processingTask, renewalTask);
                if (firstCompletedTask == renewalTask)
                {
                    renewalCompletedFirst = true;
                    await renewalTask;
                }

                await processingTask;
            }
            finally
            {
                await processingCancellation.CancelAsync();
                try
                {
                    await renewalTask;
                }
                catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                {
                    // Expected after staging completes or a lease renewal fails.
                }
                catch when (renewalCompletedFirst)
                {
                    // The renewal failure was already observed and remains the primary exception.
                }

                if (!processingTask.IsCompleted)
                {
                    try
                    {
                        await processingTask;
                    }
                    catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                    {
                        // Staging must stop when its SQL lease can no longer be renewed.
                    }
                }
            }
        }

        private async Task ProcessAsync(ConsolidatedSalesExportDestinationWork work, CancellationToken cancellationToken)
        {
            var claimToken = ValidateClaimedWork(work);

            _logger.LogInformation(
                "Phocas Blob staging started for destination work {ExportDestinationId}, export {ExportRunId}, correlation {CorrelationId} and attempt {AttemptCount}",
                work.Id,
                work.ExportRunId,
                work.CorrelationId,
                work.AttemptCount);

            try
            {
                await using var content = new FileStream(
                    Path.Combine(Path.GetTempPath(), $"phocas-{Guid.NewGuid():N}.tmp"),
                    FileMode.CreateNew,
                    FileAccess.ReadWrite,
                    FileShare.None,
                    81920,
                    FileOptions.Asynchronous | FileOptions.SequentialScan | FileOptions.DeleteOnClose);

                var file = await _fileGenerator.GenerateAsync(work.ExportRunId, work.ExportYear, content, cancellationToken);
                if (file.RowCount != work.ExtractedRowCount)
                {
                    throw new InvalidDataException("The generated Phocas row count does not match the completed Salesforce snapshot.");
                }

                var staged = await _blobStagingClient.StageAsync(
                    new PhocasBlobStageRequest
                    {
                        BlobStagingPath = _options.BlobStagingPath,
                        BlobName = $"{_options.FileActionId}_{file.FileName}",
                        ContentLength = file.ByteCount,
                        RowCount = file.RowCount,
                        ContentHash = file.ContentHash,
                        ExportRunId = work.ExportRunId,
                        ExportDestinationId = work.Id,
                        CorrelationId = work.CorrelationId,
                        RetryCount = Math.Max(0, work.RetryCycleAttemptCount - 1)
                    },
                    content,
                    cancellationToken);

                await _exportDataService.CompleteDestinationAsync(
                    work.Id,
                    claimToken,
                    file.FileName,
                    staged.BlobPath,
                    file.ContentHash,
                    file.RowCount,
                    file.ByteCount,
                    null,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                _logger.LogInformation(
                    "Phocas Blob handoff completed for destination work {ExportDestinationId}, export {ExportRunId}, correlation {CorrelationId}, file {FileName}, path {FilePath}, rows {RowCount}, bytes {ByteCount} and hash {ContentHash}; downstream Synapse and SFTP completion remains externally owned",
                    work.Id,
                    work.ExportRunId,
                    work.CorrelationId,
                    file.FileName,
                    staged.BlobPath,
                    file.RowCount,
                    file.ByteCount,
                    file.ContentHash);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception exception)
            {
                var isPermanent = exception is InvalidDataException or ArgumentException or InvalidOperationException;
                var errorCategory = GetErrorCategory(exception);
                DateTimeOffset? nextAttemptOn = isPermanent
                    ? null
                    : _timeProvider.GetUtcNow().AddSeconds(RetryDelaySeconds);
                var message = exception.Message.Length <= 2000 ? exception.Message : exception.Message[..2000];
                await _exportDataService.FailDestinationAsync(
                    work.Id,
                    claimToken,
                    errorCategory,
                    message,
                    nextAttemptOn,
                    isPermanent ? work.RetryCycleAttemptCount : MaximumRetryCount,
                    null,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);

                _logger.LogError(
                    exception,
                    "Phocas Blob staging failed for destination work {ExportDestinationId}, export {ExportRunId}, correlation {CorrelationId}, category {ErrorCategory}, permanent {IsPermanent} and next attempt {NextAttemptOn}",
                    work.Id,
                    work.ExportRunId,
                    work.CorrelationId,
                    errorCategory,
                    isPermanent,
                    nextAttemptOn);
            }
        }

        private async Task RenewLeaseUntilCancelledAsync(ConsolidatedSalesExportDestinationWork work, CancellationToken cancellationToken)
        {
            var claimToken = work.ClaimToken ?? throw new InvalidOperationException($"Claimed Phocas destination {work.Id} has no claim token.");
            var renewalInterval = TimeSpan.FromSeconds(LeaseRenewalIntervalSeconds);

            while (true)
            {
                await Task.Delay(renewalInterval, _timeProvider, cancellationToken);
                await _exportDataService.RenewDestinationLeaseAsync(
                    work.Id,
                    claimToken,
                    LeaseDurationSeconds,
                    _timeProvider.GetUtcNow(),
                    cancellationToken);
            }
        }

        private static Guid ValidateClaimedWork(ConsolidatedSalesExportDestinationWork work)
        {
            if (!string.Equals(work.Destination, Destination, StringComparison.Ordinal)
                || !string.Equals(work.Status, "Claimed", StringComparison.Ordinal)
                || work.ClaimToken is null
                || work.ExtractedRowCount is null)
            {
                throw new InvalidOperationException("The Phocas destination must reference a completed snapshot and hold an active claim.");
            }

            return work.ClaimToken.Value;
        }

        private static string GetErrorCategory(Exception exception)
        {
            return exception switch
            {
                InvalidDataException => "InvalidFileContract",
                ArgumentException or InvalidOperationException => "InvalidConfiguration",
                RequestFailedException or HttpRequestException or IOException => "BlobUnavailable",
                _ => "BlobStaging"
            };
        }

        private void ValidateOptions()
        {
            if (string.IsNullOrWhiteSpace(_options.BlobStagingPath))
            {
                throw new InvalidOperationException("The Phocas Blob staging path is not configured.");
            }

            var stagingPath = _options.BlobStagingPath.Trim();
            if (stagingPath.Contains('\\') || stagingPath.Split('/', StringSplitOptions.None).Any(string.IsNullOrWhiteSpace))
            {
                throw new InvalidOperationException("The Phocas Blob staging path must contain a container name and an optional valid virtual-directory prefix.");
            }

            if (string.IsNullOrWhiteSpace(_options.FileActionId) || _options.FileActionId.Contains('_'))
            {
                throw new InvalidOperationException("The Phocas FileAction ID must be configured and cannot contain an underscore.");
            }

        }
    }
}
