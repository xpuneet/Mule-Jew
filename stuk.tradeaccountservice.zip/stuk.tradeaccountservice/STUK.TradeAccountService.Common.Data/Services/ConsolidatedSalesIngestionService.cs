using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Orchestrates HX consolidated sales ingestion into canonical persistence
    /// </summary>
    public class ConsolidatedSalesIngestionService : IConsolidatedSalesIngestionService
    {
        private const int MaximumErrorMessageLength = 2000;
        private const string CompletedStatus = "Completed";

        private readonly ILogger<ConsolidatedSalesIngestionService> _logger;
        private readonly IConsolidatedInvoiceDataService _invoiceDataService;
        private readonly IConsolidatedSalesFileDataService _fileDataService;
        private readonly IConsolidatedSalesBlobSource _blobSource;
        private readonly IHxConsolidatedInvoiceParser _parser;
        private readonly IHxInvoiceMapper _mapper;

        private readonly ConsolidatedSalesIngestionOptions _options;
        private readonly ColumbusOptions _columbusOptions;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesIngestionService"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="fileDataService">Consolidated Sales file data service</param>
        /// <param name="blobSource">Consolidated Sales Blob source</param>
        /// <param name="parser">HX consolidated invoice parser</param>
        /// <param name="mapper">HX invoice mapper</param>
        /// <param name="invoiceDataService">Consolidated invoice data service</param>
        /// <param name="options"><see cref="ConsolidatedSalesIngestionOptions"/></param>
        /// <param name="columbusOptions">Fallback Salesforce cool-off settings following the first successful Trade Account source read</param>
        /// <exception cref="ArgumentNullException"></exception>
        public ConsolidatedSalesIngestionService(
            ILogger<ConsolidatedSalesIngestionService> logger,
            IConsolidatedSalesFileDataService fileDataService,
            IConsolidatedSalesBlobSource blobSource,
            IHxConsolidatedInvoiceParser parser,
            IHxInvoiceMapper mapper,
            IConsolidatedInvoiceDataService invoiceDataService,
            IOptions<ConsolidatedSalesIngestionOptions> options,
            IOptions<ColumbusOptions> columbusOptions)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _fileDataService = fileDataService ?? throw new ArgumentNullException(nameof(fileDataService));
            _blobSource = blobSource ?? throw new ArgumentNullException(nameof(blobSource));
            _parser = parser ?? throw new ArgumentNullException(nameof(parser));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _invoiceDataService = invoiceDataService ?? throw new ArgumentNullException(nameof(invoiceDataService));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _columbusOptions = columbusOptions?.Value ?? throw new ArgumentNullException(nameof(columbusOptions));
        }

        /// <inheritdoc />
        public async Task RunAsync(string leaseOwner, CancellationToken cancellationToken = default)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(leaseOwner);

            ValidateOptions();
            cancellationToken.ThrowIfCancellationRequested();

            await foreach (var registration in _blobSource.DiscoverAsync(cancellationToken))
            {
                var registeredSource = await _fileDataService.RegisterAsync(registration, cancellationToken);

                if (string.Equals(registeredSource.Status, CompletedStatus, StringComparison.Ordinal))
                {
                    try
                    {
                        await _blobSource.RenameAsProcessedAsync(
                            registeredSource.BlobContainer,
                            registeredSource.BlobPath,
                            registeredSource.ContentLength,
                            RequiredETag(registeredSource),
                            cancellationToken);
                    }
                    catch (Exception exception) when (exception is not OperationCanceledException)
                    {
                        // SQL is already complete and a later scheduled discovery will retry the rename.
                        // Continue so one Blob post-processing failure does not block unrelated files.
                        _logger.LogError(
                            exception,
                            "Failed to rename completed HX source Blob {BlobContainer}/{BlobPath}",
                            registeredSource.BlobContainer,
                            registeredSource.BlobPath);
                        continue;
                    }
                }
            }

            for (var processedFileCount = 0; processedFileCount < _options.MaximumFilesPerRun; processedFileCount++)
            {
                var claimedSource = await _fileDataService.ClaimNextAsync(
                    leaseOwner,
                    _options.LeaseDurationSeconds,
                    _options.MaximumRetryCount,
                    cancellationToken: cancellationToken);

                if (claimedSource?.ClaimToken is null)
                {
                    return;
                }

                try
                {
                    await ProcessWithLeaseRenewalAsync(claimedSource, cancellationToken);
                }
                catch (Exception exception) when (exception is not OperationCanceledException)
                {
                    // The failure is recorded against the claimed SQL work item by ProcessAsync.
                    // Continue so one failed file does not prevent unrelated eligible work.
                    LogProcessingFailure(exception, claimedSource);
                    continue;
                }

                try
                {
                    await _blobSource.RenameAsProcessedAsync(
                        claimedSource.BlobContainer,
                        claimedSource.BlobPath,
                        claimedSource.ContentLength,
                        RequiredETag(claimedSource),
                        cancellationToken);
                }
                catch (Exception exception) when (exception is not OperationCanceledException)
                {
                    // SQL is already complete and the next scheduled discovery will retry the rename.
                    // Continue so one Blob post-processing failure does not block unrelated files.
                    _logger.LogError(
                        exception,
                        "Failed to rename processed HX source Blob {BlobContainer}/{BlobPath} for source item {SourceItemId}",
                        claimedSource.BlobContainer,
                        claimedSource.BlobPath,
                        claimedSource.Id);
                    continue;
                }
            }
        }

        private async Task ProcessWithLeaseRenewalAsync(ConsolidatedSalesSourceItem claimedSource, CancellationToken cancellationToken)
        {
            using var processingCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            var processingTask = ProcessAsync(claimedSource, processingCancellation.Token);
            var renewalTask = RenewLeaseUntilCancelledAsync(claimedSource, processingCancellation.Token);
            var renewalCompletedFirst = false;

            try
            {
                var firstCompletedTask = await Task.WhenAny(processingTask, renewalTask);
                if (firstCompletedTask == renewalTask)
                {
                    renewalCompletedFirst = true;
                    await renewalTask;
                }

                await processingTask;
            }
            finally
            {
                await processingCancellation.CancelAsync();

                try
                {
                    await renewalTask;
                }
                catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                {
                    // Expected after source-file processing has completed or a lease renewal has failed.
                }
                catch when (renewalCompletedFirst)
                {
                    // The renewal failure was already observed above and must remain the primary exception.
                }

                if (!processingTask.IsCompleted)
                {
                    try
                    {
                        await processingTask;
                    }
                    catch (OperationCanceledException) when (processingCancellation.IsCancellationRequested)
                    {
                        // Processing must stop when its lease can no longer be renewed.
                    }
                }
            }
        }

        private async Task RenewLeaseUntilCancelledAsync(ConsolidatedSalesSourceItem claimedSource, CancellationToken cancellationToken)
        {
            var claimToken = claimedSource.ClaimToken ?? throw new InvalidOperationException("The claimed source item must have a claim token");
            var renewalInterval = TimeSpan.FromSeconds(_options.LeaseRenewalIntervalSeconds);

            while (true)
            {
                await Task.Delay(renewalInterval, cancellationToken);
                await _fileDataService.RenewLeaseAsync(
                    claimedSource.Id,
                    claimToken,
                    _options.LeaseDurationSeconds,
                    cancellationToken: cancellationToken);
            }
        }

        private async Task ProcessAsync(ConsolidatedSalesSourceItem claimedSource, CancellationToken cancellationToken)
        {
            var claimToken = claimedSource.ClaimToken ?? throw new InvalidOperationException("The claimed source item must have a claim token");
            if (claimedSource.ContentLength == 0)
            {
                _logger.LogInformation("Skipping empty HX source item {SourceItemId}; Mule parity requires it to be collected without parsing or Salesforce work", claimedSource.Id);

                await _fileDataService.CompleteAsync(
                    claimedSource.Id,
                    claimToken,
                    false,
                    cancellationToken: cancellationToken);
                return;
            }

            var salesforceCooloffHours = _columbusOptions.EnableSalesforceCooloff ? _columbusOptions.SalesforceCooloffHours : 0;
            var parseMetadata = new HxInvoiceParseMetadata();

            try
            {
                await using var source = await _blobSource.OpenReadAsync(
                    claimedSource.BlobContainer,
                    claimedSource.BlobPath,
                    RequiredETag(claimedSource),
                    cancellationToken);

                if (!source.CanRead)
                {
                    throw new IOException("The HX source stream is not readable");
                }

                await using var rewindableSource = CreateTemporaryStream();
                await source.CopyToAsync(rewindableSource, cancellationToken);

                if (rewindableSource.Length != claimedSource.ContentLength)
                {
                    throw new IOException($"The HX source read returned {rewindableSource.Length} bytes; {claimedSource.ContentLength} bytes were expected");
                }

                var salesforceCooloffStartedOn = await _fileDataService.RecordFirstReadAsync(
                    claimedSource.Id,
                    claimToken,
                    cancellationToken: cancellationToken);
                var salesforceEligibleOn = salesforceCooloffStartedOn.AddHours(salesforceCooloffHours);

                _logger.LogInformation(
                    "HX source item {SourceItemId} was first read by Trade Account at {SalesforceCooloffStartedOn}; Salesforce cool-off enabled {EnableSalesforceCooloff}, configured hours {ConfiguredSalesforceCooloffHours}, effective hours {EffectiveSalesforceCooloffHours}, eligible at {SalesforceEligibleOn}",
                    claimedSource.Id,
                    salesforceCooloffStartedOn,
                    _columbusOptions.EnableSalesforceCooloff,
                    _columbusOptions.SalesforceCooloffHours,
                    salesforceCooloffHours,
                    salesforceEligibleOn);

                rewindableSource.Position = 0;
                await foreach (var hxInvoice in _parser.ParseAsync(rewindableSource, parseMetadata, cancellationToken))
                {
                    _mapper.Map(hxInvoice, claimedSource.CorrelationId);
                }

                rewindableSource.Position = 0;

                var commitParseMetadata = new HxInvoiceParseMetadata();

                await foreach (var hxInvoice in _parser.ParseAsync(rewindableSource, commitParseMetadata, cancellationToken))
                {
                    var invoice = _mapper.Map(hxInvoice, claimedSource.CorrelationId);
                    await _invoiceDataService.CommitAsync(
                        claimedSource.Id,
                        claimToken,
                        invoice,
                        salesforceCooloffStartedOn,
                        salesforceCooloffHours,
                        salesforceEligibleOn,
                        cancellationToken: cancellationToken);
                }

                parseMetadata.SanitisationUsed |= commitParseMetadata.SanitisationUsed;

                await _fileDataService.CompleteAsync(
                    claimedSource.Id,
                    claimToken,
                    parseMetadata.SanitisationUsed,
                    cancellationToken: cancellationToken);
            }
            catch (HxInvoiceParseException exception)
            {
                await _fileDataService.AwaitCorrectionAsync(
                    claimedSource.Id,
                    claimToken,
                    exception.Category.ToString(),
                    TruncateErrorMessage(exception.Message),
                    cancellationToken: cancellationToken);

                throw;
            }
            catch (InvalidDataException exception)
            {
                await _fileDataService.AwaitCorrectionAsync(
                    claimedSource.Id,
                    claimToken,
                    "InvalidValue",
                    TruncateErrorMessage(exception.Message),
                    cancellationToken: cancellationToken);

                throw;
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                var nextAttemptOn = DateTimeOffset.UtcNow.AddSeconds(_options.RetryDelaySeconds);

                await _fileDataService.FailAsync(
                    claimedSource.Id,
                    claimToken,
                    "Unexpected",
                    TruncateErrorMessage(exception.Message),
                    nextAttemptOn,
                    _options.MaximumRetryCount,
                    cancellationToken: cancellationToken);

                throw;
            }
        }

        private void ValidateOptions()
        {
            if (_options.LeaseDurationSeconds <= 0)
            {
                throw new InvalidOperationException("The consolidated sales lease duration must be greater than zero.");
            }

            if (_options.LeaseRenewalIntervalSeconds <= 0)
            {
                throw new InvalidOperationException("The consolidated sales lease renewal interval must be greater than zero");
            }

            if (_options.LeaseRenewalIntervalSeconds >= _options.LeaseDurationSeconds)
            {
                throw new InvalidOperationException("The consolidated sales lease renewal interval must be shorter than the lease duration");
            }

            if (_options.MaximumFilesPerRun <= 0)
            {
                throw new InvalidOperationException("The consolidated sales maximum files per run must be greater than zero");
            }

            if (_options.RetryDelaySeconds <= 0)
            {
                throw new InvalidOperationException("The consolidated sales retry delay must be greater than zero");
            }

            if (_options.MaximumRetryCount <= 0)
            {
                throw new InvalidOperationException("The consolidated sales maximum retry count must be greater than zero.");
            }

            if (_columbusOptions.SalesforceCooloffHours < 0 || (_columbusOptions.EnableSalesforceCooloff && _columbusOptions.SalesforceCooloffHours <= 0))
            {
                throw new InvalidOperationException("Salesforce cool-off hours must be greater than zero when enabled, and cannot be negative");
            }
        }

        private void LogProcessingFailure(Exception exception, ConsolidatedSalesSourceItem claimedSource)
        {
            var correctionCategory = exception switch
            {
                HxInvoiceParseException parseException => parseException.Category.ToString(),
                InvalidDataException => "InvalidValue",
                _ => null
            };

            if (correctionCategory is not null)
            {
                _logger.LogError(
                    exception,
                    "HX source item {SourceItemId} and Blob {BlobContainer}/{BlobPath} requires correction for category {ErrorCategory}",
                    claimedSource.Id,
                    claimedSource.BlobContainer,
                    claimedSource.BlobPath,
                    correctionCategory);
                return;
            }

            _logger.LogError(
                exception,
                "HX source processing failed for source item {SourceItemId} and Blob {BlobContainer}/{BlobPath}",
                claimedSource.Id,
                claimedSource.BlobContainer,
                claimedSource.BlobPath);
        }

        private static string TruncateErrorMessage(string errorMessage)
        {
            return errorMessage.Length <= MaximumErrorMessageLength
                ? errorMessage
                : errorMessage[..MaximumErrorMessageLength];
        }

        private static string RequiredETag(ConsolidatedSalesSourceItem source)
        {
            return !string.IsNullOrWhiteSpace(source.ETag)
                ? source.ETag
                : throw new InvalidOperationException($"Consolidated Sales source {source.Id} does not contain a Blob ETag");
        }

        private static FileStream CreateTemporaryStream() => new(
            Path.Combine(Path.GetTempPath(), $"hx-consolidated-sales-ingestion-{Guid.NewGuid():N}.xml"),
            FileMode.CreateNew,
            FileAccess.ReadWrite,
            FileShare.None,
            bufferSize: 64 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan | FileOptions.DeleteOnClose);
    }
}
