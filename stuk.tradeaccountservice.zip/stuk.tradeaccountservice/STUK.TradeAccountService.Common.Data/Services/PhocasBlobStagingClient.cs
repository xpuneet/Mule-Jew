using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Atomically uploads complete action-prefixed files for the existing Phocas Blob trigger
    /// </summary>
    public class PhocasBlobStagingClient : IPhocasBlobStagingClient
    {
        private readonly BlobServiceClient _blobServiceClient;

        /// <summary>
        /// Initialises a new instance of the <see cref="PhocasBlobStagingClient"/>
        /// </summary>
        /// <param name="blobServiceClient">The existing Blob service client</param>
        /// <exception cref="ArgumentNullException">Thrown when the Blob client is not supplied</exception>
        public PhocasBlobStagingClient(BlobServiceClient blobServiceClient)
        {
            _blobServiceClient = blobServiceClient ?? throw new ArgumentNullException(nameof(blobServiceClient));
        }

        /// <inheritdoc />
        public async Task<PhocasBlobStageResult> StageAsync(PhocasBlobStageRequest request, Stream content, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(request);
            ArgumentNullException.ThrowIfNull(content);
            ValidateRequest(request, content);
            cancellationToken.ThrowIfCancellationRequested();

            var (containerName, prefix) = ParseStagingPath(request.BlobStagingPath);
            var blobName = string.IsNullOrEmpty(prefix)
                ? request.BlobName
                : $"{prefix}/{request.BlobName}";
            var blobClient = _blobServiceClient
                .GetBlobContainerClient(containerName)
                .GetBlobClient(blobName);

            var existing = await TryGetPropertiesAsync(blobClient, cancellationToken);
            if (existing is not null)
            {
                return GetMatchingExistingResult(request, containerName, blobName, existing);
            }

            content.Position = 0;
            var metadata = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                ["CorrelationID"] = request.CorrelationId.ToString("D", CultureInfo.InvariantCulture),
                ["RetryCount"] = request.RetryCount.ToString(CultureInfo.InvariantCulture),
                ["ExportRunID"] = request.ExportRunId.ToString("D", CultureInfo.InvariantCulture),
                ["ExportDestinationID"] = request.ExportDestinationId.ToString("D", CultureInfo.InvariantCulture),
                ["ContentHash"] = request.ContentHash,
                ["RowCount"] = request.RowCount.ToString(CultureInfo.InvariantCulture)
            };

            try
            {
                var upload = await blobClient.UploadAsync(
                    content,
                    new BlobUploadOptions
                    {
                        Conditions = new BlobRequestConditions { IfNoneMatch = ETag.All },
                        HttpHeaders = new BlobHttpHeaders { ContentType = "text/plain; charset=utf-8" },
                        Metadata = metadata
                    },
                    cancellationToken);

                return new PhocasBlobStageResult
                {
                    BlobPath = $"{containerName}/{blobName}",
                    ETag = upload.Value.ETag.ToString(),
                    AlreadyStaged = false
                };
            }
            catch (RequestFailedException exception) when (exception.Status is 409 or 412)
            {
                existing = await TryGetPropertiesAsync(blobClient, cancellationToken);
                if (existing is not null)
                {
                    return GetMatchingExistingResult(request, containerName, blobName, existing);
                }

                throw;
            }
        }

        private static async Task<BlobProperties?> TryGetPropertiesAsync(
            BlobClient blobClient,
            CancellationToken cancellationToken)
        {
            try
            {
                return (await blobClient.GetPropertiesAsync(cancellationToken: cancellationToken)).Value;
            }
            catch (RequestFailedException exception) when (exception.Status == 404)
            {
                return null;
            }
        }

        private static PhocasBlobStageResult GetMatchingExistingResult(
            PhocasBlobStageRequest request,
            string containerName,
            string blobName,
            BlobProperties properties)
        {
            var matchesRun = properties.Metadata.TryGetValue("ExportRunID", out var exportRunId)
                && string.Equals(exportRunId, request.ExportRunId.ToString("D", CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
            var matchesDestination = properties.Metadata.TryGetValue("ExportDestinationID", out var exportDestinationId)
                && string.Equals(exportDestinationId, request.ExportDestinationId.ToString("D", CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
            var matchesHash = properties.Metadata.TryGetValue("ContentHash", out var contentHash)
                && string.Equals(contentHash, request.ContentHash, StringComparison.OrdinalIgnoreCase);

            if (!matchesRun || !matchesDestination || !matchesHash || properties.ContentLength != request.ContentLength)
            {
                throw new InvalidDataException($"The watched Phocas Blob '{containerName}/{blobName}' is occupied by different export content.");
            }

            return new PhocasBlobStageResult
            {
                BlobPath = $"{containerName}/{blobName}",
                ETag = properties.ETag.ToString(),
                AlreadyStaged = true
            };
        }

        private static (string ContainerName, string Prefix) ParseStagingPath(string stagingPath)
        {
            var normalised = stagingPath.Trim().Trim('/');
            var separatorIndex = normalised.IndexOf('/');
            return separatorIndex < 0
                ? (normalised, string.Empty)
                : (normalised[..separatorIndex], normalised[(separatorIndex + 1)..].Trim('/'));
        }

        private static void ValidateRequest(PhocasBlobStageRequest request, Stream content)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(request.BlobStagingPath);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.BlobName);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.ContentHash);

            if (request.ContentLength < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(request), "The staged content length cannot be negative.");
            }

            if (request.RowCount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(request), "The staged row count cannot be negative.");
            }

            if (request.ExportRunId == Guid.Empty || request.ExportDestinationId == Guid.Empty || request.CorrelationId == Guid.Empty)
            {
                throw new ArgumentException("The export, destination and correlation identifiers are required.", nameof(request));
            }

            if (request.RetryCount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(request), "The retry count cannot be negative.");
            }

            if (!content.CanRead || !content.CanSeek)
            {
                throw new ArgumentException("The staged content stream must be readable and seekable.", nameof(content));
            }

            if (content.Length != request.ContentLength)
            {
                throw new InvalidDataException("The generated stream length does not match its content evidence.");
            }
        }
    }
}
