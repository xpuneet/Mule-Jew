using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides stored-procedure access to existing-invoice reconciliation work
    /// </summary>
    public class InvoiceReconciliationDataService : IInvoiceReconciliationDataService
    {
        private readonly IDbExecutor _accountDbExecutor;
        private readonly IDbExecutor _orderDbExecutor;

        /// <summary>
        /// Initialises a new instance of the <see cref="InvoiceReconciliationDataService"/>
        /// </summary>
        /// <param name="accountDbExecutor">The keyed Trade Account database executor used for durable reconciliation work</param>
        /// <param name="orderDbExecutor">The keyed Order database executor used for existing invoice headers</param>
        /// <exception cref="ArgumentNullException"></exception>
        public InvoiceReconciliationDataService([FromKeyedServices("AccountDb")] IDbExecutor accountDbExecutor, [FromKeyedServices("OrderDb")] IDbExecutor orderDbExecutor)
        {
            _accountDbExecutor = accountDbExecutor ?? throw new ArgumentNullException(nameof(accountDbExecutor));
            _orderDbExecutor = orderDbExecutor ?? throw new ArgumentNullException(nameof(orderDbExecutor));
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesReconciliationWork?> ClaimNextAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _accountDbExecutor.ExecuteSingleAsync<ConsolidatedSalesReconciliationWork>(StoredProcedures.ClaimNextConsolidatedSalesReconciliationWork, new { leaseOwner, leaseDurationSeconds, maximumRetryCount, now });
        }

        /// <inheritdoc />
        public async Task<InvoiceReconciliationMatchResult> MatchAndUpdateInvoiceAsync(string standardInvoiceNumber, string branchCode, string consolidatedInvoiceNumber, DateOnly? consolidatedInvoiceDate, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _orderDbExecutor.ExecuteSingleAsync<InvoiceReconciliationMatchResult>(StoredProcedures.ReconcileInvoiceHeaderConsolidatedSales, new { standardInvoiceNumber, branchCode, consolidatedInvoiceNumber, consolidatedInvoiceDate })
                ?? throw new InvalidOperationException("The invoice reconciliation did not return a result");
        }

        /// <inheritdoc />
        public async Task CompleteAsync(Guid reconciliationWorkId, Guid claimToken, Guid matchedInvoiceHeaderId, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _accountDbExecutor.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesReconciliationWork, new { reconciliationWorkId, claimToken, matchedInvoiceHeaderId, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesWorkFailureResult> DeferAsync(Guid reconciliationWorkId, Guid claimToken, DateTimeOffset nextAttemptOn, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _accountDbExecutor.ExecuteSingleAsync<ConsolidatedSalesWorkFailureResult>(StoredProcedures.DeferConsolidatedSalesReconciliationWork, new { reconciliationWorkId, claimToken, nextAttemptOn, reason, now })
                ?? throw new InvalidOperationException("The reconciliation deferral did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesWorkFailureResult> FailAsync(Guid reconciliationWorkId, Guid claimToken, string errorCategory, string errorMessage, DateTimeOffset? nextAttemptOn, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _accountDbExecutor.ExecuteSingleAsync<ConsolidatedSalesWorkFailureResult>(StoredProcedures.FailConsolidatedSalesReconciliationWork, new { reconciliationWorkId, claimToken, errorCategory, errorMessage, nextAttemptOn, maximumRetryCount, now })
                ?? throw new InvalidOperationException("The reconciliation failure did not return a result");
        }

        /// <inheritdoc />
        public async Task RequeueAsync(Guid reconciliationWorkId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _accountDbExecutor.ExecuteAsync(StoredProcedures.RequeueConsolidatedSalesWork, new { workType = "Reconciliation", workId = reconciliationWorkId, reason, now });
        }
    }
}
