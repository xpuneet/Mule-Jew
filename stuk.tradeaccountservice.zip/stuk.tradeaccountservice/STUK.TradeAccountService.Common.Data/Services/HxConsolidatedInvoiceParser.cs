using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Xml;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Streams and maps invoices from an HX consolidated invoice document
    /// </summary>
    public class HxConsolidatedInvoiceParser : IHxConsolidatedInvoiceParser
    {
        private static readonly XNamespace KmsgNamespace = "http://xml.kerridge.net/k8msg";
        private static readonly XNamespace BasdaNamespace = "urn:schemas-basda-org:2000:salesInvoice:xdr:3.01";

        /// <inheritdoc />
        public IAsyncEnumerable<HxInvoiceDto> ParseAsync(Stream source, CancellationToken cancellationToken = default)
        {
            return ParseAsync(source, new HxInvoiceParseMetadata(), cancellationToken);
        }

        /// <inheritdoc />
        public async IAsyncEnumerable<HxInvoiceDto> ParseAsync(
            Stream source,
            HxInvoiceParseMetadata metadata,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(source);
            ArgumentNullException.ThrowIfNull(metadata);

            if (!source.CanRead)
            {
                throw new ArgumentException("The HX source stream must be readable.", nameof(source));
            }

            await using var rewindableSource = await RewindableSource.CreateAsync(source, cancellationToken);
            var parsingStream = await PrepareParsingStreamAsync(rewindableSource, cancellationToken);
            metadata.SanitisationUsed = parsingStream != rewindableSource.Stream;

            await using var sanitisedStream = parsingStream == rewindableSource.Stream
                ? null
                : parsingStream;

            parsingStream.Position = 0;

            using var reader = XmlReader.Create(parsingStream, CreateReaderSettings());
            var state = new InvoiceReaderState();
            while (true)
            {
                XElement? invoiceElement;
                try
                {
                    invoiceElement = await ReadNextInvoiceAsync(reader, state, cancellationToken);
                }
                catch (XmlException exception)
                {
                    throw MalformedXmlException(exception, sanitisationAttempted: sanitisedStream is not null);
                }

                if (invoiceElement is null)
                {
                    break;
                }

                state.InvoiceFound = true;
                yield return ParseInvoice(invoiceElement);
            }

            if (!state.BodyFound)
            {
                throw new HxInvoiceParseException(HxInvoiceParseErrorCategory.UnsupportedDocument, "The HX document does not contain the expected kmsg body element.", "/kmsg/body");
            }

            if (!state.InvoiceFound)
            {
                throw new HxInvoiceParseException(HxInvoiceParseErrorCategory.UnsupportedDocument, "The HX document does not contain an invoice in the supported BASDA namespace.", "/kmsg/body/Invoice");
            }
        }

        private static async Task<XElement?> ReadNextInvoiceAsync(XmlReader reader, InvoiceReaderState state, CancellationToken cancellationToken)
        {
            if (reader.ReadState == ReadState.Initial && !await reader.ReadAsync())
            {
                return null;
            }

            while (!reader.EOF)
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (!state.BodyFound && IsElement(reader, KmsgNamespace, "body"))
                {
                    state.BodyFound = true;
                }

                if (state.BodyFound && IsElement(reader, BasdaNamespace, "Invoice"))
                {
                    return (XElement)await XNode.ReadFromAsync(reader, cancellationToken);
                }

                if (!await reader.ReadAsync())
                {
                    return null;
                }
            }

            return null;
        }

        private static async Task<Stream> PrepareParsingStreamAsync(RewindableSource source, CancellationToken cancellationToken)
        {
            try
            {
                await ValidateXmlAsync(source.Stream, cancellationToken);
                source.Stream.Position = 0;
                return source.Stream;
            }
            catch (XmlException)
            {
                source.Stream.Position = 0;
                var sanitisedStream = CreateTemporaryStream();

                try
                {
                    await HxXmlSanitiser.SanitiseAsync(source.Stream, sanitisedStream, cancellationToken);
                    sanitisedStream.Position = 0;
                    await ValidateXmlAsync(sanitisedStream, cancellationToken);
                    sanitisedStream.Position = 0;
                    return sanitisedStream;
                }
                catch (XmlException exception)
                {
                    await sanitisedStream.DisposeAsync();
                    throw MalformedXmlException(exception, sanitisationAttempted: true);
                }
                catch
                {
                    await sanitisedStream.DisposeAsync();
                    throw;
                }
            }
        }

        private static async Task ValidateXmlAsync(Stream source, CancellationToken cancellationToken)
        {
            using var reader = XmlReader.Create(source, CreateReaderSettings());
            while (await reader.ReadAsync())
            {
                cancellationToken.ThrowIfCancellationRequested();
            }
        }

        private static XmlReaderSettings CreateReaderSettings() => new()
        {
            Async = true,
            CheckCharacters = true,
            CloseInput = false,
            DtdProcessing = DtdProcessing.Prohibit,
            IgnoreComments = true,
            IgnoreProcessingInstructions = true,
            XmlResolver = null
        };

        private static HxInvoiceDto ParseInvoice(XElement invoiceElement)
        {
            var references = invoiceElement.Element(BasdaNamespace + "InvoiceReferences");
            var invoiceNumber = ValueOrNull(references?.Element(BasdaNamespace + "SuppliersInvoiceNumber"));

            try
            {
                return new HxInvoiceDto
                {
                    Header = ParseHeader(invoiceElement.Element(BasdaNamespace + "InvoiceHead")),
                    References = new HxInvoiceReferencesDto
                    {
                        BuyersOrderNumber = ValueOrNull(references?.Element(BasdaNamespace + "BuyersOrderNumber")),
                        SuppliersInvoiceNumber = invoiceNumber,
                        DeliveryNoteNumber = ValueOrNull(references?.Element(BasdaNamespace + "DeliveryNoteNumber")),
                        SuppliersOrderReference = ValueOrNull(references?.Element(BasdaNamespace + "SuppliersOrderReference"))
                    },
                    Consolidated = ParseConsolidatedHeader(invoiceElement),
                    InvoiceDate = ParseDate(invoiceElement.Element(BasdaNamespace + "InvoiceDate"), "/Invoice/InvoiceDate", invoiceNumber),
                    TaxPointDate = ParseDate(invoiceElement.Element(BasdaNamespace + "TaxPointDate"), "/Invoice/TaxPointDate", invoiceNumber),
                    Supplier = ParseParty(invoiceElement.Element(BasdaNamespace + "Supplier"), "SupplierReferences", "BuyersCodeForSupplier"),
                    Buyer = ParseParty(invoiceElement.Element(BasdaNamespace + "Buyer"), "BuyerReferences", "SuppliersCodeForBuyer"),
                    InvoiceTo = ParseParty(invoiceElement.Element(BasdaNamespace + "InvoiceTo"), "InvoiceToReferences", "SuppliersCodeForInvoiceTo"),
                    Lines = [.. invoiceElement.Elements(BasdaNamespace + "InvoiceLine").Select(line => ParseLine(line, invoiceNumber))],
                    TaxSubTotals = [.. invoiceElement.Elements(BasdaNamespace + "TaxSubTotal").Select(tax => ParseTaxSubTotal(tax, invoiceNumber))],
                    Totals = ParseTotals(invoiceElement.Element(BasdaNamespace + "InvoiceTotal"), invoiceNumber)
                };
            }
            catch (HxInvoiceParseException)
            {
                throw;
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                throw new HxInvoiceParseException(
                    HxInvoiceParseErrorCategory.InvalidValue,
                    "The HX invoice contains a value that could not be parsed.",
                    invoiceNumber: invoiceNumber,
                    innerException: exception);
            }
        }

        private static HxInvoiceHeaderDto ParseHeader(XElement? header)
        {
            var invoiceCurrency = header?.Element(BasdaNamespace + "InvoiceCurrency");
            return new HxInvoiceHeaderDto
            {
                InvoiceType = ParseCodedValue(header?.Element(BasdaNamespace + "InvoiceType")),
                Currency = ParseCodedValue(invoiceCurrency?.Element(BasdaNamespace + "Currency"))
            };
        }

        private static HxConsolidatedHeaderDto? ParseConsolidatedHeader(XElement invoice)
        {
            var consolidated = invoice.Element(BasdaNamespace + "Extensions")?.Element(KmsgNamespace + "Consolidated");
            if (consolidated is null)
            {
                return null;
            }

            var documentFlags = consolidated.Element(KmsgNamespace + "SupplierDocumentFlags");
            var contactDetails = consolidated.Element(KmsgNamespace + "SupplierContactDetails");
            var creditDetails = consolidated.Element(KmsgNamespace + "SupplierCreditDetails");

            return new HxConsolidatedHeaderDto
            {
                DocumentBrand = ParseCodedValue(documentFlags?.Element(KmsgNamespace + "DocumentBrand")),
                SupplierBranch = ParseCodedValue(contactDetails?.Element(KmsgNamespace + "Branch")),
                CreditTerms = ParseCodedValue(creditDetails?.Element(KmsgNamespace + "CreditTerms"))
            };
        }

        private static HxPartyDto? ParseParty(XElement? party, string referencesElementName, string accountElementName)
        {
            if (party is null)
            {
                return null;
            }

            return new HxPartyDto
            {
                AccountCode = ValueOrNull(party.Element(BasdaNamespace + referencesElementName)?.Element(BasdaNamespace + accountElementName)),
                Name = ValueOrNull(party.Element(BasdaNamespace + "Party")),
                Address = ParseAddress(party.Element(BasdaNamespace + "Address"), BasdaNamespace)
            };
        }

        private static HxInvoiceLineDto ParseLine(XElement line, string? invoiceNumber)
        {
            var lineNumberElement = line.Element(BasdaNamespace + "LineNumber");
            var lineNumber = ValueOrNull(lineNumberElement);
            var references = line.Element(BasdaNamespace + "InvoiceLineReferences");
            var consolidated = line.Element(BasdaNamespace + "Extensions")?.Element(KmsgNamespace + "HXConsolidatedLine");
            var product = line.Element(BasdaNamespace + "Product");
            var quantity = line.Element(BasdaNamespace + "Quantity");
            var price = line.Element(BasdaNamespace + "Price");
            var percentDiscount = line.Element(BasdaNamespace + "PercentDiscount");
            var tax = line.Element(BasdaNamespace + "LineTax");

            return new HxInvoiceLineDto
            {
                Action = AttributeValue(line, "Action"),
                LineNumber = lineNumber,
                PreserveLineNumber = ParseBoolean(AttributeValue(lineNumberElement, "Preserve"), "/Invoice/InvoiceLine/LineNumber/@Preserve", invoiceNumber, lineNumber),
                References = new HxInvoiceLineReferencesDto
                {
                    OrderLineNumber = ValueOrNull(references?.Element(BasdaNamespace + "OrderLineNumber")),
                    DeliveryNoteNumber = ValueOrNull(references?.Element(BasdaNamespace + "DeliveryNoteNumber")),
                    DeliveryNoteLineNumber = ValueOrNull(references?.Element(BasdaNamespace + "DeliveryNoteLineNumber"))
                },
                Consolidated = ParseConsolidatedLine(consolidated, invoiceNumber, lineNumber),
                Product = product is null ? null : new HxProductDto
                {
                    SuppliersProductCode = ValueOrNull(product.Element(BasdaNamespace + "SuppliersProductCode")),
                    Description = ValueOrNull(product.Element(BasdaNamespace + "Description"))
                },
                Quantity = quantity is null ? null : new HxQuantityDto
                {
                    Amount = ParseDecimal(quantity.Element(BasdaNamespace + "Amount"), "/Invoice/InvoiceLine/Quantity/Amount", invoiceNumber, lineNumber),
                    UomCode = AttributeValue(quantity, "UOMCode"),
                    UomDescription = AttributeValue(quantity, "UOMDescription")
                },
                Price = price is null ? null : new HxPriceDto
                {
                    UnitPrice = ParseDecimal(price.Element(BasdaNamespace + "UnitPrice"), "/Invoice/InvoiceLine/Price/UnitPrice", invoiceNumber, lineNumber),
                    UomCode = AttributeValue(price, "UOMCode"),
                    UomDescription = AttributeValue(price, "UOMDescription")
                },
                PercentageDiscount = ParseDecimal(percentDiscount?.Element(BasdaNamespace + "Percentage"), "/Invoice/InvoiceLine/PercentDiscount/Percentage", invoiceNumber, lineNumber),
                Tax = ParseTax(tax, invoiceNumber, lineNumber),
                LineTotal = ParseDecimal(line.Element(BasdaNamespace + "LineTotal"), "/Invoice/InvoiceLine/LineTotal", invoiceNumber, lineNumber)
            };
        }

        private static HxConsolidatedLineDto? ParseConsolidatedLine(
            XElement? consolidated,
            string? invoiceNumber,
            string? lineNumber)
        {
            if (consolidated is null)
            {
                return null;
            }

            var orderFlags = consolidated.Element(KmsgNamespace + "SupplierOrderFlags");
            var customer = consolidated.Element(KmsgNamespace + "CustomerInformation");

            return new HxConsolidatedLineDto
            {
                DocumentTextLine = ParseBoolean(ValueOrNull(consolidated.Element(KmsgNamespace + "DocumentTextLine")), "/Invoice/InvoiceLine/Extensions/HXConsolidatedLine/DocumentTextLine", invoiceNumber, lineNumber),
                OriginalOrderLineNumber = ValueOrNull(consolidated.Element(KmsgNamespace + "OriginalOrderLineNumber")),
                SupplierPartAnalysisCode = ValueOrNull(consolidated.Element(KmsgNamespace + "SupplierPartAnalysisCode")),
                SpecialProduct = ParseBoolean(ValueOrNull(consolidated.Element(KmsgNamespace + "SpecialProduct")), "/Invoice/InvoiceLine/Extensions/HXConsolidatedLine/SpecialProduct", invoiceNumber, lineNumber),
                BuyersOrderNumber = ValueOrNull(consolidated.Element(KmsgNamespace + "BuyersOrderNumber")),
                SuppliersOrderReference = ValueOrNull(consolidated.Element(KmsgNamespace + "SuppliersOrderReference")),
                SupplierDespatchDate = ParseDate(consolidated.Element(KmsgNamespace + "SupplierDespatchDate"), "/Invoice/InvoiceLine/Extensions/HXConsolidatedLine/SupplierDespatchDate", invoiceNumber, lineNumber),
                SupplierCodeForDelivery = ValueOrNull(consolidated.Element(KmsgNamespace + "SupplierCodeForDelivery")),
                SupplierOrderFlags = orderFlags is null ? null : new HxSupplierOrderFlagsDto
                {
                    OrderType = ParseCodedValue(orderFlags.Element(KmsgNamespace + "OrderType")),
                    OrderCategory = ParseCodedValue(orderFlags.Element(KmsgNamespace + "OrderCategory")),
                    DeliveryMethod = ParseCodedValue(orderFlags.Element(KmsgNamespace + "DeliveryMethod"))
                },
                CustomerInformation = ParseCustomerInformation(customer)
            };
        }

        private static HxCustomerInformationDto? ParseCustomerInformation(XElement? customer)
        {
            if (customer is null)
            {
                return null;
            }

            return new HxCustomerInformationDto
            {
                JobNumber = ValueOrNull(customer.Element(KmsgNamespace + "JobNumber")),
                JobAddress = ParseAddress(customer.Element(KmsgNamespace + "JobAddress"), KmsgNamespace),
                ContractNumber = ValueOrNull(customer.Element(KmsgNamespace + "ContractNumber")),
                BuyerLocation = ValueOrNull(customer.Element(KmsgNamespace + "BuyerLocation")),
                Operative = ValueOrNull(customer.Element(KmsgNamespace + "Operative")),
                SiteCode = ValueOrNull(customer.Element(KmsgNamespace + "SiteCode")),
                PlotNumber = ValueOrNull(customer.Element(KmsgNamespace + "PlotNumber")),
                VehicleRegistration = ValueOrNull(customer.Element(KmsgNamespace + "VehicleRegistration")),
                HouseType = ValueOrNull(customer.Element(KmsgNamespace + "HouseType")),
                ProductGroup = ValueOrNull(customer.Element(KmsgNamespace + "ProductGroup")),
                OrderAuthorised = ValueOrNull(customer.Element(KmsgNamespace + "OrderAuthorised"))
            };
        }

        private static HxAddressDto? ParseAddress(XElement? address, XNamespace xmlNamespace)
        {
            if (address is null)
            {
                return null;
            }

            return new HxAddressDto
            {
                AddressLines = [.. address.Elements(xmlNamespace + "AddressLine")
                    .Select(ValueOrNull)
                    .Where(value => value is not null)
                    .Cast<string>()],
                Street = ValueOrNull(address.Element(xmlNamespace + "Street")),
                City = ValueOrNull(address.Element(xmlNamespace + "City")),
                State = ValueOrNull(address.Element(xmlNamespace + "State")),
                PostCode = ValueOrNull(address.Element(xmlNamespace + "PostCode"))
            };
        }

        private static HxTaxDto? ParseTax(XElement? tax, string? invoiceNumber, string? lineNumber)
        {
            if (tax is null)
            {
                return null;
            }

            var taxRate = tax.Element(BasdaNamespace + "TaxRate");
            return new HxTaxDto
            {
                TaxRate = taxRate is null ? null : new HxCodedDecimalDto
                {
                    Code = AttributeValue(taxRate, "Code"),
                    Value = ParseDecimal(taxRate, "/Invoice/InvoiceLine/LineTax/TaxRate", invoiceNumber, lineNumber)
                },
                TaxValue = ParseDecimal(tax.Element(BasdaNamespace + "TaxValue"), "/Invoice/InvoiceLine/LineTax/TaxValue", invoiceNumber, lineNumber)
            };
        }

        private static HxTaxSubTotalDto ParseTaxSubTotal(XElement tax, string? invoiceNumber)
        {
            var taxRate = tax.Element(BasdaNamespace + "TaxRate");
            return new HxTaxSubTotalDto
            {
                TaxRate = taxRate is null ? null : new HxCodedDecimalDto
                {
                    Code = AttributeValue(taxRate, "Code"),
                    Value = ParseDecimal(taxRate, "/Invoice/TaxSubTotal/TaxRate", invoiceNumber)
                },
                NumberOfLinesAtRate = ParseInt(tax.Element(BasdaNamespace + "NumberOfLinesAtRate"), "/Invoice/TaxSubTotal/NumberOfLinesAtRate", invoiceNumber),
                TotalValueAtRate = ParseDecimal(tax.Element(BasdaNamespace + "TotalValueAtRate"), "/Invoice/TaxSubTotal/TotalValueAtRate", invoiceNumber),
                TaxableValueAtRate = ParseDecimal(tax.Element(BasdaNamespace + "TaxableValueAtRate"), "/Invoice/TaxSubTotal/TaxableValueAtRate", invoiceNumber),
                TaxAtRate = ParseDecimal(tax.Element(BasdaNamespace + "TaxAtRate"), "/Invoice/TaxSubTotal/TaxAtRate", invoiceNumber),
                NetPaymentAtRate = ParseDecimal(tax.Element(BasdaNamespace + "NetPaymentAtRate"), "/Invoice/TaxSubTotal/NetPaymentAtRate", invoiceNumber),
                GrossPaymentAtRate = ParseDecimal(tax.Element(BasdaNamespace + "GrossPaymentAtRate"), "/Invoice/TaxSubTotal/GrossPaymentAtRate", invoiceNumber)
            };
        }

        private static HxInvoiceTotalsDto? ParseTotals(XElement? totals, string? invoiceNumber)
        {
            if (totals is null)
            {
                return null;
            }

            return new HxInvoiceTotalsDto
            {
                NumberOfLines = ParseInt(totals.Element(BasdaNamespace + "NumberOfLines"), "/Invoice/InvoiceTotal/NumberOfLines", invoiceNumber),
                NumberOfTaxRates = ParseInt(totals.Element(BasdaNamespace + "NumberOfTaxRates"), "/Invoice/InvoiceTotal/NumberOfTaxRates", invoiceNumber),
                LineValueTotal = ParseDecimal(totals.Element(BasdaNamespace + "LineValueTotal"), "/Invoice/InvoiceTotal/LineValueTotal", invoiceNumber),
                TaxableTotal = ParseDecimal(totals.Element(BasdaNamespace + "TaxableTotal"), "/Invoice/InvoiceTotal/TaxableTotal", invoiceNumber),
                TaxTotal = ParseDecimal(totals.Element(BasdaNamespace + "TaxTotal"), "/Invoice/InvoiceTotal/TaxTotal", invoiceNumber),
                NetPaymentTotal = ParseDecimal(totals.Element(BasdaNamespace + "NetPaymentTotal"), "/Invoice/InvoiceTotal/NetPaymentTotal", invoiceNumber),
                GrossPaymentTotal = ParseDecimal(totals.Element(BasdaNamespace + "GrossPaymentTotal"), "/Invoice/InvoiceTotal/GrossPaymentTotal", invoiceNumber)
            };
        }

        private static HxCodedValueDto? ParseCodedValue(XElement? element)
        {
            if (element is null)
            {
                return null;
            }

            return new HxCodedValueDto
            {
                Code = AttributeValue(element, "Code"),
                Description = ValueOrNull(element)
            };
        }

        private static DateOnly? ParseDate(
            XElement? element,
            string path,
            string? invoiceNumber,
            string? lineNumber = null)
        {
            var value = ValueOrNull(element);
            if (value is null)
            {
                return null;
            }

            if (DateOnly.TryParseExact(value.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var date))
            {
                return date;
            }

            throw InvalidValue(path, value, invoiceNumber, lineNumber);
        }

        private static decimal? ParseDecimal(
            XElement? element,
            string path,
            string? invoiceNumber,
            string? lineNumber = null)
        {
            var value = ValueOrNull(element);
            if (value is null)
            {
                return null;
            }

            if (decimal.TryParse(value.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var number))
            {
                return number;
            }

            throw InvalidValue(path, value, invoiceNumber, lineNumber);
        }

        private static int? ParseInt(XElement? element, string path, string? invoiceNumber)
        {
            var value = ValueOrNull(element);
            if (value is null)
            {
                return null;
            }

            if (int.TryParse(value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var number))
            {
                return number;
            }

            throw InvalidValue(path, value, invoiceNumber);
        }

        private static bool? ParseBoolean(
            string? value,
            string path,
            string? invoiceNumber,
            string? lineNumber = null)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            if (bool.TryParse(value.Trim(), out var boolean))
            {
                return boolean;
            }

            if (value.Trim() == "1")
            {
                return true;
            }

            if (value.Trim() == "0")
            {
                return false;
            }

            throw InvalidValue(path, value, invoiceNumber, lineNumber);
        }

        private static HxInvoiceParseException InvalidValue(
            string path,
            string value,
            string? invoiceNumber,
            string? lineNumber = null) => new(
                HxInvoiceParseErrorCategory.InvalidValue,
                $"The HX value at '{path}' is not in the expected format.",
                path,
                invoiceNumber,
                lineNumber);

        private static HxInvoiceParseException MalformedXmlException(XmlException exception, bool sanitisationAttempted)
        {
            return new(
                HxInvoiceParseErrorCategory.MalformedXml,
                "The HX source is not well-formed XML and could not be parsed.",
                sanitisationAttempted: sanitisationAttempted,
                innerException: exception);
        }

        private static string? ValueOrNull(XElement? element) => string.IsNullOrWhiteSpace(element?.Value) ? null : element.Value;

        private static string? AttributeValue(XElement? element, string localName) => element?.Attributes()
            .FirstOrDefault(attribute => attribute.Name.LocalName.Equals(localName, StringComparison.OrdinalIgnoreCase))?
            .Value;

        private static bool IsElement(XmlReader reader, XNamespace xmlNamespace, string localName) =>
            reader.NodeType == XmlNodeType.Element &&
            reader.LocalName == localName &&
            reader.NamespaceURI == xmlNamespace.NamespaceName;

        private static FileStream CreateTemporaryStream() => new(
            Path.Combine(Path.GetTempPath(), $"hx-consolidated-sales-{Guid.NewGuid():N}.xml"),
            FileMode.CreateNew,
            FileAccess.ReadWrite,
            FileShare.None,
            bufferSize: 64 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan | FileOptions.DeleteOnClose);

        private sealed class RewindableSource : IAsyncDisposable
        {
            private readonly bool _ownsStream;

            private RewindableSource(Stream stream, bool ownsStream)
            {
                Stream = stream;
                _ownsStream = ownsStream;
            }

            public Stream Stream { get; }

            public static async Task<RewindableSource> CreateAsync(
                Stream source,
                CancellationToken cancellationToken)
            {
                if (source.CanSeek)
                {
                    source.Position = 0;
                    return new RewindableSource(source, ownsStream: false);
                }

                var temporaryStream = CreateTemporaryStream();
                try
                {
                    await source.CopyToAsync(temporaryStream, cancellationToken);
                    temporaryStream.Position = 0;
                    return new RewindableSource(temporaryStream, ownsStream: true);
                }
                catch
                {
                    await temporaryStream.DisposeAsync();
                    throw;
                }
            }

            public async ValueTask DisposeAsync()
            {
                if (_ownsStream)
                {
                    await Stream.DisposeAsync();
                }
            }
        }

        private sealed class InvoiceReaderState
        {
            public bool BodyFound { get; set; }
            public bool InvoiceFound { get; set; }
        }
    }
}
