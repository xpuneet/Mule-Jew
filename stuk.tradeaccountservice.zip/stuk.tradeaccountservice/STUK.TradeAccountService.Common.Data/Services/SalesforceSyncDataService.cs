using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides stored-procedure access to Salesforce synchronisation work and audit state
    /// </summary>
    public class SalesforceSyncDataService : ISalesforceSyncDataService
    {
        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };

        private readonly IDbExecutor _dbExecutor;

        /// <summary>
        /// Initialises a new instance of the <see cref="SalesforceSyncDataService"/>
        /// </summary>
        /// <param name="dbExecutor">The keyed Trade Account Service database executor</param>
        /// <exception cref="ArgumentNullException"></exception>
        public SalesforceSyncDataService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesforceWork?> ClaimNextAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesforceWork>(StoredProcedures.ClaimNextConsolidatedSalesforceWork, new { leaseOwner, leaseDurationSeconds, maximumRetryCount, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesforceWorkDetails?> GetDetailsAsync(Guid salesforceWorkId, Guid claimToken, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var json = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetConsolidatedSalesforceWorkDetails, new { salesforceWorkId, claimToken });
            return string.IsNullOrWhiteSpace(json) ? null : JsonSerializer.Deserialize<ConsolidatedSalesforceWorkDetails>(json, JsonOptions);
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesLeaseResult> RenewLeaseAsync(Guid salesforceWorkId, Guid claimToken, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(StoredProcedures.RenewConsolidatedSalesforceWorkLease, new { salesforceWorkId, claimToken, leaseDurationSeconds, now }) ?? throw new InvalidOperationException("The Salesforce lease renewal did not return a result");
        }

        /// <inheritdoc />
        public async Task CompleteLineAsync(Guid salesforceWorkId, Guid claimToken, string externalId, string salesforceProductId, string salesforcePricebookEntryId, string salesforceOrderItemId, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _dbExecutor.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesforceLine, new { salesforceWorkId, claimToken, externalId, salesforceProductId, salesforcePricebookEntryId, salesforceOrderItemId, now });
        }

        /// <inheritdoc />
        public async Task FailLineAsync(Guid salesforceWorkId, Guid claimToken, string externalId, string errorMessage, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _dbExecutor.ExecuteAsync(StoredProcedures.FailConsolidatedSalesforceLine, new { salesforceWorkId, claimToken, externalId, errorMessage, now });
        }

        /// <inheritdoc />
        public async Task CompleteWorkAsync(Guid salesforceWorkId, Guid claimToken, string salesforceOrderId, int actualLineCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _dbExecutor.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesforceWork, new { salesforceWorkId, claimToken, salesforceOrderId, actualLineCount, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesWorkFailureResult> FailWorkAsync(Guid salesforceWorkId, Guid claimToken, string errorCategory, string errorMessage, DateTimeOffset? nextAttemptOn, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesWorkFailureResult>(StoredProcedures.FailConsolidatedSalesforceWork, new { salesforceWorkId, claimToken, errorCategory, errorMessage, nextAttemptOn, maximumRetryCount, now })
                ?? throw new InvalidOperationException("The Salesforce failure did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesforceAttemptResult> InsertAttemptAsync(ConsolidatedSalesforceAttempt attempt, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesforceAttemptResult>(StoredProcedures.InsertConsolidatedSalesforceAttempt, attempt)
                ?? throw new InvalidOperationException("The Salesforce attempt did not return a result");
        }

        /// <inheritdoc />
        public async Task RequeueAsync(Guid salesforceWorkId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _dbExecutor.ExecuteAsync(StoredProcedures.RequeueConsolidatedSalesWork, new { workType = "Salesforce", workId = salesforceWorkId, reason, now });
        }
    }
}
