using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Provides stored-procedure access to Consolidated Sales source-file processing state
    /// </summary>
    public class ConsolidatedSalesFileDataService : IConsolidatedSalesFileDataService
    {
        private readonly IDbExecutor _dbExecutor;

        /// <summary>
        /// Initialises a new instance of the <see cref="ConsolidatedSalesFileDataService"/>
        /// </summary>
        /// <param name="dbExecutor">The keyed Trade Account Service database executor</param>
        /// <exception cref="ArgumentNullException"></exception>
        public ConsolidatedSalesFileDataService([FromKeyedServices("AccountDb")] IDbExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesSourceItem> RegisterAsync(ConsolidatedSalesSourceRegistration registration, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesSourceItem>(StoredProcedures.RegisterConsolidatedSalesSourceItem, registration)
                ?? throw new InvalidOperationException("The source registration did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesSourceItem?> ClaimNextAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesSourceItem>(StoredProcedures.ClaimNextConsolidatedSalesSourceItem, new { leaseOwner, leaseDurationSeconds, maximumRetryCount, now });
        }

        /// <inheritdoc />
        public async Task<DateTimeOffset> RecordFirstReadAsync(
            Guid sourceItemId,
            Guid claimToken,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteScalarAsync<DateTimeOffset>(
                StoredProcedures.RecordConsolidatedSalesSourceFirstRead,
                new { sourceItemId, claimToken, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesLeaseResult> RenewLeaseAsync(Guid sourceItemId, Guid claimToken, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(StoredProcedures.RenewConsolidatedSalesSourceItemLease, new { sourceItemId, claimToken, leaseDurationSeconds, now })
                ?? throw new InvalidOperationException("The source lease renewal did not return a result");
        }

        /// <inheritdoc />
        public async Task CompleteAsync(Guid sourceItemId, Guid claimToken, bool sanitisationUsed, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _dbExecutor.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesSourceItem, new { sourceItemId, claimToken, sanitisationUsed, now });
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesSourceFailureResult> FailAsync(Guid sourceItemId, Guid claimToken, string errorCategory, string errorMessage, DateTimeOffset? nextAttemptOn, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesSourceFailureResult>(StoredProcedures.FailConsolidatedSalesSourceItem, new { sourceItemId, claimToken, errorCategory, errorMessage, nextAttemptOn, maximumRetryCount, now })
                ?? throw new InvalidOperationException("The source failure did not return a result");
        }

        /// <inheritdoc />
        public async Task<ConsolidatedSalesSourceFailureResult> AwaitCorrectionAsync(
            Guid sourceItemId,
            Guid claimToken,
            string errorCategory,
            string errorMessage,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return await _dbExecutor.ExecuteSingleAsync<ConsolidatedSalesSourceFailureResult>(
                StoredProcedures.AwaitConsolidatedSalesSourceCorrection,
                new { sourceItemId, claimToken, errorCategory, errorMessage, now })
                ?? throw new InvalidOperationException("The source correction state did not return a result");
        }

        /// <inheritdoc />
        public async Task RequeueAsync(Guid sourceItemId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _dbExecutor.ExecuteAsync(StoredProcedures.RequeueConsolidatedSalesWork, new { workType = "SourceItem", workId = sourceItemId, reason, now });
        }
    }
}
