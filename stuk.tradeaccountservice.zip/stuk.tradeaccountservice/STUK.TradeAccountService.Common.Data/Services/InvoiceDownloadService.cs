﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.Handlers;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class InvoiceDownloadService(
        [FromKeyedServices("Invoice")] IDocumentMetadataResolver<string, string> resolver,
        HttpClient httpClient,
        BlobServiceClient blobServiceClient,
        IAppInsightsLoggerHelper logger) : DocumentDownloadHandler<string, string>(resolver, httpClient, blobServiceClient, logger), IInvoiceDownloadService
    {
    }
}
