﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Globalization;

namespace STUK.TradeAccountService.Common.Data.Services;

public class ColumbusInvoiceDownloadService : IColumbusInvoiceDownloadService
{
    private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
    private readonly IColumbusWebService _columbusWebService;
    private readonly IDbExecutor _dbExecutor;
    private readonly string _username;
    private readonly string _password;
    private readonly int _maxMatches;
    private readonly string _docType="INI";
    private readonly string _storageAccountUrl;
    private readonly string _containerName;
    private readonly int _maxDegreeOfParallelism;
    private readonly int _maxPollingAttempts;
    private readonly int  _retryDelaySeconds;

    public ColumbusInvoiceDownloadService(
        IAppInsightsLoggerHelper appInsightsLoggerHelper,
        [FromKeyedServices("OrderDb")] IDbExecutor dbExecutor,
        IColumbusWebService columbusWebService,
        IConfiguration configuration)
    {
        _appInsightsLoggerHelper = appInsightsLoggerHelper;
        _columbusWebService = columbusWebService;
        _dbExecutor = dbExecutor;
        _maxPollingAttempts = configuration.GetValue<int>("Columbus:MaxRetryAttempts");
        _retryDelaySeconds = configuration.GetValue<int>("Columbus:RetryDelaySeconds");
        _username = configuration["Columbus:Username"]
            ?? throw new InvalidOperationException("Columbus:Username is not configured.");
        _password = configuration["Columbus:Password"]
            ?? throw new InvalidOperationException("Columbus:Password is not configured.");
        _maxMatches = configuration.GetValue<int>("Columbus:MaxMatches", 200);
        _storageAccountUrl = configuration["BlobStorage:StorageAccountUrl"]
            ?? throw new InvalidOperationException("BlobStorage:StorageAccountUrl is not configured.");
        _containerName = configuration["BlobStorage:InvoiceContainerName"].NullIfEmpty() ?? configuration["DownloadSettings:Invoice:ContainerName"].NullIfEmpty()
            ?? throw new InvalidOperationException("BlobStorage containerName is not configured for invoice.");
        _maxDegreeOfParallelism = configuration.GetValue<int>("Columbus:MaxDegreeOfParallelism", 1);
    }

    public async Task DownloadAndSyncInvoicesAsync()
    {
        IEnumerable<ColumbusInvoiceHeader> unsynchronizedInvoices;
        try
        {
            unsynchronizedInvoices = await SearchUnSynchronizedInvoiceDocuments();
            _appInsightsLoggerHelper.LogInformation($"Fetched unsynchronized invoices. Count: {unsynchronizedInvoices?.Count() ?? 0}");
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Failed to fetch unsynchronized invoices. Aborting.");
            return;
        }
        if (unsynchronizedInvoices == null || !unsynchronizedInvoices.Any())
        {
            _appInsightsLoggerHelper.LogInformation("No unsynchronized invoices found.");
            return;
        }

        await Parallel.ForEachAsync(
            unsynchronizedInvoices,
            new ParallelOptions { MaxDegreeOfParallelism = _maxDegreeOfParallelism },
            async (invoice, _) => await ProcessInvoiceAsync(invoice));
    }

    public async Task<ColumbusInvoiceHeader?> DownloadInvoiceByStandardInvoiceNumberAndBranchCodeAsync(string invoiceId,string branchCode)
    {
        try
        {
            var invoice = await GetInvoiceByStandardInvoiceNumberAndBranchCode(invoiceId,branchCode);

            if (invoice == null || invoice?.Id == null)
            {
                _appInsightsLoggerHelper.LogInformation($"No invoice found with Id {invoiceId} and Branch Code {branchCode}.");
                return null;
            }

            _appInsightsLoggerHelper.LogInformation($"Fetched invoice details with id {invoiceId} and Branch Code {branchCode}.");

            await ProcessInvoiceAsync(invoice);

            var updatedInvoice = await GetInvoiceByStandardInvoiceNumberAndBranchCode(invoiceId,branchCode);

            return updatedInvoice;
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, $"Failed processing invoice {invoiceId} and Branch Code {branchCode}.");
            throw;
        }
    }


    public async Task<ColumbusInvoiceHeader?> GetInvoiceByStandardInvoiceNumberAndBranchCode(string invoiceId,string branchCode)
    {
        _appInsightsLoggerHelper.LogInformation(
            $"Fetching invoice document with Id {invoiceId} and Branch Code {branchCode}.");

        try
        {
            var result = await _dbExecutor.ExecuteSingleAsync<ColumbusInvoiceHeader>(
                StoredProcedures.GetInvoiceHeaderByStandardInvoiceNumberAndBranchCode,
                new { standardInvoiceNo = invoiceId,
                    branchCode=branchCode });

            if (result == null)
            {
                _appInsightsLoggerHelper.LogWarning(
                    $"No invoice found for id {invoiceId} and Branch Code {branchCode}.");
                return null; 
            }

            _appInsightsLoggerHelper.LogInformation(
                $"Fetched invoice details successfully for id {invoiceId} and Branch Code {branchCode}.");

            return result;
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Failed to fetch invoice details.");
            throw;
        }
    }
    public async Task<IEnumerable<ColumbusInvoiceHeader>> SearchUnSynchronizedInvoiceDocuments()
    {
        _appInsightsLoggerHelper.LogInformation("Fetching unsynchronized invoice documents.");
        try
        {
            var result = await _dbExecutor.ExecuteListAsync<ColumbusInvoiceHeader>(
                StoredProcedures.GetUnsynchronizedInvoices,
                new { });

            _appInsightsLoggerHelper.LogInformation($"Fetched unsynchronized invoice documents successfully. Count: {result?.Count()}");
            return result ?? Enumerable.Empty<ColumbusInvoiceHeader>();
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, "Failed to fetch unsynchronized invoice documents.");
            throw;
        }
    }

    public async Task<int> UpdateInvoiceHeader(UpdateInvoiceHeaderRequest request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        _appInsightsLoggerHelper.LogInformation(
            $"Updating invoice header. InvoiceId: {request.InvoiceId} and Branch Code {request.BranchCode}.");

        try
        {
            var rowsUpdated = await _dbExecutor.ExecuteWithOutputAsync(
                StoredProcedures.UpdateInvoiceHeader,
                "@RowsUpdated",
                request);

            _appInsightsLoggerHelper.LogInformation(
                $"Invoice header updated successfully. RowsUpdated: {rowsUpdated}");

            return rowsUpdated;
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex,
                $"Failed to update invoice header. InvoiceId: {request.InvoiceId}");
            throw;
        }
    }
    private async Task ProcessInvoiceAsync(ColumbusInvoiceHeader invoice)
    {
        string accountCode = invoice.CustomerAccount;
        string branchNo = invoice.BranchCode;
        string documentNo = invoice.StandardInvoiceNo;
        string? startDate = invoice.InvoiceDateTime?.DateTime.ToString("dd/MM/yyyy");
        string? endDate = invoice.InvoiceDateTime?.DateTime.ToString("dd/MM/yyyy");

        _appInsightsLoggerHelper.LogInformation($"Processing invoice. InvoiceId: {invoice.Id}, AccountCode: {accountCode}, BranchNo: {branchNo}, DocumentNo: {documentNo}, Date: {startDate}");

        if (string.IsNullOrWhiteSpace(startDate) || string.IsNullOrWhiteSpace(endDate))
        {
            _appInsightsLoggerHelper.LogWarning($"Invoice skipped — InvoiceDateTime is null. InvoiceId: {invoice.Id}, DocumentNo: {documentNo}");
            return;
        }

        ColumbusOpenSessionResult openResponse;
        try
        {
            openResponse = await _columbusWebService.OpenSessionAsync(_username, _password);
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, $"Failed to open Columbus session. InvoiceId: {invoice.Id}, DocumentNo: {documentNo}");
            return;
        }

        if (openResponse.ErrorNumber != 0)
        {
            _appInsightsLoggerHelper.LogWarning($"OpenSession returned an error. Skipping invoice. InvoiceId: {invoice.Id}, ErrorNumber: {openResponse.ErrorNumber}, ErrorMessage: {openResponse.ErrorMessage}");
            return;
        }

        if (openResponse.Archive == null)
        {
            _appInsightsLoggerHelper.LogWarning($"OpenSession returned no archive. Skipping invoice. InvoiceId: {invoice.Id}, DocumentNo: {documentNo}");
            return;
        }
        string sessionId = openResponse.SessionId;
        int archiveId = openResponse.Archive.ArchiveId;
        _appInsightsLoggerHelper.LogInformation($"Columbus session opened. SessionId: {sessionId}, ArchiveId: {archiveId}, InvoiceId: {invoice.Id}");

        try
        {
            await RunSearchAndDownloadLoopAsync(invoice, sessionId, archiveId);
        }
        finally
        {
            try
            {
                await _columbusWebService.CloseSessionAsync(sessionId);
                _appInsightsLoggerHelper.LogInformation($"Columbus session closed. SessionId: {sessionId}, InvoiceId: {invoice.Id}");
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to close Columbus session. SessionId: {sessionId}, InvoiceId: {invoice.Id}");
            }
        }
    }

    private async Task RunSearchAndDownloadLoopAsync(
   ColumbusInvoiceHeader invoice,
   string sessionId,
   int archiveId
        )
    {
        string? continueSearch = null;
        do
        {
            _appInsightsLoggerHelper.LogInformation($"Beginning search operation. SessionId: {sessionId}, InvoiceId: {invoice.Id}, ContinueSearch: {continueSearch ?? "null"}");
            var startDate = invoice.InvoiceDateTime?.DateTime.ToString("dd/MM/yyyy")
    ?? throw new InvalidOperationException("InvoiceDateTime cannot be null");

            var (beginSearchErrorNumber, beginSearchErrorMessage) = await _columbusWebService.BeginSearchOperationAsync(
            sessionId, archiveId, _maxMatches,_docType, invoice.CustomerAccount, invoice.BranchCode, invoice.StandardInvoiceNo, startDate, startDate, continueSearch);
            if (beginSearchErrorNumber != 0)
            {
                _appInsightsLoggerHelper.LogWarning($"BeginSearchOperation failed. Aborting search loop. InvoiceId: {invoice.Id}, ErrorNumber: {beginSearchErrorNumber}, ErrorMessage: {beginSearchErrorMessage}");
                return;
            }
            ColumbusSearchResult? searchResult = await PollSearchResultsAsync(sessionId, invoice.Id);
            if (searchResult == null)
                return;
            continueSearch = searchResult.ContinueSearch;
            int totalPages = searchResult.TotalDocuments;
            _appInsightsLoggerHelper.LogInformation($"Search results retrieved. InvoiceId: {invoice.Id}, TotalPages: {totalPages}, ContinueSearch: {continueSearch ?? "null"}");
            if (totalPages == 0)
            {
                _appInsightsLoggerHelper.LogWarning($"No documents found for invoice. InvoiceId: {invoice.Id}, DocumentNo: {invoice.StandardInvoiceNo}");
                break;
            }
            for (int page = 1; page <= totalPages; page++)
            {
                await ProcessPageAsync(invoice, sessionId,page, totalPages);
            }
        } while (!string.IsNullOrEmpty(continueSearch));
    }
    private async Task<ColumbusSearchResult?> PollSearchResultsAsync(string sessionId, Guid invoiceId)
    {

        for (int attempt = 1; attempt <= _maxPollingAttempts; attempt++)
        {
            ColumbusSearchResult searchResult;
            try
            {
                searchResult = await _columbusWebService.GetSearchResultsAsync(sessionId);
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to get search results. SessionId: {sessionId}, InvoiceId: {invoiceId}, Attempt: {attempt}/{_maxPollingAttempts}");
                return null;
            }
            if (searchResult.OperationStatus == "ACTIVE")
            {
                if (attempt == _maxPollingAttempts)
                {
                    _appInsightsLoggerHelper.LogWarning($"Search operation still ACTIVE after {_maxPollingAttempts} attempt(s). Aborting. SessionId: {sessionId}, InvoiceId: {invoiceId}");
                    return null;
                }
                _appInsightsLoggerHelper.LogInformation($"Search operation ACTIVE on attempt {attempt}/{_maxPollingAttempts}. Retrying. SessionId: {sessionId}, InvoiceId: {invoiceId}");
                await Task.Delay(TimeSpan.FromSeconds(_retryDelaySeconds));
                continue;
            }
            _appInsightsLoggerHelper.LogInformation($"Search operation completed. SessionId: {sessionId}, InvoiceId: {invoiceId}, Attempt: {attempt}, OperationStatus: {searchResult.OperationStatus}");
            return searchResult;
        }
        return null;
    }

    private async Task ProcessPageAsync(
   ColumbusInvoiceHeader invoice,
   string sessionId,
   int page,
   int totalPages)
    {
        _appInsightsLoggerHelper.LogInformation($"Beginning page operation. InvoiceId: {invoice.Id}, DocumentNo: {invoice.StandardInvoiceNo}, Page: {page}/{totalPages}");
        var (beginPageErrorNumber, beginPageErrorMessage) = await _columbusWebService.BeginPageOperationAsync(sessionId, page);
        if (beginPageErrorNumber != 0)
        {
            _appInsightsLoggerHelper.LogWarning($"BeginPageOperation failed. Skipping page. InvoiceId: {invoice.Id}, Page: {page}, ErrorNumber: {beginPageErrorNumber}, ErrorMessage: {beginPageErrorMessage}");
            return;
        }
        ColumbusPageResponse? uploadResponse = await PollPageResultsAsync(invoice, sessionId,page, totalPages);
        if (uploadResponse == null)
            return;
        if (uploadResponse.ErrorNumber != 0)
        {
            _appInsightsLoggerHelper.LogWarning($"GetPageResultsAndUploadToBlob returned an error. Skipping update. InvoiceId: {invoice.Id}, Page: {page}, ErrorNumber: {uploadResponse.ErrorNumber}, ErrorMessage: {uploadResponse.ErrorMessage}");
            return;
        }
        _appInsightsLoggerHelper.LogInformation($"Page uploaded to blob successfully. InvoiceId: {invoice.Id}, BlobUrl: {uploadResponse.BlobUrl}, FileName: {uploadResponse.CalculatedFileName}");
        await UpdateInvoiceHeaderAsync(invoice, uploadResponse);
    }

    private async Task<ColumbusPageResponse?> PollPageResultsAsync(
      ColumbusInvoiceHeader invoice,
      string sessionId,
      int page,
      int totalPages)
    {
        for (int attempt = 1; attempt <= _maxPollingAttempts; attempt++)
        {
            ColumbusPageResponse uploadResponse;
            try
            {
                var date = invoice.InvoiceDateTime?.DateTime.ToString("dd/MM/yyyy")
    ?? throw new InvalidOperationException("Invoice date is required");
                uploadResponse = await _columbusWebService.GetPageResultsAndUploadToBlobAsync(
                sessionId, invoice.CustomerAccount, invoice.BranchCode, invoice.StandardInvoiceNo, page, totalPages, date,
                _storageAccountUrl, _containerName);
            }
            catch (Exception ex)
            {
                _appInsightsLoggerHelper.LogError(ex, $"Failed to get page results or upload to blob. InvoiceId: {invoice.Id}, DocumentNo: {invoice.StandardInvoiceNo}, Page: {page}, Attempt: {attempt}/{_maxPollingAttempts}");
                return null;
            }
            if (uploadResponse.OperationStatus == "ACTIVE")
            {
                if (attempt == _maxPollingAttempts)
                {
                    _appInsightsLoggerHelper.LogWarning($"Page operation still ACTIVE after {_maxPollingAttempts} attempt(s). Aborting. InvoiceId: {invoice.Id}, DocumentNo: {invoice.StandardInvoiceNo}, Page: {page}");
                    return null;
                }
                _appInsightsLoggerHelper.LogInformation($"Page operation ACTIVE on attempt {attempt}/{_maxPollingAttempts}. Retrying in {_retryDelaySeconds}s. InvoiceId: {invoice.Id}, DocumentNo: {invoice.StandardInvoiceNo}, Page: {page}");
                await Task.Delay(TimeSpan.FromSeconds(_retryDelaySeconds));
                continue;
            }
            _appInsightsLoggerHelper.LogInformation($"Page operation completed. InvoiceId: {invoice.Id}, DocumentNo: {invoice.StandardInvoiceNo}, Page: {page}, Attempt: {attempt}, OperationStatus: {uploadResponse.OperationStatus}");
            return uploadResponse;
        }
        return null;
    }

    private async Task UpdateInvoiceHeaderAsync(ColumbusInvoiceHeader invoice, ColumbusPageResponse uploadResponse)
    {
        try
        {
            DateTimeOffset? createdOn = null;

            if (DateTimeOffset.TryParseExact(
                    uploadResponse.CreationTime,
                    "HH:mm  dd/MM/yyyy",
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out var parsedDate))
            {
                createdOn = parsedDate;
            }
            else
            {
                _appInsightsLoggerHelper.LogWarning(
                    $"Could not parse CreationTime. Setting to null. InvoiceId: {invoice.Id}, RawCreationTime: '{uploadResponse.CreationTime}'");
            }
            var request = new UpdateInvoiceHeaderRequest
            {
                InvoiceId = invoice.Id,
                BranchCode=invoice.BranchCode,
                OriginalFileName = uploadResponse.SourceFileName,
                Extension = uploadResponse.Extension,
                CalculatedFileName = uploadResponse.CalculatedFileName,
                ContentMd5 = uploadResponse.ContentMd5,
                ContentLength = uploadResponse.FileSize,
                BlobUri = uploadResponse.BlobUrl,
                CreatedOn = createdOn,
                IsSynchronized = true
            };
            int rowsUpdated  = await UpdateInvoiceHeader(request);
            if (rowsUpdated == 0)
            {
                _appInsightsLoggerHelper.LogError(new Exception($"No Records Found for InvoiceId {invoice.Id}"), $"No Records Found for InvoiceId {invoice.Id}");
            }
            _appInsightsLoggerHelper.LogInformation($"Invoice header updated successfully. InvoiceId: {invoice.Id}, FileName: {uploadResponse.CalculatedFileName}");
        }
        catch (Exception ex)
        {
            _appInsightsLoggerHelper.LogError(ex, $"Failed to update invoice header. InvoiceId: {invoice.Id}, BlobUrl: {uploadResponse.BlobUrl}");
        }
    }
    public bool DownloadInvoiceByInvoiceIdAndBranchCode(string invoiceId,string branchCode)
    {

        _= DownloadInvoiceByStandardInvoiceNumberAndBranchCodeAsync(invoiceId,branchCode);

        return true;
    }
}
file static class StringExtensions {
    internal static string? NullIfEmpty(this string? value) =>
        string.IsNullOrEmpty(value) ? null : value;
}