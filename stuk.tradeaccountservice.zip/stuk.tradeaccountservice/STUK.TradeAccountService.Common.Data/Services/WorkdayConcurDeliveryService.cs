using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Encrypts transformed Concur files and invokes the managed Blob-to-SFTP Synapse pipeline
    /// </summary>
    public class WorkdayConcurDeliveryService : IWorkdayConcurDeliveryService
    {
        private const string ExpectedPipelineName = "Blob_To_SFTP_SSH";
        private const string PgpExtension = ".pgp";

        private readonly IFileTransferConfigurationService _configurationService;
        private readonly IWorkdayConcurBlobClient _blobClient;
        private readonly IConcurPgpEncryptionService _encryptionService;
        private readonly ISynapsePipelineClient _synapseClient;
        private readonly WorkdayConcurOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="WorkdayConcurDeliveryService"/>
        /// </summary>
        /// <param name="configurationService">Managed transfer configuration service</param>
        /// <param name="blobClient">Concur Blob client</param>
        /// <param name="encryptionService">Mule-compatible PGP encryption service</param>
        /// <param name="synapseClient">Azure Synapse pipeline client</param>
        /// <param name="options">Workday-to-Concur settings</param>
        /// <param name="timeProvider">Provides deterministic UTC timestamps</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public WorkdayConcurDeliveryService(
            IFileTransferConfigurationService configurationService,
            IWorkdayConcurBlobClient blobClient,
            IConcurPgpEncryptionService encryptionService,
            ISynapsePipelineClient synapseClient,
            IOptions<WorkdayConcurOptions> options,
            TimeProvider timeProvider)
        {
            _configurationService = configurationService ?? throw new ArgumentNullException(nameof(configurationService));
            _blobClient = blobClient ?? throw new ArgumentNullException(nameof(blobClient));
            _encryptionService = encryptionService ?? throw new ArgumentNullException(nameof(encryptionService));
            _synapseClient = synapseClient ?? throw new ArgumentNullException(nameof(synapseClient));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurDeliveryCheckpoint> PrepareAsync(Guid correlationId, IReadOnlyCollection<WorkdayConcurFileIdentity> outputFiles, CancellationToken cancellationToken = default)
        {
            if (correlationId == Guid.Empty)
            {
                throw new ArgumentException("A Workday-to-Concur correlation identifier is required", nameof(correlationId));
            }

            ArgumentNullException.ThrowIfNull(outputFiles);
            if (outputFiles.Count == 0)
            {
                throw new ArgumentException("At least one transformed Concur output file is required", nameof(outputFiles));
            }

            ValidateOptions();

            var configuration = await _configurationService.GetConcurDeliveryAsync(
                _options.ConcurDeliveryIntegrationKeyId,
                _options.ConcurDeliveryActionName,
                cancellationToken);

            ValidateTransferConfiguration(configuration);

            var stagingLocation = CreateStagingLocation(configuration.Action.SourceFolderPath, correlationId);
            var stagedFiles = await StageEncryptedFilesAsync(outputFiles, configuration, stagingLocation, cancellationToken);
            return new WorkdayConcurDeliveryCheckpoint
            {
                BlobServiceEndpoint = configuration.Blob.ServiceEndPoint,
                StagingContainer = stagingLocation.Container,
                StagingFolderPath = stagingLocation.Folder,
                StagedFiles = stagedFiles,
                Status = WorkdayConcurDeliveryStatus.Staged
            };
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurDeliveryCheckpoint> StartAsync(Guid correlationId, WorkdayConcurDeliveryCheckpoint checkpoint, CancellationToken cancellationToken = default)
        {
            if (correlationId == Guid.Empty)
            {
                throw new ArgumentException("A Workday-to-Concur correlation identifier is required", nameof(correlationId));
            }

            ArgumentNullException.ThrowIfNull(checkpoint);
            ValidatePreparedCheckpoint(checkpoint);
            if (checkpoint.Status != WorkdayConcurDeliveryStatus.Starting)
            {
                throw new InvalidOperationException("The Concur delivery checkpoint must be persisted as Starting before Synapse is called");
            }

            ValidateOptions();

            var configuration = await _configurationService.GetConcurDeliveryAsync(
                _options.ConcurDeliveryIntegrationKeyId,
                _options.ConcurDeliveryActionName,
                cancellationToken);

            ValidateTransferConfiguration(configuration);
            ValidatePreparedLocation(checkpoint, configuration, correlationId);

            var stagingLocation = new BlobLocation(checkpoint.StagingContainer, checkpoint.StagingFolderPath);
            var parameters = CreateParameters(configuration, stagingLocation, correlationId);
            var startedOn = _timeProvider.GetUtcNow();
            var runId = await _synapseClient.StartAsync(configuration.Action.PipeLineName, parameters, cancellationToken);

            checkpoint.SynapseRunId = runId;
            checkpoint.StartedOn = startedOn;
            checkpoint.Status = WorkdayConcurDeliveryStatus.InProgress;
            return checkpoint;
        }

        /// <inheritdoc />
        public async Task<WorkdayConcurDeliveryCheckpoint> CompleteAsync(WorkdayConcurDeliveryCheckpoint checkpoint, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(checkpoint);
            ValidateCheckpoint(checkpoint);

            var run = await _synapseClient.WaitForCompletionAsync(checkpoint.SynapseRunId, cancellationToken);
            checkpoint.CompletedOn = _timeProvider.GetUtcNow();

            if (!string.Equals(run.Status, WorkdayConcurDeliveryStatus.Succeeded.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                checkpoint.Status = ParseTerminalStatus(run.Status);
                checkpoint.FailureMessage = string.IsNullOrWhiteSpace(run.Message)
                    ? $"Synapse Concur delivery ended with status '{run.Status}'"
                    : run.Message;
                return checkpoint;
            }

            var remainingFiles = await _blobClient.ListFilesAsync(
                new Uri(checkpoint.BlobServiceEndpoint, UriKind.Absolute),
                checkpoint.StagingContainer,
                checkpoint.StagingFolderPath,
                cancellationToken);

            if (remainingFiles.Count > 0)
            {
                checkpoint.Status = WorkdayConcurDeliveryStatus.ValidationFailed;
                checkpoint.FailureMessage = $"Synapse Concur delivery left {remainingFiles.Count} encrypted file(s) in the active staging folder";
                return checkpoint;
            }

            checkpoint.Status = WorkdayConcurDeliveryStatus.Succeeded;
            checkpoint.FailureMessage = null;
            return checkpoint;
        }

        private async Task<IReadOnlyCollection<WorkdayConcurFileIdentity>> StageEncryptedFilesAsync(IReadOnlyCollection<WorkdayConcurFileIdentity> outputFiles, WorkdayConcurDeliveryTransferConfiguration configuration, BlobLocation stagingLocation, CancellationToken cancellationToken)
        {
            var outputEndpoint = new Uri(_options.ConcurBlobServiceEndpoint, UriKind.Absolute);
            var stagingEndpoint = new Uri(configuration.Blob.ServiceEndPoint, UriKind.Absolute);
            var stagedFiles = new List<WorkdayConcurFileIdentity>();
            var selections = CreateOutputSelections(outputFiles);

            foreach (var selection in selections)
            {
                await using var source = await _blobClient.OpenReadAsync(
                    outputEndpoint,
                    _options.ConcurBlobContainerName,
                    selection.BlobName,
                    selection.File.ETag,
                    cancellationToken);
                await using var encrypted = new MemoryStream();

                await _encryptionService.EncryptAsync(
                    source,
                    encrypted,
                    _options.ConcurPgpPublicKey,
                    _options.ConcurPgpKeyId,
                    cancellationToken);

                encrypted.Position = 0;
                var stagingBlobName = $"{stagingLocation.Folder}/{selection.EncryptedFileName}";

                var stagedFile = await _blobClient.UploadAsync(
                    stagingEndpoint,
                    stagingLocation.Container,
                    stagingBlobName,
                    encrypted,
                    cancellationToken);

                stagedFiles.Add(stagedFile);
            }

            return stagedFiles;
        }

        private IReadOnlyCollection<OutputSelection> CreateOutputSelections(IReadOnlyCollection<WorkdayConcurFileIdentity> outputFiles)
        {
            var selectedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var selections = new List<OutputSelection>();

            foreach (var outputFile in outputFiles)
            {
                var blobName = GetBlobName(outputFile.Path, _options.ConcurBlobContainerName);
                var encryptedFileName = $"{Path.GetFileName(blobName)}{PgpExtension}";
                if (!selectedNames.Add(encryptedFileName))
                {
                    throw new InvalidDataException($"More than one selected Concur output maps to encrypted filename '{encryptedFileName}'");
                }

                selections.Add(new OutputSelection(outputFile, blobName, encryptedFileName));
            }

            return selections;
        }

        private IReadOnlyDictionary<string, object?> CreateParameters(WorkdayConcurDeliveryTransferConfiguration configuration, BlobLocation stagingLocation, Guid correlationId)
        {
            var action = configuration.Action;
            var destinationPath = GetConfiguredDestinationPath();

            return new Dictionary<string, object?>
            {
                ["Id"] = correlationId.ToString("D"),
                ["CorrelationID"] = correlationId.ToString("D"),
                ["SourceStorageAccountEndPoint"] = configuration.Blob.ServiceEndPoint,
                ["SourceFilePath"] = $"{stagingLocation.Container}/{stagingLocation.Folder}",
                ["FileStartFilter"] = string.Empty,
                ["FileEndFilter"] = PgpExtension,
                ["DestinationHost"] = configuration.Sftp.IpAddress,
                ["DestinationUsername"] = configuration.Sftp.Username,
                ["DestinationPassword"] = configuration.Sftp.PasswordKey,
                ["DestinationPassPhrase"] = configuration.Sftp.PassPhraseKey,
                ["DestinationFilePath"] = destinationPath,
                ["DestinationFileFormat"] = null,
                ["ArchivePath"] = null,
                ["IsArchive"] = false,
                ["ErrorPath"] = action.SourceErrorPath,
                ["LastRunTotalAmount"] = 0M,
                ["RecordCount"] = 0,
                ["TriggeredByFnApp"] = "stuk.tradeaccountservice",
                ["TriggeredBySchedulerName"] = "WorkdayConcurTimerFunction",
                ["IsErrorArchiveFileNameChange"] = false,
                ["ErrorArchiveFileName"] = null,
                ["SourceDelete"] = true,
                ["FileAction"] = _options.ConcurDeliveryActionName,
                ["RetryCount"] = "0"
            };
        }

        private void ValidateOptions()
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurDeliveryIntegrationKeyId);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurDeliveryActionName);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurBlobContainerName);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurDestinationPath);
            GetConfiguredDestinationPath();
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurPgpPublicKey);
            ArgumentException.ThrowIfNullOrWhiteSpace(_options.ConcurPgpKeyId);

            ValidateHttpsEndpoint(_options.ConcurBlobServiceEndpoint, "The Concur Blob service endpoint");
        }

        private void ValidateTransferConfiguration(WorkdayConcurDeliveryTransferConfiguration configuration)
        {
            ArgumentNullException.ThrowIfNull(configuration);

            var action = configuration.Action ?? throw new InvalidOperationException("The Concur delivery File Transfer action is missing");
            var blob = configuration.Blob ?? throw new InvalidOperationException("The Concur delivery Blob configuration is missing");
            var sftp = configuration.Sftp ?? throw new InvalidOperationException("The Concur delivery SFTP configuration is missing");

            if (!string.Equals(action.PipeLineName, ExpectedPipelineName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"Concur delivery must use the managed '{ExpectedPipelineName}' pipeline");
            }

            ArgumentException.ThrowIfNullOrWhiteSpace(action.SourceFolderPath);
            var destinationPath = GetConfiguredDestinationPath();
            if (!NormalisePath(action.DestinationFolderPath).Equals(destinationPath, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"Concur delivery must target '{destinationPath}'");
            }

            if (action.SourceArchive == true || action.SourceDelete != true)
            {
                throw new InvalidOperationException("Concur delivery must delete successfully transferred staging files without archiving them");
            }

            ValidateHttpsEndpoint(blob.ServiceEndPoint, "The Concur delivery Blob service endpoint");
            ArgumentException.ThrowIfNullOrWhiteSpace(sftp.IpAddress);
            ArgumentException.ThrowIfNullOrWhiteSpace(sftp.Username);
            ArgumentException.ThrowIfNullOrWhiteSpace(sftp.PasswordKey);
            ArgumentException.ThrowIfNullOrWhiteSpace(sftp.PassPhraseKey);
        }

        private static void ValidateCheckpoint(WorkdayConcurDeliveryCheckpoint checkpoint)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.SynapseRunId);
            ValidatePreparedCheckpoint(checkpoint);
        }

        private static void ValidatePreparedCheckpoint(WorkdayConcurDeliveryCheckpoint checkpoint)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.BlobServiceEndpoint);
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.StagingContainer);
            ArgumentException.ThrowIfNullOrWhiteSpace(checkpoint.StagingFolderPath);
            if (checkpoint.StagedFiles.Count == 0)
            {
                throw new InvalidDataException("The Concur delivery checkpoint contains no staged encrypted files");
            }
        }

        private static void ValidatePreparedLocation(WorkdayConcurDeliveryCheckpoint checkpoint, WorkdayConcurDeliveryTransferConfiguration configuration, Guid correlationId)
        {
            var expectedLocation = CreateStagingLocation(configuration.Action.SourceFolderPath, correlationId);
            if (!string.Equals(checkpoint.BlobServiceEndpoint, configuration.Blob.ServiceEndPoint, StringComparison.OrdinalIgnoreCase)
                || !string.Equals(checkpoint.StagingContainer, expectedLocation.Container, StringComparison.OrdinalIgnoreCase)
                || !string.Equals(checkpoint.StagingFolderPath, expectedLocation.Folder, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("The persisted Concur delivery staging location does not match the current managed-transfer configuration");
            }
        }

        private static WorkdayConcurDeliveryStatus ParseTerminalStatus(string status)
        {
            if (Enum.TryParse<WorkdayConcurDeliveryStatus>(status, ignoreCase: true, out var parsed)
                && parsed is WorkdayConcurDeliveryStatus.Failed or WorkdayConcurDeliveryStatus.Cancelled)
            {
                return parsed;
            }

            throw new InvalidDataException($"Synapse returned unsupported terminal delivery status '{status}'");
        }

        private static BlobLocation CreateStagingLocation(string? sourceFolderPath, Guid correlationId)
        {
            var normalisedPath = NormalisePath(sourceFolderPath).TrimStart('/');
            var separator = normalisedPath.IndexOf('/');
            if (separator <= 0 || separator == normalisedPath.Length - 1)
            {
                throw new InvalidOperationException("The Concur delivery source folder must contain a Blob container and staging path");
            }

            return new BlobLocation(
                normalisedPath[..separator],
                $"{normalisedPath[(separator + 1)..]}/{correlationId:N}");
        }

        private static string GetBlobName(string path, string containerName)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(path);

            var prefix = $"{containerName.Trim('/')}/";
            if (!path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || path.Length == prefix.Length)
            {
                throw new InvalidDataException($"Selected Concur output '{path}' is not inside Blob container '{containerName}'");
            }

            return path[prefix.Length..];
        }

        private static void ValidateHttpsEndpoint(string endpointValue, string description)
        {
            if (!Uri.TryCreate(endpointValue, UriKind.Absolute, out var endpoint) || endpoint.Scheme != Uri.UriSchemeHttps)
            {
                throw new InvalidOperationException($"{description} must be an absolute HTTPS URI");
            }
        }

        private static string NormalisePath(string? path)
        {
            return (path ?? string.Empty).Trim().TrimEnd('/');
        }

        private string GetConfiguredDestinationPath()
        {
            var destinationPath = NormalisePath(_options.ConcurDestinationPath);
            if (destinationPath.Length <= 1 || !destinationPath.StartsWith("/", StringComparison.Ordinal))
            {
                throw new InvalidOperationException("The Concur destination path must be an absolute SFTP folder");
            }

            return destinationPath;
        }

        private sealed record BlobLocation(string Container, string Folder);

        private sealed record OutputSelection(WorkdayConcurFileIdentity File, string BlobName, string EncryptedFileName);
    }
}
