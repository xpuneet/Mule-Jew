using Azure.Core;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    /// <summary>
    /// Starts and polls Azure Synapse pipeline runs through the documented data-plane API
    /// </summary>
    public class SynapsePipelineClient : ISynapsePipelineClient, IConcurSynapsePipelineClient
    {
        private const string ApiVersion = "2020-12-01";
        private const string WorkspaceHostSuffix = ".dev.azuresynapse.net";
        private static readonly TokenRequestContext TokenContext = new(["https://dev.azuresynapse.net/.default"]);
        private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

        private readonly HttpClient _httpClient;
        private readonly TokenCredential _credential;
        private readonly WorkdayConcurOptions _options;
        private readonly TimeProvider _timeProvider;

        /// <summary>
        /// Initialises a new instance of the <see cref="SynapsePipelineClient"/>
        /// </summary>
        /// <param name="httpClient">Typed HTTP client</param>
        /// <param name="credential">Azure workload credential</param>
        /// <param name="options">Workday-to-Concur settings</param>
        /// <param name="timeProvider">Provides time and polling delays</param>
        /// <exception cref="ArgumentNullException">Thrown when a required dependency is not supplied</exception>
        public SynapsePipelineClient(HttpClient httpClient, TokenCredential credential, IOptions<WorkdayConcurOptions> options, TimeProvider timeProvider)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _credential = credential ?? throw new ArgumentNullException(nameof(credential));
            _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        }

        /// <inheritdoc />
        public async Task<string> StartAsync(string pipelineName, IReadOnlyDictionary<string, object?> parameters, CancellationToken cancellationToken = default)
        {
            return await StartAsync(_options.SynapseWorkspaceName, pipelineName, parameters, cancellationToken);
        }

        async Task<string> IConcurSynapsePipelineClient.StartAsync(string pipelineName, IReadOnlyDictionary<string, object?> parameters, CancellationToken cancellationToken)
        {
            return await StartAsync(_options.ConcurSynapseWorkspaceName, pipelineName, parameters, cancellationToken);
        }

        private async Task<string> StartAsync(string workspaceName, string pipelineName, IReadOnlyDictionary<string, object?> parameters, CancellationToken cancellationToken)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(pipelineName);
            ArgumentNullException.ThrowIfNull(parameters);
            ValidateOptions(workspaceName);

            using var request = await CreateRequestAsync(workspaceName, HttpMethod.Post, $"pipelines/{Uri.EscapeDataString(pipelineName)}/createRun?api-version={ApiVersion}", cancellationToken);

            request.Content = JsonContent.Create(parameters);

            using var response = await _httpClient.SendAsync(request, cancellationToken);

            response.EnsureSuccessStatusCode();

            var payload = await response.Content.ReadFromJsonAsync<CreateRunResponse>(JsonOptions, cancellationToken);

            return !string.IsNullOrWhiteSpace(payload?.RunId)
                ? payload.RunId
                : throw new InvalidDataException("Synapse did not return a pipeline run identifier");
        }

        /// <inheritdoc />
        public async Task<SynapsePipelineRun> WaitForCompletionAsync(string runId, CancellationToken cancellationToken = default)
        {
            return await WaitForCompletionAsync(_options.SynapseWorkspaceName, runId, cancellationToken);
        }

        async Task<SynapsePipelineRun> IConcurSynapsePipelineClient.WaitForCompletionAsync(string runId, CancellationToken cancellationToken)
        {
            return await WaitForCompletionAsync(_options.ConcurSynapseWorkspaceName, runId, cancellationToken);
        }

        private async Task<SynapsePipelineRun> WaitForCompletionAsync(string workspaceName, string runId, CancellationToken cancellationToken)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(runId);
            ValidateOptions(workspaceName);

            var startedOn = _timeProvider.GetUtcNow();
            var timeout = TimeSpan.FromSeconds(_options.SynapseRunTimeoutSeconds);
            var pollInterval = TimeSpan.FromSeconds(_options.SynapsePollIntervalSeconds);

            while (_timeProvider.GetUtcNow() - startedOn < timeout)
            {
                var run = await GetRunAsync(workspaceName, runId, cancellationToken);
                if (IsTerminal(run.Status))
                {
                    return run;
                }

                await Task.Delay(pollInterval, _timeProvider, cancellationToken);
            }

            throw new TimeoutException($"Synapse pipeline run '{runId}' did not complete within the configured timeout");
        }

        private async Task<SynapsePipelineRun> GetRunAsync(string workspaceName, string runId, CancellationToken cancellationToken)
        {
            using var request = await CreateRequestAsync(workspaceName, HttpMethod.Get, $"pipelineruns/{Uri.EscapeDataString(runId)}?api-version={ApiVersion}", cancellationToken);

            using var response = await _httpClient.SendAsync(request, cancellationToken);

            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<SynapsePipelineRun>(JsonOptions, cancellationToken) ?? throw new InvalidDataException($"Synapse returned no state for pipeline run '{runId}'");
        }

        private async Task<HttpRequestMessage> CreateRequestAsync(string workspaceName, HttpMethod method, string relativePath, CancellationToken cancellationToken)
        {
            var token = await _credential.GetTokenAsync(TokenContext, cancellationToken);

            return new HttpRequestMessage(method, CreateRequestUri(workspaceName, relativePath))
            {
                Headers = { Authorization = new AuthenticationHeaderValue("Bearer", token.Token) }
            };
        }

        private static Uri CreateRequestUri(string workspaceName, string relativePath)
        {
            return new Uri(new UriBuilder(Uri.UriSchemeHttps, $"{workspaceName}{WorkspaceHostSuffix}").Uri, relativePath);
        }

        private void ValidateOptions(string workspaceName)
        {
            if (string.IsNullOrWhiteSpace(workspaceName) || workspaceName.Any(character => !char.IsAsciiLetterOrDigit(character) && character != '-'))
            {
                throw new InvalidOperationException("A valid Workday-to-Concur Synapse workspace name is required");
            }

            if (_options.SynapsePollIntervalSeconds <= 0 || _options.SynapseRunTimeoutSeconds <= 0)
            {
                throw new InvalidOperationException("Positive Synapse polling and run timeout values are required");
            }
        }

        private static bool IsTerminal(string? status)
        {
            return string.Equals(status, "Succeeded", StringComparison.OrdinalIgnoreCase)
                || string.Equals(status, "Failed", StringComparison.OrdinalIgnoreCase)
                || string.Equals(status, "Cancelled", StringComparison.OrdinalIgnoreCase);
        }

        private sealed class CreateRunResponse
        {
            public string RunId { get; set; } = string.Empty;
        }
    }
}
