﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.Text.Json;

namespace STUK.TradeAccountService.Common.Data.Services
{
    public class TradeAccountInvoiceService([FromKeyedServices("OrderDb")] IDbExecutor dbExecutor,
        IOptions<DownloadSettings> settings,
        IAppInsightsLoggerHelper appInsightsLoggerHelper) : ITradeAccountInvoicesService
    {
        private readonly IDbExecutor _dbExecutor = dbExecutor ?? throw new ArgumentNullException(nameof(dbExecutor));
        private readonly DocumentTypeDownloadSettings _typeSettings = settings.Value["Invoice"];
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));

        public async Task<InvoiceResponse?> GetInvoiceByStandardInvoiceNoAsync(string invoiceId, string branchCode, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetInvoiceByStandardInvoiceNoAsync started at {DateTime.Now} with standardInvoiceId {invoiceId} and branchCode {branchCode}.");
            var jsonString = await _dbExecutor.ExecuteSingleAsync<string>(
                    StoredProcedures.GetInvoiceDetailsByStandardInvoiceNo,
                    new { standardInvoiceNo = invoiceId, branchCode });

            if (string.IsNullOrEmpty(jsonString))
            {
                _appInsightsLoggerHelper.LogWarning($"GetInvoiceByStandardInvoiceNoAsync completed with empty json standardInvoiceNo {invoiceId} and branchCode {branchCode}.");
                return null;
            }
            var result = JsonSerializer.Deserialize<InvoiceResponse>(jsonString);
            _appInsightsLoggerHelper.LogInformation($"GetInvoiceByStandardInvoiceNoAsync completed successfully standardInvoiceNo {invoiceId} and branchCode {branchCode}.");
            return result;
        }
        public async Task<DocumentSearchResponse?> FilterInvoiceDocumentsAsync(InvoiceFilterRequest request, char documentType = 'S', CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"FilterInvoiceDocumentsAsync started for doctype: {documentType} at {DateTime.Now} with customerAccount {request.CustomerAccount}.");
            DocumentSearchResponse documentSearchResponse;
            
            var minAgeHours = _typeSettings.DownloadDelayHours;
            var jsonString = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetInvoiceSearchByAccountCode, new
            {
                request.CustomerAccount,
                documentType,
                request.BranchCode,
                request.Brand,
                request.InvoiceDateFrom,
                request.InvoiceDateTo,
                minAgeHours,
                request.OrderBranchCode,
                request.OrderNo,
                request.OrderCreatedDateFrom,
                request.OrderCreatedDateTo,
                request.OrderReference,
                request.ItemCode,
                request.SortBy,
                request.SortOrder,
                request.PageNumber,
                request.PageSize
            });
            if (string.IsNullOrEmpty(jsonString))
            {
                _appInsightsLoggerHelper.LogWarning($"FilterInvoiceDocumentsAsync completed with empty json doctype: {documentType} at {DateTime.Now} with customerAccount {request.CustomerAccount}.");
                documentSearchResponse = documentType.Equals('S') ? new InvoiceSearchResponse() : new CreditNoteSearchResponse();
                return documentSearchResponse;
            }
            var result = JsonSerializer.Deserialize<InvoiceSearchResponse>(jsonString);
            documentSearchResponse = documentType.Equals('S') ? result!
                : new CreditNoteSearchResponse { Pages = result!.Pages, CreditNotes = result!.Invoices };
            _appInsightsLoggerHelper.LogInformation($"FilterInvoiceDocumentsAsync completed for doctype: {documentType} at {DateTime.Now} with customerAccount {request.CustomerAccount}.");
            return documentSearchResponse;
        }

        public async Task<DocumentSearchResponse?> SearchInvoiceByFilterParamAsync(InvoiceSearchFilterRequest request, char documentType = 'S', CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"SearchInvoiceByFilterParamAsync started for doctype: {documentType} at {DateTime.Now} with customerAccount {request.CustomerAccount}.");
            DocumentSearchResponse documentSearchResponse;

            var minAgeHours = _typeSettings.DownloadDelayHours;
            var jsonString = await _dbExecutor.ExecuteSingleAsync<string>(StoredProcedures.GetInvoiceSearchByFilterParams, new
            {
                request.CustomerAccount,
                documentType,
                request.InvoiceStatus,
                request.SearchParam,
                minAgeHours,
                request.SortBy,
                request.SortOrder,
                request.PageNumber,
                request.PageSize
            });
            if (string.IsNullOrEmpty(jsonString))
            {
                _appInsightsLoggerHelper.LogWarning($"SearchInvoiceByFilterParamAsync completed with empty json doctype: {documentType} at {DateTime.Now} with customerAccount {request.CustomerAccount}.");
                documentSearchResponse = documentType.Equals('S') ? new InvoiceSearchResponse() : new CreditNoteSearchResponse();
                return documentSearchResponse;
            }
            var result = JsonSerializer.Deserialize<InvoiceSearchResponse>(jsonString);
            documentSearchResponse = documentType.Equals('S') ? result!
                : new CreditNoteSearchResponse { Pages = result!.Pages, CreditNotes = result!.Invoices };
            _appInsightsLoggerHelper.LogInformation($"SearchInvoiceByFilterParamAsync completed for doctype: {documentType} at {DateTime.Now} with customerAccount {request.CustomerAccount}.");
            return documentSearchResponse;
        }
    }
}
