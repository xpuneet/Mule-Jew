﻿using Azure.Core;
using Azure.Identity;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Services;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.Handlers;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Common.Data.DependencyInjection
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddSharedDatabase(this IServiceCollection services, string connectionString, string keyname)
        {
            services.AddKeyedScoped<IDbExecutor>(keyname, (sp, key) =>
            {
                return new DbExecutor(connectionString, sp.GetRequiredService<IAppInsightsLoggerHelper>());
            });

            return services;
        }

        public static IServiceCollection AddTradeAccountServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<ITradeAccountsService, TradeAccountsService>();
            services.AddScoped<ITradeAccountPaymentService, TradeAccountPaymentService>();
            services.AddScoped<IStatementService, StatementService>();
            services.AddScoped<ITradeAccountInvoicesService, TradeAccountInvoiceService>();
            services.AddScoped<IPreferredBranchService, PreferredBranchService>();

            var blobStorageSettings = configuration.GetSection("BlobStorage").Get<BlobStorage>()!;

            services.AddSingleton(new BlobServiceClient(new Uri(blobStorageSettings.StorageAccountUrl), new DefaultAzureCredential()));
            services.Configure<DownloadSettings>(configuration.GetSection("DownloadSettings"));

            services.AddHttpClient<IColumbusWebService, ColumbusWebService>();
            services.AddScoped<IColumbusInvoiceDownloadService, ColumbusInvoiceDownloadService>();
            services.AddScoped<IColumbusStatementDownloadService, ColumbusStatementDownloadService>();

            services.AddKeyedScoped<IDocumentMetadataResolver<long, string>, StatementMetadataResolver>("Statement");
            services.AddHttpClient<IStatementDownloadService, StatementDownloadService>("StatementDownload");
            services.AddKeyedScoped<IDocumentMetadataResolver<string, string>, InvoiceMetaDataResolver>("Invoice");
            services.AddHttpClient<IInvoiceDownloadService, InvoiceDownloadService>("InvoiceDownload");

            return services;
        }

        /// <summary>
        /// Registers the Workday-to-Concur feature boundary
        /// </summary>
        /// <param name="services">Service collection</param>
        /// <param name="configuration">Application configuration</param>
        /// <returns>The supplied service collection</returns>
        public static IServiceCollection AddWorkdayConcur(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<WorkdayConcurOptions>(configuration.GetSection(WorkdayConcurOptions.SectionName));
            services.AddScoped<IWorkdayConcurOrchestrationService, WorkdayConcurOrchestrationService>();
            services.AddScoped<IWorkdayConcurStateService, WorkdayConcurStateService>();
            services.AddScoped<IFileTransferConfigurationService, FileTransferConfigurationService>();
            services.AddScoped<IWorkdayConcurTm1Service, WorkdayConcurTm1Service>();
            services.AddScoped<IWorkdayConcurBlobServiceClientFactory, WorkdayConcurBlobServiceClientFactory>();
            services.AddScoped<IWorkdayConcurBlobClient, WorkdayConcurBlobClient>();
            services.AddScoped<IWorkdaySoapRequestFactory, WorkdaySoapRequestFactory>();
            services.AddScoped<IWorkdayWorkerResponseParser, WorkdayWorkerResponseParser>();
            services.AddScoped<IWorkdayConcurCsvService, WorkdayConcurCsvService>();
            services.AddScoped<IWorkdayConcurTransformationService, WorkdayConcurTransformationService>();
            services.AddScoped<IConcurPgpEncryptionService, ConcurPgpEncryptionService>();
            services.AddScoped<IWorkdayConcurDeliveryService, WorkdayConcurDeliveryService>();
            services.AddScoped<IWorkdayConcurHousekeepingService, WorkdayConcurHousekeepingService>();
            services.AddHttpClient<IWorkdayWorkersClient, WorkdayWorkersClient>((serviceProvider, httpClient) =>
            {
                var options = serviceProvider.GetRequiredService<IOptions<WorkdayConcurOptions>>().Value;
                if (!string.IsNullOrWhiteSpace(options.WorkdayEndpoint))
                {
                    httpClient.BaseAddress = new Uri(options.WorkdayEndpoint, UriKind.Absolute);
                }

                if (options.WorkdayRequestTimeoutSeconds > 0)
                {
                    httpClient.Timeout = TimeSpan.FromSeconds(options.WorkdayRequestTimeoutSeconds);
                }
            });
            services.AddHttpClient<ISynapsePipelineClient, SynapsePipelineClient>();
            services.AddHttpClient<IConcurSynapsePipelineClient, SynapsePipelineClient>();
            services.TryAddSingleton<TokenCredential>(_ => new DefaultAzureCredential());

            services.AddSingleton<TimeProvider>(TimeProvider.System);

            return services;
        }
    }
}
