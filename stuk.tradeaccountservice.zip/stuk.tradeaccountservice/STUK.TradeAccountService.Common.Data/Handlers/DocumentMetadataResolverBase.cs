﻿using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Handlers
{
    public abstract class DocumentMetadataResolverBase<TId, TId2> : IDocumentMetadataResolver<TId, TId2>
    {
        protected readonly IDbExecutor _dbExecutor;
        private readonly DocumentTypeDownloadSettings _typeSettings;

        protected DocumentMetadataResolverBase(IDbExecutor dbExecutor, IOptions<DownloadSettings> settings)
        {
            _dbExecutor = dbExecutor;
            _typeSettings = settings.Value[DocumentType];
        }

        public abstract string DocumentType { get; }
        public string ContainerName => _typeSettings.ContainerName;
        public string? FilePrepareRequestUrl => _typeSettings.FilePrepareUrl;
        public abstract string DefaultFileName { get; }
        public int TokenRefreshIntervalHours => _typeSettings.TokenRefreshIntervalHours;
        public abstract TId ParseIdentifier(string identifier);
        public abstract TId2? ParseParam1(string? param1);
        public abstract Task<DocumentMetadata?> GetMetadataAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default);
        public abstract Task RequestDocumentAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default);

        public async Task<DocumentDownloadCacheEntry?> GetCacheByIdentifierAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default)
        {
            return await _dbExecutor.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                StoredProcedures.GetDocumentDownloadCacheDetails,
                new { Identifier = identifier!.ToString(), DocumentType, AdditionalParam = param1?.ToString() });
        }

        public async Task<(Guid Token, DateTimeOffset ExpiresOn)> InsertCacheAsync(TId identifier, TId2? param1, string downloadStatus, CancellationToken cancellationToken = default)
        {
            var result = await _dbExecutor.ExecuteSingleAsync<dynamic>(
                StoredProcedures.InsertDocumentDownloadCache,
                new { Identifier = identifier!.ToString(), AdditionalParam = param1?.ToString(), DocumentType, downloadStatus, expiryHours = TokenRefreshIntervalHours });
            return (Token: result?.token, ExpiresOn: result?.expiresOn);
        }

        public async Task<DocumentDownloadCacheEntry?> GetCacheByTokenAsync(Guid token, CancellationToken cancellationToken = default)
        {
            return await _dbExecutor.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                StoredProcedures.GetDocumentDownloadCacheDetails,
                new { token });
        }

        public async Task DeleteCacheByTokenAsync(Guid token, CancellationToken cancellationToken = default)
        {
            await _dbExecutor.ExecuteSingleAsync<int>(
                StoredProcedures.DeleteDocumentDownloadCacheByToken,
                new { token });
        }
    }
}
