﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.ComponentModel.DataAnnotations;

namespace STUK.TradeAccountService.Common.Data.Handlers
{
    public class InvoiceMetaDataResolver([FromKeyedServices("OrderDb")] IDbExecutor dbExecutor,
                IOptions<DownloadSettings> settings,
                IAppInsightsLoggerHelper appInsightsLoggerHelper,
                IColumbusInvoiceDownloadService columbusInvoiceDownloadService) : DocumentMetadataResolverBase<string, string>(dbExecutor, settings)
    {
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));
        private readonly IColumbusInvoiceDownloadService _columbusInvoiceDownloadService = columbusInvoiceDownloadService ?? throw new ArgumentNullException(nameof(columbusInvoiceDownloadService));

        public override string DocumentType => "Invoice";
        public override string DefaultFileName => "Invoice.pdf";

        public override string ParseIdentifier(string identifier) => identifier;

        public override string? ParseParam1(string? param1) => param1;

        public override async Task<DocumentMetadata?> GetMetadataAsync(string identifier, string? param1, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetMetadataAsync started for invoice at {DateTime.Now} for identifier {identifier}.");

            var result = await _dbExecutor.ExecuteSingleAsync<InvoiceHeaderMetadata>(
                StoredProcedures.GetInvoiceMetadataByStandardInvoiceNo,
                new { standardInvoiceNo = identifier, branchCode= param1 ?? throw new ValidationException("branchCode is mandatory") });

            if (result == null)
            {
                _appInsightsLoggerHelper.LogWarning($"GetMetadataAsync No metadata found for invoice for identifier {identifier}.");
                return null;
            }

            _appInsightsLoggerHelper.LogInformation($"GetMetadataAsync completed for invoice at {DateTime.Now} for identifier {identifier}.");

            return new DocumentMetadata
            {
                BlobUri = result.BlobUri,
                FileName = result.CalculatedFileName
            };
        }

        public override async Task RequestDocumentAsync(string identifier, string? param1, CancellationToken cancellationToken = default)
        {
            await _columbusInvoiceDownloadService
                .DownloadInvoiceByStandardInvoiceNumberAndBranchCodeAsync(identifier, param1 ?? throw new ValidationException("branchCode is mandatory"));
        }
    }
}
