﻿using Azure.Storage.Blobs;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Data.Handlers
{
    public class DocumentDownloadHandler<TId, TId2>(
        IDocumentMetadataResolver<TId, TId2> resolver,
        HttpClient httpClient,
        BlobServiceClient blobServiceClient,
        IAppInsightsLoggerHelper appInsightsLoggerHelper) : IDocumentDownloadHandler<TId, TId2>
    {
        private readonly IDocumentMetadataResolver<TId, TId2> _resolver = resolver ?? throw new ArgumentNullException(nameof(resolver));
        private readonly HttpClient _httpClient = httpClient;
        private readonly BlobServiceClient _blobServiceClient = blobServiceClient ?? throw new ArgumentNullException(nameof(blobServiceClient));
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));

        public async Task<DocumentDownloadRequestResponse> RequestDownloadAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"RequestDownloadAsync started for {_resolver.DocumentType} at {DateTime.Now} for identifier {identifier}.");

            var existingCache = await _resolver.GetCacheByIdentifierAsync(identifier, param1, cancellationToken);

            if (existingCache != null && !existingCache.IsExpired)
            {
                _appInsightsLoggerHelper.LogInformation($"RequestDownloadAsync found existing pending token for identifier {identifier} for {_resolver.DocumentType}.");
                return new DocumentDownloadRequestResponse
                {
                    Token = existingCache.Token,
                    Message = "A download request is already active.",
                    ExpiresAt = existingCache.ExpiresOn
                };
            }

            if (existingCache is { IsExpired: true })
            {
                _appInsightsLoggerHelper.LogInformation($"RequestDownloadAsync expired token found for {_resolver.DocumentType}.", $"Expired token deleted by database for identifier {identifier}. Re-requesting document.");
            }

            var metadata = await _resolver.GetMetadataAsync(identifier, param1, cancellationToken);

            if (metadata == null)
            {
                throw new KeyNotFoundException($"{_resolver.DocumentType} not found for {identifier}");
            }

            if (string.IsNullOrEmpty(metadata.BlobUri))
            {
                _appInsightsLoggerHelper.LogInformation($"RequestDownloadAsync calling external service for {_resolver.DocumentType}.", $"BlobUri is empty for identifier {identifier}. Requesting {_resolver.DocumentType} file from external service.");
                await _resolver.RequestDocumentAsync(identifier, param1, cancellationToken);
            }

            var downloadStatus = string.IsNullOrEmpty(metadata.BlobUri) ? "Pending" : "Ready";

            var (Token, ExpiresOn) = await _resolver.InsertCacheAsync(identifier, param1, downloadStatus, cancellationToken);
            if (Token == Guid.Empty)
            {
                throw new InvalidOperationException($"Token generation failed for {_resolver.DocumentType} and identifier {identifier}.");
            }

            _appInsightsLoggerHelper.LogInformation($"RequestDownloadAsync completed for {_resolver.DocumentType}.", $"Token generated with status {downloadStatus} for identifier {identifier}.");

            return new DocumentDownloadRequestResponse
            {
                Token = Token,
                Message = downloadStatus == "Ready"
                    ? "The file is ready for download."
                    : "Download request submitted. The file is being prepared.",
                ExpiresAt = ExpiresOn
            };
        }

        public async Task<DocumentDownloadResponse> DownloadAsync(Guid token, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"DownloadAsync started for {_resolver.DocumentType} at {DateTime.Now} for token {token}.");

            var cacheEntry = await _resolver.GetCacheByTokenAsync(token, cancellationToken);

            if (cacheEntry == null)
            {
                throw new KeyNotFoundException($"Invalid or expired token for {_resolver.DocumentType} download");
            }

            if (cacheEntry.IsExpired)
            {
                _appInsightsLoggerHelper.LogInformation($"DownloadAsync token expired for {_resolver.DocumentType}.", $"Expired token {token} deleted by database for identifier {cacheEntry.Identifier}.");
                return new DocumentDownloadResponse { Message = "The token has expired. Please create a new request for token." };
            }

            var metadata = await _resolver.GetMetadataAsync(_resolver.ParseIdentifier(cacheEntry.Identifier), _resolver.ParseParam1(cacheEntry.AdditionalParam), cancellationToken);

            if (metadata == null || string.IsNullOrEmpty(metadata.BlobUri))
            {
                _appInsightsLoggerHelper.LogInformation($"DownloadAsync file not ready for {_resolver.DocumentType}.", $"BlobUri not available yet for identifier {cacheEntry.Identifier}.");
                return new DocumentDownloadResponse { Message = "The file is not ready for download yet. Please try again later." };
            }

            _appInsightsLoggerHelper.LogInformation($"DownloadAsync downloading {_resolver.DocumentType} file from {metadata.BlobUri}.");

            var blobClient = _blobServiceClient
               .GetBlobContainerClient(_resolver.ContainerName)
               .GetBlobClient(metadata.BlobUri);
            var blobDownload = await blobClient.DownloadStreamingAsync();

            await _resolver.DeleteCacheByTokenAsync(token, cancellationToken);

            _appInsightsLoggerHelper.LogInformation($"DownloadAsync downloaded file and deleted cache entry for token {token} for {_resolver.DocumentType}.");

            return new DocumentDownloadResponse
            {
                FileName = metadata.FileName ?? _resolver.DefaultFileName,
                ContentType = blobDownload.Value.Details.ContentType ?? "application/octet-stream",
                FileContent = blobDownload.Value.Content
            };
        }

        private async Task RequestFilePreparation(string fileName)
        {
            var requestUrl = $"{_resolver.FilePrepareRequestUrl}?fileName={Uri.EscapeDataString(fileName)}";
            var response = await _httpClient.PostAsync(requestUrl, null);
            response.EnsureSuccessStatusCode();
            _appInsightsLoggerHelper.LogInformation($"File preparation request sent for {_resolver.DocumentType}.", $"File preparation request sent for {fileName}.");
        }
    }
}
