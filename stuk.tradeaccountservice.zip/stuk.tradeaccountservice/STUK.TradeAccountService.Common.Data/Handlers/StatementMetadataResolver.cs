﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;

namespace STUK.TradeAccountService.Common.Data.Handlers
{
    public class StatementMetadataResolver(
        [FromKeyedServices("OrderDb")] IDbExecutor dbExecutor,
        IOptions<DownloadSettings> settings,
        IAppInsightsLoggerHelper appInsightsLoggerHelper,
        IColumbusStatementDownloadService columbusStatementDownloadService) : DocumentMetadataResolverBase<long, string>(dbExecutor, settings)
    {
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));
        private readonly IColumbusStatementDownloadService _columbusStatementDownloadService = columbusStatementDownloadService ?? throw new ArgumentNullException(nameof(columbusStatementDownloadService));

        public override string DocumentType => "Statement";
        public override string DefaultFileName => "Statement.pdf";

        public override long ParseIdentifier(string identifier) => long.Parse(identifier);
        public override string? ParseParam1(string? param1) => param1;

        public override async Task<DocumentMetadata?> GetMetadataAsync(long identifier, string? param1, CancellationToken cancellationToken = default)
        {
            _appInsightsLoggerHelper.LogInformation($"GetMetadataAsync started for statement at {DateTime.Now} for identifier {identifier}.");
            var result = await _dbExecutor.ExecuteSingleAsync<StatementHeaderMetadata>(
                StoredProcedures.GetStatementMetadataByHeaderId,
                new { StatementHeaderId = identifier });

            if (result == null)
            {
                _appInsightsLoggerHelper.LogWarning($"GetMetadataAsync metadata not found for statement for identifier {identifier}.");
                return null;
            }

            _appInsightsLoggerHelper.LogInformation($"GetMetadataAsync completed for statement at {DateTime.Now} for identifier {identifier}.");
            return new DocumentMetadata
            {
                BlobUri = result.BlobUri,
                FileName = result.CalculatedFileName
            };
        }

        public override async Task RequestDocumentAsync(long identifier, string? param1, CancellationToken cancellationToken = default)
        {
            await _columbusStatementDownloadService
                    .DownloadStatementByStatementHeaderIdAsync(identifier);
        }
    }
}
