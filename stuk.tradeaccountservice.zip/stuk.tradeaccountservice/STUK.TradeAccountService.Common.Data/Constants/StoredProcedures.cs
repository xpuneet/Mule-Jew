﻿namespace STUK.TradeAccountService.Common.Data.Constants
{
    public class StoredProcedures
    {
        public const string GetStatementHeaderMetaDataByStatementHeaderId = "GetStatementHeaderMetaDataByStatementHeaderId";
        public const string GetStatementHeaderByStatementHeaderId = "GetStatementHeaderByStatementHeaderId";
        public const string GetInvoiceHeaderByStandardInvoiceNumberAndBranchCode = "GetInvoiceHeaderByStandardInvoiceNumberAndBranchCode";
        public const string GetUnsynchronizedInvoices = "GetUnsynchronizedInvoices";
        public const string UpdateInvoiceHeader = "UpdateInvoiceHeader";
        public const string GetUnsynchronizedStatements = "GetUnsynchronizedStatements";
        public const string UpdateStatementHeaderMetadata = "UpdateStatementHeaderMetadata";
        public const string GetAccountDetailsByAccountCode = "GetAccountDetailsByAccountCode";
        public const string GetAccountsDetailsBySessionId = "GetAccountsDetailsBySessionId";
        public const string GetPaymentsByReference = "GetPaymentsByReference";
        public const string InsertPaymentInfo = "InsertPaymentInfo";
        public const string GetInvoiceDetailsByStandardInvoiceNo = "GetInvoiceDetailsByStandardInvoiceNo";
        public const string GetInvoiceSearchByAccountCode = "GetInvoiceSearchByAccountCode";
        public const string GetInvoiceSearchByFilterParams = "GetInvoiceSearchByFilterParams";

        public const string GetStatementsByAccountCode = "GetStatementsByAccountCode";
        public const string InsertDocumentDownloadCache = "InsertDocumentDownloadCache";
        public const string GetDocumentDownloadCacheDetails = "GetDocumentDownloadCacheDetails";
        public const string DeleteDocumentDownloadCacheByToken = "DeleteDocumentDownloadCacheByToken";

        public const string GetStatementMetadataByHeaderId = "GetStatementMetadataByHeaderId";
        public const string GetInvoiceMetadataByStandardInvoiceNo = "GetInvoiceMetadataByStandardInvoiceNo";
        public const string GetValidateAccount = "GetValidateAccount";
        public const string GetAccountCreditLimit = "GetAccountCreditLimit";
        public const string InsertStatementFromBlob = "InsertStatementFromBlob";
        public const string GetPendingPaymentsReference = "GetPendingPaymentsReference";
        public const string UpdatePendingPaymentsReference = "UpdatePendingPaymentsReference";
        public const string GetAndSetPreferredBranch = "GetAndSetPreferredBranch";       

        public const string RegisterConsolidatedSalesSourceItem = "dbo.RegisterConsolidatedSalesSourceItem";
        public const string ClaimNextConsolidatedSalesSourceItem = "dbo.ClaimNextConsolidatedSalesSourceItem";
        public const string RecordConsolidatedSalesSourceFirstRead = "dbo.RecordConsolidatedSalesSourceFirstRead";
        public const string CompleteConsolidatedSalesSourceItem = "dbo.CompleteConsolidatedSalesSourceItem";
        public const string FailConsolidatedSalesSourceItem = "dbo.FailConsolidatedSalesSourceItem";
        public const string AwaitConsolidatedSalesSourceCorrection = "dbo.AwaitConsolidatedSalesSourceCorrection";
        public const string CommitConsolidatedSalesInvoice = "dbo.CommitConsolidatedSalesInvoice";
        public const string GetConsolidatedSalesInvoiceByNumber = "dbo.GetConsolidatedSalesInvoiceByNumber";
        public const string ClaimNextConsolidatedSalesforceWork = "dbo.ClaimNextConsolidatedSalesforceWork";
        public const string RenewConsolidatedSalesforceWorkLease = "dbo.RenewConsolidatedSalesforceWorkLease";
        public const string CompleteConsolidatedSalesforceLine = "dbo.CompleteConsolidatedSalesforceLine";
        public const string FailConsolidatedSalesforceLine = "dbo.FailConsolidatedSalesforceLine";
        public const string CompleteConsolidatedSalesforceWork = "dbo.CompleteConsolidatedSalesforceWork";
        public const string FailConsolidatedSalesforceWork = "dbo.FailConsolidatedSalesforceWork";
        public const string InsertConsolidatedSalesforceAttempt = "dbo.InsertConsolidatedSalesforceAttempt";
        public const string ClaimNextConsolidatedSalesReconciliationWork = "dbo.ClaimNextConsolidatedSalesReconciliationWork";
        public const string ReconcileInvoiceHeaderConsolidatedSales = "dbo.ReconcileInvoiceHeaderConsolidatedSales";
        public const string CompleteConsolidatedSalesReconciliationWork = "dbo.CompleteConsolidatedSalesReconciliationWork";
        public const string DeferConsolidatedSalesReconciliationWork = "dbo.DeferConsolidatedSalesReconciliationWork";
        public const string FailConsolidatedSalesReconciliationWork = "dbo.FailConsolidatedSalesReconciliationWork";
        public const string RequeueConsolidatedSalesWork = "dbo.RequeueConsolidatedSalesWork";
        public const string GetConsolidatedSalesforceWorkDetails = "dbo.GetConsolidatedSalesforceWorkDetails";
        public const string RenewConsolidatedSalesSourceItemLease = "dbo.RenewConsolidatedSalesSourceItemLease";
        public const string CreateConsolidatedSalesExportRun = "dbo.CreateConsolidatedSalesExportRun";
        public const string ClaimNextConsolidatedSalesExportRun = "dbo.ClaimNextConsolidatedSalesExportRun";
        public const string RenewConsolidatedSalesExportRunLease = "dbo.RenewConsolidatedSalesExportRunLease";
        public const string AppendConsolidatedSalesExportPage = "dbo.AppendConsolidatedSalesExportPage";
        public const string CompleteConsolidatedSalesExportExtraction = "dbo.CompleteConsolidatedSalesExportExtraction";
        public const string FailConsolidatedSalesExportExtraction = "dbo.FailConsolidatedSalesExportExtraction";
        public const string ClaimNextConsolidatedSalesExportDestination = "dbo.ClaimNextConsolidatedSalesExportDestination";
        public const string RenewConsolidatedSalesExportDestinationLease = "dbo.RenewConsolidatedSalesExportDestinationLease";
        public const string CompleteConsolidatedSalesExportDestination = "dbo.CompleteConsolidatedSalesExportDestination";
        public const string FailConsolidatedSalesExportDestination = "dbo.FailConsolidatedSalesExportDestination";
        public const string RequeueConsolidatedSalesExportDestination = "dbo.RequeueConsolidatedSalesExportDestination";
        public const string GetConsolidatedSalesExportRows = "dbo.GetConsolidatedSalesExportRows";
        public const string CreateWorkdayConcurRun = "dbo.CreateWorkdayConcurRun";
        public const string GetIncompleteWorkdayConcurRun = "dbo.GetIncompleteWorkdayConcurRun";
        public const string RenewWorkdayConcurRunLease = "dbo.RenewWorkdayConcurRunLease";
        public const string UpdateWorkdayConcurRunStage = "dbo.UpdateWorkdayConcurRunStage";
        public const string FailWorkdayConcurRun = "dbo.FailWorkdayConcurRun";
        public const string ReleaseWorkdayConcurRunLease = "dbo.ReleaseWorkdayConcurRunLease";
        public const string CompleteWorkdayConcurNoDataRun = "dbo.CompleteWorkdayConcurNoDataRun";
        public const string CommitWorkdayConcurRun = "dbo.CommitWorkdayConcurRun";
        public const string GetFileTransferConnectionByIntegrationKey = "dbo.GetFTConnectionByIntegrationKey";
        public const string GetSftpConnectionConfigBySourceId = "dbo.GetSFTPConnectionConfigBySourceID";
        public const string GetBlobConnectionConfigByDestinationId = "dbo.GetBlobConnectionConfigByDestinationID";
        public const string GetBlobConnectionConfigBySourceId = "dbo.GetBlobConnectionConfigBySourceID";
        public const string GetSftpConnectionConfigByDestinationId = "dbo.GetSFTPConnectionConfigByDestinationID";
    }
}
