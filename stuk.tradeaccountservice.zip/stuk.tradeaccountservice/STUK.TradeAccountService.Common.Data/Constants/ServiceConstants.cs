﻿namespace STUK.TradeAccountService.Common.Data.Constants
{
    public static class ServiceConstants
    {
        public const string TradeAccountServiceName = "TradeAccountService";
    }
}
