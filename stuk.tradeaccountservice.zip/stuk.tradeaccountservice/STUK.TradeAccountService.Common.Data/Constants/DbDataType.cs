﻿namespace STUK.TradeAccountService.Common.Data.Constants
{
    public class DbDataType
    {
        //Table types
        public const string udt_StatementHeader = "udt_StatementHeader";
        public const string udt_StatementMetadata = "udt_StatementMetadata";
        public const string udt_ErpPaymentReference = "udt_ErpPaymentReference";
    }
}
