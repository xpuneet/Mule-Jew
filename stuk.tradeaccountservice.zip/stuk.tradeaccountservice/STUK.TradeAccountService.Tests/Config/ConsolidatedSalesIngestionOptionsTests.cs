using STUK.TradeAccountService.Common.Contracts.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the default HX Consolidated Sales ingestion settings
    /// </summary>
    public class ConsolidatedSalesIngestionOptionsTests
    {
        [Fact]
        public void Given_NoConfiguration_When_OptionsAreCreated_Should_UseOperationalDefaults()
        {
            var options = new ConsolidatedSalesIngestionOptions();

            Assert.Equal("HX", options.SourceSystem);
            Assert.Equal(".con.xml", options.FileSuffix);
            Assert.Equal("datalake", options.ContainerName);
            Assert.Equal("hx/delivery-staging", options.ReadyPrefix);
            Assert.Equal(10, options.MaximumFilesPerRun);
            Assert.Equal(900, options.LeaseDurationSeconds);
            Assert.Equal(300, options.LeaseRenewalIntervalSeconds);
            Assert.Equal(30, options.RetryDelaySeconds);
            Assert.Equal(2, options.MaximumRetryCount);
        }
    }
}
