using Microsoft.Extensions.Configuration;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Salesforce.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the deployable Consolidated Sales configuration hierarchy
    /// </summary>
    public class ConsolidatedSalesConfigurationSectionTests
    {
        [Fact]
        public void ConfigurationSections_Should_UseOneConsolidatedSalesHierarchy()
        {
            Assert.Equal("ConsolidatedSales:Ingestion", ConsolidatedSalesIngestionOptions.SectionName);
            Assert.Equal("ConsolidatedSales:Reconciliation", ConsolidatedSalesReconciliationOptions.SectionName);
            Assert.Equal("ConsolidatedSales:SalesforceSync", SalesforceSyncOptions.SectionName);
            Assert.Equal("ConsolidatedSales:Export:Phocas", PhocasBlobStagingOptions.SectionName);
            Assert.Equal("ConsolidatedSales:Export:DataLake", ConsolidatedSalesDataLakeOptions.SectionName);
            Assert.Equal("Salesforce", SalesforceOptions.SectionName);
        }

        [Fact]
        public void Given_FourExportRoutingValues_When_Binding_Should_PopulateFocusedOptions()
        {
            var values = new Dictionary<string, string?>
            {
                ["ConsolidatedSales:Export:Phocas:BlobStagingPath"] = "validation/phocas",
                ["ConsolidatedSales:Export:Phocas:FileActionId"] = "42",
                ["ConsolidatedSales:Export:DataLake:ServiceUri"] = "https://validation.dfs.core.windows.net",
                ["ConsolidatedSales:Export:DataLake:FileSystem"] = "validation"
            };
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(values)
                .Build();

            var phocas = configuration
                .GetSection(PhocasBlobStagingOptions.SectionName)
                .Get<PhocasBlobStagingOptions>();
            var dataLake = configuration
                .GetSection(ConsolidatedSalesDataLakeOptions.SectionName)
                .Get<ConsolidatedSalesDataLakeOptions>();

            Assert.NotNull(phocas);
            Assert.Equal("validation/phocas", phocas.BlobStagingPath);
            Assert.Equal("42", phocas.FileActionId);
            Assert.NotNull(dataLake);
            Assert.Equal("https://validation.dfs.core.windows.net", dataLake.ServiceUri);
            Assert.Equal("validation", dataLake.FileSystem);
        }
    }
}
