using STUK.TradeAccountService.Common.Contracts.Config;
using System.Text.Json;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the deployable Workday-to-Concur configuration contract
    /// </summary>
    public class WorkdayConcurDeploymentConfigurationTests
    {
        private const string DeploymentFixtureFolder = "Fixtures/Deployment";
        private const string FunctionSettingsFile = "function-appsettings.json";
        private const string PipelineFile = "azureDeploy-CD.yml";
        private const string WorkdayPasswordSetting = "WorkdayPassword";
        private const string ConcurPublicKeySetting = "ConcurPgpPublicKey";
        private static readonly string[] EnvironmentSettings =
        {
            nameof(WorkdayConcurOptions.Enabled),
            nameof(WorkdayConcurOptions.SynapseWorkspaceName),
            nameof(WorkdayConcurOptions.Tm1PickupIntegrationKeyId),
            nameof(WorkdayConcurOptions.Tm1PickupActionName),
            nameof(WorkdayConcurOptions.WorkdayEndpoint),
            nameof(WorkdayConcurOptions.WorkdayUsername),
            nameof(WorkdayConcurOptions.ConcurBlobServiceEndpoint),
            nameof(WorkdayConcurOptions.ConcurBlobContainerName),
            nameof(WorkdayConcurOptions.ConcurPgpKeyId),
            nameof(WorkdayConcurOptions.ConcurDeliveryIntegrationKeyId),
            nameof(WorkdayConcurOptions.ConcurDeliveryActionName)
        };
        private static readonly string[] NonProductionOnlySettings =
        {
            nameof(WorkdayConcurOptions.ConcurSynapseWorkspaceName),
            nameof(WorkdayConcurOptions.ConcurDestinationPath)
        };

        /// <summary>
        /// Verifies that packaged defaults are safe and contain no environment-owned values
        /// </summary>
        [Fact]
        public void Given_PackagedSettings_When_Read_Should_DefaultToDisabledWithoutSecrets()
        {
            using var document = JsonDocument.Parse(File.ReadAllText(GetFixturePath(FunctionSettingsFile)));

            var root = document.RootElement;
            var workdayConcur = root.GetProperty(WorkdayConcurOptions.SectionName);

            Assert.False(workdayConcur.GetProperty(nameof(WorkdayConcurOptions.Enabled)).GetBoolean());
            Assert.Equal("0 0 7 * * *", workdayConcur.GetProperty(nameof(WorkdayConcurOptions.Cron)).GetString());
            Assert.Equal("pl-concur-parent", workdayConcur.GetProperty(nameof(WorkdayConcurOptions.ConcurTransformationPipelineName)).GetString());
            Assert.Equal(string.Empty, workdayConcur.GetProperty(WorkdayPasswordSetting).GetString());
            Assert.Equal(string.Empty, workdayConcur.GetProperty(ConcurPublicKeySetting).GetString());
            Assert.Equal(string.Empty, root.GetProperty("ConnectionStrings").GetProperty("FileTransferDb").GetString());
        }

        /// <summary>
        /// Verifies that every deployment environment receives the complete variable-driven Workday configuration
        /// </summary>
        [Fact]
        public void Given_DeploymentPipeline_When_Read_Should_Configure_Each_Environment()
        {
            var pipeline = File.ReadAllText(GetFixturePath(PipelineFile));
            var prodStageStart = pipeline.IndexOf("# === PROD STAGE ===", StringComparison.Ordinal);
            Assert.True(prodStageStart > 0);

            var nonProductionStages = pipeline[..prodStageStart];
            var productionStage = pipeline[prodStageStart..];

            foreach (var setting in EnvironmentSettings)
            {
                Assert.Equal(2, CountOccurrences(nonProductionStages, $"WorkdayConcur__{setting}"));
                Assert.Equal(1, CountOccurrences(productionStage, $"WorkdayConcur__{setting}"));
            }

            foreach (var setting in NonProductionOnlySettings)
            {
                Assert.Equal(2, CountOccurrences(nonProductionStages, $"WorkdayConcur__{setting}"));
                Assert.DoesNotContain($"WorkdayConcur__{setting}", productionStage, StringComparison.Ordinal);
            }

            Assert.Equal(2, CountOccurrences(nonProductionStages, "Configure Workday Concur App Settings"));
            Assert.Equal(2, CountOccurrences(nonProductionStages, "\"name\": \"ConnectionStrings__FileTransferDb\""));
            Assert.Equal(1, CountOccurrences(productionStage, "Configure Workday Concur App Settings"));
            Assert.Equal(1, CountOccurrences(productionStage, "\"name\": \"ConnectionStrings__FileTransferDb\""));
            Assert.Equal(3, CountOccurrences(pipeline, "AzureWebJobs.WorkdayConcurTimerFunction.Disabled"));
        }

        /// <summary>
        /// Verifies that Key Vault-owned material and Mule endpoints are absent from deployment configuration
        /// </summary>
        [Fact]
        public void Given_DeploymentPipeline_When_Read_Should_ExcludeSecureAndMuleSettings()
        {
            var pipeline = File.ReadAllText(GetFixturePath(PipelineFile));

            Assert.DoesNotContain($"WorkdayConcur__{WorkdayPasswordSetting}", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain($"WorkdayConcur__{ConcurPublicKeySetting}", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__Cron", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__LeaseDurationSeconds", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__LeaseRenewalIntervalSeconds", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__SynapsePollIntervalSeconds", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__SynapseRunTimeoutSeconds", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__ConcurTransformationPipelineName", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__WorkdayPageSize", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__WorkdayDetailBatchSize", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__WorkdayRequestTimeoutSeconds", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__ConcurLedgerCode", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("WorkdayConcur__ConcurApprovalDefault", pipeline, StringComparison.Ordinal);
            Assert.DoesNotContain("mulesoft", pipeline, StringComparison.OrdinalIgnoreCase);
            Assert.DoesNotContain("anypoint", pipeline, StringComparison.OrdinalIgnoreCase);
        }

        private static string GetFixturePath(string fileName)
        {
            return Path.Combine(AppContext.BaseDirectory, DeploymentFixtureFolder, fileName);
        }

        private static int CountOccurrences(string value, string expected)
        {
            return value.Split(expected, StringSplitOptions.None).Length - 1;
        }
    }
}
