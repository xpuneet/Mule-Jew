using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace STUK.TradeAccountService.Tests.Config
{
    public class ColumbusDeploymentConfigurationTests
    {
        [Fact]
        public void Given_Function_App_Settings_When_Loaded_Should_Contain_The_First_Read_Fallback_Defaults()
        {
            var appSettingsPath = Path.Combine(GetRepositoryRoot(), "STUK.TradeAccountService.Functions", "appsettings.json");
            using var document = JsonDocument.Parse(File.ReadAllText(appSettingsPath));

            var columbus = document.RootElement.GetProperty("Columbus");

            Assert.True(columbus.GetProperty("EnableSalesforceCooloff").GetBoolean());
            Assert.Equal(48, columbus.GetProperty("SalesforceCooloffHours").GetInt32());
        }

        [Fact]
        public void Given_The_Deployment_Pipeline_When_Loaded_Should_Use_Safe_DEV_And_QA_Defaults_And_Map_PROD()
        {
            var pipelinePath = Path.Combine(GetRepositoryRoot(), "STUK.TradeAccountService.Functions", "Deploy", "azureDeploy-CD.yml");
            var pipeline = File.ReadAllText(pipelinePath);
            var prodStageStart = pipeline.IndexOf("# === PROD STAGE ===", StringComparison.Ordinal);
            Assert.True(prodStageStart > 0);

            var nonProductionStages = pipeline[..prodStageStart];
            var productionStage = pipeline[prodStageStart..];

            Assert.Equal(2, Regex.Matches(nonProductionStages, "\"name\": \"Columbus__EnableSalesforceCooloff\", \"value\": \"true\"").Count);
            Assert.Equal(2, Regex.Matches(nonProductionStages, "\"name\": \"Columbus__SalesforceCooloffHours\", \"value\": \"48\"").Count);
            Assert.DoesNotContain("$(Columbus.EnableSalesforceCooloff)", nonProductionStages, StringComparison.Ordinal);
            Assert.DoesNotContain("$(Columbus.SalesforceCooloffHours)", nonProductionStages, StringComparison.Ordinal);
            Assert.Single(Regex.Matches(productionStage, "\"name\": \"Columbus__EnableSalesforceCooloff\", \"value\": \"\\$\\(Columbus\\.EnableSalesforceCooloff\\)\"").Cast<Match>());
            Assert.Single(Regex.Matches(productionStage, "\"name\": \"Columbus__SalesforceCooloffHours\", \"value\": \"\\$\\(Columbus\\.SalesforceCooloffHours\\)\"").Cast<Match>());
        }

        private static string GetRepositoryRoot([CallerFilePath] string sourceFilePath = "")
        {
            return Path.GetFullPath(Path.Combine(Path.GetDirectoryName(sourceFilePath)!, "..", ".."));
        }
    }
}
