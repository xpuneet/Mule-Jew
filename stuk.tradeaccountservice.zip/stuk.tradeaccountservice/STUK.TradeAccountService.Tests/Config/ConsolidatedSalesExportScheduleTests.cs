using STUK.TradeAccountService.Common.Salesforce.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the fixed scheduled Consolidated Sales export contract
    /// </summary>
    public class ConsolidatedSalesExportScheduleTests
    {
        [Fact]
        public void Given_ExportSchedule_When_Read_Should_MatchLegacyWeeklyContract()
        {
            Assert.Equal(0, ConsolidatedSalesExportSchedule.ScheduledHour);
            Assert.Equal(30, ConsolidatedSalesExportSchedule.ScheduledMinute);
            Assert.Equal("Europe/London", ConsolidatedSalesExportSchedule.TimeZoneId);
        }
    }
}
