using System.Runtime.CompilerServices;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the deployable Phocas export configuration contract
    /// </summary>
    public class PhocasDeploymentConfigurationTests
    {
        private static readonly string[] RequiredSettings =
        {
            "ConsolidatedSalesExportCron",
            "ConsolidatedSalesExportRecoveryCron",
            "AzureWebJobs.ConsolidatedSalesExportFunction.Disabled",
            "AzureWebJobs.ConsolidatedSalesExportRecoveryFunction.Disabled",
            "ConsolidatedSales__Export__Phocas__BlobStagingPath",
            "ConsolidatedSales__Export__Phocas__FileActionId",
            "ConsolidatedSales__Export__DataLake__ServiceUri",
            "ConsolidatedSales__Export__DataLake__FileSystem"
        };

        /// <summary>
        /// Verifies that DEV, QA and PROD each receive the complete variable-driven Phocas configuration
        /// </summary>
        [Fact]
        public void Given_DeploymentPipeline_When_Read_Should_Configure_Each_Environment()
        {
            var pipelinePath = Path.Combine(GetRepositoryRoot(), "STUK.TradeAccountService.Functions", "Deploy", "azureDeploy-CD.yml");
            var pipeline = File.ReadAllText(pipelinePath);

            foreach (var setting in RequiredSettings)
            {
                Assert.Equal(3, CountOccurrences(pipeline, $"\"name\": \"{setting}\""));
            }
        }

        private static string GetRepositoryRoot([CallerFilePath] string sourceFilePath = "")
        {
            return Path.GetFullPath(Path.Combine(Path.GetDirectoryName(sourceFilePath)!, "..", ".."));
        }

        private static int CountOccurrences(string value, string expected)
        {
            return value.Split(expected, StringSplitOptions.None).Length - 1;
        }
    }
}
