using STUK.TradeAccountService.Common.Contracts.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the default Columbus configuration values before environment overrides are applied
    /// </summary>
    public class ColumbusOptionsTests
    {
        [Fact]
        public void Given_DefaultOptions_When_Read_Should_DefaultToDisabledWithFortyEightConfiguredHours()
        {
            var options = new ColumbusOptions();

            Assert.Equal("Columbus", ColumbusOptions.SectionName);
            Assert.False(options.EnableSalesforceCooloff);
            Assert.Equal(48, options.SalesforceCooloffHours);
        }
    }
}
