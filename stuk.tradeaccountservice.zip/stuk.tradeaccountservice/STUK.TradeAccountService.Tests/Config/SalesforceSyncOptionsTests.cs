using STUK.TradeAccountService.Common.Salesforce.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the default Salesforce synchronisation settings
    /// </summary>
    public class SalesforceSyncOptionsTests
    {
        [Fact]
        public void Given_NoConfiguration_When_OptionsAreCreated_Should_UseMuleSoftProcessingDefaults()
        {
            var options = new SalesforceSyncOptions();

            Assert.Equal(1, options.MaximumWorkItemsPerRun);
            Assert.Equal(240, options.LeaseDurationSeconds);
            Assert.Equal(60, options.LeaseRenewalIntervalSeconds);
            Assert.Equal(2, options.RetryDelaySeconds);
            Assert.Equal(2, options.MaximumRetryCount);
        }
    }
}
