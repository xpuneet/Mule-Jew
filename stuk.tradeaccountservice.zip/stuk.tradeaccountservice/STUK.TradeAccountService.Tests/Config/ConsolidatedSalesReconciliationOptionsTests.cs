using STUK.TradeAccountService.Common.Contracts.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the default HX Consolidated Sales reconciliation settings
    /// </summary>
    public class ConsolidatedSalesReconciliationOptionsTests
    {
        [Fact]
        public void Given_NoConfiguration_When_OptionsAreCreated_Should_UseOperationalDefaults()
        {
            var options = new ConsolidatedSalesReconciliationOptions();

            Assert.Equal(2, options.MaximumWorkItemsPerRun);
            Assert.Equal(120, options.LeaseDurationSeconds);
            Assert.Equal(300, options.NoMatchRetryDelaySeconds);
            Assert.Equal(30, options.FailureRetryDelaySeconds);
            Assert.Equal(2, options.MaximumRetryCount);
        }
    }
}
