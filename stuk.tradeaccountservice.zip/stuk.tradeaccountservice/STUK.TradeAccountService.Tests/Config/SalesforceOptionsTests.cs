using STUK.TradeAccountService.Common.Salesforce.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the default Salesforce REST settings
    /// </summary>
    public class SalesforceOptionsTests
    {
        [Fact]
        public void Given_NoConfiguration_When_OptionsAreCreated_Should_UseMuleSoftRequestTimeout()
        {
            var options = new SalesforceOptions();

            Assert.Equal(60, options.RequestTimeoutSeconds);
        }
    }
}
