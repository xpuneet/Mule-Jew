using System.Runtime.CompilerServices;
using System.Text.Json;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the database deployment targets used by the integration features
    /// </summary>
    public class DatabaseDeploymentConfigurationTests
    {
        /// <summary>
        /// Verifies that the deployer includes the managed File Transfer database as an explicit DBUp target
        /// </summary>
        [Fact]
        public void Given_DatabaseDeployer_When_Read_Should_IncludeFileTransferDatabase()
        {
            var repositoryRoot = GetRepositoryRoot();
            var program = File.ReadAllText(Path.Combine(repositoryRoot, "STUK.TradeAccountService.DBDeploy", "Program.cs"));
            var project = File.ReadAllText(Path.Combine(repositoryRoot, "STUK.TradeAccountService.DBDeploy", "STUK.TradeAccountService.DBDeploy.csproj"));

            Assert.Contains("const string FileTransferDatabase = \"FileTransferDb\";", program, StringComparison.Ordinal);
            Assert.Contains("GetConnectionString(\"FileTransferDb\")", program, StringComparison.Ordinal);
            Assert.Contains("RunDatabaseDeployment(assembly, fileTransferConnectionString!, FileTransferDatabase)", program, StringComparison.Ordinal);
            Assert.Contains("RunScriptStep(assembly, fileTransferConnectionString!, FileTransferDatabase, \"Validation\", alwaysRun: true)", program, StringComparison.Ordinal);
            Assert.Contains("<EmbeddedResource Include=\"FileTransferDb\\**\\*.sql\" />", project, StringComparison.Ordinal);
        }

        /// <summary>
        /// Verifies that packaged database settings contain no environment-owned connection strings
        /// </summary>
        [Fact]
        public void Given_DatabaseSettings_When_Read_Should_NotContainEnvironmentConnections()
        {
            var path = Path.Combine(GetRepositoryRoot(), "STUK.TradeAccountService.DBDeploy", "appsettings.json");
            using var document = JsonDocument.Parse(File.ReadAllText(path));

            var connections = document.RootElement.GetProperty("ConnectionStrings");

            Assert.Equal(string.Empty, connections.GetProperty("TradeAccountServiceDb").GetString());
            Assert.Equal(string.Empty, connections.GetProperty("OrderServiceDb").GetString());
            Assert.Equal(string.Empty, connections.GetProperty("FileTransferDb").GetString());
        }

        /// <summary>
        /// Verifies that DEV and QA pass File Transfer database configuration to DBUp and validate their targets
        /// </summary>
        [Fact]
        public void Given_DeploymentPipeline_When_Read_Should_DeployFileTransferScriptsToNonProductionOnly()
        {
            var path = Path.Combine(GetRepositoryRoot(), "STUK.TradeAccountService.Functions", "Deploy", "azureDeploy-CD.yml");
            var pipeline = File.ReadAllText(path);
            var productionStageStart = pipeline.IndexOf("# === PROD STAGE ===", StringComparison.Ordinal);

            Assert.True(productionStageStart > 0);

            var nonProductionStages = pipeline[..productionStageStart];
            var productionStage = pipeline[productionStageStart..];

            Assert.Equal(2, CountOccurrences(nonProductionStages, "FILE_TRANSFER_DB: $(ConnectionStrings.FileTransferDb)"));
            Assert.Equal(2, CountOccurrences(nonProductionStages, "ConnectionStrings__FileTransferDb: $(ConnectionStrings.FileTransferDb)"));
            Assert.Contains("FileTransferDb = 'sqldb-stuk-ais-tst'", nonProductionStages, StringComparison.Ordinal);
            Assert.Contains("sql-stuk-ais-tst-uks.database.windows.net", nonProductionStages, StringComparison.Ordinal);
            Assert.DoesNotContain("FILE_TRANSFER_DB:", productionStage, StringComparison.Ordinal);
            Assert.DoesNotContain("ConnectionStrings__FileTransferDb:", productionStage, StringComparison.Ordinal);
        }

        private static string GetRepositoryRoot([CallerFilePath] string sourceFilePath = "")
        {
            return Path.GetFullPath(Path.Combine(Path.GetDirectoryName(sourceFilePath)!, "..", ".."));
        }

        private static int CountOccurrences(string value, string expected)
        {
            return value.Split(expected, StringSplitOptions.None).Length - 1;
        }
    }
}
