using Microsoft.Extensions.Configuration;
using STUK.TradeAccountService.Common.Contracts.Config;

namespace STUK.TradeAccountService.Tests.Config
{
    /// <summary>
    /// Tests the default Workday-to-Concur feature configuration
    /// </summary>
    public class WorkdayConcurOptionsTests
    {
        /// <summary>
        /// Verifies that the feature cannot run unless it is explicitly enabled
        /// </summary>
        [Fact]
        public void Given_DefaultOptions_When_Read_Should_DefaultToDisabled()
        {
            var options = new WorkdayConcurOptions();

            Assert.Equal("WorkdayConcur", WorkdayConcurOptions.SectionName);
            Assert.False(options.Enabled);
            Assert.Equal("0 0 7 * * *", options.Cron);
            Assert.Equal(300, options.LeaseDurationSeconds);
            Assert.Equal(60, options.LeaseRenewalIntervalSeconds);
            Assert.Equal(5, options.SynapsePollIntervalSeconds);
            Assert.Equal(600, options.SynapseRunTimeoutSeconds);
            Assert.Equal("pl-concur-parent", options.ConcurTransformationPipelineName);
            Assert.Equal(100, options.WorkdayPageSize);
            Assert.Equal(100, options.WorkdayDetailBatchSize);
            Assert.Equal(60, options.WorkdayRequestTimeoutSeconds);
            Assert.Equal("SGBD", options.ConcurLedgerCode);
            Assert.Equal("N", options.ConcurApprovalDefault);
            Assert.Equal("/in", options.ConcurDestinationPath);
        }

        /// <summary>
        /// Verifies that all integration settings bind from the single WorkdayConcur section
        /// </summary>
        [Fact]
        public void Given_WorkdayConcurSection_When_Binding_Should_PopulateAllSettings()
        {
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["WorkdayConcur:Enabled"] = "true",
                    ["WorkdayConcur:Cron"] = "0 0 1 * * *",
                    ["WorkdayConcur:LeaseDurationSeconds"] = "300",
                    ["WorkdayConcur:LeaseRenewalIntervalSeconds"] = "60",
                    ["WorkdayConcur:SynapseWorkspaceName"] = "synw-concur",
                    ["WorkdayConcur:ConcurSynapseWorkspaceName"] = "synw-concur-transform",
                    ["WorkdayConcur:Tm1PickupIntegrationKeyId"] = "integration-id",
                    ["WorkdayConcur:Tm1PickupActionName"] = "PICKUP",
                    ["WorkdayConcur:SynapsePollIntervalSeconds"] = "5",
                    ["WorkdayConcur:SynapseRunTimeoutSeconds"] = "600",
                    ["WorkdayConcur:ConcurTransformationPipelineName"] = "configured-transform-pipeline",
                    ["WorkdayConcur:WorkdayEndpoint"] = "https://workday.example.test/ccx/service/tenant/Human_Resources/v40.0",
                    ["WorkdayConcur:WorkdayUsername"] = "integration-user",
                    ["WorkdayConcur:WorkdayPassword"] = "secure-value",
                    ["WorkdayConcur:WorkdayPageSize"] = "100",
                    ["WorkdayConcur:WorkdayDetailBatchSize"] = "100",
                    ["WorkdayConcur:WorkdayRequestTimeoutSeconds"] = "60",
                    ["WorkdayConcur:ConcurBlobServiceEndpoint"] = "https://storage.example.test",
                    ["WorkdayConcur:ConcurBlobContainerName"] = "stukconcurtest",
                    ["WorkdayConcur:ConcurDestinationPath"] = "/in/test/",
                    ["WorkdayConcur:ConcurLedgerCode"] = "SGBD",
                    ["WorkdayConcur:ConcurApprovalDefault"] = "N",
                    ["WorkdayConcur:ConcurPgpPublicKey"] = "armored-public-key",
                    ["WorkdayConcur:ConcurPgpKeyId"] = "BAA83C168C51C89E",
                    ["WorkdayConcur:ConcurDeliveryIntegrationKeyId"] = "concur-integration-id",
                    ["WorkdayConcur:ConcurDeliveryActionName"] = "DROP"
                })
                .Build();
            var options = new WorkdayConcurOptions();

            configuration.GetSection(WorkdayConcurOptions.SectionName).Bind(options);

            Assert.True(options.Enabled);
            Assert.Equal("0 0 1 * * *", options.Cron);
            Assert.Equal(300, options.LeaseDurationSeconds);
            Assert.Equal(60, options.LeaseRenewalIntervalSeconds);
            Assert.Equal("synw-concur", options.SynapseWorkspaceName);
            Assert.Equal("synw-concur-transform", options.ConcurSynapseWorkspaceName);
            Assert.Equal("integration-id", options.Tm1PickupIntegrationKeyId);
            Assert.Equal("PICKUP", options.Tm1PickupActionName);
            Assert.Equal(5, options.SynapsePollIntervalSeconds);
            Assert.Equal(600, options.SynapseRunTimeoutSeconds);
            Assert.Equal("configured-transform-pipeline", options.ConcurTransformationPipelineName);
            Assert.Equal("https://workday.example.test/ccx/service/tenant/Human_Resources/v40.0", options.WorkdayEndpoint);
            Assert.Equal("integration-user", options.WorkdayUsername);
            Assert.Equal("secure-value", options.WorkdayPassword);
            Assert.Equal(100, options.WorkdayPageSize);
            Assert.Equal(100, options.WorkdayDetailBatchSize);
            Assert.Equal(60, options.WorkdayRequestTimeoutSeconds);
            Assert.Equal("https://storage.example.test", options.ConcurBlobServiceEndpoint);
            Assert.Equal("stukconcurtest", options.ConcurBlobContainerName);
            Assert.Equal("/in/test/", options.ConcurDestinationPath);
            Assert.Equal("SGBD", options.ConcurLedgerCode);
            Assert.Equal("N", options.ConcurApprovalDefault);
            Assert.Equal("armored-public-key", options.ConcurPgpPublicKey);
            Assert.Equal("BAA83C168C51C89E", options.ConcurPgpKeyId);
            Assert.Equal("concur-integration-id", options.ConcurDeliveryIntegrationKeyId);
            Assert.Equal("DROP", options.ConcurDeliveryActionName);
        }
    }
}
