namespace STUK.TradeAccountService.Tests.Helpers
{
    internal class FixedTimeProvider : TimeProvider
    {
        private readonly DateTimeOffset _utcNow;

        /// <summary>
        /// Initialises a new instance of the <see cref="FixedTimeProvider"/> class
        /// </summary>
        /// <param name="utcNow">Fixed UTC timestamp returned by the provider</param>
        public FixedTimeProvider(DateTimeOffset utcNow)
        {
            _utcNow = utcNow;
        }

        public override DateTimeOffset GetUtcNow()
        {
            return _utcNow;
        }
    }
}
