namespace STUK.TradeAccountService.Tests.Fixtures.Workday
{
    /// <summary>
    /// Loads focused Workday SOAP contract fixtures copied to the test output directory
    /// </summary>
    internal static class WorkdayTestFixture
    {
        /// <summary>
        /// Reads a named Workday contract fixture from the test output directory
        /// </summary>
        /// <param name="fileName">Fixture filename</param>
        /// <returns>Fixture XML content</returns>
        public static string Read(string fileName)
        {
            return File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Fixtures", "Workday", fileName));
        }
    }
}
