using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text;
using System.Text.Json;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests encrypted Concur staging and the managed Synapse delivery contract
    /// </summary>
    public class WorkdayConcurDeliveryServiceTests
    {
        private const string DeliveryActionName = "DROP";
        private const string DeliveryIntegrationId = "concur-integration";
        private const string DeliveryRunId = "delivery-run";
        private const string OutputContainer = "stukconcurprd";
        private const string PgpKeyId = "BAA83C168C51C89E";
        private const string StagingContainer = "erp3data";
        private const string StagingFolder = "workday-concur/delivery-staging/10000000000000000000000000000001";
        private const string StagingSourcePath = "erp3data/workday-concur/delivery-staging/10000000000000000000000000000001";
        private static readonly Guid CorrelationId = new("10000000-0000-0000-0000-000000000001");
        private static readonly Uri OutputEndpoint = new("https://concur.blob.core.windows.net");
        private static readonly Uri StagingEndpoint = new("https://transfer.blob.core.windows.net");
        private static readonly DateTimeOffset Now = new(2026, 9, 5, 8, 30, 0, TimeSpan.Zero);

        private readonly Mock<IFileTransferConfigurationService> _configurationService = new(MockBehavior.Strict);
        private readonly Mock<IWorkdayConcurBlobClient> _blobClient = new(MockBehavior.Strict);
        private readonly Mock<IConcurPgpEncryptionService> _encryptionService = new(MockBehavior.Strict);
        private readonly Mock<ISynapsePipelineClient> _synapseClient = new(MockBehavior.Strict);

        /// <summary>
        /// Verifies that every selected output is encrypted, staged with a PGP suffix and delivered in one isolated run
        /// </summary>
        [Fact]
        public async Task Given_SelectedOutputFiles_When_PreparingAndStarting_Should_EncryptStageAndTriggerOneSynapseRun()
        {
            var configuration = CreateTransferConfiguration();
            var outputFiles = CreateOutputFiles();
            IReadOnlyDictionary<string, object?>? startedParameters = null;

            SetupConfiguration(configuration);
            SetupOutputRead("output/employee.txt", "employee-etag", "employee-content");

            SetupOutputRead("output/list.txt", "list-etag", "list-content");

            SetupEncryption();
            SetupUpload($"{StagingFolder}/employee.txt.pgp");

            SetupUpload($"{StagingFolder}/list.txt.pgp");

            _synapseClient
                .Setup(x => x.StartAsync("Blob_To_SFTP_SSH", It.IsAny<IReadOnlyDictionary<string, object?>>(), default))
                .Callback<string, IReadOnlyDictionary<string, object?>, CancellationToken>((_, parameters, _) => startedParameters = parameters)
                .ReturnsAsync(DeliveryRunId);

            var service = CreateService();
            var checkpoint = await service.PrepareAsync(CorrelationId, outputFiles);

            Assert.Equal(WorkdayConcurDeliveryStatus.Staged, checkpoint.Status);
            Assert.Equal(2, checkpoint.StagedFiles.Count);

            checkpoint.Status = WorkdayConcurDeliveryStatus.Starting;
            checkpoint = await service.StartAsync(CorrelationId, checkpoint);

            Assert.Equal(DeliveryRunId, checkpoint.SynapseRunId);
            Assert.Equal(StagingContainer, checkpoint.StagingContainer);
            Assert.Equal(StagingFolder, checkpoint.StagingFolderPath);
            Assert.Equal(WorkdayConcurDeliveryStatus.InProgress, checkpoint.Status);
            Assert.NotNull(startedParameters);
            Assert.Equal(StagingSourcePath, startedParameters["SourceFilePath"]);
            Assert.Equal(string.Empty, startedParameters["FileStartFilter"]);
            Assert.Equal(".pgp", startedParameters["FileEndFilter"]);
            Assert.Equal("/in/test", startedParameters["DestinationFilePath"]);
            Assert.Equal("concur-private-key-secret", startedParameters["DestinationPassword"]);
            Assert.Equal("concur-private-key-passphrase-secret", startedParameters["DestinationPassPhrase"]);
            Assert.Null(startedParameters["DestinationFileFormat"]);
            Assert.Equal(true, startedParameters["SourceDelete"]);
            Assert.Equal(false, startedParameters["IsArchive"]);
            _configurationService.VerifyAll();
            _blobClient.VerifyAll();
            _encryptionService.VerifyAll();
            _synapseClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that the original Blob entity tag is required when the plaintext is opened
        /// </summary>
        [Fact]
        public async Task Given_SelectedOutput_When_Starting_Should_ReadExactRecordedBlobVersion()
        {
            var configuration = CreateTransferConfiguration();
            var output = CreateOutputFiles().First();

            SetupConfiguration(configuration);
            SetupOutputRead("output/employee.txt", "employee-etag", "employee-content");
            SetupEncryption();
            SetupUpload($"{StagingFolder}/employee.txt.pgp");

            _synapseClient.Setup(x => x.StartAsync("Blob_To_SFTP_SSH", It.IsAny<IReadOnlyDictionary<string, object?>>(), default)).ReturnsAsync(DeliveryRunId);

            var service = CreateService();
            var checkpoint = await service.PrepareAsync(CorrelationId, new[] { output });
            checkpoint.Status = WorkdayConcurDeliveryStatus.Starting;

            await service.StartAsync(CorrelationId, checkpoint);

            _blobClient.Verify(x => x.OpenReadAsync(OutputEndpoint, OutputContainer, "output/employee.txt", "employee-etag", default), Times.Once);
        }

        /// <summary>
        /// Verifies that colliding source filenames are rejected before any content is read or staged
        /// </summary>
        [Fact]
        public async Task Given_DuplicateLeafFilenames_When_Starting_Should_RejectBeforeStaging()
        {
            var configuration = CreateTransferConfiguration();
            var outputFiles = new[]
            {
                CreateFile($"{OutputContainer}/output/first/employee.txt", "first-etag"),
                CreateFile($"{OutputContainer}/output/second/employee.txt", "second-etag")
            };

            SetupConfiguration(configuration);

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().PrepareAsync(CorrelationId, outputFiles));

            Assert.Equal("More than one selected Concur output maps to encrypted filename 'employee.txt.pgp'", exception.Message);
            _blobClient.VerifyNoOtherCalls();
            _encryptionService.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that no Synapse delivery starts when encrypted staging fails
        /// </summary>
        [Fact]
        public async Task Given_EncryptionFailure_When_Preparing_Should_NotTriggerSynapse()
        {
            var configuration = CreateTransferConfiguration();
            var output = CreateOutputFiles().First();

            SetupConfiguration(configuration);
            SetupOutputRead("output/employee.txt", "employee-etag", "employee-content");

            _encryptionService
                .Setup(x => x.EncryptAsync(It.IsAny<Stream>(), It.IsAny<Stream>(), "public-key", PgpKeyId, default))
                .ThrowsAsync(new InvalidDataException("Encryption failed"));

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().PrepareAsync(CorrelationId, new[] { output }));

            Assert.Equal("Encryption failed", exception.Message);
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that an empty transformation result cannot create an empty delivery run
        /// </summary>
        [Fact]
        public async Task Given_NoSelectedOutputs_When_Preparing_Should_RejectDelivery()
        {
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().PrepareAsync(CorrelationId, Array.Empty<WorkdayConcurFileIdentity>()));

            _configurationService.VerifyNoOtherCalls();
            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that a selected identity cannot escape the configured Concur Blob container
        /// </summary>
        [Fact]
        public async Task Given_OutputOutsideConfiguredContainer_When_Preparing_Should_RejectBeforeReading()
        {
            SetupConfiguration(CreateTransferConfiguration());
            var output = CreateFile("anothercontainer/output/employee.txt", "employee-etag");

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().PrepareAsync(CorrelationId, new[] { output }));

            Assert.Equal($"Selected Concur output 'anothercontainer/output/employee.txt' is not inside Blob container '{OutputContainer}'", exception.Message);
            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that Synapse cannot be called until the Starting intent has been persisted by the orchestrator
        /// </summary>
        [Fact]
        public async Task Given_UnmarkedStagingCheckpoint_When_Starting_Should_RejectBeforeSynapse()
        {
            var checkpoint = CreateCheckpoint();
            checkpoint.SynapseRunId = string.Empty;
            checkpoint.Status = WorkdayConcurDeliveryStatus.Staged;

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().StartAsync(CorrelationId, checkpoint));

            Assert.Equal("The Concur delivery checkpoint must be persisted as Starting before Synapse is called", exception.Message);
            _configurationService.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that transfer configuration cannot silently move a persisted staging checkpoint elsewhere
        /// </summary>
        [Fact]
        public async Task Given_ChangedStagingConfiguration_When_Starting_Should_RejectBeforeSynapse()
        {
            var checkpoint = CreateCheckpoint();
            checkpoint.SynapseRunId = string.Empty;
            checkpoint.Status = WorkdayConcurDeliveryStatus.Starting;
            var configuration = CreateTransferConfiguration();
            configuration.Action.SourceFolderPath = "erp3data/changed-staging";
            SetupConfiguration(configuration);

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().StartAsync(CorrelationId, checkpoint));

            Assert.Equal("The persisted Concur delivery staging location does not match the current managed-transfer configuration", exception.Message);
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that a successful Synapse run is accepted only after its isolated staging folder is empty
        /// </summary>
        [Fact]
        public async Task Given_SuccessfulRunAndEmptyStaging_When_Completing_Should_Succeed()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient.Setup(x => x.WaitForCompletionAsync(DeliveryRunId, default)).ReturnsAsync(new SynapsePipelineRun { Status = "Succeeded" });

            _blobClient.Setup(x => x.ListFilesAsync(StagingEndpoint, StagingContainer, checkpoint.StagingFolderPath, default)).ReturnsAsync(Array.Empty<WorkdayConcurFileIdentity>());

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal(WorkdayConcurDeliveryStatus.Succeeded, result.Status);
            Assert.Equal(Now, result.CompletedOn);
            Assert.Null(result.FailureMessage);
        }

        /// <summary>
        /// Verifies that pipeline success is not accepted while an encrypted staging file remains
        /// </summary>
        [Fact]
        public async Task Given_SuccessfulRunWithRemainingStagingFile_When_Completing_Should_FailValidation()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient.Setup(x => x.WaitForCompletionAsync(DeliveryRunId, default)).ReturnsAsync(new SynapsePipelineRun { Status = "Succeeded" });

            _blobClient
                .Setup(x => x.ListFilesAsync(StagingEndpoint, StagingContainer, checkpoint.StagingFolderPath, default))
                .ReturnsAsync(new[] { CreateFile("erp3data/workday-concur/delivery-staging/file.pgp", "etag") });

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal(WorkdayConcurDeliveryStatus.ValidationFailed, result.Status);
            Assert.Equal("Synapse Concur delivery left 1 encrypted file(s) in the active staging folder", result.FailureMessage);
        }

        /// <summary>
        /// Verifies that a failed Synapse run is returned without claiming that staged files were delivered
        /// </summary>
        [Fact]
        public async Task Given_FailedSynapseRun_When_Completing_Should_ReturnFailureWithoutListingStaging()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync(DeliveryRunId, default))
                .ReturnsAsync(new SynapsePipelineRun { Status = "Failed", Message = "SFTP rejected file" });

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal(WorkdayConcurDeliveryStatus.Failed, result.Status);
            Assert.Equal("SFTP rejected file", result.FailureMessage);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that delivery state is persisted by name inside the database checkpoint JSON
        /// </summary>
        [Fact]
        public void Given_DeliveryCheckpoint_When_Serialising_Should_PersistReadableEnumName()
        {
            var checkpoint = CreateCheckpoint();
            checkpoint.Status = WorkdayConcurDeliveryStatus.Starting;

            var json = JsonSerializer.Serialize(checkpoint);
            var restored = JsonSerializer.Deserialize<WorkdayConcurDeliveryCheckpoint>(json);

            Assert.Contains("\"Status\":\"Starting\"", json, StringComparison.Ordinal);
            Assert.NotNull(restored);
            Assert.Equal(WorkdayConcurDeliveryStatus.Starting, restored.Status);
        }

        /// <summary>
        /// Verifies that delivery refuses a transfer action that would retain active encrypted staging files
        /// </summary>
        [Fact]
        public async Task Given_ActionWithoutSourceDelete_When_Starting_Should_RejectConfiguration()
        {
            var configuration = CreateTransferConfiguration();
            configuration.Action.SourceDelete = false;
            SetupConfiguration(configuration);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().PrepareAsync(CorrelationId, new[] { CreateOutputFiles().First() }));

            Assert.Equal("Concur delivery must delete successfully transferred staging files without archiving them", exception.Message);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that delivery cannot accidentally use a different generic Synapse pipeline
        /// </summary>
        [Fact]
        public async Task Given_NonDeliveryPipeline_When_Starting_Should_RejectConfiguration()
        {
            var configuration = CreateTransferConfiguration();
            configuration.Action.PipeLineName = "SFTP_To_Blob";
            SetupConfiguration(configuration);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().PrepareAsync(CorrelationId, new[] { CreateOutputFiles().First() }));

            Assert.Equal("Concur delivery must use the managed 'Blob_To_SFTP_SSH' pipeline", exception.Message);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that the managed transfer is constrained to the existing Concur inbound folder
        /// </summary>
        [Fact]
        public async Task Given_NonConcurDestinationPath_When_Starting_Should_RejectConfiguration()
        {
            var configuration = CreateTransferConfiguration();
            configuration.Action.DestinationFolderPath = "/wrong";
            SetupConfiguration(configuration);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().PrepareAsync(CorrelationId, new[] { CreateOutputFiles().First() }));

            Assert.Equal("Concur delivery must target '/in/test'", exception.Message);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies both delivery phases require a non-empty correlation identifier
        /// </summary>
        [Fact]
        public async Task Given_EmptyCorrelationId_When_PreparingOrStarting_Should_RejectBeforeExternalCalls()
        {
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().PrepareAsync(Guid.Empty, CreateOutputFiles()));
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().StartAsync(Guid.Empty, CreateCheckpoint()));

            _configurationService.VerifyNoOtherCalls();
            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies a persisted delivery checkpoint must retain its encrypted file evidence
        /// </summary>
        [Fact]
        public async Task Given_CheckpointWithoutStagedFiles_When_Starting_Should_RejectBeforeSynapse()
        {
            var checkpoint = CreateCheckpoint();
            checkpoint.StagedFiles = [];

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().StartAsync(CorrelationId, checkpoint));

            Assert.Contains("no staged encrypted files", exception.Message);
            _configurationService.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies non-terminal Synapse states cannot be persisted as terminal delivery outcomes
        /// </summary>
        [Theory]
        [InlineData("InProgress")]
        [InlineData("Queued")]
        [InlineData("ValidationFailed")]
        public async Task Given_UnsupportedSynapseStatus_When_Completing_Should_RejectStatus(string status)
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient.Setup(x => x.WaitForCompletionAsync(DeliveryRunId, default)).ReturnsAsync(new SynapsePipelineRun { Status = status });

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().CompleteAsync(checkpoint));

            Assert.Contains(status, exception.Message);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies the transfer source must identify both its Blob container and staging folder
        /// </summary>
        [Theory]
        [InlineData("", typeof(ArgumentException))]
        [InlineData("erp3data", typeof(InvalidOperationException))]
        [InlineData("/erp3data/", typeof(InvalidOperationException))]
        public async Task Given_InvalidStagingSourcePath_When_Preparing_Should_RejectConfiguration(string sourceFolderPath, Type exceptionType)
        {
            var configuration = CreateTransferConfiguration();
            configuration.Action.SourceFolderPath = sourceFolderPath;
            SetupConfiguration(configuration);

            await Assert.ThrowsAsync(exceptionType, () => CreateService().PrepareAsync(CorrelationId, CreateOutputFiles()));

            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies both the output and managed-transfer Blob endpoints must use HTTPS
        /// </summary>
        [Fact]
        public async Task Given_InsecureBlobEndpoint_When_Preparing_Should_RejectConfiguration()
        {
            var options = CreateOptions();
            options.ConcurBlobServiceEndpoint = "http://concur.blob.core.windows.net";

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(options).PrepareAsync(CorrelationId, CreateOutputFiles()));

            var configuration = CreateTransferConfiguration();
            configuration.Blob.ServiceEndPoint = "http://transfer.blob.core.windows.net";
            SetupConfiguration(configuration);

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().PrepareAsync(CorrelationId, CreateOutputFiles()));

            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies every required delivery option before File Transfer configuration is read
        /// </summary>
        [Theory]
        [InlineData("integration")]
        [InlineData("action")]
        [InlineData("container")]
        [InlineData("destination-path")]
        [InlineData("public-key")]
        [InlineData("key-id")]
        public async Task Given_MissingRequiredOption_When_Preparing_Should_RejectBeforeConfigurationLookup(string missingOption)
        {
            var options = CreateOptions();
            switch (missingOption)
            {
                case "integration":
                    options.ConcurDeliveryIntegrationKeyId = string.Empty;
                    break;
                case "action":
                    options.ConcurDeliveryActionName = string.Empty;
                    break;
                case "container":
                    options.ConcurBlobContainerName = string.Empty;
                    break;
                case "destination-path":
                    options.ConcurDestinationPath = string.Empty;
                    break;
                case "public-key":
                    options.ConcurPgpPublicKey = string.Empty;
                    break;
                case "key-id":
                    options.ConcurPgpKeyId = string.Empty;
                    break;
            }

            await Assert.ThrowsAsync<ArgumentException>(() => CreateService(options).PrepareAsync(CorrelationId, CreateOutputFiles()));

            _configurationService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies missing managed-transfer components and SFTP values before output files are opened
        /// </summary>
        [Theory]
        [InlineData("action", typeof(InvalidOperationException))]
        [InlineData("blob", typeof(InvalidOperationException))]
        [InlineData("sftp", typeof(InvalidOperationException))]
        [InlineData("host", typeof(ArgumentException))]
        [InlineData("username", typeof(ArgumentException))]
        [InlineData("password", typeof(ArgumentException))]
        [InlineData("passphrase", typeof(ArgumentException))]
        [InlineData("archive", typeof(InvalidOperationException))]
        public async Task Given_InvalidManagedTransferConfiguration_When_Preparing_Should_RejectBeforeReadingOutput(string invalidField, Type exceptionType)
        {
            var configuration = CreateTransferConfiguration();
            switch (invalidField)
            {
                case "action":
                    configuration.Action = null!;
                    break;
                case "blob":
                    configuration.Blob = null!;
                    break;
                case "sftp":
                    configuration.Sftp = null!;
                    break;
                case "host":
                    configuration.Sftp.IpAddress = string.Empty;
                    break;
                case "username":
                    configuration.Sftp.Username = string.Empty;
                    break;
                case "password":
                    configuration.Sftp.PasswordKey = string.Empty;
                    break;
                case "passphrase":
                    configuration.Sftp.PassPhraseKey = string.Empty;
                    break;
                case "archive":
                    configuration.Action.SourceArchive = true;
                    break;
            }

            SetupConfiguration(configuration);

            await Assert.ThrowsAsync(exceptionType, () => CreateService().PrepareAsync(CorrelationId, CreateOutputFiles()));

            _blobClient.VerifyNoOtherCalls();
            _encryptionService.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        private void SetupConfiguration(WorkdayConcurDeliveryTransferConfiguration configuration)
        {
            _configurationService
                .Setup(x => x.GetConcurDeliveryAsync(DeliveryIntegrationId, DeliveryActionName, default))
                .ReturnsAsync(configuration);
        }

        private void SetupOutputRead(string blobName, string eTag, string content)
        {
            _blobClient
                .Setup(x => x.OpenReadAsync(OutputEndpoint, OutputContainer, blobName, eTag, default))
                .ReturnsAsync(() => new MemoryStream(Encoding.UTF8.GetBytes(content)));
        }

        private void SetupEncryption()
        {
            _encryptionService
                .Setup(x => x.EncryptAsync(It.IsAny<Stream>(), It.IsAny<Stream>(), "public-key", PgpKeyId, default))
                .Returns<Stream, Stream, string, string, CancellationToken>(async (_, destination, _, _, cancellationToken) =>
                {
                    await destination.WriteAsync("encrypted"u8.ToArray(), cancellationToken);
                });
        }

        private void SetupUpload(string blobName)
        {
            _blobClient
                .Setup(x => x.UploadAsync(StagingEndpoint, StagingContainer, blobName, It.IsAny<Stream>(), default))
                .ReturnsAsync(CreateFile($"{StagingContainer}/{blobName}", "staged-etag"));
        }

        private static WorkdayConcurDeliveryTransferConfiguration CreateTransferConfiguration()
        {
            return new WorkdayConcurDeliveryTransferConfiguration
            {
                Action = new FileTransferActionConfiguration
                {
                    Id = "action-id",
                    SourceId = "blob-source",
                    DestinationId = "sftp-destination",
                    PipeLineName = "Blob_To_SFTP_SSH",
                    SourceFolderPath = "erp3data/workday-concur/delivery-staging",
                    DestinationFolderPath = "/in/test",
                    SourceArchive = false,
                    SourceDelete = true,
                    SourceErrorPath = "erp3data/workday-concur/error"
                },
                Blob = new FileTransferBlobConfiguration
                {
                    ServiceEndPoint = StagingEndpoint.ToString()
                },
                Sftp = new SynapseSftpConfiguration
                {
                    IpAddress = "concur-sftp.example.test",
                    Username = "concur-user",
                    PasswordKey = "concur-private-key-secret",
                    PassPhraseKey = "concur-private-key-passphrase-secret"
                }
            };
        }

        private static IReadOnlyCollection<WorkdayConcurFileIdentity> CreateOutputFiles()
        {
            return new[]
            {
                CreateFile($"{OutputContainer}/output/employee.txt", "employee-etag"),
                CreateFile($"{OutputContainer}/output/list.txt", "list-etag")
            };
        }

        private static WorkdayConcurFileIdentity CreateFile(string path, string eTag)
        {
            return new WorkdayConcurFileIdentity
            {
                Path = path,
                ContentLength = 100,
                ETag = eTag,
                LastModifiedOn = Now
            };
        }

        private static WorkdayConcurDeliveryCheckpoint CreateCheckpoint()
        {
            return new WorkdayConcurDeliveryCheckpoint
            {
                SynapseRunId = DeliveryRunId,
                StartedOn = Now.AddMinutes(-1),
                BlobServiceEndpoint = StagingEndpoint.ToString(),
                StagingContainer = StagingContainer,
                StagingFolderPath = StagingFolder,
                StagedFiles = new[] { CreateFile("erp3data/workday-concur/delivery-staging/file.pgp", "etag") },
                Status = WorkdayConcurDeliveryStatus.InProgress
            };
        }

        private WorkdayConcurDeliveryService CreateService()
        {
            return CreateService(CreateOptions());
        }

        private WorkdayConcurDeliveryService CreateService(WorkdayConcurOptions options)
        {
            return new WorkdayConcurDeliveryService(
                _configurationService.Object,
                _blobClient.Object,
                _encryptionService.Object,
                _synapseClient.Object,
                Options.Create(options),
                new FakeTimeProvider(Now));
        }

        private static WorkdayConcurOptions CreateOptions()
        {
            return new WorkdayConcurOptions
            {
                SynapseWorkspaceName = "synw-file-transfer",
                ConcurBlobServiceEndpoint = OutputEndpoint.ToString(),
                ConcurBlobContainerName = OutputContainer,
                ConcurDestinationPath = "/in/test",
                ConcurPgpPublicKey = "public-key",
                ConcurPgpKeyId = PgpKeyId,
                ConcurDeliveryIntegrationKeyId = DeliveryIntegrationId,
                ConcurDeliveryActionName = DeliveryActionName
            };
        }
    }
}
