using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the conditional and evidence-preserving Phocas Blob hand-off
    /// </summary>
    public class PhocasBlobStagingClientTests
    {
        private static readonly Guid CorrelationId = new("70000000-0000-0000-0000-000000000001");
        private static readonly Guid ExportRunId = new("70000000-0000-0000-0000-000000000002");
        private static readonly Guid DestinationId = new("70000000-0000-0000-0000-000000000003");

        private readonly Mock<BlobServiceClient> _serviceClient = new();
        private readonly Mock<BlobContainerClient> _containerClient = new();
        private readonly Mock<BlobClient> _blobClient = new();

        [Fact]
        public async Task Given_A_New_Export_When_Staging_Should_Create_The_ActionPrefixed_Blob_With_Integrity_Metadata()
        {
            var content = Encoding.UTF8.GetBytes("row\r\n");
            var request = CreateRequest(content.LongLength);
            var uploadResult = BlobsModelFactory.BlobContentInfo(
                new ETag("\"created\""),
                default,
                null,
                null,
                null,
                null,
                0);
            _serviceClient.Setup(client => client.GetBlobContainerClient("phocas-staging")).Returns(_containerClient.Object);

            _containerClient.Setup(client => client.GetBlobClient("42_2026_ConsXref.txt")).Returns(_blobClient.Object);

            _blobClient
                .Setup(client => client.GetPropertiesAsync(It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            _blobClient
                .Setup(client => client.UploadAsync(
                    It.IsAny<Stream>(),
                    It.Is<BlobUploadOptions>(options =>
                        options.Conditions.IfNoneMatch == ETag.All
                        && options.HttpHeaders.ContentType == "text/plain; charset=utf-8"
                        && options.Metadata["CorrelationID"] == CorrelationId.ToString("D")
                        && options.Metadata["ExportRunID"] == ExportRunId.ToString("D")
                        && options.Metadata["ExportDestinationID"] == DestinationId.ToString("D")
                        && options.Metadata["ContentHash"] == "content-hash"
                        && options.Metadata["RowCount"] == "1"
                        && options.Metadata["RetryCount"] == "2"),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(uploadResult, Mock.Of<Response>()));
            await using var stream = new MemoryStream(content, writable: false);

            var result = await CreateService().StageAsync(request, stream);

            Assert.Equal("phocas-staging/42_2026_ConsXref.txt", result.BlobPath);
            Assert.Equal("\"created\"", result.ETag);
            Assert.False(result.AlreadyStaged);
            _blobClient.VerifyAll();
        }

        [Fact]
        public async Task Given_A_VirtualDirectory_Prefix_When_Staging_Should_Write_The_Blob_At_The_Watched_Path()
        {
            var content = Encoding.UTF8.GetBytes("row\r\n");
            var request = CreateRequest(content.LongLength);
            request.BlobStagingPath = "phocas/hxcustomersalessupplier/delivery-staging-sales";
            var uploadResult = BlobsModelFactory.BlobContentInfo(new ETag("\"created\""), default, null, null, null, null, 0);
            _serviceClient.Setup(client => client.GetBlobContainerClient("phocas")).Returns(_containerClient.Object);

            _containerClient.Setup(client => client.GetBlobClient("hxcustomersalessupplier/delivery-staging-sales/42_2026_ConsXref.txt")).Returns(_blobClient.Object);

            _blobClient
                .Setup(client => client.GetPropertiesAsync(It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            _blobClient
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<BlobUploadOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(uploadResult, Mock.Of<Response>()));
            await using var stream = new MemoryStream(content, writable: false);

            var result = await CreateService().StageAsync(request, stream);

            Assert.Equal("phocas/hxcustomersalessupplier/delivery-staging-sales/42_2026_ConsXref.txt", result.BlobPath);
            _blobClient.VerifyAll();
        }

        [Fact]
        public async Task Given_The_Same_Export_Is_Already_Staged_When_Retrying_Should_Accept_It_Without_Overwriting()
        {
            var content = Encoding.UTF8.GetBytes("row\r\n");
            var request = CreateRequest(content.LongLength);
            var properties = CreateProperties(request, content.LongLength);
            SetupExistingBlob(properties);
            await using var stream = new MemoryStream(content, writable: false);

            var result = await CreateService().StageAsync(request, stream);

            Assert.True(result.AlreadyStaged);
            Assert.Equal("\"existing\"", result.ETag);
            _blobClient.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<BlobUploadOptions>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Another_Worker_Wins_The_Create_Race_When_Its_Evidence_Matches_Should_Accept_The_Existing_Blob()
        {
            var content = Encoding.UTF8.GetBytes("row\r\n");
            var request = CreateRequest(content.LongLength);
            var properties = CreateProperties(request, content.LongLength);
            _serviceClient.Setup(client => client.GetBlobContainerClient("phocas-staging")).Returns(_containerClient.Object);

            _containerClient.Setup(client => client.GetBlobClient("42_2026_ConsXref.txt")).Returns(_blobClient.Object);

            _blobClient
                .SetupSequence(client => client.GetPropertiesAsync(It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"))
                .ReturnsAsync(Response.FromValue(properties, Mock.Of<Response>()));

            _blobClient
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<BlobUploadOptions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(412, "Already created"));

            await using var stream = new MemoryStream(content, writable: false);

            var result = await CreateService().StageAsync(request, stream);

            Assert.True(result.AlreadyStaged);
            Assert.Equal("\"existing\"", result.ETag);
            _blobClient.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<BlobUploadOptions>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Theory]
        [InlineData("run")]
        [InlineData("destination")]
        [InlineData("hash")]
        [InlineData("length")]
        public async Task Given_Different_Export_Evidence_Occupies_The_Name_When_Staging_Should_Reject_Without_Overwriting(string mismatch)
        {
            var content = Encoding.UTF8.GetBytes("row\r\n");
            var request = CreateRequest(content.LongLength);
            var metadata = CreateMetadata(request);
            var length = content.LongLength;
            switch (mismatch)
            {
                case "run":
                    metadata["ExportRunID"] = Guid.NewGuid().ToString("D");
                    break;
                case "destination":
                    metadata["ExportDestinationID"] = Guid.NewGuid().ToString("D");
                    break;
                case "hash":
                    metadata["ContentHash"] = "different-hash";
                    break;
                case "length":
                    length++;
                    break;
            }

            SetupExistingBlob(CreateProperties(metadata, length));
            await using var stream = new MemoryStream(content, writable: false);

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().StageAsync(request, stream));

            Assert.Contains("occupied by different export content", exception.Message);
            _blobClient.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<BlobUploadOptions>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Content_Length_Evidence_Does_Not_Match_The_Stream_When_Staging_Should_Reject_Before_Blob_Access()
        {
            var content = Encoding.UTF8.GetBytes("row\r\n");
            var request = CreateRequest(content.LongLength + 1);
            await using var stream = new MemoryStream(content, writable: false);

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().StageAsync(request, stream));

            _serviceClient.VerifyNoOtherCalls();
        }

        private PhocasBlobStagingClient CreateService()
        {
            return new PhocasBlobStagingClient(_serviceClient.Object);
        }

        private void SetupExistingBlob(BlobProperties properties)
        {
            _serviceClient.Setup(client => client.GetBlobContainerClient("phocas-staging")).Returns(_containerClient.Object);

            _containerClient.Setup(client => client.GetBlobClient("42_2026_ConsXref.txt")).Returns(_blobClient.Object);

            _blobClient
                .Setup(client => client.GetPropertiesAsync(It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(properties, Mock.Of<Response>()));
        }

        private static PhocasBlobStageRequest CreateRequest(long contentLength)
        {
            return new PhocasBlobStageRequest
            {
                BlobStagingPath = "phocas-staging",
                BlobName = "42_2026_ConsXref.txt",
                ExportRunId = ExportRunId,
                ExportDestinationId = DestinationId,
                CorrelationId = CorrelationId,
                ContentHash = "content-hash",
                ContentLength = contentLength,
                RowCount = 1,
                RetryCount = 2
            };
        }

        private static Dictionary<string, string> CreateMetadata(PhocasBlobStageRequest request)
        {
            return new Dictionary<string, string>
            {
                ["ExportRunID"] = request.ExportRunId.ToString("D"),
                ["ExportDestinationID"] = request.ExportDestinationId.ToString("D"),
                ["ContentHash"] = request.ContentHash
            };
        }

        private static BlobProperties CreateProperties(PhocasBlobStageRequest request, long contentLength)
        {
            return CreateProperties(CreateMetadata(request), contentLength);
        }

        private static BlobProperties CreateProperties(IDictionary<string, string> metadata, long contentLength)
        {
            return BlobsModelFactory.BlobProperties(
                lastModified: default,
                leaseState: default,
                leaseStatus: default,
                contentLength: contentLength,
                leaseDuration: default,
                eTag: new ETag("\"existing\""),
                contentHash: null!,
                contentEncoding: null!,
                contentDisposition: null!,
                contentLanguage: null!,
                destinationSnapshot: null!,
                cacheControl: null!,
                isIncrementalCopy: false,
                blobSequenceNumber: 0,
                copyStatus: default,
                acceptRanges: null!,
                copySource: null!,
                blobCommittedBlockCount: 0,
                copyProgress: null!,
                isServerEncrypted: false,
                copyId: null!,
                encryptionKeySha256: null!,
                copyStatusDescription: null!,
                encryptionScope: null!,
                copyCompletedOn: default,
                accessTier: null!,
                blobType: default,
                accessTierInferred: false,
                metadata: metadata,
                archiveStatus: null!,
                createdOn: default,
                accessTierChangedOn: default,
                contentType: null!);
        }
    }
}
