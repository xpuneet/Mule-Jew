﻿using Microsoft.Extensions.Options;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text.Json;

namespace STUK.TradeAccountService.Tests.Services;

public class TradeAccountInvoiceServiceTests
{
    private readonly Mock<IDbExecutor> _dbExecutorMock;
    private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
    private readonly TradeAccountInvoiceService _service;

    public TradeAccountInvoiceServiceTests()
    {
        _dbExecutorMock = new Mock<IDbExecutor>();
        _loggerMock = new Mock<IAppInsightsLoggerHelper>();

        var downloadSettings = new DownloadSettings
        {
            ["Invoice"] = new DocumentTypeDownloadSettings
            {
                ContainerName = "invoicetest",
                FilePrepareUrl = null,
                DownloadDelayHours = 24
            }
        };

        var optionsMock = new Mock<IOptions<DownloadSettings>>();
        optionsMock.Setup(o => o.Value).Returns(downloadSettings);

        _service = new TradeAccountInvoiceService(
            _dbExecutorMock.Object,
            optionsMock.Object,
            _loggerMock.Object);
    }

    #region Helpers

    private void SetupDbResponse(string response, string storedProc)
    {
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                storedProc,
                It.IsAny<object>()))
            .ReturnsAsync(response);
    }

    private void VerifyLogError(Exception ex, string messageContains, Times times)
    {
        _loggerMock.Verify(l =>
            l.LogError(
                ex,
                It.Is<string>(s => s.Contains(messageContains)),
                It.IsAny<string>(),
                It.IsAny<string>()),
            times);
    }

    private static InvoiceFilterRequest CreateValidFilterRequest() => new(
        CustomerAccount: "ACC001",
        SortBy: "issuedate",
        SortOrder: "desc",
        PageNumber: 1,
        PageSize: 10
        );

    #endregion

    #region GetInvoiceByStandardInvoiceNo

    [Fact]
    public async Task GetInvoiceByStandardInvoiceNo_ValidJson_ReturnsInvoice()
    {
        SetupDbResponse(JsonSerializer.Serialize(new InvoiceResponse()),
            StoredProcedures.GetInvoiceDetailsByStandardInvoiceNo);

        var result = await _service.GetInvoiceByStandardInvoiceNoAsync("INV-001", "123");

        Assert.NotNull(result);
    }

    [Fact]
    public async Task GetInvoiceByStandardInvoiceNo_EmptyJson_ReturnsNull()
    {
        SetupDbResponse(string.Empty,
            StoredProcedures.GetInvoiceDetailsByStandardInvoiceNo);

        var result = await _service.GetInvoiceByStandardInvoiceNoAsync("INV-001", "123");

        Assert.Null(result);
    }

    [Fact]
    public async Task GetInvoiceByStandardInvoiceNo_DbThrows_LogsAndRethrows()
    {
        var exception = new Exception("DB error");

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetInvoiceDetailsByStandardInvoiceNo,
                It.IsAny<object>()))
            .ThrowsAsync(exception);

        var ex = await Assert.ThrowsAsync<Exception>(() =>
            _service.GetInvoiceByStandardInvoiceNoAsync("INV-001", "123"));

        Assert.Equal("DB error", ex.Message);
    }

    #endregion

    #region SearchInvoiceDocuments

    [Fact]
    public async Task SearchInvoiceDocuments_ValidJson_ReturnsResponse()
    {
        SetupDbResponse(JsonSerializer.Serialize(new InvoiceSearchResponse()),
            StoredProcedures.GetInvoiceSearchByAccountCode);

        var result = await _service.FilterInvoiceDocumentsAsync(CreateValidFilterRequest());

        Assert.NotNull(result);
    }

    [Fact]
    public async Task SearchInvoiceDocuments_EmptyJson_ReturnsEmptyObject()
    {
        SetupDbResponse(string.Empty,
            StoredProcedures.GetInvoiceSearchByAccountCode);

        var result = await _service.FilterInvoiceDocumentsAsync(CreateValidFilterRequest());

        Assert.NotNull(result);
    }

    [Fact]
    public async Task SearchInvoiceDocuments_DbThrows_LogsAndRethrows()
    {
        var exception = new Exception("DB failure");

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetInvoiceSearchByAccountCode,
                It.IsAny<object>()))
            .ThrowsAsync(exception);

        var ex = await Assert.ThrowsAsync<Exception>(() =>
            _service.FilterInvoiceDocumentsAsync(CreateValidFilterRequest()));

        Assert.Equal("DB failure", ex.Message);
    }

    [Fact]
    public async Task SearchInvoiceDocuments_CallsCorrectStoredProcedure()
    {
        SetupDbResponse("{}", StoredProcedures.GetInvoiceSearchByAccountCode);

        await _service.FilterInvoiceDocumentsAsync(CreateValidFilterRequest());

        _dbExecutorMock.Verify(db =>
            db.ExecuteSingleAsync<string>(
                StoredProcedures.GetInvoiceSearchByAccountCode,
                It.IsAny<object>()),
            Times.Once());
    }

    #endregion
}