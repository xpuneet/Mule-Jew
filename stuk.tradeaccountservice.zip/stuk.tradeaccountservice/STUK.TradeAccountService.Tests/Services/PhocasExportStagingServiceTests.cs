using Azure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Tests.Helpers;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests durable generation and Blob hand-off for the Phocas destination
    /// </summary>
    public class PhocasExportStagingServiceTests
    {
        private static readonly DateTimeOffset Now = new(2026, 8, 10, 0, 31, 0, TimeSpan.Zero);
        private static readonly Guid DestinationId = new("50000000-0000-0000-0000-000000000001");
        private static readonly Guid ExportRunId = new("50000000-0000-0000-0000-000000000002");
        private static readonly Guid ClaimToken = new("50000000-0000-0000-0000-000000000003");
        private static readonly Guid CorrelationId = new("50000000-0000-0000-0000-000000000004");

        private readonly Mock<IConsolidatedSalesExportDataService> _exportDataService = new();
        private readonly Mock<IPhocasConsXrefFileGenerator> _fileGenerator = new();
        private readonly Mock<IPhocasBlobStagingClient> _blobStagingClient = new();

        [Fact]
        public async Task Given_ClaimedSnapshot_When_Run_Should_StageAndCompleteThePhocasHandoff()
        {
            var work = CreateWork();
            work.AttemptCount = 6;
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("Phocas", "invocation-1", 900, 5, null, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(work);
            _fileGenerator
                .Setup(generator => generator.GenerateAsync(ExportRunId, 2026, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .Returns<Guid, int, Stream, CancellationToken>(async (_, _, stream, cancellationToken) =>
                {
                    await stream.WriteAsync(bytes, cancellationToken);
                    return new ConsolidatedSalesExportFileResult
                    {
                        FileName = "2026_ConsXref.txt",
                        RowCount = 2,
                        ByteCount = bytes.LongLength,
                        ContentHash = "content-hash"
                    };
                });
            _blobStagingClient
                .Setup(client => client.StageAsync(
                    It.Is<PhocasBlobStageRequest>(request =>
                        request.BlobStagingPath == "phocas-staging"
                        && request.BlobName == "42_2026_ConsXref.txt"
                        && request.RowCount == 2
                        && request.RetryCount == 0),
                    It.IsAny<Stream>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new PhocasBlobStageResult
                {
                    BlobPath = "phocas-staging/42_2026_ConsXref.txt",
                    ETag = "etag"
                });
            _exportDataService
                .Setup(service => service.CompleteDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "2026_ConsXref.txt",
                    "phocas-staging/42_2026_ConsXref.txt",
                    "content-hash",
                    2,
                    bytes.LongLength,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService().RunAsync("invocation-1");

            _fileGenerator.VerifyAll();
            _blobStagingClient.VerifyAll();
            _exportDataService.VerifyAll();
            _exportDataService.Verify(service => service.FailDestinationAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<int>(), It.IsAny<string?>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_NoEligibleDestination_When_Run_Should_NotGenerateAFile()
        {
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("Phocas", "invocation-1", 900, 5, DestinationId, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesExportDestinationWork?)null);

            await CreateService().RunAsync("invocation-1", DestinationId);

            _fileGenerator.VerifyNoOtherCalls();
            _blobStagingClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_TransientBlobFailure_When_Run_Should_DurablyScheduleRetry()
        {
            var work = CreateWork();
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("Phocas", "invocation-1", 900, 5, null, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(work);
            _fileGenerator
                .Setup(generator => generator.GenerateAsync(ExportRunId, 2026, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .Returns<Guid, int, Stream, CancellationToken>(async (_, _, stream, cancellationToken) =>
                {
                    await stream.WriteAsync(bytes, cancellationToken);
                    return new ConsolidatedSalesExportFileResult
                    {
                        FileName = "2026_ConsXref.txt",
                        RowCount = 2,
                        ByteCount = bytes.LongLength,
                        ContentHash = "content-hash"
                    };
                });
            _blobStagingClient
                .Setup(client => client.StageAsync(It.IsAny<PhocasBlobStageRequest>(), It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(503, "Blob storage unavailable"));
            _exportDataService
                .Setup(service => service.FailDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "BlobUnavailable",
                    "Blob storage unavailable",
                    Now.AddMinutes(5),
                    5,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationFailureResult { Status = "Retry" });

            await CreateService().RunAsync("invocation-1");

            _exportDataService.VerifyAll();
            _exportDataService.Verify(service => service.CompleteDestinationAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<long>(), It.IsAny<long>(), It.IsAny<string?>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_ExistingBlobContainsDifferentExport_When_Run_Should_RecordPermanentFailure()
        {
            var work = CreateWork();
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("Phocas", "invocation-1", 900, 5, null, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(work);
            _fileGenerator
                .Setup(generator => generator.GenerateAsync(ExportRunId, 2026, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .Returns<Guid, int, Stream, CancellationToken>(async (_, _, stream, cancellationToken) =>
                {
                    await stream.WriteAsync(bytes, cancellationToken);
                    return new ConsolidatedSalesExportFileResult
                    {
                        FileName = "2026_ConsXref.txt",
                        RowCount = 2,
                        ByteCount = bytes.LongLength,
                        ContentHash = "content-hash"
                    };
                });
            _blobStagingClient
                .Setup(client => client.StageAsync(It.IsAny<PhocasBlobStageRequest>(), It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidDataException("The watched Phocas Blob is occupied by different export content."));
            _exportDataService
                .Setup(service => service.FailDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "InvalidFileContract",
                    It.Is<string>(message => message.Contains("different export content")),
                    null,
                    1,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationFailureResult { Status = "Failed" });

            await CreateService().RunAsync("invocation-1");

            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_GeneratedRowCountMismatch_When_Run_Should_RecordPermanentFailureWithoutStaging()
        {
            var work = CreateWork();
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("Phocas", "invocation-1", 900, 5, null, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(work);
            _fileGenerator
                .Setup(generator => generator.GenerateAsync(ExportRunId, 2026, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportFileResult
                {
                    FileName = "2026_ConsXref.txt",
                    RowCount = 1,
                    ByteCount = 5,
                    ContentHash = "content-hash"
                });
            _exportDataService
                .Setup(service => service.FailDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "InvalidFileContract",
                    It.Is<string>(message => message.Contains("row count")),
                    null,
                    1,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationFailureResult { Status = "Failed" });

            await CreateService().RunAsync("invocation-1");

            _exportDataService.VerifyAll();
            _blobStagingClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_LeaseRenewalFailsDuringStaging_When_Run_Should_CancelAndContainTheBlobWrite()
        {
            var work = CreateWork();
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            var stagingStarted = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var stagingCancelled = false;
            var timeProvider = new FakeTimeProvider(Now);
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("Phocas", "invocation-1", 900, 5, null, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(work);
            _exportDataService
                .Setup(service => service.RenewDestinationLeaseAsync(
                    DestinationId,
                    ClaimToken,
                    900,
                    It.Is<DateTimeOffset>(renewedOn => renewedOn >= Now.AddSeconds(60)),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Lease lost"));
            _fileGenerator
                .Setup(generator => generator.GenerateAsync(ExportRunId, 2026, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .Returns<Guid, int, Stream, CancellationToken>(async (_, _, stream, cancellationToken) =>
                {
                    await stream.WriteAsync(bytes, cancellationToken);
                    return new ConsolidatedSalesExportFileResult
                    {
                        FileName = "2026_ConsXref.txt",
                        RowCount = 2,
                        ByteCount = bytes.LongLength,
                        ContentHash = "content-hash"
                    };
                });
            _blobStagingClient
                .Setup(client => client.StageAsync(It.IsAny<PhocasBlobStageRequest>(), It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .Returns<PhocasBlobStageRequest, Stream, CancellationToken>(async (_, _, cancellationToken) =>
                {
                    stagingStarted.SetResult();
                    try
                    {
                        await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
                    }
                    catch (OperationCanceledException)
                    {
                        stagingCancelled = true;
                        throw;
                    }

                    return new PhocasBlobStageResult();
                });

            var runTask = CreateService(timeProvider).RunAsync("invocation-1");
            await stagingStarted.Task;

            for (var attempt = 0; attempt < 5 && !runTask.IsCompleted; attempt++)
            {
                timeProvider.Advance(TimeSpan.FromSeconds(60));
                await Task.Yield();
            }

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(
                () => runTask.WaitAsync(TimeSpan.FromSeconds(5)));

            Assert.Equal("Lease lost", exception.Message);
            Assert.True(stagingCancelled);
            _exportDataService.VerifyAll();
            _exportDataService.Verify(service => service.CompleteDestinationAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<long>(), It.IsAny<long>(), It.IsAny<string?>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _exportDataService.Verify(service => service.FailDestinationAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<int>(), It.IsAny<string?>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_A_VirtualDirectory_In_The_Staging_Setting_When_Run_Should_Preserve_It_For_The_Blob_Client()
        {
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("Phocas", "invocation-1", 900, 5, null, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesExportDestinationWork?)null);

            await CreateService(blobStagingPath: "phocas/hxcustomersalessupplier/delivery-staging-sales").RunAsync("invocation-1");

            _exportDataService.VerifyAll();
        }

        [Theory]
        [InlineData("phocas-staging\\sales")]
        [InlineData("phocas-staging//sales")]
        [InlineData("/phocas-staging")]
        [InlineData("phocas-staging/")]
        public async Task Given_An_Invalid_Staging_Path_When_Run_Should_Reject_It(string stagingPath)
        {
            var service = CreateService(blobStagingPath: stagingPath);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => service.RunAsync("invocation-1"));

            Assert.Contains("valid virtual-directory prefix", exception.Message);
            _exportDataService.VerifyNoOtherCalls();
            _fileGenerator.VerifyNoOtherCalls();
            _blobStagingClient.VerifyNoOtherCalls();
        }

        private PhocasExportStagingService CreateService(TimeProvider? timeProvider = null, string blobStagingPath = "phocas-staging")
        {
            return new PhocasExportStagingService(
                Mock.Of<ILogger<PhocasExportStagingService>>(),
                _exportDataService.Object,
                _fileGenerator.Object,
                _blobStagingClient.Object,
                Options.Create(new PhocasBlobStagingOptions
                {
                    BlobStagingPath = blobStagingPath,
                    FileActionId = "42"
                }),
                timeProvider ?? new FixedTimeProvider(Now));
        }

        private static ConsolidatedSalesExportDestinationWork CreateWork()
        {
            return new ConsolidatedSalesExportDestinationWork
            {
                Id = DestinationId,
                ExportRunId = ExportRunId,
                CorrelationId = CorrelationId,
                ExportYear = 2026,
                ExtractedRowCount = 2,
                Destination = "Phocas",
                Status = "Claimed",
                AttemptCount = 1,
                RetryCycleAttemptCount = 1,
                ClaimToken = ClaimToken
            };
        }
    }
}
