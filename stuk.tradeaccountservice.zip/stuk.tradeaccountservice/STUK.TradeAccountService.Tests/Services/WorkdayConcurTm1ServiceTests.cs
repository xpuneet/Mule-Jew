using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests managed TM1 pickup parameters and result validation
    /// </summary>
    public class WorkdayConcurTm1ServiceTests
    {
        private static readonly Guid CorrelationId = new("40000000-0000-0000-0000-000000000001");
        private static readonly DateTimeOffset Now = new(2026, 9, 4, 8, 30, 0, TimeSpan.Zero);

        private readonly Mock<IFileTransferConfigurationService> _configurationService = new(MockBehavior.Strict);
        private readonly Mock<ISynapsePipelineClient> _synapseClient = new(MockBehavior.Strict);
        private readonly Mock<IWorkdayConcurBlobClient> _blobClient = new(MockBehavior.Strict);

        /// <summary>
        /// Verifies that only the evidenced TM1 source and destination are passed to the generic pipeline
        /// </summary>
        [Fact]
        public async Task Given_ValidConfiguration_When_Starting_Should_UseExactTm1Contract()
        {
            var configuration = CreateConfiguration();

            _configurationService
                .Setup(x => x.GetTm1PickupAsync("integration-id", "PICKUP", default))
                .ReturnsAsync(configuration);

            _synapseClient.Setup(x => x.StartAsync("SFTP_To_Blob", It.Is<IReadOnlyDictionary<string, object?>>(parameters =>
                        Equals(parameters["SourceFilePath"], "/prod/tm1serv/Exports")
                        && Equals(parameters["FileStartFilter"], "TM1.csv")
                        && Equals(parameters["FileEndFilter"], "TM1.csv")
                        && Equals(parameters["DestinationFilePath"], "stdl-concur-tst-uks/input")
                        && Equals(parameters["DestinationFileFormat"], "TM1.csv")
                        && Equals(parameters["SourcePassword"], "tm1-password-secret")
                        && Equals(parameters["CorrelationID"], CorrelationId.ToString("D"))),
                    default))
                .ReturnsAsync("synapse-run");

            var checkpoint = await CreateService().StartAsync(CorrelationId);

            Assert.Equal("synapse-run", checkpoint.SynapseRunId);
            Assert.Equal("InProgress", checkpoint.Status);
            Assert.Equal("stdl-concur-tst-uks", checkpoint.DestinationContainer);
            Assert.Equal("input/TM1.csv", checkpoint.DestinationBlobName);

            _configurationService.VerifyAll();
            _synapseClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that a successful Synapse run is not complete until the fresh non-empty Blob is validated
        /// </summary>
        [Fact]
        public async Task Given_SuccessfulPipelineAndFreshBlob_When_Completing_Should_ReturnFileIdentity()
        {
            var checkpoint = CreateCheckpoint();
            var identity = new WorkdayConcurFileIdentity
            {
                Path = "input/TM1.csv",
                ContentLength = 100,
                ETag = "etag",
                LastModifiedOn = Now.AddMinutes(1)
            };

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync("synapse-run", default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = "synapse-run", Status = "Succeeded" });

            _blobClient
                .Setup(x => x.GetRequiredFreshFileAsync(
                    new Uri("https://storage.blob.core.windows.net"),
                    "stdl-concur-tst-uks",
                    "input/TM1.csv",
                    Now,
                    default))
                .ReturnsAsync(identity);

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("Succeeded", result.Status);
            Assert.Same(identity, result.File);
            Assert.Equal(Now, result.CompletedOn);

            _synapseClient.VerifyAll();
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that missing, empty or stale Blob validation failures become restart-safe terminal checkpoints
        /// </summary>
        [Fact]
        public async Task Given_InvalidBlob_When_Completing_Should_ReturnValidationFailure()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync("synapse-run", default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = "synapse-run", Status = "Succeeded" });

            _blobClient
                .Setup(x => x.GetRequiredFreshFileAsync(
                    It.IsAny<Uri>(), "stdl-concur-tst-uks", "input/TM1.csv", Now, default))
                .ThrowsAsync(new InvalidDataException("TM1.csv is stale"));

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("ValidationFailed", result.Status);
            Assert.Equal("TM1.csv is stale", result.FailureMessage);
            Assert.Null(result.File);
        }

        /// <summary>
        /// Verifies that a failed Synapse run is retained for restart-safe failure handling without accepting a Blob
        /// </summary>
        [Fact]
        public async Task Given_FailedPipeline_When_Completing_Should_ReturnTerminalFailure()
        {
            var checkpoint = CreateCheckpoint();
            _synapseClient
                .Setup(x => x.WaitForCompletionAsync("synapse-run", default))
                .ReturnsAsync(new SynapsePipelineRun
                {
                    RunId = "synapse-run",
                    Status = "Failed",
                    Message = "SFTP source unavailable"
                });

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("Failed", result.Status);
            Assert.Equal("SFTP source unavailable", result.FailureMessage);
            Assert.Null(result.File);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that configuration drift cannot broaden the transfer beyond the one required file
        /// </summary>
        [Fact]
        public async Task Given_BroaderSourcePattern_When_Starting_Should_RejectConfiguration()
        {
            var configuration = CreateConfiguration();
            configuration.Action.SourceFileNameFormat = "*.csv";
            _configurationService
                .Setup(x => x.GetTm1PickupAsync("integration-id", "PICKUP", default))
                .ReturnsAsync(configuration);

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().StartAsync(CorrelationId));

            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies every material File Transfer contract value before Synapse is called
        /// </summary>
        [Theory]
        [InlineData("pipeline", typeof(InvalidOperationException))]
        [InlineData("source-folder", typeof(InvalidOperationException))]
        [InlineData("destination-folder", typeof(InvalidOperationException))]
        [InlineData("source-host", typeof(ArgumentException))]
        [InlineData("source-username", typeof(ArgumentException))]
        [InlineData("source-password", typeof(ArgumentException))]
        [InlineData("blob-endpoint", typeof(InvalidOperationException))]
        [InlineData("missing-action", typeof(InvalidOperationException))]
        [InlineData("missing-sftp", typeof(InvalidOperationException))]
        [InlineData("missing-blob", typeof(InvalidOperationException))]
        public async Task Given_InvalidTransferContract_When_Starting_Should_RejectConfiguration(string invalidField, Type exceptionType)
        {
            var configuration = CreateConfiguration();
            Invalidate(configuration, invalidField);

            _configurationService
                .Setup(x => x.GetTm1PickupAsync("integration-id", "PICKUP", default))
                .ReturnsAsync(configuration);

            await Assert.ThrowsAsync(exceptionType, () => CreateService().StartAsync(CorrelationId));

            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies environment identifiers and the correlation identifier are required before configuration lookup
        /// </summary>
        [Theory]
        [InlineData("", "PICKUP")]
        [InlineData("integration-id", "")]
        public async Task Given_InvalidIdentifiers_When_Starting_Should_RejectBeforeConfigurationLookup(string integrationId, string actionName)
        {
            var options = new WorkdayConcurOptions
            {
                Tm1PickupIntegrationKeyId = integrationId,
                Tm1PickupActionName = actionName
            };

            await Assert.ThrowsAsync<ArgumentException>(() => CreateService(options).StartAsync(CorrelationId));

            _configurationService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies an empty correlation identifier is rejected before configuration lookup
        /// </summary>
        [Fact]
        public async Task Given_EmptyCorrelationId_When_Starting_Should_RejectBeforeConfigurationLookup()
        {
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().StartAsync(Guid.Empty));

            _configurationService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies every checkpoint field needed to resume the pickup is mandatory
        /// </summary>
        [Theory]
        [InlineData("run")]
        [InlineData("endpoint")]
        [InlineData("container")]
        [InlineData("blob")]
        public async Task Given_InvalidCheckpoint_When_Completing_Should_RejectBeforeSynapse(string invalidField)
        {
            var checkpoint = CreateCheckpoint();
            switch (invalidField)
            {
                case "run":
                    checkpoint.SynapseRunId = string.Empty;
                    break;
                case "endpoint":
                    checkpoint.BlobServiceEndpoint = string.Empty;
                    break;
                case "container":
                    checkpoint.DestinationContainer = string.Empty;
                    break;
                case "blob":
                    checkpoint.DestinationBlobName = string.Empty;
                    break;
            }

            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().CompleteAsync(checkpoint));

            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies a missing output Blob is recorded as validation failure
        /// </summary>
        [Fact]
        public async Task Given_MissingBlob_When_Completing_Should_ReturnValidationFailure()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync("synapse-run", default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = "synapse-run", Status = "Succeeded" });

            _blobClient
                .Setup(x => x.GetRequiredFreshFileAsync(It.IsAny<Uri>(), "stdl-concur-tst-uks", "input/TM1.csv", Now, default))
                .ThrowsAsync(new FileNotFoundException("TM1.csv was not produced"));

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("ValidationFailed", result.Status);
            Assert.Equal("TM1.csv was not produced", result.FailureMessage);
        }

        private WorkdayConcurTm1Service CreateService()
        {
            return CreateService(new WorkdayConcurOptions
            {
                SynapseWorkspaceName = "synw-file-transfer",
                Tm1PickupIntegrationKeyId = "integration-id",
                Tm1PickupActionName = "PICKUP",
                ConcurBlobContainerName = "stdl-concur-tst-uks"
            });
        }

        private WorkdayConcurTm1Service CreateService(WorkdayConcurOptions options)
        {
            return new WorkdayConcurTm1Service(_configurationService.Object, _synapseClient.Object, _blobClient.Object, Options.Create(options), new FakeTimeProvider(Now));
        }

        private static void Invalidate(WorkdayConcurTm1TransferConfiguration configuration, string invalidField)
        {
            switch (invalidField)
            {
                case "pipeline":
                    configuration.Action.PipeLineName = "Other_Pipeline";
                    break;
                case "source-folder":
                    configuration.Action.SourceFolderPath = "/Other";
                    break;
                case "destination-folder":
                    configuration.Action.DestinationFolderPath = "other";
                    break;
                case "source-host":
                    configuration.Sftp.IpAddress = string.Empty;
                    break;
                case "source-username":
                    configuration.Sftp.Username = string.Empty;
                    break;
                case "source-password":
                    configuration.Sftp.PasswordKey = string.Empty;
                    break;
                case "blob-endpoint":
                    configuration.Blob.ServiceEndPoint = "http://storage.blob.core.windows.net";
                    break;
                case "missing-action":
                    configuration.Action = null!;
                    break;
                case "missing-sftp":
                    configuration.Sftp = null!;
                    break;
                case "missing-blob":
                    configuration.Blob = null!;
                    break;
            }
        }

        private static WorkdayConcurTm1TransferConfiguration CreateConfiguration()
        {
            return new WorkdayConcurTm1TransferConfiguration
            {
                Action = new FileTransferActionConfiguration
                {
                    Id = "action-id",
                    SourceId = "source-id",
                    DestinationId = "destination-id",
                    PipeLineName = "SFTP_To_Blob",
                    SourceFileNameFormat = "TM1.csv",
                    SourceFolderPath = "/prod/tm1serv/Exports",
                    DestinationFileNameFormat = "TM1.csv",
                    DestinationFolderPath = "stdl-concur-tst-uks/input"
                },
                Sftp = new SynapseSftpConfiguration
                {
                    IpAddress = "tm1.example",
                    Username = "tm1-user",
                    PasswordKey = "tm1-password-secret"
                },
                Blob = new FileTransferBlobConfiguration
                {
                    ServiceEndPoint = "https://storage.blob.core.windows.net"
                }
            };
        }

        private static WorkdayConcurTm1Checkpoint CreateCheckpoint()
        {
            return new WorkdayConcurTm1Checkpoint
            {
                SynapseRunId = "synapse-run",
                StartedOn = Now,
                BlobServiceEndpoint = "https://storage.blob.core.windows.net",
                DestinationContainer = "stdl-concur-tst-uks",
                DestinationBlobName = "input/TM1.csv",
                Status = "InProgress"
            };
        }
    }
}
