using System.Xml.Linq;

namespace STUK.TradeAccountService.Tests.Services
{
    internal sealed class HxInvoiceXmlBuilder
    {
        private static readonly XNamespace KmsgNamespace = "http://xml.kerridge.net/k8msg";
        private static readonly XNamespace BasdaNamespace = "urn:schemas-basda-org:2000:salesInvoice:xdr:3.01";

        public string InvoiceNumber { get; set; } = "CON-100";

        public int LineCount { get; set; } = 1;

        public XElement BuildInvoice()
        {
            return new XElement(
                BasdaName("Invoice"),
                BuildInvoiceHead(),
                BuildInvoiceReferences(),
                new XElement(BasdaName("InvoiceDate"), "2026-07-12"),
                new XElement(BasdaName("TaxPointDate"), "2026-07-11"),
                BuildParty(
                    "Supplier",
                    "SupplierReferences",
                    "BuyersCodeForSupplier",
                    "SUP001",
                    "Supplier Ltd",
                    "Supplier Street",
                    "Supplier City",
                    "SU1 1AA"),
                BuildParty(
                    "Buyer",
                    "BuyerReferences",
                    "SuppliersCodeForBuyer",
                    "ACC001",
                    "Customer Ltd",
                    "Buyer Street",
                    "Buyer City",
                    "BU1 1AA"),
                BuildParty(
                    "InvoiceTo",
                    "InvoiceToReferences",
                    "SuppliersCodeForInvoiceTo",
                    "INV001",
                    "Invoice Recipient Ltd",
                    "Invoice Street",
                    "Invoice City",
                    "IN1 1AA"),
                BuildInvoiceExtensions(),
                Enumerable.Range(1, LineCount).Select(BuildLine),
                BuildTaxSubTotal(),
                BuildInvoiceTotal());
        }

        public static string BuildDocument(params XElement[] invoices)
        {
            var document = new XDocument(
                new XDeclaration("1.0", "utf-8", null),
                new XElement(
                    KmsgName("message"),
                    new XAttribute(XNamespace.Xmlns + "kmsg", KmsgNamespace),
                    new XAttribute("xmlns", BasdaNamespace),
                    new XElement(KmsgName("body"), invoices)));

            return $"{document.Declaration}{Environment.NewLine}{document.Root!.ToString(SaveOptions.DisableFormatting)}";
        }

        public static XElement BuildMinimalInvoice(string invoiceNumber)
        {
            return new XElement(
                BasdaName("Invoice"),
                new XElement(
                    BasdaName("InvoiceReferences"),
                    new XElement(BasdaName("SuppliersInvoiceNumber"), invoiceNumber)));
        }

        private XElement BuildInvoiceReferences()
        {
            return new XElement(
                BasdaName("InvoiceReferences"),
                new XElement(BasdaName("BuyersOrderNumber"), "BUY-ORDER-100"),
                new XElement(BasdaName("SuppliersInvoiceNumber"), InvoiceNumber),
                new XElement(BasdaName("DeliveryNoteNumber"), "DEL-100"),
                new XElement(BasdaName("SuppliersOrderReference"), "SUP-ORDER-100"));
        }

        private static XElement BuildInvoiceHead()
        {
            return new XElement(
                BasdaName("InvoiceHead"),
                BuildCodedValue(BasdaName("InvoiceType"), "INV", "Invoice"),
                new XElement(
                    BasdaName("InvoiceCurrency"),
                    BuildCodedValue(BasdaName("Currency"), "GBP", "Pounds Sterling")));
        }

        private static XElement BuildParty(
            string elementName,
            string referencesElementName,
            string accountElementName,
            string accountCode,
            string partyName,
            string street,
            string city,
            string postCode)
        {
            return new XElement(
                BasdaName(elementName),
                new XElement(
                    BasdaName(referencesElementName),
                    new XElement(BasdaName(accountElementName), accountCode)),
                new XElement(BasdaName("Party"), partyName),
                new XElement(
                    BasdaName("Address"),
                    new XElement(BasdaName("AddressLine"), "Address Line 1"),
                    new XElement(BasdaName("AddressLine"), "Address Line 2"),
                    new XElement(BasdaName("Street"), street),
                    new XElement(BasdaName("City"), city),
                    new XElement(BasdaName("State"), "State"),
                    new XElement(BasdaName("PostCode"), postCode)));
        }

        private static XElement BuildInvoiceExtensions()
        {
            return new XElement(
                BasdaName("Extensions"),
                new XElement(
                    KmsgName("Consolidated"),
                    new XElement(
                        KmsgName("SupplierDocumentFlags"),
                        BuildCodedValue(KmsgName("DocumentBrand"), "JEW", "Jewson")),
                    new XElement(
                        KmsgName("SupplierContactDetails"),
                        BuildCodedValue(KmsgName("Branch"), "0580", "Leeds")),
                    new XElement(
                        KmsgName("SupplierCreditDetails"),
                        BuildCodedValue(KmsgName("CreditTerms"), "30D", "30 Days"))));
        }

        private static XElement BuildLine(int lineNumber)
        {
            return new XElement(
                BasdaName("InvoiceLine"),
                new XAttribute("Action", "Add"),
                new XElement(
                    BasdaName("LineNumber"),
                    new XAttribute("Preserve", "true"),
                    lineNumber),
                new XElement(
                    BasdaName("InvoiceLineReferences"),
                    new XElement(BasdaName("OrderLineNumber"), "10"),
                    new XElement(BasdaName("DeliveryNoteNumber"), "DEL-LINE-100"),
                    new XElement(BasdaName("DeliveryNoteLineNumber"), "20")),
                new XElement(
                    BasdaName("Product"),
                    new XElement(BasdaName("SuppliersProductCode"), $"SKU{lineNumber:000}"),
                    new XElement(BasdaName("Description"), "Test product")),
                new XElement(
                    BasdaName("Quantity"),
                    new XAttribute("UOMCode", "EA"),
                    new XAttribute("UOMDescription", "Each"),
                    new XElement(BasdaName("Amount"), "2")),
                new XElement(
                    BasdaName("Price"),
                    new XAttribute("UOMCode", "EA"),
                    new XAttribute("UOMDescription", "Each"),
                    new XElement(BasdaName("UnitPrice"), "9.99")),
                new XElement(
                    BasdaName("PercentDiscount"),
                    new XElement(BasdaName("Percentage"), "5")),
                new XElement(
                    BasdaName("LineTax"),
                    BuildCodedValue(BasdaName("TaxRate"), "S", "20"),
                    new XElement(BasdaName("TaxValue"), "4.00")),
                new XElement(BasdaName("LineTotal"), "19.98"),
                BuildLineExtensions());
        }

        private static XElement BuildLineExtensions()
        {
            return new XElement(
                BasdaName("Extensions"),
                new XElement(
                    KmsgName("HXConsolidatedLine"),
                    new XElement(KmsgName("DocumentTextLine"), "true"),
                    new XElement(KmsgName("OriginalOrderLineNumber"), "100"),
                    new XElement(KmsgName("SupplierPartAnalysisCode"), "ANALYSIS"),
                    new XElement(KmsgName("SpecialProduct"), "false"),
                    new XElement(KmsgName("BuyersOrderNumber"), "ORD-100"),
                    new XElement(KmsgName("SuppliersOrderReference"), "SUP-REF-100"),
                    new XElement(KmsgName("SupplierDespatchDate"), "2026-07-10"),
                    new XElement(KmsgName("SupplierCodeForDelivery"), "DEL-SUP-001"),
                    new XElement(
                        KmsgName("SupplierOrderFlags"),
                        BuildCodedValue(KmsgName("OrderType"), "SALE", "Sale"),
                        BuildCodedValue(KmsgName("OrderCategory"), "NORMAL", "Normal"),
                        BuildCodedValue(KmsgName("DeliveryMethod"), "DELIVERY", "Delivery")),
                    BuildCustomerInformation()));
        }

        private static XElement BuildCustomerInformation()
        {
            return new XElement(
                KmsgName("CustomerInformation"),
                new XElement(KmsgName("JobNumber"), "JOB-1"),
                new XElement(
                    KmsgName("JobAddress"),
                    new XElement(KmsgName("AddressLine"), "Job Address 1"),
                    new XElement(KmsgName("AddressLine"), "Job Address 2"),
                    new XElement(KmsgName("Street"), "Job Street"),
                    new XElement(KmsgName("City"), "Job City"),
                    new XElement(KmsgName("State"), "Job State"),
                    new XElement(KmsgName("PostCode"), "JO1 1AA")),
                new XElement(KmsgName("ContractNumber"), "CONTRACT-1"),
                new XElement(KmsgName("BuyerLocation"), "SITE-1"),
                new XElement(KmsgName("Operative"), "Operative Name"),
                new XElement(KmsgName("SiteCode"), "SITE-CODE-1"),
                new XElement(KmsgName("PlotNumber"), "PLOT-1"),
                new XElement(KmsgName("VehicleRegistration"), "AB12 CDE"),
                new XElement(KmsgName("HouseType"), "HOUSE-TYPE-1"),
                new XElement(KmsgName("ProductGroup"), "PRODUCT-GROUP-1"),
                new XElement(KmsgName("OrderAuthorised"), "Authoriser Name"));
        }

        private static XElement BuildTaxSubTotal()
        {
            return new XElement(
                BasdaName("TaxSubTotal"),
                BuildCodedValue(BasdaName("TaxRate"), "S", "20"),
                new XElement(BasdaName("NumberOfLinesAtRate"), "1"),
                new XElement(BasdaName("TotalValueAtRate"), "19.98"),
                new XElement(BasdaName("TaxableValueAtRate"), "19.98"),
                new XElement(BasdaName("TaxAtRate"), "4.00"),
                new XElement(BasdaName("NetPaymentAtRate"), "19.98"),
                new XElement(BasdaName("GrossPaymentAtRate"), "23.98"));
        }

        private static XElement BuildInvoiceTotal()
        {
            return new XElement(
                BasdaName("InvoiceTotal"),
                new XElement(BasdaName("NumberOfLines"), "1"),
                new XElement(BasdaName("NumberOfTaxRates"), "1"),
                new XElement(BasdaName("LineValueTotal"), "19.98"),
                new XElement(BasdaName("TaxableTotal"), "19.98"),
                new XElement(BasdaName("TaxTotal"), "4.00"),
                new XElement(BasdaName("NetPaymentTotal"), "19.98"),
                new XElement(BasdaName("GrossPaymentTotal"), "23.98"));
        }

        private static XElement BuildCodedValue(XName name, string code, string description)
        {
            return new XElement(name, new XAttribute("Code", code), description);
        }

        private static XName BasdaName(string localName) => BasdaNamespace + localName;

        private static XName KmsgName(string localName) => KmsgNamespace + localName;
    }
}
