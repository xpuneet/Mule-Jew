using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests required TM1 Blob existence, size and freshness checks
    /// </summary>
    public class WorkdayConcurBlobClientTests
    {
        private static readonly Uri Endpoint = new("https://storage.blob.core.windows.net");
        private static readonly DateTimeOffset StartedOn = new(2026, 9, 4, 8, 30, 0, TimeSpan.Zero);

        private readonly Mock<IWorkdayConcurBlobServiceClientFactory> _factory = new();
        private readonly Mock<BlobServiceClient> _serviceClient = new();
        private readonly Mock<BlobContainerClient> _containerClient = new();
        private readonly Mock<BlobClient> _blobClient = new();

        /// <summary>
        /// Initialises the mocked Blob client chain
        /// </summary>
        public WorkdayConcurBlobClientTests()
        {
            _factory.Setup(x => x.Create(Endpoint)).Returns(_serviceClient.Object);
            _serviceClient.Setup(x => x.GetBlobContainerClient("input")).Returns(_containerClient.Object);
            _containerClient.Setup(x => x.GetBlobClient("TM1.csv")).Returns(_blobClient.Object);
        }

        /// <summary>
        /// Verifies that a fresh non-empty TM1 Blob returns immutable identity evidence
        /// </summary>
        [Fact]
        public async Task Given_FreshNonEmptyBlob_When_Reading_Should_ReturnIdentity()
        {
            SetupProperties(contentLength: 25, lastModified: StartedOn.AddSeconds(1));

            var result = await CreateService().GetRequiredFreshFileAsync(Endpoint, "input", "TM1.csv", StartedOn);

            Assert.Equal("input/TM1.csv", result.Path);
            Assert.Equal(25, result.ContentLength);
            Assert.Equal("\"etag\"", result.ETag);
            Assert.Equal(StartedOn.AddSeconds(1), result.LastModifiedOn);
        }

        /// <summary>
        /// Verifies that a missing TM1 Blob is rejected
        /// </summary>
        [Fact]
        public async Task Given_MissingBlob_When_Reading_Should_RejectFile()
        {
            _blobClient
                .Setup(x => x.GetPropertiesAsync(null, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            await Assert.ThrowsAsync<FileNotFoundException>(() => CreateService().GetRequiredFreshFileAsync(Endpoint, "input", "TM1.csv", StartedOn));
        }

        /// <summary>
        /// Verifies that an empty TM1 Blob is rejected
        /// </summary>
        [Fact]
        public async Task Given_EmptyBlob_When_Reading_Should_RejectFile()
        {
            SetupProperties(contentLength: 0, lastModified: StartedOn.AddSeconds(1));

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().GetRequiredFreshFileAsync(Endpoint, "input", "TM1.csv", StartedOn));
        }

        /// <summary>
        /// Verifies that a Blob left by an earlier pickup is rejected
        /// </summary>
        [Fact]
        public async Task Given_StaleBlob_When_Reading_Should_RejectFile()
        {
            SetupProperties(contentLength: 25, lastModified: StartedOn.AddSeconds(-1));

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().GetRequiredFreshFileAsync(Endpoint, "input", "TM1.csv", StartedOn));
        }

        /// <summary>
        /// Verifies that staging overwrites the exact requested Blob and returns the committed identity
        /// </summary>
        [Fact]
        public async Task Given_NonEmptyContent_When_Uploading_Should_OverwriteBlobAndReturnIdentity()
        {
            var content = new MemoryStream("employee-csv"u8.ToArray());

            var uploadResult = BlobsModelFactory.BlobContentInfo(
                eTag: new ETag("\"employee-etag\""),
                lastModified: StartedOn,
                contentHash: null,
                versionId: null,
                encryptionKeySha256: null,
                encryptionScope: null,
                blobSequenceNumber: 0);
            _serviceClient.Setup(x => x.GetBlobContainerClient("stukconcurtest")).Returns(_containerClient.Object);

            _containerClient.Setup(x => x.GetBlobClient("input/SG_CONCUR_DAILY.csv")).Returns(_blobClient.Object);

            _blobClient
                .Setup(x => x.UploadAsync(
                    content,
                    It.Is<BlobUploadOptions>(options => options.HttpHeaders.ContentType == "application/octet-stream"),
                    default))
                .ReturnsAsync(Response.FromValue(uploadResult, Mock.Of<Response>()));

            var result = await CreateService().UploadAsync(Endpoint, "stukconcurtest", "input/SG_CONCUR_DAILY.csv", content);

            Assert.Equal("stukconcurtest/input/SG_CONCUR_DAILY.csv", result.Path);
            Assert.Equal(content.Length, result.ContentLength);
            Assert.Equal("\"employee-etag\"", result.ETag);
            Assert.Equal(StartedOn, result.LastModifiedOn);
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that output selection retains every Blob while excluding Data Lake directory markers
        /// </summary>
        [Fact]
        public async Task Given_OutputFilesAndDirectory_When_Listing_Should_ReturnOnlyFiles()
        {
            var properties = CreateBlobItemProperties();
            var files = new[]
            {
                BlobsModelFactory.BlobItem("output/employee.txt", false, properties, null, new Dictionary<string, string>()),
                BlobsModelFactory.BlobItem("output/list.txt", false, properties, null, new Dictionary<string, string>()),
                BlobsModelFactory.BlobItem("output/nested/", false, properties, null, new Dictionary<string, string> { ["hdi_isfolder"] = "true" })
            };
            var page = Page<BlobItem>.FromValues(files, null, Mock.Of<Response>());
            var pageable = AsyncPageable<BlobItem>.FromPages(new[] { page });

            _serviceClient.Setup(x => x.GetBlobContainerClient("stukconcurtest")).Returns(_containerClient.Object);

            _containerClient
                .Setup(x => x.GetBlobsAsync(BlobTraits.Metadata, BlobStates.None, "output/", default))
                .Returns(pageable);

            var result = await CreateService().ListFilesAsync(Endpoint, "stukconcurtest", "/output/");

            Assert.Equal(2, result.Count);
            Assert.Collection(
                result,
                file => Assert.Equal("stukconcurtest/output/employee.txt", file.Path),
                file => Assert.Equal("stukconcurtest/output/list.txt", file.Path));
        }

        /// <summary>
        /// Verifies that current Blob identity can be read without applying a freshness rule
        /// </summary>
        [Fact]
        public async Task Given_ExistingBlob_When_GettingFile_Should_ReturnCurrentIdentity()
        {
            SetupProperties(contentLength: 25, lastModified: StartedOn);

            var result = await CreateService().GetFileAsync(Endpoint, "input", "TM1.csv");

            Assert.NotNull(result);
            Assert.Equal("input/TM1.csv", result.Path);
            Assert.Equal(25, result.ContentLength);
            Assert.Equal("\"etag\"", result.ETag);
            Assert.Equal(StartedOn, result.LastModifiedOn);
        }

        /// <summary>
        /// Verifies that a missing Blob is represented without masking other storage failures
        /// </summary>
        [Fact]
        public async Task Given_MissingBlob_When_GettingFile_Should_ReturnNull()
        {
            _blobClient
                .Setup(x => x.GetPropertiesAsync(null, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            var result = await CreateService().GetFileAsync(Endpoint, "input", "TM1.csv");

            Assert.Null(result);
        }

        /// <summary>
        /// Verifies that output content is streamed only when the selected entity tag still matches
        /// </summary>
        [Fact]
        public async Task Given_SelectedBlobIdentity_When_Opening_Should_RequireMatchingEntityTag()
        {
            var content = new MemoryStream("output-content"u8.ToArray());
            var download = BlobsModelFactory.BlobDownloadStreamingResult(content, null!);

            _serviceClient.Setup(x => x.GetBlobContainerClient("stukconcurtest")).Returns(_containerClient.Object);

            _containerClient.Setup(x => x.GetBlobClient("output/employee.txt")).Returns(_blobClient.Object);

            _blobClient
                .Setup(x => x.DownloadStreamingAsync(
                    It.Is<BlobDownloadOptions>(options => options.Conditions.IfMatch == new ETag("\"output-etag\"")),
                    default))
                .ReturnsAsync(Response.FromValue(download, Mock.Of<Response>()));

            await using var result = await CreateService().OpenReadAsync(Endpoint, "stukconcurtest", "output/employee.txt", "\"output-etag\"");

            Assert.Same(content, result);
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies upload rejects empty and non-seekable content before accessing Blob storage
        /// </summary>
        [Fact]
        public async Task Given_InvalidUploadContent_When_Uploading_Should_RejectBeforeStorage()
        {
            await using var empty = new MemoryStream();
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().UploadAsync(Endpoint, "input", "file.csv", empty));

            await using var nonSeekable = new NonSeekableReadStream("content"u8.ToArray());
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().UploadAsync(Endpoint, "input", "file.csv", nonSeekable));

            _factory.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies storage failures other than not-found are never converted into missing files
        /// </summary>
        [Fact]
        public async Task Given_StorageFailure_When_GettingFile_Should_PropagateFailure()
        {
            _blobClient
                .Setup(x => x.GetPropertiesAsync(null, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(403, "Forbidden"));

            var exception = await Assert.ThrowsAsync<RequestFailedException>(() => CreateService().GetFileAsync(Endpoint, "input", "TM1.csv"));

            Assert.Equal(403, exception.Status);
        }

        /// <summary>
        /// Verifies directory names are excluded even without Data Lake folder metadata
        /// </summary>
        [Fact]
        public async Task Given_TrailingSlashDirectory_When_Listing_Should_ExcludeDirectory()
        {
            var properties = CreateBlobItemProperties();
            var files = new[]
            {
                BlobsModelFactory.BlobItem("output/folder/", false, properties, null, new Dictionary<string, string>()),
                BlobsModelFactory.BlobItem("output/file.txt", false, properties, null, new Dictionary<string, string>())
            };
            var page = Page<BlobItem>.FromValues(files, null, Mock.Of<Response>());

            _serviceClient.Setup(x => x.GetBlobContainerClient("stukconcurtest")).Returns(_containerClient.Object);
            _containerClient.Setup(x => x.GetBlobsAsync(BlobTraits.Metadata, BlobStates.None, "output/", default)).Returns(AsyncPageable<BlobItem>.FromPages([page]));

            var result = await CreateService().ListFilesAsync(Endpoint, "stukconcurtest", "output");

            Assert.Equal("stukconcurtest/output/file.txt", Assert.Single(result).Path);
        }

        /// <summary>
        /// Verifies public Blob arguments are rejected before a client is created
        /// </summary>
        [Fact]
        public async Task Given_InvalidArguments_When_AccessingBlob_Should_RejectBeforeStorage()
        {
            await Assert.ThrowsAsync<ArgumentNullException>(() => CreateService().GetRequiredFreshFileAsync(null!, "input", "file", StartedOn));
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().GetRequiredFreshFileAsync(Endpoint, "", "file", StartedOn));
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().UploadAsync(Endpoint, "input", "", new MemoryStream([1])));
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().ListFilesAsync(Endpoint, "input", "/"));
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().OpenReadAsync(Endpoint, "input", "file", ""));

            _factory.VerifyNoOtherCalls();
        }

        private void SetupProperties(long contentLength, DateTimeOffset lastModified)
        {
            var properties = BlobsModelFactory.BlobProperties(
                lastModified: lastModified,
                contentLength: contentLength,
                eTag: new ETag("\"etag\""));

            _blobClient
                .Setup(x => x.GetPropertiesAsync(null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(properties, Mock.Of<Response>()));
        }

        private static BlobItemProperties CreateBlobItemProperties()
        {
            return BlobsModelFactory.BlobItemProperties(
                accessTierInferred: false,
                serverEncrypted: null,
                contentType: null,
                contentEncoding: null,
                contentLanguage: null,
                contentHash: null,
                contentDisposition: null,
                cacheControl: null,
                blobSequenceNumber: null,
                blobType: null,
                leaseStatus: null,
                leaseState: null,
                leaseDuration: null,
                copyId: null,
                copyStatus: null,
                copySource: null,
                copyProgress: null,
                copyStatusDescription: null,
                contentLength: 25,
                incrementalCopy: null,
                destinationSnapshot: null,
                remainingRetentionDays: null,
                accessTier: null,
                lastModified: StartedOn,
                archiveStatus: null,
                customerProvidedKeySha256: null,
                encryptionScope: null,
                tagCount: null,
                expiresOn: null,
                isSealed: null,
                rehydratePriority: null,
                lastAccessedOn: null,
                eTag: new ETag("\"output-etag\""),
                createdOn: null,
                copyCompletedOn: null,
                deletedOn: null,
                accessTierChangedOn: null);
        }

        private WorkdayConcurBlobClient CreateService()
        {
            return new WorkdayConcurBlobClient(_factory.Object);
        }

        private sealed class NonSeekableReadStream : MemoryStream
        {
            public NonSeekableReadStream(byte[] buffer) : base(buffer)
            {
            }

            public override bool CanSeek => false;
        }
    }
}
