using Moq;
using STUK.TradeAccountService.Common.Salesforce.Services;
using System.Net.Http.Headers;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the in-call Salesforce retry delay policy
    /// </summary>
    public class SalesforceRetryDelayTests
    {
        [Fact]
        public void Given_NoRetryAfter_When_Calculating_Should_UseBoundedExponentialDelay()
        {
            var policy = CreatePolicy();

            Assert.InRange(policy.Calculate(1, null), TimeSpan.FromSeconds(2), TimeSpan.FromMilliseconds(2500));
            Assert.InRange(policy.Calculate(3, null), TimeSpan.FromSeconds(8), TimeSpan.FromMilliseconds(8500));
            Assert.Equal(TimeSpan.FromSeconds(30), policy.Calculate(10, null));
        }

        [Fact]
        public void Given_RetryAfterDelta_When_Calculating_Should_HonourServerDelay()
        {
            var policy = CreatePolicy();

            var delay = policy.Calculate(1, new RetryConditionHeaderValue(TimeSpan.FromSeconds(45)));

            Assert.Equal(TimeSpan.FromSeconds(45), delay);
        }

        private static SalesforceRetryDelay CreatePolicy()
        {
            return new SalesforceRetryDelay(Mock.Of<TimeProvider>());
        }
    }
}
