using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class StatementXmlParserTests
    {
        private static readonly string Ns = "http://xml.kerridgecs.net/K809/k8Statement";
        private static readonly string NsExt = "http://xml.kerridgecs.net/K809/k8StatementExtensions";

        private static Stream BuildXmlStream(string body)
        {
            var xml = $"""
                <?xml version="1.0" encoding="utf-8"?>
                <root xmlns="{Ns}" xmlns:ext="{NsExt}">
                    <body>{body}</body>
                </root>
                """;
            return new MemoryStream(System.Text.Encoding.UTF8.GetBytes(xml));
        }

        private static string BuildStatementXml(
            string accountCode = "ACC001",
            string owningBranch = "BR01",
            string statementDate = "2026-05-01",
            string statementMonth = "May",
            string endOfNextMonth = "2026-06-30",
            string currencyCode = "GBP",
            string lineCount = "5",
            string totalVat = "20.00",
            string settDiscountTotal = "5.00",
            string statementTotal = "125.00",
            string statementDiscountTotal = "10.00",
            string queriedBalance = "50.00",
            string balanceAfterQueries = "75.00",
            string vatThisPeriod = "15.00")
        {
            return $"""
                <Statement xmlns="{Ns}" xmlns:ext="{NsExt}">
                    <StatementHead>
                        <Account code="{accountCode}">
                            <OwningBranch>{owningBranch}</OwningBranch>
                        </Account>
                        <StatementDate>{statementDate}</StatementDate>
                        <StatementMonth>{statementMonth}</StatementMonth>
                        <EndOfNextMonth>{endOfNextMonth}</EndOfNextMonth>
                        <StatementCurrency>
                            <Currency code="{currencyCode}" />
                        </StatementCurrency>
                    </StatementHead>
                    <StatementTrailer>
                        <LineCount>{lineCount}</LineCount>
                        <TotalVAT>{totalVat}</TotalVAT>
                        <SettDiscountTotal>{settDiscountTotal}</SettDiscountTotal>
                        <StatementTotal>{statementTotal}</StatementTotal>
                        <StatementDiscountTotal>{statementDiscountTotal}</StatementDiscountTotal>
                        <Extensions>
                            <ext:HXStatementTrailer>
                                <ext:QueriedBalance>{queriedBalance}</ext:QueriedBalance>
                                <ext:BalanceAfterQueries>{balanceAfterQueries}</ext:BalanceAfterQueries>
                                <ext:VATThisPeriod>{vatThisPeriod}</ext:VATThisPeriod>
                            </ext:HXStatementTrailer>
                        </Extensions>
                    </StatementTrailer>
                </Statement>
                """;
        }

        #region ParseAsync

        [Fact]
        public async Task ParseAsync_ValidXml_ReturnsCorrectAccountCode()
        {
            // Arrange
            using var stream = BuildXmlStream(BuildStatementXml());

            // Act
            var results = new List<Common.Contracts.Models.StatementHeaderData>();
            await foreach (var header in StatementXmlParser.ParseAsync(stream))
            {
                results.Add(header);
            }

            // Assert
            Assert.Single(results);
            Assert.Equal("ACC001", results[0].AccountCode);
        }

        [Fact]
        public async Task ParseAsync_ValidXml_ParsesAllFields()
        {
            // Arrange
            using var stream = BuildXmlStream(BuildStatementXml());

            // Act
            var results = new List<Common.Contracts.Models.StatementHeaderData>();
            await foreach (var header in StatementXmlParser.ParseAsync(stream))
            {
                results.Add(header);
            }

            // Assert
            var h = results[0];
            Assert.Equal("ACC001", h.AccountCode);
            Assert.Equal("BR01", h.OwningBranch);
            Assert.Equal(new DateTime(2026, 5, 1), h.StatementDate);
            Assert.Equal("May", h.StatementMonth);
            Assert.Equal(new DateTime(2026, 6, 30), h.EndOfNextMonth);
            Assert.Equal("GBP", h.CurrencyCode);
            Assert.Equal(5, h.LineCount);
            Assert.Equal(20.00m, h.TotalVAT);
            Assert.Equal(5.00m, h.SettDiscountTotal);
            Assert.Equal(125.00m, h.StatementTotal);
            Assert.Equal(10.00m, h.StatementDiscountTotal);
            Assert.Equal(50.00m, h.QueriedBalance);
            Assert.Equal(75.00m, h.BalanceAfterQueries);
            Assert.Equal(15.00m, h.VATThisPeriod);
        }

        [Fact]
        public async Task ParseAsync_MultipleStatements_ReturnsAll()
        {
            // Arrange - build XML with statements as direct children of body
            // avoiding redundant xmlns on each Statement element since the root provides the namespace
            var fullXml = $"""
                <?xml version="1.0" encoding="utf-8"?>
                <root xmlns="{Ns}" xmlns:ext="{NsExt}">
                    <body>
                        <Statement>
                            <StatementHead>
                                <Account code="ACC001"><OwningBranch>BR01</OwningBranch></Account>
                                <StatementDate>2026-05-01</StatementDate>
                                <StatementCurrency><Currency code="GBP" /></StatementCurrency>
                            </StatementHead>
                        </Statement>
                        <Statement>
                            <StatementHead>
                                <Account code="ACC002"><OwningBranch>BR02</OwningBranch></Account>
                                <StatementDate>2026-06-01</StatementDate>
                                <StatementCurrency><Currency code="EUR" /></StatementCurrency>
                            </StatementHead>
                        </Statement>
                    </body>
                </root>
                """;
            using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(fullXml));

            // Act
            var results = new List<Common.Contracts.Models.StatementHeaderData>();
            await foreach (var header in StatementXmlParser.ParseAsync(stream))
            {
                results.Add(header);
            }

            // Assert
            Assert.Equal(2, results.Count);
            Assert.Equal("ACC001", results[0].AccountCode);
            Assert.Equal("ACC002", results[1].AccountCode);
        }

        [Fact]
        public async Task ParseAsync_NoBodyElement_ThrowsInvalidOperationException()
        {
            // Arrange
            var xml = $"""
                <?xml version="1.0" encoding="utf-8"?>
                <root xmlns="{Ns}">
                    <notbody></notbody>
                </root>
                """;
            using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(xml));

            // Act & Assert
            var ex = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
            {
                await foreach (var _ in StatementXmlParser.ParseAsync(stream)) { }
            });
            Assert.Contains("<body>", ex.Message);
        }

        [Fact]
        public async Task ParseAsync_NoStatements_ReturnsEmpty()
        {
            // Arrange
            using var stream = BuildXmlStream("");

            // Act
            var results = new List<Common.Contracts.Models.StatementHeaderData>();
            await foreach (var header in StatementXmlParser.ParseAsync(stream))
            {
                results.Add(header);
            }

            // Assert
            Assert.Empty(results);
        }

        [Fact]
        public async Task ParseAsync_MissingAccountCode_ThrowsInvalidOperationException()
        {
            // Arrange
            var xml = $"""
                <Statement xmlns="{Ns}">
                    <StatementHead>
                        <StatementDate>2026-05-01</StatementDate>
                        <StatementCurrency>
                            <Currency code="GBP" />
                        </StatementCurrency>
                    </StatementHead>
                </Statement>
                """;
            using var stream = BuildXmlStream(xml);

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(async () =>
            {
                await foreach (var _ in StatementXmlParser.ParseAsync(stream)) { }
            });
        }

        [Fact]
        public async Task ParseAsync_MissingOptionalTrailer_ReturnsNullTrailerFields()
        {
            // Arrange
            var xml = $"""
                <Statement xmlns="{Ns}">
                    <StatementHead>
                        <Account code="ACC001">
                            <OwningBranch>BR01</OwningBranch>
                        </Account>
                        <StatementDate>2026-05-01</StatementDate>
                        <StatementCurrency>
                            <Currency code="GBP" />
                        </StatementCurrency>
                    </StatementHead>
                </Statement>
                """;
            using var stream = BuildXmlStream(xml);

            // Act
            var results = new List<Common.Contracts.Models.StatementHeaderData>();
            await foreach (var header in StatementXmlParser.ParseAsync(stream))
            {
                results.Add(header);
            }

            // Assert
            Assert.Single(results);
            Assert.Null(results[0].LineCount);
            Assert.Null(results[0].TotalVAT);
            Assert.Null(results[0].StatementTotal);
        }

        [Fact]
        public async Task ParseAsync_CancellationRequested_ThrowsOperationCancelled()
        {
            // Arrange
            var xml = BuildStatementXml() + BuildStatementXml(accountCode: "ACC002");
            using var stream = BuildXmlStream(xml);
            var cts = new CancellationTokenSource();
            cts.Cancel();

            // Act & Assert
            await Assert.ThrowsAsync<OperationCanceledException>(async () =>
            {
                await foreach (var _ in StatementXmlParser.ParseAsync(stream, cts.Token)) { }
            });
        }

        #endregion

        #region BuildMetadata

        [Fact]
        public void BuildMetadata_ReturnsMappedMetadata()
        {
            // Arrange
            var batch = new List<Common.Contracts.Models.StatementHeaderData>
            {
                new() { AccountCode = "ACC001", StatementDate = new DateTime(2026, 5, 1), CurrencyCode = "GBP" },
                new() { AccountCode = "ACC002", StatementDate = new DateTime(2026, 6, 1), CurrencyCode = "EUR" }
            };

            // Act
            var result = StatementXmlParser.BuildMetadata(
                batch,
                originalFileName: "test.xml",
                extension: ".xml",
                contentMd5: "abc123",
                contentLength: 1024,
                blobUri: "2026/05/test.xml",
                createdBy: "System");

            // Assert
            Assert.Equal(2, result.Count);
            Assert.Equal("ACC001", result[0].AccountCode);
            Assert.Equal(new DateTime(2026, 5, 1), result[0].StatementDate);
            Assert.Equal("test.xml", result[0].OriginalFileName);
            Assert.Equal(".xml", result[0].Extension);
            Assert.Equal("abc123", result[0].ContentMd5);
            Assert.Equal(1024, result[0].ContentLength);
            Assert.Equal("2026/05/test.xml", result[0].BlobUri);
            Assert.Equal("System", result[0].CreatedBy);
        }

        [Fact]
        public void BuildMetadata_EmptyBatch_ReturnsEmptyList()
        {
            // Arrange
            var batch = new List<Common.Contracts.Models.StatementHeaderData>();

            // Act
            var result = StatementXmlParser.BuildMetadata(batch);

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public void BuildMetadata_NullOptionalParams_ReturnsNullFields()
        {
            // Arrange
            var batch = new List<Common.Contracts.Models.StatementHeaderData>
            {
                new() { AccountCode = "ACC001", StatementDate = new DateTime(2026, 5, 1), CurrencyCode = "GBP" }
            };

            // Act
            var result = StatementXmlParser.BuildMetadata(batch);

            // Assert
            Assert.Single(result);
            Assert.Null(result[0].OriginalFileName);
            Assert.Null(result[0].Extension);
            Assert.Null(result[0].ContentMd5);
            Assert.Null(result[0].ContentLength);
            Assert.Null(result[0].BlobUri);
            Assert.Null(result[0].CreatedBy);
        }

        #endregion
    }
}
