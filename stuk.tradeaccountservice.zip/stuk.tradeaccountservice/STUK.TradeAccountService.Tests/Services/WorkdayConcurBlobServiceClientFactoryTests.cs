using Azure.Core;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests workload-identity Blob client creation
    /// </summary>
    public class WorkdayConcurBlobServiceClientFactoryTests
    {
        /// <summary>
        /// Verifies the requested service endpoint is retained by the created client
        /// </summary>
        [Fact]
        public void Given_ServiceEndpoint_When_Creating_Should_CreateClientForEndpoint()
        {
            var endpoint = new Uri("https://storage.blob.core.windows.net");
            var factory = new WorkdayConcurBlobServiceClientFactory(new StubTokenCredential());

            var client = factory.Create(endpoint);

            Assert.Equal(endpoint, client.Uri);
        }

        /// <summary>
        /// Verifies constructor and method dependencies are mandatory
        /// </summary>
        [Fact]
        public void Given_MissingDependencies_When_Creating_Should_RejectValues()
        {
            Assert.Throws<ArgumentNullException>(() => new WorkdayConcurBlobServiceClientFactory(null!));
            Assert.Throws<ArgumentNullException>(() => new WorkdayConcurBlobServiceClientFactory(new StubTokenCredential()).Create(null!));
        }

        private sealed class StubTokenCredential : TokenCredential
        {
            public override AccessToken GetToken(TokenRequestContext requestContext, CancellationToken cancellationToken)
            {
                return new AccessToken("token", DateTimeOffset.MaxValue);
            }

            public override ValueTask<AccessToken> GetTokenAsync(TokenRequestContext requestContext, CancellationToken cancellationToken)
            {
                return ValueTask.FromResult(GetToken(requestContext, cancellationToken));
            }
        }
    }
}
