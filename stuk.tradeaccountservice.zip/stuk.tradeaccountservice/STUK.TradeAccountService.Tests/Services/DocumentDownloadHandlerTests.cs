﻿using Azure.Storage.Blobs;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Handlers;

namespace STUK.TradeAccountService.Tests.Services
{
    public class DocumentDownloadHandlerTests
    {
        private readonly Mock<IDocumentMetadataResolver<string, string?>> _resolverMock;
        private readonly Mock<BlobServiceClient> _blobServiceClientMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly DocumentDownloadHandler<string, string?> _handler;

        public DocumentDownloadHandlerTests()
        {
            _resolverMock = new Mock<IDocumentMetadataResolver<string, string?>>();
            _blobServiceClientMock = new Mock<BlobServiceClient>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();

            _resolverMock.Setup(r => r.DocumentType).Returns("Invoice");
            _resolverMock.Setup(r => r.ContainerName).Returns("invoicetest");
            _resolverMock.Setup(r => r.DefaultFileName).Returns("Invoice.pdf");
            _resolverMock.Setup(r => r.ParseIdentifier(It.IsAny<string>())).Returns((string s) => s);

            _handler = new DocumentDownloadHandler<string, string?>(
                _resolverMock.Object,
                new HttpClient(),
                _blobServiceClientMock.Object,
                _loggerMock.Object);
        }

        #region RequestDownload

        [Fact]
        public async Task RequestDownload_ExistingCache_ReturnsExistingTokenWithPendingMessage()
        {
            // Arrange
            var existingToken = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = existingToken,
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Pending"
                });

            // Act
            var result = await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            Assert.Equal(existingToken, result.Token);
            Assert.Contains("already active", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_MetadataNotFound_ThrowsKeyNotFoundException()
        {
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentMetadata?)null);

            // Act & Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() =>
                _handler.RequestDownloadAsync("INV-001", "123"));
        }

        [Fact]
        public async Task RequestDownload_BlobUriEmpty_ReturnsPendingStatusMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Pending", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            var result = await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            Assert.Equal(token, result.Token);
            Assert.Contains("being prepared", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_BlobUriExists_ReturnsReadyStatusMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/03/file.pdf", FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            var result = await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            Assert.Equal(token, result.Token);
            Assert.Contains("ready for download", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_TokenGenerationFails_ThrowsInvalidOperationException()
        {
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/03/file.pdf", FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((Guid.Empty, DateTimeOffset.Now));

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                _handler.RequestDownloadAsync("INV-001", "123"));
        }

        [Fact]
        public async Task RequestDownload_BlobUriExists_CallsInsertCacheWithReadyStatus()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/03/file.pdf", FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            _resolverMock.Verify(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task RequestDownload_BlobUriEmpty_CallsInsertCacheWithPendingStatus()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Pending", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            _resolverMock.Verify(r => r.InsertCacheAsync("INV-001", "123", "Pending", It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task RequestDownload_ExpiredCache_ReRequestsDocument()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Pending",
                    IsExpired = true
                });

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/03/file.pdf", FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            var result = await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            Assert.Equal(token, result.Token);
            _resolverMock.Verify(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task RequestDownload_BlobUriEmpty_CallsRequestDocument()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Pending", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            _resolverMock.Verify(r => r.RequestDocumentAsync("INV-001", "123", It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task RequestDownload_BlobUriExists_DoesNotCallRequestDocument()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/03/file.pdf", FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            await _handler.RequestDownloadAsync("INV-001", "123");

            // Assert
            _resolverMock.Verify(r => r.RequestDocumentAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        #endregion

        #region Download

        [Fact]
        public async Task Download_InvalidToken_ThrowsKeyNotFoundException()
        {
            var invalidToken = Guid.Empty;
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(invalidToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act & Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() =>
                _handler.DownloadAsync(invalidToken));
        }

        [Fact]
        public async Task Download_MetadataNotFound_ReturnsNotReadyMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Ready"
                });

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentMetadata?)null);

            // Act
            var result = await _handler.DownloadAsync(token);

            // Assert
            Assert.Null(result.FileContent);
            Assert.Contains("not ready", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task Download_BlobUriEmpty_ReturnsNotReadyMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Pending"
                });

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "file.pdf" });

            // Act
            var result = await _handler.DownloadAsync(token);

            // Assert
            Assert.Null(result.FileContent);
            Assert.Contains("not ready", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task Download_InvalidToken_DoesNotCallGetMetadata()
        {
            var invalidToken = Guid.Empty;
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(invalidToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            await Assert.ThrowsAsync<KeyNotFoundException>(() =>
                _handler.DownloadAsync(invalidToken));

            // Assert
            _resolverMock.Verify(r => r.GetMetadataAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Download_ExpiredToken_ReturnsExpiredMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Ready",
                    IsExpired = true
                });

            // Act
            var result = await _handler.DownloadAsync(token);

            // Assert
            Assert.Null(result.FileContent);
            Assert.Contains("expired", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task Download_ExpiredToken_DoesNotCallGetMetadata()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Ready",
                    IsExpired = true
                });

            // Act
            await _handler.DownloadAsync(token);

            // Assert
            _resolverMock.Verify(r => r.GetMetadataAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        #endregion
    }
}