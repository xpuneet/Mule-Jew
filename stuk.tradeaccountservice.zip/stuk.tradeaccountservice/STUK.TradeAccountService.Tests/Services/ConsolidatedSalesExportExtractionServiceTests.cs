using Moq;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Exceptions;
using STUK.TradeAccountService.Common.Salesforce.Models;
using STUK.TradeAccountService.Common.Salesforce.Services;
using System.Net;
using System.Text.Json;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedSalesExportExtractionServiceTests
    {
        private static readonly Guid ExportRunId = new("30000000-0000-0000-0000-000000000001");
        private static readonly Guid CorrelationId = new("30000000-0000-0000-0000-000000000002");
        private static readonly Guid ClaimToken = new("30000000-0000-0000-0000-000000000003");

        private readonly Mock<ISalesforceApiClient> _salesforceApiClient = new();
        private readonly Mock<IConsolidatedSalesExportDataService> _exportDataService = new();

        [Fact]
        public async Task Given_Paged_Salesforce_Data_When_Extracting_Should_Persist_And_Complete_One_Snapshot()
        {
            var firstPage = new SalesforceQueryResult<SalesforceConsXrefOrderItem>
            {
                TotalSize = 3,
                Done = false,
                NextRecordsUrl = "/services/data/v65.0/query/next-page",
                Records = [CreateRow("ACC001", "INV001"), CreateRow("ACC002", "INV002")]
            };
            var secondPage = new SalesforceQueryResult<SalesforceConsXrefOrderItem>
            {
                TotalSize = 3,
                Done = true,
                Records = [CreateRow("ACC003", "INV003")]
            };
            string? capturedSoql = null;
            var persistedPages = new List<(int PageNumber, long FirstSequence, bool HasMore, string RowsJson)>();
            _salesforceApiClient
                .Setup(client => client.QueryPagesAsync<SalesforceConsXrefOrderItem>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Callback<string, CancellationToken>((soql, _) => capturedSoql = soql)
                .Returns(ToAsyncEnumerable(firstPage, secondPage));
            _exportDataService
                .Setup(service => service.AppendPageAsync(
                    ExportRunId,
                    ClaimToken,
                    It.IsAny<int>(),
                    It.IsAny<long>(),
                    It.Is<byte[]>(hash => hash.Length == 32),
                    It.IsAny<bool>(),
                    It.IsAny<string>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .Callback<Guid, Guid, int, long, byte[], bool, string, DateTimeOffset?, CancellationToken>(
                    (_, _, pageNumber, firstSequence, _, hasMore, rowsJson, _, _) =>
                        persistedPages.Add((pageNumber, firstSequence, hasMore, rowsJson)))
                .ReturnsAsync(new ConsolidatedSalesExportPage());
            _exportDataService
                .Setup(service => service.CompleteExtractionAsync(
                    ExportRunId,
                    ClaimToken,
                    2,
                    3,
                    It.Is<byte[]>(hash => hash.Length == 32),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            var timeProvider = CreateTimeProvider();

            var result = await CreateService(timeProvider.Object).ExtractAsync(CreateClaimedRun());

            Assert.Equal(
                "SELECT Order.Account.Account_Number__c, Order.Invoice_Number__c, Order.Invoice_Date__c, Delivery_Note_Number__c, Delivery_Note_Line_Number__c, Despatch_Date__c, Product2.productCode, Quantity, Order_Product_Total__c FROM OrderItem WHERE Order.Invoice_Date__c >= 2026-01-01",
                capturedSoql);
            Assert.Equal(2, persistedPages.Count);
            Assert.Equal((1, 1L, true), (persistedPages[0].PageNumber, persistedPages[0].FirstSequence, persistedPages[0].HasMore));
            Assert.Equal((2, 3L, false), (persistedPages[1].PageNumber, persistedPages[1].FirstSequence, persistedPages[1].HasMore));
            using var firstRows = JsonDocument.Parse(persistedPages[0].RowsJson);
            Assert.Equal("ACC001", firstRows.RootElement[0].GetProperty("AccountNumber").GetString());
            Assert.Equal("INV001", firstRows.RootElement[0].GetProperty("InvoiceNumber").GetString());
            Assert.Equal("2026-08-01", firstRows.RootElement[0].GetProperty("InvoiceDate").GetString());
            Assert.Equal("DEL001", firstRows.RootElement[0].GetProperty("DeliveryNoteNumber").GetString());
            Assert.Equal("1", firstRows.RootElement[0].GetProperty("DeliveryNoteLineNumber").GetString());
            Assert.Equal("2026-07-31", firstRows.RootElement[0].GetProperty("DespatchDate").GetString());
            Assert.Equal("PRODUCT001", firstRows.RootElement[0].GetProperty("ProductCode").GetString());
            Assert.Equal(1m, firstRows.RootElement[0].GetProperty("Quantity").GetDecimal());
            Assert.Equal(9.99m, firstRows.RootElement[0].GetProperty("TotalPrice").GetDecimal());
            Assert.Equal("INV002", firstRows.RootElement[1].GetProperty("InvoiceNumber").GetString());
            Assert.Equal(ExportRunId, result.ExportRunId);
            Assert.Equal(CorrelationId, result.CorrelationId);
            Assert.Equal(2, result.PageCount);
            Assert.Equal(3, result.RowCount);
            Assert.Equal(TimeSpan.FromSeconds(3), result.Duration);
            _salesforceApiClient.VerifyAll();
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_An_Empty_Result_When_Extracting_Should_Persist_The_Final_Empty_Page()
        {
            var page = new SalesforceQueryResult<SalesforceConsXrefOrderItem>
            {
                TotalSize = 0,
                Done = true,
                Records = []
            };
            _salesforceApiClient
                .Setup(client => client.QueryPagesAsync<SalesforceConsXrefOrderItem>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Returns(ToAsyncEnumerable(page));
            _exportDataService
                .Setup(service => service.AppendPageAsync(
                    ExportRunId,
                    ClaimToken,
                    1,
                    1,
                    It.IsAny<byte[]>(),
                    false,
                    "[]",
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportPage());
            _exportDataService
                .Setup(service => service.CompleteExtractionAsync(
                    ExportRunId,
                    ClaimToken,
                    1,
                    0,
                    It.IsAny<byte[]>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var result = await CreateService(CreateTimeProvider().Object).ExtractAsync(CreateClaimedRun());

            Assert.Equal(0, result.RowCount);
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_A_Total_Size_Mismatch_When_Extracting_Should_Not_Publish_The_Snapshot()
        {
            var page = new SalesforceQueryResult<SalesforceConsXrefOrderItem>
            {
                TotalSize = 2,
                Done = true,
                Records = [CreateRow("ACC001", "INV001")]
            };
            _salesforceApiClient
                .Setup(client => client.QueryPagesAsync<SalesforceConsXrefOrderItem>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Returns(ToAsyncEnumerable(page));
            _exportDataService
                .Setup(service => service.AppendPageAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<Guid>(),
                    It.IsAny<int>(),
                    It.IsAny<long>(),
                    It.IsAny<byte[]>(),
                    It.IsAny<bool>(),
                    It.IsAny<string>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportPage());
            _exportDataService
                .Setup(service => service.FailExtractionAsync(
                    ExportRunId,
                    ClaimToken,
                    "SalesforceInvalidResponse",
                    It.Is<string>(message => message.Contains("reported 2 records but returned 1")),
                    true,
                    It.IsAny<DateTimeOffset?>(),
                    5,
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportFailureResult());

            var exception = await Assert.ThrowsAsync<SalesforceQueryResponseException>(() =>
                CreateService(CreateTimeProvider().Object).ExtractAsync(CreateClaimedRun()));

            Assert.Contains("reported 2 records but returned 1", exception.Message);
            _exportDataService.Verify(
                service => service.CompleteExtractionAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<Guid>(),
                    It.IsAny<int>(),
                    It.IsAny<long>(),
                    It.IsAny<byte[]>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
        }

        [Fact]
        public async Task Given_An_Unclaimed_Run_When_Extracting_Should_Reject_Before_Calling_Salesforce()
        {
            var run = CreateClaimedRun();
            run.Status = "Pending";

            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                CreateService(CreateTimeProvider().Object).ExtractAsync(run));

            _salesforceApiClient.VerifyNoOtherCalls();
            _exportDataService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_Exhausted_Transient_Salesforce_Failure_When_Extracting_Should_Schedule_Durable_Retry()
        {
            var failure = new SalesforceApiException("Salesforce unavailable", HttpStatusCode.ServiceUnavailable);
            _salesforceApiClient
                .Setup(client => client.QueryPagesAsync<SalesforceConsXrefOrderItem>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Returns(ThrowAsync<SalesforceConsXrefOrderItem>(failure));
            _exportDataService
                .Setup(service => service.FailExtractionAsync(
                    ExportRunId,
                    ClaimToken,
                    "SalesforceUnavailable",
                    "Salesforce unavailable",
                    true,
                    It.IsAny<DateTimeOffset?>(),
                    5,
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportFailureResult());

            var exception = await Assert.ThrowsAsync<SalesforceApiException>(() =>
                CreateService(CreateTimeProvider().Object).ExtractAsync(CreateClaimedRun()));

            Assert.Same(failure, exception);
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_Permanent_Salesforce_Query_Failure_When_Extracting_Should_Record_Terminal_Failure()
        {
            var failure = new SalesforceApiException("Invalid field", HttpStatusCode.BadRequest);
            _salesforceApiClient
                .Setup(client => client.QueryPagesAsync<SalesforceConsXrefOrderItem>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Returns(ThrowAsync<SalesforceConsXrefOrderItem>(failure));
            _exportDataService
                .Setup(service => service.FailExtractionAsync(
                    ExportRunId,
                    ClaimToken,
                    "SalesforceRequestRejected",
                    "Invalid field",
                    false,
                    null,
                    5,
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportFailureResult());

            var exception = await Assert.ThrowsAsync<SalesforceApiException>(() =>
                CreateService(CreateTimeProvider().Object).ExtractAsync(CreateClaimedRun()));

            Assert.Same(failure, exception);
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_Salesforce_Fails_After_One_Page_When_Extracting_Should_Keep_The_Snapshot_Incomplete_And_Schedule_A_Retry()
        {
            var firstPage = new SalesforceQueryResult<SalesforceConsXrefOrderItem>
            {
                TotalSize = 2,
                Done = false,
                NextRecordsUrl = "/services/data/v65.0/query/next-page",
                Records = [CreateRow("ACC001", "INV001")]
            };
            var failure = new HttpRequestException("Connection reset");
            _salesforceApiClient
                .Setup(client => client.QueryPagesAsync<SalesforceConsXrefOrderItem>(It.IsAny<string>(), It.IsAny<CancellationToken>()))
                .Returns(YieldThenThrowAsync(firstPage, failure));

            _exportDataService
                .Setup(service => service.AppendPageAsync(
                    ExportRunId,
                    ClaimToken,
                    1,
                    1,
                    It.Is<byte[]>(hash => hash.Length == 32),
                    true,
                    It.IsAny<string>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportPage());

            _exportDataService
                .Setup(service => service.FailExtractionAsync(
                    ExportRunId,
                    ClaimToken,
                    "SalesforceNetwork",
                    "Connection reset",
                    true,
                    It.IsAny<DateTimeOffset?>(),
                    5,
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportFailureResult());

            var exception = await Assert.ThrowsAsync<HttpRequestException>(() => CreateService(CreateTimeProvider().Object).ExtractAsync(CreateClaimedRun()));

            Assert.Same(failure, exception);
            _exportDataService.Verify(service => service.CompleteExtractionAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<int>(),
                It.IsAny<long>(),
                It.IsAny<byte[]>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_The_Caller_Cancels_When_Extracting_Should_Not_Record_An_Operational_Failure()
        {
            using var cancellationSource = new CancellationTokenSource();
            cancellationSource.Cancel();

            var exception = await Assert.ThrowsAsync<OperationCanceledException>(() =>
                CreateService(CreateTimeProvider().Object).ExtractAsync(CreateClaimedRun(), cancellationSource.Token));

            Assert.Equal(cancellationSource.Token, exception.CancellationToken);
            _exportDataService.Verify(service => service.FailExtractionAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<bool>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _salesforceApiClient.VerifyNoOtherCalls();
        }

        private ConsolidatedSalesExportExtractionService CreateService(TimeProvider timeProvider)
        {
            return new ConsolidatedSalesExportExtractionService(
                Mock.Of<ILogger<ConsolidatedSalesExportExtractionService>>(),
                _salesforceApiClient.Object,
                new SalesforceConsXrefRowMapper(),
                _exportDataService.Object,
                new SalesforceExportRetryPolicy(timeProvider),
                timeProvider);
        }

        private static ConsolidatedSalesExportRun CreateClaimedRun()
        {
            return new ConsolidatedSalesExportRun
            {
                Id = ExportRunId,
                CorrelationId = CorrelationId,
                ExportYear = 2026,
                ExtractFromDate = new DateOnly(2026, 1, 1),
                Status = "Extracting",
                ExtractionAttemptCount = 1,
                ClaimToken = ClaimToken
            };
        }

        private static SalesforceConsXrefOrderItem CreateRow(string accountNumber, string invoiceNumber)
        {
            return new SalesforceConsXrefOrderItem
            {
                Order = new SalesforceConsXrefOrder
                {
                    Account = new SalesforceConsXrefAccount { AccountNumber = accountNumber },
                    InvoiceNumber = invoiceNumber,
                    InvoiceDate = new DateOnly(2026, 8, 1)
                },
                DeliveryNoteNumber = "DEL001",
                DeliveryNoteLineNumber = 1,
                DespatchDate = new DateOnly(2026, 7, 31),
                Product = new SalesforceConsXrefProduct { ProductCode = "PRODUCT001" },
                Quantity = 1,
                TotalPrice = 9.99m
            };
        }

        private static Mock<TimeProvider> CreateTimeProvider()
        {
            var start = new DateTimeOffset(2026, 8, 13, 9, 0, 0, TimeSpan.Zero);
            var timeProvider = new Mock<TimeProvider>();
            timeProvider.SetupSequence(provider => provider.GetUtcNow())
                .Returns(start)
                .Returns(start.AddSeconds(1))
                .Returns(start.AddSeconds(2))
                .Returns(start.AddSeconds(3));
            return timeProvider;
        }

        private static async IAsyncEnumerable<T> ToAsyncEnumerable<T>(params T[] values)
        {
            foreach (var value in values)
            {
                yield return value;
                await Task.Yield();
            }
        }

        private static async IAsyncEnumerable<SalesforceQueryResult<T>> ThrowAsync<T>(Exception exception)
        {
            await Task.Yield();
            throw exception;
#pragma warning disable CS0162
            yield break;
#pragma warning restore CS0162
        }

        private static async IAsyncEnumerable<SalesforceQueryResult<T>> YieldThenThrowAsync<T>(SalesforceQueryResult<T> page, Exception exception)
        {
            yield return page;
            await Task.Yield();
            throw exception;
        }
    }
}
