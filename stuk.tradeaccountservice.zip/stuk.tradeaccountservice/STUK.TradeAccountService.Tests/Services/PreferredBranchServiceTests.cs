using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services;

public class PreferredBranchServiceTests
{
    private readonly Mock<IDbExecutor> _dbExecutorMock;
    private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
    private readonly PreferredBranchService _service;

    public PreferredBranchServiceTests()
    {
        _dbExecutorMock = new Mock<IDbExecutor>();
        _loggerMock = new Mock<IAppInsightsLoggerHelper>();
        _service = new PreferredBranchService(_dbExecutorMock.Object, _loggerMock.Object);
    }

    #region Constructor

    [Fact]
    public void Constructor_NullDbExecutor_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() =>
            new PreferredBranchService(null!, _loggerMock.Object));
    }

    [Fact]
    public void Constructor_NullLogger_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() =>
            new PreferredBranchService(_dbExecutorMock.Object, null!));
    }

    #endregion

    #region GetPreferredBranchAsync

    [Fact]
    public async Task GetPreferredBranchAsync_CallsCorrectStoredProcedure()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync((PreferredBranchData?)null);

        // Act
        await _service.GetPreferredBranchAsync("ACC001");

        // Assert
        _dbExecutorMock.Verify(db =>
            db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()),
            Times.Once);
    }

    [Fact]
    public async Task GetPreferredBranchAsync_ValidAccount_ReturnsPreferredBranch()
    {
        // Arrange
        var expected = new PreferredBranchData("BR01", "");

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.Is<object>(o => o.GetType().GetProperty("accountCode")!.GetValue(o)!.ToString() == "ACC001")))
            .ReturnsAsync(expected);

        // Act
        var result = await _service.GetPreferredBranchAsync("ACC001");

        // Assert
        Assert.NotNull(result);
        Assert.Equal("BR01", result!.PreferredBranch);
    }

    [Fact]
    public async Task GetPreferredBranchAsync_AccountNotFound_ReturnsNull()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync((PreferredBranchData?)null);

        // Act
        var result = await _service.GetPreferredBranchAsync("NONEXISTENT");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task GetPreferredBranchAsync_DbThrows_Propagates()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ThrowsAsync(new Exception("Connection failed"));

        // Act & Assert
        var ex = await Assert.ThrowsAsync<Exception>(
            () => _service.GetPreferredBranchAsync("ACC001"));
        Assert.Equal("Connection failed", ex.Message);
    }

    [Fact]
    public async Task GetPreferredBranchAsync_LogsStartAndCompletion()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync(new PreferredBranchData("BR01", ""));

        // Act
        await _service.GetPreferredBranchAsync("ACC001");

        // Assert
        _loggerMock.Verify(l =>
            l.LogInformation(
                It.Is<string>(s => s.Contains("GetPreferredBranchAsync started")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);

        _loggerMock.Verify(l =>
            l.LogInformation(
                It.Is<string>(s => s.Contains("GetPreferredBranchAsync completed")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
    }

    #endregion

    #region SetPreferredBranchAsync

    [Fact]
    public async Task SetPreferredBranchAsync_CallsCorrectStoredProcedure()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync((PreferredBranchData?)null);

        // Act
        await _service.SetPreferredBranchAsync("ACC001", "BR02");

        // Assert
        _dbExecutorMock.Verify(db =>
            db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()),
            Times.Once);
    }

    [Fact]
    public async Task SetPreferredBranchAsync_ValidRequest_ReturnsUpdatedBranch()
    {
        // Arrange
        var expected = new PreferredBranchData("BR02", "");

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync(expected);

        // Act
        var result = await _service.SetPreferredBranchAsync("ACC001", "BR02");

        // Assert
        Assert.NotNull(result);
        Assert.Equal("BR02", result!.PreferredBranch);
    }

    [Fact]
    public async Task SetPreferredBranchAsync_AccountNotFound_ReturnsNull()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync((PreferredBranchData?)null);

        // Act
        var result = await _service.SetPreferredBranchAsync("NONEXISTENT", "BR02");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task SetPreferredBranchAsync_DbThrows_Propagates()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ThrowsAsync(new Exception("DB error"));

        // Act & Assert
        var ex = await Assert.ThrowsAsync<Exception>(
            () => _service.SetPreferredBranchAsync("ACC001", "BR02"));
        Assert.Equal("DB error", ex.Message);
    }

    [Fact]
    public async Task SetPreferredBranchAsync_LogsStartAndCompletion()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync(new PreferredBranchData("BR02", ""));

        // Act
        await _service.SetPreferredBranchAsync("ACC001", "BR02");

        // Assert
        _loggerMock.Verify(l =>
            l.LogInformation(
                It.Is<string>(s => s.Contains("SetPreferredBranchAsync started")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);

        _loggerMock.Verify(l =>
            l.LogInformation(
                It.Is<string>(s => s.Contains("SetPreferredBranchAsync completed")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task SetPreferredBranchAsync_WithErrorCode_ReturnsErrorData()
    {
        // Arrange
        var expected = new PreferredBranchData("", "INVALID_BRANCH");

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<PreferredBranchData>(
                StoredProcedures.GetAndSetPreferredBranch,
                It.IsAny<object>()))
            .ReturnsAsync(expected);

        // Act
        var result = await _service.SetPreferredBranchAsync("ACC001", "INVALID");

        // Assert
        Assert.NotNull(result);
        Assert.Equal("INVALID_BRANCH", result!.ErrorCode);
    }

    #endregion
}
