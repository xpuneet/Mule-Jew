using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class InvoiceReconciliationDataServiceTests
    {
        private const string BranchCode = "0580";
        private const string ConsolidatedInvoiceNumber = "CON-1";
        private const string StandardInvoiceNumber = "INV-1";
        private static readonly Guid WorkId = new("20000000-0000-0000-0000-000000000001");
        private static readonly Guid ClaimToken = new("20000000-0000-0000-0000-000000000002");
        private static readonly Guid MatchedInvoiceHeaderId = new("20000000-0000-0000-0000-000000000003");
        private static readonly DateOnly ConsolidatedInvoiceDate = new(2026, 8, 5);
        private static readonly DateTimeOffset NextAttemptOn = new(2026, 8, 5, 10, 30, 0, TimeSpan.Zero);

        private readonly Mock<IDbExecutor> _accountDbExecutor = new();
        private readonly Mock<IDbExecutor> _orderDbExecutor = new();

        [Fact]
        public async Task Given_Reconciliation_Work_When_Processing_The_Lifecycle_Should_Use_The_Owning_Database_For_Each_Procedure()
        {
            _accountDbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesReconciliationWork>(StoredProcedures.ClaimNextConsolidatedSalesReconciliationWork, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesReconciliationWork());
            _orderDbExecutor.Setup(x => x.ExecuteSingleAsync<InvoiceReconciliationMatchResult>(StoredProcedures.ReconcileInvoiceHeaderConsolidatedSales, It.IsAny<object>())).ReturnsAsync(new InvoiceReconciliationMatchResult());
            _accountDbExecutor.Setup(x => x.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesReconciliationWork, It.IsAny<object>())).ReturnsAsync(1);
            _accountDbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesWorkFailureResult>(StoredProcedures.DeferConsolidatedSalesReconciliationWork, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesWorkFailureResult());
            _accountDbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesWorkFailureResult>(StoredProcedures.FailConsolidatedSalesReconciliationWork, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesWorkFailureResult());
            _accountDbExecutor.Setup(x => x.ExecuteAsync(StoredProcedures.RequeueConsolidatedSalesWork, It.IsAny<object>())).ReturnsAsync(1);
            var service = CreateService();

            await service.ClaimNextAsync("worker", 60, 3);
            await service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate);
            await service.CompleteAsync(WorkId, ClaimToken, MatchedInvoiceHeaderId);
            await service.DeferAsync(WorkId, ClaimToken, NextAttemptOn, "Invoice has not arrived");
            await service.FailAsync(WorkId, ClaimToken, "Transient", "Failure", NextAttemptOn, 3);
            await service.RequeueAsync(WorkId, "Approved replay");

            _accountDbExecutor.VerifyAll();
            _orderDbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_Invoice_Keys_When_Matching_Should_Use_OrderDb_And_Return_The_Result()
        {
            var expected = new InvoiceReconciliationMatchResult
            {
                MatchCount = 1,
                MatchedInvoiceHeaderId = MatchedInvoiceHeaderId
            };
            _orderDbExecutor.Setup(x => x.ExecuteSingleAsync<InvoiceReconciliationMatchResult>(StoredProcedures.ReconcileInvoiceHeaderConsolidatedSales, It.IsAny<object>())).ReturnsAsync(expected);

            var result = await CreateService().MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate);

            Assert.Same(expected, result);
            _orderDbExecutor.Verify(x => x.ExecuteSingleAsync<InvoiceReconciliationMatchResult>(
                StoredProcedures.ReconcileInvoiceHeaderConsolidatedSales,
                It.Is<object>(parameters =>
                    GetProperty<string>(parameters, "standardInvoiceNumber") == StandardInvoiceNumber
                    && GetProperty<string>(parameters, "branchCode") == BranchCode
                    && GetProperty<string>(parameters, "consolidatedInvoiceNumber") == ConsolidatedInvoiceNumber
                    && GetProperty<DateOnly?>(parameters, "consolidatedInvoiceDate") == ConsolidatedInvoiceDate)), Times.Once);
            _accountDbExecutor.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_A_Matched_Invoice_When_Completing_Should_Use_AccountDb()
        {
            _accountDbExecutor.Setup(x => x.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesReconciliationWork, It.IsAny<object>())).ReturnsAsync(1);

            await CreateService().CompleteAsync(WorkId, ClaimToken, MatchedInvoiceHeaderId, NextAttemptOn);

            _accountDbExecutor.Verify(x => x.ExecuteAsync(
                StoredProcedures.CompleteConsolidatedSalesReconciliationWork,
                It.Is<object>(parameters =>
                    GetProperty<Guid>(parameters, "reconciliationWorkId") == WorkId
                    && GetProperty<Guid>(parameters, "claimToken") == ClaimToken
                    && GetProperty<Guid>(parameters, "matchedInvoiceHeaderId") == MatchedInvoiceHeaderId)), Times.Once);
            _orderDbExecutor.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_Claimed_Reconciliation_Work_When_Claiming_Should_Return_The_Matching_Keys()
        {
            var expected = new ConsolidatedSalesReconciliationWork
            {
                StandardInvoiceNumber = StandardInvoiceNumber,
                BranchCode = BranchCode,
                ConsolidatedInvoiceNumber = ConsolidatedInvoiceNumber,
                ComponentReferenceKey = "COMP-1"
            };
            _accountDbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesReconciliationWork>(StoredProcedures.ClaimNextConsolidatedSalesReconciliationWork, It.IsAny<object>())).ReturnsAsync(expected);

            var result = await CreateService().ClaimNextAsync("worker", 60, 3);

            Assert.Same(expected, result);
            _orderDbExecutor.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_A_Cancelled_Token_When_Claiming_Should_Not_Call_Either_Database()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().ClaimNextAsync("worker", 60, 3, cancellationToken: token));

            _accountDbExecutor.VerifyNoOtherCalls();
            _orderDbExecutor.VerifyNoOtherCalls();
        }

        private InvoiceReconciliationDataService CreateService() => new(_accountDbExecutor.Object, _orderDbExecutor.Object);

        private static T GetProperty<T>(object value, string propertyName)
        {
            return (T)value.GetType().GetProperty(propertyName)!.GetValue(value)!;
        }
    }
}
