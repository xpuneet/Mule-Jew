using Moq;
using STUK.TradeAccountService.Common.Salesforce;
using STUK.TradeAccountService.Common.Salesforce.Exceptions;
using STUK.TradeAccountService.Common.Salesforce.Services;
using System.Net;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests durable Salesforce extraction failure classification and backoff
    /// </summary>
    public class SalesforceExportRetryPolicyTests
    {
        [Theory]
        [InlineData(HttpStatusCode.RequestTimeout, true, "SalesforceUnavailable")]
        [InlineData(HttpStatusCode.TooManyRequests, true, "SalesforceRateLimit")]
        [InlineData(HttpStatusCode.ServiceUnavailable, true, "SalesforceUnavailable")]
        [InlineData(HttpStatusCode.BadRequest, false, "SalesforceRequestRejected")]
        public void Given_SalesforceApiFailure_When_Classifying_Should_ReturnExpectedPolicy(
            HttpStatusCode statusCode,
            bool expectedTransient,
            string expectedCategory)
        {
            var policy = CreatePolicy();
            var exception = new SalesforceApiException("Failure", statusCode);

            Assert.True(policy.CanHandle(exception));
            Assert.Equal(expectedTransient, policy.IsTransient(exception));
            Assert.Equal(expectedCategory, policy.GetCategory(exception));
        }

        [Fact]
        public void Given_RepeatedAttempts_When_Calculating_Should_ApplyBoundedExponentialBackoff()
        {
            var now = new DateTimeOffset(2026, 8, 13, 9, 0, 0, TimeSpan.Zero);
            var timeProvider = new Mock<TimeProvider>();
            timeProvider.Setup(provider => provider.GetUtcNow()).Returns(now);
            var policy = CreatePolicy(timeProvider.Object);

            Assert.InRange(policy.CalculateNextAttemptOn(1), now.AddMinutes(1), now.AddSeconds(90));
            Assert.InRange(policy.CalculateNextAttemptOn(3), now.AddMinutes(4), now.AddSeconds(270));
            Assert.Equal(now.AddMinutes(15), policy.CalculateNextAttemptOn(10));
        }

        [Fact]
        public void Given_InternalTimeout_When_Classifying_Should_BeTransientAndObservable()
        {
            var policy = CreatePolicy();
            var exception = new TaskCanceledException("Salesforce request timed out");

            Assert.True(policy.CanHandle(exception));
            Assert.True(policy.IsTransient(exception));
            Assert.Equal("SalesforceTimeout", policy.GetCategory(exception));
        }

        private static SalesforceExportRetryPolicy CreatePolicy(TimeProvider? timeProvider = null)
        {
            return new SalesforceExportRetryPolicy(timeProvider ?? Mock.Of<TimeProvider>());
        }
    }
}
