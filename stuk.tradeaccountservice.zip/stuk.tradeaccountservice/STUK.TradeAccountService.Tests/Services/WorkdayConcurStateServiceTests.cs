using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the stored-procedure boundary for Workday-to-Concur run state
    /// </summary>
    public class WorkdayConcurStateServiceTests
    {
        private static readonly Guid RunId = new("30000000-0000-0000-0000-000000000001");
        private static readonly Guid CorrelationId = new("30000000-0000-0000-0000-000000000002");
        private static readonly Guid ClaimToken = new("30000000-0000-0000-0000-000000000003");
        private static readonly DateTimeOffset Now = new(2026, 9, 4, 8, 30, 0, TimeSpan.Zero);

        private readonly Mock<IDbExecutor> _dbExecutor = new(MockBehavior.Strict);

        /// <summary>
        /// Verifies that run creation passes the frozen boundary and lease data to the named procedure
        /// </summary>
        [Fact]
        public async Task Given_RunAcquisition_When_CreatingOrResuming_Should_UseNamedProcedure()
        {
            var expected = new WorkdayConcurRun { RunId = RunId };
            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<WorkdayConcurRun>(
                    StoredProcedures.CreateWorkdayConcurRun,
                    It.Is<object>(parameters =>
                        Property<Guid>(parameters, "correlationId") == CorrelationId
                        && Property<string>(parameters, "leaseOwner") == "invocation"
                        && Property<DateTimeOffset>(parameters, "extractThrough") == Now
                        && Property<int>(parameters, "leaseDurationSeconds") == 300
                        && Property<DateTimeOffset?>(parameters, "now") == Now)))
                .ReturnsAsync(expected);

            var result = await CreateService().CreateOrResumeRunAsync(
                CorrelationId,
                "invocation",
                Now,
                300,
                Now);

            Assert.Same(expected, result);
            _dbExecutor.VerifyAll();
        }

        /// <summary>
        /// Verifies that each lifecycle operation uses its specific named stored procedure
        /// </summary>
        [Fact]
        public async Task Given_ClaimedRun_When_UpdatingLifecycle_Should_UseNamedProcedures()
        {
            SetupExecute(StoredProcedures.RenewWorkdayConcurRunLease);
            SetupExecute(StoredProcedures.UpdateWorkdayConcurRunStage);
            SetupExecute(StoredProcedures.FailWorkdayConcurRun);
            SetupExecute(StoredProcedures.ReleaseWorkdayConcurRunLease);
            SetupExecute(StoredProcedures.CompleteWorkdayConcurNoDataRun);
            SetupExecute(StoredProcedures.CommitWorkdayConcurRun);

            var service = CreateService();

            await service.RenewLeaseAsync(RunId, ClaimToken, 300, Now);

            await service.UpdateStageAsync(
                RunId,
                ClaimToken,
                WorkdayConcurRunStage.Pending,
                WorkdayConcurRunStage.CollectingInputs,
                "{\"tm1\":\"ready\"}",
                "tm1-run",
                now: Now);

            await service.FailRunAsync(RunId, ClaimToken, "Synapse", "Failed", Now);
            await service.ReleaseLeaseAsync(RunId, ClaimToken, Now);
            await service.CompleteNoDataRunAsync(RunId, ClaimToken, Now);
            await service.CommitRunAsync(RunId, ClaimToken, Now);

            _dbExecutor.Verify(x => x.ExecuteAsync(
                StoredProcedures.UpdateWorkdayConcurRunStage,
                It.Is<object>(parameters =>
                    Property<string>(parameters, "expectedStage") == "Pending"
                    && Property<string>(parameters, "newStage") == "CollectingInputs"
                    && Property<string>(parameters, "fileStateJson") == "{\"tm1\":\"ready\"}"
                    && Property<string>(parameters, "tm1SynapseRunId") == "tm1-run")), Times.Once);
            _dbExecutor.VerifyAll();
        }

        /// <summary>
        /// Verifies that support inspection uses the incomplete-run query procedure
        /// </summary>
        [Fact]
        public async Task Given_SupportInspection_When_GettingIncompleteRun_Should_UseNamedProcedure()
        {
            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<WorkdayConcurRun>(
                    StoredProcedures.GetIncompleteWorkdayConcurRun,
                    It.IsAny<object>()))
                .ReturnsAsync((WorkdayConcurRun?)null);

            var result = await CreateService().GetIncompleteRunAsync();

            Assert.Null(result);
            _dbExecutor.VerifyAll();
        }

        /// <summary>
        /// Verifies that cancellation is observed before database access
        /// </summary>
        [Fact]
        public async Task Given_CancelledToken_When_AccessingState_Should_NotCallDatabase()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().GetIncompleteRunAsync(token));

            _dbExecutor.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that the state service rejects a missing database executor
        /// </summary>
        [Fact]
        public void Given_MissingExecutor_When_Constructing_Should_RejectDependency()
        {
            Assert.Throws<ArgumentNullException>(() => new WorkdayConcurStateService(null!));
        }

        private void SetupExecute(string procedure)
        {
            _dbExecutor
                .Setup(x => x.ExecuteAsync(procedure, It.IsAny<object>()))
                .ReturnsAsync(1);
        }

        private WorkdayConcurStateService CreateService()
        {
            return new WorkdayConcurStateService(_dbExecutor.Object);
        }

        private static T? Property<T>(object value, string propertyName)
        {
            return (T?)value.GetType().GetProperty(propertyName)?.GetValue(value);
        }
    }
}
