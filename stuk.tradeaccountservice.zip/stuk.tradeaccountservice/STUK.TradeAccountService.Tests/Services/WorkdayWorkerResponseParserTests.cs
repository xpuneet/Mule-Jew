using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Tests.Fixtures.Workday;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests parsing of Workday Get_Workers SOAP responses
    /// </summary>
    public class WorkdayWorkerResponseParserTests
    {
        private const string WorkdayNamespace = "urn:com.workday/bsvc";

        /// <summary>
        /// Verifies that discovery returns only Employee_ID references rather than contingent-worker identifiers
        /// </summary>
        [Fact]
        public void Given_WorkerReferences_When_Parsing_Should_ReturnOnlyEmployeeIdentifiers()
        {
            var response = WorkdayTestFixture.Read("reference-workers.xml");

            var page = new WorkdayWorkerResponseParser().ParseReferencePage(response);

            Assert.Equal(1, page.Page);
            Assert.Equal(1, page.TotalPages);
            Assert.Equal(["1001"], page.EmployeeIds);
        }

        /// <summary>
        /// Verifies that the parser extracts the Workday fields consumed by the employee CSV mapping
        /// </summary>
        [Fact]
        public void Given_WorkerDetails_When_Parsing_Should_ReturnTypedWorkerValues()
        {
            var response = WorkdayTestFixture.Read("worker-details.xml");

            var page = new WorkdayWorkerResponseParser().ParseWorkerPage(response);

            var worker = Assert.Single(page.Workers);
            Assert.Equal("1001", worker.EmployeeId);
            Assert.Equal("alex.worker@example.test", worker.PrimaryWorkEmail);
            Assert.Equal("Alex", worker.PreferredFirstName);
            Assert.Equal("Worker", worker.PreferredLastName);
            Assert.Equal("Branch Manager", worker.PositionTitle);
            Assert.Equal("London", worker.OrganizationName);
            Assert.Equal("2026-08-31", worker.TerminationDate);
            Assert.Equal("person@stark.example", worker.FirstIntegrationFieldOverrideValue);
            Assert.Equal("person@stark.example", worker.IntegrationFieldOverrides["UPN"]);
            Assert.Equal("PL1001", worker.CustomIds["SUK_Purchase_Ledger_Code_UK"]);
        }

        /// <summary>
        /// Verifies a missing integration-field override remains absent so CSV generation applies the Mule default
        /// </summary>
        [Fact]
        public void Given_NoIntegrationFieldOverride_When_Parsing_Should_PreserveMissingValue()
        {
            var workerXml = "<wd:Worker><wd:Worker_Data><wd:Worker_ID>1001</wd:Worker_ID></wd:Worker_Data></wd:Worker>";
            var response = CreateResponse("1", "1", workerXml);

            var page = new WorkdayWorkerResponseParser().ParseWorkerPage(response);

            Assert.Null(Assert.Single(page.Workers).FirstIntegrationFieldOverrideValue);
        }

        /// <summary>
        /// Verifies that Workday SOAP faults cannot be treated as empty employee responses
        /// </summary>
        [Fact]
        public void Given_SoapFault_When_Parsing_Should_FailWithFaultMessage()
        {
            var response = WorkdayTestFixture.Read("soap-fault.xml");

            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseReferencePage(response));

            Assert.Contains("Invalid credentials", exception.Message);
        }

        /// <summary>
        /// Verifies that response parsing does not allow document type declarations
        /// </summary>
        [Fact]
        public void Given_DocumentTypeDeclaration_When_Parsing_Should_RejectResponse()
        {
            const string response = "<!DOCTYPE response [<!ENTITY value 'unsafe'>]><response>&value;</response>";

            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseReferencePage(response));

            Assert.Contains("invalid XML", exception.Message);
        }

        /// <summary>
        /// Verifies malformed XML is reported as invalid source data
        /// </summary>
        [Fact]
        public void Given_MalformedXml_When_Parsing_Should_RejectResponse()
        {
            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseReferencePage("<broken>"));

            Assert.Contains("invalid XML", exception.Message);
        }

        /// <summary>
        /// Verifies a valid XML document cannot masquerade as a Workday response
        /// </summary>
        [Fact]
        public void Given_MissingWorkdayResponse_When_Parsing_Should_RejectResponse()
        {
            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseReferencePage("<response />"));

            Assert.Contains("Get_Workers_Response", exception.Message);
        }

        /// <summary>
        /// Verifies paging metadata is mandatory
        /// </summary>
        [Fact]
        public void Given_MissingPagingMetadata_When_Parsing_Should_RejectResponse()
        {
            var response = $"<wd:Get_Workers_Response xmlns:wd=\"{WorkdayNamespace}\" />";

            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseReferencePage(response));

            Assert.Contains("Response_Results", exception.Message);
        }

        /// <summary>
        /// Verifies impossible and non-numeric Workday page values are rejected
        /// </summary>
        [Theory]
        [InlineData("invalid", "1")]
        [InlineData("1", "invalid")]
        [InlineData("-1", "1")]
        [InlineData("0", "1")]
        [InlineData("2", "1")]
        public void Given_InvalidPagingMetadata_When_Parsing_Should_RejectResponse(string page, string totalPages)
        {
            var response = CreateResponse(page, totalPages);

            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseReferencePage(response));

            Assert.Contains("invalid", exception.Message, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Verifies an invalid Employee_ID SOAP fault is exposed as the retryable typed exception
        /// </summary>
        [Fact]
        public void Given_InvalidEmployeeIdFault_When_Parsing_Should_ReturnRejectedEmployeeId()
        {
            var response = WorkdayTestFixture.Read("invalid-employee-id-fault.xml");

            var exception = Assert.ThrowsAny<IOException>(() => new WorkdayWorkerResponseParser().ParseWorkerPage(response));

            Assert.Equal("WorkdayInvalidEmployeeIdException", exception.GetType().Name);
            Assert.Contains("Employee_ID '1002'", exception.Message);
        }

        /// <summary>
        /// Verifies a SOAP fault without descriptive content still fails explicitly
        /// </summary>
        [Fact]
        public void Given_EmptySoapFault_When_Parsing_Should_RejectResponse()
        {
            const string response = "<Envelope><Body><Fault /></Body></Envelope>";

            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseReferencePage(response));

            Assert.Equal("Workday returned a SOAP fault", exception.Message);
        }

        /// <summary>
        /// Verifies worker detail records require both Worker_Data and Worker_ID
        /// </summary>
        [Theory]
        [InlineData("<wd:Worker />", "Worker_Data")]
        [InlineData("<wd:Worker><wd:Worker_Data /></wd:Worker>", "Worker_ID")]
        public void Given_IncompleteWorker_When_Parsing_Should_RejectResponse(string workerXml, string expectedMessage)
        {
            var response = CreateResponse("1", "1", workerXml);

            var exception = Assert.Throws<InvalidDataException>(() => new WorkdayWorkerResponseParser().ParseWorkerPage(response));

            Assert.Contains(expectedMessage, exception.Message);
        }

        /// <summary>
        /// Verifies an empty response is rejected by the public parser boundary
        /// </summary>
        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        public void Given_EmptyResponse_When_Parsing_Should_RejectArgument(string response)
        {
            Assert.Throws<ArgumentException>(() => new WorkdayWorkerResponseParser().ParseReferencePage(response));
            Assert.Throws<ArgumentException>(() => new WorkdayWorkerResponseParser().ParseWorkerPage(response));
        }

        private static string CreateResponse(string page, string totalPages, string workerXml = "")
        {
            return $"<wd:Get_Workers_Response xmlns:wd=\"{WorkdayNamespace}\"><wd:Response_Results><wd:Page>{page}</wd:Page><wd:Total_Pages>{totalPages}</wd:Total_Pages></wd:Response_Results><wd:Response_Data>{workerXml}</wd:Response_Data></wd:Get_Workers_Response>";
        }
    }
}
