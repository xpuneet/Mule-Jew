using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedSalesBlobSourceTests
    {
        private const string BlobETag = "\"etag\"";
        private static readonly byte[] ContentHash = [1, 2, 3, 4];
        private static readonly DateTimeOffset LastModifiedOn = new(2026, 8, 7, 9, 30, 0, TimeSpan.Zero);
        private static readonly Guid CorrelationId = Guid.Parse("448679dc-b491-4d74-bcfa-ab2072330a19");

        private readonly Mock<ILogger<ConsolidatedSalesBlobSource>> _logger = new();
        private readonly Mock<BlobServiceClient> _blobServiceClient = new();
        private readonly Mock<BlobContainerClient> _blobContainerClient = new();

        [Fact]
        public async Task Given_A_Ready_Prefix_When_Discovering_Should_Return_Only_Supported_HX_Files()
        {
            var supportedBlob = CreateBlobItem("ready/cons_JEW041_0580_260712.con.xml");
            var unsupportedBlob = CreateBlobItem("ready/readme.txt");
            SetupBlobs([supportedBlob, unsupportedBlob]);

            var results = await CollectAsync(CreateService().DiscoverAsync());

            var result = Assert.Single(results);
            Assert.Equal("HX", result.SourceSystem);
            Assert.Equal("consolidated-sales", result.BlobContainer);
            Assert.Equal(supportedBlob.Name, result.BlobPath);
            Assert.Equal("cons_JEW041_0580_260712.con.xml", result.SourceFileName);
            Assert.Equal(172, result.ContentLength);
            Assert.Equal(LastModifiedOn, result.BlobLastModifiedOn);
            Assert.Equal(CorrelationId, result.CorrelationId);
            Assert.Equal(Convert.ToBase64String(ContentHash), result.ContentChecksum);
            Assert.Equal("\"etag\"", result.ETag);
            _blobContainerClient.Verify(
                x => x.GetBlobsAsync(
                    BlobTraits.Metadata,
                    BlobStates.None,
                    "ready/",
                    It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("not-a-guid")]
        public async Task Given_Missing_Or_Invalid_Correlation_Metadata_When_Discovering_Should_Generate_And_Log_A_Correlation_Id(string? correlationMetadata)
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            var blob = correlationMetadata is null
                ? CreateBlobItem(blobPath, includeCorrelationMetadata: false)
                : CreateBlobItem(blobPath, correlationMetadata: correlationMetadata);
            SetupBlobs([blob]);

            var results = await CollectAsync(CreateService().DiscoverAsync());

            var result = Assert.Single(results);
            Assert.NotEqual(Guid.Empty, result.CorrelationId);
            VerifyGeneratedCorrelationIdLog(blobPath, result.CorrelationId, Times.Once());
        }

        [Fact]
        public async Task Given_No_Ready_Prefix_When_Discovering_Should_Reject_The_Configuration()
        {
            var service = CreateService(readyPrefix: string.Empty);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(
                async () => await CollectAsync(service.DiscoverAsync()));

            Assert.Equal("The consolidated sales Blob ready prefix must be configured", exception.Message);
            _blobServiceClient.VerifyNoOtherCalls();
        }

        [Theory]
        [InlineData("", ".con.xml", "HX", "The consolidated sales Blob container must be configured")]
        [InlineData("consolidated-sales", "", "HX", "The consolidated sales file suffix must be configured")]
        [InlineData("consolidated-sales", ".con.xml", "", "The consolidated sales source system must be configured")]
        public async Task Given_A_Required_Discovery_Option_Is_Missing_When_Discovering_Should_Reject_The_Configuration(string containerName, string fileSuffix, string sourceSystem, string expectedMessage)
        {
            var service = CreateService(containerName: containerName, fileSuffix: fileSuffix, sourceSystem: sourceSystem);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(async () => await CollectAsync(service.DiscoverAsync()));

            Assert.Equal(expectedMessage, exception.Message);
            _blobServiceClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_A_Blob_Without_An_ETag_When_Discovering_Should_Reject_And_Log_The_Source()
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            SetupBlobs([CreateBlobItem(blobPath, includeETag: false)]);

            var results = await CollectAsync(CreateService().DiscoverAsync());

            Assert.Empty(results);
            VerifyRejectedBlobLog(blobPath, Times.Once());
        }

        [Fact]
        public async Task Given_A_Blob_Without_A_Content_Length_When_Discovering_Should_Reject_And_Log_The_Source()
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            SetupBlobs([CreateBlobItem(blobPath, includeContentLength: false)]);

            var results = await CollectAsync(CreateService().DiscoverAsync());

            Assert.Empty(results);
            VerifyRejectedBlobLog(blobPath, Times.Once());
        }

        [Fact]
        public async Task Given_A_Blob_Without_A_Last_Modified_Time_When_Discovering_Should_Reject_And_Log_The_Source()
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            SetupBlobs([CreateBlobItem(blobPath, includeLastModified: false)]);

            var results = await CollectAsync(CreateService().DiscoverAsync());

            Assert.Empty(results);
            VerifyRejectedBlobLog(blobPath, Times.Once());
        }

        [Fact]
        public async Task Given_An_Expected_ETag_When_Opening_A_Source_Should_Use_A_Conditional_Read()
        {
            const string sourcePath = "ready/cons_JEW041_0580_260712.con.xml";
            var sourceBlob = new Mock<BlobClient>();
            var content = new MemoryStream([1, 2, 3]);

            _blobServiceClient
                .Setup(x => x.GetBlobContainerClient("consolidated-sales"))
                .Returns(_blobContainerClient.Object);

            _blobContainerClient
                .Setup(x => x.GetBlobClient(sourcePath))
                .Returns(sourceBlob.Object);

            sourceBlob
                .Setup(x => x.DownloadStreamingAsync(
                    It.Is<BlobDownloadOptions>(options => options.Conditions.IfMatch == new ETag(BlobETag)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(BlobsModelFactory.BlobDownloadStreamingResult(content, null!), Mock.Of<Response>()));

            await using var result = await CreateService().OpenReadAsync("consolidated-sales", sourcePath, BlobETag);

            Assert.Same(content, result);
            sourceBlob.VerifyAll();
        }

        [Fact]
        public async Task Given_A_Registered_Source_When_Opening_Should_Read_The_Exact_Blob_Version()
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            var blobClient = new Mock<BlobClient>();
            var content = new MemoryStream([1, 2, 3]);
            _blobServiceClient
                .Setup(x => x.GetBlobContainerClient("consolidated-sales"))
                .Returns(_blobContainerClient.Object);

            _blobContainerClient
                .Setup(x => x.GetBlobClient(blobPath))
                .Returns(blobClient.Object);

            blobClient
                .Setup(x => x.DownloadStreamingAsync(
                    It.Is<BlobDownloadOptions>(options => options.Conditions.IfMatch == new ETag(BlobETag)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(BlobsModelFactory.BlobDownloadStreamingResult(content, null!), Mock.Of<Response>()));

            var result = await CreateService().OpenReadAsync("consolidated-sales", blobPath, BlobETag);

            Assert.Same(content, result);
            blobClient.VerifyAll();
        }

        [Fact]
        public async Task Given_A_Processed_Source_When_Renaming_Should_Verify_The_Copy_Before_Deleting_The_Original()
        {
            const string sourcePath = "ready/cons_JEW041_0580_260712.con.xml";
            const string processedPath = "ready/cons_JEW041_0580_260712.con.xml-ok";
            var sourceUri = new Uri("https://storage.test/consolidated-sales/ready/cons_JEW041_0580_260712.con.xml");
            var sourceBlob = new Mock<BlobClient>();
            var processedBlob = new Mock<BlobClient>();
            var processedProperties = CreateProcessedBlobProperties(172);
            var processedContent = new MemoryStream([1]);

            sourceBlob.SetupGet(x => x.Uri).Returns(sourceUri);

            SetupRename(sourcePath, processedPath, sourceBlob, processedBlob);
            processedBlob
                .Setup(x => x.StartCopyFromUriAsync(
                    sourceUri,
                    It.Is<BlobCopyFromUriOptions>(options => options.SourceConditions.IfMatch == new ETag(BlobETag)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((CopyFromUriOperation)null!);
            processedBlob
                .Setup(x => x.GetPropertiesAsync(
                    It.IsAny<BlobRequestConditions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(processedProperties, Mock.Of<Response>()));
            processedBlob
                .Setup(x => x.DownloadStreamingAsync(
                    It.Is<BlobDownloadOptions>(options => options.Conditions.IfMatch == processedProperties.ETag),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(
                    BlobsModelFactory.BlobDownloadStreamingResult(processedContent, null!),
                    Mock.Of<Response>()));
            sourceBlob
                .Setup(x => x.DeleteIfExistsAsync(
                    DeleteSnapshotsOption.IncludeSnapshots,
                    It.IsAny<BlobRequestConditions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(true, Mock.Of<Response>()));

            await CreateService().RenameAsProcessedAsync("consolidated-sales", sourcePath, 172, BlobETag);

            processedBlob.Verify(x => x.StartCopyFromUriAsync(
                sourceUri,
                It.Is<BlobCopyFromUriOptions>(options => options.SourceConditions.IfMatch == new ETag(BlobETag)),
                It.IsAny<CancellationToken>()), Times.Once);
            processedBlob.Verify(x => x.GetPropertiesAsync(
                It.IsAny<BlobRequestConditions>(),
                It.IsAny<CancellationToken>()), Times.Once);
            processedBlob.Verify(x => x.DownloadStreamingAsync(
                It.Is<BlobDownloadOptions>(options => options.Conditions.IfMatch == processedProperties.ETag),
                It.IsAny<CancellationToken>()), Times.Once);
            sourceBlob.Verify(x => x.DeleteIfExistsAsync(
                DeleteSnapshotsOption.IncludeSnapshots,
                It.Is<BlobRequestConditions>(conditions => conditions.IfMatch == new ETag(BlobETag)),
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Copy_With_The_Wrong_Length_When_Renaming_Should_Keep_The_Original()
        {
            const string sourcePath = "ready/cons_JEW041_0580_260712.con.xml";
            const string processedPath = "ready/cons_JEW041_0580_260712.con.xml-ok";
            var sourceUri = new Uri("https://storage.test/consolidated-sales/ready/cons_JEW041_0580_260712.con.xml");
            var sourceBlob = new Mock<BlobClient>();
            var processedBlob = new Mock<BlobClient>();
            var processedProperties = CreateProcessedBlobProperties(171);

            sourceBlob.SetupGet(x => x.Uri).Returns(sourceUri);

            SetupRename(sourcePath, processedPath, sourceBlob, processedBlob);
            processedBlob
                .Setup(x => x.StartCopyFromUriAsync(
                    sourceUri,
                    It.Is<BlobCopyFromUriOptions>(options => options.SourceConditions.IfMatch == new ETag(BlobETag)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((CopyFromUriOperation)null!);
            processedBlob
                .Setup(x => x.GetPropertiesAsync(
                    It.IsAny<BlobRequestConditions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(processedProperties, Mock.Of<Response>()));

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
                CreateService().RenameAsProcessedAsync("consolidated-sales", sourcePath, 172, BlobETag));

            Assert.Equal("The processed Blob length does not match the source-file length", exception.Message);
            processedBlob.Verify(x => x.DownloadStreamingAsync(
                It.IsAny<BlobDownloadOptions>(),
                It.IsAny<CancellationToken>()), Times.Never);
            sourceBlob.Verify(x => x.DeleteIfExistsAsync(
                It.IsAny<DeleteSnapshotsOption>(),
                It.IsAny<BlobRequestConditions>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_A_Copy_Fails_When_Renaming_Should_Keep_The_Original()
        {
            const string sourcePath = "ready/cons_JEW041_0580_260712.con.xml";
            const string processedPath = "ready/cons_JEW041_0580_260712.con.xml-ok";
            var sourceUri = new Uri("https://storage.test/consolidated-sales/ready/cons_JEW041_0580_260712.con.xml");
            var sourceBlob = new Mock<BlobClient>();
            var processedBlob = new Mock<BlobClient>();
            var processedProperties = CreateProcessedBlobProperties(172, CopyStatus.Failed, "Copy failed");

            sourceBlob.SetupGet(x => x.Uri).Returns(sourceUri);

            SetupRename(sourcePath, processedPath, sourceBlob, processedBlob);

            processedBlob
                .Setup(x => x.StartCopyFromUriAsync(sourceUri, It.IsAny<BlobCopyFromUriOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((CopyFromUriOperation)null!);

            processedBlob
                .Setup(x => x.GetPropertiesAsync(It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(processedProperties, Mock.Of<Response>()));

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().RenameAsProcessedAsync("consolidated-sales", sourcePath, 172, BlobETag));

            Assert.Equal("Blob copy did not complete successfully: Copy failed", exception.Message);
            processedBlob.Verify(x => x.DownloadStreamingAsync(It.IsAny<BlobDownloadOptions>(), It.IsAny<CancellationToken>()), Times.Never);
            sourceBlob.Verify(x => x.DeleteIfExistsAsync(It.IsAny<DeleteSnapshotsOption>(), It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_A_Copied_Blob_Cannot_Be_Read_When_Renaming_Should_Keep_The_Original()
        {
            const string sourcePath = "ready/cons_JEW041_0580_260712.con.xml";
            const string processedPath = "ready/cons_JEW041_0580_260712.con.xml-ok";
            var sourceUri = new Uri("https://storage.test/consolidated-sales/ready/cons_JEW041_0580_260712.con.xml");
            var sourceBlob = new Mock<BlobClient>();
            var processedBlob = new Mock<BlobClient>();
            var processedProperties = CreateProcessedBlobProperties(172);

            sourceBlob.SetupGet(x => x.Uri).Returns(sourceUri);

            SetupRename(sourcePath, processedPath, sourceBlob, processedBlob);

            processedBlob
                .Setup(x => x.StartCopyFromUriAsync(sourceUri, It.IsAny<BlobCopyFromUriOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((CopyFromUriOperation)null!);

            processedBlob
                .Setup(x => x.GetPropertiesAsync(It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(processedProperties, Mock.Of<Response>()));

            processedBlob
                .Setup(x => x.DownloadStreamingAsync(It.IsAny<BlobDownloadOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(BlobsModelFactory.BlobDownloadStreamingResult(new MemoryStream(), null!), Mock.Of<Response>()));

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().RenameAsProcessedAsync("consolidated-sales", sourcePath, 172, BlobETag));

            Assert.Equal("The processed Blob could not be read after copying", exception.Message);
            sourceBlob.Verify(x => x.DeleteIfExistsAsync(It.IsAny<DeleteSnapshotsOption>(), It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_A_Zero_Byte_Blob_Is_Copied_When_Renaming_Should_Delete_The_Original_Without_A_Content_Read()
        {
            const string sourcePath = "ready/empty.con.xml";
            const string processedPath = "ready/empty.con.xml-ok";
            var sourceUri = new Uri("https://storage.test/consolidated-sales/ready/empty.con.xml");
            var sourceBlob = new Mock<BlobClient>();
            var processedBlob = new Mock<BlobClient>();
            var processedProperties = CreateProcessedBlobProperties(0);

            sourceBlob.SetupGet(x => x.Uri).Returns(sourceUri);

            SetupRename(sourcePath, processedPath, sourceBlob, processedBlob);

            processedBlob
                .Setup(x => x.StartCopyFromUriAsync(sourceUri, It.IsAny<BlobCopyFromUriOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((CopyFromUriOperation)null!);

            processedBlob
                .Setup(x => x.GetPropertiesAsync(It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(processedProperties, Mock.Of<Response>()));

            sourceBlob
                .Setup(x => x.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots, It.IsAny<BlobRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(true, Mock.Of<Response>()));

            await CreateService().RenameAsProcessedAsync("consolidated-sales", sourcePath, 0, BlobETag);

            processedBlob.Verify(x => x.DownloadStreamingAsync(It.IsAny<BlobDownloadOptions>(), It.IsAny<CancellationToken>()), Times.Never);
            sourceBlob.Verify(x => x.DeleteIfExistsAsync(
                DeleteSnapshotsOption.IncludeSnapshots,
                It.Is<BlobRequestConditions>(conditions => conditions.IfMatch == new ETag(BlobETag)),
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Negative_Expected_Length_When_Renaming_Should_Reject_Without_Accessing_Blob_Storage()
        {
            var exception = await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => CreateService().RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", -1, BlobETag));

            Assert.Equal("expectedContentLength", exception.ParamName);
            _blobServiceClient.VerifyNoOtherCalls();
        }

        private void SetupBlobs(IReadOnlyList<BlobItem> blobs)
        {
            var page = Page<BlobItem>.FromValues(blobs, null, Mock.Of<Response>());
            var pageable = AsyncPageable<BlobItem>.FromPages([page]);

            _blobServiceClient
                .Setup(x => x.GetBlobContainerClient("consolidated-sales"))
                .Returns(_blobContainerClient.Object);
            _blobContainerClient
                .Setup(x => x.GetBlobsAsync(
                    BlobTraits.Metadata,
                    BlobStates.None,
                    "ready/",
                    It.IsAny<CancellationToken>()))
                .Returns(pageable);
        }

        private void SetupRename(
            string sourcePath,
            string processedPath,
            Mock<BlobClient> sourceBlob,
            Mock<BlobClient> processedBlob)
        {
            _blobServiceClient
                .Setup(x => x.GetBlobContainerClient("consolidated-sales"))
                .Returns(_blobContainerClient.Object);
            _blobContainerClient
                .Setup(x => x.GetBlobClient(sourcePath))
                .Returns(sourceBlob.Object);
            _blobContainerClient
                .Setup(x => x.GetBlobClient(processedPath))
                .Returns(processedBlob.Object);
        }

        private ConsolidatedSalesBlobSource CreateService(string readyPrefix = "ready/", string containerName = "consolidated-sales", string fileSuffix = ".con.xml", string sourceSystem = "HX")
        {
            var options = Options.Create(new ConsolidatedSalesIngestionOptions
            {
                SourceSystem = sourceSystem,
                ContainerName = containerName,
                ReadyPrefix = readyPrefix,
                FileSuffix = fileSuffix
            });

            return new ConsolidatedSalesBlobSource(_logger.Object, _blobServiceClient.Object, options);
        }

        private void VerifyRejectedBlobLog(string blobPath, Times times)
        {
            _logger.Verify(
                logger => logger.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((value, _) =>
                        value.ToString()!.Contains("Rejected staged HX Blob", StringComparison.Ordinal)
                        && value.ToString()!.Contains(blobPath, StringComparison.Ordinal)),
                    It.IsAny<InvalidOperationException>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                times);
        }

        private void VerifyGeneratedCorrelationIdLog(string blobPath, Guid correlationId, Times times)
        {
            _logger.Verify(
                logger => logger.Log(
                    LogLevel.Warning,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((value, _) =>
                        value.ToString()!.Contains(blobPath, StringComparison.Ordinal)
                        && value.ToString()!.Contains(correlationId.ToString(), StringComparison.Ordinal)),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                times);
        }

        private static BlobItem CreateBlobItem(
            string name,
            bool includeETag = true,
            bool includeContentLength = true,
            long contentLength = 172,
            bool includeLastModified = true,
            bool includeCorrelationMetadata = true,
            string correlationMetadata = "448679dc-b491-4d74-bcfa-ab2072330a19")
        {
            var properties = BlobsModelFactory.BlobItemProperties(
                accessTierInferred: false,
                contentHash: ContentHash,
                contentLength: includeContentLength ? contentLength : null,
                eTag: includeETag ? new ETag(BlobETag) : (ETag?)null,
                lastModified: includeLastModified ? LastModifiedOn : null);

            var metadata = new Dictionary<string, string>();
            if (includeCorrelationMetadata)
            {
                metadata["CorrelationID"] = correlationMetadata;
            }

            return BlobsModelFactory.BlobItem(
                name,
                false,
                properties,
                null,
                metadata);
        }

        private static BlobProperties CreateProcessedBlobProperties(long contentLength, CopyStatus copyStatus = CopyStatus.Success, string? copyStatusDescription = null)
        {
            return BlobsModelFactory.BlobProperties(
                lastModified: default,
                leaseState: default,
                leaseStatus: default,
                contentLength: contentLength,
                leaseDuration: default,
                eTag: new ETag("\"processed-etag\""),
                contentHash: null!,
                contentEncoding: null!,
                contentDisposition: null!,
                contentLanguage: null!,
                destinationSnapshot: null!,
                cacheControl: null!,
                isIncrementalCopy: false,
                blobSequenceNumber: 0,
                copyStatus: copyStatus,
                acceptRanges: null!,
                copySource: null!,
                blobCommittedBlockCount: 0,
                copyProgress: null!,
                isServerEncrypted: false,
                copyId: null!,
                encryptionKeySha256: null!,
                copyStatusDescription: copyStatusDescription,
                encryptionScope: null!,
                copyCompletedOn: default,
                accessTier: null!,
                blobType: default,
                accessTierInferred: false,
                metadata: null!,
                archiveStatus: null!,
                createdOn: default,
                accessTierChangedOn: default,
                contentType: null!);
        }

        private static async Task<IReadOnlyList<T>> CollectAsync<T>(IAsyncEnumerable<T> values)
        {
            var results = new List<T>();
            await foreach (var value in values)
            {
                results.Add(value);
            }

            return results;
        }

        [Fact]
        public async Task Given_A_Known_Blob_Version_When_Opening_Should_Use_The_Expected_ETag()
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            var blobClient = new Mock<BlobClient>();
            var content = new MemoryStream([1, 2, 3]);

            _blobServiceClient
                .Setup(client => client.GetBlobContainerClient("consolidated-sales"))
                .Returns(_blobContainerClient.Object);

            _blobContainerClient
                .Setup(client => client.GetBlobClient(blobPath))
                .Returns(blobClient.Object);

            blobClient
                .Setup(client => client.DownloadStreamingAsync(
                    It.Is<BlobDownloadOptions>(options => options.Conditions.IfMatch == new ETag(BlobETag)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(
                    BlobsModelFactory.BlobDownloadStreamingResult(content, null!),
                    Mock.Of<Response>()));

            await using var result = await CreateService().OpenReadAsync("consolidated-sales", blobPath, BlobETag);

            Assert.Same(content, result);
            blobClient.Verify(client => client.DownloadStreamingAsync(
                It.Is<BlobDownloadOptions>(options => options.Conditions.IfMatch == new ETag(BlobETag)),
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Zero_Length_Blob_When_Renaming_Should_Verify_And_Delete_The_Original()
        {
            const string sourcePath = "ready/empty.con.xml";
            const string processedPath = "ready/empty.con.xml-ok";
            var sourceUri = new Uri("https://storage.test/consolidated-sales/ready/empty.con.xml");
            var sourceBlob = new Mock<BlobClient>();
            var processedBlob = new Mock<BlobClient>();
            var processedProperties = CreateProcessedBlobProperties(0);

            sourceBlob.SetupGet(client => client.Uri).Returns(sourceUri);

            SetupRename(sourcePath, processedPath, sourceBlob, processedBlob);

            processedBlob
                .Setup(client => client.StartCopyFromUriAsync(
                    sourceUri,
                    It.IsAny<BlobCopyFromUriOptions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((CopyFromUriOperation)null!);

            processedBlob
                .Setup(client => client.GetPropertiesAsync(
                    It.IsAny<BlobRequestConditions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(processedProperties, Mock.Of<Response>()));

            processedBlob
                .Setup(client => client.DownloadStreamingAsync(
                    It.IsAny<BlobDownloadOptions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(
                    BlobsModelFactory.BlobDownloadStreamingResult(new MemoryStream(), null!),
                    Mock.Of<Response>()));

            sourceBlob
                .Setup(client => client.DeleteIfExistsAsync(
                    DeleteSnapshotsOption.IncludeSnapshots,
                    It.IsAny<BlobRequestConditions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(true, Mock.Of<Response>()));

            await CreateService().RenameAsProcessedAsync("consolidated-sales", sourcePath, 0, BlobETag);

            sourceBlob.Verify(client => client.DeleteIfExistsAsync(
                DeleteSnapshotsOption.IncludeSnapshots,
                It.Is<BlobRequestConditions>(conditions => conditions.IfMatch == new ETag(BlobETag)),
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Negative_Content_Length_When_Renaming_Should_Reject_Before_Accessing_Storage()
        {
            var exception = await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() =>
                CreateService().RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", -1, BlobETag));

            Assert.Equal("expectedContentLength", exception.ParamName);
            _blobServiceClient.VerifyNoOtherCalls();
        }

        [Theory]
        [InlineData("", "consolidated-sales", "ready/", ".con.xml", "source system")]
        [InlineData("HX", "", "ready/", ".con.xml", "container")]
        [InlineData("HX", "consolidated-sales", "ready/", "", "file suffix")]
        public async Task Given_Required_Discovery_Configuration_Is_Missing_When_Discovering_Should_Reject_The_Configuration(
            string sourceSystem,
            string containerName,
            string readyPrefix,
            string fileSuffix,
            string expectedMessage)
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
                await CollectAsync(CreateService(readyPrefix, containerName, fileSuffix, sourceSystem).DiscoverAsync()));

            Assert.Contains(expectedMessage, exception.Message, StringComparison.OrdinalIgnoreCase);
            _blobServiceClient.VerifyNoOtherCalls();
        }


        [Fact]
        public async Task Given_A_Blob_Without_An_ETag_When_Discovering_Should_Skip_And_Log_The_Source()
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            SetupBlobs([CreateBlobItem(blobPath, includeETag: false)]);

            var registrations = await CollectAsync(CreateService().DiscoverAsync());

            Assert.Empty(registrations);
            VerifyRejectedBlobLog(blobPath, Times.Once());
        }

        [Fact]
        public async Task Given_A_Blob_Without_A_Content_Length_When_Discovering_Should_Skip_And_Log_The_Source()
        {
            const string blobPath = "ready/cons_JEW041_0580_260712.con.xml";
            SetupBlobs([CreateBlobItem(blobPath, includeContentLength: false)]);

            var registrations = await CollectAsync(CreateService().DiscoverAsync());

            Assert.Empty(registrations);
            VerifyRejectedBlobLog(blobPath, Times.Once());
        }

    }
}
