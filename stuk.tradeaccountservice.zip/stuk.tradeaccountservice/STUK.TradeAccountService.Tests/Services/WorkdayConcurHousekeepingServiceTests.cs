using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the reverse-engineered Workday-to-Concur copy-before-delete behaviour
    /// </summary>
    public class WorkdayConcurHousekeepingServiceTests
    {
        private const string BlobEndpoint = "https://storage.blob.core.windows.net/";
        private const string ContainerName = "stukconcurprd";
        private static readonly DateTimeOffset Now = new(2026, 9, 5, 13, 14, 15, 678, TimeSpan.Zero);
        private static readonly Guid CorrelationId = new("20000000-0000-0000-0000-000000000001");

        private readonly Mock<ISynapsePipelineClient> _synapseClient = new();
        private readonly Mock<IWorkdayConcurBlobClient> _blobClient = new();

        /// <summary>
        /// Verifies that output and input files are frozen into the current Mule destination and naming contract
        /// </summary>
        [Fact]
        public async Task Given_OutputAndInputFiles_When_Preparing_Should_CreateTimestampedMovePlan()
        {
            var output = CreateFile("stukconcurprd/output/employee.txt", 100, "output-etag");
            var input = CreateFile("stukconcurprd/input/TM1.csv", 50, "input-etag");

            _blobClient
                .Setup(value => value.ListFilesAsync(new Uri(BlobEndpoint), ContainerName, "input", default))
                .ReturnsAsync(new[] { input });

            var checkpoint = await CreateService().PrepareAsync(new[] { output });

            Assert.Equal(WorkdayConcurHousekeepingStatus.InProgress, checkpoint.Status);
            Assert.Equal(BlobEndpoint, checkpoint.BlobServiceEndpoint);
            Assert.Collection(
                checkpoint.Moves,
                move => AssertMove(move, "stukconcurprd/output", "employee.txt", "stukconcurprd/collected", "employee_20260905011415678.txt"),
                move => AssertMove(move, "stukconcurprd/input", "TM1.csv", "stukconcurprd/archive", "TM1_20260905011415678.csv"));
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies the exact existing Synapse copy-pipeline parameter contract
        /// </summary>
        [Fact]
        public async Task Given_CopyStarting_When_StartingCopy_Should_ValidateSourceAndCallExistingPipeline()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Starting;

            SetupCurrentSource(move);

            _synapseClient
                .Setup(value => value.StartAsync(
                    "Blob_Archive_With_Delete",
                    It.Is<IReadOnlyDictionary<string, object?>>(parameters => CopyParametersMatch(parameters, move)),
                    default))
                .ReturnsAsync("copy-run");

            var result = await CreateService().StartCopyAsync(CorrelationId, move);

            Assert.Equal(WorkdayConcurFileMoveStatus.InProgress, result.CopyStatus);
            Assert.Equal("copy-run", result.CopySynapseRunId);
            Assert.Equal(Now, result.CopyStartedOn);
            _blobClient.VerifyAll();
            _synapseClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that a changed source cannot be copied using a stale checkpoint
        /// </summary>
        [Fact]
        public async Task Given_SourceIdentityChanged_When_StartingCopy_Should_StopBeforeSynapse()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Starting;

            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "output/employee.txt", default))
                .ReturnsAsync(CreateFile("stukconcurprd/output/employee.txt", 101, "replacement-etag"));

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().StartCopyAsync(CorrelationId, move));

            Assert.Contains("changed after it was selected", exception.Message);
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies recovery when copy and delete completed before their final checkpoint was saved
        /// </summary>
        [Fact]
        public async Task Given_SourceMissingAndCopiedFileExists_When_RestartingCopy_Should_ReconcileWithoutSynapse()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Starting;

            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "output/employee.txt", default))
                .ReturnsAsync((WorkdayConcurFileIdentity?)null);

            var copied = CreateFile("stukconcurprd/collected/employee_20260905011415678.txt", 100, "copied-etag");
            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "collected/employee_20260905011415678.txt", default))
                .ReturnsAsync(copied);

            var result = await CreateService().StartCopyAsync(CorrelationId, move);

            Assert.Equal(WorkdayConcurFileMoveStatus.Succeeded, result.CopyStatus);
            Assert.Same(copied, result.DestinationFile);
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that a successful Synapse copy is accepted only when the destination length matches
        /// </summary>
        [Fact]
        public async Task Given_SuccessfulCopy_When_Completing_Should_ValidateDestination()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.CopySynapseRunId = "copy-run";

            _synapseClient
                .Setup(value => value.WaitForCompletionAsync("copy-run", default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = "copy-run", Status = "Succeeded" });

            var copied = CreateFile("stukconcurprd/collected/employee_20260905011415678.txt", 100, "copied-etag");
            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "collected/employee_20260905011415678.txt", default))
                .ReturnsAsync(copied);

            var result = await CreateService().CompleteCopyAsync(move);

            Assert.Equal(WorkdayConcurFileMoveStatus.Succeeded, result.CopyStatus);
            Assert.Same(copied, result.DestinationFile);
            Assert.Null(result.FailureMessage);
            _synapseClient.VerifyAll();
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that a destination mismatch prevents source deletion
        /// </summary>
        [Fact]
        public async Task Given_CopiedLengthMismatch_When_CompletingCopy_Should_RecordValidationFailure()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.CopySynapseRunId = "copy-run";

            _synapseClient
                .Setup(value => value.WaitForCompletionAsync("copy-run", default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = "copy-run", Status = "Succeeded" });

            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "collected/employee_20260905011415678.txt", default))
                .ReturnsAsync(CreateFile("stukconcurprd/collected/employee_20260905011415678.txt", 99, "copied-etag"));

            var result = await CreateService().CompleteCopyAsync(move);

            Assert.Equal(WorkdayConcurFileMoveStatus.ValidationFailed, result.CopyStatus);
            Assert.Null(result.DestinationFile);
            Assert.Contains("does not match", result.FailureMessage);
        }

        /// <summary>
        /// Verifies that source deletion is allowed only after the copied Blob is validated
        /// </summary>
        [Fact]
        public async Task Given_CopyNotValidated_When_StartingDelete_Should_StopBeforeSynapse()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
            move.DeleteStatus = WorkdayConcurFileMoveStatus.Starting;

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().StartDeleteAsync(CorrelationId, move));

            Assert.Contains("copied Blob has been validated", exception.Message);
            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies the exact existing Synapse delete-pipeline parameter contract
        /// </summary>
        [Fact]
        public async Task Given_ValidatedCopy_When_StartingDelete_Should_RevalidateSourceAndCallExistingPipeline()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
            move.DestinationFile = CreateFile("stukconcurprd/collected/employee_20260905011415678.txt", 100, "copied-etag");
            move.DeleteStatus = WorkdayConcurFileMoveStatus.Starting;

            SetupCurrentSource(move);

            _synapseClient
                .Setup(value => value.StartAsync(
                    "Blob_Delete",
                    It.Is<IReadOnlyDictionary<string, object?>>(parameters => DeleteParametersMatch(parameters, move)),
                    default))
                .ReturnsAsync("delete-run");

            var result = await CreateService().StartDeleteAsync(CorrelationId, move);

            Assert.Equal(WorkdayConcurFileMoveStatus.InProgress, result.DeleteStatus);
            Assert.Equal("delete-run", result.DeleteSynapseRunId);
            Assert.Equal(Now, result.DeleteStartedOn);
            _blobClient.VerifyAll();
            _synapseClient.VerifyAll();
        }

        /// <summary>
        /// Verifies recovery when a source was deleted before its Synapse run identifier was checkpointed
        /// </summary>
        [Fact]
        public async Task Given_SourceAlreadyAbsent_When_RestartingDelete_Should_ReconcileWithoutSynapse()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
            move.DestinationFile = CreateFile("stukconcurprd/collected/employee_20260905011415678.txt", 100, "copied-etag");
            move.DeleteStatus = WorkdayConcurFileMoveStatus.Starting;

            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "output/employee.txt", default))
                .ReturnsAsync((WorkdayConcurFileIdentity?)null);

            var result = await CreateService().StartDeleteAsync(CorrelationId, move);

            Assert.Equal(WorkdayConcurFileMoveStatus.Succeeded, result.DeleteStatus);
            Assert.Null(result.DeleteSynapseRunId);
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that source absence is authoritative when a repeated delete run reports failure
        /// </summary>
        [Fact]
        public async Task Given_DeletePipelineFailedButSourceIsAbsent_When_Completing_Should_TreatDeleteAsSucceeded()
        {
            var move = CreateMove();
            move.DeleteStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.DeleteSynapseRunId = "delete-run";

            _synapseClient
                .Setup(value => value.WaitForCompletionAsync("delete-run", default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = "delete-run", Status = "Failed", Message = "Not found" });

            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "output/employee.txt", default))
                .ReturnsAsync((WorkdayConcurFileIdentity?)null);

            var result = await CreateService().CompleteDeleteAsync(move);

            Assert.Equal(WorkdayConcurFileMoveStatus.Succeeded, result.DeleteStatus);
            Assert.Null(result.FailureMessage);
        }

        /// <summary>
        /// Verifies that Synapse success is rejected if the source remains present
        /// </summary>
        [Fact]
        public async Task Given_DeleteReportedSuccessButSourceRemains_When_Completing_Should_RecordValidationFailure()
        {
            var move = CreateMove();
            move.DeleteStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.DeleteSynapseRunId = "delete-run";

            _synapseClient
                .Setup(value => value.WaitForCompletionAsync("delete-run", default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = "delete-run", Status = "Succeeded" });

            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "output/employee.txt", default))
                .ReturnsAsync(move.SourceFile);

            var result = await CreateService().CompleteDeleteAsync(move);

            Assert.Equal(WorkdayConcurFileMoveStatus.ValidationFailed, result.DeleteStatus);
            Assert.Contains("still exists", result.FailureMessage);
        }

        /// <summary>
        /// Verifies an empty delivered output set cannot create a move plan
        /// </summary>
        [Fact]
        public async Task Given_NoDeliveredOutputs_When_Preparing_Should_RejectMovePlan()
        {
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().PrepareAsync([]));

            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies copy cannot start or complete from an unpersisted state
        /// </summary>
        [Fact]
        public async Task Given_InvalidCopyState_When_Processing_Should_RejectBeforeSynapse()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Pending;

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().StartCopyAsync(CorrelationId, move));
            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().CompleteCopyAsync(move));

            _synapseClient.VerifyNoOtherCalls();
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies copy restart fails when neither source nor the intended destination exists
        /// </summary>
        [Fact]
        public async Task Given_SourceAndDestinationMissing_When_RestartingCopy_Should_RejectMissingFile()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Starting;

            _blobClient.SetupSequence(value => value.GetFileAsync(It.IsAny<Uri>(), ContainerName, It.IsAny<string>(), default))
                .ReturnsAsync((WorkdayConcurFileIdentity?)null)
                .ReturnsAsync((WorkdayConcurFileIdentity?)null);

            await Assert.ThrowsAsync<FileNotFoundException>(() => CreateService().StartCopyAsync(CorrelationId, move));

            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies failed and cancelled copy runs retain their terminal state without validating a destination
        /// </summary>
        [Theory]
        [InlineData("Failed", WorkdayConcurFileMoveStatus.Failed)]
        [InlineData("Cancelled", WorkdayConcurFileMoveStatus.Cancelled)]
        public async Task Given_UnsuccessfulCopyRun_When_Completing_Should_RecordTerminalState(string status, WorkdayConcurFileMoveStatus expected)
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.CopySynapseRunId = "copy-run";

            _synapseClient.Setup(value => value.WaitForCompletionAsync("copy-run", default)).ReturnsAsync(new SynapsePipelineRun { Status = status });

            var result = await CreateService().CompleteCopyAsync(move);

            Assert.Equal(expected, result.CopyStatus);
            Assert.Contains(status, result.FailureMessage);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies delete cannot start or complete from an unpersisted state
        /// </summary>
        [Fact]
        public async Task Given_InvalidDeleteState_When_Processing_Should_RejectBeforeSynapse()
        {
            var move = CreateMove();
            move.DeleteStatus = WorkdayConcurFileMoveStatus.Pending;

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().StartDeleteAsync(CorrelationId, move));
            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().CompleteDeleteAsync(move));

            _synapseClient.VerifyNoOtherCalls();
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies an unsuccessful delete remains failed while its source still exists
        /// </summary>
        [Theory]
        [InlineData("Failed", WorkdayConcurFileMoveStatus.Failed)]
        [InlineData("Cancelled", WorkdayConcurFileMoveStatus.Cancelled)]
        public async Task Given_UnsuccessfulDeleteAndExistingSource_When_Completing_Should_RecordTerminalState(string status, WorkdayConcurFileMoveStatus expected)
        {
            var move = CreateMove();
            move.DeleteStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.DeleteSynapseRunId = "delete-run";

            _synapseClient.Setup(value => value.WaitForCompletionAsync("delete-run", default)).ReturnsAsync(new SynapsePipelineRun { Status = status });
            _blobClient.Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "output/employee.txt", default)).ReturnsAsync(move.SourceFile);

            var result = await CreateService().CompleteDeleteAsync(move);

            Assert.Equal(expected, result.DeleteStatus);
            Assert.Contains(status, result.FailureMessage);
        }

        /// <summary>
        /// Verifies move plans cannot include files outside the configured Concur container
        /// </summary>
        [Fact]
        public async Task Given_OutputOutsideContainer_When_Preparing_Should_RejectMovePlan()
        {
            _blobClient
                .Setup(value => value.ListFilesAsync(new Uri(BlobEndpoint), ContainerName, "input", default))
                .ReturnsAsync(Array.Empty<WorkdayConcurFileIdentity>());

            var outsideContainer = CreateFile("other/output/employee.txt", 100, "etag");
            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().PrepareAsync([outsideContainer]));

            _blobClient.Verify(value => value.ListFilesAsync(new Uri(BlobEndpoint), ContainerName, "input", default), Times.Once);
        }

        /// <summary>
        /// Verifies the Blob endpoint and container are mandatory before a move plan is created
        /// </summary>
        [Theory]
        [InlineData("http://storage.blob.core.windows.net", ContainerName)]
        [InlineData("", ContainerName)]
        public async Task Given_InvalidOptions_When_Preparing_Should_RejectConfiguration(string endpoint, string container)
        {
            var service = CreateService(new WorkdayConcurOptions
            {
                ConcurBlobServiceEndpoint = endpoint,
                ConcurBlobContainerName = container
            });

            await Assert.ThrowsAsync<InvalidOperationException>(() => service.PrepareAsync([CreateFile("stukconcurprd/output/employee.txt", 100, "etag")]));

            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies a Blob container is required before a move plan is created
        /// </summary>
        [Fact]
        public async Task Given_MissingContainer_When_Preparing_Should_RejectConfiguration()
        {
            var service = CreateService(new WorkdayConcurOptions
            {
                ConcurBlobServiceEndpoint = BlobEndpoint,
                ConcurBlobContainerName = string.Empty
            });

            await Assert.ThrowsAsync<ArgumentException>(() => service.PrepareAsync([CreateFile("stukconcurprd/output/employee.txt", 100, "etag")]));

            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies unsupported Synapse states cannot become terminal copy state
        /// </summary>
        [Fact]
        public async Task Given_UnsupportedCopyStatus_When_Completing_Should_RejectStatus()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.InProgress;
            move.CopySynapseRunId = "copy-run";

            _synapseClient.Setup(value => value.WaitForCompletionAsync("copy-run", default)).ReturnsAsync(new SynapsePipelineRun { Status = "Queued" });

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().CompleteCopyAsync(move));

            Assert.Contains("Queued", exception.Message);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies delete requires a persisted Starting intent even after copy validation
        /// </summary>
        [Fact]
        public async Task Given_DeleteNotMarkedStarting_When_StartingDelete_Should_RejectBeforeSynapse()
        {
            var move = CreateMove();
            move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
            move.DestinationFile = CreateFile("stukconcurprd/collected/employee.txt", 100, "etag");
            move.DeleteStatus = WorkdayConcurFileMoveStatus.Pending;

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService().StartDeleteAsync(CorrelationId, move));

            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies source files require a filename extension for deterministic archive naming
        /// </summary>
        [Theory]
        [InlineData("stukconcurprd/output/employee")]
        [InlineData("stukconcurprd/output/.txt")]
        public async Task Given_InvalidSourceFilename_When_Preparing_Should_RejectMovePlan(string path)
        {
            _blobClient.Setup(value => value.ListFilesAsync(new Uri(BlobEndpoint), ContainerName, "input", default)).ReturnsAsync(Array.Empty<WorkdayConcurFileIdentity>());

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().PrepareAsync([CreateFile(path, 100, "etag")]));
        }

        /// <summary>
        /// Verifies move execution rejects empty source identity evidence and malformed persisted locations
        /// </summary>
        [Fact]
        public async Task Given_InvalidPersistedMove_When_StartingCopy_Should_RejectBeforeSynapse()
        {
            var empty = CreateMove();
            empty.SourceFile.ContentLength = 0;
            empty.CopyStatus = WorkdayConcurFileMoveStatus.Starting;

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().StartCopyAsync(CorrelationId, empty));

            var invalidLocation = CreateMove();
            invalidLocation.SourcePath = "output";
            invalidLocation.CopyStatus = WorkdayConcurFileMoveStatus.Starting;

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().StartCopyAsync(CorrelationId, invalidLocation));

            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies selected Blob paths contain container, folder and filename segments
        /// </summary>
        [Theory]
        [InlineData("stukconcurprd/employee.txt")]
        [InlineData("/employee.txt")]
        [InlineData("stukconcurprd/output/")]
        public async Task Given_MalformedBlobPath_When_Preparing_Should_RejectMovePlan(string path)
        {
            _blobClient.Setup(value => value.ListFilesAsync(new Uri(BlobEndpoint), ContainerName, "input", default)).ReturnsAsync(Array.Empty<WorkdayConcurFileIdentity>());

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService().PrepareAsync([CreateFile(path, 100, "etag")]));
        }

        private WorkdayConcurHousekeepingService CreateService()
        {
            return CreateService(new WorkdayConcurOptions
            {
                SynapseWorkspaceName = "synw-file-transfer",
                ConcurBlobServiceEndpoint = BlobEndpoint,
                ConcurBlobContainerName = ContainerName
            });
        }

        private WorkdayConcurHousekeepingService CreateService(WorkdayConcurOptions options)
        {
            return new WorkdayConcurHousekeepingService(_synapseClient.Object, _blobClient.Object, Options.Create(options), new FakeTimeProvider(Now));
        }

        private static WorkdayConcurFileMove CreateMove()
        {
            return new WorkdayConcurFileMove
            {
                SourceFile = CreateFile("stukconcurprd/output/employee.txt", 100, "source-etag"),
                SourcePath = "stukconcurprd/output",
                SourceFileName = "employee.txt",
                DestinationPath = "stukconcurprd/collected",
                DestinationFileName = "employee_20260905011415678.txt"
            };
        }

        private void SetupCurrentSource(WorkdayConcurFileMove move)
        {
            _blobClient
                .Setup(value => value.GetFileAsync(new Uri(BlobEndpoint), ContainerName, "output/employee.txt", default))
                .ReturnsAsync(move.SourceFile);
        }

        private static WorkdayConcurFileIdentity CreateFile(string path, long length, string eTag)
        {
            return new WorkdayConcurFileIdentity
            {
                Path = path,
                ContentLength = length,
                ETag = eTag,
                LastModifiedOn = Now
            };
        }

        private static void AssertMove(WorkdayConcurFileMove move, string sourcePath, string sourceName, string destinationPath, string destinationName)
        {
            Assert.Equal(sourcePath, move.SourcePath);
            Assert.Equal(sourceName, move.SourceFileName);
            Assert.Equal(destinationPath, move.DestinationPath);
            Assert.Equal(destinationName, move.DestinationFileName);
            Assert.Equal(WorkdayConcurFileMoveStatus.Pending, move.CopyStatus);
            Assert.Equal(WorkdayConcurFileMoveStatus.Pending, move.DeleteStatus);
        }

        private static bool CopyParametersMatch(IReadOnlyDictionary<string, object?> parameters, WorkdayConcurFileMove move)
        {
            return parameters.Count == 11
                && Equals(parameters["SourcePath"], move.SourcePath)
                && Equals(parameters["FileName"], move.SourceFileName)
                && Equals(parameters["DestinationPath"], move.DestinationPath)
                && Equals(parameters["SourceStorageAccountEndPoint"], BlobEndpoint)
                && Equals(parameters["IsErrorArchiveFileNameChange"], true)
                && Equals(parameters["ErrorArchiveFileName"], move.DestinationFileName)
                && Equals(parameters["TriggeredByFnApp"], "stuk.tradeaccountservice")
                && Equals(parameters["TriggeredBySchedulerName"], "WorkdayConcurTimerFunction")
                && Equals(parameters["Id"], CorrelationId.ToString("D"))
                && Equals(parameters["CorrelationID"], CorrelationId.ToString("D"))
                && Equals(parameters["RetryCount"], "0");
        }

        private static bool DeleteParametersMatch(IReadOnlyDictionary<string, object?> parameters, WorkdayConcurFileMove move)
        {
            return parameters.Count == 7
                && Equals(parameters["SourcePath"], move.SourcePath)
                && Equals(parameters["FileName"], move.SourceFileName)
                && Equals(parameters["SourceStorageAccountEndPoint"], BlobEndpoint)
                && Equals(parameters["TriggeredByFnApp"], "stuk.tradeaccountservice")
                && Equals(parameters["TriggeredBySchedulerName"], "WorkdayConcurTimerFunction")
                && Equals(parameters["Id"], CorrelationId.ToString("D"))
                && Equals(parameters["CorrelationID"], CorrelationId.ToString("D"));
        }
    }
}
