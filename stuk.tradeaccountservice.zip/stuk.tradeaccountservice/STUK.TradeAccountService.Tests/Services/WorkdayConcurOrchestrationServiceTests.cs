using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using System.Text.Json;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests Workday-to-Concur run acquisition and overlap behaviour
    /// </summary>
    public class WorkdayConcurOrchestrationServiceTests
    {
        private static readonly DateTimeOffset Now = new(2026, 9, 4, 8, 30, 0, TimeSpan.Zero);
        private static readonly Guid CorrelationId = new("10000000-0000-0000-0000-000000000001");
        private static readonly Guid RunId = new("10000000-0000-0000-0000-000000000002");
        private static readonly Guid ClaimToken = new("10000000-0000-0000-0000-000000000003");

        private readonly Mock<ILogger<WorkdayConcurOrchestrationService>> _logger = new();
        private readonly Mock<IWorkdayConcurStateService> _stateService = new();
        private readonly Mock<IWorkdayConcurTm1Service> _tm1Service = new();
        private readonly Mock<IWorkdayWorkersClient> _workersClient = new();
        private readonly Mock<IWorkdayConcurCsvService> _csvService = new();
        private readonly Mock<IWorkdayConcurTransformationService> _transformationService = new();
        private readonly Mock<IWorkdayConcurDeliveryService> _deliveryService = new();
        private readonly Mock<IWorkdayConcurHousekeepingService> _housekeepingService = new();
        private readonly FakeTimeProvider _timeProvider = new(Now);

        /// <summary>
        /// Verifies that the disabled feature does not acquire durable run state
        /// </summary>
        [Fact]
        public async Task Given_FeatureDisabled_When_Run_Should_NotAcquireRun()
        {
            var service = CreateService(enabled: false);

            await service.RunAsync(CorrelationId.ToString());

            _stateService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that a new run completes every stage and commits its frozen Workday window
        /// </summary>
        [Fact]
        public async Task Given_NewRun_When_Running_Should_CompleteAndCommitRun()
        {
            var run = new WorkdayConcurRun
            {
                RunId = RunId,
                CorrelationId = CorrelationId,
                ExtractFrom = Now.AddDays(-1),
                ExtractThrough = Now,
                CurrentStage = WorkdayConcurRunStage.Pending.ToString(),
                ClaimToken = ClaimToken
            };
            _stateService
                .Setup(x => x.CreateOrResumeRunAsync(CorrelationId, CorrelationId.ToString(), Now, 300, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(run);
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Pending,
                    WorkdayConcurRunStage.CollectingInputs,
                    null, null, null, null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.CollectingInputs,
                    WorkdayConcurRunStage.CollectingInputs,
                    It.IsAny<string>(),
                    "synapse-run", null, null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            var started = CreateTm1Checkpoint("InProgress");

            var completed = CreateTm1Checkpoint("Succeeded");
            completed.File = new WorkdayConcurFileIdentity
            {
                Path = "input/TM1.csv",
                ContentLength = 10,
                ETag = "etag",
                LastModifiedOn = Now
            };
            _tm1Service.Setup(x => x.StartAsync(CorrelationId, It.IsAny<CancellationToken>())).ReturnsAsync(started);

            _tm1Service.Setup(x => x.CompleteAsync(started, It.IsAny<CancellationToken>())).ReturnsAsync(completed);

            SetupSuccessfulWorkdayInput();
            SetupSuccessfulTransformation();

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _stateService.VerifyAll();
            _tm1Service.VerifyAll();
            _workersClient.VerifyAll();
            _csvService.VerifyAll();
        }

        /// <summary>
        /// Verifies that restart continues an in-progress Synapse run rather than starting another pickup
        /// </summary>
        [Fact]
        public async Task Given_InProgressTm1Checkpoint_When_Resuming_Should_WaitForExistingSynapseRun()
        {
            var checkpoint = CreateTm1Checkpoint("InProgress");

            var inputCheckpoint = new WorkdayConcurRunCheckpoint { Tm1 = checkpoint };

            var run = CreateRun(WorkdayConcurRunStage.CollectingInputs, JsonSerializer.Serialize(inputCheckpoint));
            run.Tm1SynapseRunId = checkpoint.SynapseRunId;

            SetupRunAcquisition(run);

            var completed = CreateTm1Checkpoint("Succeeded");
            completed.File = new WorkdayConcurFileIdentity
            {
                Path = "input/TM1.csv",
                ContentLength = 10,
                ETag = "etag",
                LastModifiedOn = Now
            };
            _tm1Service.Setup(x => x.CompleteAsync(It.IsAny<WorkdayConcurTm1Checkpoint>(), It.IsAny<CancellationToken>())).ReturnsAsync(completed);

            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId, ClaimToken,
                    WorkdayConcurRunStage.CollectingInputs,
                    WorkdayConcurRunStage.CollectingInputs,
                    It.IsAny<string>(), "synapse-run", null, null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            SetupSuccessfulWorkdayInput();
            SetupSuccessfulTransformation();

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _tm1Service.Verify(x => x.StartAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()), Times.Never);
            _tm1Service.VerifyAll();
            _stateService.VerifyAll();
            _workersClient.VerifyAll();
            _csvService.VerifyAll();
        }

        /// <summary>
        /// Verifies that no changed Workday employees closes the run without creating a file or advancing the watermark
        /// </summary>
        [Fact]
        public async Task Given_NoChangedWorkers_When_Running_Should_CloseNoDataRun()
        {
            var checkpoint = CreateCompletedInputCheckpoint();

            var run = CreateRun(WorkdayConcurRunStage.CollectingInputs, JsonSerializer.Serialize(checkpoint));

            SetupRunAcquisition(run);

            _workersClient.Setup(x => x.GetWorkersAsync(Now.AddDays(-1), Now, It.IsAny<CancellationToken>())).ReturnsAsync(Array.Empty<WorkdayWorker>());

            _stateService.Setup(x => x.CompleteNoDataRunAsync(RunId, ClaimToken, Now, It.IsAny<CancellationToken>())).Returns(Task.CompletedTask);

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _csvService.VerifyNoOtherCalls();
            _stateService.Verify(x => x.ReleaseLeaseAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _workersClient.VerifyAll();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a resumed run does not retrieve or overwrite an employee file already checkpointed successfully
        /// </summary>
        [Fact]
        public async Task Given_StagedEmployeeCheckpoint_When_Resuming_Should_NotWriteEmployeeFileAgain()
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = new WorkdayConcurFileIdentity
            {
                Path = "stukconcurprd/input/SG_CONCUR_DAILY.csv",
                ContentLength = 100,
                ETag = "employee-etag",
                LastModifiedOn = Now
            };
            checkpoint.WorkdayEmployeeCount = 1;

            var run = CreateRun(WorkdayConcurRunStage.CollectingInputs, JsonSerializer.Serialize(checkpoint));

            SetupRunAcquisition(run);

            SetupSuccessfulTransformation();

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _workersClient.VerifyNoOtherCalls();
            _csvService.VerifyNoOtherCalls();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a terminal pickup failure is checkpointed and leaves the run recoverable
        /// </summary>
        [Fact]
        public async Task Given_FailedTm1Pipeline_When_Running_Should_CheckpointAndFailRun()
        {
            var run = CreateRun(WorkdayConcurRunStage.CollectingInputs);
            SetupRunAcquisition(run);

            var started = CreateTm1Checkpoint("InProgress");

            var failed = CreateTm1Checkpoint("Failed");
            failed.FailureMessage = "Pipeline failed";
            _tm1Service.Setup(x => x.StartAsync(CorrelationId, It.IsAny<CancellationToken>())).ReturnsAsync(started);
            _tm1Service.Setup(x => x.CompleteAsync(started, It.IsAny<CancellationToken>())).ReturnsAsync(failed);
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId, ClaimToken,
                    WorkdayConcurRunStage.CollectingInputs,
                    WorkdayConcurRunStage.CollectingInputs,
                    It.IsAny<string>(), "synapse-run", null, null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _stateService
                .Setup(x => x.FailRunAsync(RunId, ClaimToken, "Tm1Pickup", "Pipeline failed", Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString()));

            Assert.Equal("Pipeline failed", exception.Message);
            _stateService.VerifyAll();
            _tm1Service.VerifyAll();
        }

        /// <summary>
        /// Verifies that restart observes the persisted Synapse transformation instead of starting a duplicate
        /// </summary>
        [Fact]
        public async Task Given_InProgressTransformation_When_Resuming_Should_WaitForExistingSynapseRun()
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = CreateEmployeeFile();
            checkpoint.WorkdayEmployeeCount = 1;
            checkpoint.Transformation = CreateTransformationCheckpoint("InProgress");

            var run = CreateRun(WorkdayConcurRunStage.Transforming, JsonSerializer.Serialize(checkpoint));
            run.Tm1SynapseRunId = "synapse-run";
            run.TransformSynapseRunId = "transform-run";

            SetupRunAcquisition(run);
            SetupCompletedTransformation(checkpoint.Transformation);

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _transformationService.Verify(x => x.StartAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()), Times.Never);
            _transformationService.VerifyAll();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a completed transformation checkpoint advances without running Synapse again
        /// </summary>
        [Fact]
        public async Task Given_CompletedTransformationCheckpoint_When_Resuming_Should_AdvanceToDelivery()
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = CreateEmployeeFile();
            checkpoint.WorkdayEmployeeCount = 1;
            checkpoint.Transformation = CreateTransformationCheckpoint("Succeeded", includeOutput: true);

            var run = CreateRun(WorkdayConcurRunStage.Transforming, JsonSerializer.Serialize(checkpoint));
            run.Tm1SynapseRunId = "synapse-run";
            run.TransformSynapseRunId = "transform-run";

            SetupRunAcquisition(run);

            SetupSuccessfulDelivery();

            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Transforming,
                    WorkdayConcurRunStage.Delivering,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _transformationService.VerifyNoOtherCalls();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that transformation failure is checkpointed against the Concur transformation stage
        /// </summary>
        [Fact]
        public async Task Given_FailedTransformation_When_Running_Should_CheckpointAndFailRun()
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = CreateEmployeeFile();
            checkpoint.WorkdayEmployeeCount = 1;

            var run = CreateRun(WorkdayConcurRunStage.CollectingInputs, JsonSerializer.Serialize(checkpoint));

            SetupRunAcquisition(run);

            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.CollectingInputs,
                    WorkdayConcurRunStage.Transforming,
                    It.IsAny<string>(),
                    "synapse-run", null, null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Transforming,
                    WorkdayConcurRunStage.Transforming,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _stateService
                .Setup(x => x.FailRunAsync(RunId, ClaimToken, "ConcurTransformation", "Child pipeline failed", Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var started = CreateTransformationCheckpoint("InProgress");
            var failed = CreateTransformationCheckpoint("Failed");
            failed.FailureMessage = "Child pipeline failed";

            _transformationService.Setup(x => x.StartAsync(CorrelationId, It.IsAny<CancellationToken>())).ReturnsAsync(started);

            _transformationService.Setup(x => x.CompleteAsync(started, It.IsAny<CancellationToken>())).ReturnsAsync(failed);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString()));

            Assert.Equal("Child pipeline failed", exception.Message);
            _transformationService.VerifyAll();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that restart observes the persisted Synapse delivery instead of sending files again
        /// </summary>
        [Fact]
        public async Task Given_InProgressDelivery_When_Resuming_Should_WaitForExistingSynapseRun()
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = CreateEmployeeFile();
            checkpoint.WorkdayEmployeeCount = 1;
            checkpoint.Transformation = CreateTransformationCheckpoint("Succeeded", includeOutput: true);
            checkpoint.Delivery = CreateDeliveryCheckpoint(WorkdayConcurDeliveryStatus.InProgress);

            var run = CreateRun(WorkdayConcurRunStage.Delivering, JsonSerializer.Serialize(checkpoint));
            run.Tm1SynapseRunId = "synapse-run";
            run.TransformSynapseRunId = "transform-run";
            run.DeliverySynapseRunId = "delivery-run";

            SetupRunAcquisition(run);

            var completed = CreateDeliveryCheckpoint(WorkdayConcurDeliveryStatus.Succeeded);
            _deliveryService.Setup(x => x.CompleteAsync(It.IsAny<WorkdayConcurDeliveryCheckpoint>(), It.IsAny<CancellationToken>())).ReturnsAsync(completed);

            SetupDeliveryStateUpdates();

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _deliveryService.Verify(x => x.PrepareAsync(It.IsAny<Guid>(), It.IsAny<IReadOnlyCollection<WorkdayConcurFileIdentity>>(), It.IsAny<CancellationToken>()), Times.Never);
            _deliveryService.VerifyAll();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a failed or ambiguous delivery cannot automatically resend previously transferred files
        /// </summary>
        [Theory]
        [InlineData(WorkdayConcurDeliveryStatus.Starting)]
        [InlineData(WorkdayConcurDeliveryStatus.Failed)]
        public async Task Given_AmbiguousDeliveryCheckpoint_When_Resuming_Should_RequireReconciliation(WorkdayConcurDeliveryStatus status)
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = CreateEmployeeFile();
            checkpoint.WorkdayEmployeeCount = 1;
            checkpoint.Transformation = CreateTransformationCheckpoint("Succeeded", includeOutput: true);
            checkpoint.Delivery = CreateDeliveryCheckpoint(status);

            var run = CreateRun(WorkdayConcurRunStage.Delivering, JsonSerializer.Serialize(checkpoint));
            run.DeliverySynapseRunId = "delivery-run";

            SetupRunAcquisition(run);

            _stateService
                .Setup(x => x.FailRunAsync(
                    RunId,
                    ClaimToken,
                    "ConcurDelivery",
                    "A failed or ambiguous Concur delivery requires reconciliation before it can be retried",
                    Now,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString()));

            Assert.Equal("A failed or ambiguous Concur delivery requires reconciliation before it can be retried", exception.Message);
            _deliveryService.VerifyNoOtherCalls();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a successful persisted delivery advances without invoking delivery again
        /// </summary>
        [Fact]
        public async Task Given_SuccessfulDeliveryCheckpoint_When_Resuming_Should_AdvanceToMovingFiles()
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = CreateEmployeeFile();
            checkpoint.WorkdayEmployeeCount = 1;
            checkpoint.Transformation = CreateTransformationCheckpoint("Succeeded", includeOutput: true);
            checkpoint.Delivery = CreateDeliveryCheckpoint(WorkdayConcurDeliveryStatus.Succeeded);

            var run = CreateRun(WorkdayConcurRunStage.Delivering, JsonSerializer.Serialize(checkpoint));
            SetupRunAcquisition(run);

            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Delivering,
                    WorkdayConcurRunStage.MovingFiles,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            SetupSuccessfulHousekeeping();

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _deliveryService.VerifyNoOtherCalls();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that restart waits for the persisted copy and does not repeat completed file moves
        /// </summary>
        [Fact]
        public async Task Given_PartiallyCompletedHousekeeping_When_Resuming_Should_ContinueIncompleteOperationOnly()
        {
            var completedMove = CreateHousekeepingMove("complete.txt", WorkdayConcurFileMoveStatus.Succeeded, WorkdayConcurFileMoveStatus.Succeeded);
            completedMove.DestinationFile = CreateHousekeepingDestination(completedMove);

            var currentMove = CreateHousekeepingMove("current.txt", WorkdayConcurFileMoveStatus.InProgress, WorkdayConcurFileMoveStatus.Pending);
            currentMove.CopySynapseRunId = "copy-run";

            var checkpoint = CreateMovingFilesCheckpoint(completedMove, currentMove);
            var run = CreateRun(WorkdayConcurRunStage.MovingFiles, JsonSerializer.Serialize(checkpoint));
            run.HousekeepingSynapseRunId = "copy-run";
            SetupRunAcquisition(run);

            _housekeepingService
                .Setup(value => value.CompleteCopyAsync(It.Is<WorkdayConcurFileMove>(move => move.SourceFileName == "current.txt"), It.IsAny<CancellationToken>()))
                .ReturnsAsync((WorkdayConcurFileMove move, CancellationToken _) =>
                {
                    move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
                    move.DestinationFile = CreateHousekeepingDestination(move);
                    return move;
                });

            _housekeepingService
                .Setup(value => value.StartDeleteAsync(CorrelationId, It.Is<WorkdayConcurFileMove>(move => move.SourceFileName == "current.txt"), It.IsAny<CancellationToken>()))
                .ReturnsAsync((Guid _, WorkdayConcurFileMove move, CancellationToken _) =>
                {
                    move.DeleteStatus = WorkdayConcurFileMoveStatus.InProgress;
                    move.DeleteSynapseRunId = "delete-run";
                    return move;
                });

            _housekeepingService
                .Setup(value => value.CompleteDeleteAsync(It.Is<WorkdayConcurFileMove>(move => move.SourceFileName == "current.txt"), It.IsAny<CancellationToken>()))
                .ReturnsAsync((WorkdayConcurFileMove move, CancellationToken _) =>
                {
                    move.DeleteStatus = WorkdayConcurFileMoveStatus.Succeeded;
                    return move;
                });

            SetupHousekeepingStateUpdates();

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _housekeepingService.Verify(value => value.PrepareAsync(It.IsAny<IReadOnlyCollection<WorkdayConcurFileIdentity>>(), It.IsAny<CancellationToken>()), Times.Never);
            _housekeepingService.Verify(value => value.StartCopyAsync(It.IsAny<Guid>(), It.IsAny<WorkdayConcurFileMove>(), It.IsAny<CancellationToken>()), Times.Never);
            _housekeepingService.VerifyAll();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a failed copy withholds source deletion and watermark commit
        /// </summary>
        [Fact]
        public async Task Given_HousekeepingCopyFailure_When_Running_Should_FailWithoutDeletingOrCommitting()
        {
            var move = CreateHousekeepingMove("employee.txt", WorkdayConcurFileMoveStatus.Pending, WorkdayConcurFileMoveStatus.Pending);
            var housekeeping = new WorkdayConcurHousekeepingCheckpoint
            {
                BlobServiceEndpoint = "https://storage.blob.core.windows.net",
                Moves = new[] { move },
                Status = WorkdayConcurHousekeepingStatus.InProgress
            };
            var checkpoint = CreateMovingFilesCheckpoint();
            var run = CreateRun(WorkdayConcurRunStage.MovingFiles, JsonSerializer.Serialize(checkpoint));
            SetupRunAcquisition(run);

            _housekeepingService
                .Setup(value => value.PrepareAsync(It.IsAny<IReadOnlyCollection<WorkdayConcurFileIdentity>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(housekeeping);

            _housekeepingService
                .Setup(value => value.StartCopyAsync(CorrelationId, move, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() =>
                {
                    move.CopyStatus = WorkdayConcurFileMoveStatus.InProgress;
                    move.CopySynapseRunId = "copy-run";
                    return move;
                });

            _housekeepingService
                .Setup(value => value.CompleteCopyAsync(move, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() =>
                {
                    move.CopyStatus = WorkdayConcurFileMoveStatus.Failed;
                    move.FailureMessage = "Copy failed";
                    return move;
                });

            _stateService
                .Setup(value => value.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.MovingFiles,
                    WorkdayConcurRunStage.MovingFiles,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", It.IsAny<string?>(), Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            _stateService
                .Setup(value => value.FailRunAsync(RunId, ClaimToken, "ConcurHousekeeping", "Copy failed", Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString()));

            Assert.Equal("Copy failed", exception.Message);
            _housekeepingService.Verify(value => value.StartDeleteAsync(It.IsAny<Guid>(), It.IsAny<WorkdayConcurFileMove>(), It.IsAny<CancellationToken>()), Times.Never);
            _stateService.Verify(value => value.CommitRunAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a fully persisted housekeeping checkpoint commits without replaying external work
        /// </summary>
        [Fact]
        public async Task Given_CompletedHousekeeping_When_Resuming_Should_CommitWithoutRepeatingPipelines()
        {
            var move = CreateHousekeepingMove("employee.txt", WorkdayConcurFileMoveStatus.Succeeded, WorkdayConcurFileMoveStatus.Succeeded);
            move.DestinationFile = CreateHousekeepingDestination(move);

            var checkpoint = CreateMovingFilesCheckpoint(move);
            checkpoint.Housekeeping!.Status = WorkdayConcurHousekeepingStatus.Succeeded;
            checkpoint.Housekeeping.CompletedOn = Now;

            var run = CreateRun(WorkdayConcurRunStage.MovingFiles, JsonSerializer.Serialize(checkpoint));
            SetupRunAcquisition(run);
            SetupHousekeepingStateUpdates();

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _housekeepingService.VerifyNoOtherCalls();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that a persisted in-progress operation must match the run-level Synapse identifier
        /// </summary>
        [Fact]
        public async Task Given_HousekeepingRunIdMismatch_When_Resuming_Should_StopForReconciliation()
        {
            var move = CreateHousekeepingMove("employee.txt", WorkdayConcurFileMoveStatus.InProgress, WorkdayConcurFileMoveStatus.Pending);
            move.CopySynapseRunId = "checkpoint-run";

            var checkpoint = CreateMovingFilesCheckpoint(move);
            var run = CreateRun(WorkdayConcurRunStage.MovingFiles, JsonSerializer.Serialize(checkpoint));
            run.HousekeepingSynapseRunId = "database-run";
            SetupRunAcquisition(run);

            _stateService
                .Setup(value => value.FailRunAsync(
                    RunId,
                    ClaimToken,
                    "ConcurHousekeeping",
                    "The persisted housekeeping checkpoint does not match the run's Synapse identifier",
                    Now,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await Assert.ThrowsAsync<InvalidDataException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString()));

            _housekeepingService.VerifyNoOtherCalls();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that an invocation exits without changing state when another worker owns the run
        /// </summary>
        [Fact]
        public async Task Given_ActiveLease_When_Run_Should_NotReleaseAnotherWorkersLease()
        {
            _stateService
                .Setup(x => x.CreateOrResumeRunAsync(CorrelationId, CorrelationId.ToString(), Now, 300, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync((WorkdayConcurRun?)null);

            await CreateService(enabled: true).RunAsync(CorrelationId.ToString());

            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies a database result without its ownership token cannot process integration work
        /// </summary>
        [Fact]
        public async Task Given_RunWithoutClaimToken_When_Run_Should_RejectBeforeProcessing()
        {
            var run = CreateRun(WorkdayConcurRunStage.Pending);
            run.ClaimToken = null;
            SetupRunAcquisition(run);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString()));

            Assert.Contains("without a claim token", exception.Message);
            _tm1Service.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies corrupt persisted checkpoint JSON is recorded against the claimed run and cannot restart from scratch
        /// </summary>
        [Fact]
        public async Task Given_CorruptCheckpoint_When_Run_Should_FailClaimedRun()
        {
            var run = CreateRun(WorkdayConcurRunStage.CollectingInputs, "{");
            SetupRunAcquisition(run);

            _stateService
                .Setup(value => value.FailRunAsync(
                    RunId,
                    ClaimToken,
                    "Tm1Pickup",
                    It.IsAny<string>(),
                    Now,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await Assert.ThrowsAsync<JsonException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString()));

            _tm1Service.VerifyNoOtherCalls();
            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that an enabled invocation requires a database lease duration
        /// </summary>
        [Fact]
        public async Task Given_InvalidLeaseDuration_When_Run_Should_FailBeforeStateAccess()
        {
            var service = CreateService(enabled: true, leaseDurationSeconds: 0);

            await Assert.ThrowsAsync<InvalidOperationException>(() => service.RunAsync(CorrelationId.ToString()));

            _stateService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that the renewal interval must expire before the database lease
        /// </summary>
        [Fact]
        public async Task Given_InvalidLeaseRenewalInterval_When_Run_Should_FailBeforeStateAccess()
        {
            var service = CreateService(enabled: true, leaseDurationSeconds: 60, leaseRenewalIntervalSeconds: 60);

            await Assert.ThrowsAsync<InvalidOperationException>(() => service.RunAsync(CorrelationId.ToString()));

            _stateService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies a non-positive lease renewal interval is rejected independently of the lease duration
        /// </summary>
        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public async Task Given_NonPositiveLeaseRenewalInterval_When_Run_Should_FailBeforeStateAccess(int renewalIntervalSeconds)
        {
            var service = CreateService(enabled: true, leaseDurationSeconds: 300, leaseRenewalIntervalSeconds: renewalIntervalSeconds);

            await Assert.ThrowsAsync<InvalidOperationException>(() => service.RunAsync(CorrelationId.ToString()));

            _stateService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that an active run renews its database lease while external work remains in progress
        /// </summary>
        [Fact]
        public async Task Given_LongRunningStage_When_Running_Should_RenewLeaseUntilProcessingStops()
        {
            var checkpoint = CreateMovingFilesCheckpoint();
            var run = CreateRun(WorkdayConcurRunStage.MovingFiles, JsonSerializer.Serialize(checkpoint));
            SetupRunAcquisition(run);

            var prepareStarted = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var prepareCompletion = new TaskCompletionSource<WorkdayConcurHousekeepingCheckpoint>(TaskCreationOptions.RunContinuationsAsynchronously);
            var leaseRenewed = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

            _housekeepingService
                .Setup(value => value.PrepareAsync(It.IsAny<IReadOnlyCollection<WorkdayConcurFileIdentity>>(), It.IsAny<CancellationToken>()))
                .Callback(() => prepareStarted.SetResult())
                .Returns((IReadOnlyCollection<WorkdayConcurFileIdentity> _, CancellationToken token) => prepareCompletion.Task.WaitAsync(token));

            _stateService
                .Setup(value => value.RenewLeaseAsync(RunId, ClaimToken, 300, Now.AddSeconds(60), It.IsAny<CancellationToken>()))
                .Callback(() => leaseRenewed.SetResult())
                .Returns(Task.CompletedTask);

            using var cancellation = new CancellationTokenSource();
            var runTask = CreateService(enabled: true).RunAsync(CorrelationId.ToString(), cancellation.Token);

            await prepareStarted.Task.WaitAsync(TimeSpan.FromSeconds(2));
            _timeProvider.Advance(TimeSpan.FromSeconds(60));
            await leaseRenewed.Task.WaitAsync(TimeSpan.FromSeconds(2));
            await cancellation.CancelAsync();

            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => runTask);

            _stateService.VerifyAll();
        }

        /// <summary>
        /// Verifies that an enabled invocation requires a GUID correlation identifier
        /// </summary>
        [Fact]
        public async Task Given_InvalidCorrelationId_When_Run_Should_RejectInvocation()
        {
            var service = CreateService(enabled: true);

            await Assert.ThrowsAsync<ArgumentException>(() => service.RunAsync("invocation-id"));

            _stateService.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies that cancellation is honoured before processing starts
        /// </summary>
        [Fact]
        public async Task Given_CancelledInvocation_When_Run_Should_PropagateCancellation()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService(enabled: true).RunAsync(CorrelationId.ToString(), token));

            _stateService.VerifyNoOtherCalls();
        }

        private WorkdayConcurOrchestrationService CreateService(bool enabled, int leaseDurationSeconds = 300, int leaseRenewalIntervalSeconds = 60)
        {
            return new WorkdayConcurOrchestrationService(
                _logger.Object,
                Options.Create(new WorkdayConcurOptions
                {
                    Enabled = enabled,
                    LeaseDurationSeconds = leaseDurationSeconds,
                    LeaseRenewalIntervalSeconds = leaseRenewalIntervalSeconds
                }),
                _stateService.Object,
                _tm1Service.Object,
                _workersClient.Object,
                _csvService.Object,
                _transformationService.Object,
                _deliveryService.Object,
                _housekeepingService.Object,
                _timeProvider);
        }

        private void SetupRunAcquisition(WorkdayConcurRun run)
        {
            _stateService
                .Setup(x => x.CreateOrResumeRunAsync(CorrelationId, CorrelationId.ToString(), Now, 300, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(run);
        }

        private static WorkdayConcurRun CreateRun(WorkdayConcurRunStage stage, string? fileStateJson = null)
        {
            return new WorkdayConcurRun
            {
                RunId = RunId,
                CorrelationId = CorrelationId,
                ExtractFrom = Now.AddDays(-1),
                ExtractThrough = Now,
                CurrentStage = stage.ToString(),
                FileStateJson = fileStateJson,
                ClaimToken = ClaimToken
            };
        }

        private static WorkdayConcurTm1Checkpoint CreateTm1Checkpoint(string status)
        {
            return new WorkdayConcurTm1Checkpoint
            {
                SynapseRunId = "synapse-run",
                StartedOn = Now,
                BlobServiceEndpoint = "https://storage.blob.core.windows.net",
                DestinationContainer = "input",
                DestinationBlobName = "TM1.csv",
                Status = status
            };
        }

        private static WorkdayConcurRunCheckpoint CreateCompletedInputCheckpoint()
        {
            var tm1 = CreateTm1Checkpoint("Succeeded");
            tm1.File = new WorkdayConcurFileIdentity
            {
                Path = "input/TM1.csv",
                ContentLength = 10,
                ETag = "tm1-etag",
                LastModifiedOn = Now
            };

            return new WorkdayConcurRunCheckpoint { Tm1 = tm1 };
        }

        private static WorkdayConcurFileIdentity CreateEmployeeFile()
        {
            return new WorkdayConcurFileIdentity
            {
                Path = "stukconcurprd/input/SG_CONCUR_DAILY.csv",
                ContentLength = 100,
                ETag = "employee-etag",
                LastModifiedOn = Now
            };
        }

        private static WorkdayConcurTransformationCheckpoint CreateTransformationCheckpoint(string status, bool includeOutput = false)
        {
            return new WorkdayConcurTransformationCheckpoint
            {
                SynapseRunId = "transform-run",
                StartedOn = Now,
                Status = status,
                OutputFiles = includeOutput
                    ? new[]
                    {
                        new WorkdayConcurFileIdentity
                        {
                            Path = "stukconcurprd/output/employee.txt",
                            ContentLength = 100,
                            ETag = "output-etag",
                            LastModifiedOn = Now
                        }
                    }
                    : Array.Empty<WorkdayConcurFileIdentity>()
            };
        }

        private static WorkdayConcurDeliveryCheckpoint CreateDeliveryCheckpoint(WorkdayConcurDeliveryStatus status)
        {
            return new WorkdayConcurDeliveryCheckpoint
            {
                SynapseRunId = "delivery-run",
                StartedOn = Now,
                BlobServiceEndpoint = "https://storage.blob.core.windows.net",
                StagingContainer = "erp3data",
                StagingFolderPath = "workday-concur/delivery/10000000000000000000000000000001",
                StagedFiles = new[]
                {
                    new WorkdayConcurFileIdentity
                    {
                        Path = "erp3data/workday-concur/delivery/10000000000000000000000000000001/employee.txt.pgp",
                        ContentLength = 200,
                        ETag = "encrypted-etag",
                        LastModifiedOn = Now
                    }
                },
                Status = status
            };
        }

        private static WorkdayConcurRunCheckpoint CreateMovingFilesCheckpoint(params WorkdayConcurFileMove[] moves)
        {
            var checkpoint = CreateCompletedInputCheckpoint();
            checkpoint.WorkdayEmployeeFile = CreateEmployeeFile();
            checkpoint.WorkdayEmployeeCount = 1;
            checkpoint.Transformation = CreateTransformationCheckpoint("Succeeded", includeOutput: true);
            checkpoint.Delivery = CreateDeliveryCheckpoint(WorkdayConcurDeliveryStatus.Succeeded);
            if (moves.Length > 0)
            {
                checkpoint.Housekeeping = new WorkdayConcurHousekeepingCheckpoint
                {
                    BlobServiceEndpoint = "https://storage.blob.core.windows.net",
                    Moves = moves,
                    Status = WorkdayConcurHousekeepingStatus.InProgress
                };
            }

            return checkpoint;
        }

        private static WorkdayConcurFileMove CreateHousekeepingMove(string fileName, WorkdayConcurFileMoveStatus copyStatus, WorkdayConcurFileMoveStatus deleteStatus)
        {
            return new WorkdayConcurFileMove
            {
                SourceFile = new WorkdayConcurFileIdentity
                {
                    Path = $"stukconcurprd/output/{fileName}",
                    ContentLength = 100,
                    ETag = $"{fileName}-etag",
                    LastModifiedOn = Now
                },
                SourcePath = "stukconcurprd/output",
                SourceFileName = fileName,
                DestinationPath = "stukconcurprd/collected",
                DestinationFileName = $"moved-{fileName}",
                CopyStatus = copyStatus,
                DeleteStatus = deleteStatus
            };
        }

        private static WorkdayConcurFileIdentity CreateHousekeepingDestination(WorkdayConcurFileMove move)
        {
            return new WorkdayConcurFileIdentity
            {
                Path = $"{move.DestinationPath}/{move.DestinationFileName}",
                ContentLength = move.SourceFile.ContentLength,
                ETag = "destination-etag",
                LastModifiedOn = Now
            };
        }

        private void SetupCompletedTransformation(WorkdayConcurTransformationCheckpoint started)
        {
            var completed = CreateTransformationCheckpoint("Succeeded", includeOutput: true);

            _transformationService
                .Setup(x => x.CompleteAsync(
                    It.Is<WorkdayConcurTransformationCheckpoint>(checkpoint => checkpoint.SynapseRunId == started.SynapseRunId),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(completed);

            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Transforming,
                    WorkdayConcurRunStage.Transforming,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            SetupSuccessfulDelivery();
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Transforming,
                    WorkdayConcurRunStage.Delivering,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
        }

        private void SetupSuccessfulWorkdayInput()
        {
            var workers = new[] { new WorkdayWorker { EmployeeId = "1001" } };

            var file = new WorkdayConcurFileIdentity
            {
                Path = "stukconcurprd/input/SG_CONCUR_DAILY.csv",
                ContentLength = 100,
                ETag = "employee-etag",
                LastModifiedOn = Now
            };

            _workersClient.Setup(x => x.GetWorkersAsync(Now.AddDays(-1), Now, It.IsAny<CancellationToken>())).ReturnsAsync(workers);

            _csvService.Setup(x => x.StageAsync(workers, It.IsAny<CancellationToken>())).ReturnsAsync(file);
        }

        private void SetupSuccessfulTransformation()
        {
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.CollectingInputs,
                    WorkdayConcurRunStage.Transforming,
                    It.IsAny<string>(),
                    "synapse-run", null, null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Transforming,
                    WorkdayConcurRunStage.Transforming,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Transforming,
                    WorkdayConcurRunStage.Delivering,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", null, null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var started = new WorkdayConcurTransformationCheckpoint
            {
                SynapseRunId = "transform-run",
                StartedOn = Now,
                Status = "InProgress"
            };

            var completed = new WorkdayConcurTransformationCheckpoint
            {
                SynapseRunId = "transform-run",
                StartedOn = Now,
                CompletedOn = Now,
                Status = "Succeeded",
                OutputFiles = new[]
                {
                    new WorkdayConcurFileIdentity
                    {
                        Path = "stukconcurprd/output/employee.txt",
                        ContentLength = 100,
                        ETag = "output-etag",
                        LastModifiedOn = Now
                    }
                }
            };

            _transformationService.Setup(x => x.StartAsync(CorrelationId, It.IsAny<CancellationToken>())).ReturnsAsync(started);

            _transformationService.Setup(x => x.CompleteAsync(started, It.IsAny<CancellationToken>())).ReturnsAsync(completed);

            SetupSuccessfulDelivery();
        }

        private void SetupSuccessfulDelivery()
        {
            var prepared = new WorkdayConcurDeliveryCheckpoint
            {
                BlobServiceEndpoint = "https://storage.blob.core.windows.net",
                StagingContainer = "erp3data",
                StagingFolderPath = "workday-concur/delivery/10000000000000000000000000000001",
                StagedFiles = new[]
                {
                    new WorkdayConcurFileIdentity
                    {
                        Path = "erp3data/workday-concur/delivery/10000000000000000000000000000001/employee.txt.pgp",
                        ContentLength = 200,
                        ETag = "encrypted-etag",
                        LastModifiedOn = Now
                    }
                },
                Status = WorkdayConcurDeliveryStatus.Staged
            };
            var started = new WorkdayConcurDeliveryCheckpoint
            {
                SynapseRunId = "delivery-run",
                StartedOn = Now,
                BlobServiceEndpoint = prepared.BlobServiceEndpoint,
                StagingContainer = prepared.StagingContainer,
                StagingFolderPath = prepared.StagingFolderPath,
                StagedFiles = prepared.StagedFiles,
                Status = WorkdayConcurDeliveryStatus.InProgress
            };
            var completed = new WorkdayConcurDeliveryCheckpoint
            {
                SynapseRunId = started.SynapseRunId,
                StartedOn = started.StartedOn,
                CompletedOn = Now,
                BlobServiceEndpoint = started.BlobServiceEndpoint,
                StagingContainer = started.StagingContainer,
                StagingFolderPath = started.StagingFolderPath,
                StagedFiles = started.StagedFiles,
                Status = WorkdayConcurDeliveryStatus.Succeeded
            };

            _deliveryService
                .Setup(x => x.PrepareAsync(CorrelationId, It.IsAny<IReadOnlyCollection<WorkdayConcurFileIdentity>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(prepared);

            _deliveryService
                .Setup(x => x.StartAsync(CorrelationId, It.Is<WorkdayConcurDeliveryCheckpoint>(checkpoint => checkpoint.Status == WorkdayConcurDeliveryStatus.Starting), It.IsAny<CancellationToken>()))
                .ReturnsAsync(started);

            _deliveryService.Setup(x => x.CompleteAsync(started, It.IsAny<CancellationToken>())).ReturnsAsync(completed);

            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Delivering,
                    WorkdayConcurRunStage.Delivering,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Delivering,
                    WorkdayConcurRunStage.MovingFiles,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            SetupSuccessfulHousekeeping();
        }

        private void SetupDeliveryStateUpdates()
        {
            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Delivering,
                    WorkdayConcurRunStage.Delivering,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            _stateService
                .Setup(x => x.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.Delivering,
                    WorkdayConcurRunStage.MovingFiles,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", null, Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            SetupSuccessfulHousekeeping();
        }

        private void SetupSuccessfulHousekeeping()
        {
            var move = new WorkdayConcurFileMove
            {
                SourceFile = new WorkdayConcurFileIdentity
                {
                    Path = "stukconcurprd/output/employee.txt",
                    ContentLength = 100,
                    ETag = "output-etag",
                    LastModifiedOn = Now
                },
                SourcePath = "stukconcurprd/output",
                SourceFileName = "employee.txt",
                DestinationPath = "stukconcurprd/collected",
                DestinationFileName = "employee_20260905083000000.txt",
                CopyStatus = WorkdayConcurFileMoveStatus.Pending,
                DeleteStatus = WorkdayConcurFileMoveStatus.Pending
            };
            var housekeeping = new WorkdayConcurHousekeepingCheckpoint
            {
                BlobServiceEndpoint = "https://storage.blob.core.windows.net",
                Moves = new[] { move },
                Status = WorkdayConcurHousekeepingStatus.InProgress
            };

            _housekeepingService
                .Setup(value => value.PrepareAsync(It.IsAny<IReadOnlyCollection<WorkdayConcurFileIdentity>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(housekeeping);

            _housekeepingService
                .Setup(value => value.StartCopyAsync(CorrelationId, move, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() =>
                {
                    move.CopyStatus = WorkdayConcurFileMoveStatus.InProgress;
                    move.CopySynapseRunId = "housekeeping-copy-run";
                    return move;
                });

            _housekeepingService
                .Setup(value => value.CompleteCopyAsync(move, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() =>
                {
                    move.CopyStatus = WorkdayConcurFileMoveStatus.Succeeded;
                    move.DestinationFile = new WorkdayConcurFileIdentity
                    {
                        Path = "stukconcurprd/collected/employee_20260905083000000.txt",
                        ContentLength = 100,
                        ETag = "collected-etag",
                        LastModifiedOn = Now
                    };
                    return move;
                });

            _housekeepingService
                .Setup(value => value.StartDeleteAsync(CorrelationId, move, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() =>
                {
                    move.DeleteStatus = WorkdayConcurFileMoveStatus.InProgress;
                    move.DeleteSynapseRunId = "housekeeping-delete-run";
                    return move;
                });

            _housekeepingService
                .Setup(value => value.CompleteDeleteAsync(move, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() =>
                {
                    move.DeleteStatus = WorkdayConcurFileMoveStatus.Succeeded;
                    return move;
                });

            _stateService
                .Setup(value => value.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.MovingFiles,
                    WorkdayConcurRunStage.MovingFiles,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", It.IsAny<string?>(), Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            _stateService.Setup(value => value.CommitRunAsync(RunId, ClaimToken, Now, It.IsAny<CancellationToken>())).Returns(Task.CompletedTask);
        }

        private void SetupHousekeepingStateUpdates()
        {
            _stateService
                .Setup(value => value.UpdateStageAsync(
                    RunId,
                    ClaimToken,
                    WorkdayConcurRunStage.MovingFiles,
                    WorkdayConcurRunStage.MovingFiles,
                    It.IsAny<string>(),
                    "synapse-run", "transform-run", "delivery-run", It.IsAny<string?>(), Now, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            _stateService.Setup(value => value.CommitRunAsync(RunId, ClaimToken, Now, It.IsAny<CancellationToken>())).Returns(Task.CompletedTask);
        }
    }
}
