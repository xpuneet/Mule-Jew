using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class PaymentReferenceSyncServiceTests
    {
        private readonly Mock<IDbExecutor> _dbExecutorMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly PaymentReferenceSyncService _service;

        public PaymentReferenceSyncServiceTests()
        {
            _dbExecutorMock = new Mock<IDbExecutor>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();

            _service = new PaymentReferenceSyncService(
                _dbExecutorMock.Object,
                _loggerMock.Object);
        }

        #region GetPendingPaymentsAsync

        [Fact]
        public async Task GetPendingPaymentsAsync_CallsCorrectStoredProcedure()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteListAsync<PendingPaymentReference>(
                    StoredProcedures.GetPendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(new List<PendingPaymentReference>());

            // Act
            await _service.GetPendingPaymentsAsync();

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteListAsync<PendingPaymentReference>(
                    StoredProcedures.GetPendingPaymentsReference,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task GetPendingPaymentsAsync_ReturnsResults()
        {
            // Arrange
            var expected = new List<PendingPaymentReference>
            {
                new() { PaymentId = 1, AccountCode = "ACC001", BranchId = "10", Description = "Payment 1", PaymentType = 'C', PaymentAmount = 100m, ApiPaymentReference = Guid.NewGuid() },
                new() { PaymentId = 2, AccountCode = "ACC002", BranchId = "20", Description = "Payment 2", PaymentType = 'D', PaymentAmount = 200m, ApiPaymentReference = Guid.NewGuid() }
            };

            _dbExecutorMock
                .Setup(db => db.ExecuteListAsync<PendingPaymentReference>(
                    StoredProcedures.GetPendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(expected);

            // Act
            var result = await _service.GetPendingPaymentsAsync();

            // Assert
            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task GetPendingPaymentsAsync_EmptyResults_ReturnsEmptyCollection()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteListAsync<PendingPaymentReference>(
                    StoredProcedures.GetPendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(new List<PendingPaymentReference>());

            // Act
            var result = await _service.GetPendingPaymentsAsync();

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetPendingPaymentsAsync_LogsStartAndCompletion()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteListAsync<PendingPaymentReference>(
                    StoredProcedures.GetPendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(new List<PendingPaymentReference>());

            // Act
            await _service.GetPendingPaymentsAsync();

            // Assert
            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("GetPendingPaymentsAsync started")),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);

            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("GetPendingPaymentsAsync completed")),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task GetPendingPaymentsAsync_DbThrows_Propagates()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteListAsync<PendingPaymentReference>(
                    StoredProcedures.GetPendingPaymentsReference,
                    It.IsAny<object>()))
                .ThrowsAsync(new Exception("Connection failed"));

            // Act & Assert
            var ex = await Assert.ThrowsAsync<Exception>(
                () => _service.GetPendingPaymentsAsync());
            Assert.Equal("Connection failed", ex.Message);
        }

        #endregion

        #region UpdatePendingPaymentsAsync

        [Fact]
        public async Task UpdatePendingPaymentsAsync_CallsCorrectStoredProcedure()
        {
            // Arrange
            var results = new List<UpdatePaymentReference>
            {
                new() { PaymentId = 1, ErpPaymentReference = "ERP-001", ErpStatus = "Completed" }
            };

            _dbExecutorMock
                .Setup(db => db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            // Act
            await _service.UpdatePendingPaymentsAsync(results);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task UpdatePendingPaymentsAsync_WithNullFields_CallsDbSuccessfully()
        {
            // Arrange
            var results = new List<UpdatePaymentReference>
            {
                new() { PaymentId = 1, ErpPaymentReference = null, ErpStatus = "Failed", ErpReason = null }
            };

            _dbExecutorMock
                .Setup(db => db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            // Act
            await _service.UpdatePendingPaymentsAsync(results);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task UpdatePendingPaymentsAsync_MultipleResults_CallsDbOnce()
        {
            // Arrange
            var results = new List<UpdatePaymentReference>
            {
                new() { PaymentId = 1, ErpPaymentReference = "ERP-001", ErpStatus = "Completed" },
                new() { PaymentId = 2, ErpPaymentReference = "ERP-002", ErpStatus = "Failed", ErpReason = "Timeout" }
            };

            _dbExecutorMock
                .Setup(db => db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            // Act
            await _service.UpdatePendingPaymentsAsync(results);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task UpdatePendingPaymentsAsync_LogsStartAndCompletion()
        {
            // Arrange
            var results = new List<UpdatePaymentReference>
            {
                new() { PaymentId = 1, ErpPaymentReference = "ERP-001", ErpStatus = "Completed" }
            };

            _dbExecutorMock
                .Setup(db => db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            // Act
            await _service.UpdatePendingPaymentsAsync(results);

            // Assert
            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("UpdatePendingPaymentsAsync started")),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);

            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("UpdatePendingPaymentsAsync completed")),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task UpdatePendingPaymentsAsync_DbThrows_Propagates()
        {
            // Arrange
            var results = new List<UpdatePaymentReference>
            {
                new() { PaymentId = 1, ErpPaymentReference = "ERP-001", ErpStatus = "Completed" }
            };

            _dbExecutorMock
                .Setup(db => db.ExecuteAsync(
                    StoredProcedures.UpdatePendingPaymentsReference,
                    It.IsAny<object>()))
                .ThrowsAsync(new Exception("DB error"));

            // Act & Assert
            var ex = await Assert.ThrowsAsync<Exception>(
                () => _service.UpdatePendingPaymentsAsync(results));
            Assert.Equal("DB error", ex.Message);
        }

        #endregion
    }
}
