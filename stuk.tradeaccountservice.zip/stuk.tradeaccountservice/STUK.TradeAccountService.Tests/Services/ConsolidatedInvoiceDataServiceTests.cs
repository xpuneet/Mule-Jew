using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text.Json;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedInvoiceDataServiceTests
    {
        private static readonly Guid SourceItemId = new("30000000-0000-0000-0000-000000000001");
        private static readonly Guid ClaimToken = new("30000000-0000-0000-0000-000000000002");
        private static readonly DateTimeOffset SalesforceCooloffStartedOn = new(2026, 8, 24, 9, 0, 0, TimeSpan.Zero);
        private static readonly DateTimeOffset SalesforceEligibleOn = SalesforceCooloffStartedOn.AddHours(48);

        private readonly Mock<IDbExecutor> _dbExecutor = new();

        [Fact]
        public async Task Given_A_Canonical_Invoice_When_Committing_Should_Send_The_Complete_Hierarchy_As_Json()
        {
            var invoice = new ConsolidatedSalesInvoice
            {
                ConsolidatedInvoiceNumber = "CON-100",
                ExpectedLineCount = 1,
                Parties = [new ConsolidatedSalesInvoiceParty { PartyRole = "Buyer" }],
                Components = [new ConsolidatedSalesInvoiceComponent { ComponentReferenceKey = "COMP-1" }],
                Lines = [new ConsolidatedSalesInvoiceLine { ComponentReferenceKey = "COMP-1", LineIdentity = "LINE-1", SalesforceExternalId = "SF-1" }],
                TaxSubTotals = [new ConsolidatedSalesTaxSubTotal { TaxRateCode = "S" }]
            };

            object? parameters = null;

            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesCommitResult>(StoredProcedures.CommitConsolidatedSalesInvoice, It.IsAny<object>()))
                .Callback<string, object>((_, value) => parameters = value)
                .ReturnsAsync(new ConsolidatedSalesCommitResult { IsNew = true });

            var result = await CreateService().CommitAsync(
                SourceItemId,
                ClaimToken,
                invoice,
                SalesforceCooloffStartedOn,
                48,
                SalesforceEligibleOn);

            Assert.True(result.IsNew);

            using var document = JsonDocument.Parse(GetProperty<string>(parameters!, "invoiceJson"));

            Assert.Equal("CON-100", document.RootElement.GetProperty("ConsolidatedInvoiceNumber").GetString());
            Assert.Single(document.RootElement.GetProperty("Parties").EnumerateArray());
            Assert.Single(document.RootElement.GetProperty("Components").EnumerateArray());
            Assert.Single(document.RootElement.GetProperty("Lines").EnumerateArray());
            Assert.Single(document.RootElement.GetProperty("TaxSubTotals").EnumerateArray());
            Assert.Equal(SalesforceCooloffStartedOn, GetProperty<DateTimeOffset>(parameters!, "salesforceCooloffStartedOn"));
            Assert.Equal(48, GetProperty<int>(parameters!, "salesforceCooloffHours"));
            Assert.Equal(SalesforceEligibleOn, GetProperty<DateTimeOffset>(parameters!, "salesforceEligibleOn"));
        }

        [Fact]
        public async Task Given_Camel_Case_Database_Json_When_Reading_By_Number_Should_Return_The_Complete_Hierarchy()
        {
            const string json = """
                {"id":"00000000-0000-0000-0000-000000000001","consolidatedInvoiceNumber":"CON-100","expectedLineCount":1,"parties":[{"partyRole":"Buyer"}],"components":[{"componentReferenceKey":"COMP-1"}],"lines":[{"lineIdentity":"LINE-1","salesforceExternalId":"SF-1"}],"taxSubTotals":[{"taxRateCode":"S"}]}
                """;
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<string>(StoredProcedures.GetConsolidatedSalesInvoiceByNumber, It.IsAny<object>())).ReturnsAsync(json);

            var result = await CreateService().GetByNumberAsync("CON-100");

            Assert.NotNull(result);
            Assert.Equal("CON-100", result.ConsolidatedInvoiceNumber);
            Assert.Single(result.Parties);
            Assert.Single(result.Components);
            Assert.Single(result.Lines);
            Assert.Single(result.TaxSubTotals);
        }

        [Fact]
        public async Task Given_No_Database_Json_When_Reading_By_Number_Should_Return_Null()
        {
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<string>(StoredProcedures.GetConsolidatedSalesInvoiceByNumber, It.IsAny<object>())).ReturnsAsync((string?)null);

            var result = await CreateService().GetByNumberAsync("missing");

            Assert.Null(result);
        }

        [Fact]
        public async Task Given_A_Cancelled_Token_When_Committing_Should_Not_Call_The_Database()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().CommitAsync(
                SourceItemId,
                ClaimToken,
                new ConsolidatedSalesInvoice(),
                SalesforceCooloffStartedOn,
                48,
                SalesforceEligibleOn,
                cancellationToken: token));

            _dbExecutor.VerifyNoOtherCalls();
        }

        private ConsolidatedInvoiceDataService CreateService() => new(_dbExecutor.Object);

        private static T GetProperty<T>(object instance, string propertyName) => (T)instance.GetType().GetProperty(propertyName)!.GetValue(instance)!;
    }
}
