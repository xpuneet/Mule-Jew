using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceInvoiceMapperTests
    {
        private const string ConsolidatedInvoiceNumber = "3051/00721885";
        private const string CustomerAccountCode = "ACC-100";
        private const string ExternalId = "3051/007218851";
        private const string ProductCode = "PROD-100";
        private const string TextExternalId = "3051/007218852";

        [Fact]
        public void Given_CompleteCanonicalInvoice_When_Map_Should_MapSalesforceOrder()
        {
            var source = CreateInvoice();

            var result = CreateMapper().Map(source);

            Assert.Equal(CustomerAccountCode, result.Order.AccountExternalId);
            Assert.Equal(ConsolidatedInvoiceNumber, result.Order.InvoiceNumber);
            Assert.Equal("Draft", result.Order.Status);
            Assert.Equal("Invoice", result.Order.OrderType);
            Assert.Equal(new DateOnly(2026, 7, 12), result.Order.EffectiveDate);
            Assert.Equal(new DateOnly(2026, 7, 12), result.Order.InvoiceDate);
            Assert.Equal(new DateOnly(2026, 7, 11), result.Order.TaxPointDate);
            Assert.Equal("Monthly", result.Order.CreditTerms);
            Assert.Equal(100m, result.Order.TaxableTotal);
            Assert.Equal(20m, result.Order.TaxTotal);
            Assert.Equal(120m, result.Order.GrossPaymentTotal);
            Assert.Equal(2, result.Order.ExpectedLineCount);
        }

        [Fact]
        public void Given_CompleteCanonicalLine_When_Map_Should_MapSalesforceOrderItem()
        {
            var source = CreateInvoice();

            var result = CreateMapper().Map(source);

            var item = result.Items[0];
            Assert.Equal(ExternalId, item.ExternalId);
            Assert.Equal(ConsolidatedInvoiceNumber, item.InvoiceNumber);
            Assert.Equal(ProductCode, item.ProductCode);
            Assert.Equal("1", item.LineNumber);
            Assert.Equal(10m, item.OrderLineNumber);
            Assert.Equal(9m, item.OriginalOrderLineNumber);
            Assert.Equal("137/00163396", item.DeliveryNoteNumber);
            Assert.Equal(20m, item.DeliveryNoteLineNumber);
            Assert.Equal("BUY-100", item.BuyersOrderNumber);
            Assert.Equal("SUP-100", item.OrderReference);
            Assert.Equal(new DateOnly(2026, 7, 10), item.DespatchDate);
            Assert.Equal("DEL-100", item.CodeForDelivery);
            Assert.Equal("Sale", item.OrderType);
            Assert.Equal("Collections", item.OrderCategory);
            Assert.Equal("Collect now", item.DeliveryMethod);
            Assert.Equal("PART-100", item.PartAnalysisCode);
            Assert.True(item.IsSpecialProduct);
            Assert.Equal("Product description", item.Description);
            Assert.Equal(5m, item.Quantity);
            Assert.Equal("EA", item.QuantityUomCode);
            Assert.Equal("Each", item.QuantityUomDescription);
            Assert.Equal(10m, item.UnitPrice);
            Assert.Equal("EA", item.PriceUomCode);
            Assert.Equal("Each", item.PriceUomDescription);
            Assert.Equal(5m, item.PercentageDiscount);
            Assert.Equal("S", item.TaxRateCode);
            Assert.Equal(20m, item.TaxRate);
            Assert.Equal(10m, item.TaxValue);
            Assert.Equal(50m, item.OrderProductTotal);
            Assert.Equal("JOB-100", item.JobNumber);
            Assert.Equal("Line 1", item.JobAddressLine);
            Assert.Equal("Job Street", item.JobStreet);
            Assert.Equal("Job City", item.JobCity);
            Assert.Equal("Job State", item.JobState);
            Assert.Equal("LONG POS", item.JobPostcode);
            Assert.Equal("CONTRACT-100", item.ContractNumber);
            Assert.Equal("LOCATION-100", item.BuyerLocationCode);
            Assert.Equal("Operative", item.Operative);
            Assert.Equal("SITE-100", item.SiteCode);
            Assert.Equal("PLOT-100", item.PlotNumber);
            Assert.Equal("VEH-100", item.VehicleRegistration);
            Assert.Equal("HOUSE-100", item.HouseType);
            Assert.Equal("GROUP-100", item.ProductGroup);
            Assert.True(item.OrderAuthorised);
        }

        [Fact]
        public void Given_TextLine_When_Map_Should_ApplyTextProductRules()
        {
            var source = CreateInvoice();
            var textLine = source.Lines[1];
            textLine.IsTextLine = true;
            textLine.ProductCode = null;
            textLine.Quantity = 99m;
            textLine.UnitPrice = 99m;

            var result = CreateMapper().Map(source);

            var item = result.Items[1];
            Assert.Equal("TEXT", item.ProductCode);
            Assert.Equal(1m, item.Quantity);
            Assert.Equal(0m, item.UnitPrice);
        }

        [Fact]
        public void Given_RepeatedProductCodes_When_Map_Should_ReturnDistinctRequiredProducts()
        {
            var source = CreateInvoice();
            source.Lines[1].ProductCode = ProductCode;

            var result = CreateMapper().Map(source);

            Assert.Equal(new[] { ProductCode }, result.RequiredProductCodes);
        }

        [Fact]
        public void Given_DescriptionWithCommas_When_Map_Should_RemoveCommasForCompatibility()
        {
            var source = CreateInvoice();
            source.Lines[0].ProductDescription = "Product, description, value";

            var result = CreateMapper().Map(source);

            Assert.Equal("Product description value", result.Items[0].Description);
        }

        [Fact]
        public void Given_LongPostcode_When_Map_Should_TruncateValueToEightCharacters()
        {
            var source = CreateInvoice();
            source.Lines[0].JobPostcode = "LONG POSTCODE";

            var result = CreateMapper().Map(source);

            Assert.Equal("LONG POS", result.Items[0].JobPostcode);
        }

        [Theory]
        [InlineData("No")]
        [InlineData("YES")]
        [InlineData("yes")]
        [InlineData(null)]
        public void Given_OrderAuthorisedIsNotExactYes_When_Map_Should_MapFalse(string? value)
        {
            var source = CreateInvoice();
            source.Lines[0].OrderAuthorised = value;

            var result = CreateMapper().Map(source);

            Assert.False(result.Items[0].OrderAuthorised);
        }

        [Fact]
        public void Given_EmptyOptionalLineNumbers_When_Map_Should_LeaveSalesforceNumbersNull()
        {
            var source = CreateInvoice();
            source.Lines[0].OrderLineNumber = null;
            source.Lines[0].OriginalOrderLineNumber = string.Empty;
            source.Lines[0].DeliveryNoteLineNumber = "   ";

            var result = CreateMapper().Map(source);

            Assert.Null(result.Items[0].OrderLineNumber);
            Assert.Null(result.Items[0].OriginalOrderLineNumber);
            Assert.Null(result.Items[0].DeliveryNoteLineNumber);
        }

        [Theory]
        [InlineData("not-a-number")]
        [InlineData("100000")]
        public void Given_InvalidOrderLineNumber_When_Map_Should_ThrowInvalidOperationException(string value)
        {
            var source = CreateInvoice();
            source.Lines[0].OrderLineNumber = value;

            var exception = Assert.Throws<InvalidOperationException>(() => CreateMapper().Map(source));

            Assert.Equal(
                $"The order line number for Salesforce line {ExternalId} must be a number no greater than 99999.",
                exception.Message);
        }

        [Fact]
        public void Given_MissingInvoiceNumber_When_Map_Should_ThrowInvalidOperationException()
        {
            var source = CreateInvoice();
            source.ConsolidatedInvoiceNumber = string.Empty;

            var exception = Assert.Throws<InvalidOperationException>(() => CreateMapper().Map(source));

            Assert.Equal("The consolidated invoice number is required for Salesforce mapping.", exception.Message);
        }

        [Fact]
        public void Given_MissingCustomerAccount_When_Map_Should_ThrowInvalidOperationException()
        {
            var source = CreateInvoice();
            source.CustomerAccountCode = null;

            var exception = Assert.Throws<InvalidOperationException>(() => CreateMapper().Map(source));

            Assert.Equal("The customer account code is required for Salesforce mapping.", exception.Message);
        }

        [Fact]
        public void Given_MissingLineExternalId_When_Map_Should_ThrowInvalidOperationException()
        {
            var source = CreateInvoice();
            source.Lines[0].SalesforceExternalId = string.Empty;

            var exception = Assert.Throws<InvalidOperationException>(() => CreateMapper().Map(source));

            Assert.Equal(
                $"The Salesforce external identifier is required for invoice {ConsolidatedInvoiceNumber}.",
                exception.Message);
        }

        [Fact]
        public void Given_MissingNormalProductCode_When_Map_Should_ThrowInvalidOperationException()
        {
            var source = CreateInvoice();
            source.Lines[0].ProductCode = null;

            var exception = Assert.Throws<InvalidOperationException>(() => CreateMapper().Map(source));

            Assert.Equal(
                $"The product code is required for Salesforce line {ExternalId}.",
                exception.Message);
        }

        [Fact]
        public void Given_MissingSpecialProductIndicator_When_Map_Should_ThrowInvalidOperationException()
        {
            var source = CreateInvoice();
            source.Lines[0].IsSpecialProduct = null;

            var exception = Assert.Throws<InvalidOperationException>(() => CreateMapper().Map(source));

            Assert.Equal(
                $"The special product indicator is required for Salesforce line {ExternalId}.",
                exception.Message);
        }

        [Fact]
        public void Given_NullCanonicalInvoice_When_Map_Should_ThrowArgumentNullException()
        {
            Assert.Throws<ArgumentNullException>(() => CreateMapper().Map(null!));
        }

        private static SalesforceInvoiceMapper CreateMapper()
        {
            return new SalesforceInvoiceMapper();
        }

        private static ConsolidatedSalesInvoice CreateInvoice()
        {
            return new ConsolidatedSalesInvoice
            {
                ConsolidatedInvoiceNumber = ConsolidatedInvoiceNumber,
                CustomerAccountCode = CustomerAccountCode,
                InvoiceDate = new DateOnly(2026, 7, 12),
                TaxPointDate = new DateOnly(2026, 7, 11),
                CreditTermsCode = "MN",
                CreditTermsDescription = "Monthly",
                TaxableTotal = 100m,
                TaxTotal = 20m,
                GrossPaymentTotal = 120m,
                ExpectedLineCount = 2,
                Lines =
                [
                    CreateLine(ExternalId, "1", ProductCode),
                    CreateLine(TextExternalId, "2", "PROD-200")
                ]
            };
        }

        private static ConsolidatedSalesInvoiceLine CreateLine(
            string externalId,
            string lineNumber,
            string productCode)
        {
            return new ConsolidatedSalesInvoiceLine
            {
                SalesforceExternalId = externalId,
                SourceLineNumber = lineNumber,
                ProductCode = productCode,
                OrderLineNumber = "00010",
                OriginalOrderLineNumber = "00009",
                DeliveryNoteNumber = "137/00163396",
                DeliveryNoteLineNumber = "00020",
                BuyersOrderNumber = "BUY-100",
                SuppliersOrderReference = "SUP-100",
                SupplierDespatchDate = new DateOnly(2026, 7, 10),
                SupplierCodeForDelivery = "DEL-100",
                OrderTypeCode = "SL",
                OrderTypeDescription = "Sale",
                OrderCategoryCode = "C",
                OrderCategoryDescription = "Collections",
                DeliveryMethodCode = "N",
                DeliveryMethodDescription = "Collect now",
                SupplierPartAnalysisCode = "PART-100",
                IsSpecialProduct = true,
                ProductDescription = "Product description",
                Quantity = 5m,
                QuantityUomCode = "EA",
                QuantityUomDescription = "Each",
                UnitPrice = 10m,
                PriceUomCode = "EA",
                PriceUomDescription = "Each",
                PercentageDiscount = 5m,
                TaxRateCode = "S",
                TaxRate = 20m,
                TaxValue = 10m,
                LineTotal = 50m,
                JobNumber = "JOB-100",
                JobAddressLine1 = "Line 1",
                JobAddressLine2 = "Line 2",
                JobAddressLine3 = "Line 3",
                JobAddressLine4 = "Line 4",
                JobStreet = "Job Street",
                JobCity = "Job City",
                JobState = "Job State",
                JobPostcode = "LONG POSTCODE",
                ContractNumber = "CONTRACT-100",
                BuyerLocation = "LOCATION-100",
                Operative = "Operative",
                SiteCode = "SITE-100",
                PlotNumber = "PLOT-100",
                VehicleRegistration = "VEH-100",
                HouseType = "HOUSE-100",
                ProductGroup = "GROUP-100",
                OrderAuthorised = "Yes"
            };
        }
    }
}
