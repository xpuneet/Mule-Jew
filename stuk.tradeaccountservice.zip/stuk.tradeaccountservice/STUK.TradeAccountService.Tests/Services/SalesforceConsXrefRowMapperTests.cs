using STUK.TradeAccountService.Common.Salesforce.Models;
using STUK.TradeAccountService.Common.Salesforce.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceConsXrefRowMapperTests
    {
        [Fact]
        public void Given_A_Complete_Salesforce_Row_When_Mapping_Should_Preserve_The_Nine_Export_Values()
        {
            var source = new SalesforceConsXrefOrderItem
            {
                Order = new SalesforceConsXrefOrder
                {
                    Account = new SalesforceConsXrefAccount { AccountNumber = "ACC001" },
                    InvoiceNumber = "INV001",
                    InvoiceDate = new DateOnly(2026, 8, 1)
                },
                DeliveryNoteNumber = "DEL001",
                DeliveryNoteLineNumber = 12,
                DespatchDate = new DateOnly(2026, 7, 31),
                Product = new SalesforceConsXrefProduct { ProductCode = "PRODUCT001" },
                Quantity = 2.5m,
                TotalPrice = 19.98m
            };

            var result = new SalesforceConsXrefRowMapper().Map(source);

            Assert.Equal("ACC001", result.AccountNumber);
            Assert.Equal("INV001", result.InvoiceNumber);
            Assert.Equal(new DateOnly(2026, 8, 1), result.InvoiceDate);
            Assert.Equal("DEL001", result.DeliveryNoteNumber);
            Assert.Equal("12", result.DeliveryNoteLineNumber);
            Assert.Equal(new DateOnly(2026, 7, 31), result.DespatchDate);
            Assert.Equal("PRODUCT001", result.ProductCode);
            Assert.Equal(2.5m, result.Quantity);
            Assert.Equal(19.98m, result.TotalPrice);
        }

        [Fact]
        public void Given_Null_Relationships_When_Mapping_Should_Preserve_Null_Export_Values()
        {
            var result = new SalesforceConsXrefRowMapper().Map(new SalesforceConsXrefOrderItem());

            Assert.Null(result.AccountNumber);
            Assert.Null(result.InvoiceNumber);
            Assert.Null(result.InvoiceDate);
            Assert.Null(result.ProductCode);
        }

        [Fact]
        public void Given_A_Null_Row_When_Mapping_Should_Reject_It()
        {
            Assert.Throws<ArgumentNullException>(() => new SalesforceConsXrefRowMapper().Map(null!));
        }
    }
}
