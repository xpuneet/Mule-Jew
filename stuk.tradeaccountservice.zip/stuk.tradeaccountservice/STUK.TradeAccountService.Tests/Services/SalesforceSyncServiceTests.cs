using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using STUK.TradeAccountService.Common.Salesforce.Services;
using System.Net;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceSyncServiceTests
    {
        private const string InvoiceNumber = "CON-100";
        private const string LineExternalId = "CON-10000001";
        private const string OrderId = "801000000000001";
        private const string OrderItemId = "802000000000001";
        private const string PricebookEntryId = "01u000000000001";
        private const string ProductCode = "PRODUCT-001";
        private const string ProductId = "01t000000000001";
        private static readonly Guid ClaimToken = new("50000000-0000-0000-0000-000000000002");
        private static readonly Guid CorrelationId = new("50000000-0000-0000-0000-000000000003");
        private static readonly DateTimeOffset CurrentTime = new(2026, 8, 8, 10, 0, 0, TimeSpan.Zero);
        private static readonly Guid InvoiceId = new("50000000-0000-0000-0000-000000000004");
        private static readonly Guid WorkId = new("50000000-0000-0000-0000-000000000001");

        [Fact]
        public async Task Given_CompleteCanonicalInvoice_When_Run_Should_ActivateOrderAndCompleteDurableWork()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();
            dependencies.Mapper.Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>())).Returns(projection);
            SetupSuccessfulSalesforce(dependencies, projection);
            var service = CreateService(dependencies);

            await service.RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.CompleteLineAsync(
                WorkId,
                ClaimToken,
                LineExternalId,
                ProductId,
                PricebookEntryId,
                OrderItemId,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.CompleteWorkAsync(
                WorkId,
                ClaimToken,
                OrderId,
                1,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dependencies.DataService.Verify(dataService => dataService.InsertAttemptAsync(
                It.IsAny<ConsolidatedSalesforceAttempt>(),
                It.IsAny<CancellationToken>()), Times.Exactly(4));
            dependencies.DataService.Verify(dataService => dataService.InsertAttemptAsync(
                It.Is<ConsolidatedSalesforceAttempt>(attempt => attempt.Outcome == "Succeeded"),
                It.IsAny<CancellationToken>()), Times.Exactly(4));
        }

        [Fact]
        public async Task Given_OrderItemCountDoesNotMatch_When_Run_Should_LeaveOrderIncompleteAndScheduleRetry()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();
            dependencies.Mapper.Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>())).Returns(projection);
            SetupSuccessfulSalesforce(dependencies, projection, activated: false, actualLineCount: 0);
            var service = CreateService(dependencies);

            await service.RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "LineCountMismatch",
                It.Is<string>(message => message.Contains(InvoiceNumber, StringComparison.Ordinal)),
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.CompleteWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_LineAlreadyCompleted_When_Run_Should_NotUpsertLineAgain()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService, "Completed");
            var projection = CreateProjection();
            dependencies.Mapper.Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>())).Returns(projection);
            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Id = OrderId, Success = true });
            dependencies.ProductService
                .Setup(service => service.EnsureProductsAsync(projection.RequiredProductCodes, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreatePrerequisites());
            dependencies.OrderService
                .Setup(service => service.FinaliseOrderAsync(InvoiceNumber, 1, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceOrderFinalisationResult { ExpectedLineCount = 1, ActualLineCount = 1, Activated = true });
            var service = CreateService(dependencies);

            await service.RunAsync("worker-1");

            dependencies.OrderService.Verify(service => service.UpsertOrderItemAsync(
                It.IsAny<SalesforceOrderItemProjection>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dependencies.DataService.Verify(dataService => dataService.CompleteWorkAsync(
                WorkId,
                ClaimToken,
                OrderId,
                1,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_NoEligibleWork_When_Run_Should_NotCallSalesforce()
        {
            var dependencies = CreateDependencies();
            dependencies.DataService
                .Setup(dataService => dataService.ClaimNextAsync(
                    "worker-1",
                    120,
                    3,
                    CurrentTime,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesforceWork?)null);
            var service = CreateService(dependencies);

            await service.RunAsync("worker-1");

            dependencies.Mapper.VerifyNoOtherCalls();
            dependencies.ProductService.VerifyNoOtherCalls();
            dependencies.OrderService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_Salesforce_Is_Transiently_Unavailable_When_Upserting_The_Order_Should_Audit_And_Schedule_A_Retry()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();
            var failure = new SalesforceApiException("Salesforce unavailable", HttpStatusCode.ServiceUnavailable);
            dependencies.Mapper.Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>())).Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ThrowsAsync(failure);
            var service = CreateService(dependencies);

            await service.RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.InsertAttemptAsync(
                It.Is<ConsolidatedSalesforceAttempt>(attempt =>
                    attempt.Operation == "UpsertDraftOrder"
                    && attempt.Outcome == "Failed"
                    && attempt.ErrorCategory == "TransientSalesforce"
                    && attempt.HttpStatusCode == 503),
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "TransientSalesforce",
                "Salesforce unavailable",
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.ProductService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_An_OrderItem_Upsert_Fails_When_Run_Should_Fail_The_Line_And_The_Parent_Work()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();
            dependencies.Mapper.Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>())).Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Id = OrderId, Success = true });

            dependencies.ProductService
                .Setup(service => service.EnsureProductsAsync(projection.RequiredProductCodes, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreatePrerequisites());

            dependencies.OrderService
                .Setup(service => service.UpsertOrderItemAsync(projection.Items[0], It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Invalid line"));
            var service = CreateService(dependencies);

            await service.RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailLineAsync(
                WorkId,
                ClaimToken,
                LineExternalId,
                "Invalid line",
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "InvalidDataOrConfiguration",
                "Invalid line",
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.CompleteLineAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Claimed_Work_Has_No_Canonical_Details_When_Run_Should_Record_A_Data_Failure_Without_Calling_Salesforce()
        {
            var dependencies = CreateDependencies();
            dependencies.DataService
                .SetupSequence(service => service.ClaimNextAsync("worker-1", 120, 3, CurrentTime, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesforceWork
                {
                    Id = WorkId,
                    ConsolidatedInvoiceId = InvoiceId,
                    ConsolidatedInvoiceNumber = InvoiceNumber,
                    CorrelationId = CorrelationId,
                    ClaimToken = ClaimToken,
                    AttemptCount = 1
                })
                .ReturnsAsync((ConsolidatedSalesforceWork?)null);

            dependencies.DataService
                .Setup(service => service.GetDetailsAsync(WorkId, ClaimToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesforceWorkDetails?)null);
            var service = CreateService(dependencies);

            await service.RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "InvalidDataOrConfiguration",
                It.Is<string>(message => message.Contains("no canonical invoice details", StringComparison.Ordinal)),
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.Mapper.VerifyNoOtherCalls();
            dependencies.ProductService.VerifyNoOtherCalls();
            dependencies.OrderService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_The_Lease_Is_Lost_During_A_Salesforce_Call_When_Run_Should_Cancel_Processing_Without_Completing_Or_Failing_Work()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();
            var callStarted = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var callCancelled = false;
            dependencies.Mapper.Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>())).Returns(projection);

            dependencies.DataService
                .SetupSequence(dataService => dataService.RenewLeaseAsync(
                    WorkId,
                    ClaimToken,
                    120,
                    CurrentTime,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesLeaseResult())
                .ThrowsAsync(new InvalidOperationException("Lease lost"));

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .Returns<SalesforceOrderProjection, CancellationToken>(async (_, cancellationToken) =>
                {
                    callStarted.SetResult();
                    try
                    {
                        await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
                    }
                    catch (OperationCanceledException)
                    {
                        callCancelled = true;
                        throw;
                    }

                    return new SalesforceUpsertResult();
                });
            var service = CreateService(dependencies, new SalesforceSyncOptions
            {
                MaximumWorkItemsPerRun = 2,
                LeaseDurationSeconds = 120,
                LeaseRenewalIntervalSeconds = 1,
                RetryDelaySeconds = 60,
                MaximumRetryCount = 3
            });

            var runTask = service.RunAsync("worker-1");
            await callStarted.Task;
            await runTask.WaitAsync(TimeSpan.FromSeconds(5));

            Assert.True(callCancelled);
            dependencies.DataService.Verify(dataService => dataService.CompleteWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Theory]
        [InlineData("MaximumWorkItemsPerRun")]
        [InlineData("LeaseDurationSeconds")]
        [InlineData("LeaseRenewalIntervalSeconds")]
        [InlineData("LeaseRenewalIntervalNotShorter")]
        [InlineData("RetryDelaySeconds")]
        [InlineData("MaximumRetryCount")]
        public async Task Given_An_Invalid_Salesforce_Worker_Setting_When_Run_Should_Reject_It_Before_Claiming_Work(string setting)
        {
            var dependencies = CreateDependencies();
            var options = CreateOptions();
            switch (setting)
            {
                case "MaximumWorkItemsPerRun":
                    options.MaximumWorkItemsPerRun = 0;
                    break;
                case "LeaseDurationSeconds":
                    options.LeaseDurationSeconds = 0;
                    break;
                case "LeaseRenewalIntervalSeconds":
                    options.LeaseRenewalIntervalSeconds = 0;
                    break;
                case "LeaseRenewalIntervalNotShorter":
                    options.LeaseRenewalIntervalSeconds = options.LeaseDurationSeconds;
                    break;
                case "RetryDelaySeconds":
                    options.RetryDelaySeconds = 0;
                    break;
                case "MaximumRetryCount":
                    options.MaximumRetryCount = 0;
                    break;
            }

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(dependencies, options).RunAsync("worker-1"));

            dependencies.DataService.VerifyNoOtherCalls();
        }

        private static SalesforceSyncService CreateService(SalesforceSyncDependencies dependencies, SalesforceSyncOptions? options = null, TimeProvider? timeProvider = null)
        {
            var processingTimeProvider = timeProvider ?? CreateTimeProvider();

            return new SalesforceSyncService(
                Mock.Of<ILogger<SalesforceSyncService>>(),
                dependencies.DataService.Object,
                dependencies.Mapper.Object,
                dependencies.ProductService.Object,
                dependencies.OrderService.Object,
                Options.Create(options ?? CreateOptions()),
                processingTimeProvider);
        }

        private static SalesforceSyncOptions CreateOptions()
        {
            return new SalesforceSyncOptions
            {
                MaximumWorkItemsPerRun = 2,
                LeaseDurationSeconds = 120,
                LeaseRenewalIntervalSeconds = 30,
                RetryDelaySeconds = 60,
                MaximumRetryCount = 3
            };
        }

        private static TimeProvider CreateTimeProvider()
        {
            var timeProvider = new Mock<TimeProvider>();
            timeProvider.Setup(provider => provider.GetUtcNow()).Returns(CurrentTime);
            return timeProvider.Object;
        }

        private static SalesforceSyncDependencies CreateDependencies()
        {
            var dependencies = new SalesforceSyncDependencies();
            dependencies.DataService
                .Setup(dataService => dataService.RenewLeaseAsync(
                    WorkId,
                    ClaimToken,
                    120,
                    CurrentTime,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesLeaseResult());
            dependencies.DataService
                .Setup(dataService => dataService.InsertAttemptAsync(
                    It.IsAny<ConsolidatedSalesforceAttempt>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesforceAttemptResult());
            dependencies.DataService
                .Setup(dataService => dataService.FailWorkAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<Guid>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<int>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesWorkFailureResult());

            return dependencies;
        }

        private static void SetupClaimedWork(Mock<ISalesforceSyncDataService> dataService, string lineStatus = "Pending", int leaseDurationSeconds = 120)
        {
            dataService
                .SetupSequence(service => service.ClaimNextAsync(
                    "worker-1",
                    leaseDurationSeconds,
                    3,
                    CurrentTime,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesforceWork
                {
                    Id = WorkId,
                    ConsolidatedInvoiceId = InvoiceId,
                    ConsolidatedInvoiceNumber = InvoiceNumber,
                    CorrelationId = CorrelationId,
                    ClaimToken = ClaimToken,
                    AttemptCount = 1
                })
                .ReturnsAsync((ConsolidatedSalesforceWork?)null);
            dataService
                .Setup(service => service.GetDetailsAsync(WorkId, ClaimToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesforceWorkDetails
                {
                    SalesforceWorkId = WorkId,
                    ConsolidatedInvoiceId = InvoiceId,
                    Invoice = new ConsolidatedSalesInvoice
                    {
                        Id = InvoiceId,
                        ConsolidatedInvoiceNumber = InvoiceNumber,
                        ExpectedLineCount = 1
                    },
                    Lines =
                    [
                        new ConsolidatedSalesforceLineDetails
                        {
                            SalesforceExternalId = LineExternalId,
                            SalesforceLineStatus = lineStatus
                        }
                    ]
                });
        }

        private static void SetupSuccessfulSalesforce(
            SalesforceSyncDependencies dependencies,
            SalesforceInvoiceProjection projection,
            bool activated = true,
            int actualLineCount = 1)
        {
            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Id = OrderId, Success = true });
            dependencies.ProductService
                .Setup(service => service.EnsureProductsAsync(projection.RequiredProductCodes, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreatePrerequisites());
            dependencies.OrderService
                .Setup(service => service.UpsertOrderItemAsync(projection.Items[0], It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Id = OrderItemId, Success = true });
            dependencies.OrderService
                .Setup(service => service.FinaliseOrderAsync(InvoiceNumber, 1, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceOrderFinalisationResult
                {
                    ExpectedLineCount = 1,
                    ActualLineCount = actualLineCount,
                    Activated = activated
                });
        }

        private static SalesforceInvoiceProjection CreateProjection()
        {
            return new SalesforceInvoiceProjection
            {
                Order = new SalesforceOrderProjection
                {
                    InvoiceNumber = InvoiceNumber,
                    ExpectedLineCount = 1
                },
                Items =
                [
                    new SalesforceOrderItemProjection
                    {
                        ExternalId = LineExternalId,
                        InvoiceNumber = InvoiceNumber,
                        ProductCode = ProductCode
                    }
                ],
                RequiredProductCodes = [ProductCode]
            };
        }

        private static IReadOnlyDictionary<string, SalesforceProductPrerequisite> CreatePrerequisites()
        {
            return new Dictionary<string, SalesforceProductPrerequisite>
            {
                [ProductCode] = new SalesforceProductPrerequisite
                {
                    ExternalId = ProductCode,
                    ProductId = ProductId,
                    PricebookEntryId = PricebookEntryId
                }
            };
        }

        private static async Task<T> WaitForCancellationAsync<T>(TaskCompletionSource cancellationObserved, CancellationToken cancellationToken)
        {
            try
            {
                await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
            }
            catch (OperationCanceledException)
            {
                cancellationObserved.SetResult();
                throw;
            }

            throw new InvalidOperationException("The operation should have been cancelled");
        }

        private sealed class SalesforceSyncDependencies
        {
            public Mock<ISalesforceSyncDataService> DataService { get; } = new();

            public Mock<ISalesforceInvoiceMapper> Mapper { get; } = new();

            public Mock<ISalesforceProductService> ProductService { get; } = new();

            public Mock<ISalesforceOrderService> OrderService { get; } = new();
        }

        [Fact]
        public async Task Given_Salesforce_Rejects_The_Order_When_Run_Should_Audit_And_Classify_The_Failure()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new SalesforceApiException("Rate limited", System.Net.HttpStatusCode.TooManyRequests));

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.InsertAttemptAsync(
                It.Is<ConsolidatedSalesforceAttempt>(attempt =>
                    attempt.Operation == "UpsertDraftOrder"
                    && attempt.Outcome == "Failed"
                    && attempt.HttpStatusCode == 429
                    && attempt.ErrorCategory == "TransientSalesforce"),
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "TransientSalesforce",
                "Rate limited",
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.ProductService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_An_Order_Item_Times_Out_When_Run_Should_Fail_The_Line_And_The_Work()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Id = OrderId, Success = true });

            dependencies.ProductService
                .Setup(service => service.EnsureProductsAsync(projection.RequiredProductCodes, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreatePrerequisites());

            dependencies.OrderService
                .Setup(service => service.UpsertOrderItemAsync(projection.Items[0], It.IsAny<CancellationToken>()))
                .ThrowsAsync(new TimeoutException("Salesforce timed out"));

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailLineAsync(
                WorkId,
                ClaimToken,
                LineExternalId,
                "Salesforce timed out",
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "TransientHttp",
                "Salesforce timed out",
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.DataService.Verify(dataService => dataService.CompleteLineAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dependencies.OrderService.Verify(service => service.FinaliseOrderAsync(
                It.IsAny<string>(),
                It.IsAny<int>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Claimed_Work_Has_No_Details_When_Run_Should_Record_An_Invalid_Data_Failure()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);

            dependencies.DataService
                .Setup(dataService => dataService.GetDetailsAsync(WorkId, ClaimToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesforceWorkDetails?)null);

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "InvalidDataOrConfiguration",
                It.Is<string>(message => message.Contains("no canonical invoice details", StringComparison.Ordinal)),
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.Mapper.VerifyNoOtherCalls();
            dependencies.OrderService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_A_Line_Has_No_Durable_State_When_Run_Should_Not_Upsert_That_Line()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();

            dependencies.DataService
                .Setup(dataService => dataService.GetDetailsAsync(WorkId, ClaimToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesforceWorkDetails
                {
                    SalesforceWorkId = WorkId,
                    ConsolidatedInvoiceId = InvoiceId,
                    Invoice = new ConsolidatedSalesInvoice
                    {
                        Id = InvoiceId,
                        ConsolidatedInvoiceNumber = InvoiceNumber,
                        ExpectedLineCount = 1
                    },
                    Lines = []
                });

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Id = OrderId, Success = true });

            dependencies.ProductService
                .Setup(service => service.EnsureProductsAsync(projection.RequiredProductCodes, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreatePrerequisites());

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "InvalidDataOrConfiguration",
                It.Is<string>(message => message.Contains(LineExternalId, StringComparison.Ordinal)),
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.OrderService.Verify(service => service.UpsertOrderItemAsync(
                It.IsAny<SalesforceOrderItemProjection>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Product_Prerequisites_Are_Missing_When_Run_Should_Not_Upsert_The_Order_Item()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Id = OrderId, Success = true });

            dependencies.ProductService
                .Setup(service => service.EnsureProductsAsync(projection.RequiredProductCodes, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new Dictionary<string, SalesforceProductPrerequisite>());

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "InvalidDataOrConfiguration",
                It.Is<string>(message => message.Contains(ProductCode, StringComparison.Ordinal)),
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.OrderService.Verify(service => service.UpsertOrderItemAsync(
                It.IsAny<SalesforceOrderItemProjection>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Processing_Is_Cancelled_When_Run_Should_Propagate_Cancellation_Without_Recording_A_Failure()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new OperationCanceledException());

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService(dependencies).RunAsync("worker-1"));

            dependencies.DataService.Verify(dataService => dataService.InsertAttemptAsync(
                It.IsAny<ConsolidatedSalesforceAttempt>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Salesforce_Rejects_Invalid_Data_When_Run_Should_Classify_The_Failure_As_Non_Transient()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);
            var projection = CreateProjection();

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Returns(projection);

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new SalesforceApiException("Invalid Salesforce field", System.Net.HttpStatusCode.BadRequest));

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "SalesforceRejected",
                "Invalid Salesforce field",
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_An_Unexpected_Mapping_Error_When_Run_Should_Classify_The_Failure_As_Unexpected()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService);

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Throws(new ApplicationException("Unexpected mapping failure"));

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                WorkId,
                ClaimToken,
                "Unexpected",
                "Unexpected mapping failure",
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dependencies.OrderService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_Claimed_Work_Has_No_Claim_Token_When_Run_Should_Not_Call_Salesforce_Or_Record_A_Work_Result()
        {
            var dependencies = CreateDependencies();

            dependencies.DataService
                .SetupSequence(dataService => dataService.ClaimNextAsync(
                    "worker-1",
                    120,
                    3,
                    CurrentTime,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesforceWork
                {
                    Id = WorkId,
                    ConsolidatedInvoiceId = InvoiceId,
                    ConsolidatedInvoiceNumber = InvoiceNumber,
                    CorrelationId = CorrelationId,
                    ClaimToken = null,
                    AttemptCount = 1
                })
                .ReturnsAsync((ConsolidatedSalesforceWork?)null);

            await CreateService(dependencies).RunAsync("worker-1");

            dependencies.Mapper.VerifyNoOtherCalls();
            dependencies.ProductService.VerifyNoOtherCalls();
            dependencies.OrderService.VerifyNoOtherCalls();
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Background_Lease_Renewal_Fails_When_Run_Should_Cancel_Salesforce_Processing_Without_Recording_A_False_Result()
        {
            var dependencies = CreateDependencies();
            SetupClaimedWork(dependencies.DataService, leaseDurationSeconds: 10);
            var projection = CreateProjection();
            var processingCancelled = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

            dependencies.Mapper
                .Setup(mapper => mapper.Map(It.IsAny<ConsolidatedSalesInvoice>()))
                .Returns(projection);

            dependencies.DataService
                .SetupSequence(dataService => dataService.RenewLeaseAsync(
                    WorkId,
                    ClaimToken,
                    10,
                    CurrentTime,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesLeaseResult())
                .ThrowsAsync(new InvalidOperationException("The Salesforce lease could not be renewed"));

            dependencies.OrderService
                .Setup(service => service.UpsertDraftOrderAsync(projection.Order, It.IsAny<CancellationToken>()))
                .Returns((SalesforceOrderProjection _, CancellationToken cancellationToken) =>
                    WaitForCancellationAsync<SalesforceUpsertResult>(processingCancelled, cancellationToken));

            var options = new SalesforceSyncOptions
            {
                MaximumWorkItemsPerRun = 1,
                LeaseDurationSeconds = 10,
                LeaseRenewalIntervalSeconds = 1,
                RetryDelaySeconds = 60,
                MaximumRetryCount = 3
            };

            await CreateService(dependencies, options).RunAsync("worker-1");

            Assert.True(processingCancelled.Task.IsCompleted);
            dependencies.DataService.Verify(dataService => dataService.CompleteWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dependencies.DataService.Verify(dataService => dataService.FailWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Theory]
        [InlineData(0, 120, 30, 60, 3, "maximum work items")]
        [InlineData(2, 0, 30, 60, 3, "lease duration")]
        [InlineData(2, 120, 0, 60, 3, "lease renewal interval")]
        [InlineData(2, 120, 120, 60, 3, "shorter than the lease duration")]
        [InlineData(2, 120, 30, 0, 3, "retry delay")]
        [InlineData(2, 120, 30, 60, 0, "maximum retry count")]
        public async Task Given_Invalid_Options_When_Run_Should_Reject_The_Configuration(
            int maximumWorkItemsPerRun,
            int leaseDurationSeconds,
            int leaseRenewalIntervalSeconds,
            int retryDelaySeconds,
            int maximumRetryCount,
            string expectedMessage)
        {
            var dependencies = CreateDependencies();
            var options = new SalesforceSyncOptions
            {
                MaximumWorkItemsPerRun = maximumWorkItemsPerRun,
                LeaseDurationSeconds = leaseDurationSeconds,
                LeaseRenewalIntervalSeconds = leaseRenewalIntervalSeconds,
                RetryDelaySeconds = retryDelaySeconds,
                MaximumRetryCount = maximumRetryCount
            };

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(dependencies, options).RunAsync("worker-1"));

            Assert.Contains(expectedMessage, exception.Message, StringComparison.OrdinalIgnoreCase);
            dependencies.DataService.Verify(dataService => dataService.ClaimNextAsync(
                It.IsAny<string>(),
                It.IsAny<int>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

    }
}
