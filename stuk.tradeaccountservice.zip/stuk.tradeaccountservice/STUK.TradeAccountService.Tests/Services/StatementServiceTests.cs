﻿using Microsoft.Extensions.Options;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class StatementServiceTests
    {
        private readonly Mock<IDbExecutor> _dbExecutorMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly StatementService _service;

        public StatementServiceTests()
        {
            _dbExecutorMock = new Mock<IDbExecutor>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();
            var downloadSettings = new DownloadSettings
            {
                ["Statement"] = new DocumentTypeDownloadSettings
                {
                    ContainerName = "statementtest",
                    FilePrepareUrl = null,
                    DownloadDelayHours =24
                }
            };

            var optionsMock = new Mock<IOptions<DownloadSettings>>();
            optionsMock.Setup(o => o.Value).Returns(downloadSettings);

            _service = new StatementService(
                _dbExecutorMock.Object,
                 optionsMock.Object,
                _loggerMock.Object);
        }

        #region SearchStatements

        [Fact]
        public async Task SearchStatements_CallsCorrectStoredProcedure()
        {
            // Arrange
            var request = new StatementSearchRequest(
                AccountCode: "ACC001",
                PageNumber: 1,
                PageSize: 10
            );

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync((string?)null);

            // Act
            await _service.SearchStatementsAsync(request);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task SearchStatements_DbReturnsNull_ReturnsEmptyResponse()
        {
            // Arrange
            var request = new StatementSearchRequest(
                AccountCode: "ACC001",
                PageNumber: 1,
                PageSize: 10
            );

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync((string?)null);

            // Act
            var result = await _service.SearchStatementsAsync(request);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task SearchStatements_DbReturnsEmptyString_ReturnsEmptyResponse()
        {
            // Arrange
            var request = new StatementSearchRequest(
                AccountCode: "ACC001",
                PageNumber: 1,
                PageSize: 10
            );

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync(string.Empty);

            // Act
            var result = await _service.SearchStatementsAsync(request);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task SearchStatements_DbReturnsValidJson_ReturnsDeserializedResponse()
        {
            // Arrange
            var request = new StatementSearchRequest(
                AccountCode: "ACC001",
                PageNumber: 1,
                PageSize: 10
            );

            var json = """
            {
                "pages": { "pageNumber": 1, "pageSize": 10, "totalPages": 1, "totalRecords": 1 },
                "statements": [
                    {
                        "statement": {
                            "header": {
                                "ID": 1,
                                "accountCode": "ACC001",
                                "statementDate": "2026-05-01",
                                "currencyCode": "GBP"
                            }
                        },
                        "lines": []
                    }
                ]
            }
            """;

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync(json);

            // Act
            var result = await _service.SearchStatementsAsync(request);

            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result!.Statements);
            Assert.Single(result.Statements);
            Assert.Equal("ACC001", result.Statements[0].Statement.Header.AccountCode);
        }

        [Fact]
        public async Task SearchStatements_DbReturnsNull_LogsWarning()
        {
            // Arrange
            var request = new StatementSearchRequest(
                AccountCode: "ACC001",
                PageNumber: 1,
                PageSize: 10
            );

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync((string?)null);

            // Act
            await _service.SearchStatementsAsync(request);

            // Assert
            _loggerMock.Verify(l =>
                l.LogWarning(
                    It.Is<string>(s => s.Contains("empty json", StringComparison.OrdinalIgnoreCase)),
                    It.IsAny<string>(),
                    It.IsAny<string>()),
                Times.Once);
        }

        [Fact]
        public async Task SearchStatements_DbReturnsValidJson_LogsSuccess()
        {
            // Arrange
            var request = new StatementSearchRequest(
                 AccountCode: "ACC001",
                 PageNumber: 1,
                 PageSize: 10
             );

            var json = """
            {
                "pages": { "pageNumber": 1, "pageSize": 10, "totalPages": 1, "totalRecords": 1 },
                "statements": []
            }
            """;

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync(json);

            // Act
            await _service.SearchStatementsAsync(request);

            // Assert
            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("completed successfully", StringComparison.OrdinalIgnoreCase)),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task SearchStatements_WithDateFilters_CallsDbWithConvertedDates()
        {
            // Arrange
            var request = new StatementSearchRequest
            (
                AccountCode: "ACC001",
                PageNumber: 1,
                PageSize: 10,
                StatementDateFrom: new DateOnly(2026, 1, 1),
                StatementDateTo: new DateOnly(2026, 5, 31)
            );

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync((string?)null);

            // Act
            await _service.SearchStatementsAsync(request);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task SearchStatements_WithNullDateFilters_CallsDbSuccessfully()
        {
            // Arrange
            var request = new StatementSearchRequest
            (
                AccountCode: "ACC001",
                PageNumber: 1,
                PageSize: 10,
                StatementDateFrom: null,
                StatementDateTo: null
            );

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()))
                .ReturnsAsync((string?)null);

            // Act
            await _service.SearchStatementsAsync(request);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<string>(
                    StoredProcedures.GetStatementsByAccountCode,
                    It.IsAny<object>()),
                Times.Once);
        }

        #endregion
    }
}