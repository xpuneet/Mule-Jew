using Azure.Core;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.Services;
using System.Net;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests direct Azure Synapse pipeline API requests
    /// </summary>
    public class SynapsePipelineClientTests
    {
        private const string WorkspaceName = "synw-concur";
        private const string ConcurWorkspaceName = "synw-concur-transform";
        private const string PipelineName = "SFTP_To_Blob";
        private const string RunId = "synapse-run";
        private const string AccessToken = "test-token";
        private const string ApiVersion = "2020-12-01";
        private const string SourceFilePath = "/Exports";

        /// <summary>
        /// Verifies that pipeline start uses the configured workspace, bearer token and supplied parameters
        /// </summary>
        [Fact]
        public async Task Given_Parameters_When_Starting_Should_ReturnSynapseRunId()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, $"{{\"runId\":\"{RunId}\"}}");

            var client = CreateClient(handler);

            var runId = await client.StartAsync(
                PipelineName,
                new Dictionary<string, object?> { ["SourceFilePath"] = SourceFilePath });

            Assert.Equal(RunId, runId);
            Assert.Equal(HttpMethod.Post, handler.Method);
            Assert.Equal($"https://{WorkspaceName}.dev.azuresynapse.net/pipelines/{PipelineName}/createRun?api-version={ApiVersion}", handler.RequestUri?.ToString());
            Assert.Equal("Bearer", handler.AuthorizationScheme);
            Assert.Equal(AccessToken, handler.AuthorizationParameter);
            Assert.Contains($"\"SourceFilePath\":\"{SourceFilePath}\"", handler.Content);
        }

        /// <summary>
        /// Verifies that the Concur transformation client targets the separate Concur workspace
        /// </summary>
        [Fact]
        public async Task Given_ConcurClient_When_Starting_Should_UseConcurWorkspace()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, $"{{\"runId\":\"{RunId}\"}}");

            IConcurSynapsePipelineClient client = CreateClient(handler);

            var runId = await client.StartAsync(PipelineName, new Dictionary<string, object?>());

            Assert.Equal(RunId, runId);
            Assert.Equal($"https://{ConcurWorkspaceName}.dev.azuresynapse.net/pipelines/{PipelineName}/createRun?api-version={ApiVersion}", handler.RequestUri?.ToString());
        }

        /// <summary>
        /// Verifies that pipeline names are escaped as one route segment
        /// </summary>
        [Fact]
        public async Task Given_PipelineNameContainingReservedCharacters_When_Starting_Should_EscapeRouteSegment()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, $"{{\"runId\":\"{RunId}\"}}");

            var client = CreateClient(handler);

            await client.StartAsync("folder/name", new Dictionary<string, object?>());

            Assert.Equal($"https://{WorkspaceName}.dev.azuresynapse.net/pipelines/folder%2Fname/createRun?api-version={ApiVersion}", handler.RequestUri?.ToString());
        }

        /// <summary>
        /// Verifies that a successful response without a run identifier cannot create an untrackable run
        /// </summary>
        [Theory]
        [InlineData("{}")]
        [InlineData("{\"runId\":\"\"}")]
        [InlineData("null")]
        public async Task Given_MissingRunId_When_Starting_Should_RejectResponse(string responseContent)
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, responseContent);

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateClient(handler).StartAsync(PipelineName, new Dictionary<string, object?>()));

            Assert.Contains("run identifier", exception.Message);
        }

        /// <summary>
        /// Verifies that a failed start request preserves the HTTP failure
        /// </summary>
        [Fact]
        public async Task Given_HttpFailure_When_Starting_Should_PropagateStatusCode()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.Forbidden, "{}");

            var exception = await Assert.ThrowsAsync<HttpRequestException>(() => CreateClient(handler).StartAsync(PipelineName, new Dictionary<string, object?>()));

            Assert.Equal(HttpStatusCode.Forbidden, exception.StatusCode);
        }

        /// <summary>
        /// Verifies that a terminal Synapse status is returned without waiting for a callback
        /// </summary>
        [Fact]
        public async Task Given_TerminalRun_When_Waiting_Should_ReturnStatus()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, $"{{\"runId\":\"{RunId}\",\"status\":\"Succeeded\"}}");

            var client = CreateClient(handler);

            var result = await client.WaitForCompletionAsync(RunId);

            Assert.Equal(RunId, result.RunId);
            Assert.Equal("Succeeded", result.Status);
            Assert.Equal(HttpMethod.Get, handler.Method);

            Assert.Equal($"https://{WorkspaceName}.dev.azuresynapse.net/pipelineruns/{RunId}?api-version={ApiVersion}", handler.RequestUri?.ToString());
        }

        /// <summary>
        /// Verifies every Synapse terminal state is returned without callback handling
        /// </summary>
        [Theory]
        [InlineData("Succeeded")]
        [InlineData("succeeded")]
        [InlineData("Failed")]
        [InlineData("Cancelled")]
        public async Task Given_AnyTerminalStatus_When_Waiting_Should_ReturnImmediately(string status)
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, $"{{\"runId\":\"{RunId}\",\"status\":\"{status}\"}}");

            var result = await CreateClient(handler).WaitForCompletionAsync(RunId);

            Assert.Equal(status, result.Status);
            Assert.Equal(1, handler.RequestCount);
        }

        /// <summary>
        /// Verifies that an empty run-state response cannot be treated as completion
        /// </summary>
        [Fact]
        public async Task Given_EmptyRunResponse_When_Waiting_Should_RejectResponse()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, "null");

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => CreateClient(handler).WaitForCompletionAsync(RunId));

            Assert.Contains(RunId, exception.Message);
        }

        /// <summary>
        /// Verifies that a failed status request preserves the HTTP failure
        /// </summary>
        [Fact]
        public async Task Given_HttpFailure_When_ReadingRun_Should_PropagateStatusCode()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.ServiceUnavailable, "{}");

            var exception = await Assert.ThrowsAsync<HttpRequestException>(() => CreateClient(handler).WaitForCompletionAsync(RunId));

            Assert.Equal(HttpStatusCode.ServiceUnavailable, exception.StatusCode);
        }

        /// <summary>
        /// Verifies that malformed workspace names cannot alter the Synapse host
        /// </summary>
        [Theory]
        [InlineData("")]
        [InlineData("workspace.example.test")]
        [InlineData("workspace/path")]
        [InlineData("workspace_name")]
        public async Task Given_InvalidWorkspaceName_When_Starting_Should_RejectConfiguration(string workspaceName)
        {
            var options = CreateOptions();
            options.Value.SynapseWorkspaceName = workspaceName;

            var client = CreateClient(new StubHttpMessageHandler(HttpStatusCode.OK, "{}"), options);

            await Assert.ThrowsAsync<InvalidOperationException>(() => client.StartAsync(PipelineName, new Dictionary<string, object?>()));
        }

        /// <summary>
        /// Verifies that non-positive polling values cannot create invalid wait behaviour
        /// </summary>
        [Theory]
        [InlineData(0, 60)]
        [InlineData(1, 0)]
        [InlineData(-1, 60)]
        [InlineData(1, -1)]
        public async Task Given_InvalidPollingValues_When_Starting_Should_RejectConfiguration(int pollIntervalSeconds, int timeoutSeconds)
        {
            var options = CreateOptions();
            options.Value.SynapsePollIntervalSeconds = pollIntervalSeconds;
            options.Value.SynapseRunTimeoutSeconds = timeoutSeconds;

            var client = CreateClient(new StubHttpMessageHandler(HttpStatusCode.OK, "{}"), options);

            await Assert.ThrowsAsync<InvalidOperationException>(() => client.StartAsync(PipelineName, new Dictionary<string, object?>()));
        }

        /// <summary>
        /// Verifies public argument guards fail before an HTTP request is attempted
        /// </summary>
        [Fact]
        public async Task Given_InvalidArguments_When_CallingClient_Should_RejectBeforeHttp()
        {
            var handler = new StubHttpMessageHandler(HttpStatusCode.OK, "{}");
            var client = CreateClient(handler);

            await Assert.ThrowsAsync<ArgumentException>(() => client.StartAsync(string.Empty, new Dictionary<string, object?>()));
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.StartAsync(PipelineName, null!));
            await Assert.ThrowsAsync<ArgumentException>(() => client.WaitForCompletionAsync(string.Empty));

            Assert.Equal(0, handler.RequestCount);
        }

        private static SynapsePipelineClient CreateClient(HttpMessageHandler handler)
        {
            return CreateClient(handler, CreateOptions());
        }

        private static SynapsePipelineClient CreateClient(HttpMessageHandler handler, IOptions<WorkdayConcurOptions> options)
        {
            return new SynapsePipelineClient(new HttpClient(handler), new TestTokenCredential(), options, new FakeTimeProvider());
        }

        private static IOptions<WorkdayConcurOptions> CreateOptions()
        {
            return Options.Create(new WorkdayConcurOptions
            {
                SynapseWorkspaceName = WorkspaceName,
                ConcurSynapseWorkspaceName = ConcurWorkspaceName,
                SynapsePollIntervalSeconds = 1,
                SynapseRunTimeoutSeconds = 60
            });
        }

        private sealed class TestTokenCredential : TokenCredential
        {
            public override AccessToken GetToken(TokenRequestContext requestContext, CancellationToken cancellationToken)
            {
                return new AccessToken(AccessToken, DateTimeOffset.MaxValue);
            }

            public override ValueTask<AccessToken> GetTokenAsync(TokenRequestContext requestContext, CancellationToken cancellationToken)
            {
                return ValueTask.FromResult(GetToken(requestContext, cancellationToken));
            }
        }

        private sealed class StubHttpMessageHandler : HttpMessageHandler
        {
            private readonly HttpStatusCode _statusCode;
            private readonly string _responseContent;

            public StubHttpMessageHandler(HttpStatusCode statusCode, string responseContent)
            {
                _statusCode = statusCode;
                _responseContent = responseContent;
            }

            public HttpMethod? Method { get; private set; }

            public Uri? RequestUri { get; private set; }

            public string? AuthorizationScheme { get; private set; }

            public string? AuthorizationParameter { get; private set; }

            public string Content { get; private set; } = string.Empty;

            public int RequestCount { get; private set; }

            protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                RequestCount++;
                Method = request.Method;
                RequestUri = request.RequestUri;
                AuthorizationScheme = request.Headers.Authorization?.Scheme;
                AuthorizationParameter = request.Headers.Authorization?.Parameter;
                Content = request.Content is null
                    ? string.Empty
                    : await request.Content.ReadAsStringAsync(cancellationToken);

                return new HttpResponseMessage(_statusCode)
                {
                    Content = new StringContent(_responseContent, Encoding.UTF8, "application/json")
                };
            }
        }
    }
}
