using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using STUK.TradeAccountService.Common.Salesforce.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceOrderServiceTests
    {
        private const string AccountExternalId = "ACCOUNT-001";
        private const string InvoiceNumber = "CON-100";
        private const string OrderItemExternalId = "CON-10000001";
        private const string PricebookId = "01s000000000001";
        private const string ProductCode = "PRODUCT-001";

        [Fact]
        public async Task Given_MappedOrder_When_UpsertDraftOrder_Should_UseInvoiceNumberAndDraftStatus()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            SetupNoExistingRecord(apiClient);
            SalesforceOrderRequest? capturedRequest = null;
            apiClient
                .Setup(client => client.UpsertAsync(
                    "Order",
                    "Invoice_Number__c",
                    InvoiceNumber,
                    It.IsAny<SalesforceOrderRequest>(),
                    It.IsAny<CancellationToken>()))
                .Callback<string, string, string, SalesforceOrderRequest, CancellationToken>(
                    (_, _, _, request, _) => capturedRequest = request)
                .ReturnsAsync(SuccessfulUpsert());
            var service = CreateService(apiClient.Object);
            var order = CreateOrder();
            order.Status = "Activated";

            await service.UpsertDraftOrderAsync(order);

            Assert.NotNull(capturedRequest);
            Assert.Equal("Draft", capturedRequest.Status);
            Assert.Equal(InvoiceNumber, capturedRequest.InvoiceNumber);
            Assert.Equal(AccountExternalId, capturedRequest.Account.AccountNumber);
            Assert.Equal(AccountExternalId, capturedRequest.AccountCode);
            Assert.Equal(PricebookId, capturedRequest.PricebookId);
            Assert.Equal(new DateOnly(2026, 7, 12), capturedRequest.EffectiveDate);
            Assert.Equal(20m, capturedRequest.TaxableTotal);
            Assert.Equal(4m, capturedRequest.TaxTotal);
            Assert.Equal(24m, capturedRequest.GrossPaymentTotal);
        }

        [Fact]
        public async Task Given_MappedOrderItem_When_UpsertOrderItem_Should_UseDeterministicExternalIdAndRelationships()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            SetupNoExistingRecord(apiClient);
            SalesforceOrderItemRequest? capturedRequest = null;
            apiClient
                .Setup(client => client.UpsertAsync(
                    "OrderItem",
                    "External_ID__c",
                    OrderItemExternalId,
                    It.IsAny<SalesforceOrderItemRequest>(),
                    It.IsAny<CancellationToken>()))
                .Callback<string, string, string, SalesforceOrderItemRequest, CancellationToken>(
                    (_, _, _, request, _) => capturedRequest = request)
                .ReturnsAsync(SuccessfulUpsert());
            var service = CreateService(apiClient.Object);

            await service.UpsertOrderItemAsync(CreateOrderItem());

            Assert.NotNull(capturedRequest);
            Assert.Equal(OrderItemExternalId, capturedRequest.ExternalId);
            Assert.Equal(InvoiceNumber, capturedRequest.Order.InvoiceNumber);
            Assert.Equal(ProductCode, capturedRequest.Product.ExternalId);
            Assert.Equal(ProductCode, capturedRequest.PricebookEntry.ExternalId);
            Assert.Equal("00001", capturedRequest.LineNumber);
            Assert.Equal(10m, capturedRequest.OrderLineNumber);
            Assert.Equal(9m, capturedRequest.OriginalOrderLineNumber);
            Assert.Equal("EA", capturedRequest.QuantityUomCode);
            Assert.Equal("Each", capturedRequest.PriceUomDescription);
            Assert.Equal("NR13 3JR", capturedRequest.JobPostcode);
            Assert.Equal(19.98m, capturedRequest.OrderProductTotal);
        }

        [Fact]
        public async Task Given_ExpectedOrderItemCount_When_FinaliseOrder_Should_ActivateOrder()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceOrderItemCount>(
                    It.Is<string>(query =>
                        query.Contains("COUNT(Id) ItemCount", StringComparison.Ordinal)
                        && query.Contains("FROM OrderItem", StringComparison.Ordinal)
                        && query.Contains("Order.Invoice_Number__c = 'CON-100'", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([new SalesforceOrderItemCount { ItemCount = 3 }]);
            SalesforceOrderStatusRequest? capturedRequest = null;
            apiClient
                .Setup(client => client.UpsertAsync(
                    "Order",
                    "Invoice_Number__c",
                    InvoiceNumber,
                    It.IsAny<SalesforceOrderStatusRequest>(),
                    It.IsAny<CancellationToken>()))
                .Callback<string, string, string, SalesforceOrderStatusRequest, CancellationToken>(
                    (_, _, _, request, _) => capturedRequest = request)
                .ReturnsAsync(SuccessfulUpsert());
            var service = CreateService(apiClient.Object);

            var result = await service.FinaliseOrderAsync(InvoiceNumber, 3);

            Assert.Equal(3, result.ExpectedLineCount);
            Assert.Equal(3, result.ActualLineCount);
            Assert.True(result.Activated);
            Assert.NotNull(capturedRequest);
            Assert.Equal("Activated", capturedRequest.Status);
        }

        [Fact]
        public async Task Given_IncompleteOrderItemCount_When_FinaliseOrder_Should_LeaveOrderDraft()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceOrderItemCount>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([new SalesforceOrderItemCount { ItemCount = 2 }]);
            var service = CreateService(apiClient.Object);

            var result = await service.FinaliseOrderAsync(InvoiceNumber, 3);

            Assert.Equal(3, result.ExpectedLineCount);
            Assert.Equal(2, result.ActualLineCount);
            Assert.False(result.Activated);
            apiClient.Verify(
                client => client.UpsertAsync(
                    "Order",
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<SalesforceOrderStatusRequest>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
        }

        [Fact]
        public async Task Given_InvoiceNumberContainsApostrophe_When_FinaliseOrder_Should_EscapeSoqlValue()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceOrderItemCount>(
                    It.Is<string>(query => query.Contains("CON\\'100", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([]);
            var service = CreateService(apiClient.Object);

            await service.FinaliseOrderAsync("CON'100", 1);

            apiClient.VerifyAll();
        }

        [Fact]
        public async Task Given_ZeroExpectedLines_When_FinaliseOrder_Should_RejectBeforeCallingSalesforce()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            var service = CreateService(apiClient.Object);

            await Assert.ThrowsAsync<ArgumentOutOfRangeException>(
                () => service.FinaliseOrderAsync(InvoiceNumber, 0));

            apiClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_OrderWithoutInvoiceNumber_When_UpsertDraftOrder_Should_RejectBeforeCallingSalesforce()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            var service = CreateService(apiClient.Object);
            var order = CreateOrder();
            order.InvoiceNumber = string.Empty;

            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.UpsertDraftOrderAsync(order));

            apiClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_OrderItemWithoutProductCode_When_UpsertOrderItem_Should_RejectBeforeCallingSalesforce()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            var service = CreateService(apiClient.Object);
            var orderItem = CreateOrderItem();
            orderItem.ProductCode = string.Empty;

            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.UpsertOrderItemAsync(orderItem));

            apiClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_ExistingOrder_When_UpsertDraftOrderUpdatesRecord_Should_ReturnExistingIdentifier()
        {
            const string existingOrderId = "801000000000002";
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceRecord>(
                    It.Is<string>(query => query.Contains($"Invoice_Number__c = '{InvoiceNumber}'", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([new SalesforceRecord { Id = existingOrderId }]);
            apiClient
                .Setup(client => client.UpsertAsync(
                    "Order",
                    "Invoice_Number__c",
                    InvoiceNumber,
                    It.IsAny<SalesforceOrderRequest>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = false });
            var service = CreateService(apiClient.Object);

            var result = await service.UpsertDraftOrderAsync(CreateOrder());

            Assert.Equal(existingOrderId, result.Id);
        }

        [Fact]
        public async Task Given_OrderCreatedByAnotherWorker_When_UpsertUpdatesOrder_Should_QueryForIdentifier()
        {
            const string existingOrderId = "801000000000002";
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .SetupSequence(client => client.QueryAllAsync<SalesforceRecord>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([])
                .ReturnsAsync([new SalesforceRecord { Id = existingOrderId }]);
            apiClient
                .Setup(client => client.UpsertAsync(
                    "Order",
                    "Invoice_Number__c",
                    InvoiceNumber,
                    It.IsAny<SalesforceOrderRequest>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = false });
            var service = CreateService(apiClient.Object);

            var result = await service.UpsertDraftOrderAsync(CreateOrder());

            Assert.Equal(existingOrderId, result.Id);
            apiClient.Verify(
                client => client.QueryAllAsync<SalesforceRecord>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()),
                Times.Exactly(2));
        }

        [Fact]
        public async Task Given_OrderItemCreatedByAnotherWorker_When_UpsertUpdatesOrderItem_Should_QueryForIdentifier()
        {
            const string existingOrderItemId = "802000000000002";
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .SetupSequence(client => client.QueryAllAsync<SalesforceRecord>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([])
                .ReturnsAsync([new SalesforceRecord { Id = existingOrderItemId }]);
            apiClient
                .Setup(client => client.UpsertAsync(
                    "OrderItem",
                    "External_ID__c",
                    OrderItemExternalId,
                    It.IsAny<SalesforceOrderItemRequest>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = false });
            var service = CreateService(apiClient.Object);

            var result = await service.UpsertOrderItemAsync(CreateOrderItem());

            Assert.Equal(existingOrderItemId, result.Id);
            apiClient.Verify(
                client => client.QueryAllAsync<SalesforceRecord>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()),
                Times.Exactly(2));
        }

        private static SalesforceOrderService CreateService(ISalesforceApiClient apiClient)
        {
            return new SalesforceOrderService(
                apiClient,
                Options.Create(new SalesforceOptions { PricebookId = PricebookId }));
        }

        private static SalesforceOrderProjection CreateOrder()
        {
            return new SalesforceOrderProjection
            {
                AccountExternalId = AccountExternalId,
                InvoiceNumber = InvoiceNumber,
                Status = "Draft",
                OrderType = "Invoice",
                EffectiveDate = new DateOnly(2026, 7, 12),
                InvoiceDate = new DateOnly(2026, 7, 12),
                TaxPointDate = new DateOnly(2026, 7, 11),
                CreditTerms = "30 Days",
                TaxableTotal = 20m,
                TaxTotal = 4m,
                GrossPaymentTotal = 24m,
                ExpectedLineCount = 1
            };
        }

        private static SalesforceOrderItemProjection CreateOrderItem()
        {
            return new SalesforceOrderItemProjection
            {
                ExternalId = OrderItemExternalId,
                InvoiceNumber = InvoiceNumber,
                ProductCode = ProductCode,
                LineNumber = "00001",
                OrderLineNumber = 10m,
                OriginalOrderLineNumber = 9m,
                DeliveryNoteNumber = "DEL-100",
                DeliveryNoteLineNumber = 1m,
                BuyersOrderNumber = "BUY-100",
                OrderReference = "SUP-100",
                DespatchDate = new DateOnly(2026, 7, 11),
                CodeForDelivery = "DEL",
                OrderType = "SL",
                OrderCategory = "N",
                DeliveryMethod = "S",
                PartAnalysisCode = "PA",
                IsSpecialProduct = false,
                Description = "Product description",
                Quantity = 2m,
                QuantityUomCode = "EA",
                QuantityUomDescription = "Each",
                UnitPrice = 9.99m,
                PriceUomCode = "EA",
                PriceUomDescription = "Each",
                PercentageDiscount = 0m,
                TaxRateCode = "S",
                TaxRate = 20m,
                TaxValue = 4m,
                OrderProductTotal = 19.98m,
                JobNumber = "JOB-1",
                JobAddressLine = "1 Test Street",
                JobStreet = "Test Street",
                JobCity = "Norwich",
                JobState = "Norfolk",
                JobPostcode = "NR13 3JR",
                ContractNumber = "CONTRACT-1",
                BuyerLocationCode = "LOC-1",
                Operative = "OP-1",
                SiteCode = "SITE-1",
                PlotNumber = "PLOT-1",
                VehicleRegistration = "AB12 CDE",
                HouseType = "Detached",
                ProductGroup = "GROUP-1",
                OrderAuthorised = true
            };
        }

        private static SalesforceUpsertResult SuccessfulUpsert()
        {
            return new SalesforceUpsertResult
            {
                Success = true,
                Created = true,
                Id = "801000000000001"
            };
        }

        private static void SetupNoExistingRecord(Mock<ISalesforceApiClient> apiClient)
        {
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceRecord>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([]);
        }
    }
}
