﻿using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;
namespace STUK.TradeAccountService.Tests.Services
{
    public class ColumbusInvoiceDownloadServiceTests
    {
        private readonly Mock<IColumbusWebService> _ws = new(MockBehavior.Strict);
        private readonly Mock<IDbExecutor> _db = new(MockBehavior.Strict);
        private readonly Mock<IAppInsightsLoggerHelper> _logger = new(MockBehavior.Loose);

        private ColumbusInvoiceDownloadService CreateService()
        {
            var config = new ConfigurationBuilder()
    .AddInMemoryCollection(
        new Dictionary<string, string>
        {
            ["Columbus:Username"] = "API-SalesLedgerUser",
            ["Columbus:Password"] = "SLTESTING",
            ["Columbus:MaxRetryAttempts"] = "3",
            ["Columbus:RetryDelaySeconds"] = "0",
            ["Columbus:MaxDegreeOfParallelism"] = "1",
            ["BlobStorage:StorageAccountUrl"] = "https://blob",
            ["BlobStorage:InvoiceContainerName"] = "invoice"
        }.Select(kvp => new KeyValuePair<string, string?>(kvp.Key, kvp.Value))
    )
    .Build();

            return new ColumbusInvoiceDownloadService(
                _logger.Object, _db.Object, _ws.Object, config);
        }

        private ColumbusInvoiceHeader CreateInvoice() => new()
        {
            Id = Guid.NewGuid(),
            BranchCode = "307",
            CustomerAccount = "M137789",
            StandardInvoiceNo = "10617389",
            InvoiceDateTime = DateTime.ParseExact("12/11/2025", "dd/MM/yyyy", CultureInfo.InvariantCulture)
        };

        [Fact]
        public async Task Should_Process_Invoice_Successfully()
        {
            var service = CreateService();
            var invoice = CreateInvoice();

            _ws.Setup(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusOpenSessionResult
                {
                    SessionId = "S1",
                    ErrorNumber = 0,
                    Archive = new ColumbusArchiveInfo { ArchiveId = 1 }
                });

            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), null))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult
                {
                    OperationStatus = "COMPLETE",
                    TotalDocuments = 1
                });

            _ws.Setup(x => x.BeginPageOperationAsync(It.IsAny<string>(), 1))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetPageResultsAndUploadToBlobAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse
                {
                    OperationStatus = "COMPLETE",
                    ErrorNumber = 0,
                    BlobUrl = "url",
                    CalculatedFileName = "file.pdf"
                });

            _db.Setup(x => x.ExecuteWithOutputAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(1);

            _ws.Setup(x => x.CloseSessionAsync("S1"))
                .ReturnsAsync(0);

            await service.DownloadAndSyncInvoicesAsync(); // no invoices yet

            // simulate DB returning invoice
            _db.Setup(x => x.ExecuteListAsync<ColumbusInvoiceHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusInvoiceHeader> { invoice });

            await service.DownloadAndSyncInvoicesAsync();

            _ws.Verify(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            _ws.Verify(x => x.CloseSessionAsync("S1"), Times.Once);
        }

        [Fact]
        public async Task Should_Exit_When_No_Invoices()
        {
            var service = CreateService();

            _db.Setup(x => x.ExecuteListAsync<ColumbusInvoiceHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusInvoiceHeader>());

            await service.DownloadAndSyncInvoicesAsync();

            _ws.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Should_Stop_When_DB_Fails()
        {
            var service = CreateService();

            _db.Setup(x => x.ExecuteListAsync<ColumbusInvoiceHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ThrowsAsync(new Exception());

            await service.DownloadAndSyncInvoicesAsync();

            _ws.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Should_Skip_When_OpenSession_Throws()
        {
            var service = CreateService();
            var invoice = CreateInvoice();

            _db.Setup(x => x.ExecuteListAsync<ColumbusInvoiceHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusInvoiceHeader> { invoice });

            _ws.Setup(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new Exception());

            await service.DownloadAndSyncInvoicesAsync();
        }

        [Fact]
        public async Task Should_Skip_When_OpenSession_ErrorNumber()
        {
            var service = CreateService();
            var invoice = CreateInvoice();

            _db.Setup(x => x.ExecuteListAsync<ColumbusInvoiceHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusInvoiceHeader> { invoice });

            _ws.Setup(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusOpenSessionResult { ErrorNumber = 10 });

            await service.DownloadAndSyncInvoicesAsync();
        }

        [Fact]
        public async Task Should_Stop_When_BeginSearch_Fails()
        {
            var service = CreateService();
            var invoice = CreateInvoice();

            SetupOpenSession();

            _ws.Setup(x => x.BeginSearchOperationAsync(
                It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((1, "error"));

            SetupInvoices(invoice);

            await service.DownloadAndSyncInvoicesAsync();
        }

        [Fact]
        public async Task Should_Stop_When_No_Documents_Found()
        {
            var service = CreateService();
            var invoice = CreateInvoice();

            SetupOpenSession();

            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult { TotalDocuments = 0, OperationStatus = "COMPLETE" });

            SetupInvoices(invoice);

            await service.DownloadAndSyncInvoicesAsync();
        }

        [Fact]
        public async Task Should_Retry_When_Search_Active()
        {
            var service = CreateService();
            var invoice = CreateInvoice();

            SetupOpenSession();

            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((0, null));

            var sequence = new MockSequence();

            _ws.InSequence(sequence)
                .Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult { OperationStatus = "ACTIVE" });

            _ws.InSequence(sequence)
                .Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult { OperationStatus = "COMPLETE", TotalDocuments = 1 });

            SetupPageSuccess();
            SetupInvoices(invoice);

            await service.DownloadAndSyncInvoicesAsync();
        }

        [Fact]
        public async Task Should_Retry_Page_When_Active()
        {
            var service = CreateService();
            var invoice = CreateInvoice();

            SetupOpenSession();
            SetupSearchSuccess();

            _ws.Setup(x => x.BeginPageOperationAsync(It.IsAny<string>(), 1))
                .ReturnsAsync((0, null));

            var seq = new MockSequence();

            _ws.InSequence(seq)
                .Setup(x => x.GetPageResultsAndUploadToBlobAsync(It.IsAny<string>(),
                    It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                    It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(),
                    It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse { OperationStatus = "ACTIVE" });

            _ws.InSequence(seq)
                .Setup(x => x.GetPageResultsAndUploadToBlobAsync(It.IsAny<string>(),
                    It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                    It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(),
                    It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse { OperationStatus = "COMPLETE", ErrorNumber = 0 });

            SetupInvoices(invoice);
            SetupDbUpdate();
            SetupCloseSession();

            await service.DownloadAndSyncInvoicesAsync();
        }


        private void SetupInvoices(ColumbusInvoiceHeader invoice)
        {
            _db.Setup(x => x.ExecuteListAsync<ColumbusInvoiceHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusInvoiceHeader> { invoice });
        }

        private void SetupOpenSession()
        {
            _ws.Setup(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusOpenSessionResult
                {
                    SessionId = "S1",
                    ErrorNumber = 0,
                    Archive = new ColumbusArchiveInfo { ArchiveId = 1 }
                });
        }

        private void SetupSearchSuccess()
        {
            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult { TotalDocuments = 1, OperationStatus = "COMPLETE" });
        }

        private void SetupPageSuccess()
        {
            _ws.Setup(x => x.BeginPageOperationAsync(It.IsAny<string>(), 1))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetPageResultsAndUploadToBlobAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), 1, It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse { OperationStatus = "COMPLETE", ErrorNumber = 0 });

            SetupDbUpdate();
            SetupCloseSession();
        }

        private void SetupDbUpdate()
        {
            _db.Setup(x => x.ExecuteWithOutputAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(1);
        }

        private void SetupCloseSession()
        {
            _ws.Setup(x => x.CloseSessionAsync(It.IsAny<string>()))
                .ReturnsAsync(0);
        }
    }
}