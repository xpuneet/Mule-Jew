using Microsoft.Extensions.DependencyInjection;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedSalesDatabaseBindingTests
    {
        [Fact]
        public void Given_Consolidated_Sales_Data_Services_When_Resolved_Should_Use_TradeAccountServiceDb()
        {
            var services = new ServiceCollection();
            services.AddKeyedSingleton("AccountDb", Mock.Of<IDbExecutor>());
            services.AddTransient<ConsolidatedInvoiceDataService>();
            services.AddTransient<ConsolidatedSalesFileDataService>();
            services.AddTransient<ConsolidatedSalesExportDataService>();
            services.AddTransient<SalesforceSyncDataService>();

            using var serviceProvider = services.BuildServiceProvider();

            Assert.NotNull(serviceProvider.GetRequiredService<ConsolidatedInvoiceDataService>());
            Assert.NotNull(serviceProvider.GetRequiredService<ConsolidatedSalesFileDataService>());
            Assert.NotNull(serviceProvider.GetRequiredService<ConsolidatedSalesExportDataService>());
            Assert.NotNull(serviceProvider.GetRequiredService<SalesforceSyncDataService>());
        }

        [Fact]
        public void Given_Invoice_Reconciliation_When_Resolved_Should_Use_AccountDb_For_Work_And_OrderDb_For_Invoices()
        {
            var services = new ServiceCollection();
            services.AddKeyedSingleton("AccountDb", Mock.Of<IDbExecutor>());
            services.AddKeyedSingleton("OrderDb", Mock.Of<IDbExecutor>());
            services.AddTransient<InvoiceReconciliationDataService>();

            using var serviceProvider = services.BuildServiceProvider();

            Assert.NotNull(serviceProvider.GetRequiredService<InvoiceReconciliationDataService>());
        }
    }
}
