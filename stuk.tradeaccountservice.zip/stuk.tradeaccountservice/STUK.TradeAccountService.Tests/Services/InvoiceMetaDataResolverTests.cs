﻿using Microsoft.Extensions.Options;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Handlers;

namespace STUK.TradeAccountService.Tests.Services
{
    public class InvoiceMetaDataResolverTests
    {
        private readonly Mock<IDbExecutor> _dbExecutorMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly Mock<IColumbusInvoiceDownloadService> _columbusMock;
        private readonly InvoiceMetaDataResolver _resolver;

        public InvoiceMetaDataResolverTests()
        {
            _dbExecutorMock = new Mock<IDbExecutor>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();
            _columbusMock = new Mock<IColumbusInvoiceDownloadService>();

            var downloadSettings = new DownloadSettings
            {
                ["Invoice"] = new DocumentTypeDownloadSettings
                {
                    ContainerName = "invoicetest",
                    FilePrepareUrl = null
                }
            };

            var optionsMock = new Mock<IOptions<DownloadSettings>>();
            optionsMock.Setup(o => o.Value).Returns(downloadSettings);

            _resolver = new InvoiceMetaDataResolver(
                _dbExecutorMock.Object,
                optionsMock.Object,
                _loggerMock.Object,
                _columbusMock.Object);
        }

        #region GetMetadata

        [Fact]
        public async Task GetMetadata_DbReturnsNull_ReturnsNull()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<InvoiceHeaderMetadata>(
                    StoredProcedures.GetInvoiceMetadataByStandardInvoiceNo,
                    It.IsAny<object>()))
                .ReturnsAsync((InvoiceHeaderMetadata?)null);

            // Act
            var result = await _resolver.GetMetadataAsync("INV-001", "123");

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetMetadata_DbReturnsResult_ReturnsMappedBlobUri()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<InvoiceHeaderMetadata>(
                    StoredProcedures.GetInvoiceMetadataByStandardInvoiceNo,
                    It.IsAny<object>()))
                .ReturnsAsync(new InvoiceHeaderMetadata
                {
                    BlobUri = "2026/03/acct-A1PA010_2026-03b_invoice.pdf",
                    CalculatedFileName = "acct-A1PA010_2026-03b_invoice.pdf"
                });

            // Act
            var result = await _resolver.GetMetadataAsync("INV-001", "123");

            // Assert
            Assert.NotNull(result);
            Assert.Equal("2026/03/acct-A1PA010_2026-03b_invoice.pdf", result.BlobUri);
        }

        [Fact]
        public async Task GetMetadata_DbReturnsResult_ReturnsMappedFileName()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<InvoiceHeaderMetadata>(
                    StoredProcedures.GetInvoiceMetadataByStandardInvoiceNo,
                    It.IsAny<object>()))
                .ReturnsAsync(new InvoiceHeaderMetadata
                {
                    BlobUri = "2026/03/acct-A1PA010_2026-03b_invoice.pdf",
                    CalculatedFileName = "acct-A1PA010_2026-03b_invoice.pdf"
                });

            // Act
            var result = await _resolver.GetMetadataAsync("INV-001", "123");

            // Assert
            Assert.NotNull(result);
            Assert.Equal("acct-A1PA010_2026-03b_invoice.pdf", result.FileName);
        }

        [Fact]
        public async Task GetMetadata_DbReturnsNull_LogsWarning()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<InvoiceHeaderMetadata>(
                    StoredProcedures.GetInvoiceMetadataByStandardInvoiceNo,
                    It.IsAny<object>()))
                .ReturnsAsync((InvoiceHeaderMetadata?)null);

            // Act
            await _resolver.GetMetadataAsync("INV-001", "123");

            // Assert
            _loggerMock.Verify(l =>
                    l.LogWarning(
                    It.Is<string>(s =>
                    s.Contains("No metadata found", StringComparison.OrdinalIgnoreCase)),
                    It.IsAny<string>(),
                    It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetMetadata_CallsCorrectStoredProcedure()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<InvoiceHeaderMetadata>(
                    StoredProcedures.GetInvoiceMetadataByStandardInvoiceNo,
                    It.IsAny<object>()))
                .ReturnsAsync((InvoiceHeaderMetadata?)null);

            // Act
            await _resolver.GetMetadataAsync("INV-001", "123");

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<InvoiceHeaderMetadata>(
                    StoredProcedures.GetInvoiceMetadataByStandardInvoiceNo,
                    It.IsAny<object>()),
                Times.Once);
        }

        #endregion

        #region RequestDocument

        [Fact]
        public async Task RequestDocument_CallsColumbusDownloadService()
        {
            // Act
            await _resolver.RequestDocumentAsync("INV-001", "123");

            // Assert
            _columbusMock.Verify(c =>
                c.DownloadInvoiceByStandardInvoiceNumberAndBranchCodeAsync("INV-001", "123"),
                Times.Once);
        }

        #endregion

        #region GetCacheByIdentifier

        [Fact]
        public async Task GetCacheByIdentifier_CallsCorrectStoredProcedure()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            await _resolver.GetCacheByIdentifierAsync("INV-001", "123");

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task GetCacheByIdentifier_DbReturnsEntry_ReturnsCacheEntry()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = token,
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Ready"
                });

            // Act
            var result = await _resolver.GetCacheByIdentifierAsync("INV-001", "123");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(token, result.Token);
            Assert.Equal("INV-001", result.Identifier);
        }

        [Fact]
        public async Task GetCacheByIdentifier_DbReturnsNull_ReturnsNull()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            var result = await _resolver.GetCacheByIdentifierAsync("INV-001", "123");

            // Assert
            Assert.Null(result);
        }

        #endregion

        #region GetCacheByToken

        [Fact]
        public async Task GetCacheByToken_CallsCorrectStoredProcedure()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            await _resolver.GetCacheByTokenAsync(token);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task GetCacheByToken_DbReturnsEntry_ReturnsCacheEntry()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = token,
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Ready"
                });

            // Act
            var result = await _resolver.GetCacheByTokenAsync(token);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(token, result.Token);
        }

        [Fact]
        public async Task GetCacheByToken_DbReturnsNull_ReturnsNull()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            var result = await _resolver.GetCacheByTokenAsync(Guid.NewGuid());

            // Assert
            Assert.Null(result);
        }

        #endregion

        #region InsertCache

        [Fact]
        public async Task InsertCache_CallsCorrectStoredProcedure()
        {
            // Arrange

            var expectedToken = Guid.NewGuid();
            var expiresOn = DateTimeOffset.Now;
            var expando = (IDictionary<string, object?>)new System.Dynamic.ExpandoObject();
            expando["token"] = expectedToken;
            expando["expiresOn"] = expiresOn;

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<dynamic>(
                    StoredProcedures.InsertDocumentDownloadCache,
                    It.IsAny<object>()))
                .ReturnsAsync((object)expando);

            // Act
            await _resolver.InsertCacheAsync("INV-001", "123", "Ready");

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<dynamic>(
                    StoredProcedures.InsertDocumentDownloadCache,
                    It.IsAny<object>()),
                Times.Once);
        }

        #endregion

        #region DeleteCacheByToken

        [Fact]
        public async Task DeleteCacheByToken_CallsCorrectStoredProcedure()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<int>(
                    StoredProcedures.DeleteDocumentDownloadCacheByToken,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            // Act
            await _resolver.DeleteCacheByTokenAsync(token);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<int>(
                    StoredProcedures.DeleteDocumentDownloadCacheByToken,
                    It.IsAny<object>()),
                Times.Once);
        }

        #endregion

        #region Properties

        [Fact]
        public void DocumentType_ReturnsInvoice()
        {
            Assert.Equal("Invoice", _resolver.DocumentType);
        }

        [Fact]
        public void DefaultFileName_ReturnsInvoicePdf()
        {
            Assert.Equal("Invoice.pdf", _resolver.DefaultFileName);
        }

        [Fact]
        public void ContainerName_ReturnsConfiguredContainerName()
        {
            Assert.Equal("invoicetest", _resolver.ContainerName);
        }

        [Fact]
        public void ParseIdentifier_ReturnsSameStringValue()
        {
            var result = _resolver.ParseIdentifier("INV-001");

            Assert.Equal("INV-001", result);
        }

        #endregion
    }
}
