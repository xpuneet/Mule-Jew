using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests Mule-free Synapse transformation execution and output selection
    /// </summary>
    public class WorkdayConcurTransformationServiceTests
    {
        private const string ContainerName = "stukconcurprd";
        private const string PipelineName = "configured-transform-pipeline";
        private const string SynapseRunId = "transform-run";

        private static readonly Guid CorrelationId = new("10000000-0000-0000-0000-000000000001");
        private static readonly DateTimeOffset Now = new(2026, 9, 5, 8, 30, 0, TimeSpan.Zero);
        private static readonly Uri BlobEndpoint = new("https://storage.blob.core.windows.net");

        private readonly Mock<IConcurSynapsePipelineClient> _synapseClient = new(MockBehavior.Strict);
        private readonly Mock<IWorkdayConcurBlobClient> _blobClient = new(MockBehavior.Strict);

        /// <summary>
        /// Verifies that the Mule-free parent receives the existing correlation parameter
        /// </summary>
        [Fact]
        public async Task Given_ValidConfiguration_When_Starting_Should_StartMuleFreeParent()
        {
            _synapseClient
                .Setup(x => x.StartAsync(
                    PipelineName,
                    It.Is<IReadOnlyDictionary<string, object?>>(parameters =>
                        parameters.Count == 1
                        && Equals(parameters["transactionCorrelationId"], CorrelationId.ToString("D"))),
                    default))
                .ReturnsAsync(SynapseRunId);

            var result = await CreateService().StartAsync(CorrelationId);

            Assert.Equal(SynapseRunId, result.SynapseRunId);
            Assert.Equal("InProgress", result.Status);
            Assert.Equal(Now, result.StartedOn);
            _synapseClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that every non-directory output returned by the Blob boundary is checkpointed
        /// </summary>
        [Fact]
        public async Task Given_SuccessfulPipelineWithOutput_When_Completing_Should_CheckpointAllFiles()
        {
            var checkpoint = CreateCheckpoint();
            var files = new[]
            {
                new WorkdayConcurFileIdentity { Path = "stukconcurprd/output/employee.txt", ContentLength = 10 },
                new WorkdayConcurFileIdentity { Path = "stukconcurprd/output/list.txt", ContentLength = 20 }
            };

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync(SynapseRunId, default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = SynapseRunId, Status = "Succeeded" });

            _blobClient
                .Setup(x => x.ListFilesAsync(BlobEndpoint, ContainerName, "output", default))
                .ReturnsAsync(files);

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("Succeeded", result.Status);
            Assert.Equal(files, result.OutputFiles);
            Assert.Equal(Now, result.CompletedOn);
            Assert.Null(result.FailureMessage);
            _synapseClient.VerifyAll();
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that an empty output path cannot advance the integration
        /// </summary>
        [Fact]
        public async Task Given_SuccessfulPipelineWithoutOutput_When_Completing_Should_FailValidation()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync(SynapseRunId, default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = SynapseRunId, Status = "Succeeded" });

            _blobClient
                .Setup(x => x.ListFilesAsync(BlobEndpoint, ContainerName, "output", default))
                .ReturnsAsync(Array.Empty<WorkdayConcurFileIdentity>());

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("ValidationFailed", result.Status);
            Assert.Empty(result.OutputFiles);
            Assert.Equal("The successful Synapse Concur transformation produced no files under 'output'", result.FailureMessage);
            _synapseClient.VerifyAll();
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that a failed parent pipeline does not inspect or accept output files
        /// </summary>
        [Fact]
        public async Task Given_FailedPipeline_When_Completing_Should_ReturnFailureWithoutListingOutput()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync(SynapseRunId, default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = SynapseRunId, Status = "Failed", Message = "Child failed" });

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("Failed", result.Status);
            Assert.Equal("Child failed", result.FailureMessage);
            _blobClient.VerifyNoOtherCalls();
            _synapseClient.VerifyAll();
        }

        /// <summary>
        /// Verifies a failed pipeline without diagnostic text receives a stable failure message
        /// </summary>
        [Fact]
        public async Task Given_FailedPipelineWithoutMessage_When_Completing_Should_CreateFailureMessage()
        {
            var checkpoint = CreateCheckpoint();

            _synapseClient
                .Setup(x => x.WaitForCompletionAsync(SynapseRunId, default))
                .ReturnsAsync(new SynapsePipelineRun { RunId = SynapseRunId, Status = "Failed" });

            var result = await CreateService().CompleteAsync(checkpoint);

            Assert.Equal("Synapse Concur transformation ended with status 'Failed'", result.FailureMessage);
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies public start and completion arguments are validated before external calls
        /// </summary>
        [Fact]
        public async Task Given_InvalidArguments_When_Processing_Should_RejectBeforeExternalCalls()
        {
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().StartAsync(Guid.Empty));
            await Assert.ThrowsAsync<ArgumentNullException>(() => CreateService().CompleteAsync(null!));

            var checkpoint = CreateCheckpoint();
            checkpoint.SynapseRunId = string.Empty;

            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().CompleteAsync(checkpoint));

            _synapseClient.VerifyNoOtherCalls();
            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies all environment-specific transformation settings before Synapse is called
        /// </summary>
        [Theory]
        [InlineData("", "https://storage.blob.core.windows.net", ContainerName, typeof(ArgumentException))]
        [InlineData(PipelineName, "", ContainerName, typeof(InvalidOperationException))]
        [InlineData(PipelineName, "http://storage.blob.core.windows.net", ContainerName, typeof(InvalidOperationException))]
        [InlineData(PipelineName, "https://storage.blob.core.windows.net", "", typeof(ArgumentException))]
        public async Task Given_InvalidOptions_When_Starting_Should_RejectConfiguration(string pipeline, string endpoint, string container, Type exceptionType)
        {
            var options = new WorkdayConcurOptions
            {
                ConcurSynapseWorkspaceName = "synw-concur-transform",
                ConcurTransformationPipelineName = pipeline,
                ConcurBlobServiceEndpoint = endpoint,
                ConcurBlobContainerName = container
            };

            await Assert.ThrowsAsync(exceptionType, () => CreateService(options).StartAsync(CorrelationId));

            _synapseClient.VerifyNoOtherCalls();
        }

        private WorkdayConcurTransformationService CreateService()
        {
            return CreateService(new WorkdayConcurOptions
            {
                ConcurSynapseWorkspaceName = "synw-concur-transform",
                ConcurTransformationPipelineName = PipelineName,
                ConcurBlobServiceEndpoint = BlobEndpoint.ToString(),
                ConcurBlobContainerName = ContainerName
            });
        }

        private WorkdayConcurTransformationService CreateService(WorkdayConcurOptions options)
        {
            return new WorkdayConcurTransformationService(_synapseClient.Object, _blobClient.Object, Options.Create(options), new FakeTimeProvider(Now));
        }

        private static WorkdayConcurTransformationCheckpoint CreateCheckpoint()
        {
            return new WorkdayConcurTransformationCheckpoint
            {
                SynapseRunId = SynapseRunId,
                StartedOn = Now,
                Status = "InProgress"
            };
        }
    }
}
