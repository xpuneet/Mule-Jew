using Org.BouncyCastle.Bcpg;
using Org.BouncyCastle.Bcpg.OpenPgp;
using PgpCore;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the OpenPGP contract replacing Concur SAPI encryption
    /// </summary>
    public class ConcurPgpEncryptionServiceTests
    {
        private const string CurrentConcurMasterKeyId = "BAA83C168C51C89E";
        private const string InternalFileName = "stream";
        private const string Password = "test-passphrase";
        private const string Plaintext = "employee,ledger\r\n1001,SGBD\r\n";
        private const string Username = "concur-test@example.test";

        private static readonly Lazy<Task<KeyMaterial>> PrimaryKeyMaterial = new(CreateKeyMaterialAsync);
        private static readonly Lazy<Task<KeyMaterial>> SecondaryKeyMaterial = new(CreateKeyMaterialAsync);

        /// <summary>
        /// Verifies every Mule PGP output setting exposed by the Mule 1.3.14 operation contract
        /// </summary>
        [Fact]
        public async Task Given_ConcurPublicKey_When_Encrypting_Should_UseMulePgpContract()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;

            var encrypted = await EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), keyMaterial.PublicKey, keyMaterial.KeyId);

            using var encryptedStream = new MemoryStream(encrypted);
            using var inspector = CreatePgpWithPrivateKey(keyMaterial);

            var inspection = await inspector.InspectAsync(encryptedStream);

            Assert.True(inspection.IsArmored);
            Assert.True(inspection.IsCompressed);
            Assert.True(inspection.IsEncrypted);
            Assert.True(inspection.IsIntegrityProtected);
            Assert.Equal(SymmetricKeyAlgorithmTag.Aes256, inspection.SymmetricKeyAlgorithm);
            Assert.Equal(InternalFileName, inspection.FileName);
            Assert.Equal(CompressionAlgorithmTag.Zip, GetCompressionAlgorithm(encrypted, keyMaterial.PrivateKey));
        }

        /// <summary>
        /// Verifies that the current Mule repository Concur key is accepted and its configured fingerprint is selected
        /// </summary>
        [Fact]
        public async Task Given_CurrentConcurPublicKey_When_Encrypting_Should_TargetConfiguredFingerprint()
        {
            var publicKey = await File.ReadAllTextAsync(GetFixturePath("ConcurCurrentPublicKey.asc"));

            var encrypted = await EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), publicKey, CurrentConcurMasterKeyId);

            var recipientKeyIds = GetRecipientKeyIds(encrypted);

            Assert.Single(recipientKeyIds);
            Assert.Equal(CurrentConcurMasterKeyId, FormatKeyId(recipientKeyIds.Single()));
        }

        /// <summary>
        /// Verifies that encryption and decryption preserve arbitrary source bytes without text conversion
        /// </summary>
        [Fact]
        public async Task Given_BinaryContent_When_EncryptingAndDecrypting_Should_PreserveEveryByte()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var content = Enumerable.Range(0, 1024).Select(index => (byte)(index % 256)).ToArray();

            var encrypted = await EncryptAsync(content, keyMaterial.PublicKey, keyMaterial.KeyId);
            var decrypted = await DecryptAsync(encrypted, keyMaterial);

            Assert.Equal(content, decrypted);
        }

        /// <summary>
        /// Verifies that the implementation does not normalise Concur line endings or UTF-8 content
        /// </summary>
        [Fact]
        public async Task Given_ConcurTextContent_When_EncryptingAndDecrypting_Should_PreserveExactContent()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var content = Encoding.UTF8.GetBytes("employee,name\r\n1001,Renée\r\n1002,東京\r\n");

            var encrypted = await EncryptAsync(content, keyMaterial.PublicKey, keyMaterial.KeyId);
            var decrypted = await DecryptAsync(encrypted, keyMaterial);

            Assert.Equal(content, decrypted);
        }

        /// <summary>
        /// Verifies that a representative large file remains byte-identical after streamed encryption and decryption
        /// </summary>
        [Fact]
        public async Task Given_LargeContent_When_EncryptingAndDecrypting_Should_PreserveEveryByte()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var content = new byte[1024 * 1024];
            new Random(12087).NextBytes(content);

            var encrypted = await EncryptAsync(content, keyMaterial.PublicKey, keyMaterial.KeyId);
            var decrypted = await DecryptAsync(encrypted, keyMaterial);

            Assert.Equal(content, decrypted);
        }

        /// <summary>
        /// Verifies that an empty source still produces a valid decryptable OpenPGP message
        /// </summary>
        [Fact]
        public async Task Given_EmptyContent_When_EncryptingAndDecrypting_Should_ReturnEmptyContent()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;

            var encrypted = await EncryptAsync(Array.Empty<byte>(), keyMaterial.PublicKey, keyMaterial.KeyId);
            var decrypted = await DecryptAsync(encrypted, keyMaterial);

            Assert.Empty(decrypted);
        }

        /// <summary>
        /// Verifies that OpenPGP randomness prevents deterministic ciphertext while preserving the same plaintext
        /// </summary>
        [Fact]
        public async Task Given_SameContentAndKey_When_EncryptingTwice_Should_CreateDifferentDecryptableCiphertext()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var content = Encoding.UTF8.GetBytes(Plaintext);

            var first = await EncryptAsync(content, keyMaterial.PublicKey, keyMaterial.KeyId);
            var second = await EncryptAsync(content, keyMaterial.PublicKey, keyMaterial.KeyId);

            Assert.NotEqual(first, second);
            Assert.Equal(content, await DecryptAsync(first, keyMaterial));
            Assert.Equal(content, await DecryptAsync(second, keyMaterial));
        }

        /// <summary>
        /// Verifies that plaintext is not exposed in the ASCII-armored encrypted output
        /// </summary>
        [Fact]
        public async Task Given_Plaintext_When_Encrypting_Should_NotExposePlaintextInOutput()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;

            var encrypted = await EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), keyMaterial.PublicKey, keyMaterial.KeyId);
            var armored = Encoding.ASCII.GetString(encrypted);

            Assert.StartsWith("-----BEGIN PGP MESSAGE-----", armored);
            Assert.DoesNotContain(Plaintext, armored, StringComparison.Ordinal);
        }

        /// <summary>
        /// Verifies that only the holder of the selected recipient private key can decrypt the message
        /// </summary>
        [Fact]
        public async Task Given_DifferentPrivateKey_When_Decrypting_Should_RejectMessage()
        {
            var recipient = await PrimaryKeyMaterial.Value;
            var otherParty = await SecondaryKeyMaterial.Value;
            var encrypted = await EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), recipient.PublicKey, recipient.KeyId);

            await Assert.ThrowsAsync<NoDecryptionKeyException>(() => DecryptAsync(encrypted, otherParty));
        }

        /// <summary>
        /// Verifies that the Mule-compatible modification detection code rejects altered encrypted content
        /// </summary>
        [Fact]
        public async Task Given_TamperedCiphertext_When_Decrypting_Should_FailIntegrityCheck()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var encrypted = await EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), keyMaterial.PublicKey, keyMaterial.KeyId);
            var tampered = TamperEncryptedPacket(encrypted);

            var exception = await Record.ExceptionAsync(() => DecryptAsync(tampered, keyMaterial));

            Assert.NotNull(exception);
            Assert.True(exception is MessageIntegrityException or InvalidDataException or PgpException);
        }

        /// <summary>
        /// Verifies that configuration cannot silently encrypt with a different key from the expected Concur key
        /// </summary>
        [Fact]
        public async Task Given_KeyRingWithoutExpectedKey_When_Encrypting_Should_RejectConfiguration()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), keyMaterial.PublicKey, "0000000000000001"));

            Assert.Equal("The configured Concur PGP keyring does not contain key '0000000000000001'", exception.Message);
        }

        /// <summary>
        /// Verifies that the hexadecimal key identifier accepts the format used by deployment configuration
        /// </summary>
        [Fact]
        public async Task Given_LowercasePrefixedKeyId_When_Encrypting_Should_SelectExpectedKey()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var configuredKeyId = $"0x{keyMaterial.KeyId.ToLowerInvariant()}";

            var encrypted = await EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), keyMaterial.PublicKey, configuredKeyId);
            var decrypted = await DecryptAsync(encrypted, keyMaterial);

            Assert.Equal(Plaintext, Encoding.UTF8.GetString(decrypted));
        }

        /// <summary>
        /// Verifies that a non-hexadecimal Concur key identifier is rejected before encryption
        /// </summary>
        [Fact]
        public async Task Given_NonHexadecimalKeyId_When_Encrypting_Should_RejectConfiguration()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;

            var exception = await Assert.ThrowsAsync<ArgumentException>(() => EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), keyMaterial.PublicKey, "not-a-key-id"));

            Assert.Equal("keyId", exception.ParamName);
            Assert.StartsWith("The Concur PGP key identifier must be hexadecimal", exception.Message);
        }

        /// <summary>
        /// Verifies that invalid public-key material fails rather than producing an unusable output
        /// </summary>
        [Fact]
        public async Task Given_InvalidPublicKey_When_Encrypting_Should_RejectConfiguration()
        {
            await Assert.ThrowsAsync<InvalidKeyMaterialException>(() => EncryptAsync(Encoding.UTF8.GetBytes(Plaintext), "not-a-public-key", "0000000000000001"));
        }

        /// <summary>
        /// Verifies that encryption works with a forward-only source stream used for streamed Blob content
        /// </summary>
        [Fact]
        public async Task Given_NonSeekableSource_When_EncryptingAndDecrypting_Should_PreserveEveryByte()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var content = Encoding.UTF8.GetBytes(Plaintext);
            using var source = new NonSeekableReadStream(content);
            using var encryptedStream = new MemoryStream();

            await new ConcurPgpEncryptionService().EncryptAsync(source, encryptedStream, keyMaterial.PublicKey, keyMaterial.KeyId);

            var decrypted = await DecryptAsync(encryptedStream.ToArray(), keyMaterial);

            Assert.Equal(content, decrypted);
        }

        /// <summary>
        /// Verifies that caller-owned source and destination streams remain open after encryption
        /// </summary>
        [Fact]
        public async Task Given_CallerOwnedStreams_When_Encrypting_Should_LeaveStreamsOpen()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            using var source = new MemoryStream(Encoding.UTF8.GetBytes(Plaintext));
            using var destination = new MemoryStream();

            await new ConcurPgpEncryptionService().EncryptAsync(source, destination, keyMaterial.PublicKey, keyMaterial.KeyId);

            Assert.True(source.CanRead);
            Assert.True(destination.CanWrite);
        }

        /// <summary>
        /// Verifies that an unreadable source is rejected before key processing
        /// </summary>
        [Fact]
        public async Task Given_UnreadableSource_When_Encrypting_Should_RejectStream()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            var source = new MemoryStream();
            source.Dispose();
            using var destination = new MemoryStream();

            var exception = await Assert.ThrowsAsync<ArgumentException>(() => new ConcurPgpEncryptionService().EncryptAsync(source, destination, keyMaterial.PublicKey, keyMaterial.KeyId));

            Assert.Equal("source", exception.ParamName);
        }

        /// <summary>
        /// Verifies that an unwritable destination is rejected before key processing
        /// </summary>
        [Fact]
        public async Task Given_UnwritableDestination_When_Encrypting_Should_RejectStream()
        {
            var keyMaterial = await PrimaryKeyMaterial.Value;
            using var source = new MemoryStream(Encoding.UTF8.GetBytes(Plaintext));
            using var destination = new MemoryStream(Array.Empty<byte>(), writable: false);

            var exception = await Assert.ThrowsAsync<ArgumentException>(() => new ConcurPgpEncryptionService().EncryptAsync(source, destination, keyMaterial.PublicKey, keyMaterial.KeyId));

            Assert.Equal("destination", exception.ParamName);
        }

        /// <summary>
        /// Verifies that a cancelled invocation does not start encryption
        /// </summary>
        [Fact]
        public async Task Given_CancelledInvocation_When_Encrypting_Should_PropagateCancellation()
        {
            using var source = new MemoryStream(Encoding.UTF8.GetBytes(Plaintext));
            using var encrypted = new MemoryStream();
            var token = new CancellationToken(canceled: true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => new ConcurPgpEncryptionService().EncryptAsync(source, encrypted, "public-key", "0000000000000001", token));
        }

        private static async Task<byte[]> EncryptAsync(byte[] content, string publicKey, string keyId)
        {
            using var source = new MemoryStream(content);
            using var encrypted = new MemoryStream();

            await new ConcurPgpEncryptionService().EncryptAsync(source, encrypted, publicKey, keyId);

            return encrypted.ToArray();
        }

        private static async Task<byte[]> DecryptAsync(byte[] encrypted, KeyMaterial keyMaterial)
        {
            using var encryptedStream = new MemoryStream(encrypted);
            using var decryptedStream = new MemoryStream();
            using var decryptor = CreatePgpWithPrivateKey(keyMaterial);

            await decryptor.DecryptAsync(encryptedStream, decryptedStream);

            return decryptedStream.ToArray();
        }

        private static PGP CreatePgpWithPrivateKey(KeyMaterial keyMaterial)
        {
            return new PGP(new EncryptionKeys(keyMaterial.PublicKey, keyMaterial.PrivateKey, Password));
        }

        private static IReadOnlyCollection<long> GetRecipientKeyIds(byte[] encrypted)
        {
            using var encryptedStream = new MemoryStream(encrypted);
            using var decodedStream = PgpUtilities.GetDecoderStream(encryptedStream);
            var objectFactory = new PgpObjectFactory(decodedStream);
            var packet = objectFactory.NextPgpObject();

            if (packet is PgpMarker)
            {
                packet = objectFactory.NextPgpObject();
            }

            var encryptedDataList = packet as PgpEncryptedDataList ?? throw new InvalidDataException("The PGP message does not contain an encrypted-data packet");

            return encryptedDataList.GetEncryptedDataObjects()
                .Cast<PgpPublicKeyEncryptedData>()
                .Select(item => item.KeyId)
                .ToArray();
        }

        private static CompressionAlgorithmTag GetCompressionAlgorithm(byte[] encrypted, string privateKey)
        {
            using var encryptedStream = new MemoryStream(encrypted);
            using var decodedEncryptedStream = PgpUtilities.GetDecoderStream(encryptedStream);
            var encryptedFactory = new PgpObjectFactory(decodedEncryptedStream);
            var encryptedDataList = encryptedFactory.NextPgpObject() as PgpEncryptedDataList ?? throw new InvalidDataException("The PGP message does not contain an encrypted-data packet");
            var encryptedData = encryptedDataList.GetEncryptedDataObjects().Cast<PgpPublicKeyEncryptedData>().Single();

            using var privateKeyStream = new MemoryStream(Encoding.UTF8.GetBytes(privateKey));
            using var decodedPrivateKeyStream = PgpUtilities.GetDecoderStream(privateKeyStream);
            var secretKeys = new PgpSecretKeyRingBundle(decodedPrivateKeyStream);
            var secretKey = secretKeys.GetSecretKey(encryptedData.KeyId) ?? throw new InvalidDataException("The test private key does not contain the selected recipient key");
            var extractedPrivateKey = secretKey.ExtractPrivateKey(Password.ToCharArray());

            using var clearStream = encryptedData.GetDataStream(extractedPrivateKey);
            var clearFactory = new PgpObjectFactory(clearStream);
            var compressedData = clearFactory.NextPgpObject() as PgpCompressedData ?? throw new InvalidDataException("The decrypted PGP message does not contain compressed data");

            return (CompressionAlgorithmTag)compressedData.Algorithm;
        }

        private static byte[] TamperEncryptedPacket(byte[] armored)
        {
            using var armoredStream = new MemoryStream(armored);
            using var decodedStream = PgpUtilities.GetDecoderStream(armoredStream);
            using var binaryStream = new MemoryStream();

            decodedStream.CopyTo(binaryStream);

            var binary = binaryStream.ToArray();
            var packetOffset = 0;
            SkipPacket(binary, ref packetOffset);

            var encryptedPacketTag = binary[packetOffset++] & 0x3F;
            if (encryptedPacketTag != 18)
            {
                throw new InvalidDataException("The PGP message does not contain a symmetrically encrypted integrity-protected packet");
            }

            ReadNewPacketLength(binary, ref packetOffset);
            binary[packetOffset + 24] ^= 0x01;

            using var output = new MemoryStream();
            using (var armoredOutput = new ArmoredOutputStream(output))
            {
                armoredOutput.Write(binary);
            }

            return output.ToArray();
        }

        private static void SkipPacket(byte[] packet, ref int offset)
        {
            var packetHeader = packet[offset++];
            if ((packetHeader & 0x40) == 0)
            {
                var lengthType = packetHeader & 0x03;
                var oldPacketLength = lengthType switch
                {
                    0 => packet[offset++],
                    1 => (packet[offset++] << 8) | packet[offset++],
                    2 => ReadFourByteLength(packet, ref offset),
                    _ => throw new InvalidDataException("The PGP message uses an indeterminate old-format packet length")
                };
                offset += oldPacketLength;

                return;
            }

            var packetLength = ReadNewPacketLength(packet, ref offset);
            offset += packetLength;
        }

        private static int ReadNewPacketLength(byte[] packet, ref int offset)
        {
            var first = packet[offset++];
            if (first < 192)
            {
                return first;
            }

            if (first <= 223)
            {
                return ((first - 192) << 8) + packet[offset++] + 192;
            }

            if (first == 255)
            {
                return ReadFourByteLength(packet, ref offset);
            }

            return 1 << (first & 0x1F);
        }

        private static int ReadFourByteLength(byte[] packet, ref int offset)
        {
            var length = (packet[offset] << 24)
                | (packet[offset + 1] << 16)
                | (packet[offset + 2] << 8)
                | packet[offset + 3];
            offset += 4;

            return length;
        }

        private static async Task<KeyMaterial> CreateKeyMaterialAsync()
        {
            using var publicKeyStream = new MemoryStream();
            using var privateKeyStream = new MemoryStream();
            using var pgp = new PGP();

            await pgp.GenerateKeyAsync(
                publicKeyStream,
                privateKeyStream,
                Username,
                Password,
                strength: 2048,
                certainty: 16);

            var publicKey = Encoding.UTF8.GetString(publicKeyStream.ToArray());
            var privateKey = Encoding.UTF8.GetString(privateKeyStream.ToArray());
            var encryptionKeys = new EncryptionKeys(publicKey);
            var keyId = FormatKeyId(encryptionKeys.MasterKey.KeyId);

            return new KeyMaterial(publicKey, privateKey, keyId);
        }

        private static string FormatKeyId(long keyId)
        {
            return unchecked((ulong)keyId).ToString("X16");
        }

        private static string GetFixturePath(string fileName)
        {
            return Path.Combine(AppContext.BaseDirectory, "Fixtures", "Workday", fileName);
        }

        private sealed record KeyMaterial(string PublicKey, string PrivateKey, string KeyId);

        private sealed class NonSeekableReadStream : Stream
        {
            private readonly MemoryStream _inner;

            public NonSeekableReadStream(byte[] content)
            {
                _inner = new MemoryStream(content);
            }

            public override bool CanRead => true;
            public override bool CanSeek => false;
            public override bool CanWrite => false;
            public override long Length => throw new NotSupportedException();
            public override long Position
            {
                get => throw new NotSupportedException();
                set => throw new NotSupportedException();
            }

            public override void Flush()
            {
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                return _inner.Read(buffer, offset, count);
            }

            public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
            {
                return _inner.ReadAsync(buffer, cancellationToken);
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                throw new NotSupportedException();
            }

            public override void SetLength(long value)
            {
                throw new NotSupportedException();
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                throw new NotSupportedException();
            }

            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    _inner.Dispose();
                }

                base.Dispose(disposing);
            }
        }
    }
}
