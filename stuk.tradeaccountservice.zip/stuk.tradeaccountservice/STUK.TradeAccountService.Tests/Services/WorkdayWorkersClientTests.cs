using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Tests.Fixtures.Workday;
using System.Net;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests direct Workday employee discovery and detail retrieval
    /// </summary>
    public class WorkdayWorkersClientTests
    {
        private const string WorkdayEndpoint = "https://workday.example.test/ccx/service/tenant/Human_Resources/v40.0";
        private const string WorkdayNamespace = "urn:com.workday/bsvc";
        private const string IntegrationUsername = "integration-user";
        private const string IntegrationPassword = "secure-password";
        private const string ResponseXml = "<response />";

        /// <summary>
        /// Verifies the effective, updated and distinct detail request sequence
        /// </summary>
        [Fact]
        public async Task Given_FixedWindow_When_Retrieving_Should_ReproduceMuleRequestSequence()
        {
            var parser = new Mock<IWorkdayWorkerResponseParser>();
            var requestFactory = new Mock<IWorkdaySoapRequestFactory>();
            var from = new DateTimeOffset(2026, 7, 1, 0, 0, 0, TimeSpan.Zero);
            var through = new DateTimeOffset(2026, 7, 1, 1, 30, 0, TimeSpan.Zero);

            requestFactory.Setup(value => value.CreateEffectiveWorkerRequest(from, through, 1, 100))
                .Returns("effective-request");

            requestFactory.Setup(value => value.CreateUpdatedWorkerRequest(from, through, 1, 100))
                .Returns("updated-request");

            requestFactory.Setup(value => value.CreateWorkerDetailRequest(
                    It.Is<IReadOnlyCollection<string>>(ids => ids.SequenceEqual(new[] { "1001", "1002" })),
                    1,
                    100))
                .Returns("detail-request");

            parser.SetupSequence(value => value.ParseReferencePage(ResponseXml))
                .Returns(new WorkdayWorkerReferencePage { EmployeeIds = ["1001"], Page = 1, TotalPages = 1 })
                .Returns(new WorkdayWorkerReferencePage { EmployeeIds = ["1001", "1002"], Page = 1, TotalPages = 1 });

            parser.Setup(value => value.ParseWorkerPage(ResponseXml))
                .Returns(new WorkdayWorkerPage
                {
                    Workers = [new WorkdayWorker { EmployeeId = "1001" }, new WorkdayWorker { EmployeeId = "1002" }],
                    Page = 1,
                    TotalPages = 1
                });

            var handler = new RecordingHttpMessageHandler(3);

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var options = CreateOptions();

            var client = new WorkdayWorkersClient(httpClient, requestFactory.Object, parser.Object, options);

            var workers = await client.GetWorkersAsync(from, through);

            Assert.Equal(["1001", "1002"], workers.Select(worker => worker.EmployeeId));
            Assert.Equal(["effective-request", "updated-request", "detail-request"], handler.Requests.Select(request => request.Content));
            Assert.All(handler.Requests, request => Assert.Equal(HttpMethod.Post, request.Method));
            Assert.All(handler.Requests, request => Assert.Equal(WorkdayEndpoint, request.Uri.AbsoluteUri));
            Assert.All(handler.Requests, request => Assert.Null(request.Authorization));
            Assert.All(handler.Requests, request => Assert.Equal("text/xml", request.MediaType));
            Assert.All(handler.Requests, request => Assert.Equal("utf-8", request.CharSet));
        }

        /// <summary>
        /// Verifies that discovery follows Workday paging metadata and detail requests use the configured batch size
        /// </summary>
        [Fact]
        public async Task Given_MultiplePagesAndSmallBatches_When_Retrieving_Should_PageAndBatch()
        {
            var parser = new Mock<IWorkdayWorkerResponseParser>();
            var requestFactory = new Mock<IWorkdaySoapRequestFactory>();
            var from = DateTimeOffset.UtcNow.AddHours(-1);
            var through = DateTimeOffset.UtcNow;

            requestFactory.Setup(value => value.CreateEffectiveWorkerRequest(from, through, 1, 100))
                .Returns("effective-page-1");

            requestFactory.Setup(value => value.CreateEffectiveWorkerRequest(from, through, 2, 100))
                .Returns("effective-page-2");

            requestFactory.Setup(value => value.CreateUpdatedWorkerRequest(from, through, 1, 100))
                .Returns("updated-page-1");

            requestFactory.Setup(value => value.CreateWorkerDetailRequest(It.IsAny<IReadOnlyCollection<string>>(), 1, 100))
                .Returns<IReadOnlyCollection<string>, int, int>((ids, _, _) => $"detail-{ids.Single()}");

            parser.SetupSequence(value => value.ParseReferencePage(ResponseXml))
                .Returns(new WorkdayWorkerReferencePage { EmployeeIds = ["1001"], Page = 1, TotalPages = 2 })
                .Returns(new WorkdayWorkerReferencePage { EmployeeIds = ["1002"], Page = 2, TotalPages = 2 })
                .Returns(new WorkdayWorkerReferencePage { EmployeeIds = [], Page = 0, TotalPages = 0 });

            parser.SetupSequence(value => value.ParseWorkerPage(ResponseXml))
                .Returns(new WorkdayWorkerPage { Workers = [new WorkdayWorker { EmployeeId = "1001" }], Page = 1, TotalPages = 1 })
                .Returns(new WorkdayWorkerPage { Workers = [new WorkdayWorker { EmployeeId = "1002" }], Page = 1, TotalPages = 1 });

            var handler = new RecordingHttpMessageHandler(5);

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var options = CreateOptions();
            options.Value.WorkdayDetailBatchSize = 1;

            var client = new WorkdayWorkersClient(httpClient, requestFactory.Object, parser.Object, options);

            var workers = await client.GetWorkersAsync(from, through);

            Assert.Equal(2, workers.Count);
            Assert.Equal(["effective-page-1", "effective-page-2", "updated-page-1", "detail-1001", "detail-1002"], handler.Requests.Select(request => request.Content));
        }

        /// <summary>
        /// Verifies the source-derived retry that removes an Employee_ID explicitly rejected by Workday
        /// </summary>
        [Fact]
        public async Task Given_InvalidEmployeeIdFault_When_RetrievingDetails_Should_RemoveIdAndRetryBatch()
        {
            var handler = new RecordingHttpMessageHandler(
                (HttpStatusCode.OK, WorkdayTestFixture.Read("reference-two-employees.xml")),
                (HttpStatusCode.OK, WorkdayTestFixture.Read("reference-empty.xml")),
                (HttpStatusCode.InternalServerError, WorkdayTestFixture.Read("invalid-employee-id-fault.xml")),
                (HttpStatusCode.OK, WorkdayTestFixture.Read("worker-details.xml")));

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var options = CreateOptions();

            var client = new WorkdayWorkersClient(httpClient, new WorkdaySoapRequestFactory(options), new WorkdayWorkerResponseParser(), options);

            var workers = await client.GetWorkersAsync(DateTimeOffset.UtcNow.AddHours(-1), DateTimeOffset.UtcNow);

            Assert.Equal("1001", Assert.Single(workers).EmployeeId);
            Assert.Equal(4, handler.Requests.Count);
            Assert.Equal(["1001", "1002"], WorkerIds(handler.Requests[2].Content));
            Assert.Equal(["1001"], WorkerIds(handler.Requests[3].Content));
        }

        /// <summary>
        /// Verifies that a reversed integration window is rejected before Workday is called
        /// </summary>
        [Fact]
        public async Task Given_ReversedWindow_When_Retrieving_Should_RejectBeforeHttp()
        {
            var handler = new RecordingHttpMessageHandler(0);

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var client = new WorkdayWorkersClient(httpClient, Mock.Of<IWorkdaySoapRequestFactory>(), Mock.Of<IWorkdayWorkerResponseParser>(), CreateOptions());

            await Assert.ThrowsAsync<ArgumentException>(() => client.GetWorkersAsync(DateTimeOffset.UtcNow, DateTimeOffset.UtcNow.AddMinutes(-1)));

            Assert.Empty(handler.Requests);
        }

        /// <summary>
        /// Verifies that all numeric Workday client limits must be positive
        /// </summary>
        [Theory]
        [InlineData(0, 100, 60)]
        [InlineData(100, 0, 60)]
        [InlineData(100, 100, 0)]
        [InlineData(-1, 100, 60)]
        public async Task Given_InvalidClientLimits_When_Retrieving_Should_RejectConfiguration(int pageSize, int batchSize, int timeoutSeconds)
        {
            var handler = new RecordingHttpMessageHandler(0);

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var options = CreateOptions();
            options.Value.WorkdayPageSize = pageSize;
            options.Value.WorkdayDetailBatchSize = batchSize;
            options.Value.WorkdayRequestTimeoutSeconds = timeoutSeconds;

            var client = new WorkdayWorkersClient(httpClient, Mock.Of<IWorkdaySoapRequestFactory>(), Mock.Of<IWorkdayWorkerResponseParser>(), options);

            await Assert.ThrowsAsync<InvalidOperationException>(() => client.GetWorkersAsync(DateTimeOffset.UtcNow.AddMinutes(-1), DateTimeOffset.UtcNow));

            Assert.Empty(handler.Requests);
        }

        /// <summary>
        /// Verifies that an endpoint setting without a configured HTTP base address cannot send to an unintended host
        /// </summary>
        [Fact]
        public async Task Given_MissingBaseAddress_When_Retrieving_Should_RejectConfiguration()
        {
            using var httpClient = new HttpClient(new RecordingHttpMessageHandler(0));

            var client = new WorkdayWorkersClient(httpClient, Mock.Of<IWorkdaySoapRequestFactory>(), Mock.Of<IWorkdayWorkerResponseParser>(), CreateOptions());

            await Assert.ThrowsAsync<InvalidOperationException>(() => client.GetWorkersAsync(DateTimeOffset.UtcNow.AddMinutes(-1), DateTimeOffset.UtcNow));
        }

        /// <summary>
        /// Verifies Workday credentials and worker data cannot be sent over an unencrypted HTTP connection
        /// </summary>
        [Fact]
        public async Task Given_HttpBaseAddress_When_Retrieving_Should_RejectConfiguration()
        {
            var handler = new RecordingHttpMessageHandler(0);

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://workday.example.test/") };

            var client = new WorkdayWorkersClient(httpClient, Mock.Of<IWorkdaySoapRequestFactory>(), Mock.Of<IWorkdayWorkerResponseParser>(), CreateOptions());

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => client.GetWorkersAsync(DateTimeOffset.UtcNow.AddMinutes(-1), DateTimeOffset.UtcNow));

            Assert.Contains("HTTPS", exception.Message);
        }

        /// <summary>
        /// Verifies that a non-success response without a SOAP fault remains an HTTP failure
        /// </summary>
        [Fact]
        public async Task Given_EmptyHttpFailure_When_Retrieving_Should_PropagateStatusCode()
        {
            var requestFactory = new Mock<IWorkdaySoapRequestFactory>();
            requestFactory.Setup(value => value.CreateEffectiveWorkerRequest(It.IsAny<DateTimeOffset>(), It.IsAny<DateTimeOffset>(), 1, 100)).Returns("request");
            var handler = new RecordingHttpMessageHandler((HttpStatusCode.ServiceUnavailable, string.Empty));

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var client = new WorkdayWorkersClient(httpClient, requestFactory.Object, Mock.Of<IWorkdayWorkerResponseParser>(), CreateOptions());

            var exception = await Assert.ThrowsAsync<HttpRequestException>(() => client.GetWorkersAsync(DateTimeOffset.UtcNow.AddMinutes(-1), DateTimeOffset.UtcNow));

            Assert.Equal(HttpStatusCode.ServiceUnavailable, exception.StatusCode);
        }

        /// <summary>
        /// Verifies that Workday SOAP fault detail is preserved even when the HTTP response is unsuccessful
        /// </summary>
        [Fact]
        public async Task Given_SoapFaultHttpFailure_When_Retrieving_Should_PreserveFaultMessage()
        {
            var requestFactory = new Mock<IWorkdaySoapRequestFactory>();
            requestFactory.Setup(value => value.CreateEffectiveWorkerRequest(It.IsAny<DateTimeOffset>(), It.IsAny<DateTimeOffset>(), 1, 100)).Returns("request");
            var handler = new RecordingHttpMessageHandler((HttpStatusCode.InternalServerError, WorkdayTestFixture.Read("soap-fault.xml")));

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var client = new WorkdayWorkersClient(httpClient, requestFactory.Object, new WorkdayWorkerResponseParser(), CreateOptions());

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() => client.GetWorkersAsync(DateTimeOffset.UtcNow.AddMinutes(-1), DateTimeOffset.UtcNow));

            Assert.Contains("Invalid credentials", exception.Message);
        }

        /// <summary>
        /// Verifies that detail retrieval follows Workday paging metadata for the same employee batch
        /// </summary>
        [Fact]
        public async Task Given_MultiPageWorkerDetails_When_Retrieving_Should_RequestEveryDetailPage()
        {
            var parser = new Mock<IWorkdayWorkerResponseParser>();
            var requestFactory = new Mock<IWorkdaySoapRequestFactory>();
            var from = DateTimeOffset.UtcNow.AddHours(-1);
            var through = DateTimeOffset.UtcNow;

            requestFactory.Setup(value => value.CreateEffectiveWorkerRequest(from, through, 1, 100)).Returns("effective");
            requestFactory.Setup(value => value.CreateUpdatedWorkerRequest(from, through, 1, 100)).Returns("updated");
            requestFactory.Setup(value => value.CreateWorkerDetailRequest(It.IsAny<IReadOnlyCollection<string>>(), 1, 100)).Returns("details-1");
            requestFactory.Setup(value => value.CreateWorkerDetailRequest(It.IsAny<IReadOnlyCollection<string>>(), 2, 100)).Returns("details-2");

            parser.SetupSequence(value => value.ParseReferencePage(ResponseXml))
                .Returns(new WorkdayWorkerReferencePage { EmployeeIds = ["1001"], Page = 1, TotalPages = 1 })
                .Returns(new WorkdayWorkerReferencePage { EmployeeIds = [], Page = 0, TotalPages = 0 });

            parser.SetupSequence(value => value.ParseWorkerPage(ResponseXml))
                .Returns(new WorkdayWorkerPage { Workers = [new WorkdayWorker { EmployeeId = "1001" }], Page = 1, TotalPages = 2 })
                .Returns(new WorkdayWorkerPage { Workers = [], Page = 2, TotalPages = 2 });

            var handler = new RecordingHttpMessageHandler(4);

            using var httpClient = new HttpClient(handler) { BaseAddress = new Uri(WorkdayEndpoint) };

            var client = new WorkdayWorkersClient(httpClient, requestFactory.Object, parser.Object, CreateOptions());

            var workers = await client.GetWorkersAsync(from, through);

            Assert.Equal("1001", Assert.Single(workers).EmployeeId);
            Assert.Equal(["effective", "updated", "details-1", "details-2"], handler.Requests.Select(request => request.Content));
        }

        private static IOptions<WorkdayConcurOptions> CreateOptions()
        {
            return Options.Create(new WorkdayConcurOptions
            {
                WorkdayEndpoint = WorkdayEndpoint,
                WorkdayUsername = IntegrationUsername,
                WorkdayPassword = IntegrationPassword,
                WorkdayPageSize = 100,
                WorkdayDetailBatchSize = 100,
                WorkdayRequestTimeoutSeconds = 60
            });
        }

        private static IEnumerable<string> WorkerIds(string requestXml)
        {
            XNamespace workday = WorkdayNamespace;
            return XDocument.Parse(requestXml)
                .Descendants(workday + "Worker_Reference")
                .Select(reference => reference.Element(workday + "ID")?.Value ?? string.Empty);
        }

        private sealed class RecordingHttpMessageHandler : HttpMessageHandler
        {
            private readonly int _expectedRequestCount;
            private readonly Queue<(HttpStatusCode StatusCode, string Content)> _responses;

            public RecordingHttpMessageHandler(int expectedRequestCount)
            {
                _expectedRequestCount = expectedRequestCount;
                _responses = new Queue<(HttpStatusCode, string)>(Enumerable.Repeat(
                    (HttpStatusCode.OK, ResponseXml),
                    expectedRequestCount));
            }

            public RecordingHttpMessageHandler(params (HttpStatusCode StatusCode, string Content)[] responses)
            {
                _expectedRequestCount = responses.Length;
                _responses = new Queue<(HttpStatusCode, string)>(responses);
            }

            public List<RecordedRequest> Requests { get; } = [];

            protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                if (Requests.Count >= _expectedRequestCount)
                {
                    throw new InvalidOperationException("The client sent more Workday requests than the test expected.");
                }

                Requests.Add(new RecordedRequest(
                    request.Method,
                    request.RequestUri ?? throw new InvalidOperationException("The Workday request URI was not set."),
                    request.Headers.Authorization,
                    request.Content?.Headers.ContentType?.MediaType,
                    request.Content?.Headers.ContentType?.CharSet,
                    await request.Content!.ReadAsStringAsync(cancellationToken)));

                var response = _responses.Dequeue();
                return new HttpResponseMessage(response.StatusCode)
                {
                    Content = new StringContent(response.Content)
                };
            }
        }

        private sealed record RecordedRequest(HttpMethod Method, Uri Uri, System.Net.Http.Headers.AuthenticationHeaderValue? Authorization, string? MediaType, string? CharSet, string Content);
    }
}
