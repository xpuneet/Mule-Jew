using Microsoft.Extensions.Options;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Configuration;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class IconServiceTests
    {
        private readonly Mock<IIconHttpClient> _iconHttpClientMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly IconService _service;

        public IconServiceTests()
        {
            _iconHttpClientMock = new Mock<IIconHttpClient>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();

            var options = new TradeAcnSyncOptions { IconApiMaxRetries = 3 };
            var optionsMock = new Mock<IOptions<TradeAcnSyncOptions>>();
            optionsMock.Setup(o => o.Value).Returns(options);

            var iconSettings = new IconSettings { K8_XI_AuthToken = "test-token" };
            _iconHttpClientMock.Setup(c => c.IconSettings).Returns(iconSettings);

            _service = new IconService(
                _iconHttpClientMock.Object,
                optionsMock.Object,
                _loggerMock.Object);
        }

        private static PendingPaymentReference CreateValidPendingReference() => new()
        {
            PaymentId = 1,
            AccountCode = "ACC001",
            BranchId = "10",
            Description = "Test payment",
            PaymentType = 'C',
            PaymentAmount = 100.50m,
            ApiPaymentReference = Guid.NewGuid()
        };

        #region MakeAccountPaymentAsync - Success

        [Fact]
        public async Task MakeAccountPaymentAsync_SuccessfulCall_ReturnsIsDefinitiveTrue()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();
            var expectedResponse = new IconMakeAccountPaymentResponse();

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _service.MakeAccountPaymentAsync(pendingRef, CancellationToken.None);

            // Assert
            Assert.True(result.IsDefinitive);
            Assert.Equal(200, result.StatusCode);
            Assert.Equal(expectedResponse, result.Response);
            Assert.Null(result.ErrorMessage);
        }

        [Fact]
        public async Task MakeAccountPaymentAsync_SuccessfulCall_CallsPostAccountPaymentOnce()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new IconMakeAccountPaymentResponse());

            // Act
            await _service.MakeAccountPaymentAsync(pendingRef, CancellationToken.None);

            // Assert
            _iconHttpClientMock.Verify(c =>
                c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    "test-token",
                    It.IsAny<CancellationToken>()),
                Times.Once);
        }

        #endregion

        #region MakeAccountPaymentAsync - ApiException (4xx)

        [Fact]
        public async Task MakeAccountPaymentAsync_ApiException4xx_ReturnsDefinitiveError()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();
            var apiException = new ApiException("Bad Request", 400, "Invalid account", null, null);

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(apiException);

            // Act
            var result = await _service.MakeAccountPaymentAsync(pendingRef, CancellationToken.None);

            // Assert
            Assert.True(result.IsDefinitive);
            Assert.Equal(400, result.StatusCode);
            Assert.NotNull(result.ErrorMessage);
        }

        [Fact]
        public async Task MakeAccountPaymentAsync_ApiExceptionNullResponse_ReturnsNullPlaceholder()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();
            var apiException = new ApiException("Bad Request", 400, null, null, null);

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(apiException);

            // Act
            var result = await _service.MakeAccountPaymentAsync(pendingRef, CancellationToken.None);

            // Assert
            Assert.True(result.IsDefinitive);
            Assert.Equal("(null)", result.ErrorMessage);
        }

        #endregion

        #region MakeAccountPaymentAsync - Retries and Transient Failure

        [Fact]
        public async Task MakeAccountPaymentAsync_AllRetriesFail_ReturnsTransientFailure()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new Exception("Connection timeout"));

            // Act
            var result = await _service.MakeAccountPaymentAsync(pendingRef, CancellationToken.None);

            // Assert
            Assert.False(result.IsDefinitive);
            Assert.Contains("failed after 3 attempts", result.ErrorMessage);
        }

        [Fact]
        public async Task MakeAccountPaymentAsync_TransientThenSuccess_ReturnsSuccess()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();
            var callCount = 0;

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Returns((IconMakeAccountPaymentRequest _, string _, CancellationToken _) =>
                {
                    callCount++;
                    if (callCount == 1)
                        throw new Exception("Transient failure");
                    return Task.FromResult(new IconMakeAccountPaymentResponse());
                });

            // Act
            var result = await _service.MakeAccountPaymentAsync(pendingRef, CancellationToken.None);

            // Assert
            Assert.True(result.IsDefinitive);
            Assert.Equal(200, result.StatusCode);
        }

        #endregion

        #region MakeAccountPaymentAsync - Cancellation

        [Fact]
        public async Task MakeAccountPaymentAsync_CancellationRequested_ThrowsOperationCancelled()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();
            var cts = new CancellationTokenSource();
            cts.Cancel();

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new OperationCanceledException());

            // Act & Assert
            await Assert.ThrowsAsync<OperationCanceledException>(() =>
                _service.MakeAccountPaymentAsync(pendingRef, cts.Token));
        }

        #endregion

        #region MakeAccountPaymentAsync - Request Building

        [Fact]
        public async Task MakeAccountPaymentAsync_BuildsRequestWithCorrectAccountCode()
        {
            // Arrange
            var pendingRef = CreateValidPendingReference();
            IconMakeAccountPaymentRequest? capturedRequest = null;

            _iconHttpClientMock
                .Setup(c => c.POST_AccountPaymentAsync(
                    It.IsAny<IconMakeAccountPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .Callback<IconMakeAccountPaymentRequest, string, CancellationToken>((req, _, _) => capturedRequest = req)
                .ReturnsAsync(new IconMakeAccountPaymentResponse());

            // Act
            await _service.MakeAccountPaymentAsync(pendingRef, CancellationToken.None);

            // Assert
            Assert.NotNull(capturedRequest);
            Assert.Equal("ACC001", capturedRequest!.Account);
            Assert.Equal(10.0, capturedRequest.Branch);
            Assert.Equal("Test payment", capturedRequest.Description);
            Assert.Equal(1, capturedRequest.Till);
        }

        #endregion
    }
}
