using Microsoft.Extensions.Options;
using Moq;
using System.Text;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Tests.Fixtures.Workday;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the reverse-engineered Mule employee CSV mapping and Blob staging contract
    /// </summary>
    public class WorkdayConcurCsvServiceTests
    {
        private static readonly Uri Endpoint = new("https://storage.example.test");

        private readonly Mock<IWorkdayConcurBlobClient> _blobClient = new();

        /// <summary>
        /// Verifies the exact 25-column order, Mule mappings, comma removal and destination Blob
        /// </summary>
        [Fact]
        public async Task Given_WorkdayWorker_When_Staging_Should_WriteMuleCompatibleCsv()
        {
            var worker = CreateWorker();

            var identity = new WorkdayConcurFileIdentity
            {
                Path = "stukconcurtest/input/SG_CONCUR_DAILY.csv",
                ContentLength = 100,
                ETag = "etag"
            };

            byte[]? uploadedContent = null;

            _blobClient
                .Setup(x => x.UploadAsync(Endpoint, "stukconcurtest", "input/SG_CONCUR_DAILY.csv", It.IsAny<Stream>(), default))
                .Callback<Uri, string, string, Stream, CancellationToken>((_, _, _, content, _) =>
                {
                    using var copy = new MemoryStream();
                    content.CopyTo(copy);
                    uploadedContent = copy.ToArray();
                })
                .ReturnsAsync(identity);

            var result = await CreateService().StageAsync(new[] { worker });

            Assert.NotNull(uploadedContent);
            Assert.Equal(WorkdayTestFixture.Read("sg-concur-daily.csv").ReplaceLineEndings("\n"), Encoding.UTF8.GetString(uploadedContent));
            Assert.Same(identity, result);
            _blobClient.VerifyAll();
        }

        /// <summary>
        /// Verifies that the configured approval default is used only when Workday omits every override
        /// </summary>
        [Fact]
        public async Task Given_NoIntegrationOverride_When_Staging_Should_UseApprovalDefault()
        {
            var worker = CreateWorker();
            worker.FirstIntegrationFieldOverrideValue = null;
            string? csv = null;
            _blobClient
                .Setup(x => x.UploadAsync(Endpoint, "stukconcurtest", "input/SG_CONCUR_DAILY.csv", It.IsAny<Stream>(), default))
                .Callback<Uri, string, string, Stream, CancellationToken>((_, _, _, content, _) =>
                {
                    using var reader = new StreamReader(content, Encoding.UTF8, leaveOpen: true);
                    csv = reader.ReadToEnd();
                })
                .ReturnsAsync(new WorkdayConcurFileIdentity());

            await CreateService().StageAsync(new[] { worker });

            Assert.EndsWith(",N\n", csv);
        }

        /// <summary>
        /// Verifies that an empty worker set cannot overwrite the live employee input with a header-only file
        /// </summary>
        [Fact]
        public async Task Given_NoWorkers_When_Staging_Should_RejectWrite()
        {
            await Assert.ThrowsAsync<ArgumentException>(() => CreateService().StageAsync(Array.Empty<WorkdayWorker>()));

            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies a null worker collection cannot reach Blob storage
        /// </summary>
        [Fact]
        public async Task Given_NullWorkers_When_Staging_Should_RejectWrite()
        {
            await Assert.ThrowsAsync<ArgumentNullException>(() => CreateService().StageAsync(null!));

            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies a null worker within a non-empty set cannot produce a partial CSV
        /// </summary>
        [Fact]
        public async Task Given_NullWorker_When_Staging_Should_RejectWrite()
        {
            _blobClient.Setup(x => x.UploadAsync(Endpoint, "stukconcurtest", "input/SG_CONCUR_DAILY.csv", It.IsAny<Stream>(), default));

            await Assert.ThrowsAsync<ArgumentNullException>(() => CreateService().StageAsync(new WorkdayWorker[] { null! }));

            _blobClient.Verify(x => x.UploadAsync(It.IsAny<Uri>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Stream>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        /// <summary>
        /// Verifies CSV-sensitive characters are quoted without changing their content
        /// </summary>
        [Fact]
        public async Task Given_QuotesAndLineBreaks_When_Staging_Should_EscapeCsvField()
        {
            var worker = CreateWorker();
            worker.PrimaryWorkEmail = "alex\"worker\n@example.test";

            string? csv = null;

            _blobClient
                .Setup(x => x.UploadAsync(Endpoint, "stukconcurtest", "input/SG_CONCUR_DAILY.csv", It.IsAny<Stream>(), default))
                .Callback<Uri, string, string, Stream, CancellationToken>((_, _, _, content, _) =>
                {
                    using var reader = new StreamReader(content, Encoding.UTF8, leaveOpen: true);
                    csv = reader.ReadToEnd();
                })
                .ReturnsAsync(new WorkdayConcurFileIdentity());

            await CreateService().StageAsync(new[] { worker });

            Assert.Contains("\"alex\"\"worker\n@example.test\"", csv);
        }

        /// <summary>
        /// Verifies every required Blob and mapping setting is validated before upload
        /// </summary>
        [Theory]
        [InlineData("", "stukconcurtest", "SGBD", "N")]
        [InlineData("http://storage.example.test", "stukconcurtest", "SGBD", "N")]
        [InlineData("https://storage.example.test", "", "SGBD", "N")]
        [InlineData("https://storage.example.test", "stukconcurtest", "", "N")]
        [InlineData("https://storage.example.test", "stukconcurtest", "SGBD", "")]
        public async Task Given_InvalidOptions_When_Staging_Should_RejectConfiguration(string endpoint, string container, string ledgerCode, string approvalDefault)
        {
            var options = Options.Create(new WorkdayConcurOptions
            {
                ConcurBlobServiceEndpoint = endpoint,
                ConcurBlobContainerName = container,
                ConcurLedgerCode = ledgerCode,
                ConcurApprovalDefault = approvalDefault
            });

            var service = new WorkdayConcurCsvService(_blobClient.Object, options);

            await Assert.ThrowsAsync<InvalidOperationException>(() => service.StageAsync(new[] { CreateWorker() }));

            _blobClient.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies all three source-derived company-car mappings
        /// </summary>
        [Theory]
        [InlineData("Company Car", "True")]
        [InlineData("No Company Car", "False")]
        [InlineData("Not Supplied", "")]
        public async Task Given_CompanyCarOverride_When_Staging_Should_MapCurrentContract(string sourceValue, string expected)
        {
            var worker = CreateWorker();
            worker.IntegrationFieldOverrides = new Dictionary<string, string>(worker.IntegrationFieldOverrides)
            {
                ["COMPCAR_FLG"] = sourceValue
            };

            string? csv = null;

            _blobClient
                .Setup(x => x.UploadAsync(Endpoint, "stukconcurtest", "input/SG_CONCUR_DAILY.csv", It.IsAny<Stream>(), default))
                .Callback<Uri, string, string, Stream, CancellationToken>((_, _, _, content, _) =>
                {
                    using var reader = new StreamReader(content, Encoding.UTF8, leaveOpen: true);
                    csv = reader.ReadToEnd();
                })
                .ReturnsAsync(new WorkdayConcurFileIdentity());

            await CreateService().StageAsync([worker]);

            var dataRow = csv!.Split('\n', StringSplitOptions.RemoveEmptyEntries)[1].Split(',');
            Assert.Equal(expected, dataRow[14]);
        }

        private WorkdayConcurCsvService CreateService()
        {
            return new WorkdayConcurCsvService(
                _blobClient.Object,
                Options.Create(new WorkdayConcurOptions
                {
                    ConcurBlobServiceEndpoint = Endpoint.ToString(),
                    ConcurBlobContainerName = "stukconcurtest",
                    ConcurLedgerCode = "SGBD",
                    ConcurApprovalDefault = "N"
                }));
        }

        private static WorkdayWorker CreateWorker()
        {
            return new WorkdayWorker
            {
                EmployeeId = "10,01",
                PrimaryWorkEmail = "alex@example.test",
                PreferredFirstName = "Al,ex",
                PreferredLastName = "Worker",
                PositionTitle = "Branch, Manager",
                OrganizationName = "Lon,don",
                TerminationDate = "2026-08-31",
                FirstIntegrationFieldOverrideValue = "Approved,Yes",
                IntegrationFieldOverrides = new Dictionary<string, string>
                {
                    ["UPN"] = "alex.worker",
                    ["Compensation Grade Number"] = "G7",
                    ["Cost Center Code"] = "CC100",
                    ["COMPCAR_FLG"] = "Company Car",
                    ["Manager1"] = "2001",
                    ["Manager2"] = "3001"
                },
                CustomIds = new Dictionary<string, string>
                {
                    ["SUK_Purchase_Ledger_Code_UK"] = "PL1001"
                }
            };
        }
    }
}
