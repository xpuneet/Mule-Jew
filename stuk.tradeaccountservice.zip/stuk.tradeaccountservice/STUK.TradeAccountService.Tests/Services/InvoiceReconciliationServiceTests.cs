using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Tests.Helpers;

namespace STUK.TradeAccountService.Tests.Services
{
    public class InvoiceReconciliationServiceTests
    {
        private const string BranchCode = "137";
        private const string ConsolidatedInvoiceNumber = "C-00163396";
        private const string LeaseOwner = "worker-1";
        private const string StandardInvoiceNumber = "00163396";
        private static readonly Guid ClaimToken = new("60000000-0000-0000-0000-000000000002");
        private static readonly DateTimeOffset CurrentTime = new(2026, 8, 8, 10, 0, 0, TimeSpan.Zero);
        private static readonly DateOnly ConsolidatedInvoiceDate = new(2026, 8, 7);
        private static readonly Guid MatchedInvoiceHeaderId = new("60000000-0000-0000-0000-000000000003");
        private static readonly Guid WorkId = new("60000000-0000-0000-0000-000000000001");

        [Fact]
        public async Task Given_ExactlyOneInvoiceMatch_When_Run_Should_Reconcile_The_Claimed_Work()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());
            dataService.Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new InvoiceReconciliationMatchResult
                {
                    MatchCount = 1,
                    MatchedInvoiceHeaderId = MatchedInvoiceHeaderId
                });

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()), Times.Once);
            dataService.Verify(service => service.CompleteAsync(WorkId, ClaimToken, MatchedInvoiceHeaderId, CurrentTime, It.IsAny<CancellationToken>()), Times.Once);
            dataService.Verify(service => service.DeferAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<DateTimeOffset>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dataService.Verify(service => service.FailAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_InvoiceHasNotArrived_When_Run_Should_Defer_The_Claimed_Work()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());
            dataService.Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new InvoiceReconciliationMatchResult());

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.DeferAsync(
                WorkId,
                ClaimToken,
                CurrentTime.AddSeconds(300),
                It.Is<string>(message => message.Contains(StandardInvoiceNumber, StringComparison.Ordinal)
                    && message.Contains(BranchCode, StringComparison.Ordinal)),
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_MultipleInvoiceMatches_When_Run_Should_Record_A_TerminalFailure()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());
            dataService.Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new InvoiceReconciliationMatchResult { MatchCount = 2 });

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.FailAsync(
                WorkId,
                ClaimToken,
                "AmbiguousInvoiceMatch",
                It.Is<string>(message => message.Contains("matched 2", StringComparison.Ordinal)),
                null,
                1,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_One_Match_Without_An_Invoice_Id_When_Run_Should_Record_A_TerminalFailure()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());

            dataService
                .Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new InvoiceReconciliationMatchResult { MatchCount = 1 });

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.CompleteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            dataService.Verify(service => service.FailAsync(
                WorkId,
                ClaimToken,
                "AmbiguousInvoiceMatch",
                It.Is<string>(message => message.Contains("matched 1", StringComparison.Ordinal)),
                null,
                1,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_MissingMatchKey_When_Run_Should_Record_A_TerminalFailure_Without_Reconciling()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork(standardInvoiceNumber: null));

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.FailAsync(
                WorkId,
                ClaimToken,
                "InvalidMatchKey",
                It.IsAny<string>(),
                null,
                1,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
            dataService.Verify(service => service.MatchAndUpdateInvoiceAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_ReconciliationFailure_When_Run_Should_Record_A_RetryableFailure()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());
            dataService.Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Database unavailable"));

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.FailAsync(
                WorkId,
                ClaimToken,
                "ReconciliationFailure",
                "Database unavailable",
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_NoEligibleWork_When_Run_Should_Not_Reconcile()
        {
            var dataService = CreateDataService();
            dataService.Setup(service => service.ClaimNextAsync(LeaseOwner, 120, 3, CurrentTime, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesReconciliationWork?)null);

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.MatchAndUpdateInvoiceAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Claimed_Work_Has_No_Claim_Token_When_Run_Should_Reject_The_Invalid_Claim()
        {
            var dataService = CreateDataService();
            var work = CreateWork();
            work.ClaimToken = null;

            SetupClaim(dataService, work);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(dataService).RunAsync(LeaseOwner));

            Assert.Equal($"Claimed reconciliation work {WorkId} has no claim token", exception.Message);
            dataService.Verify(service => service.MatchAndUpdateInvoiceAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateOnly?>(), It.IsAny<CancellationToken>()), Times.Never);
            dataService.Verify(service => service.FailAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Reconciliation_Is_Cancelled_When_Run_Should_Propagate_Cancellation_Without_Recording_A_Failure()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());

            dataService
                .Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new OperationCanceledException());

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService(dataService).RunAsync(LeaseOwner));

            dataService.Verify(service => service.FailAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Theory]
        [InlineData(0, 120, 300, 60, 3, "The reconciliation maximum work items per run must be greater than zero")]
        [InlineData(2, 0, 300, 60, 3, "The reconciliation lease duration must be greater than zero")]
        [InlineData(2, 120, 0, 60, 3, "The reconciliation no-match retry delay must be greater than zero")]
        [InlineData(2, 120, 300, 0, 3, "The reconciliation failure retry delay must be greater than zero")]
        [InlineData(2, 120, 300, 60, 0, "The reconciliation maximum retry count must be greater than zero")]
        public async Task Given_An_Invalid_Option_When_Run_Should_Reject_The_Configuration(
            int maximumWorkItemsPerRun,
            int leaseDurationSeconds,
            int noMatchRetryDelaySeconds,
            int failureRetryDelaySeconds,
            int maximumRetryCount,
            string expectedMessage)
        {
            var dataService = CreateDataService();
            var options = new ConsolidatedSalesReconciliationOptions
            {
                MaximumWorkItemsPerRun = maximumWorkItemsPerRun,
                LeaseDurationSeconds = leaseDurationSeconds,
                NoMatchRetryDelaySeconds = noMatchRetryDelaySeconds,
                FailureRetryDelaySeconds = failureRetryDelaySeconds,
                MaximumRetryCount = maximumRetryCount
            };

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(dataService, options).RunAsync(LeaseOwner));

            Assert.Equal(expectedMessage, exception.Message);
            dataService.VerifyNoOtherCalls();
        }

        private static InvoiceReconciliationService CreateService(Mock<IInvoiceReconciliationDataService> dataService, ConsolidatedSalesReconciliationOptions? options = null)
        {
            return new InvoiceReconciliationService(
                Mock.Of<ILogger<InvoiceReconciliationService>>(),
                dataService.Object,
                Options.Create(options ?? new ConsolidatedSalesReconciliationOptions
                {
                    MaximumWorkItemsPerRun = 2,
                    LeaseDurationSeconds = 120,
                    NoMatchRetryDelaySeconds = 300,
                    FailureRetryDelaySeconds = 60,
                    MaximumRetryCount = 3
                }),
                new FixedTimeProvider(CurrentTime));
        }

        private static ConsolidatedSalesReconciliationOptions CreateOptions()
        {
            return new ConsolidatedSalesReconciliationOptions
            {
                MaximumWorkItemsPerRun = 2,
                LeaseDurationSeconds = 120,
                NoMatchRetryDelaySeconds = 300,
                FailureRetryDelaySeconds = 60,
                MaximumRetryCount = 3
            };
        }

        private static Mock<IInvoiceReconciliationDataService> CreateDataService()
        {
            var dataService = new Mock<IInvoiceReconciliationDataService>();
            dataService.Setup(service => service.DeferAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<Guid>(),
                    It.IsAny<DateTimeOffset>(),
                    It.IsAny<string>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesWorkFailureResult());
            dataService.Setup(service => service.FailAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<Guid>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<int>(),
                    It.IsAny<DateTimeOffset?>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesWorkFailureResult());
            return dataService;
        }

        private static void SetupClaim(Mock<IInvoiceReconciliationDataService> dataService, ConsolidatedSalesReconciliationWork work)
        {
            dataService.SetupSequence(service => service.ClaimNextAsync(LeaseOwner, 120, 3, CurrentTime, It.IsAny<CancellationToken>()))
                .ReturnsAsync(work)
                .ReturnsAsync((ConsolidatedSalesReconciliationWork?)null);
        }

        private static ConsolidatedSalesReconciliationWork CreateWork(string? standardInvoiceNumber = StandardInvoiceNumber)
        {
            return new ConsolidatedSalesReconciliationWork
            {
                Id = WorkId,
                ClaimToken = ClaimToken,
                StandardInvoiceNumber = standardInvoiceNumber,
                BranchCode = BranchCode,
                ConsolidatedInvoiceNumber = ConsolidatedInvoiceNumber,
                ConsolidatedInvoiceDate = ConsolidatedInvoiceDate
            };
        }

        [Fact]
        public async Task Given_Claimed_Work_Has_No_Claim_Token_When_Run_Should_Reject_The_Work()
        {
            var dataService = CreateDataService();
            var work = CreateWork();
            work.ClaimToken = null;
            SetupClaim(dataService, work);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(dataService).RunAsync(LeaseOwner));

            Assert.Contains(WorkId.ToString(), exception.Message, StringComparison.Ordinal);
            dataService.Verify(service => service.MatchAndUpdateInvoiceAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateOnly?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            dataService.Verify(service => service.FailAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_One_Match_Has_No_Header_Id_When_Run_Should_Record_An_Ambiguous_Match()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());

            dataService
                .Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new InvoiceReconciliationMatchResult { MatchCount = 1 });

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.FailAsync(
                WorkId,
                ClaimToken,
                "AmbiguousInvoiceMatch",
                It.Is<string>(message => message.Contains("matched 1", StringComparison.Ordinal)),
                null,
                1,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Long_Reconciliation_Error_When_Run_Should_Truncate_The_Persisted_Message()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());
            var errorMessage = new string('x', 2500);

            dataService
                .Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException(errorMessage));

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.FailAsync(
                WorkId,
                ClaimToken,
                "ReconciliationFailure",
                It.Is<string>(message => message.Length == 2000 && message.All(character => character == 'x')),
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Theory]
        [InlineData(0, 120, 300, 60, 3, "maximum work items")]
        [InlineData(2, 0, 300, 60, 3, "lease duration")]
        [InlineData(2, 120, 0, 60, 3, "no-match retry delay")]
        [InlineData(2, 120, 300, 0, 3, "failure retry delay")]
        [InlineData(2, 120, 300, 60, 0, "maximum retry count")]
        public async Task Given_Invalid_Options_When_Run_Should_Reject_The_Configuration(
            int maximumWorkItemsPerRun,
            int leaseDurationSeconds,
            int noMatchRetryDelaySeconds,
            int failureRetryDelaySeconds,
            int maximumRetryCount,
            string expectedMessage)
        {
            var dataService = CreateDataService();
            var options = new ConsolidatedSalesReconciliationOptions
            {
                MaximumWorkItemsPerRun = maximumWorkItemsPerRun,
                LeaseDurationSeconds = leaseDurationSeconds,
                NoMatchRetryDelaySeconds = noMatchRetryDelaySeconds,
                FailureRetryDelaySeconds = failureRetryDelaySeconds,
                MaximumRetryCount = maximumRetryCount
            };

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(dataService, options).RunAsync(LeaseOwner));

            Assert.Contains(expectedMessage, exception.Message, StringComparison.OrdinalIgnoreCase);
            dataService.Verify(service => service.ClaimNextAsync(
                It.IsAny<string>(),
                It.IsAny<int>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }


        [Fact]
        public async Task Given_A_Long_Database_Error_When_Run_Should_Truncate_The_Persisted_Failure_Message()
        {
            var dataService = CreateDataService();
            SetupClaim(dataService, CreateWork());
            var errorMessage = new string('x', 2100);
            dataService
                .Setup(service => service.MatchAndUpdateInvoiceAsync(StandardInvoiceNumber, BranchCode, ConsolidatedInvoiceNumber, ConsolidatedInvoiceDate, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException(errorMessage));

            await CreateService(dataService).RunAsync(LeaseOwner);

            dataService.Verify(service => service.FailAsync(
                WorkId,
                ClaimToken,
                "ReconciliationFailure",
                It.Is<string>(message => message.Length == 2000 && errorMessage.StartsWith(message, StringComparison.Ordinal)),
                CurrentTime.AddSeconds(60),
                3,
                CurrentTime,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Theory]
        [InlineData("MaximumWorkItemsPerRun")]
        [InlineData("LeaseDurationSeconds")]
        [InlineData("NoMatchRetryDelaySeconds")]
        [InlineData("FailureRetryDelaySeconds")]
        [InlineData("MaximumRetryCount")]
        public async Task Given_An_Invalid_Worker_Setting_When_Run_Should_Reject_It_Before_Claiming_Work(string setting)
        {
            var dataService = CreateDataService();
            var options = CreateOptions();
            switch (setting)
            {
                case "MaximumWorkItemsPerRun":
                    options.MaximumWorkItemsPerRun = 0;
                    break;
                case "LeaseDurationSeconds":
                    options.LeaseDurationSeconds = 0;
                    break;
                case "NoMatchRetryDelaySeconds":
                    options.NoMatchRetryDelaySeconds = 0;
                    break;
                case "FailureRetryDelaySeconds":
                    options.FailureRetryDelaySeconds = 0;
                    break;
                case "MaximumRetryCount":
                    options.MaximumRetryCount = 0;
                    break;
            }

            await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(dataService, options).RunAsync(LeaseOwner));

            dataService.VerifyNoOtherCalls();
        }

    }
}
