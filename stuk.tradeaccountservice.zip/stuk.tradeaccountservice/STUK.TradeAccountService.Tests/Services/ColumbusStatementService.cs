﻿using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;
namespace STUK.TradeAccountService.Tests.Services
{
    public class ColumbusStatementDownloadServiceTests
    {
        private readonly Mock<IColumbusWebService> _ws = new(MockBehavior.Strict);
        private readonly Mock<IDbExecutor> _db = new(MockBehavior.Strict);
        private readonly Mock<IAppInsightsLoggerHelper> _logger = new(MockBehavior.Loose);

        private ColumbusStatementDownloadService CreateService()
        {
            var config = new ConfigurationBuilder()
     .AddInMemoryCollection(
         new Dictionary<string, string>
         {
             ["Columbus:Username"] = "API-SalesLedgerUser",
             ["Columbus:Password"] = "SLTESTING",
             ["Columbus:MaxRetryAttempts"] = "3",
             ["Columbus:RetryDelaySeconds"] = "0",
             ["Columbus:MaxDegreeOfParallelism"] = "1",
             ["BlobStorage:StorageAccountUrl"] = "https://blob",
             ["BlobStorage:StatementContainerName"] = "statement"
         }.Select(kvp => new KeyValuePair<string, string?>(kvp.Key, kvp.Value))
     )
     .Build();
            return new ColumbusStatementDownloadService(
                _logger.Object, _db.Object, _ws.Object, config);
        }

        private ColumbusStatementHeader CreateStatement() => new()
        {
            StatementHeaderId = 1,
            AccountCode = "M111247",
            OwningBranch = "307",
            StatementDate = DateTime.ParseExact("28/02/2022", "dd/MM/yyyy", CultureInfo.InvariantCulture)
        };

        [Fact]
        public async Task Should_Process_Statement_Successfully()
        {
            var service = CreateService();
            var statement = CreateStatement();

            _db.Setup(x => x.ExecuteListAsync<ColumbusStatementHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusStatementHeader> { statement });

            SetupOpenSession();
            SetupSearchSuccess();
            SetupPageSuccess();
            SetupDbUpdate();
            SetupCloseSession();

            await service.DownloadAndSyncStatementsAsync();

            _ws.Verify(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            _ws.Verify(x => x.CloseSessionAsync(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task Should_Exit_When_No_Statements()
        {
            var service = CreateService();

            _db.Setup(x => x.ExecuteListAsync<ColumbusStatementHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusStatementHeader>());

            await service.DownloadAndSyncStatementsAsync();

            _ws.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Should_Stop_When_DB_Fails()
        {
            var service = CreateService();

            _db.Setup(x => x.ExecuteListAsync<ColumbusStatementHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ThrowsAsync(new Exception());

            await service.DownloadAndSyncStatementsAsync();
        }

       
        [Fact]
        public async Task Should_Skip_When_Archive_Null()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            SetupStatementList(stmt);

            _ws.Setup(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusOpenSessionResult
                {
                    ErrorNumber = 0,
                    Archive = null
                });

            await service.DownloadAndSyncStatementsAsync();
        }

        [Fact]
        public async Task Should_Stop_When_BeginSearch_Fails()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            SetupStatementList(stmt);
            SetupOpenSession();

            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(),
                null, It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((1, "error"));

            await service.DownloadAndSyncStatementsAsync();
        }

        [Fact]
        public async Task Should_Stop_When_No_Documents()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            SetupStatementList(stmt);
            SetupOpenSession();

            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(),
                null, It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult
                {
                    TotalDocuments = 0,
                    OperationStatus = "COMPLETE"
                });

            SetupCloseSession();

            await service.DownloadAndSyncStatementsAsync();
        }

        [Fact]
        public async Task Should_Retry_Search_When_Active()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            SetupStatementList(stmt);
            SetupOpenSession();

            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(),
                null, It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((0, null));

            var seq = new MockSequence();
            _ws.InSequence(seq)
                .Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult { OperationStatus = "ACTIVE" });

            _ws.InSequence(seq)
                .Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult
                {
                    OperationStatus = "COMPLETE",
                    TotalDocuments = 1
                });

            SetupPageSuccess();
            SetupStatementList(stmt);

            await service.DownloadAndSyncStatementsAsync();
        }

        [Fact]
        public async Task Should_Retry_Page_When_Active()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            SetupStatementList(stmt);
            SetupOpenSession();
            SetupSearchSuccess();

            _ws.Setup(x => x.BeginPageOperationAsync(It.IsAny<string>(), It.IsAny<int>()))
                .ReturnsAsync((0, null));

            var seq = new MockSequence();

            _ws.InSequence(seq)
                .Setup(x => x.GetPageResultsAndUploadToBlobAsync(
                    It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                    null, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(),
                    It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse { OperationStatus = "ACTIVE" });

            _ws.InSequence(seq)
                .Setup(x => x.GetPageResultsAndUploadToBlobAsync(
                    It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                    null, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(),
                    It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse { OperationStatus = "COMPLETE", ErrorNumber = 0 });

            SetupDbUpdate();
            SetupCloseSession();

            await service.DownloadAndSyncStatementsAsync();
        }

        [Fact]
        public async Task Should_Log_When_DB_Update_Returns_Zero()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            SetupStatementList(stmt);
            SetupOpenSession();
            SetupSearchSuccess();
            SetupPageSuccess();

            _db.Setup(x => x.ExecuteWithOutputAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(0);

            SetupCloseSession();

            await service.DownloadAndSyncStatementsAsync();
        }

        [Fact]
        public async Task Should_Handle_Invalid_CreationTime()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            SetupStatementList(stmt);
            SetupOpenSession();
            SetupSearchSuccess();

            _ws.Setup(x => x.BeginPageOperationAsync(It.IsAny<string>(), 1))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetPageResultsAndUploadToBlobAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                null, 1, It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse
                {
                    OperationStatus = "COMPLETE",
                    ErrorNumber = 0,
                    CreationTime = "BAD_DATE"
                });

            SetupDbUpdate();
            SetupCloseSession();

            await service.DownloadAndSyncStatementsAsync();
        }

        [Fact]
        public async Task Should_Download_By_Id()
        {
            var service = CreateService();
            var stmt = CreateStatement();

            _db.Setup(x => x.ExecuteSingleAsync<ColumbusStatementHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(stmt);

            _db.Setup(x => x.ExecuteSingleAsync<ColumbusStatementHeaderMetadataRequest>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new ColumbusStatementHeaderMetadataRequest());

            SetupOpenSession();
            SetupSearchSuccess();
            SetupPageSuccess();
            SetupDbUpdate();
            SetupCloseSession();

            var result = await service.DownloadStatementByStatementHeaderIdAsync(1);

            result.Should().NotBeNull();
        }


        private void SetupStatementList(ColumbusStatementHeader stmt)
        {
            _db.Setup(x => x.ExecuteListAsync<ColumbusStatementHeader>(It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(new List<ColumbusStatementHeader> { stmt });
        }

        private void SetupOpenSession()
        {
            _ws.Setup(x => x.OpenSessionAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusOpenSessionResult
                {
                    SessionId = "S1",
                    ErrorNumber = 0,
                    Archive = new ColumbusArchiveInfo { ArchiveId = 1 }
                });
        }

        private void SetupSearchSuccess()
        {
            _ws.Setup(x => x.BeginSearchOperationAsync(It.IsAny<string>(), It.IsAny<int>(),
                It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), null,
                It.IsAny<string>(), It.IsAny<string>(), null))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetSearchResultsAsync(It.IsAny<string>()))
                .ReturnsAsync(new ColumbusSearchResult
                {
                    OperationStatus = "COMPLETE",
                    TotalDocuments = 1
                });
        }

        private void SetupPageSuccess()
        {
            _ws.Setup(x => x.BeginPageOperationAsync(It.IsAny<string>(), 1))
                .ReturnsAsync((0, null));

            _ws.Setup(x => x.GetPageResultsAndUploadToBlobAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                null, 1, It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new ColumbusPageResponse
                {
                    OperationStatus = "COMPLETE",
                    ErrorNumber = 0,
                    BlobUrl = "url",
                    CalculatedFileName = "file.pdf"
                });
        }

        private void SetupDbUpdate()
        {
            _db.Setup(x => x.ExecuteWithOutputAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()))
                .ReturnsAsync(1);
        }

        private void SetupCloseSession()
        {
            _ws.Setup(x => x.CloseSessionAsync(It.IsAny<string>()))
                .ReturnsAsync(0);
        }
    }
}