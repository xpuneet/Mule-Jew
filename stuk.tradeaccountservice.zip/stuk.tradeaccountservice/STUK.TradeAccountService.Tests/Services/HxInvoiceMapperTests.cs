using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class HxInvoiceMapperTests
    {
        private const string ConsolidatedInvoiceNumber = "3051/00721885";
        private const string DeliveryNoteNumber = "137/00163396";
        private const string CorrelationIdValue = "44a7c9f8-93d1-4eab-b5bc-b2ef58ef634a";

        [Fact]
        public void Given_CompleteHxInvoice_When_Map_Should_MapCanonicalHierarchy()
        {
            var source = CreateInvoice();
            var correlationId = Guid.Parse(CorrelationIdValue);

            var result = CreateMapper().Map(source, correlationId);

            Assert.Equal(correlationId, result.CorrelationId);
            Assert.Equal(ConsolidatedInvoiceNumber, result.ConsolidatedInvoiceNumber);
            Assert.Equal("INV", result.InvoiceTypeCode);
            Assert.Equal("Invoice", result.InvoiceTypeDescription);
            Assert.Equal(new DateOnly(2026, 7, 12), result.InvoiceDate);
            Assert.Equal(new DateOnly(2026, 7, 11), result.TaxPointDate);
            Assert.Equal("BUY-100", result.BuyersOrderNumber);
            Assert.Equal(ConsolidatedInvoiceNumber, result.SourceSuppliersInvoiceNumber);
            Assert.Equal("DEL-HEADER", result.DeliveryNoteNumber);
            Assert.Equal("SUP-HEADER", result.SuppliersOrderReference);
            Assert.Equal("ACC-100", result.CustomerAccountCode);
            Assert.Equal("JEW", result.DocumentBrandCode);
            Assert.Equal("Jewson", result.DocumentBrandDescription);
            Assert.Equal("0580", result.SupplierBranchCode);
            Assert.Equal("Leeds", result.SupplierBranchDescription);
            Assert.Equal("GBP", result.CurrencyCode);
            Assert.Equal("Pounds Sterling", result.CurrencyDescription);
            Assert.Equal("30D", result.CreditTermsCode);
            Assert.Equal("30 Days", result.CreditTermsDescription);
            Assert.Equal(2, result.ExpectedLineCount);
            Assert.Equal(1, result.NumberOfTaxRates);
            Assert.Equal(30.00m, result.LineValueTotal);
            Assert.Equal(30.00m, result.TaxableTotal);
            Assert.Equal(6.00m, result.TaxTotal);
            Assert.Equal(30.00m, result.NetPaymentTotal);
            Assert.Equal(36.00m, result.GrossPaymentTotal);

            Assert.Collection(
                result.Parties,
                party => AssertParty(party, "Supplier", "SUP-100", "Supplier Ltd"),
                party => AssertParty(party, "Buyer", "BUY-ACCOUNT", "Buyer Ltd"),
                party => AssertParty(party, "InvoiceTo", "ACC-100", "Invoice Recipient Ltd"));

            var component = Assert.Single(result.Components);
            Assert.Equal(DeliveryNoteNumber, component.ComponentReferenceKey);
            Assert.Equal("137", component.BranchCode);
            Assert.Equal("00163396", component.StandardInvoiceNumber);
            Assert.Equal(DeliveryNoteNumber, component.DeliveryNoteNumber);
            Assert.Equal("BUY-LINE", component.BuyersOrderNumber);
            Assert.Equal("SUP-LINE", component.SuppliersOrderReference);

            Assert.Collection(result.Lines, line => AssertNormalLine(line), line => AssertTextLine(line));

            var tax = Assert.Single(result.TaxSubTotals);
            Assert.Equal("S", tax.TaxRateCode);
            Assert.Equal(20m, tax.TaxRate);
            Assert.Equal(2, tax.NumberOfLinesAtRate);
            Assert.Equal(30m, tax.TotalValueAtRate);
            Assert.Equal(30m, tax.TaxableValueAtRate);
            Assert.Equal(6m, tax.TaxAtRate);
            Assert.Equal(30m, tax.NetPaymentAtRate);
            Assert.Equal(36m, tax.GrossPaymentAtRate);
        }

        [Fact]
        public void Given_NoReportedLineCount_When_Map_Should_UseMappedLineCount()
        {
            var source = CreateInvoice();
            source.Totals!.NumberOfLines = null;

            var result = CreateMapper().Map(source, Guid.Parse(CorrelationIdValue));

            Assert.Equal(source.Lines.Count, result.ExpectedLineCount);
        }

        [Fact]
        public void Given_ReportedLineCountDiffers_When_Map_Should_UseActualMappedLineCount()
        {
            var source = CreateInvoice();
            source.Totals!.NumberOfLines = source.Lines.Count + 1;

            var result = CreateMapper().Map(source, Guid.Parse(CorrelationIdValue));

            Assert.Equal(source.Lines.Count, result.ExpectedLineCount);
        }

        [Fact]
        public void Given_LinesFromDifferentDeliveryNotes_When_Map_Should_CreateDistinctComponents()
        {
            var source = CreateInvoice();
            source.Lines[1].References.DeliveryNoteNumber = "143/00141790";

            var result = CreateMapper().Map(source, Guid.Parse(CorrelationIdValue));

            Assert.Equal(2, result.Components.Count);
            Assert.Contains(result.Components, component => component.ComponentReferenceKey == DeliveryNoteNumber);
            Assert.Contains(result.Components, component => component.ComponentReferenceKey == "143/00141790");
            Assert.Equal(DeliveryNoteNumber, result.Lines[0].ComponentReferenceKey);
            Assert.Equal("143/00141790", result.Lines[1].ComponentReferenceKey);
        }

        [Fact]
        public void Given_DeliveryNoteWithoutBranchSeparator_When_Map_Should_PreserveCompleteReference()
        {
            var source = CreateInvoice();
            source.Lines = [CreateLine("1", "ADVANCE100")];
            source.Totals!.NumberOfLines = 1;

            var result = CreateMapper().Map(source, Guid.Parse(CorrelationIdValue));

            var component = Assert.Single(result.Components);
            Assert.Null(component.BranchCode);
            Assert.Equal("ADVANCE100", component.StandardInvoiceNumber);
            Assert.Equal("ADVANCE100", component.DeliveryNoteNumber);
        }

        [Fact]
        public void Given_MissingSupplierInvoiceNumber_When_Map_Should_ThrowInvalidDataException()
        {
            var source = CreateInvoice();
            source.References.SuppliersInvoiceNumber = null;

            var exception = Assert.Throws<InvalidDataException>(
                () => CreateMapper().Map(source, Guid.Parse(CorrelationIdValue)));

            Assert.Contains("supplier invoice number", exception.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void Given_MissingLineNumber_When_Map_Should_ThrowInvalidDataException()
        {
            var source = CreateInvoice();
            source.Lines[0].LineNumber = null;

            var exception = Assert.Throws<InvalidDataException>(() => CreateMapper().Map(source, Guid.Parse(CorrelationIdValue)));

            Assert.Contains("line number", exception.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void Given_DuplicateLineNumbers_When_Map_Should_ThrowInvalidDataException()
        {
            var source = CreateInvoice();
            source.Lines[1].LineNumber = source.Lines[0].LineNumber;

            var exception = Assert.Throws<InvalidDataException>(() => CreateMapper().Map(source, Guid.Parse(CorrelationIdValue)));

            Assert.Contains("unique", exception.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void Given_OptionalValuesAreMissing_When_Map_Should_MapAvailableValues()
        {
            var source = new HxInvoiceDto
            {
                References = new HxInvoiceReferencesDto
                {
                    SuppliersInvoiceNumber = ConsolidatedInvoiceNumber
                },
                Lines =
                [
                    new HxInvoiceLineDto
                    {
                        LineNumber = "1"
                    }
                ]
            };

            var result = CreateMapper().Map(source, Guid.Parse(CorrelationIdValue));

            Assert.Equal(ConsolidatedInvoiceNumber, result.ConsolidatedInvoiceNumber);
            Assert.Equal(1, result.ExpectedLineCount);
            Assert.Empty(result.Parties);
            Assert.Empty(result.Components);

            var line = Assert.Single(result.Lines);

            Assert.Null(line.ComponentReferenceKey);
            Assert.Equal("1", line.LineIdentity);
        }

        [Fact]
        public void Given_NullSource_When_Map_Should_ThrowArgumentNullException()
        {
            Assert.Throws<ArgumentNullException>(() => CreateMapper().Map(null!, Guid.Parse(CorrelationIdValue)));
        }

        private static void AssertParty(
            ConsolidatedSalesInvoiceParty party,
            string expectedRole,
            string expectedAccountCode,
            string expectedName)
        {
            Assert.Equal(expectedRole, party.PartyRole);
            Assert.Equal(expectedAccountCode, party.AccountCode);
            Assert.Equal(expectedName, party.PartyName);
            Assert.Equal("[\"Line 1\",\"Line 2\",\"Line 3\",\"Line 4\",\"Line 5\"]", party.AddressLinesJson);
            Assert.Equal("Line 1", party.AddressLine1);
            Assert.Equal("Line 2", party.AddressLine2);
            Assert.Equal("Line 3", party.AddressLine3);
            Assert.Equal("Line 4", party.AddressLine4);
            Assert.Equal("Street", party.Street);
            Assert.Equal("City", party.City);
            Assert.Equal("State", party.State);
            Assert.Equal("PO1 1AA", party.Postcode);
        }

        private static void AssertNormalLine(ConsolidatedSalesInvoiceLine line)
        {
            Assert.Equal(DeliveryNoteNumber, line.ComponentReferenceKey);
            Assert.Equal("1", line.LineIdentity);
            Assert.Equal(string.Concat(ConsolidatedInvoiceNumber, "1"), line.SalesforceExternalId);
            Assert.Equal(1, line.LineSequence);
            Assert.Equal("1", line.SourceLineNumber);
            Assert.True(line.PreserveLineNumber);
            Assert.Equal("Add", line.SourceAction);
            Assert.Equal("10", line.OrderLineNumber);
            Assert.Equal("20", line.OriginalOrderLineNumber);
            Assert.Equal(DeliveryNoteNumber, line.DeliveryNoteNumber);
            Assert.Equal("1", line.DeliveryNoteLineNumber);
            Assert.Equal("BUY-LINE", line.BuyersOrderNumber);
            Assert.Equal("SUP-LINE", line.SuppliersOrderReference);
            Assert.Equal(new DateOnly(2026, 7, 10), line.SupplierDespatchDate);
            Assert.Equal("DEL-CODE", line.SupplierCodeForDelivery);
            Assert.Equal("SL", line.OrderTypeCode);
            Assert.Equal("Sales", line.OrderTypeDescription);
            Assert.Equal("N", line.OrderCategoryCode);
            Assert.Equal("Normal", line.OrderCategoryDescription);
            Assert.Equal("D", line.DeliveryMethodCode);
            Assert.Equal("Delivery", line.DeliveryMethodDescription);
            Assert.Equal("PART", line.SupplierPartAnalysisCode);
            Assert.True(line.IsSpecialProduct);
            Assert.False(line.IsTextLine);
            Assert.Equal("PROD-100", line.ProductCode);
            Assert.Equal("Product description", line.ProductDescription);
            Assert.Equal(2m, line.Quantity);
            Assert.Equal("EA", line.QuantityUomCode);
            Assert.Equal("Each", line.QuantityUomDescription);
            Assert.Equal(10m, line.UnitPrice);
            Assert.Equal("EA", line.PriceUomCode);
            Assert.Equal("10", line.PriceUomDescription);
            Assert.Equal(5m, line.PercentageDiscount);
            Assert.Equal("S", line.TaxRateCode);
            Assert.Equal(20m, line.TaxRate);
            Assert.Equal(4m, line.TaxValue);
            Assert.Equal(20m, line.LineTotal);
            Assert.Equal("JOB-100", line.JobNumber);
            Assert.Equal("CONTRACT-100", line.ContractNumber);
            Assert.Equal("SITE-100", line.BuyerLocation);
            Assert.Equal("Operative", line.Operative);
            Assert.Equal("SITE-CODE-100", line.SiteCode);
            Assert.Equal("PLOT-100", line.PlotNumber);
            Assert.Equal("AB12 CDE", line.VehicleRegistration);
            Assert.Equal("HOUSE-TYPE-100", line.HouseType);
            Assert.Equal("PRODUCT-GROUP-100", line.ProductGroup);
            Assert.Equal("Yes", line.OrderAuthorised);
            Assert.Equal("[\"Line 1\",\"Line 2\",\"Line 3\",\"Line 4\",\"Line 5\"]", line.JobAddressLinesJson);
            Assert.Equal("Line 1", line.JobAddressLine1);
            Assert.Equal("Line 2", line.JobAddressLine2);
            Assert.Equal("Line 3", line.JobAddressLine3);
            Assert.Equal("Line 4", line.JobAddressLine4);
            Assert.Equal("Street", line.JobStreet);
            Assert.Equal("City", line.JobCity);
            Assert.Equal("State", line.JobState);
            Assert.Equal("PO1 1AA", line.JobPostcode);
        }

        private static void AssertTextLine(ConsolidatedSalesInvoiceLine line)
        {
            Assert.Equal("2", line.LineIdentity);
            Assert.Equal(string.Concat(ConsolidatedInvoiceNumber, "2"), line.SalesforceExternalId);
            Assert.True(line.IsTextLine);
            Assert.Equal("TEXT", line.ProductCode);
            Assert.Equal(1m, line.Quantity);
            Assert.Equal(0m, line.UnitPrice);
            Assert.Equal(10m, line.LineTotal);
        }

        private static HxInvoiceDto CreateInvoice()
        {
            return new HxInvoiceDto
            {
                Header = new HxInvoiceHeaderDto
                {
                    InvoiceType = CodedValue("INV", "Invoice"),
                    Currency = CodedValue("GBP", "Pounds Sterling")
                },
                References = new HxInvoiceReferencesDto
                {
                    BuyersOrderNumber = "BUY-100",
                    SuppliersInvoiceNumber = ConsolidatedInvoiceNumber,
                    DeliveryNoteNumber = "DEL-HEADER",
                    SuppliersOrderReference = "SUP-HEADER"
                },
                Consolidated = new HxConsolidatedHeaderDto
                {
                    DocumentBrand = CodedValue("JEW", "Jewson"),
                    SupplierBranch = CodedValue("0580", "Leeds"),
                    CreditTerms = CodedValue("30D", "30 Days")
                },
                InvoiceDate = new DateOnly(2026, 7, 12),
                TaxPointDate = new DateOnly(2026, 7, 11),
                Supplier = CreateParty("SUP-100", "Supplier Ltd"),
                Buyer = CreateParty("BUY-ACCOUNT", "Buyer Ltd"),
                InvoiceTo = CreateParty("ACC-100", "Invoice Recipient Ltd"),
                Lines =
                [
                    CreateLine("1", DeliveryNoteNumber),
                    CreateLine("2", DeliveryNoteNumber, isTextLine: true)
                ],
                TaxSubTotals =
                [
                    new HxTaxSubTotalDto
                    {
                        TaxRate = new HxCodedDecimalDto { Code = "S", Value = 20m },
                        NumberOfLinesAtRate = 2,
                        TotalValueAtRate = 30m,
                        TaxableValueAtRate = 30m,
                        TaxAtRate = 6m,
                        NetPaymentAtRate = 30m,
                        GrossPaymentAtRate = 36m
                    }
                ],
                Totals = new HxInvoiceTotalsDto
                {
                    NumberOfLines = 2,
                    NumberOfTaxRates = 1,
                    LineValueTotal = 30m,
                    TaxableTotal = 30m,
                    TaxTotal = 6m,
                    NetPaymentTotal = 30m,
                    GrossPaymentTotal = 36m
                }
            };
        }

        private static HxInvoiceLineDto CreateLine(string lineNumber, string deliveryNoteNumber, bool isTextLine = false)
        {
            return new HxInvoiceLineDto
            {
                Action = "Add",
                LineNumber = lineNumber,
                PreserveLineNumber = true,
                References = new HxInvoiceLineReferencesDto
                {
                    OrderLineNumber = "10",
                    DeliveryNoteNumber = deliveryNoteNumber,
                    DeliveryNoteLineNumber = lineNumber
                },
                Consolidated = new HxConsolidatedLineDto
                {
                    DocumentTextLine = isTextLine,
                    OriginalOrderLineNumber = "20",
                    SupplierPartAnalysisCode = "PART",
                    SpecialProduct = true,
                    BuyersOrderNumber = "BUY-LINE",
                    SuppliersOrderReference = "SUP-LINE",
                    SupplierDespatchDate = new DateOnly(2026, 7, 10),
                    SupplierCodeForDelivery = "DEL-CODE",
                    SupplierOrderFlags = new HxSupplierOrderFlagsDto
                    {
                        OrderType = CodedValue("SL", "Sales"),
                        OrderCategory = CodedValue("N", "Normal"),
                        DeliveryMethod = CodedValue("D", "Delivery")
                    },
                    CustomerInformation = new HxCustomerInformationDto
                    {
                        JobNumber = "JOB-100",
                        JobAddress = CreateAddress(),
                        ContractNumber = "CONTRACT-100",
                        BuyerLocation = "SITE-100",
                        Operative = "Operative",
                        SiteCode = "SITE-CODE-100",
                        PlotNumber = "PLOT-100",
                        VehicleRegistration = "AB12 CDE",
                        HouseType = "HOUSE-TYPE-100",
                        ProductGroup = "PRODUCT-GROUP-100",
                        OrderAuthorised = "Yes"
                    }
                },
                Product = new HxProductDto
                {
                    SuppliersProductCode = "PROD-100",
                    Description = "Product description"
                },
                Quantity = new HxQuantityDto
                {
                    Amount = 2m,
                    UomCode = "EA",
                    UomDescription = "Each"
                },
                Price = new HxPriceDto
                {
                    UnitPrice = 10m,
                    UomCode = "EA",
                    UomDescription = "Each"
                },
                PercentageDiscount = 5m,
                Tax = new HxTaxDto
                {
                    TaxRate = new HxCodedDecimalDto { Code = "S", Value = 20m },
                    TaxValue = 4m
                },
                LineTotal = isTextLine ? 10m : 20m
            };
        }

        private static HxPartyDto CreateParty(string accountCode, string name)
        {
            return new HxPartyDto
            {
                AccountCode = accountCode,
                Name = name,
                Address = CreateAddress()
            };
        }

        private static HxAddressDto CreateAddress()
        {
            return new HxAddressDto
            {
                AddressLines = ["Line 1", "Line 2", "Line 3", "Line 4", "Line 5"],
                Street = "Street",
                City = "City",
                State = "State",
                PostCode = "PO1 1AA"
            };
        }

        private static HxCodedValueDto CodedValue(string code, string description)
        {
            return new HxCodedValueDto { Code = code, Description = description };
        }

        private static HxInvoiceMapper CreateMapper() => new();
    }
}
