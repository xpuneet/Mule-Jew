using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Runtime.CompilerServices;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedSalesIngestionServiceTests
    {
        private static readonly Guid SourceItemId = new("10000000-0000-0000-0000-000000000001");
        private static readonly Guid CorrelationId = new("10000000-0000-0000-0000-000000000002");
        private static readonly Guid ClaimToken = new("10000000-0000-0000-0000-000000000003");
        private static readonly DateTimeOffset SalesforceCooloffStartedOn = new(2026, 8, 24, 9, 0, 0, TimeSpan.Zero);
        private static readonly DateTimeOffset SalesforceEligibleOn = SalesforceCooloffStartedOn.AddHours(48);
        private const string BlobETag = "\"etag\"";
        private const string LeaseOwner = "function-invocation";

        private readonly Mock<IConsolidatedSalesFileDataService> _fileDataService = new();
        private readonly Mock<IConsolidatedSalesBlobSource> _blobSource = new();
        private readonly Mock<IHxConsolidatedInvoiceParser> _parser = new();
        private readonly Mock<IHxInvoiceMapper> _mapper = new();
        private readonly Mock<IConsolidatedInvoiceDataService> _invoiceDataService = new();
        private readonly Mock<ILogger<ConsolidatedSalesIngestionService>> _logger = new();

        [Fact]
        public async Task Given_A_Discovered_Source_File_When_Running_Should_Register_Claim_Map_Commit_And_Complete_It()
        {
            var sourceInvoice = new HxInvoiceDto();
            var invoice = new ConsolidatedSalesInvoice { ConsolidatedInvoiceNumber = "CON-100" };
            var registration = CreateRegistration();
            SetupDiscovery([registration]);
            SetupClaimedSource();
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns((Stream _, HxInvoiceParseMetadata metadata, CancellationToken cancellationToken) =>
                {
                    metadata.SanitisationUsed = true;
                    return ToAsyncEnumerable([sourceInvoice], cancellationToken);
                });
            _mapper.Setup(x => x.Map(sourceInvoice, CorrelationId)).Returns(invoice);
            _invoiceDataService
                .Setup(x => x.CommitAsync(SourceItemId, ClaimToken, invoice, SalesforceCooloffStartedOn, 48, SalesforceEligibleOn, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesCommitResult());
            _fileDataService
                .Setup(x => x.CompleteAsync(SourceItemId, ClaimToken, true, null, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.RegisterAsync(registration, It.IsAny<CancellationToken>()), Times.Once);
            _fileDataService.Verify(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()), Times.Exactly(2));
            _fileDataService.Verify(x => x.RecordFirstReadAsync(SourceItemId, ClaimToken, null, It.IsAny<CancellationToken>()), Times.Once);
            _invoiceDataService.Verify(x => x.CommitAsync(SourceItemId, ClaimToken, invoice, SalesforceCooloffStartedOn, 48, SalesforceEligibleOn, null, It.IsAny<CancellationToken>()), Times.Once);
            _fileDataService.Verify(x => x.CompleteAsync(SourceItemId, ClaimToken, true, null, It.IsAny<CancellationToken>()), Times.Once);
            _blobSource.Verify(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_No_Eligible_Work_When_Running_Should_Complete_Without_Opening_A_Blob()
        {
            SetupDiscovery([]);
            _fileDataService
                .Setup(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesSourceItem?)null);

            await CreateService().RunAsync(LeaseOwner);

            _blobSource.Verify(x => x.OpenReadAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
            _parser.Verify(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_An_Empty_Source_When_Running_Should_Complete_And_Collect_Without_Parsing_Or_Salesforce_Work()
        {
            SetupDiscovery([]);
            _fileDataService
                .SetupSequence(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateClaimedSource(contentLength: 0))
                .ReturnsAsync((ConsolidatedSalesSourceItem?)null);
            _fileDataService
                .Setup(x => x.CompleteAsync(SourceItemId, ClaimToken, false, null, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 0, BlobETag, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService().RunAsync(LeaseOwner);

            _blobSource.Verify(x => x.OpenReadAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
            _parser.Verify(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()), Times.Never);
            _invoiceDataService.Verify(x => x.CommitAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<ConsolidatedSalesInvoice>(), It.IsAny<DateTimeOffset>(),
                It.IsAny<int>(), It.IsAny<DateTimeOffset>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.CompleteAsync(SourceItemId, ClaimToken, false, null, It.IsAny<CancellationToken>()), Times.Once);
            _blobSource.Verify(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 0, BlobETag, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_Salesforce_Cooloff_Is_Disabled_When_Committing_Should_Make_Work_Immediately_Eligible()
        {
            var sourceInvoice = new HxInvoiceDto();
            var invoice = new ConsolidatedSalesInvoice { ConsolidatedInvoiceNumber = "CON-100" };
            SetupDiscovery([]);
            SetupClaimedSource();
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns((Stream _, HxInvoiceParseMetadata _, CancellationToken cancellationToken) =>
                    ToAsyncEnumerable([sourceInvoice], cancellationToken));
            _mapper.Setup(x => x.Map(sourceInvoice, CorrelationId)).Returns(invoice);
            _invoiceDataService
                .Setup(x => x.CommitAsync(
                    SourceItemId,
                    ClaimToken,
                    invoice,
                    SalesforceCooloffStartedOn,
                    0,
                    SalesforceCooloffStartedOn,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesCommitResult());
            _fileDataService
                .Setup(x => x.CompleteAsync(SourceItemId, ClaimToken, false, null, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService(enableSalesforceCooloff: false, salesforceCooloffHours: 48).RunAsync(LeaseOwner);

            _invoiceDataService.Verify(x => x.CommitAsync(
                SourceItemId,
                ClaimToken,
                invoice,
                SalesforceCooloffStartedOn,
                0,
                SalesforceCooloffStartedOn,
                null,
                It.IsAny<CancellationToken>()), Times.Once);
            VerifyCooloffLog(SalesforceCooloffStartedOn, false, 48, 0, SalesforceCooloffStartedOn, Times.Once());
        }

        [Fact]
        public async Task Given_Salesforce_Cooloff_Is_Disabled_With_Zero_Hours_When_Running_Should_Accept_The_Configuration()
        {
            SetupDiscovery([]);
            _fileDataService
                .Setup(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesSourceItem?)null);

            await CreateService(enableSalesforceCooloff: false, salesforceCooloffHours: 0).RunAsync(LeaseOwner);

            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Custom_Enabled_Cooloff_When_Committing_Should_Use_The_Configured_Duration()
        {
            const int configuredHours = 12;
            var expectedEligibleOn = SalesforceCooloffStartedOn.AddHours(configuredHours);
            var sourceInvoice = new HxInvoiceDto();
            var invoice = new ConsolidatedSalesInvoice { ConsolidatedInvoiceNumber = "CON-100" };
            SetupDiscovery([]);
            SetupClaimedSource();
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns((Stream _, HxInvoiceParseMetadata _, CancellationToken cancellationToken) =>
                    ToAsyncEnumerable([sourceInvoice], cancellationToken));
            _mapper.Setup(x => x.Map(sourceInvoice, CorrelationId)).Returns(invoice);
            _invoiceDataService
                .Setup(x => x.CommitAsync(
                    SourceItemId, ClaimToken, invoice, SalesforceCooloffStartedOn, configuredHours,
                    expectedEligibleOn, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesCommitResult());
            _fileDataService
                .Setup(x => x.CompleteAsync(SourceItemId, ClaimToken, false, null, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService(enableSalesforceCooloff: true, salesforceCooloffHours: configuredHours).RunAsync(LeaseOwner);

            _invoiceDataService.Verify(x => x.CommitAsync(
                SourceItemId, ClaimToken, invoice, SalesforceCooloffStartedOn, configuredHours,
                expectedEligibleOn, null, It.IsAny<CancellationToken>()), Times.Once);
            VerifyCooloffLog(SalesforceCooloffStartedOn, true, configuredHours, configuredHours, expectedEligibleOn, Times.Once());
        }

        [Fact]
        public async Task Given_Salesforce_Cooloff_Is_Enabled_With_Zero_Hours_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
                CreateService(enableSalesforceCooloff: true, salesforceCooloffHours: 0).RunAsync(LeaseOwner));

            Assert.Equal(
                "Salesforce cool-off hours must be greater than zero when enabled, and cannot be negative",
                exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Salesforce_Cooloff_Is_Disabled_With_Negative_Hours_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(enableSalesforceCooloff: false, salesforceCooloffHours: -1).RunAsync(LeaseOwner));

            Assert.Equal("Salesforce cool-off hours must be greater than zero when enabled, and cannot be negative", exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_A_Parsing_Failure_When_Running_Should_Await_A_Corrected_Blob_Version()
        {
            SetupDiscovery([]);
            SetupClaimedSource();
            SetupReadableBlob();
            var exception = new HxInvoiceParseException(HxInvoiceParseErrorCategory.MalformedXml, "Invalid HX XML");
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns(ThrowingAsyncEnumerable(exception));
            _fileDataService
                .Setup(x => x.AwaitCorrectionAsync(SourceItemId, ClaimToken, "MalformedXml", "Invalid HX XML", null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.AwaitCorrectionAsync(SourceItemId, ClaimToken, "MalformedXml", "Invalid HX XML", null, It.IsAny<CancellationToken>()), Times.Once);
            _fileDataService.Verify(x => x.FailAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>(), It.IsAny<int>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.CompleteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<bool>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _blobSource.Verify(x => x.RenameAsProcessedAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<long>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()), Times.Exactly(2));
            VerifyCorrectionLog("MalformedXml", Times.Once());
        }

        [Fact]
        public async Task Given_A_Later_Invoice_Has_Invalid_Data_When_Running_Should_Not_Commit_Any_Invoice_From_The_File()
        {
            var firstSourceInvoice = new HxInvoiceDto();
            var secondSourceInvoice = new HxInvoiceDto();
            var firstInvoice = new ConsolidatedSalesInvoice { ConsolidatedInvoiceNumber = "CON-100" };
            SetupDiscovery([]);
            SetupClaimedSource();
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns((Stream _, HxInvoiceParseMetadata _, CancellationToken cancellationToken) =>
                    ToAsyncEnumerable([firstSourceInvoice, secondSourceInvoice], cancellationToken));
            _mapper
                .Setup(x => x.Map(firstSourceInvoice, CorrelationId))
                .Returns(firstInvoice);
            _mapper
                .Setup(x => x.Map(secondSourceInvoice, CorrelationId))
                .Throws(new InvalidDataException("The consolidated invoice identity is invalid"));
            _fileDataService
                .Setup(x => x.AwaitCorrectionAsync(
                    SourceItemId,
                    ClaimToken,
                    "InvalidValue",
                    "The consolidated invoice identity is invalid",
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _invoiceDataService.Verify(x => x.CommitAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<ConsolidatedSalesInvoice>(),
                It.IsAny<DateTimeOffset>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.AwaitCorrectionAsync(
                SourceItemId,
                ClaimToken,
                "InvalidValue",
                "The consolidated invoice identity is invalid",
                null,
                It.IsAny<CancellationToken>()), Times.Once);
            VerifyCorrectionLog("InvalidValue", Times.Once());
        }

        [Fact]
        public async Task Given_A_Blob_Failure_When_Running_Should_Record_The_Failure_And_Continue()
        {
            SetupDiscovery([]);
            SetupClaimedSource();
            _blobSource
                .Setup(x => x.OpenReadAsync("consolidated-sales", "ready/test.con.xml", BlobETag, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new IOException("Blob unavailable"));
            _fileDataService
                .Setup(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "Blob unavailable", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "Blob unavailable", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()), Times.Once);
            _fileDataService.Verify(x => x.RecordFirstReadAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()), Times.Exactly(2));
        }

        [Fact]
        public async Task Given_The_Complete_Blob_Cannot_Be_Read_When_Running_Should_Not_Start_The_Salesforce_Cooloff()
        {
            SetupDiscovery([]);
            SetupClaimedSource();
            _blobSource
                .Setup(x => x.OpenReadAsync("consolidated-sales", "ready/test.con.xml", BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() => new FailingReadStream());
            _fileDataService
                .Setup(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "Source read failed", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.RecordFirstReadAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "Source read failed", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_The_Blob_Read_Ends_Early_When_Running_Should_Not_Start_The_Salesforce_Cooloff()
        {
            SetupDiscovery([]);
            SetupClaimedSource();

            _blobSource
                .Setup(x => x.OpenReadAsync("consolidated-sales", "ready/test.con.xml", BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() => new MemoryStream([1, 2]));

            _fileDataService
                .Setup(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "The HX source read returned 2 bytes; 3 bytes were expected", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.RecordFirstReadAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _parser.Verify(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()), Times.Never);
            _invoiceDataService.Verify(x => x.CommitAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<ConsolidatedSalesInvoice>(),
                It.IsAny<DateTimeOffset>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "The HX source read returned 2 bytes; 3 bytes were expected", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_The_Blob_Stream_Is_Not_Readable_When_Running_Should_Not_Start_The_Salesforce_Cooloff()
        {
            SetupDiscovery([]);
            SetupClaimedSource();

            _blobSource
                .Setup(x => x.OpenReadAsync("consolidated-sales", "ready/test.con.xml", BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() => new UnreadableStream());

            _fileDataService
                .Setup(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "The HX source stream is not readable", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.RecordFirstReadAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _parser.Verify(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "The HX source stream is not readable", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_The_First_Read_Cannot_Be_Persisted_When_Running_Should_Not_Parse_Or_Commit_The_File()
        {
            SetupDiscovery([]);
            SetupClaimedSource();
            SetupReadableBlob();

            _fileDataService
                .Setup(x => x.RecordFirstReadAsync(SourceItemId, ClaimToken, null, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("The source claim is stale"));

            _fileDataService
                .Setup(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "The source claim is stale", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _parser.Verify(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()), Times.Never);
            _invoiceDataService.Verify(x => x.CommitAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<ConsolidatedSalesInvoice>(),
                It.IsAny<DateTimeOffset>(),
                It.IsAny<int>(),
                It.IsAny<DateTimeOffset>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.CompleteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<bool>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
            _blobSource.Verify(x => x.RenameAsProcessedAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<long>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(x => x.FailAsync(SourceItemId, ClaimToken, "Unexpected", "The source claim is stale", It.IsAny<DateTimeOffset?>(), 3, null, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_Cancelled_Processing_When_Running_Should_Not_Record_A_Failure()
        {
            SetupDiscovery([]);
            SetupClaimedSource();
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns(ThrowingAsyncEnumerable(new OperationCanceledException()));

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().RunAsync(LeaseOwner));

            _fileDataService.Verify(x => x.FailAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>(), It.IsAny<int>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_The_Per_Run_Limit_When_Running_Should_Not_Claim_More_Work()
        {
            SetupDiscovery([]);
            SetupClaimedSource();
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns(ToAsyncEnumerable<HxInvoiceDto>([], CancellationToken.None));
            _fileDataService
                .Setup(x => x.CompleteAsync(SourceItemId, ClaimToken, false, null, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService(maximumFilesPerRun: 1).RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Completed_Source_Still_Has_Its_Original_Name_When_Discovering_Should_Retry_The_Rename()
        {
            var registration = CreateRegistration();
            SetupDiscovery([registration], new ConsolidatedSalesSourceItem
            {
                BlobContainer = registration.BlobContainer,
                BlobPath = registration.BlobPath,
                ContentLength = registration.ContentLength,
                ETag = registration.ETag,
                Status = "Completed"
            });
            SetupNoClaimableSource();
            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService().RunAsync(LeaseOwner);

            _blobSource.Verify(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()), Times.Once);
            _blobSource.Verify(x => x.OpenReadAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_A_Completed_Source_Rename_Fails_When_Discovering_Should_Continue_To_The_Claim_Phase()
        {
            var registration = CreateRegistration();
            SetupDiscovery([registration], new ConsolidatedSalesSourceItem
            {
                BlobContainer = registration.BlobContainer,
                BlobPath = registration.BlobPath,
                ContentLength = registration.ContentLength,
                ETag = registration.ETag,
                Status = "Completed"
            });
            SetupNoClaimableSource();

            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new IOException("Rename failed"));

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()), Times.Once);
            _blobSource.Verify(x => x.OpenReadAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_An_Unchanged_Source_Awaiting_Correction_When_Running_Should_Not_Open_It_Again()
        {
            SetupDiscovery([CreateRegistration()], new ConsolidatedSalesSourceItem
            {
                Status = "AwaitingCorrection"
            });
            SetupNoClaimableSource();

            await CreateService().RunAsync(LeaseOwner);

            _blobSource.Verify(x => x.OpenReadAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
            _blobSource.Verify(x => x.RenameAsProcessedAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<long>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_An_Unconfigured_Retry_Delay_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
                CreateService(retryDelaySeconds: 0).RunAsync(LeaseOwner));

            Assert.Equal("The consolidated sales retry delay must be greater than zero", exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_An_Unconfigured_Lease_Renewal_Interval_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
                CreateService(leaseRenewalIntervalSeconds: 0).RunAsync(LeaseOwner));

            Assert.Equal("The consolidated sales lease renewal interval must be greater than zero", exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_An_Unconfigured_Lease_Duration_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(leaseDurationSeconds: 0).RunAsync(LeaseOwner));

            Assert.Equal("The consolidated sales lease duration must be greater than zero.", exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_An_Unconfigured_Maximum_Files_Per_Run_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(maximumFilesPerRun: 0).RunAsync(LeaseOwner));

            Assert.Equal("The consolidated sales maximum files per run must be greater than zero", exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_An_Unconfigured_Maximum_Retry_Count_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(maximumRetryCount: 0).RunAsync(LeaseOwner));

            Assert.Equal("The consolidated sales maximum retry count must be greater than zero.", exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_A_Lease_Renewal_Interval_Not_Shorter_Than_The_Lease_When_Running_Should_Reject_The_Configuration()
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
                CreateService(leaseDurationSeconds: 60, leaseRenewalIntervalSeconds: 60).RunAsync(LeaseOwner));

            Assert.Equal("The consolidated sales lease renewal interval must be shorter than the lease duration", exception.Message);
            _blobSource.Verify(x => x.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Processing_Exceeds_The_Renewal_Interval_When_Running_Should_Renew_The_Lease()
        {
            SetupDiscovery([]);
            SetupClaimedSource(leaseDurationSeconds: 10);
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns((Stream _, HxInvoiceParseMetadata _, CancellationToken cancellationToken) =>
                    DelayedAsyncEnumerable(TimeSpan.FromMilliseconds(1250), cancellationToken));
            _fileDataService
                .Setup(x => x.RenewLeaseAsync(SourceItemId, ClaimToken, 10, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesLeaseResult());
            _fileDataService
                .Setup(x => x.CompleteAsync(SourceItemId, ClaimToken, false, null, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            _blobSource
                .Setup(x => x.RenameAsProcessedAsync("consolidated-sales", "ready/test.con.xml", 3, BlobETag, It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService(
                maximumFilesPerRun: 1,
                leaseDurationSeconds: 10,
                leaseRenewalIntervalSeconds: 1).RunAsync(LeaseOwner);

            _fileDataService.Verify(
                x => x.RenewLeaseAsync(SourceItemId, ClaimToken, 10, null, It.IsAny<CancellationToken>()),
                Times.AtLeastOnce());
        }

        [Fact]
        public async Task Given_Lease_Renewal_Fails_When_Processing_Should_Cancel_Processing_Without_Completing_The_File()
        {
            var cancellationObserved = new TaskCompletionSource(
                TaskCreationOptions.RunContinuationsAsynchronously);
            SetupDiscovery([]);
            SetupClaimedSource(leaseDurationSeconds: 10);
            SetupReadableBlob();
            _parser
                .Setup(x => x.ParseAsync(It.IsAny<Stream>(), It.IsAny<HxInvoiceParseMetadata>(), It.IsAny<CancellationToken>()))
                .Returns((Stream _, HxInvoiceParseMetadata _, CancellationToken cancellationToken) =>
                    WaitForCancellationAsyncEnumerable(cancellationObserved, cancellationToken));
            _fileDataService
                .Setup(x => x.RenewLeaseAsync(SourceItemId, ClaimToken, 10, null, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("The source lease could not be renewed"));

            await CreateService(
                maximumFilesPerRun: 1,
                leaseDurationSeconds: 10,
                leaseRenewalIntervalSeconds: 1).RunAsync(LeaseOwner);

            await cancellationObserved.Task;
            _fileDataService.Verify(
                x => x.CompleteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<bool>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()),
                Times.Never);
            _fileDataService.Verify(
                x => x.FailAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTimeOffset?>(), It.IsAny<int>(), It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()),
                Times.Never);
            _blobSource.Verify(
                x => x.RenameAsProcessedAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<long>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
                Times.Never);
        }

        [Fact]
        public async Task Given_Claimed_Source_Has_No_ETag_When_Running_Should_Record_An_Unexpected_Failure()
        {
            SetupDiscovery([]);
            var claimedSource = CreateClaimedSource();
            claimedSource.ETag = null!;

            _fileDataService
                .SetupSequence(service => service.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(claimedSource)
                .ReturnsAsync((ConsolidatedSalesSourceItem?)null);

            _fileDataService
                .Setup(service => service.FailAsync(
                    SourceItemId,
                    ClaimToken,
                    "Unexpected",
                    It.Is<string>(message => message.Contains("does not contain a Blob ETag", StringComparison.Ordinal)),
                    It.IsAny<DateTimeOffset?>(),
                    3,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _blobSource.Verify(service => service.OpenReadAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _fileDataService.Verify(service => service.CompleteAsync(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<bool>(),
                It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Blob_Stream_Is_Not_Readable_When_Running_Should_Record_A_Retryable_Failure()
        {
            SetupDiscovery([]);
            SetupClaimedSource();
            var unreadableStream = new Mock<Stream>();
            unreadableStream.SetupGet(stream => stream.CanRead).Returns(false);

            _blobSource
                .Setup(source => source.OpenReadAsync("consolidated-sales", "ready/test.con.xml", BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(unreadableStream.Object);

            _fileDataService
                .Setup(service => service.FailAsync(
                    SourceItemId,
                    ClaimToken,
                    "Unexpected",
                    "The HX source stream is not readable",
                    It.IsAny<DateTimeOffset?>(),
                    3,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            await CreateService().RunAsync(LeaseOwner);

            _parser.Verify(parser => parser.ParseAsync(
                It.IsAny<Stream>(),
                It.IsAny<HxInvoiceParseMetadata>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _blobSource.Verify(source => source.RenameAsProcessedAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<long>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Renaming_A_Previously_Completed_Source_Fails_When_Discovering_Should_Continue_Discovery()
        {
            var firstRegistration = CreateRegistration();
            var secondRegistration = CreateRegistration();
            secondRegistration.BlobPath = "ready/second.con.xml";
            secondRegistration.SourceFileName = "second.con.xml";

            _blobSource
                .Setup(source => source.DiscoverAsync(It.IsAny<CancellationToken>()))
                .Returns((CancellationToken cancellationToken) => ToAsyncEnumerable([firstRegistration, secondRegistration], cancellationToken));

            _fileDataService
                .SetupSequence(service => service.RegisterAsync(It.IsAny<ConsolidatedSalesSourceRegistration>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceItem
                {
                    Id = SourceItemId,
                    BlobContainer = firstRegistration.BlobContainer,
                    BlobPath = firstRegistration.BlobPath,
                    ContentLength = firstRegistration.ContentLength,
                    ETag = firstRegistration.ETag,
                    Status = "Completed"
                })
                .ReturnsAsync(new ConsolidatedSalesSourceItem { Status = "AwaitingCorrection" });

            _blobSource
                .Setup(source => source.RenameAsProcessedAsync(
                    firstRegistration.BlobContainer,
                    firstRegistration.BlobPath,
                    firstRegistration.ContentLength,
                    BlobETag,
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new IOException("Rename failed"));

            SetupNoClaimableSource();

            await CreateService().RunAsync(LeaseOwner);

            _fileDataService.Verify(service => service.RegisterAsync(secondRegistration, It.IsAny<CancellationToken>()), Times.Once);
            _fileDataService.Verify(service => service.ClaimNextAsync(
                LeaseOwner,
                900,
                3,
                null,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Theory]
        [InlineData(10, 300, 0, 300, 3, "lease duration")]
        [InlineData(0, 300, 900, 300, 3, "maximum files")]
        [InlineData(10, 300, 900, 300, 0, "maximum retry count")]
        public async Task Given_Invalid_Options_When_Running_Should_Reject_The_Configuration(
            int maximumFilesPerRun,
            int retryDelaySeconds,
            int leaseDurationSeconds,
            int leaseRenewalIntervalSeconds,
            int maximumRetryCount,
            string expectedMessage)
        {
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => CreateService(
                maximumFilesPerRun,
                retryDelaySeconds,
                leaseDurationSeconds,
                leaseRenewalIntervalSeconds,
                maximumRetryCount).RunAsync(LeaseOwner));

            Assert.Contains(expectedMessage, exception.Message, StringComparison.OrdinalIgnoreCase);
            _blobSource.Verify(source => source.DiscoverAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        private void SetupDiscovery(
            IReadOnlyList<ConsolidatedSalesSourceRegistration> registrations,
            ConsolidatedSalesSourceItem? registeredSource = null)
        {
            _blobSource
                .Setup(x => x.DiscoverAsync(It.IsAny<CancellationToken>()))
                .Returns((CancellationToken cancellationToken) => ToAsyncEnumerable(registrations, cancellationToken));
            _fileDataService
                .Setup(x => x.RegisterAsync(It.IsAny<ConsolidatedSalesSourceRegistration>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(registeredSource ?? new ConsolidatedSalesSourceItem());
        }

        private void SetupNoClaimableSource()
        {
            _fileDataService
                .Setup(x => x.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesSourceItem?)null);
        }

        private void SetupClaimedSource(int leaseDurationSeconds = 900)
        {
            _fileDataService
                .SetupSequence(x => x.ClaimNextAsync(LeaseOwner, leaseDurationSeconds, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateClaimedSource())
                .ReturnsAsync((ConsolidatedSalesSourceItem?)null);
            _fileDataService
                .Setup(x => x.RecordFirstReadAsync(SourceItemId, ClaimToken, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(SalesforceCooloffStartedOn);
        }

        private void SetupReadableBlob()
        {
            _blobSource
                .Setup(x => x.OpenReadAsync("consolidated-sales", "ready/test.con.xml", BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() => new MemoryStream([1, 2, 3]));
        }

        private ConsolidatedSalesIngestionService CreateService(
            int maximumFilesPerRun = 10,
            int retryDelaySeconds = 300,
            int leaseDurationSeconds = 900,
            int leaseRenewalIntervalSeconds = 300,
            int maximumRetryCount = 3,
            bool enableSalesforceCooloff = true,
            int salesforceCooloffHours = 48)
        {
            var options = Options.Create(new ConsolidatedSalesIngestionOptions
            {
                SourceSystem = "HX",
                ContainerName = "consolidated-sales",
                ReadyPrefix = "ready/",
                FileSuffix = ".con.xml",
                MaximumFilesPerRun = maximumFilesPerRun,
                LeaseDurationSeconds = leaseDurationSeconds,
                LeaseRenewalIntervalSeconds = leaseRenewalIntervalSeconds,
                RetryDelaySeconds = retryDelaySeconds,
                MaximumRetryCount = maximumRetryCount
            });

            return new ConsolidatedSalesIngestionService(
                _logger.Object,
                _fileDataService.Object,
                _blobSource.Object,
                _parser.Object,
                _mapper.Object,
                _invoiceDataService.Object,
                options,
                Options.Create(new ColumbusOptions
                {
                    EnableSalesforceCooloff = enableSalesforceCooloff,
                    SalesforceCooloffHours = salesforceCooloffHours
                }));
        }

        private void VerifyCorrectionLog(string errorCategory, Times times)
        {
            _logger.Verify(
                logger => logger.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((value, _) =>
                        value.ToString()!.Contains("requires correction", StringComparison.Ordinal)
                        && value.ToString()!.Contains(errorCategory, StringComparison.Ordinal)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                times);
        }

        private void VerifyCooloffLog(DateTimeOffset startedOn, bool enabled, int configuredHours, int effectiveHours, DateTimeOffset eligibleOn, Times times)
        {
            _logger.Verify(
                logger => logger.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((value, _) => HasCooloffTelemetry(value, startedOn, enabled, configuredHours, effectiveHours, eligibleOn)),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                times);
        }

        private static bool HasCooloffTelemetry(object state, DateTimeOffset startedOn, bool enabled, int configuredHours, int effectiveHours, DateTimeOffset eligibleOn)
        {
            if (state is not IEnumerable<KeyValuePair<string, object?>> values)
            {
                return false;
            }

            var fields = values.ToDictionary(value => value.Key, value => value.Value);
            return Equals(fields["SalesforceCooloffStartedOn"], startedOn)
                && Equals(fields["EnableSalesforceCooloff"], enabled)
                && Equals(fields["ConfiguredSalesforceCooloffHours"], configuredHours)
                && Equals(fields["EffectiveSalesforceCooloffHours"], effectiveHours)
                && Equals(fields["SalesforceEligibleOn"], eligibleOn);
        }

        private static ConsolidatedSalesSourceItem CreateClaimedSource(long contentLength = 3)
        {
            return new ConsolidatedSalesSourceItem
            {
                Id = SourceItemId,
                CorrelationId = CorrelationId,
                BlobContainer = "consolidated-sales",
                BlobPath = "ready/test.con.xml",
                ContentLength = contentLength,
                ETag = BlobETag,
                Status = "Claimed",
                ClaimToken = ClaimToken
            };
        }

        private static ConsolidatedSalesSourceRegistration CreateRegistration()
        {
            return new ConsolidatedSalesSourceRegistration
            {
                CorrelationId = CorrelationId,
                SourceSystem = "HX",
                BlobContainer = "consolidated-sales",
                BlobPath = "ready/test.con.xml",
                SourceFileName = "test.con.xml",
                ContentLength = 3,
                BlobLastModifiedOn = new DateTimeOffset(2026, 8, 7, 9, 0, 0, TimeSpan.Zero),
                ETag = BlobETag
            };
        }

        private static async IAsyncEnumerable<T> ToAsyncEnumerable<T>(
            IReadOnlyList<T> values,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            foreach (var value in values)
            {
                cancellationToken.ThrowIfCancellationRequested();
                yield return value;
            }

            await Task.CompletedTask;
        }

        private static async IAsyncEnumerable<HxInvoiceDto> ThrowingAsyncEnumerable(
            Exception exception,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await Task.Yield();
            throw exception;
#pragma warning disable CS0162
            yield break;
#pragma warning restore CS0162
        }

        private static async IAsyncEnumerable<HxInvoiceDto> DelayedAsyncEnumerable(
            TimeSpan delay,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            await Task.Delay(delay, cancellationToken);
            yield break;
        }

        private static async IAsyncEnumerable<HxInvoiceDto> WaitForCancellationAsyncEnumerable(
            TaskCompletionSource cancellationObserved,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            try
            {
                await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
            }
            catch (OperationCanceledException)
            {
                cancellationObserved.SetResult();
                throw;
            }

            yield break;
        }

        private sealed class FailingReadStream : MemoryStream
        {
            public FailingReadStream()
                : base([1, 2, 3])
            {
            }

            public override async Task CopyToAsync(
                Stream destination,
                int bufferSize,
                CancellationToken cancellationToken)
            {
                await destination.WriteAsync(new byte[] { 1 }, cancellationToken);
                throw new IOException("Source read failed");
            }
        }

        private sealed class UnreadableStream : MemoryStream
        {
            public override bool CanRead => false;
        }
    }
}
