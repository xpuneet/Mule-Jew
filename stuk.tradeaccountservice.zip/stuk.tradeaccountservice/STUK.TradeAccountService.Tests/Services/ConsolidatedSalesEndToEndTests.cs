using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Common.Salesforce.Services;
using System.Runtime.CompilerServices;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedSalesEndToEndTests
    {
        private const string BlobContainer = "consolidated-sales";
        private const string BlobETag = "\"etag\"";
        private const string BlobPath = "ready/test.con.xml";
        private const string ConsolidatedInvoiceNumber = "CON-100";
        private const string LeaseOwner = "function-invocation";
        private static readonly string ValidSourceXml = HxInvoiceXmlBuilder.BuildDocument(new HxInvoiceXmlBuilder { InvoiceNumber = ConsolidatedInvoiceNumber }.BuildInvoice());
        private static readonly long ValidContentLength = Encoding.UTF8.GetByteCount(ValidSourceXml);

        private static readonly Guid FirstClaimToken = new("90000000-0000-0000-0000-000000000003");
        private static readonly Guid FirstCorrelationId = new("90000000-0000-0000-0000-000000000002");
        private static readonly Guid FirstSourceItemId = new("90000000-0000-0000-0000-000000000001");
        private static readonly DateTimeOffset FirstLastModifiedOn = new(2026, 8, 8, 9, 0, 0, TimeSpan.Zero);
        private static readonly DateTimeOffset SalesforceCooloffStartedOn = new(2026, 8, 8, 9, 5, 0, TimeSpan.Zero);
        private static readonly DateTimeOffset SalesforceEligibleOn = SalesforceCooloffStartedOn.AddHours(48);
        private static readonly Guid SecondClaimToken = new("90000000-0000-0000-0000-000000000006");
        private static readonly Guid SecondCorrelationId = new("90000000-0000-0000-0000-000000000005");
        private static readonly Guid SecondSourceItemId = new("90000000-0000-0000-0000-000000000004");
        private static readonly DateTimeOffset SecondLastModifiedOn = new(2026, 8, 8, 10, 0, 0, TimeSpan.Zero);

        [Fact]
        public async Task Given_A_Representative_Hx_Invoice_When_Mapped_End_To_End_Should_Create_The_Expected_Salesforce_Projection()
        {
            var parseMetadata = new HxInvoiceParseMetadata();

            await using var source = CreateStream(ValidSourceXml);

            var hxInvoices = await ReadAllAsync(new HxConsolidatedInvoiceParser().ParseAsync(source, parseMetadata));

            var canonicalInvoice = new HxInvoiceMapper().Map(Assert.Single(hxInvoices), FirstCorrelationId);
            var salesforceProjection = new SalesforceInvoiceMapper().Map(canonicalInvoice);

            Assert.False(parseMetadata.SanitisationUsed);
            Assert.Equal(FirstCorrelationId, canonicalInvoice.CorrelationId);
            Assert.Equal(ConsolidatedInvoiceNumber, canonicalInvoice.ConsolidatedInvoiceNumber);
            Assert.Equal("INV001", canonicalInvoice.CustomerAccountCode);
            Assert.Equal(1, canonicalInvoice.ExpectedLineCount);

            Assert.Equal(ConsolidatedInvoiceNumber, salesforceProjection.Order.InvoiceNumber);
            Assert.Equal("INV001", salesforceProjection.Order.AccountExternalId);
            Assert.Equal("Draft", salesforceProjection.Order.Status);
            Assert.Equal(1, salesforceProjection.Order.ExpectedLineCount);

            var item = Assert.Single(salesforceProjection.Items);
            Assert.Equal("CON-1001", item.ExternalId);
            Assert.Equal("TEXT", item.ProductCode);
            Assert.Equal("9.99", item.PriceUomDescription);
            Assert.Equal("SITE-CODE-1", item.SiteCode);
            Assert.Equal("PLOT-1", item.PlotNumber);
            Assert.Equal("HOUSE-TYPE-1", item.HouseType);
            Assert.Equal("PRODUCT-GROUP-1", item.ProductGroup);
        }

        [Fact]
        public async Task Given_A_Corrected_Blob_Version_When_Ingestion_Runs_Again_Should_Process_And_Rename_The_Corrected_File()
        {
            var fileDataService = new Mock<IConsolidatedSalesFileDataService>();
            var blobSource = new Mock<IConsolidatedSalesBlobSource>();
            var invoiceDataService = new Mock<IConsolidatedInvoiceDataService>();
            const string invalidXml = "<invalid";
            var invalidContentLength = Encoding.UTF8.GetByteCount(invalidXml);
            var firstRegistration = CreateRegistration(FirstCorrelationId, FirstLastModifiedOn, invalidContentLength);
            var secondRegistration = CreateRegistration(SecondCorrelationId, SecondLastModifiedOn, ValidContentLength);
            var discoveryCall = 0;

            blobSource
                .Setup(source => source.DiscoverAsync(It.IsAny<CancellationToken>()))
                .Returns((CancellationToken cancellationToken) => ToAsyncEnumerable(
                    [discoveryCall++ == 0 ? firstRegistration : secondRegistration],
                    cancellationToken));

            fileDataService
                .Setup(service => service.RegisterAsync(It.IsAny<ConsolidatedSalesSourceRegistration>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceItem { Status = "Pending" });

            fileDataService
                .SetupSequence(service => service.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateClaimedSource(FirstSourceItemId, FirstCorrelationId, FirstClaimToken, invalidContentLength))
                .ReturnsAsync(CreateClaimedSource(SecondSourceItemId, SecondCorrelationId, SecondClaimToken));

            blobSource
                .SetupSequence(source => source.OpenReadAsync(BlobContainer, BlobPath, BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateStream(invalidXml))
                .ReturnsAsync(CreateValidHxStream());

            fileDataService
                .Setup(service => service.AwaitCorrectionAsync(
                    FirstSourceItemId,
                    FirstClaimToken,
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            invoiceDataService
                .Setup(service => service.CommitAsync(
                    SecondSourceItemId,
                    SecondClaimToken,
                    It.IsAny<ConsolidatedSalesInvoice>(),
                    SalesforceCooloffStartedOn,
                    48,
                    SalesforceEligibleOn,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesCommitResult());

            fileDataService
                .Setup(service => service.CompleteAsync(
                    SecondSourceItemId,
                    SecondClaimToken,
                    false,
                    null,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            blobSource
                .Setup(source => source.RenameAsProcessedAsync(
                    BlobContainer,
                    BlobPath,
                    ValidContentLength,
                    BlobETag,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var service = CreateIngestionService(fileDataService, blobSource, invoiceDataService);

            await service.RunAsync(LeaseOwner);
            await service.RunAsync(LeaseOwner);

            fileDataService.Verify(service => service.RegisterAsync(
                It.Is<ConsolidatedSalesSourceRegistration>(registration => registration.BlobLastModifiedOn == FirstLastModifiedOn),
                It.IsAny<CancellationToken>()), Times.Once);

            fileDataService.Verify(service => service.RegisterAsync(
                It.Is<ConsolidatedSalesSourceRegistration>(registration => registration.BlobLastModifiedOn == SecondLastModifiedOn),
                It.IsAny<CancellationToken>()), Times.Once);

            fileDataService.Verify(service => service.AwaitCorrectionAsync(
                FirstSourceItemId,
                FirstClaimToken,
                It.IsAny<string>(),
                It.IsAny<string>(),
                null,
                It.IsAny<CancellationToken>()), Times.Once);

            invoiceDataService.Verify(service => service.CommitAsync(
                SecondSourceItemId,
                SecondClaimToken,
                It.Is<ConsolidatedSalesInvoice>(invoice => invoice.ConsolidatedInvoiceNumber == ConsolidatedInvoiceNumber),
                SalesforceCooloffStartedOn,
                48,
                SalesforceEligibleOn,
                null,
                It.IsAny<CancellationToken>()), Times.Once);

            blobSource.Verify(source => source.RenameAsProcessedAsync(
                BlobContainer,
                BlobPath,
                ValidContentLength,
                BlobETag,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Transient_Blob_Failure_When_The_Work_Becomes_Eligible_Again_Should_Complete_Without_Duplicate_Canonical_Data()
        {
            var fileDataService = new Mock<IConsolidatedSalesFileDataService>();
            var blobSource = new Mock<IConsolidatedSalesBlobSource>();
            var invoiceDataService = new Mock<IConsolidatedInvoiceDataService>();

            SetupRepeatedDiscovery(fileDataService, blobSource);

            fileDataService
                .SetupSequence(service => service.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateClaimedSource(FirstSourceItemId, FirstCorrelationId, FirstClaimToken))
                .ReturnsAsync(CreateClaimedSource(FirstSourceItemId, FirstCorrelationId, SecondClaimToken));

            blobSource
                .SetupSequence(source => source.OpenReadAsync(BlobContainer, BlobPath, BlobETag, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new IOException("Blob unavailable"))
                .ReturnsAsync(CreateValidHxStream());

            fileDataService
                .Setup(service => service.FailAsync(
                    FirstSourceItemId,
                    FirstClaimToken,
                    "Unexpected",
                    "Blob unavailable",
                    It.IsAny<DateTimeOffset?>(),
                    3,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            invoiceDataService
                .Setup(service => service.CommitAsync(
                    FirstSourceItemId,
                    SecondClaimToken,
                    It.IsAny<ConsolidatedSalesInvoice>(),
                    SalesforceCooloffStartedOn,
                    48,
                    SalesforceEligibleOn,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesCommitResult());

            fileDataService
                .Setup(service => service.CompleteAsync(
                    FirstSourceItemId,
                    SecondClaimToken,
                    false,
                    null,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            blobSource
                .Setup(source => source.RenameAsProcessedAsync(
                    BlobContainer,
                    BlobPath,
                    ValidContentLength,
                    BlobETag,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            var service = CreateIngestionService(fileDataService, blobSource, invoiceDataService);

            await service.RunAsync(LeaseOwner);
            await service.RunAsync(LeaseOwner);

            fileDataService.Verify(service => service.FailAsync(
                FirstSourceItemId,
                FirstClaimToken,
                "Unexpected",
                "Blob unavailable",
                It.IsAny<DateTimeOffset?>(),
                3,
                null,
                It.IsAny<CancellationToken>()), Times.Once);

            invoiceDataService.Verify(service => service.CommitAsync(
                FirstSourceItemId,
                SecondClaimToken,
                It.IsAny<ConsolidatedSalesInvoice>(),
                SalesforceCooloffStartedOn,
                48,
                SalesforceEligibleOn,
                null,
                It.IsAny<CancellationToken>()), Times.Once);

            blobSource.Verify(source => source.RenameAsProcessedAsync(
                BlobContainer,
                BlobPath,
                ValidContentLength,
                BlobETag,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_A_Source_Was_Read_When_Database_Commit_Fails_Should_Resume_After_Restart_Without_Losing_The_Source()
        {
            var fileDataService = new Mock<IConsolidatedSalesFileDataService>();
            var blobSource = new Mock<IConsolidatedSalesBlobSource>();
            var invoiceDataService = new Mock<IConsolidatedInvoiceDataService>();

            SetupRepeatedDiscovery(fileDataService, blobSource);
            fileDataService
                .SetupSequence(service => service.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateClaimedSource(FirstSourceItemId, FirstCorrelationId, FirstClaimToken))
                .ReturnsAsync(CreateClaimedSource(FirstSourceItemId, FirstCorrelationId, SecondClaimToken));
            blobSource
                .Setup(source => source.OpenReadAsync(BlobContainer, BlobPath, BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateValidHxStream);
            invoiceDataService
                .SetupSequence(service => service.CommitAsync(
                    FirstSourceItemId,
                    It.IsAny<Guid>(),
                    It.IsAny<ConsolidatedSalesInvoice>(),
                    SalesforceCooloffStartedOn,
                    48,
                    SalesforceEligibleOn,
                    null,
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new IOException("Database unavailable"))
                .ReturnsAsync(new ConsolidatedSalesCommitResult());
            fileDataService
                .Setup(service => service.FailAsync(
                    FirstSourceItemId,
                    FirstClaimToken,
                    "Unexpected",
                    "Database unavailable",
                    It.IsAny<DateTimeOffset?>(),
                    3,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceFailureResult());
            fileDataService
                .Setup(service => service.CompleteAsync(
                    FirstSourceItemId,
                    SecondClaimToken,
                    false,
                    null,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            blobSource
                .Setup(source => source.RenameAsProcessedAsync(
                    BlobContainer,
                    BlobPath,
                    ValidContentLength,
                    BlobETag,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateIngestionService(fileDataService, blobSource, invoiceDataService).RunAsync(LeaseOwner);

            blobSource.Verify(source => source.RenameAsProcessedAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<long>(),
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()), Times.Never);

            await CreateIngestionService(fileDataService, blobSource, invoiceDataService).RunAsync(LeaseOwner);

            invoiceDataService.Verify(service => service.CommitAsync(
                FirstSourceItemId,
                It.IsAny<Guid>(),
                It.IsAny<ConsolidatedSalesInvoice>(),
                SalesforceCooloffStartedOn,
                48,
                SalesforceEligibleOn,
                null,
                It.IsAny<CancellationToken>()), Times.Exactly(2));
            fileDataService.Verify(service => service.FailAsync(
                FirstSourceItemId,
                FirstClaimToken,
                "Unexpected",
                "Database unavailable",
                It.IsAny<DateTimeOffset?>(),
                3,
                null,
                It.IsAny<CancellationToken>()), Times.Once);
            blobSource.Verify(source => source.RenameAsProcessedAsync(
                BlobContainer,
                BlobPath,
                ValidContentLength,
                BlobETag,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_The_First_Processed_Rename_Fails_When_Discovery_Runs_Again_Should_Retry_Only_The_Rename()
        {
            var fileDataService = new Mock<IConsolidatedSalesFileDataService>();
            var blobSource = new Mock<IConsolidatedSalesBlobSource>();
            var invoiceDataService = new Mock<IConsolidatedInvoiceDataService>();
            var registration = CreateRegistration(FirstCorrelationId, FirstLastModifiedOn, ValidContentLength);
            var registerCall = 0;

            blobSource
                .Setup(source => source.DiscoverAsync(It.IsAny<CancellationToken>()))
                .Returns((CancellationToken cancellationToken) => ToAsyncEnumerable([registration], cancellationToken));

            fileDataService
                .Setup(service => service.RegisterAsync(registration, It.IsAny<CancellationToken>()))
                .ReturnsAsync(() => registerCall++ == 0
                    ? new ConsolidatedSalesSourceItem { Status = "Pending" }
                    : new ConsolidatedSalesSourceItem
                    {
                        BlobContainer = BlobContainer,
                        BlobPath = BlobPath,
                        ContentLength = ValidContentLength,
                        ETag = BlobETag,
                        Status = "Completed"
                    });

            fileDataService
                .SetupSequence(service => service.ClaimNextAsync(LeaseOwner, 900, 3, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateClaimedSource(FirstSourceItemId, FirstCorrelationId, FirstClaimToken))
                .ReturnsAsync((ConsolidatedSalesSourceItem?)null);

            blobSource
                .Setup(source => source.OpenReadAsync(BlobContainer, BlobPath, BlobETag, It.IsAny<CancellationToken>()))
                .ReturnsAsync(CreateValidHxStream());

            invoiceDataService
                .Setup(service => service.CommitAsync(
                    FirstSourceItemId,
                    FirstClaimToken,
                    It.IsAny<ConsolidatedSalesInvoice>(),
                    SalesforceCooloffStartedOn,
                    48,
                    SalesforceEligibleOn,
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesCommitResult());

            fileDataService
                .Setup(service => service.CompleteAsync(
                    FirstSourceItemId,
                    FirstClaimToken,
                    false,
                    null,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            blobSource
                .SetupSequence(source => source.RenameAsProcessedAsync(
                    BlobContainer,
                    BlobPath,
                    ValidContentLength,
                    BlobETag,
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new IOException("Rename interrupted"))
                .Returns(Task.CompletedTask);

            var service = CreateIngestionService(fileDataService, blobSource, invoiceDataService);

            await service.RunAsync(LeaseOwner);
            await service.RunAsync(LeaseOwner);

            invoiceDataService.Verify(service => service.CommitAsync(
                FirstSourceItemId,
                FirstClaimToken,
                It.IsAny<ConsolidatedSalesInvoice>(),
                SalesforceCooloffStartedOn,
                48,
                SalesforceEligibleOn,
                null,
                It.IsAny<CancellationToken>()), Times.Once);

            blobSource.Verify(source => source.OpenReadAsync(
                BlobContainer,
                BlobPath,
                BlobETag,
                It.IsAny<CancellationToken>()), Times.Once);

            blobSource.Verify(source => source.RenameAsProcessedAsync(
                BlobContainer,
                BlobPath,
                ValidContentLength,
                BlobETag,
                It.IsAny<CancellationToken>()), Times.Exactly(2));
        }

        private static ConsolidatedSalesIngestionService CreateIngestionService(
            Mock<IConsolidatedSalesFileDataService> fileDataService,
            Mock<IConsolidatedSalesBlobSource> blobSource,
            Mock<IConsolidatedInvoiceDataService> invoiceDataService)
        {
            fileDataService
                .Setup(service => service.RecordFirstReadAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<Guid>(),
                    null,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(SalesforceCooloffStartedOn);

            return new ConsolidatedSalesIngestionService(
                Mock.Of<ILogger<ConsolidatedSalesIngestionService>>(),
                fileDataService.Object,
                blobSource.Object,
                new HxConsolidatedInvoiceParser(),
                new HxInvoiceMapper(),
                invoiceDataService.Object,
                Options.Create(new ConsolidatedSalesIngestionOptions
                {
                    SourceSystem = "HX",
                    ContainerName = BlobContainer,
                    ReadyPrefix = "ready/",
                    FileSuffix = ".con.xml",
                    MaximumFilesPerRun = 1,
                    LeaseDurationSeconds = 900,
                    LeaseRenewalIntervalSeconds = 300,
                    RetryDelaySeconds = 300,
                    MaximumRetryCount = 3
                }),
                Options.Create(new ColumbusOptions
                {
                    EnableSalesforceCooloff = true,
                    SalesforceCooloffHours = 48
                }));
        }

        private static void SetupRepeatedDiscovery(Mock<IConsolidatedSalesFileDataService> fileDataService, Mock<IConsolidatedSalesBlobSource> blobSource)
        {
            var registration = CreateRegistration(FirstCorrelationId, FirstLastModifiedOn, ValidContentLength);

            blobSource
                .Setup(source => source.DiscoverAsync(It.IsAny<CancellationToken>()))
                .Returns((CancellationToken cancellationToken) => ToAsyncEnumerable([registration], cancellationToken));

            fileDataService
                .Setup(service => service.RegisterAsync(registration, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesSourceItem { Status = "Pending" });
        }

        private static ConsolidatedSalesSourceRegistration CreateRegistration(Guid correlationId, DateTimeOffset lastModifiedOn, long contentLength)
        {
            return new ConsolidatedSalesSourceRegistration
            {
                CorrelationId = correlationId,
                SourceSystem = "HX",
                BlobContainer = BlobContainer,
                BlobPath = BlobPath,
                SourceFileName = "test.con.xml",
                ContentLength = contentLength,
                BlobLastModifiedOn = lastModifiedOn,
                ETag = $"etag-{lastModifiedOn.Ticks}"
            };
        }

        private static ConsolidatedSalesSourceItem CreateClaimedSource(Guid sourceItemId, Guid correlationId, Guid claimToken, long? contentLength = null)
        {
            return new ConsolidatedSalesSourceItem
            {
                Id = sourceItemId,
                CorrelationId = correlationId,
                BlobContainer = BlobContainer,
                BlobPath = BlobPath,
                ContentLength = contentLength ?? ValidContentLength,
                ETag = BlobETag,
                Status = "Claimed",
                ClaimToken = claimToken
            };
        }

        private static MemoryStream CreateValidHxStream()
        {
            return CreateStream(ValidSourceXml);
        }

        private static MemoryStream CreateStream(string value)
        {
            return new MemoryStream(Encoding.UTF8.GetBytes(value));
        }

        private static async Task<List<T>> ReadAllAsync<T>(IAsyncEnumerable<T> values)
        {
            var result = new List<T>();
            await foreach (var value in values)
            {
                result.Add(value);
            }

            return result;
        }

        private static async IAsyncEnumerable<T> ToAsyncEnumerable<T>(IReadOnlyList<T> values, [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            foreach (var value in values)
            {
                cancellationToken.ThrowIfCancellationRequested();
                yield return value;
            }

            await Task.CompletedTask;
        }
    }
}
