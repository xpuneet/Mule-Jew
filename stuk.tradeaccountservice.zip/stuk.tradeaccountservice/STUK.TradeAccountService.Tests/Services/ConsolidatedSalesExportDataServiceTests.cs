using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedSalesExportDataServiceTests
    {
        private static readonly Guid ExportRunId = new("20000000-0000-0000-0000-000000000001");
        private static readonly Guid ExportDestinationId = new("20000000-0000-0000-0000-000000000002");
        private static readonly Guid ClaimToken = new("20000000-0000-0000-0000-000000000003");
        private static readonly DateTimeOffset NextAttemptOn = new(2026, 8, 13, 10, 30, 0, TimeSpan.Zero);

        private readonly Mock<IDbExecutor> _dbExecutor = new();

        [Fact]
        public async Task Given_A_Run_Registration_When_Creating_Should_Use_The_Create_Procedure()
        {
            var registration = new ConsolidatedSalesExportRunRegistration
            {
                LogicalRunKey = "2026-08-17",
                CorrelationId = Guid.NewGuid(),
                ExportYear = 2026,
                ExtractFromDate = new DateOnly(2026, 1, 1),
                ScheduledFor = NextAttemptOn
            };
            var expected = new ConsolidatedSalesExportRun { Id = ExportRunId, IsNew = true };
            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesExportRun>(
                    StoredProcedures.CreateConsolidatedSalesExportRun,
                    registration))
                .ReturnsAsync(expected);

            var result = await CreateService().CreateRunAsync(registration);

            Assert.Same(expected, result);
            _dbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_Extraction_Work_When_Processing_Lifecycle_Should_Use_The_Extraction_Procedures()
        {
            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesExportRun>(
                    StoredProcedures.ClaimNextConsolidatedSalesExportRun,
                    It.IsAny<object>()))
                .ReturnsAsync(new ConsolidatedSalesExportRun());

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(
                    StoredProcedures.RenewConsolidatedSalesExportRunLease,
                    It.IsAny<object>()))
                .ReturnsAsync(new ConsolidatedSalesLeaseResult());

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesExportPage>(
                    StoredProcedures.AppendConsolidatedSalesExportPage,
                    It.IsAny<object>()))
                .ReturnsAsync(new ConsolidatedSalesExportPage());

            _dbExecutor
                .Setup(x => x.ExecuteAsync(
                    StoredProcedures.CompleteConsolidatedSalesExportExtraction,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesExportFailureResult>(
                    StoredProcedures.FailConsolidatedSalesExportExtraction,
                    It.IsAny<object>()))
                .ReturnsAsync(new ConsolidatedSalesExportFailureResult());

            var service = CreateService();

            await service.ClaimNextRunAsync("worker", 300, 5);
            await service.RenewRunLeaseAsync(ExportRunId, ClaimToken, 300);
            await service.AppendPageAsync(
                ExportRunId,
                ClaimToken,
                1,
                1,
                new byte[32],
                false,
                "[]");
            await service.CompleteExtractionAsync(
                ExportRunId,
                ClaimToken,
                1,
                0,
                new byte[32]);
            await service.FailExtractionAsync(
                ExportRunId,
                ClaimToken,
                "Transient",
                "Failure",
                true,
                NextAttemptOn,
                3);

            _dbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_Destination_Work_When_Processing_Lifecycle_Should_Use_The_Destination_Procedures()
        {
            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesExportDestinationWork>(
                    StoredProcedures.ClaimNextConsolidatedSalesExportDestination,
                    It.Is<object>(parameters =>
                        Equals(
                            parameters.GetType().GetProperty("exportDestinationId")!.GetValue(parameters),
                            ExportDestinationId))))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationWork());

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(
                    StoredProcedures.RenewConsolidatedSalesExportDestinationLease,
                    It.IsAny<object>()))
                .ReturnsAsync(new ConsolidatedSalesLeaseResult());

            _dbExecutor
                .Setup(x => x.ExecuteAsync(
                    StoredProcedures.CompleteConsolidatedSalesExportDestination,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesExportDestinationFailureResult>(
                    StoredProcedures.FailConsolidatedSalesExportDestination,
                    It.IsAny<object>()))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationFailureResult());

            _dbExecutor
                .Setup(x => x.ExecuteAsync(
                    StoredProcedures.RequeueConsolidatedSalesExportDestination,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            _dbExecutor
                .Setup(x => x.ExecuteListAsync<ConsolidatedSalesExportRow>(
                    StoredProcedures.GetConsolidatedSalesExportRows,
                    It.IsAny<object>()))
                .ReturnsAsync(new[] { new ConsolidatedSalesExportRow { RowSequence = 1 } });

            var service = CreateService();

            await service.ClaimNextDestinationAsync("Phocas", "worker", 300, 5, ExportDestinationId);
            await service.RenewDestinationLeaseAsync(ExportDestinationId, ClaimToken, 300);

            await service.CompleteDestinationAsync(
                ExportDestinationId,
                ClaimToken,
                "2026_ConsXref.txt",
                "/inbound/2026_ConsXref.txt",
                "hash",
                1,
                100,
                "execution-id");

            await service.FailDestinationAsync(
                ExportDestinationId,
                ClaimToken,
                "Transient",
                "Failure",
                NextAttemptOn,
                3);

            await service.RequeueDestinationAsync(ExportDestinationId, "Approved replay");
            var rows = await service.GetRowsAsync(ExportRunId, 0, 1000);

            Assert.Single(rows);
            _dbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_A_Cancelled_Token_When_Creating_A_Run_Should_Not_Call_The_Database()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().CreateRunAsync(new ConsolidatedSalesExportRunRegistration(), token));

            _dbExecutor.VerifyNoOtherCalls();
        }

        [Fact]
        public void Given_A_Null_Executor_When_Constructing_Should_Reject_It()
        {
            Assert.Throws<ArgumentNullException>(() => new ConsolidatedSalesExportDataService(null!));
        }

        private ConsolidatedSalesExportDataService CreateService()
        {
            return new ConsolidatedSalesExportDataService(_dbExecutor.Object);
        }
    }
}
