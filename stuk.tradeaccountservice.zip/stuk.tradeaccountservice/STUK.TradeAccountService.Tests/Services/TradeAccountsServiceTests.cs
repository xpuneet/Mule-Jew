using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text.Json;

namespace STUK.TradeAccountService.Tests.Services;

public class TradeAccountsServiceTests
{
    private readonly Mock<IDbExecutor> _dbExecutorMock;
    private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
    private readonly TradeAccountsService _service;

    public TradeAccountsServiceTests()
    {
        _dbExecutorMock = new Mock<IDbExecutor>();
        _loggerMock = new Mock<IAppInsightsLoggerHelper>();
        _service = new TradeAccountsService(_dbExecutorMock.Object, _loggerMock.Object);
    }

    #region GetAccountByAccountCode

    [Fact]
    public async Task GetAccountByAccountCode_ValidJson_ReturnsDeserializedResponse()
    {
        // Arrange
        var expected = new AccountResponse
        {
            Account = new AccountDetail
            {
                AccountCode = "ACC001",
                Name = "Test Corp",
                ParentAccountCode = "PAR001",
                AccountType = "Trade",
                AccountLevel = "Standard",
                OwningBranch = "BR01",
                OwningBrand = "Brand1"
            }
        };
        var json = JsonSerializer.Serialize(expected);

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountDetailsByAccountCode,
                It.Is<object>(o => o.GetType().GetProperty("accountCode")!.GetValue(o)!.ToString() == "ACC001")))
            .ReturnsAsync(json);

        // Act
        var result = await _service.GetAccountByAccountCodeAsync("ACC001");

        // Assert
        Assert.NotNull(result);
        Assert.Equal("ACC001", result!.Account!.AccountCode);
        Assert.Equal("Test Corp", result.Account.Name);
    }

    [Fact]
    public async Task GetAccountByAccountCode_NullJson_ReturnsEmptyAccountResponse()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountDetailsByAccountCode,
                It.IsAny<object>()))
            .ReturnsAsync((string?)null!);

        // Act
        var result = await _service.GetAccountByAccountCodeAsync("ACC001");

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task GetAccountByAccountCode_EmptyString_ReturnsEmptyAccountResponse()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountDetailsByAccountCode,
                It.IsAny<object>()))
            .ReturnsAsync(string.Empty);

        // Act
        var result = await _service.GetAccountByAccountCodeAsync("ACC001");

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task GetAccountByAccountCode_InvalidJson_ThrowsJsonException()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountDetailsByAccountCode,
                It.IsAny<object>()))
            .ReturnsAsync("{ invalid json }}}");

        // Act & Assert
        await Assert.ThrowsAsync<JsonException>(
            () => _service.GetAccountByAccountCodeAsync("ACC001"));
    }

    [Fact]
    public async Task GetAccountByAccountCode_DbThrowsException_Propagates()
    {
        // Arrange
        var dbException = new InvalidOperationException("Connection timeout");
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountDetailsByAccountCode,
                It.IsAny<object>()))
            .ThrowsAsync(dbException);

        // Act & Assert
        var ex = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _service.GetAccountByAccountCodeAsync("ACC001"));
        Assert.Equal("Connection timeout", ex.Message);
    }

    [Fact]
    public async Task GetAccountByAccountCode_LogsStartAndCompletion()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountDetailsByAccountCode,
                It.IsAny<object>()))
            .ReturnsAsync("{}");

        // Act
        await _service.GetAccountByAccountCodeAsync("ACC001");

        // Assert
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("started") && s.Contains("ACC001")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("completed")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task GetAccountByAccountCode_CallsCorrectStoredProcedure()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountDetailsByAccountCode,
                It.IsAny<object>()))
            .ReturnsAsync("{}");

        // Act
        await _service.GetAccountByAccountCodeAsync("ACC001");

        // Assert
        _dbExecutorMock.Verify(
            db => db.ExecuteSingleAsync<string>(
                "GetAccountDetailsByAccountCode",
                It.IsAny<object>()),
            Times.Once);
    }

    [Fact]
    public async Task GetAccountByAccountCode_WithComplexAccount_DeserializesAllFields()
    {
        // Arrange
        var account = new AccountResponse
        {
            Account = new AccountDetail
            {
                AccountCode = "ACC001",
                Name = "Complex Corp",
                ParentAccountCode = "PAR001",
                AccountType = "Trade",
                AccountLevel = "Premium",
                OwningBranch = "BR01",
                OwningBrand = "Brand1",
                Contacts = new List<Contact>
                {
                    new() { Type = "Primary", Name = "John", Phone = "123456", Email = "john@test.com" }
                },
                Addresses = new List<Address>
                {
                    new() { Type = "Billing", Lines = new List<string> { "123 St" }, Town = "London", PostCode = "SW1A 1AA" }
                },
                PaymentProfile = new PaymentProfile
                {
                    PaymentOnCredit = true,
                    PaymentOnCard = false,
                    AccountOnStop = false,
                    CreditAttributes = new List<CreditAttribute>
                    {
                        new() { Name = "Limit", Code = "LMT", Description = "Credit limit" }
                    },
                    CreditStatuses = new List<CreditStatus>
                    {
                        new() { Name = "Balance", Amount = 5000m, LastUpdatedDate = new DateTime(2026, 1, 1) }
                    }
                }
            }
        };
        var json = JsonSerializer.Serialize(account);
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(StoredProcedures.GetAccountDetailsByAccountCode, It.IsAny<object>()))
            .ReturnsAsync(json);

        // Act
        var result = await _service.GetAccountByAccountCodeAsync("ACC001");

        // Assert
        Assert.NotNull(result);
        Assert.Single(result!.Account!.Contacts);
        Assert.Equal("John", result.Account.Contacts[0].Name);
        Assert.Single(result.Account.Addresses);
        Assert.True(result.Account.PaymentProfile.PaymentOnCredit);
        Assert.Single(result.Account.PaymentProfile.CreditAttributes);
        Assert.Single(result.Account.PaymentProfile.CreditStatuses);
        Assert.Equal(5000m, result.Account.PaymentProfile.CreditStatuses[0].Amount);
    }

    #endregion

    #region SearchAccountBySession

    [Fact]
    public async Task SearchAccountBySession_ValidJson_ReturnsDeserializedResponse()
    {
        // Arrange
        var expected = new AccountSearchResponse
        {
            Pages = new PaginationInfo { PageNumber = 1, LastPage = false },
            Accounts = new List<AccountDetail>
            {
                new() { AccountCode = "ACC001", Name = "Test Corp" },
                new() { AccountCode = "ACC002", Name = "Other Corp" }
            }
        };
        var json = JsonSerializer.Serialize(expected);

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.Is<object>(o =>
                    o.GetType().GetProperty("sessionId")!.GetValue(o)!.ToString() == "session-123" &&
                    (int)o.GetType().GetProperty("pageNumber")!.GetValue(o)! == 1 &&
                    (int)o.GetType().GetProperty("pageSize")!.GetValue(o)! == 10)))
            .ReturnsAsync(json);

        // Act
        var result = await _service.SearchAccountBySessionAsync("session-123", 1, 10);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(1, result!.Pages.PageNumber);
        Assert.False(result.Pages.LastPage);
        Assert.Equal(2, result.Accounts.Count);
        Assert.Equal("ACC001", result.Accounts[0].AccountCode);
    }

    [Fact]
    public async Task SearchAccountBySession_NullJson_ReturnsEmptyAccountSearchResponse()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.IsAny<object>()))
            .ReturnsAsync((string?)null!);

        // Act
        var result = await _service.SearchAccountBySessionAsync("session-123", 1, 10);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task SearchAccountBySession_EmptyString_ReturnsEmptyAccountSearchResponse()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.IsAny<object>()))
            .ReturnsAsync(string.Empty);

        // Act
        var result = await _service.SearchAccountBySessionAsync("session-123", 1, 10);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task SearchAccountBySession_InvalidJson_ThrowsJsonException()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.IsAny<object>()))
            .ReturnsAsync("{ invalid json }}}");

        // Act & Assert
        await Assert.ThrowsAsync<JsonException>(
            () => _service.SearchAccountBySessionAsync("session-123", 1, 10));
    }

    [Fact]
    public async Task SearchAccountBySession_DbThrowsException_Propagates()
    {
        // Arrange
        var dbException = new InvalidOperationException("Connection timeout");
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.IsAny<object>()))
            .ThrowsAsync(dbException);

        // Act & Assert
        var ex = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _service.SearchAccountBySessionAsync("session-123", 1, 10));
        Assert.Equal("Connection timeout", ex.Message);
    }

    [Fact]
    public async Task SearchAccountBySession_LogsStartAndCompletion()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.IsAny<object>()))
            .ReturnsAsync("{}");

        // Act
        await _service.SearchAccountBySessionAsync("session-123", 1, 10);

        // Assert
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("started")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("completed")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task SearchAccountBySession_EmptyJson_LogsWarning()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.IsAny<object>()))
            .ReturnsAsync(string.Empty);

        // Act
        await _service.SearchAccountBySessionAsync("session-123", 1, 10);

        // Assert
        _loggerMock.Verify(
            l => l.LogWarning(
                It.Is<string>(s => s.Contains("empty json")),
                It.IsAny<string>(),
                It.IsAny<string>()),
            Times.Once);
    }

    [Fact]
    public async Task SearchAccountBySession_CallsCorrectStoredProcedure()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetAccountsDetailsBySessionId,
                It.IsAny<object>()))
            .ReturnsAsync("{}");

        // Act
        await _service.SearchAccountBySessionAsync("session-123", 1, 10);

        // Assert
        _dbExecutorMock.Verify(
            db => db.ExecuteSingleAsync<string>(
                "GetAccountsDetailsBySessionId",
                It.IsAny<object>()),
            Times.Once);
    }

    #endregion

    #region LinkUnlinkAccount

    [Fact]
    public async Task LinkUnlinkAccount_ThrowsNotImplementedException()
    {
        await Assert.ThrowsAsync<NotImplementedException>(
            () => _service.LinkUnlinkAccountAsync("ACC001"));
    }

    #endregion

    #region ValidateAccountAsync

    [Fact]
    public async Task ValidateAccountAsync_ValidJson_ReturnsDeserializedResponse()
    {
        // Arrange
        var json = JsonSerializer.Serialize(new AccountValidateResponse
        {
            AccountCode = "ACC001",
            PostcodeIsValid = true,
            BrandIsValid = true,
            OnStop = false,
            Email = "test@test.com"
        });

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()))
            .ReturnsAsync(json);

        // Act
        var result = await _service.ValidateAccountAsync("ACC001", "SW1A 1AA", "Brand1");

        // Assert
        Assert.NotNull(result);
        Assert.Equal("ACC001", result!.AccountCode);
        Assert.True(result.PostcodeIsValid);
        Assert.True(result.BrandIsValid);
    }

    [Fact]
    public async Task ValidateAccountAsync_NullJson_ReturnsNull()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()))
            .ReturnsAsync((string?)null!);

        // Act
        var result = await _service.ValidateAccountAsync("ACC001", "SW1A 1AA", "Brand1");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task ValidateAccountAsync_EmptyJson_ReturnsNull()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()))
            .ReturnsAsync(string.Empty);

        // Act
        var result = await _service.ValidateAccountAsync("ACC001", "SW1A 1AA", "Brand1");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task ValidateAccountAsync_EmptyObjectJson_ReturnsNull()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()))
            .ReturnsAsync("{}");

        // Act
        var result = await _service.ValidateAccountAsync("ACC001", "SW1A 1AA", "Brand1");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task ValidateAccountAsync_CallsCorrectStoredProcedure()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()))
            .ReturnsAsync((string?)null!);

        // Act
        await _service.ValidateAccountAsync("ACC001", "SW1A 1AA", "Brand1");

        // Assert
        _dbExecutorMock.Verify(
            db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()),
            Times.Once);
    }

    [Fact]
    public async Task ValidateAccountAsync_DbThrowsException_Propagates()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()))
            .ThrowsAsync(new Exception("DB error"));

        // Act & Assert
        var ex = await Assert.ThrowsAsync<Exception>(
            () => _service.ValidateAccountAsync("ACC001", "SW1A 1AA", "Brand1"));
        Assert.Equal("DB error", ex.Message);
    }

    [Fact]
    public async Task ValidateAccountAsync_NoRecord_LogsWarning()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<string>(
                StoredProcedures.GetValidateAccount,
                It.IsAny<object>()))
            .ReturnsAsync((string?)null!);

        // Act
        await _service.ValidateAccountAsync("ACC001", "SW1A 1AA", "Brand1");

        // Assert
        _loggerMock.Verify(
            l => l.LogWarning(
                It.Is<string>(s => s.Contains("no record", StringComparison.OrdinalIgnoreCase)),
                It.IsAny<string>(),
                It.IsAny<string>()),
            Times.Once);
    }

    #endregion

    #region GetCreditLimitByAccountCodeAsync

    [Fact]
    public async Task GetCreditLimitByAccountCodeAsync_ValidResult_ReturnsCreditLimit()
    {
        // Arrange
        var expected = new CreditLimitResponse
        {
            Account = "ACC001",
            CreditLimit = 10000m,
            CreditBalance = 5000m,
            OutstandingBalance = 3000m,
            UsedCredit = 2000m
        };

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreditLimitResponse>(
                StoredProcedures.GetAccountCreditLimit,
                It.IsAny<object>()))
            .ReturnsAsync(expected);

        // Act
        var result = await _service.GetCreditLimitByAccountCodeAsync("ACC001");

        // Assert
        Assert.NotNull(result);
        Assert.Equal("ACC001", result!.Account);
        Assert.Equal(10000m, result.CreditLimit);
        Assert.Equal(5000m, result.CreditBalance);
    }

    [Fact]
    public async Task GetCreditLimitByAccountCodeAsync_DbReturnsNull_ReturnsNull()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreditLimitResponse>(
                StoredProcedures.GetAccountCreditLimit,
                It.IsAny<object>()))
            .ReturnsAsync((CreditLimitResponse?)null);

        // Act
        var result = await _service.GetCreditLimitByAccountCodeAsync("ACC001");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task GetCreditLimitByAccountCodeAsync_WithErrorCode_LogsWarning()
    {
        // Arrange
        var response = new CreditLimitResponse
        {
            Account = "ACC001",
            ErrorCode = "ACCOUNT_NOT_FOUND"
        };

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreditLimitResponse>(
                StoredProcedures.GetAccountCreditLimit,
                It.IsAny<object>()))
            .ReturnsAsync(response);

        // Act
        var result = await _service.GetCreditLimitByAccountCodeAsync("ACC001");

        // Assert
        Assert.NotNull(result);
        Assert.Equal("ACCOUNT_NOT_FOUND", result!.ErrorCode);
        _loggerMock.Verify(
            l => l.LogWarning(
                It.Is<string>(s => s.Contains("completed with error", StringComparison.OrdinalIgnoreCase)),
                It.IsAny<string>(),
                It.IsAny<string>()),
            Times.Once);
    }

    [Fact]
    public async Task GetCreditLimitByAccountCodeAsync_NoErrorCode_LogsSuccess()
    {
        // Arrange
        var response = new CreditLimitResponse
        {
            Account = "ACC001",
            CreditLimit = 10000m
        };

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreditLimitResponse>(
                StoredProcedures.GetAccountCreditLimit,
                It.IsAny<object>()))
            .ReturnsAsync(response);

        // Act
        await _service.GetCreditLimitByAccountCodeAsync("ACC001");

        // Assert
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("completed successfully", StringComparison.OrdinalIgnoreCase)),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task GetCreditLimitByAccountCodeAsync_CallsCorrectStoredProcedure()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreditLimitResponse>(
                StoredProcedures.GetAccountCreditLimit,
                It.IsAny<object>()))
            .ReturnsAsync(new CreditLimitResponse { Account = "ACC001" });

        // Act
        await _service.GetCreditLimitByAccountCodeAsync("ACC001");

        // Assert
        _dbExecutorMock.Verify(
            db => db.ExecuteSingleAsync<CreditLimitResponse>(
                StoredProcedures.GetAccountCreditLimit,
                It.IsAny<object>()),
            Times.Once);
    }

    [Fact]
    public async Task GetCreditLimitByAccountCodeAsync_DbThrows_Propagates()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreditLimitResponse>(
                StoredProcedures.GetAccountCreditLimit,
                It.IsAny<object>()))
            .ThrowsAsync(new Exception("Timeout"));

        // Act & Assert
        var ex = await Assert.ThrowsAsync<Exception>(
            () => _service.GetCreditLimitByAccountCodeAsync("ACC001"));
        Assert.Equal("Timeout", ex.Message);
    }

    #endregion
}
