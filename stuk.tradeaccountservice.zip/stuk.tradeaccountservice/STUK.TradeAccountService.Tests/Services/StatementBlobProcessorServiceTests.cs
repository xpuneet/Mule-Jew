﻿using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class StatementBlobProcessorServiceTests
    {
        private readonly Mock<IDbExecutor> _dbExecutorMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly StatementBlobProcessorService _service;

        public StatementBlobProcessorServiceTests()
        {
            _dbExecutorMock = new Mock<IDbExecutor>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();

            _service = new StatementBlobProcessorService(
                _dbExecutorMock.Object,
                _loggerMock.Object);
        }

        #region UpsertBatchAsync

        [Fact]
        public async Task UpsertBatchAsync_EmptyDocuments_ReturnsWithoutCallingDb()
        {
            // Arrange
            var documents = new List<StatementHeaderData>();
            var metadata = new List<StatementMetadataData>();

            // Act
            await _service.UpsertBatchAsync(documents, metadata);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteAsync(
                    It.IsAny<string>(),
                    It.IsAny<object>()),
                Times.Never);
        }

        [Fact]
        public async Task UpsertBatchAsync_EmptyDocuments_LogsWarning()
        {
            // Arrange
            var documents = new List<StatementHeaderData>();
            var metadata = new List<StatementMetadataData>();

            // Act
            await _service.UpsertBatchAsync(documents, metadata);

            // Assert
            _loggerMock.Verify(l =>
                l.LogWarning(
                    It.IsAny<string>(),
                    It.Is<string>(s => s.Contains("0 header(s)")),
                    It.IsAny<string>()),
                Times.Once);
        }

        [Fact]
        public async Task UpsertBatchAsync_WithDocuments_CallsCorrectStoredProcedure()
        {
            // Arrange
            var documents = new List<StatementHeaderData>
            {
                new StatementHeaderData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1),
                    CurrencyCode = "GBP"
                }
            };

            var metadata = new List<StatementMetadataData>
            {
                new StatementMetadataData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1)
                }
            };

            // Act
            await _service.UpsertBatchAsync(documents, metadata);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteAsync(
                    StoredProcedures.InsertStatementFromBlob,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task UpsertBatchAsync_WithDocuments_LogsInformationOnStart()
        {
            // Arrange
            var documents = new List<StatementHeaderData>
            {
                new StatementHeaderData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1),
                    CurrencyCode = "GBP"
                }
            };

            var metadata = new List<StatementMetadataData>();

            // Act
            await _service.UpsertBatchAsync(documents, metadata);

            // Assert
            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("UpsertBatchAsync Started")),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task UpsertBatchAsync_WithDocuments_LogsInformationOnCompletion()
        {
            // Arrange
            var documents = new List<StatementHeaderData>
            {
                new StatementHeaderData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1),
                    CurrencyCode = "GBP"
                }
            };

            var metadata = new List<StatementMetadataData>();

            // Act
            await _service.UpsertBatchAsync(documents, metadata);

            // Assert
            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("UpsertBatchAsync Completed")),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task UpsertBatchAsync_MultipleDocuments_CallsDbOnce()
        {
            // Arrange
            var documents = new List<StatementHeaderData>
            {
                new StatementHeaderData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1),
                    CurrencyCode = "GBP"
                },
                new StatementHeaderData
                {
                    AccountCode = "ACC002",
                    StatementDate = new DateTime(2026, 5, 2),
                    CurrencyCode = "EUR"
                }
            };

            var metadata = new List<StatementMetadataData>
            {
                new StatementMetadataData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1),
                    OriginalFileName = "statement1.pdf",
                    Extension = ".pdf",
                    CalculatedFileName = "calc1.pdf",
                    ContentMd5 = "abc123",
                    ContentLength = 1024,
                    BlobUri = "2026/05/statement1.pdf",
                    CreatedBy = "System"
                },
                new StatementMetadataData
                {
                    AccountCode = "ACC002",
                    StatementDate = new DateTime(2026, 5, 2),
                    OriginalFileName = "statement2.pdf",
                    Extension = ".pdf",
                    CalculatedFileName = "calc2.pdf",
                    ContentMd5 = "def456",
                    ContentLength = 2048,
                    BlobUri = "2026/05/statement2.pdf",
                    CreatedBy = "System"
                }
            };

            // Act
            await _service.UpsertBatchAsync(documents, metadata);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteAsync(
                    StoredProcedures.InsertStatementFromBlob,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task UpsertBatchAsync_WithNullableFields_CallsDbSuccessfully()
        {
            // Arrange
            var documents = new List<StatementHeaderData>
            {
                new StatementHeaderData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1),
                    StatementMonth = null,
                    EndOfNextMonth = null,
                    CurrencyCode = "GBP",
                    LineCount = null,
                    TotalVAT = null,
                    SettDiscountTotal = null,
                    StatementTotal = null,
                    StatementDiscountTotal = null,
                    QueriedBalance = null,
                    BalanceAfterQueries = null,
                    VATThisPeriod = null
                }
            };

            var metadata = new List<StatementMetadataData>
            {
                new StatementMetadataData
                {
                    AccountCode = "ACC001",
                    StatementDate = new DateTime(2026, 5, 1),
                    OriginalFileName = null,
                    Extension = null,
                    CalculatedFileName = null,
                    ContentMd5 = null,
                    ContentLength = 0,
                    BlobUri = null,
                    CreatedBy = null
                }
            };

            // Act
            await _service.UpsertBatchAsync(documents, metadata);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteAsync(
                    StoredProcedures.InsertStatementFromBlob,
                    It.IsAny<object>()),
                Times.Once);
        }

        #endregion
    }
}