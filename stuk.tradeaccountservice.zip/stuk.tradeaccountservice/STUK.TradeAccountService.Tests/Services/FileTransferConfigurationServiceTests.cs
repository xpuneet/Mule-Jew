using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the read-only File Transfer Database configuration boundary
    /// </summary>
    public class FileTransferConfigurationServiceTests
    {
        private readonly Mock<IDbExecutor> _dbExecutor = new(MockBehavior.Strict);

        /// <summary>
        /// Verifies that the action and both connection records come from their established procedures
        /// </summary>
        [Fact]
        public async Task Given_Tm1Identifiers_When_ReadingConfiguration_Should_UseExistingProcedures()
        {
            var action = new FileTransferActionConfiguration
            {
                Id = "action-id",
                SourceId = "source-id",
                DestinationId = "destination-id"
            };
            var sftp = new SynapseSftpConfiguration { IpAddress = "host" };
            var blob = new FileTransferBlobConfiguration { ServiceEndPoint = "https://storage.blob.core.windows.net" };

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<FileTransferActionConfiguration>(
                    StoredProcedures.GetFileTransferConnectionByIntegrationKey,
                    It.Is<object>(value =>
                        Property<string>(value, "integrationKey") == "integration-id"
                        && Property<string>(value, "actionName") == "PICKUP")))
                .ReturnsAsync(action);

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<SynapseSftpConfiguration>(
                    StoredProcedures.GetSftpConnectionConfigBySourceId,
                    It.Is<object>(value => Property<string>(value, "sourceId") == "source-id")))
                .ReturnsAsync(sftp);

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<FileTransferBlobConfiguration>(
                    StoredProcedures.GetBlobConnectionConfigByDestinationId,
                    It.Is<object>(value => Property<string>(value, "destinationId") == "destination-id")))
                .ReturnsAsync(blob);

            var result = await new FileTransferConfigurationService(_dbExecutor.Object).GetTm1PickupAsync("integration-id", "PICKUP");

            Assert.Same(action, result.Action);
            Assert.Same(sftp, result.Sftp);
            Assert.Same(blob, result.Blob);
            _dbExecutor.VerifyAll();
        }

        /// <summary>
        /// Verifies that missing action configuration stops before connection lookups
        /// </summary>
        [Fact]
        public async Task Given_MissingAction_When_ReadingConfiguration_Should_FailClearly()
        {
            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<FileTransferActionConfiguration>(
                    StoredProcedures.GetFileTransferConnectionByIntegrationKey,
                    It.IsAny<object>()))
                .ReturnsAsync((FileTransferActionConfiguration?)null);

            await Assert.ThrowsAsync<InvalidOperationException>(() => new FileTransferConfigurationService(_dbExecutor.Object).GetTm1PickupAsync("integration-id", "PICKUP"));

            _dbExecutor.VerifyAll();
        }

        /// <summary>
        /// Verifies that Concur delivery reverses the connection direction to Blob source and SFTP destination
        /// </summary>
        [Fact]
        public async Task Given_ConcurDeliveryIdentifiers_When_ReadingConfiguration_Should_UseBlobSourceAndSftpDestination()
        {
            var action = new FileTransferActionConfiguration
            {
                Id = "action-id",
                SourceId = "blob-source-id",
                DestinationId = "sftp-destination-id"
            };
            var blob = new FileTransferBlobConfiguration { ServiceEndPoint = "https://storage.blob.core.windows.net" };
            var sftp = new SynapseSftpConfiguration { IpAddress = "concur-host" };

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<FileTransferActionConfiguration>(
                    StoredProcedures.GetFileTransferConnectionByIntegrationKey,
                    It.Is<object>(value =>
                        Property<string>(value, "integrationKey") == "concur-integration"
                        && Property<string>(value, "actionName") == "DROP")))
                .ReturnsAsync(action);

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<FileTransferBlobConfiguration>(
                    StoredProcedures.GetBlobConnectionConfigBySourceId,
                    It.Is<object>(value => Property<string>(value, "sourceId") == "blob-source-id")))
                .ReturnsAsync(blob);

            _dbExecutor
                .Setup(x => x.ExecuteSingleAsync<SynapseSftpConfiguration>(
                    StoredProcedures.GetSftpConnectionConfigByDestinationId,
                    It.Is<object>(value => Property<string>(value, "destinationId") == "sftp-destination-id")))
                .ReturnsAsync(sftp);

            var result = await new FileTransferConfigurationService(_dbExecutor.Object).GetConcurDeliveryAsync("concur-integration", "DROP");

            Assert.Same(action, result.Action);
            Assert.Same(blob, result.Blob);
            Assert.Same(sftp, result.Sftp);
            _dbExecutor.VerifyAll();
        }

        /// <summary>
        /// Verifies missing TM1 connection records are reported independently
        /// </summary>
        [Theory]
        [InlineData(true)]
        [InlineData(false)]
        public async Task Given_MissingTm1Connection_When_ReadingConfiguration_Should_FailClearly(bool missingSftp)
        {
            var action = new FileTransferActionConfiguration { SourceId = "source-id", DestinationId = "destination-id" };
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<FileTransferActionConfiguration>(StoredProcedures.GetFileTransferConnectionByIntegrationKey, It.IsAny<object>())).ReturnsAsync(action);
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<SynapseSftpConfiguration>(StoredProcedures.GetSftpConnectionConfigBySourceId, It.IsAny<object>())).ReturnsAsync(missingSftp ? null : new SynapseSftpConfiguration());
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<FileTransferBlobConfiguration>(StoredProcedures.GetBlobConnectionConfigByDestinationId, It.IsAny<object>())).ReturnsAsync(missingSftp ? new FileTransferBlobConfiguration() : null);

            await Assert.ThrowsAsync<InvalidOperationException>(() => new FileTransferConfigurationService(_dbExecutor.Object).GetTm1PickupAsync("integration-id", "PICKUP"));
        }

        /// <summary>
        /// Verifies missing Concur connection records are reported independently
        /// </summary>
        [Theory]
        [InlineData(true)]
        [InlineData(false)]
        public async Task Given_MissingConcurConnection_When_ReadingConfiguration_Should_FailClearly(bool missingBlob)
        {
            var action = new FileTransferActionConfiguration { SourceId = "source-id", DestinationId = "destination-id" };
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<FileTransferActionConfiguration>(StoredProcedures.GetFileTransferConnectionByIntegrationKey, It.IsAny<object>())).ReturnsAsync(action);
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<FileTransferBlobConfiguration>(StoredProcedures.GetBlobConnectionConfigBySourceId, It.IsAny<object>())).ReturnsAsync(missingBlob ? null : new FileTransferBlobConfiguration());
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<SynapseSftpConfiguration>(StoredProcedures.GetSftpConnectionConfigByDestinationId, It.IsAny<object>())).ReturnsAsync(missingBlob ? new SynapseSftpConfiguration() : null);

            await Assert.ThrowsAsync<InvalidOperationException>(() => new FileTransferConfigurationService(_dbExecutor.Object).GetConcurDeliveryAsync("integration-id", "DROP"));
        }

        /// <summary>
        /// Verifies invalid identifiers and cancellation stop before database access
        /// </summary>
        [Fact]
        public async Task Given_InvalidRequest_When_ReadingConfiguration_Should_StopBeforeDatabase()
        {
            var service = new FileTransferConfigurationService(_dbExecutor.Object);
            using var cancellation = new CancellationTokenSource();
            cancellation.Cancel();

            await Assert.ThrowsAsync<ArgumentException>(() => service.GetTm1PickupAsync(string.Empty, "PICKUP"));
            await Assert.ThrowsAsync<ArgumentException>(() => service.GetConcurDeliveryAsync("integration-id", string.Empty));
            await Assert.ThrowsAsync<OperationCanceledException>(() => service.GetTm1PickupAsync("integration-id", "PICKUP", cancellation.Token));

            _dbExecutor.VerifyNoOtherCalls();
        }

        /// <summary>
        /// Verifies the database executor is a mandatory dependency
        /// </summary>
        [Fact]
        public void Given_MissingExecutor_When_Constructing_Should_RejectDependency()
        {
            Assert.Throws<ArgumentNullException>(() => new FileTransferConfigurationService(null!));
        }

        private static T? Property<T>(object value, string propertyName)
        {
            return (T?)value.GetType().GetProperty(propertyName)?.GetValue(value);
        }
    }
}
