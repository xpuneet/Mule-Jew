using Azure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Tests.Helpers;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests durable Data Lake dataset and token delivery
    /// </summary>
    public class DataLakeExportServiceTests
    {
        private static readonly DateTimeOffset Now = new(2026, 8, 10, 0, 37, 40, TimeSpan.Zero);
        private static readonly DateTimeOffset CreatedOn = new(2026, 8, 10, 0, 30, 25, TimeSpan.Zero);
        private static readonly Guid DestinationId = new("60000000-0000-0000-0000-000000000001");
        private static readonly Guid ExportRunId = new("60000000-0000-0000-0000-000000000002");
        private static readonly Guid ClaimToken = new("60000000-0000-0000-0000-000000000003");
        private static readonly Guid CorrelationId = new("60000000-0000-0000-0000-000000000004");

        private readonly Mock<IConsolidatedSalesExportDataService> _exportDataService = new();
        private readonly Mock<IPhocasConsXrefFileGenerator> _fileGenerator = new();
        private readonly Mock<IDataLakeCompletionTokenGenerator> _tokenGenerator = new();
        private readonly Mock<IDataLakeExportClient> _dataLakeClient = new();

        [Fact]
        public async Task Given_ClaimedSnapshot_When_Run_Should_WriteDatasetAndTokenThenComplete()
        {
            var work = CreateWork();
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            var token = Encoding.UTF8.GetBytes("completion-token");
            SetupClaim(work);
            SetupGeneration(bytes);
            _tokenGenerator
                .Setup(generator => generator.Generate(Now, "DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token);
            _dataLakeClient
                .Setup(client => client.WriteAsync(
                    It.Is<DataLakeExportWriteRequest>(request =>
                        request.FileSystem == "adls-test"
                        && request.DatasetDirectory == "data/reception/ecs_conxref"
                        && request.DatasetFileName == "2026_ConsXref20260810_003025.csv"
                        && request.TokenDirectory == "operational/dl_5oprl_monitor_job_token/token_name=DL_F5_ECS_CONSXREF_DATA"
                        && request.TokenFileName == "DL_F5_ECS_CONSXREF_DATA"
                        && request.TokenContent == token
                        && request.RowCount == 2),
                    It.IsAny<Stream>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DataLakeExportWriteResult
                {
                    DatasetPath = "adls-test/data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv",
                    TokenPath = "adls-test/operational/token"
                });
            _exportDataService
                .Setup(service => service.CompleteDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "2026_ConsXref20260810_003025.csv",
                    "adls-test/data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv",
                    "content-hash",
                    2,
                    bytes.LongLength,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService().RunAsync("invocation-1");

            _fileGenerator.VerifyAll();
            _tokenGenerator.VerifyAll();
            _dataLakeClient.VerifyAll();
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_NoEligibleDestination_When_Run_Should_NotGenerateDatasetOrToken()
        {
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("DataLake", "invocation-1", 900, 5, DestinationId, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesExportDestinationWork?)null);

            await CreateService().RunAsync("invocation-1", DestinationId);

            _fileGenerator.VerifyNoOtherCalls();
            _tokenGenerator.VerifyNoOtherCalls();
            _dataLakeClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_TransientDataLakeFailure_When_Run_Should_DurablyScheduleRetry()
        {
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            SetupClaim(CreateWork());
            SetupGeneration(bytes);
            _tokenGenerator
                .Setup(generator => generator.Generate(Now, "DL_F5_ECS_CONSXREF_DATA"))
                .Returns(Encoding.UTF8.GetBytes("completion-token"));
            _dataLakeClient
                .Setup(client => client.WriteAsync(It.IsAny<DataLakeExportWriteRequest>(), It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(503, "Data Lake unavailable"));
            _exportDataService
                .Setup(service => service.FailDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "DataLakeUnavailable",
                    "Data Lake unavailable",
                    Now.AddMinutes(5),
                    5,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationFailureResult { Status = "Retry" });

            await CreateService().RunAsync("invocation-1");

            _exportDataService.VerifyAll();
            _exportDataService.Verify(service => service.CompleteDestinationAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<long>(), It.IsAny<long>(), It.IsAny<string?>(), It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_ExistingDatasetContainsDifferentExport_When_Run_Should_RecordPermanentFailure()
        {
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            SetupClaim(CreateWork());
            SetupGeneration(bytes);
            _tokenGenerator
                .Setup(generator => generator.Generate(Now, "DL_F5_ECS_CONSXREF_DATA"))
                .Returns(Encoding.UTF8.GetBytes("completion-token"));
            _dataLakeClient
                .Setup(client => client.WriteAsync(It.IsAny<DataLakeExportWriteRequest>(), It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidDataException("The Data Lake dataset is occupied by different export content."));
            _exportDataService
                .Setup(service => service.FailDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "InvalidFileContract",
                    It.Is<string>(message => message.Contains("different export content")),
                    null,
                    1,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationFailureResult { Status = "Failed" });

            await CreateService().RunAsync("invocation-1");

            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_GeneratedRowCountMismatch_When_Run_Should_RecordPermanentFailureWithoutTokenOrDelivery()
        {
            SetupClaim(CreateWork());
            _fileGenerator
                .Setup(generator => generator.GenerateAsync(ExportRunId, 2026, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportFileResult
                {
                    FileName = "2026_ConsXref.txt",
                    RowCount = 1,
                    ByteCount = 5,
                    ContentHash = "content-hash"
                });
            _exportDataService
                .Setup(service => service.FailDestinationAsync(
                    DestinationId,
                    ClaimToken,
                    "InvalidFileContract",
                    It.Is<string>(message => message.Contains("row count")),
                    null,
                    1,
                    null,
                    Now,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportDestinationFailureResult { Status = "Failed" });

            await CreateService().RunAsync("invocation-1");

            _exportDataService.VerifyAll();
            _tokenGenerator.VerifyNoOtherCalls();
            _dataLakeClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_LeaseRenewalFailsDuringDelivery_When_Run_Should_CancelAndContainTheDataLakeWrite()
        {
            var bytes = Encoding.UTF8.GetBytes("row-1\r\nrow-2\r\n");
            var token = Encoding.UTF8.GetBytes("completion-token");
            var deliveryStarted = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var deliveryCancelled = false;
            var timeProvider = new FakeTimeProvider(Now);
            SetupClaim(CreateWork());
            SetupGeneration(bytes);
            _tokenGenerator
                .Setup(generator => generator.Generate(Now, "DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token);
            _exportDataService
                .Setup(service => service.RenewDestinationLeaseAsync(
                    DestinationId,
                    ClaimToken,
                    900,
                    It.Is<DateTimeOffset>(renewedOn => renewedOn >= Now.AddSeconds(60)),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Lease lost"));
            _dataLakeClient
                .Setup(client => client.WriteAsync(It.IsAny<DataLakeExportWriteRequest>(), It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .Returns<DataLakeExportWriteRequest, Stream, CancellationToken>(async (_, _, cancellationToken) =>
                {
                    deliveryStarted.SetResult();
                    try
                    {
                        await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
                    }
                    catch (OperationCanceledException)
                    {
                        deliveryCancelled = true;
                        throw;
                    }

                    return new DataLakeExportWriteResult();
                });

            var runTask = CreateService(timeProvider).RunAsync("invocation-1");
            await deliveryStarted.Task;

            for (var attempt = 0; attempt < 5 && !runTask.IsCompleted; attempt++)
            {
                timeProvider.Advance(TimeSpan.FromSeconds(60));
                await Task.Yield();
            }

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(
                () => runTask.WaitAsync(TimeSpan.FromSeconds(5)));

            Assert.Equal("Lease lost", exception.Message);
            Assert.True(deliveryCancelled);
            _exportDataService.VerifyAll();
            _exportDataService.Verify(service => service.CompleteDestinationAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<long>(), It.IsAny<long>(), It.IsAny<string?>(), It.IsAny<DateTimeOffset?>(),
                It.IsAny<CancellationToken>()), Times.Never);
            _exportDataService.Verify(service => service.FailDestinationAsync(
                It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<int>(), It.IsAny<string?>(),
                It.IsAny<DateTimeOffset?>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        private void SetupClaim(ConsolidatedSalesExportDestinationWork work)
        {
            _exportDataService
                .Setup(service => service.ClaimNextDestinationAsync("DataLake", "invocation-1", 900, 5, null, Now, It.IsAny<CancellationToken>()))
                .ReturnsAsync(work);
        }

        private void SetupGeneration(byte[] bytes)
        {
            _fileGenerator
                .Setup(generator => generator.GenerateAsync(ExportRunId, 2026, It.IsAny<Stream>(), It.IsAny<CancellationToken>()))
                .Returns<Guid, int, Stream, CancellationToken>(async (_, _, stream, cancellationToken) =>
                {
                    await stream.WriteAsync(bytes, cancellationToken);
                    return new ConsolidatedSalesExportFileResult
                    {
                        FileName = "2026_ConsXref.txt",
                        RowCount = 2,
                        ByteCount = bytes.LongLength,
                        ContentHash = "content-hash"
                    };
                });
        }

        private DataLakeExportService CreateService(TimeProvider? timeProvider = null)
        {
            return new DataLakeExportService(
                Mock.Of<ILogger<DataLakeExportService>>(),
                _exportDataService.Object,
                _fileGenerator.Object,
                _tokenGenerator.Object,
                _dataLakeClient.Object,
                Options.Create(new ConsolidatedSalesDataLakeOptions
                {
                    ServiceUri = "https://storage.test.dfs.core.windows.net",
                    FileSystem = "adls-test"
                }),
                timeProvider ?? new FixedTimeProvider(Now));
        }

        private static ConsolidatedSalesExportDestinationWork CreateWork()
        {
            return new ConsolidatedSalesExportDestinationWork
            {
                Id = DestinationId,
                ExportRunId = ExportRunId,
                CorrelationId = CorrelationId,
                ExportYear = 2026,
                ExtractedRowCount = 2,
                Destination = "DataLake",
                Status = "Claimed",
                AttemptCount = 1,
                RetryCycleAttemptCount = 1,
                ClaimToken = ClaimToken,
                CreatedOn = CreatedOn
            };
        }
    }
}
