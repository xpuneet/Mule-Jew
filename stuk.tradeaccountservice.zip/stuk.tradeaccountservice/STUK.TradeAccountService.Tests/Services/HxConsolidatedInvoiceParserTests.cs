using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Tests.Services
{
    public class HxConsolidatedInvoiceParserTests
    {
        private readonly HxConsolidatedInvoiceParser _parser = new();

        [Fact]
        public async Task Given_A_Complete_Hx_Invoice_When_Parsed_Should_Map_All_Source_Fields()
        {
            // Arrange
            await using var stream = BuildStream(BuildDocument(BuildInvoice()));

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            var invoice = Assert.Single(invoices);
            Assert.Equal("INV", invoice.Header.InvoiceType?.Code);
            Assert.Equal("Invoice", invoice.Header.InvoiceType?.Description);
            Assert.Equal("GBP", invoice.Header.Currency?.Code);
            Assert.Equal("Pounds Sterling", invoice.Header.Currency?.Description);
            Assert.Equal("BUY-ORDER-100", invoice.References.BuyersOrderNumber);
            Assert.Equal("CON-100", invoice.References.SuppliersInvoiceNumber);
            Assert.Equal("DEL-100", invoice.References.DeliveryNoteNumber);
            Assert.Equal("SUP-ORDER-100", invoice.References.SuppliersOrderReference);
            Assert.Equal(new DateOnly(2026, 7, 12), invoice.InvoiceDate);
            Assert.Equal(new DateOnly(2026, 7, 11), invoice.TaxPointDate);

            Assert.Equal("JEW", invoice.Consolidated?.DocumentBrand?.Code);
            Assert.Equal("Jewson", invoice.Consolidated?.DocumentBrand?.Description);
            Assert.Equal("0580", invoice.Consolidated?.SupplierBranch?.Code);
            Assert.Equal("Leeds", invoice.Consolidated?.SupplierBranch?.Description);
            Assert.Equal("30D", invoice.Consolidated?.CreditTerms?.Code);
            Assert.Equal("30 Days", invoice.Consolidated?.CreditTerms?.Description);

            AssertParty(invoice.Supplier, "SUP001", "Supplier Ltd", "Supplier Street", "Supplier City", "SU1 1AA");
            AssertParty(invoice.Buyer, "ACC001", "Customer Ltd", "Buyer Street", "Buyer City", "BU1 1AA");
            AssertParty(invoice.InvoiceTo, "INV001", "Invoice Recipient Ltd", "Invoice Street", "Invoice City", "IN1 1AA");

            var line = Assert.Single(invoice.Lines);
            Assert.Equal("Add", line.Action);
            Assert.Equal("1", line.LineNumber);
            Assert.True(line.PreserveLineNumber);
            Assert.Equal("10", line.References.OrderLineNumber);
            Assert.Equal("DEL-LINE-100", line.References.DeliveryNoteNumber);
            Assert.Equal("20", line.References.DeliveryNoteLineNumber);
            Assert.Equal("SKU001", line.Product?.SuppliersProductCode);
            Assert.Equal("Test product", line.Product?.Description);
            Assert.Equal(2m, line.Quantity?.Amount);
            Assert.Equal("EA", line.Quantity?.UomCode);
            Assert.Equal("Each", line.Quantity?.UomDescription);
            Assert.Equal(9.99m, line.Price?.UnitPrice);
            Assert.Equal("EA", line.Price?.UomCode);
            Assert.Equal("Each", line.Price?.UomDescription);
            Assert.Equal(5m, line.PercentageDiscount);
            Assert.Equal("S", line.Tax?.TaxRate?.Code);
            Assert.Equal(20m, line.Tax?.TaxRate?.Value);
            Assert.Equal(4m, line.Tax?.TaxValue);
            Assert.Equal(19.98m, line.LineTotal);

            Assert.True(line.Consolidated?.DocumentTextLine);
            Assert.Equal("100", line.Consolidated?.OriginalOrderLineNumber);
            Assert.Equal("ANALYSIS", line.Consolidated?.SupplierPartAnalysisCode);
            Assert.False(line.Consolidated?.SpecialProduct);
            Assert.Equal("ORD-100", line.Consolidated?.BuyersOrderNumber);
            Assert.Equal("SUP-REF-100", line.Consolidated?.SuppliersOrderReference);
            Assert.Equal(new DateOnly(2026, 7, 10), line.Consolidated?.SupplierDespatchDate);
            Assert.Equal("DEL-SUP-001", line.Consolidated?.SupplierCodeForDelivery);
            Assert.Equal("SALE", line.Consolidated?.SupplierOrderFlags?.OrderType?.Code);
            Assert.Equal("NORMAL", line.Consolidated?.SupplierOrderFlags?.OrderCategory?.Code);
            Assert.Equal("DELIVERY", line.Consolidated?.SupplierOrderFlags?.DeliveryMethod?.Code);
            Assert.Equal("JOB-1", line.Consolidated?.CustomerInformation?.JobNumber);
            Assert.Equal("CONTRACT-1", line.Consolidated?.CustomerInformation?.ContractNumber);
            Assert.Equal("SITE-1", line.Consolidated?.CustomerInformation?.BuyerLocation);
            Assert.Equal("Operative Name", line.Consolidated?.CustomerInformation?.Operative);
            Assert.Equal("SITE-CODE-1", line.Consolidated?.CustomerInformation?.SiteCode);
            Assert.Equal("PLOT-1", line.Consolidated?.CustomerInformation?.PlotNumber);
            Assert.Equal("AB12 CDE", line.Consolidated?.CustomerInformation?.VehicleRegistration);
            Assert.Equal("HOUSE-TYPE-1", line.Consolidated?.CustomerInformation?.HouseType);
            Assert.Equal("PRODUCT-GROUP-1", line.Consolidated?.CustomerInformation?.ProductGroup);
            Assert.Equal("Authoriser Name", line.Consolidated?.CustomerInformation?.OrderAuthorised);
            Assert.Equal(["Job Address 1", "Job Address 2"], line.Consolidated?.CustomerInformation?.JobAddress?.AddressLines);
            Assert.Equal("Job Street", line.Consolidated?.CustomerInformation?.JobAddress?.Street);
            Assert.Equal("Job City", line.Consolidated?.CustomerInformation?.JobAddress?.City);
            Assert.Equal("Job State", line.Consolidated?.CustomerInformation?.JobAddress?.State);
            Assert.Equal("JO1 1AA", line.Consolidated?.CustomerInformation?.JobAddress?.PostCode);

            var taxSubTotal = Assert.Single(invoice.TaxSubTotals);
            Assert.Equal("S", taxSubTotal.TaxRate?.Code);
            Assert.Equal(20m, taxSubTotal.TaxRate?.Value);
            Assert.Equal(1, taxSubTotal.NumberOfLinesAtRate);
            Assert.Equal(19.98m, taxSubTotal.TotalValueAtRate);
            Assert.Equal(19.98m, taxSubTotal.TaxableValueAtRate);
            Assert.Equal(4m, taxSubTotal.TaxAtRate);
            Assert.Equal(19.98m, taxSubTotal.NetPaymentAtRate);
            Assert.Equal(23.98m, taxSubTotal.GrossPaymentAtRate);

            Assert.Equal(1, invoice.Totals?.NumberOfLines);
            Assert.Equal(1, invoice.Totals?.NumberOfTaxRates);
            Assert.Equal(19.98m, invoice.Totals?.LineValueTotal);
            Assert.Equal(19.98m, invoice.Totals?.TaxableTotal);
            Assert.Equal(4m, invoice.Totals?.TaxTotal);
            Assert.Equal(19.98m, invoice.Totals?.NetPaymentTotal);
            Assert.Equal(23.98m, invoice.Totals?.GrossPaymentTotal);
        }

        [Fact]
        public async Task Given_Multiple_Adjacent_Invoices_When_Parsed_Should_Return_Each_Invoice_Once_In_Order()
        {
            // Arrange
            var xml = BuildDocument(
                BuildInvoice("CON-100"),
                BuildInvoice("CON-200"));

            await using var stream = BuildStream(xml);

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Equal(["CON-100", "CON-200"], invoices.Select(invoice => invoice.References.SuppliersInvoiceNumber));
        }

        [Fact]
        public async Task Given_An_Invoice_With_More_Than_One_Hundred_Lines_When_Parsed_Should_Preserve_All_Lines_In_Order()
        {
            // Arrange
            var invoiceElement = new HxInvoiceXmlBuilder { LineCount = 125 }.BuildInvoice();
            await using var stream = BuildStream(HxInvoiceXmlBuilder.BuildDocument(invoiceElement));

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            var invoice = Assert.Single(invoices);
            Assert.Equal(125, invoice.Lines.Count);
            Assert.Equal("1", invoice.Lines[0].LineNumber);
            Assert.Equal("125", invoice.Lines[^1].LineNumber);
        }

        [Fact]
        public async Task Given_An_Invoice_With_Optional_Sections_Missing_When_Parsed_Should_Return_Null_And_Empty_Values()
        {
            // Arrange
            var invoice = HxInvoiceXmlBuilder.BuildMinimalInvoice("CON-MINIMAL");
            await using var stream = BuildStream(HxInvoiceXmlBuilder.BuildDocument(invoice));

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            var parsedInvoice = Assert.Single(invoices);
            Assert.Equal("CON-MINIMAL", parsedInvoice.References.SuppliersInvoiceNumber);
            Assert.Null(parsedInvoice.Header.InvoiceType);
            Assert.Null(parsedInvoice.Header.Currency);
            Assert.Null(parsedInvoice.Consolidated);
            Assert.Null(parsedInvoice.InvoiceDate);
            Assert.Null(parsedInvoice.TaxPointDate);
            Assert.Null(parsedInvoice.Supplier);
            Assert.Null(parsedInvoice.Buyer);
            Assert.Null(parsedInvoice.InvoiceTo);
            Assert.Empty(parsedInvoice.Lines);
            Assert.Empty(parsedInvoice.TaxSubTotals);
            Assert.Null(parsedInvoice.Totals);
        }

        [Fact]
        public async Task Given_A_Bare_Ampersand_When_Parsed_Should_Sanitise_And_Preserve_The_Value()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice())
                .Replace("Test product", "Timber & Fixings", StringComparison.Ordinal);
            await using var stream = BuildStream(xml);
            var metadata = new HxInvoiceParseMetadata();

            // Act
            var invoices = await ParseAllAsync(stream, metadata);

            // Assert
            Assert.Equal("Timber & Fixings", Assert.Single(invoices).Lines[0].Product?.Description);
            Assert.True(metadata.SanitisationUsed);
        }

        [Theory]
        [InlineData("Timber &amp; Fixings", "Timber & Fixings")]
        [InlineData("Caf&#233; product", "Café product")]
        [InlineData("Caf&#xE9; product", "Café product")]
        public async Task Given_A_Valid_Xml_Entity_When_Parsed_Should_Not_Double_Escape_The_Value(string sourceValue, string expectedValue)
        {
            // Arrange
            var invoice = BuildInvoice().Replace("Test product", sourceValue, StringComparison.Ordinal);
            await using var stream = BuildStream(BuildDocument(invoice));

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Equal(expectedValue, Assert.Single(invoices).Lines[0].Product?.Description);
        }

        [Fact]
        public async Task Given_An_Invalid_Xml_Entity_When_Parsed_Should_Escape_And_Preserve_The_Text()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice())
                .Replace("Test product", "Timber &notAnEntity; Fixings", StringComparison.Ordinal);
            await using var stream = BuildStream(xml);

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Equal("Timber &notAnEntity; Fixings", Assert.Single(invoices).Lines[0].Product?.Description);
        }

        [Fact]
        public async Task Given_An_Invalid_Entity_Followed_By_An_Invalid_Less_Than_Sequence_When_Parsed_Should_Preserve_The_Text()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice())
                .Replace("Test product", "Timber &invalid<] Fixings", StringComparison.Ordinal);
            await using var stream = BuildStream(xml);
            var metadata = new HxInvoiceParseMetadata();

            // Act
            var invoices = await ParseAllAsync(stream, metadata);

            // Assert
            Assert.Equal("Timber &invalid<] Fixings", Assert.Single(invoices).Lines[0].Product?.Description);
            Assert.True(metadata.SanitisationUsed);
        }

        [Fact]
        public async Task Given_An_Invalid_Xml_Character_When_Parsed_Should_Remove_The_Character_During_Fallback()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice())
                .Replace("Test product", "Test\u0001 product", StringComparison.Ordinal);
            await using var stream = BuildStream(xml);

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Equal("Test product", Assert.Single(invoices).Lines[0].Product?.Description);
        }

        [Fact]
        public async Task Given_An_Invalid_Less_Than_Sequence_In_Text_When_Parsed_Should_Escape_And_Preserve_The_Text()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice())
                .Replace("Test product", "Timber !<] Fixings", StringComparison.Ordinal);
            await using var stream = BuildStream(xml);
            var metadata = new HxInvoiceParseMetadata();

            // Act
            var invoices = await ParseAllAsync(stream, metadata);

            // Assert
            Assert.Equal("Timber !<] Fixings", Assert.Single(invoices).Lines[0].Product?.Description);
            Assert.True(metadata.SanitisationUsed);
        }

        [Fact]
        public async Task Given_Structurally_Malformed_Xml_When_Parsed_Should_Throw_A_Classified_Exception_After_Sanitisation()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice()).Replace("</Product>", "</WrongElement>", StringComparison.Ordinal);
            await using var stream = BuildStream(xml);

            // Act
            var exception = await Assert.ThrowsAsync<HxInvoiceParseException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal(HxInvoiceParseErrorCategory.MalformedXml, exception.Category);
            Assert.True(exception.SanitisationAttempted);
            Assert.IsType<System.Xml.XmlException>(exception.InnerException);
        }

        [Fact]
        public async Task Given_A_Document_Type_Definition_When_Parsed_Should_Reject_The_Document()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice())
                .Replace("<kmsg:message", "<!DOCTYPE message [<!ENTITY example 'value'>]><kmsg:message", StringComparison.Ordinal);
            await using var stream = BuildStream(xml);

            // Act
            var exception = await Assert.ThrowsAsync<HxInvoiceParseException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal(HxInvoiceParseErrorCategory.MalformedXml, exception.Category);
            Assert.True(exception.SanitisationAttempted);
        }

        [Theory]
        [InlineData("<InvoiceDate>2026-99-99</InvoiceDate>", "/Invoice/InvoiceDate", null)]
        [InlineData("<UnitPrice>invalid</UnitPrice>", "/Invoice/InvoiceLine/Price/UnitPrice", "1")]
        [InlineData("<NumberOfLines>invalid</NumberOfLines>", "/Invoice/InvoiceTotal/NumberOfLines", null)]
        public async Task Given_An_Invalid_Typed_Value_When_Parsed_Should_Report_Invoice_And_Element_Context(string invalidElement, string expectedPath, string? expectedLineNumber)
        {
            // Arrange
            var xml = invalidElement.StartsWith("<InvoiceDate>", StringComparison.Ordinal)
                ? BuildInvoice().Replace("<InvoiceDate>2026-07-12</InvoiceDate>", invalidElement, StringComparison.Ordinal)
                : invalidElement.StartsWith("<UnitPrice>", StringComparison.Ordinal)
                    ? BuildInvoice().Replace("<UnitPrice>9.99</UnitPrice>", invalidElement, StringComparison.Ordinal)
                    : BuildInvoice().Replace("<NumberOfLines>1</NumberOfLines>", invalidElement, StringComparison.Ordinal);

            await using var stream = BuildStream(BuildDocument(xml));

            // Act
            var exception = await Assert.ThrowsAsync<HxInvoiceParseException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal(HxInvoiceParseErrorCategory.InvalidValue, exception.Category);
            Assert.Equal(expectedPath, exception.ElementPath);
            Assert.Equal("CON-100", exception.InvoiceNumber);
            Assert.Equal(expectedLineNumber, exception.LineNumber);
        }

        [Theory]
        [InlineData("not-a-boolean", "/Invoice/InvoiceLine/LineNumber/@Preserve")]
        [InlineData("invalid-document-text", "/Invoice/InvoiceLine/Extensions/HXConsolidatedLine/DocumentTextLine")]
        [InlineData("invalid-special-product", "/Invoice/InvoiceLine/Extensions/HXConsolidatedLine/SpecialProduct")]
        public async Task Given_An_Invalid_Boolean_When_Parsed_Should_Report_The_Line_Context(string invalidValue, string expectedPath)
        {
            // Arrange
            var invoice = expectedPath.EndsWith("@Preserve", StringComparison.Ordinal)
                ? BuildInvoice().Replace("Preserve=\"true\"", $"Preserve=\"{invalidValue}\"", StringComparison.Ordinal)
                : expectedPath.EndsWith("DocumentTextLine", StringComparison.Ordinal)
                    ? BuildInvoice().Replace(">true</", $">{invalidValue}</", StringComparison.Ordinal)
                    : BuildInvoice().Replace(">false</", $">{invalidValue}</", StringComparison.Ordinal);
            await using var stream = BuildStream(BuildDocument(invoice));

            // Act
            var exception = await Assert.ThrowsAsync<HxInvoiceParseException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal(HxInvoiceParseErrorCategory.InvalidValue, exception.Category);
            Assert.Equal(expectedPath, exception.ElementPath);
            Assert.Equal("CON-100", exception.InvoiceNumber);
            Assert.Equal("1", exception.LineNumber);
        }

        [Theory]
        [InlineData("1", true)]
        [InlineData("0", false)]
        [InlineData(" true ", true)]
        [InlineData(" false ", false)]
        public async Task Given_A_Supported_Boolean_Representation_When_Parsed_Should_Map_The_Value(string sourceValue, bool expectedValue)
        {
            // Arrange
            var invoice = BuildInvoice().Replace("Preserve=\"true\"", $"Preserve=\"{sourceValue}\"", StringComparison.Ordinal);

            await using var stream = BuildStream(BuildDocument(invoice));

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Equal(expectedValue, Assert.Single(invoices).Lines[0].PreserveLineNumber);
        }

        [Fact]
        public async Task Given_A_Non_Seekable_Stream_When_Parsed_Should_Return_The_Invoice()
        {
            // Arrange
            await using var innerStream = BuildStream(BuildDocument(BuildInvoice()));
            await using var stream = new NonSeekableReadStream(innerStream);

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Single(invoices);
        }

        [Fact]
        public async Task Given_A_Seekable_Stream_With_An_Advanced_Position_When_Parsed_Should_Read_From_The_Start()
        {
            // Arrange
            await using var stream = BuildStream(BuildDocument(BuildInvoice()));
            stream.Position = stream.Length;

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Single(invoices);
        }

        [Fact]
        public async Task Given_An_Unreadable_Stream_When_Parsed_Should_Throw_An_Argument_Exception()
        {
            // Arrange
            await using var stream = new UnreadableStream();

            // Act
            var exception = await Assert.ThrowsAsync<ArgumentException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal("source", exception.ParamName);
        }

        [Fact]
        public async Task Given_A_Null_Stream_When_Parsed_Should_Throw_An_Argument_Null_Exception()
        {
            // Act
            var exception = await Assert.ThrowsAsync<ArgumentNullException>(() => ParseAllAsync(null!));

            // Assert
            Assert.Equal("source", exception.ParamName);
        }

        [Fact]
        public async Task Given_Iso_8859_1_Input_When_Parsed_Should_Preserve_Non_Ascii_Characters()
        {
            // Arrange
            var xml = BuildDocument(BuildInvoice().Replace("Test product", "Café product", StringComparison.Ordinal))
                .Replace("utf-8", "iso-8859-1", StringComparison.OrdinalIgnoreCase);
            await using var stream = new MemoryStream(Encoding.Latin1.GetBytes(xml));

            // Act
            var invoices = await ParseAllAsync(stream);

            // Assert
            Assert.Equal("Café product", Assert.Single(invoices).Lines[0].Product?.Description);
        }

        [Fact]
        public async Task Given_A_Document_Without_A_Kmsg_Body_When_Parsed_Should_Throw_An_Unsupported_Document_Exception()
        {
            // Arrange
            await using var stream = BuildStream("<root />");

            // Act
            var exception = await Assert.ThrowsAsync<HxInvoiceParseException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal(HxInvoiceParseErrorCategory.UnsupportedDocument, exception.Category);
            Assert.Equal("/kmsg/body", exception.ElementPath);
        }

        [Fact]
        public async Task Given_A_Kmsg_Body_Without_An_Invoice_When_Parsed_Should_Throw_An_Unsupported_Document_Exception()
        {
            // Arrange
            await using var stream = BuildStream(HxInvoiceXmlBuilder.BuildDocument());

            // Act
            var exception = await Assert.ThrowsAsync<HxInvoiceParseException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal(HxInvoiceParseErrorCategory.UnsupportedDocument, exception.Category);
            Assert.Equal("/kmsg/body/Invoice", exception.ElementPath);
        }

        [Fact]
        public async Task Given_An_Invoice_In_The_Wrong_Namespace_When_Parsed_Should_Throw_An_Unsupported_Document_Exception()
        {
            // Arrange
            var invoice = new XElement(XName.Get("Invoice", "urn:wrong-namespace"));
            await using var stream = BuildStream(HxInvoiceXmlBuilder.BuildDocument(invoice));

            // Act
            var exception = await Assert.ThrowsAsync<HxInvoiceParseException>(() => ParseAllAsync(stream));

            // Assert
            Assert.Equal(HxInvoiceParseErrorCategory.UnsupportedDocument, exception.Category);
            Assert.Equal("/kmsg/body/Invoice", exception.ElementPath);
        }

        [Fact]
        public async Task Given_A_Cancelled_Token_When_Parsed_Should_Throw_An_Operation_Cancelled_Exception()
        {
            // Arrange
            await using var stream = BuildStream(BuildDocument(BuildInvoice()));
            using var cancellation = new CancellationTokenSource();
            cancellation.Cancel();

            // Act and Assert
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => ParseAllAsync(stream, cancellation.Token));
        }

        private async Task<List<HxInvoiceDto>> ParseAllAsync(Stream source, CancellationToken cancellationToken = default)
        {
            var invoices = new List<HxInvoiceDto>();
            await foreach (var invoice in _parser.ParseAsync(source, cancellationToken))
            {
                invoices.Add(invoice);
            }

            return invoices;
        }

        private async Task<List<HxInvoiceDto>> ParseAllAsync(Stream source, HxInvoiceParseMetadata metadata, CancellationToken cancellationToken = default)
        {
            var invoices = new List<HxInvoiceDto>();
            await foreach (var invoice in _parser.ParseAsync(source, metadata, cancellationToken))
            {
                invoices.Add(invoice);
            }

            return invoices;
        }

        private static void AssertParty(
            HxPartyDto? party,
            string expectedAccountCode,
            string expectedName,
            string expectedStreet,
            string expectedCity,
            string expectedPostCode)
        {
            Assert.NotNull(party);
            Assert.Equal(expectedAccountCode, party.AccountCode);
            Assert.Equal(expectedName, party.Name);
            Assert.Equal(["Address Line 1", "Address Line 2"], party.Address?.AddressLines);
            Assert.Equal(expectedStreet, party.Address?.Street);
            Assert.Equal(expectedCity, party.Address?.City);
            Assert.Equal("State", party.Address?.State);
            Assert.Equal(expectedPostCode, party.Address?.PostCode);
        }

        private static MemoryStream BuildStream(string xml) => new(Encoding.UTF8.GetBytes(xml));

        private static string BuildDocument(params string[] invoices) => HxInvoiceXmlBuilder.BuildDocument(invoices.Select(XElement.Parse).ToArray());

        private static string BuildInvoice(string invoiceNumber = "CON-100") => new HxInvoiceXmlBuilder { InvoiceNumber = invoiceNumber }.BuildInvoice().ToString(SaveOptions.DisableFormatting);

        private sealed class NonSeekableReadStream : Stream
        {
            private readonly Stream _innerStream;

            /// <summary>
            /// Initialises a new instance of the <see cref="NonSeekableReadStream"/> class
            /// </summary>
            /// <param name="innerStream">Readable stream exposed without seek support</param>
            public NonSeekableReadStream(Stream innerStream)
            {
                _innerStream = innerStream;
            }

            public override bool CanRead => _innerStream.CanRead;
            public override bool CanSeek => false;
            public override bool CanWrite => false;
            public override long Length => throw new NotSupportedException();
            public override long Position
            {
                get => throw new NotSupportedException();
                set => throw new NotSupportedException();
            }

            public override void Flush() => throw new NotSupportedException();
            public override int Read(byte[] buffer, int offset, int count) => _innerStream.Read(buffer, offset, count);
            public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default) => _innerStream.ReadAsync(buffer, cancellationToken);
            public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
            public override void SetLength(long value) => throw new NotSupportedException();
            public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        }

        private sealed class UnreadableStream : Stream
        {
            public override bool CanRead => false;
            public override bool CanSeek => false;
            public override bool CanWrite => false;
            public override long Length => throw new NotSupportedException();
            public override long Position
            {
                get => throw new NotSupportedException();
                set => throw new NotSupportedException();
            }

            public override void Flush() => throw new NotSupportedException();
            public override int Read(byte[] buffer, int offset, int count) => throw new NotSupportedException();
            public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
            public override void SetLength(long value) => throw new NotSupportedException();
            public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        }
    }
}
