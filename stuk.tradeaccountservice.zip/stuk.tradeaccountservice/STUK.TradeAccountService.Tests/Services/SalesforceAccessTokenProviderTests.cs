using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Moq;
using STUK.TradeAccountService.Common.Salesforce;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Services;
using STUK.TradeAccountService.Tests.Helpers;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceAccessTokenProviderTests
    {
        private const string AccessToken = "access-token";
        private const string Audience = "https://test.salesforce.com";
        private const string ClientId = "external-client-id";
        private const string InstanceUrl = "https://example.my.salesforce.com";
        private const string TokenEndpoint = "https://test.salesforce.com/services/oauth2/token";
        private const string Username = "integration.user@example.com";
        private static readonly DateTimeOffset UtcNow = new(2026, 8, 7, 12, 0, 0, TimeSpan.Zero);

        [Fact]
        public async Task Given_ValidConfiguration_When_GetAccessToken_Should_SendSignedJwtAndReturnToken()
        {
            string? requestContent = null;
            var handler = new StubHttpMessageHandler(async (request, cancellationToken) =>
            {
                Assert.Equal(HttpMethod.Post, request.Method);
                Assert.Equal(TokenEndpoint, request.RequestUri?.AbsoluteUri);
                requestContent = await request.Content!.ReadAsStringAsync(cancellationToken);

                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent($$"""
                        {
                          "access_token": "{{AccessToken}}",
                          "instance_url": "{{InstanceUrl}}",
                          "token_type": "Bearer"
                        }
                        """)
                };
            });
            using var certificate = CreateCertificate();
            var certificateProvider = new Mock<ISalesforceSigningCertificateProvider>();
            certificateProvider.Setup(provider => provider.GetCertificate()).Returns(CloneCertificate(certificate));
            var provider = CreateProvider(handler, certificateProvider.Object, CreateOptions());

            var result = await provider.GetAccessTokenAsync();

            Assert.Equal(AccessToken, result.AccessToken);
            Assert.Equal(InstanceUrl, result.InstanceUrl);
            Assert.NotNull(requestContent);
            var form = ParseForm(requestContent!);
            Assert.Equal("urn:ietf:params:oauth:grant-type:jwt-bearer", form["grant_type"]);

            var jwt = new JwtSecurityTokenHandler().ReadJwtToken(form["assertion"]);
            Assert.Equal(ClientId, jwt.Issuer);
            Assert.Equal(Audience, jwt.Audiences.Single());
            Assert.Equal(Username, jwt.Subject);
            Assert.Equal(SecurityAlgorithms.RsaSha256, jwt.Header.Alg);
            Assert.Equal(UtcNow.UtcDateTime, jwt.ValidFrom);
            Assert.Equal(UtcNow.AddMinutes(3).UtcDateTime, jwt.ValidTo);
        }

        [Fact]
        public async Task Given_SalesforceRejectsTokenRequest_When_GetAccessToken_Should_ThrowSalesforceApiException()
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.BadRequest)));
            using var certificate = CreateCertificate();
            var certificateProvider = new Mock<ISalesforceSigningCertificateProvider>();
            certificateProvider.Setup(provider => provider.GetCertificate()).Returns(CloneCertificate(certificate));
            var provider = CreateProvider(handler, certificateProvider.Object, CreateOptions());

            var exception = await Assert.ThrowsAsync<SalesforceApiException>(
                () => provider.GetAccessTokenAsync());

            Assert.Equal(HttpStatusCode.BadRequest, exception.StatusCode);
        }

        [Fact]
        public async Task Given_MissingClientId_When_GetAccessToken_Should_ThrowBeforeRequest()
        {
            var requestSent = false;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestSent = true;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK));
            });
            var certificateProvider = new Mock<ISalesforceSigningCertificateProvider>();
            var options = CreateOptions();
            options.ClientId = string.Empty;
            var provider = CreateProvider(handler, certificateProvider.Object, options);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(
                () => provider.GetAccessTokenAsync());

            Assert.Equal("Salesforce ClientId is not configured.", exception.Message);
            Assert.False(requestSent);
        }

        [Fact]
        public async Task Given_InsecureTokenEndpoint_When_GetAccessToken_Should_ThrowBeforeRequest()
        {
            var requestSent = false;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestSent = true;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK));
            });
            var options = CreateOptions();
            options.TokenEndpoint = "http://test.salesforce.com/services/oauth2/token";
            var provider = CreateProvider(
                handler,
                Mock.Of<ISalesforceSigningCertificateProvider>(),
                options);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(
                () => provider.GetAccessTokenAsync());

            Assert.Contains("HTTPS", exception.Message, StringComparison.Ordinal);
            Assert.False(requestSent);
        }

        private static SalesforceAccessTokenProvider CreateProvider(
            HttpMessageHandler handler,
            ISalesforceSigningCertificateProvider certificateProvider,
            SalesforceOptions options)
        {
            return new SalesforceAccessTokenProvider(
                new HttpClient(handler),
                certificateProvider,
                Options.Create(options),
                new FixedTimeProvider(UtcNow));
        }

        private static SalesforceOptions CreateOptions()
        {
            return new SalesforceOptions
            {
                TokenEndpoint = TokenEndpoint,
                Audience = Audience,
                ClientId = ClientId,
                Username = Username
            };
        }

        private static X509Certificate2 CreateCertificate()
        {
            using var rsa = RSA.Create(2048);
            var request = new CertificateRequest(
                "CN=Salesforce Test",
                rsa,
                HashAlgorithmName.SHA256,
                RSASignaturePadding.Pkcs1);

            return request.CreateSelfSigned(UtcNow.AddDays(-1), UtcNow.AddDays(1));
        }

        private static X509Certificate2 CloneCertificate(X509Certificate2 certificate)
        {
            return new X509Certificate2(
                certificate.Export(X509ContentType.Pfx),
                (string?)null,
                X509KeyStorageFlags.EphemeralKeySet);
        }

        private static Dictionary<string, string> ParseForm(string content)
        {
            return content
                .Split('&', StringSplitOptions.RemoveEmptyEntries)
                .Select(value => value.Split('=', 2))
                .ToDictionary(
                    value => Uri.UnescapeDataString(value[0]),
                    value => Uri.UnescapeDataString(value[1].Replace('+', ' ')));
        }

        [Theory]
        [InlineData("TokenEndpoint")]
        [InlineData("Audience")]
        [InlineData("Username")]
        public async Task Given_Required_Configuration_Is_Missing_When_Getting_Access_Token_Should_Reject_Before_Using_The_Certificate(string missingProperty)
        {
            var options = CreateOptions();
            typeof(SalesforceOptions).GetProperty(missingProperty)!.SetValue(options, string.Empty);
            var certificateProvider = new Mock<ISalesforceSigningCertificateProvider>();
            var provider = CreateProvider(
                new StubHttpMessageHandler((_, _) => throw new InvalidOperationException("HTTP should not be called")),
                certificateProvider.Object,
                options);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => provider.GetAccessTokenAsync());

            Assert.Equal($"Salesforce {missingProperty} is not configured.", exception.Message);
            certificateProvider.Verify(value => value.GetCertificate(), Times.Never);
        }

        [Fact]
        public async Task Given_Token_Endpoint_Is_Not_Absolute_When_Getting_Access_Token_Should_Reject_Before_Using_The_Certificate()
        {
            var options = CreateOptions();
            options.TokenEndpoint = "/services/oauth2/token";
            var certificateProvider = new Mock<ISalesforceSigningCertificateProvider>();
            var provider = CreateProvider(
                new StubHttpMessageHandler((_, _) => throw new InvalidOperationException("HTTP should not be called")),
                certificateProvider.Object,
                options);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => provider.GetAccessTokenAsync());

            Assert.Equal("Salesforce TokenEndpoint must be an absolute HTTPS URI.", exception.Message);
            certificateProvider.Verify(value => value.GetCertificate(), Times.Never);
        }

        [Theory]
        [InlineData("null", "Salesforce returned an empty access-token response.")]
        [InlineData("{}", "Salesforce returned an incomplete access-token response.")]
        [InlineData("{\"access_token\":\"access-token\"}", "Salesforce returned an incomplete access-token response.")]
        [InlineData("{\"instance_url\":\"https://example.my.salesforce.com\"}", "Salesforce returned an incomplete access-token response.")]
        public async Task Given_Token_Response_Is_Incomplete_When_Getting_Access_Token_Should_Reject_The_Response(string responseContent, string expectedMessage)
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(responseContent)
                }));
            using var certificate = CreateCertificate();
            var certificateProvider = new Mock<ISalesforceSigningCertificateProvider>();

            certificateProvider
                .Setup(value => value.GetCertificate())
                .Returns(CloneCertificate(certificate));

            var provider = CreateProvider(handler, certificateProvider.Object, CreateOptions());

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => provider.GetAccessTokenAsync());

            Assert.Equal(expectedMessage, exception.Message);
        }

    }
}
