using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Services;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceSigningCertificateProviderTests
    {
        private const string CertificatePassword = "test-password";

        [Fact]
        public void Given_ValidCertificateConfiguration_When_GetCertificate_Should_ReturnCertificateWithPrivateKey()
        {
            var certificateBytes = CreateCertificateBytes();
            var provider = CreateProvider(Convert.ToBase64String(certificateBytes));

            using var result = provider.GetCertificate();

            Assert.True(result.HasPrivateKey);
        }

        [Fact]
        public void Given_PasswordlessKeyVaultCertificate_When_GetCertificate_Should_ReturnCertificateWithPrivateKey()
        {
            var certificateBytes = CreateCertificateBytes(password: null);
            var provider = CreateProvider(Convert.ToBase64String(certificateBytes), null);

            using var result = provider.GetCertificate();

            Assert.True(result.HasPrivateKey);
        }

        [Fact]
        public void Given_MissingCertificateConfiguration_When_GetCertificate_Should_ThrowInvalidOperationException()
        {
            var provider = CreateProvider(string.Empty);

            var exception = Assert.Throws<InvalidOperationException>(() => provider.GetCertificate());

            Assert.Equal("The Salesforce signing certificate is not configured.", exception.Message);
        }

        [Fact]
        public void Given_InvalidBase64Certificate_When_GetCertificate_Should_ThrowInvalidOperationException()
        {
            var provider = CreateProvider("not-base64");

            var exception = Assert.Throws<InvalidOperationException>(() => provider.GetCertificate());

            Assert.Equal("The Salesforce signing certificate is not valid Base64.", exception.Message);
        }

        [Fact]
        public void Given_A_PublicOnlyCertificate_When_GetCertificate_Should_Reject_It()
        {
            var certificateBytes = CreateCertificateBytes(X509ContentType.Cert);
            var provider = CreateProvider(Convert.ToBase64String(certificateBytes));

            var exception = Assert.Throws<InvalidOperationException>(() => provider.GetCertificate());

            Assert.Equal("The Salesforce signing certificate does not contain a private key.", exception.Message);
        }

        [Fact]
        public void Given_The_Certificate_Password_Is_Wrong_When_GetCertificate_Should_Report_A_Load_Failure()
        {
            var certificateBytes = CreateCertificateBytes();
            var provider = CreateProvider(Convert.ToBase64String(certificateBytes), "wrong-password");

            var exception = Assert.Throws<InvalidOperationException>(() => provider.GetCertificate());

            Assert.Equal("The Salesforce signing certificate could not be loaded.", exception.Message);
            Assert.IsType<CryptographicException>(exception.InnerException);
        }

        private static SalesforceSigningCertificateProvider CreateProvider(string certificateBase64, string? password = CertificatePassword)
        {
            var options = Options.Create(new SalesforceOptions
            {
                SigningCertificateBase64 = certificateBase64,
                SigningCertificatePassword = password
            });

            return new SalesforceSigningCertificateProvider(options);
        }

        private static byte[] CreateCertificateBytes(X509ContentType contentType = X509ContentType.Pfx, string? password = CertificatePassword)
        {
            using var rsa = RSA.Create(2048);
            var request = new CertificateRequest(
                "CN=Salesforce Test",
                rsa,
                HashAlgorithmName.SHA256,
                RSASignaturePadding.Pkcs1);
            using var certificate = request.CreateSelfSigned(
                new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero),
                new DateTimeOffset(2027, 1, 1, 0, 0, 0, TimeSpan.Zero));

            return contentType == X509ContentType.Pfx
                ? certificate.Export(contentType, password)
                : certificate.Export(contentType);
        }

        private static byte[] CreatePublicCertificateBytes()
        {
            using var rsa = RSA.Create(2048);
            var request = new CertificateRequest(
                "CN=Salesforce Public Test",
                rsa,
                HashAlgorithmName.SHA256,
                RSASignaturePadding.Pkcs1);
            using var certificate = request.CreateSelfSigned(
                new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero),
                new DateTimeOffset(2027, 1, 1, 0, 0, 0, TimeSpan.Zero));

            return certificate.Export(X509ContentType.Cert);
        }

        [Fact]
        public void Given_Certificate_Has_No_Private_Key_When_Getting_Certificate_Should_Reject_It()
        {
            var certificateBytes = CreatePublicCertificateBytes();
            var provider = CreateProvider(Convert.ToBase64String(certificateBytes));

            var exception = Assert.Throws<InvalidOperationException>(() => provider.GetCertificate());

            Assert.Equal("The Salesforce signing certificate does not contain a private key.", exception.Message);
        }

        [Fact]
        public void Given_Base64_Does_Not_Contain_A_Certificate_When_Getting_Certificate_Should_Report_A_Loading_Failure()
        {
            var provider = CreateProvider(Convert.ToBase64String([1, 2, 3, 4]));

            var exception = Assert.Throws<InvalidOperationException>(() => provider.GetCertificate());

            Assert.Equal("The Salesforce signing certificate could not be loaded.", exception.Message);
            Assert.IsType<CryptographicException>(exception.InnerException);
        }

    }
}
