﻿using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
namespace STUK.TradeAccountService.Tests.Services
{
    public class ColumbusFilesServiceTests
    {
        private readonly Mock<IBlobService> _blob = new(MockBehavior.Strict);
        private readonly Mock<IAppInsightsLoggerHelper> _logger = new(MockBehavior.Strict);
        private readonly Mock<IDbExecutor> _db = new(MockBehavior.Strict);

        private const string Storage = "stadstukais004";
        private const string Container = "columbus-staging";
        private const string SourceFile = "26a9d256-89e0-4d4b-8218-4b33121c49d2.pdf";

        private ColumbusFilesService CreateService()
        {
            var config = new ConfigurationBuilder()
     .AddInMemoryCollection(new Dictionary<string, string?>
     {
         ["ColumbusFilesStorageAccount"] = Storage,
         ["ColumbusStagingContainer"] = Container
     })
     .Build();
            return new ColumbusFilesService(
                _db.Object,
                _logger.Object,
                new Mock<IServiceScopeFactory>().Object,
                _blob.Object,
                config);
        }

        // COMMON LOGGER SETUP (fixes strict issues)
        private void SetupLogger()
        {
            _logger.Setup(x => x.LogInformation(
                It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<Dictionary<string, string>>()));

            _logger.Setup(x => x.LogWarning(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));

            _logger.Setup(x => x.LogError(
                It.IsAny<Exception>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>()));
        }

        private ArchiveDocument StatementDoc(string date = "28/02/2022") => new()
        {
            TypeName = "Statement",
            Indexes = new()
        {
            new() { ShortName="ACC", Value="M111247"},
            new() { ShortName="BNC", Value="307"},
            new() { ShortName="DAT", Value=date }
        }
        };

        private ArchiveDocument InvoiceDoc(string date = "12/11/2025") => new()
        {
            TypeName = "Invoice",
            Indexes = new()
        {
            new() { ShortName="ACC", Value="M137789"},
            new() { ShortName="BNC", Value="307"},
            new() { ShortName="DAT", Value=date },
            new() { ShortName="DNO", Value="10617389"}
        }
        };

        private ColumbusMetaDataFile Archive(ArchiveDocument doc) => new()
        {
            Input = new ArchiveInput
            {
                MultiDocumentFile = new MultiDocumentFile
                {
                    File = SourceFile,
                    Documents = new List<ArchiveDocument> { doc }
                }
            }
        };
        private void SetupMetadata(DocumentType type)
        {
            _blob.Setup(x => x.GetDocumentMetadataAsync(
                    Storage,
                    It.IsAny<string>(),   // ✅ FIX: don't hardcode container path
                    type))
                .ReturnsAsync(new DocumentMetadataUpdate { Extension = ".pdf" });
        }
        [Fact]
        public async Task Statement_FullFlow()
        {
            SetupLogger();
            var service = CreateService();

            object? captured = null;

            // ✅ FIX: container is dynamic ("statement"), not config value
            _blob.Setup(x => x.ReadArchiveXmlAsync(
                    Storage,
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(Archive(StatementDoc()));

            SetupMetadata(DocumentType.Statement);

            _db.Setup(x => x.ExecuteWithOutputAsync(
                    "CheckColumbusStatementHeaderExists",
                    "@RecordCount",
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            _blob.Setup(x => x.CopyBlobAsync(
                    Storage,
                    It.IsAny<string>(),
                    SourceFile,
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(true);

            _blob.Setup(x => x.DeleteBlobAsync(
                    Storage,
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(true);

            _db.Setup(x => x.ExecuteWithOutputAsync(
                    "UpdateColumbusDocumentMetadata",
                    "@RowsUpdated",
                    It.IsAny<object>()))
                .Callback<string, string, object>((_, _, p) => captured = p)
                .ReturnsAsync(1);

            await service.UploadColumbusFileAsync(
                "f80a61e8-d3b1-4014-91d5-f133fa38905d.xml",
                "statement");

            var json = JsonSerializer.Serialize(captured);

            json.Should().Contain("M111247");
            json.Should().Contain("307");
            json.Should().Contain("Statement");
            json.Should().Contain("M111247_307_28022022.pdf");
        }
        [Fact]
        public async Task Invoice_FullFlow()
        {
            SetupLogger();
            var service = CreateService();

            object? captured = null;

            // ✅ FIX: allow any container ("invoice" is passed at runtime)
            _blob.Setup(x => x.ReadArchiveXmlAsync(
                    Storage,
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(Archive(InvoiceDoc()));

            SetupMetadata(DocumentType.Invoice);

            _blob.Setup(x => x.CopyBlobAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(true);

            _blob.Setup(x => x.DeleteBlobAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(true);

            _db.Setup(x => x.ExecuteWithOutputAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<object>()))
                .Callback((string _, string __, object p) => captured = p)
                .ReturnsAsync(1);

            await service.UploadColumbusFileAsync(
                "26a9d256-89e0-4d4b-8218-4b33121c49d2.xml",
                "invoice");

            var json = JsonSerializer.Serialize(captured);

            json.Should().Contain("10617389");
            json.Should().Contain("M137789");
        }

        [Fact]
        public async Task Should_Stop_When_Copy_Fails()
        {
            SetupLogger();
            var service = CreateService();

            _blob.Setup(x => x.ReadArchiveXmlAsync(
                    Storage,
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(Archive(StatementDoc()));

            SetupMetadata(DocumentType.Statement);

            _db.Setup(x => x.ExecuteWithOutputAsync(
                    "CheckColumbusStatementHeaderExists",
                    "@RecordCount",
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            // ✅ Copy fails
            _blob.Setup(x => x.CopyBlobAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(false);

            await service.UploadColumbusFileAsync("meta.xml", "invoice");

            _db.Verify(x => x.ExecuteWithOutputAsync(
                "UpdateColumbusDocumentMetadata",
                It.IsAny<string>(),
                It.IsAny<object>()),
                Times.Never);
        }
        [Fact]
        public async Task Should_Stop_When_DbReturnsZero()
        {
            SetupLogger();
            var service = CreateService();

            _blob.Setup(x => x.ReadArchiveXmlAsync(
                    Storage,
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(Archive(StatementDoc()));

            SetupMetadata(DocumentType.Statement);

            _blob.Setup(x => x.CopyBlobAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(true);

            // ✅ DB returns 0
            _db.Setup(x => x.ExecuteWithOutputAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<object>()))
                .ReturnsAsync(0);

            await service.UploadColumbusFileAsync("meta.xml", "invoice");

            // ✅ Delete should NOT be called
            _blob.Verify(x => x.DeleteBlobAsync(
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<string>()),
                Times.Never);
        }
        [Fact]
        public async Task Should_Throw_When_Date_Invalid()
        {
            SetupLogger();
            var service = CreateService();

            _blob.Setup(x => x.ReadArchiveXmlAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(Archive(StatementDoc("BAD")));

            await Assert.ThrowsAsync<Exception>(() => service.UploadColumbusFileAsync("meta.xml","invoice"));
        }

        [Fact]
        public async Task Should_Return_When_Metadata_Null()
        {
            SetupLogger();
            var service = CreateService();

            _blob.Setup(x => x.ReadArchiveXmlAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync((ColumbusMetaDataFile?)null);

            await service.UploadColumbusFileAsync("meta.xml","invoice");
        }

        [Fact]
        public async Task Should_Return_When_No_Documents()
        {
            SetupLogger();
            var service = CreateService();

            var archive = new ColumbusMetaDataFile
            {
                Input = new ArchiveInput
                {
                    MultiDocumentFile = new MultiDocumentFile
                    {
                        File = "file",
                        Documents = new List<ArchiveDocument>()
                    }
                }
            };

            _blob.Setup(x => x.ReadArchiveXmlAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(archive);

            await service.UploadColumbusFileAsync("meta.xml","invoice");

            _blob.Verify(x => x.CopyBlobAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        // 8 empty filename
        [Fact]
        public async Task Should_Return_When_FileName_Empty()
        {
            SetupLogger();
            var service = CreateService();

            await service.UploadColumbusFileAsync("","invoice");
        }
    }
}