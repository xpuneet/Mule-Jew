using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using STUK.TradeAccountService.Common.Salesforce.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceProductServiceTests
    {
        private const string PricebookId = "01s000000000001";
        private const string PricebookEntryId = "01u000000000001";
        private const string ProductCode = "PRODUCT-001";
        private const string ProductId = "01t000000000001";

        [Fact]
        public async Task Given_ProductAndPricebookEntryExist_When_EnsureProducts_Should_NotUpsert()
        {
            var apiClient = CreateApiClient(
                [new SalesforceProduct { Id = ProductId, ExternalId = ProductCode }],
                [new SalesforcePricebookEntry { Id = PricebookEntryId, ExternalId = ProductCode }]);
            var service = CreateService(apiClient.Object);

            var result = await service.EnsureProductsAsync([ProductCode]);

            Assert.Equal(ProductId, result[ProductCode].ProductId);
            Assert.Equal(PricebookEntryId, result[ProductCode].PricebookEntryId);

            apiClient.Verify(
                client => client.UpsertAsync(
                    "Product2",
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<SalesforceProductRequest>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
            apiClient.Verify(
                client => client.UpsertAsync(
                    "PricebookEntry",
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<SalesforcePricebookEntryRequest>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
        }

        [Fact]
        public async Task Given_ProductDoesNotExist_When_EnsureProducts_Should_CreateProduct()
        {
            var apiClient = CreateApiClient([], []);
            SalesforceProductRequest? capturedRequest = null;
            apiClient
                .Setup(client => client.UpsertAsync(
                    "Product2",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforceProductRequest>(),
                    It.IsAny<CancellationToken>()))
                .Callback<string, string, string, SalesforceProductRequest, CancellationToken>(
                    (_, _, _, request, _) => capturedRequest = request)
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = true, Id = ProductId });
            SetupPricebookEntryUpsert(apiClient);
            var service = CreateService(apiClient.Object);

            var result = await service.EnsureProductsAsync([ProductCode]);

            Assert.NotNull(capturedRequest);
            Assert.Equal(ProductCode, capturedRequest.Name);
            Assert.Equal(ProductCode, capturedRequest.ProductCode);
            Assert.Equal(ProductCode, capturedRequest.ExternalId);
            Assert.True(capturedRequest.IsActive);
            Assert.Equal(ProductId, result[ProductCode].ProductId);
            Assert.Equal(PricebookEntryId, result[ProductCode].PricebookEntryId);
        }

        [Fact]
        public async Task Given_ExistingProductWithoutPricebookEntry_When_EnsureProducts_Should_CreatePricebookEntryOnly()
        {
            var apiClient = CreateApiClient(
                [new SalesforceProduct { Id = ProductId, ExternalId = ProductCode }],
                []);
            SalesforcePricebookEntryRequest? capturedRequest = null;
            apiClient
                .Setup(client => client.UpsertAsync(
                    "PricebookEntry",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforcePricebookEntryRequest>(),
                    It.IsAny<CancellationToken>()))
                .Callback<string, string, string, SalesforcePricebookEntryRequest, CancellationToken>(
                    (_, _, _, request, _) => capturedRequest = request)
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = true, Id = PricebookEntryId });
            var service = CreateService(apiClient.Object);

            var result = await service.EnsureProductsAsync([ProductCode]);

            apiClient.Verify(
                client => client.UpsertAsync(
                    "Product2",
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<SalesforceProductRequest>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
            Assert.NotNull(capturedRequest);
            Assert.Equal(PricebookId, capturedRequest.PricebookId);
            Assert.Equal(0m, capturedRequest.UnitPrice);
            Assert.True(capturedRequest.IsActive);
            Assert.Equal(ProductCode, capturedRequest.ExternalId);
            Assert.Equal(ProductCode, capturedRequest.Product.ExternalId);
            Assert.Equal(ProductId, result[ProductCode].ProductId);
            Assert.Equal(PricebookEntryId, result[ProductCode].PricebookEntryId);
        }

        [Fact]
        public async Task Given_DuplicateProductCodes_When_EnsureProducts_Should_QueryAndCreateEachProductOnce()
        {
            var apiClient = CreateApiClient([], []);
            SetupProductUpsert(apiClient);
            SetupPricebookEntryUpsert(apiClient);
            var service = CreateService(apiClient.Object);

            await service.EnsureProductsAsync([ProductCode, ProductCode]);

            apiClient.Verify(
                client => client.UpsertAsync(
                    "Product2",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforceProductRequest>(),
                    It.IsAny<CancellationToken>()),
                Times.Once);
            apiClient.Verify(
                client => client.UpsertAsync(
                    "PricebookEntry",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforcePricebookEntryRequest>(),
                    It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_ProductCreatedByAnotherWorker_When_UpsertUpdatesProduct_Should_QueryForIdentifier()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceProduct>(
                    It.Is<string>(query => query.Contains("FROM Product2", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([]);
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceRecord>(
                    It.Is<string>(query => query.Contains("FROM Product2", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([new SalesforceRecord { Id = ProductId }]);
            apiClient
                .Setup(client => client.UpsertAsync(
                    "Product2",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforceProductRequest>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = false });
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforcePricebookEntry>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([new SalesforcePricebookEntry { Id = PricebookEntryId, ExternalId = ProductCode }]);
            var service = CreateService(apiClient.Object);

            var result = await service.EnsureProductsAsync([ProductCode]);

            Assert.Equal(ProductId, result[ProductCode].ProductId);
            Assert.Equal(PricebookEntryId, result[ProductCode].PricebookEntryId);
            apiClient.Verify(
                client => client.QueryAllAsync<SalesforceRecord>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_PricebookEntryCreatedByAnotherWorker_When_UpsertUpdatesEntry_Should_QueryForIdentifier()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceProduct>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([new SalesforceProduct { Id = ProductId, ExternalId = ProductCode }]);
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforcePricebookEntry>(
                    It.Is<string>(query => query.Contains("FROM PricebookEntry", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([]);
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceRecord>(
                    It.Is<string>(query => query.Contains("FROM PricebookEntry", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync([new SalesforceRecord { Id = PricebookEntryId }]);
            apiClient
                .Setup(client => client.UpsertAsync(
                    "PricebookEntry",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforcePricebookEntryRequest>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = false });
            var service = CreateService(apiClient.Object);

            var result = await service.EnsureProductsAsync([ProductCode]);

            Assert.Equal(ProductId, result[ProductCode].ProductId);
            Assert.Equal(PricebookEntryId, result[ProductCode].PricebookEntryId);
            apiClient.Verify(
                client => client.QueryAllAsync<SalesforceRecord>(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_MissingPrerequisites_When_EnsureProducts_Should_QueryBeforeEachUpsert()
        {
            var apiClient = CreateApiClient([], []);
            SetupProductUpsert(apiClient);
            SetupPricebookEntryUpsert(apiClient);
            var service = CreateService(apiClient.Object);

            await service.EnsureProductsAsync([ProductCode]);

            Assert.Collection(
                apiClient.Invocations,
                invocation => Assert.Equal(nameof(ISalesforceApiClient.QueryAllAsync), invocation.Method.Name),
                invocation => Assert.Equal(nameof(ISalesforceApiClient.UpsertAsync), invocation.Method.Name),
                invocation => Assert.Equal(nameof(ISalesforceApiClient.QueryAllAsync), invocation.Method.Name),
                invocation => Assert.Equal(nameof(ISalesforceApiClient.UpsertAsync), invocation.Method.Name));
        }

        [Fact]
        public async Task Given_EmptyProductCode_When_EnsureProducts_Should_RejectRequestBeforeCallingSalesforce()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            var service = CreateService(apiClient.Object);

            await Assert.ThrowsAsync<ArgumentException>(
                () => service.EnsureProductsAsync([string.Empty]));

            apiClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_PricebookIsNotConfigured_When_EnsureProducts_Should_RejectRequestBeforeCallingSalesforce()
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            var service = new SalesforceProductService(
                apiClient.Object,
                Options.Create(new SalesforceOptions()));

            await Assert.ThrowsAsync<InvalidOperationException>(
                () => service.EnsureProductsAsync([ProductCode]));

            apiClient.VerifyNoOtherCalls();
        }

        private static SalesforceProductService CreateService(ISalesforceApiClient apiClient)
        {
            return new SalesforceProductService(
                apiClient,
                Options.Create(new SalesforceOptions { PricebookId = PricebookId }));
        }

        private static Mock<ISalesforceApiClient> CreateApiClient(
            IReadOnlyList<SalesforceProduct> products,
            IReadOnlyList<SalesforcePricebookEntry> pricebookEntries)
        {
            var apiClient = new Mock<ISalesforceApiClient>();
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforceProduct>(
                    It.Is<string>(query => query.Contains("FROM Product2", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(products);
            apiClient
                .Setup(client => client.QueryAllAsync<SalesforcePricebookEntry>(
                    It.Is<string>(query =>
                        query.Contains("FROM PricebookEntry", StringComparison.Ordinal)
                        && query.Contains($"Pricebook2Id = '{PricebookId}'", StringComparison.Ordinal)),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(pricebookEntries);

            return apiClient;
        }

        private static void SetupProductUpsert(Mock<ISalesforceApiClient> apiClient)
        {
            apiClient
                .Setup(client => client.UpsertAsync(
                    "Product2",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforceProductRequest>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = true, Id = ProductId });
        }

        private static void SetupPricebookEntryUpsert(Mock<ISalesforceApiClient> apiClient)
        {
            apiClient
                .Setup(client => client.UpsertAsync(
                    "PricebookEntry",
                    "External_ID__c",
                    ProductCode,
                    It.IsAny<SalesforcePricebookEntryRequest>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceUpsertResult { Success = true, Created = true, Id = PricebookEntryId });
        }
    }
}
