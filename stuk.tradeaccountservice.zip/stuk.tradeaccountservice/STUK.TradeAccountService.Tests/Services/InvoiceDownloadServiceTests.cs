﻿using Azure.Storage.Blobs;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class InvoiceDownloadServiceTests
    {
        private readonly Mock<IDocumentMetadataResolver<string, string>> _resolverMock;
        private readonly Mock<BlobServiceClient> _blobServiceClientMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly InvoiceDownloadService _service;

        public InvoiceDownloadServiceTests()
        {
            _resolverMock = new Mock<IDocumentMetadataResolver<string, string>>();
            _blobServiceClientMock = new Mock<BlobServiceClient>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();

            _resolverMock.Setup(r => r.DocumentType).Returns("Invoice");
            _resolverMock.Setup(r => r.ContainerName).Returns("invoicetest");
            _resolverMock.Setup(r => r.DefaultFileName).Returns("Invoice.pdf");
            _resolverMock.Setup(r => r.ParseIdentifier(It.IsAny<string>())).Returns((string s) => s);

            _service = new InvoiceDownloadService(
                _resolverMock.Object,
                new HttpClient(),
                _blobServiceClientMock.Object,
                _loggerMock.Object);
        }

        #region RequestDownload

        [Fact]
        public async Task RequestDownload_ExistingCache_ReturnsExistingToken()
        {
            // Arrange
            var existingToken = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = existingToken,
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Pending"
                });

            // Act
            var result = await _service.RequestDownloadAsync("INV-001", "123");

            // Assert
            Assert.Equal(existingToken, result.Token);
            Assert.Contains("already active", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_MetadataNotFound_ThrowsKeyNotFoundException()
        {
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentMetadata?)null);

            // Act & Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() =>
                _service.RequestDownloadAsync("INV-001", "123"));
        }

        [Fact]
        public async Task RequestDownload_BlobUriEmpty_ReturnsPendingStatus()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Pending", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            var result = await _service.RequestDownloadAsync("INV-001", "123");

            // Assert
            Assert.Equal(token, result.Token);
            Assert.Contains("being prepared", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_BlobUriExists_ReturnsReadyStatus()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/03/file.pdf", FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            var result = await _service.RequestDownloadAsync("INV-001", "123");

            // Assert
            Assert.Equal(token, result.Token);
            Assert.Contains("ready for download", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_TokenGenerationFails_ThrowsInvalidOperationException()
        {
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/03/file.pdf", FileName = "file.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync("INV-001", "123", "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((Guid.Empty, DateTimeOffset.Now));

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                _service.RequestDownloadAsync("INV-001", "123"));
        }

        #endregion

        #region Download

        [Fact]
        public async Task Download_InvalidToken_ThrowsKeyNotFoundException()
        {
            var invalidToken = Guid.Empty;
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(invalidToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act & Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() =>
                _service.DownloadAsync(invalidToken));
        }

        [Fact]
        public async Task Download_MetadataNotFound_ReturnsNotReadyMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Ready"
                });

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentMetadata?)null);

            // Act
            var result = await _service.DownloadAsync(token);

            // Assert
            Assert.Null(result.FileContent);
            Assert.Contains("not ready", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task Download_BlobUriEmpty_ReturnsNotReadyMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "INV-001",
                    DocumentType = "Invoice",
                    DownloadStatus = "Pending"
                });

            _resolverMock
                .Setup(r => r.GetMetadataAsync("INV-001", "123", It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "file.pdf" });

            // Act
            var result = await _service.DownloadAsync(token);

            // Assert
            Assert.Null(result.FileContent);
            Assert.Contains("not ready", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        #endregion

        #region ServiceType

        [Fact]
        public void Service_ImplementsIInvoiceDownloadService()
        {
            Assert.IsAssignableFrom<IInvoiceDownloadService>(_service);
        }

        #endregion
    }
}
