using STUK.TradeAccountService.Common.Data.Services;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the recovered Data Lake completion-token contract
    /// </summary>
    public class DataLakeCompletionTokenGeneratorTests
    {
        [Fact]
        public void Given_CompletedDataset_When_Generating_Should_UseLegacyFiveFieldContract()
        {
            var generator = new DataLakeCompletionTokenGenerator();

            var result = generator.Generate(
                new DateTimeOffset(2026, 8, 10, 1, 37, 40, TimeSpan.FromHours(1)),
                "DL_F5_ECS_CONSXREF_DATA");

            Assert.Equal(
                "2026-08-10 12:37:40|reception_completed|1|2026-08-10|DL_F5_ECS_CONSXREF_DATA\n",
                Encoding.UTF8.GetString(result));
            Assert.False(result.AsSpan().StartsWith(Encoding.UTF8.Preamble));
        }

        [Fact]
        public void Given_YearBoundary_When_Generating_Should_PreserveLegacyWeekYearProcessedDate()
        {
            var generator = new DataLakeCompletionTokenGenerator();

            var result = generator.Generate(
                new DateTimeOffset(2021, 1, 1, 9, 5, 7, TimeSpan.Zero),
                "DL_F5_ECS_CONSXREF_DATA");

            Assert.Equal(
                "2021-01-01 09:05:07|reception_completed|1|2020-01-01|DL_F5_ECS_CONSXREF_DATA\n",
                Encoding.UTF8.GetString(result));
        }
    }
}
