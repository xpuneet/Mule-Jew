using Microsoft.Extensions.Options;
using Moq;
using STUK.TradeAccountService.Common.Salesforce;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Exceptions;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Models;
using STUK.TradeAccountService.Tests.Helpers;
using System.Net;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceApiClientTests
    {
        private const string AccessToken = "access-token";
        private const string InstanceUrl = "https://example.my.salesforce.com";

        [Fact]
        public async Task Given_PagedSoqlResults_When_QueryPages_Should_StreamEachPageInOrder()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                var content = requestCount == 1
                    ? """
                      {"totalSize":2,"done":false,"nextRecordsUrl":"/services/data/v65.0/query/next-page","records":[{"Id":"001"}]}
                      """
                    : """
                      {"totalSize":2,"done":true,"records":[{"Id":"002"}]}
                      """;

                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(content)
                });
            });
            var client = CreateClient(handler, CreateTokenProvider().Object);
            var pages = new List<SalesforceQueryResult<TestSalesforceRecord>>();

            await foreach (var page in client.QueryPagesAsync<TestSalesforceRecord>("SELECT Id FROM Product2"))
            {
                pages.Add(page);
            }

            Assert.Equal(2, pages.Count);
            Assert.False(pages[0].Done);
            Assert.Equal("001", Assert.Single(pages[0].Records).Id);
            Assert.True(pages[1].Done);
            Assert.Equal("002", Assert.Single(pages[1].Records).Id);
            Assert.Equal(2, requestCount);
        }

        [Fact]
        public async Task Given_The_Legacy_ConsXref_Query_Shape_When_Querying_Should_Deserialize_The_Nine_Values()
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("""
                        {
                          "totalSize": 1,
                          "done": true,
                          "records": [
                            {
                              "Order": {
                                "Account": { "Account_Number__c": "ACC001" },
                                "Invoice_Number__c": "INV001",
                                "Invoice_Date__c": "2026-08-01"
                              },
                              "Delivery_Note_Number__c": "DEL001",
                              "Delivery_Note_Line_Number__c": 12,
                              "Despatch_Date__c": "2026-07-31",
                              "Product2": { "ProductCode": "PRODUCT001" },
                              "Quantity": 2.5,
                              "Order_Product_Total__c": 19.98
                            }
                          ]
                        }
                        """)
                }));
            var client = CreateClient(handler, CreateTokenProvider().Object);
            SalesforceConsXrefOrderItem? record = null;

            await foreach (var page in client.QueryPagesAsync<SalesforceConsXrefOrderItem>(
                "SELECT legacy fields FROM OrderItem"))
            {
                record = Assert.Single(page.Records);
            }

            Assert.NotNull(record);
            Assert.Equal("ACC001", record.Order?.Account?.AccountNumber);
            Assert.Equal("INV001", record.Order?.InvoiceNumber);
            Assert.Equal(new DateOnly(2026, 8, 1), record.Order?.InvoiceDate);
            Assert.Equal("DEL001", record.DeliveryNoteNumber);
            Assert.Equal(12, record.DeliveryNoteLineNumber);
            Assert.Equal(new DateOnly(2026, 7, 31), record.DespatchDate);
            Assert.Equal("PRODUCT001", record.Product?.ProductCode);
            Assert.Equal(2.5m, record.Quantity);
            Assert.Equal(19.98m, record.TotalPrice);
        }

        [Fact]
        public async Task Given_PagedSoqlResults_When_QueryAll_Should_ReturnAllRecords()
        {
            var requestedPaths = new List<string>();
            var handler = new StubHttpMessageHandler((request, _) =>
            {
                Assert.Equal($"Bearer {AccessToken}", request.Headers.Authorization?.ToString());
                requestedPaths.Add(request.RequestUri!.PathAndQuery);

                var content = requestedPaths.Count == 1
                    ? """
                      {"totalSize":2,"done":false,"nextRecordsUrl":"/services/data/v65.0/query/next-page","records":[{"Id":"001"}]}
                      """
                    : """
                      {"totalSize":2,"done":true,"records":[{"Id":"002"}]}
                      """;

                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(content)
                });
            });
            var tokenProvider = CreateTokenProvider();
            var client = CreateClient(handler, tokenProvider.Object);

            var result = await client.QueryAllAsync<TestSalesforceRecord>(
                "SELECT Id FROM Product2");

            Assert.Equal(new[] { "001", "002" }, result.Select(record => record.Id));
            Assert.Equal(2, requestedPaths.Count);
            Assert.StartsWith("/services/data/v65.0/query?q=", requestedPaths[0]);
            Assert.Equal("/services/data/v65.0/query/next-page", requestedPaths[1]);
            tokenProvider.Verify(
                provider => provider.GetAccessTokenAsync(It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_AbsoluteContinuationUrl_When_Querying_Should_RejectItBeforeSendingAccessToken()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("""
                        {
                          "totalSize": 2,
                          "done": false,
                          "nextRecordsUrl": "https://untrusted.example/services/data/v65.0/query/next-page",
                          "records": [{"Id":"001"}]
                        }
                        """)
                });
            });
            var client = CreateClient(handler, CreateTokenProvider().Object);

            var exception = await Assert.ThrowsAsync<SalesforceQueryResponseException>(
                () => client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Equal("Salesforce returned an invalid query continuation URL.", exception.Message);
            Assert.Equal(1, requestCount);
        }

        [Fact]
        public async Task Given_ContinuationOutsideQueryApi_When_Querying_Should_RejectIt()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("""
                        {
                          "totalSize": 2,
                          "done": false,
                          "nextRecordsUrl": "/services/data/v65.0/sobjects/Account",
                          "records": [{"Id":"001"}]
                        }
                        """)
                });
            });
            var client = CreateClient(handler, CreateTokenProvider().Object);

            await Assert.ThrowsAsync<SalesforceQueryResponseException>(
                () => client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Equal(1, requestCount);
        }

        [Fact]
        public async Task Given_NewExternalId_When_Upsert_Should_ReturnCreatedRecord()
        {
            HttpRequestMessage? capturedRequest = null;
            string? capturedContent = null;
            var handler = new StubHttpMessageHandler(async (request, cancellationToken) =>
            {
                capturedRequest = request;
                capturedContent = await request.Content!.ReadAsStringAsync(cancellationToken);

                return new HttpResponseMessage(HttpStatusCode.Created)
                {
                    Content = new StringContent("""
                        {"id":"801000000000001","success":true,"created":true}
                        """)
                };
            });
            var client = CreateClient(handler, CreateTokenProvider().Object);

            var result = await client.UpsertAsync(
                "Order",
                "Invoice_Number__c",
                "3051/00721885",
                new { Status = "Draft" });

            Assert.Equal(HttpMethod.Patch, capturedRequest?.Method);
            Assert.Equal(
                "/services/data/v65.0/sobjects/Order/Invoice_Number__c/3051%2F00721885",
                capturedRequest?.RequestUri?.AbsolutePath);
            Assert.Contains("\"status\":\"Draft\"", capturedContent);
            Assert.True(result.Success);
            Assert.True(result.Created);
            Assert.Equal("801000000000001", result.Id);
        }

        [Fact]
        public async Task Given_ExistingExternalId_When_Upsert_Should_ReturnUpdatedRecord()
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.NoContent)));
            var client = CreateClient(handler, CreateTokenProvider().Object);

            var result = await client.UpsertAsync(
                "Order",
                "Invoice_Number__c",
                "3051/00721885",
                new { Status = "Draft" });

            Assert.True(result.Success);
            Assert.False(result.Created);
            Assert.Null(result.Id);
        }

        [Fact]
        public async Task Given_ExpiredAccessToken_When_Upsert_Should_ReauthenticateAndRetryOnce()
        {
            const string replacementAccessToken = "replacement-access-token";
            var authorisationHeaders = new List<string?>();
            var requestCount = 0;
            var handler = new StubHttpMessageHandler(async (request, cancellationToken) =>
            {
                requestCount++;
                authorisationHeaders.Add(request.Headers.Authorization?.ToString());
                Assert.Contains("\"status\":\"Draft\"", await request.Content!.ReadAsStringAsync(cancellationToken));

                return requestCount == 1
                    ? new HttpResponseMessage(HttpStatusCode.Unauthorized)
                    : new HttpResponseMessage(HttpStatusCode.NoContent);
            });
            var tokenProvider = new Mock<ISalesforceAccessTokenProvider>();
            tokenProvider
                .SetupSequence(provider => provider.GetAccessTokenAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceAccessToken
                {
                    AccessToken = AccessToken,
                    InstanceUrl = InstanceUrl,
                    TokenType = "Bearer"
                })
                .ReturnsAsync(new SalesforceAccessToken
                {
                    AccessToken = replacementAccessToken,
                    InstanceUrl = InstanceUrl,
                    TokenType = "Bearer"
                });
            var client = CreateClient(handler, tokenProvider.Object);

            var result = await client.UpsertAsync(
                "Order",
                "Invoice_Number__c",
                "3051/00721885",
                new { Status = "Draft" });

            Assert.True(result.Success);
            Assert.Equal(
                new[] { $"Bearer {AccessToken}", $"Bearer {replacementAccessToken}" },
                authorisationHeaders);
            tokenProvider.Verify(
                provider => provider.GetAccessTokenAsync(It.IsAny<CancellationToken>()),
                Times.Exactly(2));
        }

        [Fact]
        public async Task Given_SecondUnauthorisedResponse_When_QueryAll_Should_NotRetryIndefinitely()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.Unauthorized));
            });
            var tokenProvider = CreateTokenProvider();
            var client = CreateClient(handler, tokenProvider.Object);

            var exception = await Assert.ThrowsAsync<SalesforceApiException>(
                () => client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Equal(HttpStatusCode.Unauthorized, exception.StatusCode);
            Assert.Equal(2, requestCount);
            tokenProvider.Verify(
                provider => provider.GetAccessTokenAsync(It.IsAny<CancellationToken>()),
                Times.Exactly(2));
        }

        [Fact]
        public async Task Given_SalesforceError_When_QueryAll_Should_ExposeStructuredError()
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    Content = new StringContent("""
                        [{"message":"Invalid field","errorCode":"INVALID_FIELD","fields":["Missing__c"]}]
                        """)
                }));
            var client = CreateClient(handler, CreateTokenProvider().Object);

            var exception = await Assert.ThrowsAsync<SalesforceApiException>(
                () => client.QueryAllAsync<TestSalesforceRecord>("SELECT Missing__c FROM Order"));

            Assert.Equal(HttpStatusCode.BadRequest, exception.StatusCode);
            var error = Assert.Single(exception.Errors);
            Assert.Equal("INVALID_FIELD", error.ErrorCode);
            Assert.Equal("Invalid field", error.Message);
            Assert.Equal(new[] { "Missing__c" }, error.Fields);
        }

        [Fact]
        public async Task Given_RateLimit_When_Querying_Should_HonourRetryAfterAndSucceed()
        {
            var requestCount = 0;
            var retryDelay = CreateRetryDelay();
            var retryAfter = new System.Net.Http.Headers.RetryConditionHeaderValue(TimeSpan.FromSeconds(7));
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                if (requestCount == 1)
                {
                    var response = new HttpResponseMessage(HttpStatusCode.TooManyRequests);
                    response.Headers.RetryAfter = retryAfter;
                    return Task.FromResult(response);
                }

                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("""{"totalSize":0,"done":true,"records":[]}""")
                });
            });
            var client = CreateClient(handler, CreateTokenProvider().Object, retryDelay);

            var result = await client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2");

            Assert.Empty(result);
            Assert.Equal(2, requestCount);
            retryDelay.Verify(value => value.Calculate(1, retryAfter), Times.Once);
            retryDelay.Verify(value => value.WaitAsync(TimeSpan.FromSeconds(7), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_TransientServerFailure_When_QueryRetriesAreExhausted_Should_ThrowFinalFailure()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.ServiceUnavailable));
            });
            var retryDelay = CreateRetryDelay();
            var client = CreateClient(handler, CreateTokenProvider().Object, retryDelay);

            var exception = await Assert.ThrowsAsync<SalesforceApiException>(
                () => client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Equal(HttpStatusCode.ServiceUnavailable, exception.StatusCode);
            Assert.Equal(4, requestCount);
            retryDelay.Verify(value => value.WaitAsync(It.IsAny<TimeSpan>(), It.IsAny<CancellationToken>()), Times.Exactly(3));
        }

        [Fact]
        public async Task Given_NetworkFailure_When_Querying_Should_RetryAndSucceed()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                if (requestCount == 1)
                {
                    throw new HttpRequestException("Connection reset");
                }

                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("""{"totalSize":0,"done":true,"records":[]}""")
                });
            });
            var client = CreateClient(handler, CreateTokenProvider().Object, CreateRetryDelay());

            var result = await client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2");

            Assert.Empty(result);
            Assert.Equal(2, requestCount);
        }

        [Fact]
        public async Task Given_RequestTimeout_When_Querying_Should_RetryAndSucceed()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                if (requestCount == 1)
                {
                    throw new TaskCanceledException("Salesforce request timed out");
                }

                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("""{"totalSize":0,"done":true,"records":[]}""")
                });
            });
            var client = CreateClient(handler, CreateTokenProvider().Object, CreateRetryDelay());

            var result = await client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2");

            Assert.Empty(result);
            Assert.Equal(2, requestCount);
        }

        [Fact]
        public async Task Given_HttpRequestTimeoutResponse_When_Querying_Should_RetryAndSucceed()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                return Task.FromResult(requestCount == 1
                    ? new HttpResponseMessage(HttpStatusCode.RequestTimeout)
                    : new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent("""{"totalSize":0,"done":true,"records":[]}""")
                    });
            });
            var client = CreateClient(handler, CreateTokenProvider().Object, CreateRetryDelay());

            var result = await client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2");

            Assert.Empty(result);
            Assert.Equal(2, requestCount);
        }

        [Fact]
        public async Task Given_CallerCancellation_When_Querying_Should_NotRetry()
        {
            var requestCount = 0;
            using var cancellationTokenSource = new CancellationTokenSource();
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                cancellationTokenSource.Cancel();
                throw new OperationCanceledException(cancellationTokenSource.Token);
            });
            var retryDelay = CreateRetryDelay();
            var client = CreateClient(handler, CreateTokenProvider().Object, retryDelay);

            await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
                client.QueryAllAsync<TestSalesforceRecord>(
                    "SELECT Id FROM Product2",
                    cancellationTokenSource.Token));

            Assert.Equal(1, requestCount);
            retryDelay.Verify(value => value.WaitAsync(It.IsAny<TimeSpan>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_ValidationFailure_When_Querying_Should_NotRetry()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.BadRequest));
            });
            var retryDelay = CreateRetryDelay();
            var client = CreateClient(handler, CreateTokenProvider().Object, retryDelay);

            await Assert.ThrowsAsync<SalesforceApiException>(
                () => client.QueryAllAsync<TestSalesforceRecord>("SELECT Missing__c FROM Order"));

            Assert.Equal(1, requestCount);
            retryDelay.Verify(value => value.WaitAsync(It.IsAny<TimeSpan>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_TransientServerFailure_When_Upserting_Should_NotApplyQueryRetryPolicy()
        {
            var requestCount = 0;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestCount++;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.ServiceUnavailable));
            });
            var retryDelay = CreateRetryDelay();
            var client = CreateClient(handler, CreateTokenProvider().Object, retryDelay);

            await Assert.ThrowsAsync<SalesforceApiException>(() => client.UpsertAsync(
                "Order",
                "Invoice_Number__c",
                "INV001",
                new { Status = "Draft" }));

            Assert.Equal(1, requestCount);
            retryDelay.Verify(value => value.WaitAsync(It.IsAny<TimeSpan>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_EmptySoql_When_QueryAll_Should_ThrowArgumentException()
        {
            var client = CreateClient(new StubHttpMessageHandler((_, _) => throw new InvalidOperationException()), CreateTokenProvider().Object);

            await Assert.ThrowsAsync<ArgumentException>(
                () => client.QueryAllAsync<TestSalesforceRecord>(string.Empty));
        }

        [Fact]
        public async Task Given_InsecureSalesforceInstanceUrl_When_Querying_Should_RejectBeforeSendingBearerToken()
        {
            var requestSent = false;
            var handler = new StubHttpMessageHandler((_, _) =>
            {
                requestSent = true;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK));
            });
            var tokenProvider = new Mock<ISalesforceAccessTokenProvider>();
            tokenProvider
                .Setup(value => value.GetAccessTokenAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceAccessToken
                {
                    AccessToken = AccessToken,
                    InstanceUrl = "http://example.my.salesforce.com"
                });
            var client = CreateClient(handler, tokenProvider.Object);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(
                () => client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Contains("HTTPS", exception.Message, StringComparison.Ordinal);
            Assert.False(requestSent);
        }

        private static SalesforceApiClient CreateClient(
            HttpMessageHandler handler,
            ISalesforceAccessTokenProvider tokenProvider,
            Mock<ISalesforceRetryDelay>? retryDelay = null,
            string apiVersion = "v65.0")
        {
            retryDelay ??= CreateRetryDelay();

            return new SalesforceApiClient(
                new HttpClient(handler),
                tokenProvider,
                Options.Create(new SalesforceOptions { ApiVersion = apiVersion }),
                retryDelay.Object);
        }

        private static SalesforceApiClient CreateClient(HttpMessageHandler handler, ISalesforceAccessTokenProvider tokenProvider, string apiVersion)
        {
            return CreateClient(handler, tokenProvider, null, apiVersion);
        }

        private static Mock<ISalesforceRetryDelay> CreateRetryDelay()
        {
            var retryDelay = new Mock<ISalesforceRetryDelay>();
            retryDelay
                .Setup(value => value.Calculate(It.IsAny<int>(), It.IsAny<System.Net.Http.Headers.RetryConditionHeaderValue?>()))
                .Returns<int, System.Net.Http.Headers.RetryConditionHeaderValue?>((_, retryAfter) => retryAfter?.Delta ?? TimeSpan.Zero);
            retryDelay
                .Setup(value => value.WaitAsync(It.IsAny<TimeSpan>(), It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);
            return retryDelay;
        }

        private static Mock<ISalesforceAccessTokenProvider> CreateTokenProvider()
        {
            var provider = new Mock<ISalesforceAccessTokenProvider>();
            provider
                .Setup(value => value.GetAccessTokenAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(new SalesforceAccessToken
                {
                    AccessToken = AccessToken,
                    InstanceUrl = InstanceUrl,
                    TokenType = "Bearer"
                });

            return provider;
        }

        private class TestSalesforceRecord
        {
            public string Id { get; set; } = string.Empty;
        }

        [Fact]
        public async Task Given_Paged_Query_Has_No_Next_Url_When_Querying_Should_Reject_The_Incomplete_Response()
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("""
                        {"totalSize":1,"done":false,"records":[{"Id":"001"}]}
                        """)
                }));
            var client = CreateClient(handler, CreateTokenProvider().Object);

            var exception = await Assert.ThrowsAsync<SalesforceQueryResponseException>(() =>
                client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Equal("Salesforce returned an incomplete paged query response.", exception.Message);
        }

        [Fact]
        public async Task Given_Salesforce_Returns_An_Empty_Upsert_Response_When_Upserting_Should_Reject_The_Response()
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.Created)
                {
                    Content = new StringContent("null")
                }));
            var client = CreateClient(handler, CreateTokenProvider().Object);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => client.UpsertAsync(
                "Order",
                "Invoice_Number__c",
                "3051/00721885",
                new { Status = "Draft" }));

            Assert.Equal("Salesforce returned an empty upsert response.", exception.Message);
        }

        [Fact]
        public async Task Given_Api_Version_Is_Missing_When_Querying_Should_Reject_Before_Requesting_A_Token()
        {
            var tokenProvider = CreateTokenProvider();
            var client = CreateClient(
                new StubHttpMessageHandler((_, _) => throw new InvalidOperationException("HTTP should not be called")),
                tokenProvider.Object,
                string.Empty);

            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
                client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Equal("Salesforce ApiVersion is not configured.", exception.Message);
            tokenProvider.Verify(provider => provider.GetAccessTokenAsync(It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_Salesforce_Returns_A_Non_Json_Error_When_Querying_Should_Preserve_The_Status_Without_Fabricating_Errors()
        {
            var handler = new StubHttpMessageHandler((_, _) => Task.FromResult(
                new HttpResponseMessage(HttpStatusCode.BadGateway)
                {
                    Content = new StringContent("upstream gateway unavailable")
                }));
            var client = CreateClient(handler, CreateTokenProvider().Object);

            var exception = await Assert.ThrowsAsync<SalesforceApiException>(() =>
                client.QueryAllAsync<TestSalesforceRecord>("SELECT Id FROM Product2"));

            Assert.Equal(HttpStatusCode.BadGateway, exception.StatusCode);
            Assert.Empty(exception.Errors);
        }

    }
}
