using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class ConsolidatedSalesFileDataServiceTests
    {
        private static readonly Guid SourceItemId = new("10000000-0000-0000-0000-000000000001");
        private static readonly Guid ClaimToken = new("10000000-0000-0000-0000-000000000002");
        private static readonly DateTimeOffset FirstReadOn = new(2026, 8, 5, 10, 0, 0, TimeSpan.Zero);
        private static readonly DateTimeOffset NextAttemptOn = new(2026, 8, 5, 10, 30, 0, TimeSpan.Zero);

        private readonly Mock<IDbExecutor> _dbExecutor = new();

        [Fact]
        public async Task Given_A_Source_Registration_When_Registering_Should_Use_The_Register_Procedure()
        {
            var registration = new ConsolidatedSalesSourceRegistration { ETag = "etag" };
            var expected = new ConsolidatedSalesSourceItem { IsNew = true };
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesSourceItem>(StoredProcedures.RegisterConsolidatedSalesSourceItem, registration)).ReturnsAsync(expected);

            var result = await CreateService().RegisterAsync(registration);

            Assert.Same(expected, result);
            _dbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_Source_Work_When_Processing_Lifecycle_Should_Use_The_Source_Procedures()
        {
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesSourceItem>(StoredProcedures.ClaimNextConsolidatedSalesSourceItem, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesSourceItem());

            _dbExecutor.Setup(x => x.ExecuteScalarAsync<DateTimeOffset>(StoredProcedures.RecordConsolidatedSalesSourceFirstRead, It.IsAny<object>())).ReturnsAsync(FirstReadOn);

            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(StoredProcedures.RenewConsolidatedSalesSourceItemLease, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesLeaseResult());

            _dbExecutor.Setup(x => x.ExecuteAsync(StoredProcedures.CompleteConsolidatedSalesSourceItem, It.IsAny<object>())).ReturnsAsync(1);

            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesSourceFailureResult>(StoredProcedures.FailConsolidatedSalesSourceItem, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesSourceFailureResult>(StoredProcedures.AwaitConsolidatedSalesSourceCorrection, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesSourceFailureResult());

            _dbExecutor.Setup(x => x.ExecuteAsync(StoredProcedures.RequeueConsolidatedSalesWork, It.IsAny<object>())).ReturnsAsync(1);

            var service = CreateService();

            await service.ClaimNextAsync("worker", 60, 3);
            Assert.Equal(FirstReadOn, await service.RecordFirstReadAsync(SourceItemId, ClaimToken));
            await service.RenewLeaseAsync(SourceItemId, ClaimToken, 60);
            await service.CompleteAsync(SourceItemId, ClaimToken, true);
            await service.FailAsync(SourceItemId, ClaimToken, "Transient", "Failure", NextAttemptOn, 3);
            await service.AwaitCorrectionAsync(SourceItemId, ClaimToken, "MalformedXml", "Invalid HX XML");
            await service.RequeueAsync(SourceItemId, "Approved replay");

            _dbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_A_Claimed_Source_When_Recording_First_Read_Should_Pass_The_Claim_And_UTC_Time_To_The_Database()
        {
            object? parameters = null;
            _dbExecutor
                .Setup(x => x.ExecuteScalarAsync<DateTimeOffset>(StoredProcedures.RecordConsolidatedSalesSourceFirstRead, It.IsAny<object>()))
                .Callback<string, object>((_, value) => parameters = value)
                .ReturnsAsync(FirstReadOn);

            var result = await CreateService().RecordFirstReadAsync(SourceItemId, ClaimToken, FirstReadOn);

            Assert.Equal(FirstReadOn, result);
            Assert.Equal(SourceItemId, GetProperty<Guid>(parameters!, "sourceItemId"));
            Assert.Equal(ClaimToken, GetProperty<Guid>(parameters!, "claimToken"));
            Assert.Equal(FirstReadOn, GetProperty<DateTimeOffset?>(parameters!, "now"));
            _dbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_A_Cancelled_Token_When_Recording_First_Read_Should_Not_Call_The_Database()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().RecordFirstReadAsync(SourceItemId, ClaimToken, FirstReadOn, token));

            _dbExecutor.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_A_Cancelled_Token_When_Registering_Should_Not_Call_The_Database()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().RegisterAsync(new ConsolidatedSalesSourceRegistration(), token));

            _dbExecutor.VerifyNoOtherCalls();
        }

        private ConsolidatedSalesFileDataService CreateService() => new(_dbExecutor.Object);

        private static T GetProperty<T>(object instance, string propertyName) => (T)instance.GetType().GetProperty(propertyName)!.GetValue(instance)!;
    }
}
