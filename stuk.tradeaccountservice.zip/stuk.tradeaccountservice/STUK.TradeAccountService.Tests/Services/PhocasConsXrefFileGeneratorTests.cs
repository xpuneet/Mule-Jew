using Moq;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Security.Cryptography;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the recovered MuleSoft Phocas ConsXref file contract
    /// </summary>
    public class PhocasConsXrefFileGeneratorTests
    {
        private static readonly Guid ExportRunId = new("50000000-0000-0000-0000-000000000001");

        private readonly Mock<IConsolidatedSalesExportDataService> _exportDataService = new();

        [Fact]
        public async Task Given_CompletedSnapshot_When_Generating_Should_WriteLegacyPhocasLayoutAndEvidence()
        {
            _exportDataService
                .Setup(service => service.GetRowsAsync(ExportRunId, 0, 1000, It.IsAny<CancellationToken>()))
                .ReturnsAsync(
                [
                    new ConsolidatedSalesExportRow
                    {
                        RowSequence = 1,
                        AccountNumber = "hdy",
                        InvoiceNumber = "9999",
                        InvoiceDate = new DateOnly(2020, 8, 9),
                        DeliveryNoteNumber = "89098",
                        DeliveryNoteLineNumber = "9",
                        DespatchDate = new DateOnly(2020, 8, 9),
                        ProductCode = "EI3018ZZ",
                        Quantity = 3m,
                        TotalPrice = 23m
                    },
                    new ConsolidatedSalesExportRow
                    {
                        RowSequence = 2,
                        AccountNumber = "ACP09",
                        InvoiceNumber = "9090",
                        InvoiceDate = new DateOnly(2020, 8, 9),
                        DeliveryNoteNumber = "89098",
                        DeliveryNoteLineNumber = "0",
                        DespatchDate = new DateOnly(2020, 8, 9),
                        ProductCode = "EI3018ZZ",
                        Quantity = 1.23456m,
                        TotalPrice = 19.123456789012345678m
                    }
                ]);
            await using var destination = new MemoryStream();

            var result = await CreateService().GenerateAsync(ExportRunId, 2020, destination);

            var expected = string.Join(
                string.Empty,
                "hdy\t9999\t09/08/2020\t89098\t9\t09/08/2020\tEI3018ZZ\t3.0\t23\r\n",
                "ACP09\t9090\t09/08/2020\t89098\t0\t09/08/2020\tEI3018ZZ\t1.2346\t19.123456789012345678\r\n");
            var expectedBytes = new UTF8Encoding(false).GetBytes(expected);

            Assert.Equal(expectedBytes, destination.ToArray());
            Assert.Equal("2020_ConsXref.txt", result.FileName);
            Assert.Equal(2, result.RowCount);
            Assert.Equal(expectedBytes.LongLength, result.ByteCount);
            Assert.Equal(Convert.ToHexString(SHA256.HashData(expectedBytes)).ToLowerInvariant(), result.ContentHash);
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_NullValues_When_Generating_Should_WriteEmptyUnquotedColumns()
        {
            _exportDataService
                .Setup(service => service.GetRowsAsync(ExportRunId, 0, 1000, It.IsAny<CancellationToken>()))
                .ReturnsAsync([new ConsolidatedSalesExportRow { RowSequence = 1 }]);
            await using var destination = new MemoryStream();

            var result = await CreateService().GenerateAsync(ExportRunId, 2026, destination);

            Assert.Equal("\t\t\t\t\t\t\t\t\r\n", Encoding.UTF8.GetString(destination.ToArray()));
            Assert.Equal(1, result.RowCount);
        }

        [Fact]
        public async Task Given_EmptySnapshot_When_Generating_Should_ReturnEmptyFileEvidence()
        {
            _exportDataService
                .Setup(service => service.GetRowsAsync(ExportRunId, 0, 1000, It.IsAny<CancellationToken>()))
                .ReturnsAsync([]);
            await using var destination = new MemoryStream();

            var result = await CreateService().GenerateAsync(ExportRunId, 2026, destination);

            Assert.Empty(destination.ToArray());
            Assert.Equal(0, result.RowCount);
            Assert.Equal(0, result.ByteCount);
            Assert.Equal(Convert.ToHexString(SHA256.HashData([])).ToLowerInvariant(), result.ContentHash);
        }

        [Fact]
        public async Task Given_NonSequentialSnapshot_When_Generating_Should_RejectTheFile()
        {
            _exportDataService
                .Setup(service => service.GetRowsAsync(ExportRunId, 0, 1000, It.IsAny<CancellationToken>()))
                .ReturnsAsync([new ConsolidatedSalesExportRow { RowSequence = 2 }]);
            await using var destination = new MemoryStream();

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() =>
                CreateService().GenerateAsync(ExportRunId, 2026, destination));

            Assert.Contains("expected row sequence 1 but received 2", exception.Message);
        }

        [Fact]
        public async Task Given_NonNumericDeliveryLine_When_Generating_Should_RejectTheFile()
        {
            _exportDataService
                .Setup(service => service.GetRowsAsync(ExportRunId, 0, 1000, It.IsAny<CancellationToken>()))
                .ReturnsAsync(
                [
                    new ConsolidatedSalesExportRow
                    {
                        RowSequence = 1,
                        DeliveryNoteLineNumber = "line-one"
                    }
                ]);
            await using var destination = new MemoryStream();

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() =>
                CreateService().GenerateAsync(ExportRunId, 2026, destination));

            Assert.Contains("is not numeric", exception.Message);
        }

        [Fact]
        public async Task Given_LargeCompletedSnapshot_When_Generating_Should_ReadBoundedPagesInSequence()
        {
            var firstPage = Enumerable.Range(1, 1000)
                .Select(sequence => new ConsolidatedSalesExportRow { RowSequence = sequence })
                .ToArray();
            _exportDataService
                .Setup(service => service.GetRowsAsync(
                    ExportRunId,
                    It.IsAny<long>(),
                    1000,
                    It.IsAny<CancellationToken>()))
                .Returns<Guid, long, int, CancellationToken>((_, afterRowSequence, _, _) =>
                {
                    IReadOnlyCollection<ConsolidatedSalesExportRow> rows = afterRowSequence switch
                    {
                        0 => firstPage,
                        1000 => [new ConsolidatedSalesExportRow { RowSequence = 1001 }],
                        _ => []
                    };

                    return Task.FromResult(rows);
                });
            await using var destination = new MemoryStream();

            var result = await CreateService().GenerateAsync(ExportRunId, 2026, destination);

            Assert.Equal(1001, result.RowCount);
            _exportDataService.Verify(service => service.GetRowsAsync(
                ExportRunId,
                0,
                1000,
                It.IsAny<CancellationToken>()), Times.Once);
            _exportDataService.Verify(service => service.GetRowsAsync(
                ExportRunId,
                1000,
                1000,
                It.IsAny<CancellationToken>()), Times.Once);
        }

        private PhocasConsXrefFileGenerator CreateService()
        {
            return new PhocasConsXrefFileGenerator(_exportDataService.Object);
        }
    }
}
