﻿using Azure.Storage.Blobs;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class StatementDownloadServiceTests
    {
        private readonly Mock<IDocumentMetadataResolver<long, string?>> _resolverMock;
        private readonly Mock<BlobServiceClient> _blobServiceClientMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly StatementDownloadService _service;

        public StatementDownloadServiceTests()
        {
            _resolverMock = new Mock<IDocumentMetadataResolver<long, string?>>();
            _blobServiceClientMock = new Mock<BlobServiceClient>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();

            _resolverMock.Setup(r => r.DocumentType).Returns("Statement");
            _resolverMock.Setup(r => r.ContainerName).Returns("statementtest");
            _resolverMock.Setup(r => r.DefaultFileName).Returns("DefaultStatement.pdf");
            _resolverMock.Setup(r => r.ParseIdentifier(It.IsAny<string>())).Returns((string s) => long.Parse(s));

            _service = new StatementDownloadService(
                _resolverMock.Object,
                new HttpClient(),
                _blobServiceClientMock.Object,
                _loggerMock.Object);
        }

        #region RequestDownload

        [Fact]
        public async Task RequestDownload_ExistingCache_ReturnsExistingToken()
        {
            // Arrange
            var existingToken = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = existingToken,
                    Identifier = "100",
                    DocumentType = "Statement",
                    DownloadStatus = "Pending"
                });

            // Act
            var result = await _service.RequestDownloadAsync(100L, null);

            // Assert
            Assert.Equal(existingToken, result.Token);
            Assert.Contains("already active", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_MetadataNotFound_ThrowsKeyNotFoundException()
        {
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentMetadata?)null);

            // Act & Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() =>
                _service.RequestDownloadAsync(100L, null));
        }

        [Fact]
        public async Task RequestDownload_BlobUriEmpty_ReturnsPendingStatus()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "statement.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync(100L, null, "Pending", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            var result = await _service.RequestDownloadAsync(100L, null);

            // Assert
            Assert.Equal(token, result.Token);
            Assert.Contains("being prepared", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_BlobUriExists_ReturnsReadyStatus()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/05/statement.pdf", FileName = "statement.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync(100L, null, "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((token, DateTimeOffset.Now));

            // Act
            var result = await _service.RequestDownloadAsync(100L, null);

            // Assert
            Assert.Equal(token, result.Token);
            Assert.Contains("ready for download", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task RequestDownload_TokenGenerationFails_ThrowsInvalidOperationException()
        {
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByIdentifierAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            _resolverMock
                .Setup(r => r.GetMetadataAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = "2026/05/statement.pdf", FileName = "statement.pdf" });

            _resolverMock
                .Setup(r => r.InsertCacheAsync(100L, null, "Ready", It.IsAny<CancellationToken>()))
                .ReturnsAsync((Guid.Empty, DateTimeOffset.Now));

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                _service.RequestDownloadAsync(100L, null));
        }

        #endregion

        #region Download

        [Fact]
        public async Task Download_InvalidToken_ThrowsKeyNotFoundException()
        {
            var invalidToken = Guid.Empty;
            // Arrange
            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(invalidToken, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act & Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() =>
                _service.DownloadAsync(invalidToken));
        }

        [Fact]
        public async Task Download_MetadataNotFound_ReturnsNotReadyMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "100",
                    DocumentType = "Statement",
                    DownloadStatus = "Ready"
                });

            _resolverMock
                .Setup(r => r.GetMetadataAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync((DocumentMetadata?)null);

            // Act
            var result = await _service.DownloadAsync(token);

            // Assert
            Assert.Null(result.FileContent);
            Assert.Contains("not ready", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task Download_BlobUriEmpty_ReturnsNotReadyMessage()
        {
            // Arrange
            var token = Guid.NewGuid();

            _resolverMock
                .Setup(r => r.GetCacheByTokenAsync(token, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = Guid.NewGuid(),
                    Identifier = "100",
                    DocumentType = "Statement",
                    DownloadStatus = "Pending"
                });

            _resolverMock
                .Setup(r => r.GetMetadataAsync(100L, null, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new DocumentMetadata { BlobUri = null, FileName = "statement.pdf" });

            // Act
            var result = await _service.DownloadAsync(token);

            // Assert
            Assert.Null(result.FileContent);
            Assert.Contains("not ready", result.Message, StringComparison.OrdinalIgnoreCase);
        }

        #endregion

        #region ServiceType

        [Fact]
        public void Service_ImplementsIStatementDownloadService()
        {
            Assert.IsAssignableFrom<IStatementDownloadService>(_service);
        }

        #endregion
    }
}
