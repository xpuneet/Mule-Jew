using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services;

public class TradeAccountPaymentServiceTests
{
    private readonly Mock<IDbExecutor> _dbExecutorMock;
    private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
    private readonly TradeAccountPaymentService _service;

    public TradeAccountPaymentServiceTests()
    {
        _dbExecutorMock = new Mock<IDbExecutor>();
        _loggerMock = new Mock<IAppInsightsLoggerHelper>();
        _service = new TradeAccountPaymentService(_dbExecutorMock.Object, _loggerMock.Object);
    }

    #region GetPayementByReferenceCode

    [Fact]
    public async Task GetPayementByReferenceCode_ValidRef_ReturnsPayment()
    {
        var paymentRef = Guid.NewGuid();
        // Arrange
        var expected = new Payment
        {
            AccountCode = "ACC001",
            BranchId = "BR01",
            Source = "Online",
            Description = "Order payment",
            PaymentType = "Card",
            PaymentAmount = 250.50m,
            ApiPaymentReference = Guid.NewGuid()
        };
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<Payment>(
                StoredProcedures.GetPaymentsByReference,
                It.Is<object>(o => o.GetType().GetProperty("paymentRef")!.GetValue(o)!.ToString() == paymentRef.ToString())))
            .ReturnsAsync(expected);

        // Act
        var result = await _service.GetPayementReferenceByRefCodeAsync(paymentRef);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("ACC001", result!.AccountCode);
        Assert.Equal(250.50m, result.PaymentAmount);
    }

    [Fact]
    public async Task GetPayementByReferenceCode_NotFound_ReturnsNull()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<Payment>(
                StoredProcedures.GetPaymentsByReference,
                It.IsAny<object>()))
            .ReturnsAsync((Payment?)null);

        // Act
        var result = await _service.GetPayementReferenceByRefCodeAsync(Guid.NewGuid());

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task GetPayementByReferenceCode_DbThrows_Propagates()
    {
        // Arrange
        var exception = new Exception("Connection refused");
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<Payment>(
                StoredProcedures.GetPaymentsByReference,
                It.IsAny<object>()))
            .ThrowsAsync(exception);

        // Act & Assert
        var ex = await Assert.ThrowsAsync<Exception>(
            () => _service.GetPayementReferenceByRefCodeAsync(Guid.NewGuid()));
        Assert.Equal("Connection refused", ex.Message);
    }

    [Fact]
    public async Task GetPayementByReferenceCode_CallsCorrectStoredProcedure()
    {
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<Payment>(
                StoredProcedures.GetPaymentsByReference,
                It.IsAny<object>()))
            .ReturnsAsync(new Payment());

        // Act
        await _service.GetPayementReferenceByRefCodeAsync(Guid.NewGuid());

        // Assert
        _dbExecutorMock.Verify(
            db => db.ExecuteSingleAsync<Payment>("GetPaymentsByReference", It.IsAny<object>()),
            Times.Once);
    }

    [Fact]
    public async Task GetPayementByReferenceCode_LogsStartAndCompletion()
    {
        var paymentRef = Guid.NewGuid();
        // Arrange
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<Payment>(
                StoredProcedures.GetPaymentsByReference,
                It.IsAny<object>()))
            .ReturnsAsync(new Payment());

        // Act
        await _service.GetPayementReferenceByRefCodeAsync(paymentRef);

        // Assert
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("started") && s.Contains(paymentRef.ToString())),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("found")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
    }

    #endregion

    #region CreatePayementAsync

    [Fact]
    public async Task CreatePayementAsync_ValidRequest_ReturnsSuccess()
    {
        // Arrange
        var request = CreateValidRequest();

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()))
            .ReturnsAsync(new CreatePaymentResponse
            {
                Success = true,
                Message = "Payment created",
                PaymentId = 1,
                ErrorMessage = string.Empty
            });

        // Act
        var result = await _service.CreatePayementreferenceAsync(request);

        // Assert
        Assert.NotNull(result);
        Assert.True(result!.Success);
        Assert.Equal("Payment created", result.Message);
        Assert.Equal(1, result.PaymentId);
    }

    [Fact]
    public async Task CreatePayementAsync_CallsCorrectStoredProcedure()
    {
        // Arrange
        var request = CreateValidRequest();
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()))
            .ReturnsAsync(new CreatePaymentResponse { Success = true, Message = "Payment created", PaymentId = 1 });

        // Act
        await _service.CreatePayementreferenceAsync(request);

        // Assert
        _dbExecutorMock.Verify(
            db => db.ExecuteSingleAsync<CreatePaymentResponse>("InsertPaymentInfo", It.IsAny<object>()),
            Times.Once);
    }

    [Fact]
    public async Task CreatePayementAsync_DbThrows_Propagates()
    {
        // Arrange
        var request = CreateValidRequest();
        var exception = new InvalidOperationException("Constraint violation");
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()))
            .ThrowsAsync(exception);

        // Act & Assert
        var ex = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _service.CreatePayementreferenceAsync(request));
        Assert.Equal("Constraint violation", ex.Message);
    }

    [Fact]
    public async Task CreatePayementAsync_LogsStartAndCompletion()
    {
        // Arrange
        var request = CreateValidRequest();
        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()))
            .ReturnsAsync(new CreatePaymentResponse { Success = true, Message = "Payment created", PaymentId = 1 });

        // Act
        await _service.CreatePayementreferenceAsync(request);

        // Assert
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("started")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
        _loggerMock.Verify(
            l => l.LogInformation(
                It.Is<string>(s => s.Contains("completed")),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<Dictionary<string, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task CreatePayementAsync_NullResult_ReturnsNull()
    {
        // Arrange
        var request = CreateValidRequest();

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()))
            .ReturnsAsync((CreatePaymentResponse?)null);

        // Act
        var result = await _service.CreatePayementreferenceAsync(request);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task CreatePayementAsync_FailedResult_LogsWarning()
    {
        // Arrange
        var request = CreateValidRequest();

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()))
            .ReturnsAsync(new CreatePaymentResponse
            {
                Success = false,
                Message = "Duplicate",
                ErrorMessage = "Payment already exists"
            });

        // Act
        var result = await _service.CreatePayementreferenceAsync(request);

        // Assert
        Assert.NotNull(result);
        Assert.False(result!.Success);
        _loggerMock.Verify(
            l => l.LogWarning(
                It.Is<string>(s => s.Contains("duplicate", StringComparison.OrdinalIgnoreCase)),
                It.IsAny<string>(),
                It.IsAny<string>()),
            Times.Once);
    }

    [Fact]
    public async Task CreatePayementAsync_WithOptionalFields_Succeeds()
    {
        // Arrange
        var request = CreateValidRequest();
        request.UserId = "USER01";
        request.OrderReference = "ORD-001";
        request.OrderNumber = "12345";
        request.CreditCardReference = "CC-REF";

        _dbExecutorMock
            .Setup(db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()))
            .ReturnsAsync(new CreatePaymentResponse
            {
                Success = true,
                Message = "Payment created",
                PaymentId = 1,
                ErrorMessage = string.Empty
            });

        // Act
        var result = await _service.CreatePayementreferenceAsync(request);

        // Assert
        Assert.NotNull(result);
        Assert.True(result!.Success);
        Assert.Equal("Payment created", result.Message);

        _dbExecutorMock.Verify(
            db => db.ExecuteSingleAsync<CreatePaymentResponse>(
                StoredProcedures.InsertPaymentInfo,
                It.IsAny<object>()),
            Times.Once);
    }

    #endregion

    #region Helpers

    private static CreatePaymentRequest CreateValidRequest() => new()
    {
        AccountCode = "ACC001",
        BranchId = "BR01",
        Source = "Online",
        Description = "Test payment",
        PaymentType = 'C',
        PaymentAmount = 100.00m
    };

    #endregion
}
