using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Time.Testing;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Salesforce.Config;
using STUK.TradeAccountService.Common.Salesforce.Interfaces;
using STUK.TradeAccountService.Common.Salesforce.Services;
using STUK.TradeAccountService.Tests.Helpers;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests idempotent scheduling, claiming and replay for the Consolidated Sales export
    /// </summary>
    public class ConsolidatedSalesExportOrchestrationServiceTests
    {
        private static readonly DateTimeOffset SummerMondayScheduleUtc = new(2026, 8, 9, 23, 30, 0, TimeSpan.Zero);
        private static readonly Guid ExportRunId = new("40000000-0000-0000-0000-000000000001");
        private static readonly Guid ClaimToken = new("40000000-0000-0000-0000-000000000002");

        private readonly Mock<IConsolidatedSalesExportDataService> _exportDataService = new();
        private readonly Mock<IConsolidatedSalesExportExtractionService> _extractionService = new();
        private readonly Mock<IPhocasExportStagingService> _phocasExportStagingService = new();
        private readonly Mock<IDataLakeExportService> _dataLakeExportService = new();

        [Fact]
        public async Task Given_MondaySchedule_When_Run_Should_RegisterStableLondonLogicalRun()
        {
            ConsolidatedSalesExportRunRegistration? capturedRegistration = null;
            _exportDataService
                .Setup(service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()))
                .Callback<ConsolidatedSalesExportRunRegistration, CancellationToken>((registration, _) => capturedRegistration = registration)
                .ReturnsAsync(new ConsolidatedSalesExportRun());
            _exportDataService
                .Setup(service => service.ClaimNextRunAsync(
                    "invocation-1",
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesExportRun?)null);

            await CreateService().RunAsync("invocation-1");

            Assert.NotNull(capturedRegistration);
            Assert.Equal("ConsXref:2026-08-10", capturedRegistration.LogicalRunKey);
            Assert.Equal(2026, capturedRegistration.ExportYear);
            Assert.Equal(new DateOnly(2026, 1, 1), capturedRegistration.ExtractFromDate);
            Assert.Equal(SummerMondayScheduleUtc, capturedRegistration.ScheduledFor);
            Assert.Equal(SummerMondayScheduleUtc, capturedRegistration.Now);
            Assert.NotEqual(Guid.Empty, capturedRegistration.CorrelationId);
            _extractionService.VerifyNoOtherCalls();
            _phocasExportStagingService.Verify(service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()), Times.Once);
            _dataLakeExportService.Verify(service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_DuplicateTimerInvocations_When_Run_Should_UseTheSameLogicalRunKey()
        {
            var logicalRunKeys = new List<string>();
            _exportDataService
                .Setup(service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()))
                .Callback<ConsolidatedSalesExportRunRegistration, CancellationToken>((registration, _) => logicalRunKeys.Add(registration.LogicalRunKey))
                .ReturnsAsync(new ConsolidatedSalesExportRun());
            _exportDataService
                .Setup(service => service.ClaimNextRunAsync(
                    It.IsAny<string>(),
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesExportRun?)null);
            var service = CreateService();

            await service.RunAsync("invocation-1");
            await service.RunAsync("invocation-2");

            Assert.Equal(new[] { "ConsXref:2026-08-10", "ConsXref:2026-08-10" }, logicalRunKeys);
            _extractionService.VerifyNoOtherCalls();
            _phocasExportStagingService.Verify(service => service.RunAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>()), Times.Exactly(2));
            _dataLakeExportService.Verify(service => service.RunAsync(It.IsAny<string>(), null, It.IsAny<CancellationToken>()), Times.Exactly(2));
        }

        [Fact]
        public async Task Given_EligibleRun_When_Run_Should_ExtractTheClaimedSnapshot()
        {
            var claimedRun = new ConsolidatedSalesExportRun
            {
                Id = ExportRunId,
                CorrelationId = Guid.NewGuid(),
                Status = "Extracting",
                ClaimToken = ClaimToken
            };
            _exportDataService
                .Setup(service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportRun());
            _exportDataService
                .Setup(service => service.ClaimNextRunAsync(
                    "invocation-1",
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(claimedRun);
            _extractionService
                .Setup(service => service.ExtractAsync(
                    claimedRun,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportExtractionResult { ExportRunId = ExportRunId });

            await CreateService().RunAsync("invocation-1");

            _extractionService.VerifyAll();
            _phocasExportStagingService.Verify(service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()), Times.Once);
            _dataLakeExportService.Verify(service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task Given_OverlappingWorkers_When_OnlyOneClaimSucceeds_Should_ExtractSnapshotOnce()
        {
            var claimedRun = new ConsolidatedSalesExportRun
            {
                Id = ExportRunId,
                CorrelationId = Guid.NewGuid(),
                Status = "Extracting",
                ClaimToken = ClaimToken
            };
            _exportDataService
                .Setup(service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportRun());
            _exportDataService
                .SetupSequence(service => service.ClaimNextRunAsync(
                    It.IsAny<string>(),
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(claimedRun)
                .ReturnsAsync((ConsolidatedSalesExportRun?)null);
            _extractionService
                .Setup(service => service.ExtractAsync(claimedRun, It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportExtractionResult { ExportRunId = ExportRunId });
            var service = CreateService();

            await service.RunAsync("worker-1");
            await service.RunAsync("worker-2");

            _extractionService.Verify(
                extraction => extraction.ExtractAsync(claimedRun, It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_ExtractionLeaseLoss_When_Run_Should_CancelExtractionAndNotPublishFromThatWorker()
        {
            var claimedRun = new ConsolidatedSalesExportRun
            {
                Id = ExportRunId,
                CorrelationId = Guid.NewGuid(),
                Status = "Extracting",
                ClaimToken = ClaimToken
            };
            var extractionCancelled = false;
            var extractionStarted = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            _exportDataService
                .Setup(service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportRun());
            _exportDataService
                .Setup(service => service.ClaimNextRunAsync(
                    "worker-1",
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(claimedRun);
            _exportDataService
                .Setup(service => service.RenewRunLeaseAsync(
                    ExportRunId,
                    ClaimToken,
                    900,
                    It.Is<DateTimeOffset>(renewedOn => renewedOn >= SummerMondayScheduleUtc.AddSeconds(60)),
                    It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Lease lost"));
            _extractionService
                .Setup(service => service.ExtractAsync(claimedRun, It.IsAny<CancellationToken>()))
                .Returns<ConsolidatedSalesExportRun, CancellationToken>(async (_, cancellationToken) =>
                {
                    extractionStarted.SetResult();
                    try
                    {
                        await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
                    }
                    catch (OperationCanceledException)
                    {
                        extractionCancelled = true;
                        throw;
                    }

                    return new ConsolidatedSalesExportExtractionResult();
                });
            var timeProvider = new FakeTimeProvider(SummerMondayScheduleUtc);

            var runTask = CreateService(timeProvider).RunAsync("worker-1");
            await extractionStarted.Task;
            for (var advanceNumber = 0; advanceNumber < 3 && !runTask.IsCompleted; advanceNumber++)
            {
                await Task.Delay(10);
                timeProvider.Advance(TimeSpan.FromSeconds(60));
            }

            await runTask.WaitAsync(TimeSpan.FromSeconds(5));

            Assert.True(extractionCancelled);
            _exportDataService.VerifyAll();
        }

        [Fact]
        public async Task Given_PhocasCannotStart_When_Run_Should_StillProcessDataLakeIndependently()
        {
            _exportDataService
                .Setup(service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportRun());
            _exportDataService
                .Setup(service => service.ClaimNextRunAsync(
                    "invocation-1",
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesExportRun?)null);
            _phocasExportStagingService
                .Setup(service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Phocas is not configured"));

            await CreateService().RunAsync("invocation-1");

            _dataLakeExportService.Verify(
                service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_DataLakeCannotStart_When_Run_Should_StillProcessPhocasIndependently()
        {
            _exportDataService
                .Setup(service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportRun());
            _exportDataService
                .Setup(service => service.ClaimNextRunAsync(
                    "invocation-1",
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((ConsolidatedSalesExportRun?)null);
            _dataLakeExportService
                .Setup(service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Data Lake is not configured"));

            await CreateService().RunAsync("invocation-1");

            _phocasExportStagingService.Verify(
                service => service.RunAsync("invocation-1", null, It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_ApprovedDestinationReplay_When_Replaying_Should_RetainTheExistingSnapshot()
        {
            var destinationId = Guid.NewGuid();
            _exportDataService
                .Setup(service => service.RequeueDestinationAsync(
                    destinationId,
                    "Approved support replay",
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .Returns(Task.CompletedTask);

            await CreateService().ReplayDestinationAsync(destinationId, "Approved support replay");

            _exportDataService.VerifyAll();
            _exportDataService.Verify(
                service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
            _extractionService.VerifyNoOtherCalls();
            _phocasExportStagingService.VerifyNoOtherCalls();
            _dataLakeExportService.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_DestinationRecovery_When_Running_Should_Not_Register_Or_Extract_A_Salesforce_Snapshot()
        {
            await CreateService().RunDestinationsAsync("recovery-invocation");

            _exportDataService.Verify(
                service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
            _extractionService.VerifyNoOtherCalls();
            _phocasExportStagingService.Verify(
                service => service.RunAsync("recovery-invocation", null, It.IsAny<CancellationToken>()),
                Times.Once);
            _dataLakeExportService.Verify(
                service => service.RunAsync("recovery-invocation", null, It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_TargetedDestinationRecovery_When_Running_Should_OnlyOfferTheRequestedDestinationId()
        {
            var destinationId = Guid.NewGuid();

            await CreateService().RunDestinationsAsync("replay-invocation", destinationId);

            _phocasExportStagingService.Verify(
                service => service.RunAsync("replay-invocation", destinationId, It.IsAny<CancellationToken>()),
                Times.Once);
            _dataLakeExportService.Verify(
                service => service.RunAsync("replay-invocation", destinationId, It.IsAny<CancellationToken>()),
                Times.Once);
        }

        [Fact]
        public async Task Given_EligibleExtraction_When_RecoveryRuns_Should_ProcessWithoutRegisteringANewWeeklyRun()
        {
            var claimedRun = new ConsolidatedSalesExportRun
            {
                Id = ExportRunId,
                CorrelationId = Guid.NewGuid(),
                Status = "Extracting",
                ClaimToken = ClaimToken
            };
            _exportDataService
                .Setup(service => service.ClaimNextRunAsync(
                    "recovery-invocation",
                    900,
                    5,
                    SummerMondayScheduleUtc,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(claimedRun);
            _extractionService
                .Setup(service => service.ExtractAsync(
                    claimedRun,
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ConsolidatedSalesExportExtractionResult { ExportRunId = ExportRunId });

            await CreateService().RunRecoveryAsync("recovery-invocation");

            _exportDataService.Verify(
                service => service.CreateRunAsync(
                    It.IsAny<ConsolidatedSalesExportRunRegistration>(),
                    It.IsAny<CancellationToken>()),
                Times.Never);
            _extractionService.VerifyAll();
            _phocasExportStagingService.Verify(
                service => service.RunAsync("recovery-invocation", null, It.IsAny<CancellationToken>()),
                Times.Once);
            _dataLakeExportService.Verify(
                service => service.RunAsync("recovery-invocation", null, It.IsAny<CancellationToken>()),
                Times.Once);
        }

        private ConsolidatedSalesExportOrchestrationService CreateService(TimeProvider? timeProvider = null)
        {
            return new ConsolidatedSalesExportOrchestrationService(
                Mock.Of<ILogger<ConsolidatedSalesExportOrchestrationService>>(),
                _exportDataService.Object,
                _extractionService.Object,
                _phocasExportStagingService.Object,
                _dataLakeExportService.Object,
                timeProvider ?? new FixedTimeProvider(SummerMondayScheduleUtc));
        }
    }
}
