using Microsoft.Extensions.Options;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Data.Services;
using STUK.TradeAccountService.Tests.Fixtures.Workday;
using System.Xml.Linq;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests the source-derived Workday Get_Workers SOAP request contracts
    /// </summary>
    public class WorkdaySoapRequestFactoryTests
    {
        private const string WorkdayNamespace = "urn:com.workday/bsvc";
        private const string SecurityNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
        private const string IntegrationUsername = "integration-user";
        private const string IntegrationPassword = "secure-password";
        private static readonly DateTimeOffset From = new(2026, 7, 1, 0, 0, 0, TimeSpan.Zero);
        private static readonly DateTimeOffset Through = new(2026, 7, 1, 1, 30, 0, TimeSpan.Zero);

        /// <summary>
        /// Verifies the effective-worker date criteria, integration provider and full response group
        /// </summary>
        [Fact]
        public void Given_EffectiveWindow_When_CreatingRequest_Should_MatchMuleContract()
        {
            var document = XDocument.Parse(CreateFactory().CreateEffectiveWorkerRequest(From, Through, 2, 100));

            AssertMatchesFixture(document, "effective-request.xml");
            AssertCommonEnvelope(document);
            Assert.Equal("2026-06-30T17:00:00", Value(document, "Effective_From"));
            Assert.Equal("2026-06-30T18:30:00", Value(document, "Effective_Through"));
            Assert.Equal("INT029ConcurFields", Value(document, "Provider_Reference"));
            Assert.Equal("true", Value(document, "Include_Personal_Information"));
            Assert.Equal("2", Value(document, "Page"));
            Assert.Equal("100", Value(document, "Count"));
            Assert.Empty(document.Descendants(WorkdayName("Exclude_Contingent_Workers")));
        }

        /// <summary>
        /// Verifies the updated-worker date criteria and reference-only response group
        /// </summary>
        [Fact]
        public void Given_UpdatedWindow_When_CreatingRequest_Should_MatchMuleContract()
        {
            var document = XDocument.Parse(CreateFactory().CreateUpdatedWorkerRequest(From, Through, 1, 100));

            AssertMatchesFixture(document, "updated-request.xml");
            AssertCommonEnvelope(document);
            Assert.Equal("2026-06-30T17:00:00", Value(document, "Updated_From"));
            Assert.Equal("2026-06-30T18:30:00", Value(document, "Updated_Through"));
            Assert.Equal("true", Value(document, "Include_Reference"));
            Assert.Equal("false", Value(document, "Include_Personal_Information"));
            Assert.Empty(document.Descendants(WorkdayName("Provider_Reference")));
        }

        /// <summary>
        /// Verifies detail requests use Employee_ID references, the integration provider and full response group
        /// </summary>
        [Fact]
        public void Given_EmployeeIds_When_CreatingDetailRequest_Should_MatchMuleContract()
        {
            var document = XDocument.Parse(CreateFactory().CreateWorkerDetailRequest(["1001", "1002"], 1, 100));
            var references = document.Descendants(WorkdayName("Worker_Reference")).ToArray();

            AssertMatchesFixture(document, "detail-request.xml");
            AssertCommonEnvelope(document);
            Assert.Equal(["1001", "1002"], references.Select(reference => Value(reference, "ID")));
            Assert.All(references, reference =>
                Assert.Equal("Employee_ID", reference.Element(WorkdayName("ID"))?.Attribute(WorkdayName("type"))?.Value));
            Assert.Equal("INT029ConcurFields", Value(document, "Provider_Reference"));
            Assert.Equal("true", Value(document, "Include_Employment_Information"));
        }

        /// <summary>
        /// Verifies that winter boundaries use Pacific standard time rather than a fixed summer offset
        /// </summary>
        [Fact]
        public void Given_WinterWindow_When_CreatingRequest_Should_ApplyPacificStandardTime()
        {
            var from = new DateTimeOffset(2026, 1, 15, 0, 0, 0, TimeSpan.Zero);
            var through = from.AddHours(1);

            var document = XDocument.Parse(CreateFactory().CreateEffectiveWorkerRequest(from, through, 1, 100));

            Assert.Equal("2026-01-14T16:00:00", Value(document, "Effective_From"));
            Assert.Equal("2026-01-14T17:00:00", Value(document, "Effective_Through"));
        }

        /// <summary>
        /// Verifies invalid integration windows are rejected before a SOAP document is created
        /// </summary>
        [Fact]
        public void Given_ReversedWindow_When_CreatingRequest_Should_RejectWindow()
        {
            Assert.Throws<ArgumentException>(() => CreateFactory().CreateEffectiveWorkerRequest(Through, From, 1, 100));
            Assert.Throws<ArgumentException>(() => CreateFactory().CreateUpdatedWorkerRequest(Through, From, 1, 100));
        }

        /// <summary>
        /// Verifies Workday paging values must be positive for every request shape
        /// </summary>
        [Theory]
        [InlineData(0, 100)]
        [InlineData(1, 0)]
        [InlineData(-1, 100)]
        [InlineData(1, -1)]
        public void Given_InvalidPaging_When_CreatingRequest_Should_RejectValues(int page, int pageSize)
        {
            Assert.ThrowsAny<ArgumentOutOfRangeException>(() => CreateFactory().CreateEffectiveWorkerRequest(From, Through, page, pageSize));
            Assert.ThrowsAny<ArgumentOutOfRangeException>(() => CreateFactory().CreateUpdatedWorkerRequest(From, Through, page, pageSize));
            Assert.ThrowsAny<ArgumentOutOfRangeException>(() => CreateFactory().CreateWorkerDetailRequest(["1001"], page, pageSize));
        }

        /// <summary>
        /// Verifies details cannot be requested without valid employee identifiers
        /// </summary>
        [Fact]
        public void Given_InvalidEmployeeIds_When_CreatingDetailRequest_Should_RejectValues()
        {
            Assert.Throws<ArgumentNullException>(() => CreateFactory().CreateWorkerDetailRequest(null!, 1, 100));
            Assert.Throws<ArgumentException>(() => CreateFactory().CreateWorkerDetailRequest([], 1, 100));
            Assert.Throws<ArgumentException>(() => CreateFactory().CreateWorkerDetailRequest(["1001", " "], 1, 100));
        }

        /// <summary>
        /// Verifies both Workday authentication values are required for every SOAP request
        /// </summary>
        [Theory]
        [InlineData("", IntegrationPassword)]
        [InlineData(IntegrationUsername, "")]
        [InlineData(" ", IntegrationPassword)]
        public void Given_MissingCredentials_When_CreatingRequest_Should_RejectConfiguration(string username, string password)
        {
            var factory = new WorkdaySoapRequestFactory(Options.Create(new WorkdayConcurOptions
            {
                WorkdayUsername = username,
                WorkdayPassword = password
            }));

            Assert.Throws<ArgumentException>(() => factory.CreateEffectiveWorkerRequest(From, Through, 1, 100));
            Assert.Throws<ArgumentException>(() => factory.CreateWorkerDetailRequest(["1001"], 1, 100));
        }

        private static WorkdaySoapRequestFactory CreateFactory()
        {
            return new WorkdaySoapRequestFactory(Options.Create(new WorkdayConcurOptions
            {
                WorkdayUsername = IntegrationUsername,
                WorkdayPassword = IntegrationPassword
            }));
        }

        private static void AssertMatchesFixture(XDocument actual, string fixtureName)
        {
            var expected = XDocument.Parse(WorkdayTestFixture.Read(fixtureName));
            Assert.True(XNode.DeepEquals(expected, actual), $"The generated request does not match {fixtureName}.");
        }

        private static void AssertCommonEnvelope(XDocument document)
        {
            XNamespace soap = "http://schemas.xmlsoap.org/soap/envelope/";
            XNamespace security = SecurityNamespace;
            var request = document.Descendants(WorkdayName("Get_Workers_Request")).Single();
            var securityHeader = document.Descendants(security + "Security").Single();
            var password = document.Descendants(security + "Password").Single();

            Assert.Equal("v40.0", request.Attribute(WorkdayName("version"))?.Value);
            Assert.Equal("1", securityHeader.Attribute(soap + "mustUnderstand")?.Value);
            Assert.Equal(IntegrationUsername, document.Descendants(security + "Username").Single().Value);
            Assert.Equal(IntegrationPassword, password.Value);
            Assert.Equal(
                "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText",
                password.Attribute("Type")?.Value);
            Assert.Empty(document.Descendants().Where(element => element.Name.LocalName is "Nonce" or "Created"));
        }

        private static XName WorkdayName(string localName)
        {
            return XName.Get(localName, WorkdayNamespace);
        }

        private static string Value(XContainer container, string localName)
        {
            return container.Descendants().First(element => element.Name.LocalName == localName).Value;
        }
    }
}
