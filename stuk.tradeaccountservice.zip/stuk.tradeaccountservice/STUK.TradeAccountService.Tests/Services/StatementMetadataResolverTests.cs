﻿using Microsoft.Extensions.Options;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Handlers;

namespace STUK.TradeAccountService.Tests.Services
{
    public class StatementMetadataResolverTests
    {
        private readonly Mock<IDbExecutor> _dbExecutorMock;
        private readonly Mock<IAppInsightsLoggerHelper> _loggerMock;
        private readonly Mock<IColumbusStatementDownloadService> _columbusMock;
        private readonly StatementMetadataResolver _resolver;

        public StatementMetadataResolverTests()
        {
            _dbExecutorMock = new Mock<IDbExecutor>();
            _loggerMock = new Mock<IAppInsightsLoggerHelper>();
            _columbusMock = new Mock<IColumbusStatementDownloadService>();

            var downloadSettings = new DownloadSettings
            {
                ["Statement"] = new DocumentTypeDownloadSettings
                {
                    ContainerName = "statementtest",
                    FilePrepareUrl = null
                }
            };

            var optionsMock = new Mock<IOptions<DownloadSettings>>();
            optionsMock.Setup(o => o.Value).Returns(downloadSettings);

            _resolver = new StatementMetadataResolver(
                _dbExecutorMock.Object,
                optionsMock.Object,
                _loggerMock.Object,
                _columbusMock.Object);
        }

        #region GetMetadata

        [Fact]
        public async Task GetMetadata_DbReturnsNull_ReturnsNull()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<StatementHeaderMetadata>(
                    StoredProcedures.GetStatementMetadataByHeaderId,
                    It.IsAny<object>()))
                .ReturnsAsync((StatementHeaderMetadata?)null);

            // Act
            var result = await _resolver.GetMetadataAsync(100L, null);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetMetadata_DbReturnsResult_ReturnsMappedBlobUri()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<StatementHeaderMetadata>(
                    StoredProcedures.GetStatementMetadataByHeaderId,
                    It.IsAny<object>()))
                .ReturnsAsync(new StatementHeaderMetadata
                {
                    BlobUri = "2026/05/acct-ACC001_2026-05_statement.pdf",
                    OriginalFileName = "acct-ACC001_2026-05_statement.pdf"
                });

            // Act
            var result = await _resolver.GetMetadataAsync(100L, null);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("2026/05/acct-ACC001_2026-05_statement.pdf", result.BlobUri);
        }

        [Fact]
        public async Task GetMetadata_DbReturnsResult_ReturnsMappedFileName()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<StatementHeaderMetadata>(
                    StoredProcedures.GetStatementMetadataByHeaderId,
                    It.IsAny<object>()))
                .ReturnsAsync(new StatementHeaderMetadata
                {
                    BlobUri = "2026/05/acct-ACC001_2026-05_statement.pdf",
                    CalculatedFileName = "acct-ACC001_2026-05_statement.pdf"
                });

            // Act
            var result = await _resolver.GetMetadataAsync(100L, null);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("acct-ACC001_2026-05_statement.pdf", result.FileName);
        }

        [Fact]
        public async Task GetMetadata_DbReturnsNull_LogsWarning()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<StatementHeaderMetadata>(
                    StoredProcedures.GetStatementMetadataByHeaderId,
                    It.IsAny<object>()))
                .ReturnsAsync((StatementHeaderMetadata?)null);

            // Act
            await _resolver.GetMetadataAsync(100L, null);

            // Assert
            _loggerMock.Verify(l =>
                    l.LogWarning(
                    It.Is<string>(s =>
                    s.Contains("metadata not found", StringComparison.OrdinalIgnoreCase)),
                    It.IsAny<string>(),
                    It.IsAny<string>()),
                Times.Once);
        }

        [Fact]
        public async Task GetMetadata_CallsCorrectStoredProcedure()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<StatementHeaderMetadata>(
                    StoredProcedures.GetStatementMetadataByHeaderId,
                    It.IsAny<object>()))
                .ReturnsAsync((StatementHeaderMetadata?)null);

            // Act
            await _resolver.GetMetadataAsync(100L, null);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<StatementHeaderMetadata>(
                    StoredProcedures.GetStatementMetadataByHeaderId,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task GetMetadata_DbReturnsResult_LogsInformation()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<StatementHeaderMetadata>(
                    StoredProcedures.GetStatementMetadataByHeaderId,
                    It.IsAny<object>()))
                .ReturnsAsync(new StatementHeaderMetadata
                {
                    BlobUri = "2026/05/statement.pdf",
                    OriginalFileName = "statement.pdf"
                });

            // Act
            await _resolver.GetMetadataAsync(100L, null);

            // Assert
            _loggerMock.Verify(l =>
                l.LogInformation(
                    It.Is<string>(s => s.Contains("GetMetadataAsync completed", StringComparison.OrdinalIgnoreCase)),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<Dictionary<string, string>>()),
                Times.Once);
        }

        #endregion

        #region RequestDocument

        [Fact]
        public async Task RequestDocument_CallsColumbusDownloadService()
        {
            // Act
            await _resolver.RequestDocumentAsync(100L, null);

            // Assert
            _columbusMock.Verify(c =>
                c.DownloadStatementByStatementHeaderIdAsync(100L),
                Times.Once);
        }

        #endregion

        #region GetCacheByIdentifier

        [Fact]
        public async Task GetCacheByIdentifier_CallsCorrectStoredProcedure()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            await _resolver.GetCacheByIdentifierAsync(100L, null);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task GetCacheByIdentifier_DbReturnsEntry_ReturnsCacheEntry()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = token,
                    Identifier = "100",
                    DocumentType = "Statement",
                    DownloadStatus = "Ready"
                });

            // Act
            var result = await _resolver.GetCacheByIdentifierAsync(100L, null);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(token, result.Token);
            Assert.Equal("100", result.Identifier);
        }

        [Fact]
        public async Task GetCacheByIdentifier_DbReturnsNull_ReturnsNull()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            var result = await _resolver.GetCacheByIdentifierAsync(100L, null);

            // Assert
            Assert.Null(result);
        }

        #endregion

        #region GetCacheByToken

        [Fact]
        public async Task GetCacheByToken_CallsCorrectStoredProcedure()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            await _resolver.GetCacheByTokenAsync(token);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()),
                Times.Once);
        }

        [Fact]
        public async Task GetCacheByToken_DbReturnsEntry_ReturnsCacheEntry()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync(new DocumentDownloadCacheEntry
                {
                    Token = token,
                    Identifier = "100",
                    DocumentType = "Statement",
                    DownloadStatus = "Ready"
                });

            // Act
            var result = await _resolver.GetCacheByTokenAsync(token);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(token, result.Token);
        }

        [Fact]
        public async Task GetCacheByToken_DbReturnsNull_ReturnsNull()
        {
            // Arrange
            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<DocumentDownloadCacheEntry>(
                    StoredProcedures.GetDocumentDownloadCacheDetails,
                    It.IsAny<object>()))
                .ReturnsAsync((DocumentDownloadCacheEntry?)null);

            // Act
            var result = await _resolver.GetCacheByTokenAsync(Guid.NewGuid());

            // Assert
            Assert.Null(result);
        }

        #endregion

        #region InsertCache

        [Fact]
        public async Task InsertCache_CallsCorrectStoredProcedure()
        {
            // Arrange
            var expectedToken = Guid.NewGuid();
            var expiresOn = DateTimeOffset.Now;
            var expando = (IDictionary<string, object?>)new System.Dynamic.ExpandoObject();
            expando["token"] = expectedToken;
            expando["expiresOn"] = expiresOn;

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<dynamic>(
                    StoredProcedures.InsertDocumentDownloadCache,
                    It.IsAny<object>()))
                .ReturnsAsync((object)expando);

            // Act
            await _resolver.InsertCacheAsync(100L, null, "Ready");

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<dynamic>(
                    StoredProcedures.InsertDocumentDownloadCache,
                    It.IsAny<object>()),
                Times.Once);
        }

        #endregion

        #region DeleteCacheByToken

        [Fact]
        public async Task DeleteCacheByToken_CallsCorrectStoredProcedure()
        {
            // Arrange
            var token = Guid.NewGuid();

            _dbExecutorMock
                .Setup(db => db.ExecuteSingleAsync<int>(
                    StoredProcedures.DeleteDocumentDownloadCacheByToken,
                    It.IsAny<object>()))
                .ReturnsAsync(1);

            // Act
            await _resolver.DeleteCacheByTokenAsync(token);

            // Assert
            _dbExecutorMock.Verify(db =>
                db.ExecuteSingleAsync<int>(
                    StoredProcedures.DeleteDocumentDownloadCacheByToken,
                    It.IsAny<object>()),
                Times.Once);
        }

        #endregion

        #region Properties

        [Fact]
        public void DocumentType_ReturnsStatement()
        {
            Assert.Equal("Statement", _resolver.DocumentType);
        }

        [Fact]
        public void DefaultFileName_ReturnsDefaultStatementPdf()
        {
            Assert.Equal("Statement.pdf", _resolver.DefaultFileName);
        }

        [Fact]
        public void ContainerName_ReturnsConfiguredContainerName()
        {
            Assert.Equal("statementtest", _resolver.ContainerName);
        }

        [Fact]
        public void ParseIdentifier_ReturnsLongValue()
        {
            var result = _resolver.ParseIdentifier("100");

            Assert.Equal(100L, result);
        }

        [Fact]
        public void ParseIdentifier_InvalidString_ThrowsFormatException()
        {
            Assert.Throws<FormatException>(() =>
                _resolver.ParseIdentifier("not-a-number"));
        }

        #endregion
    }
}
