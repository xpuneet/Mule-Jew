using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.Services
{
    public class SalesforceSyncDataServiceTests
    {
        private static readonly Guid WorkId = new("40000000-0000-0000-0000-000000000001");
        private static readonly Guid ClaimToken = new("40000000-0000-0000-0000-000000000002");
        private static readonly DateTimeOffset NextAttemptOn = new(2026, 8, 5, 10, 30, 0, TimeSpan.Zero);

        private readonly Mock<IDbExecutor> _dbExecutor = new();

        [Fact]
        public async Task Given_Salesforce_Work_When_Processing_The_Lifecycle_Should_Use_All_State_Procedures()
        {
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesforceWork>(StoredProcedures.ClaimNextConsolidatedSalesforceWork, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesforceWork());
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesLeaseResult>(StoredProcedures.RenewConsolidatedSalesforceWorkLease, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesLeaseResult());

            SetupWrite(StoredProcedures.CompleteConsolidatedSalesforceLine);
            SetupWrite(StoredProcedures.FailConsolidatedSalesforceLine);
            SetupWrite(StoredProcedures.CompleteConsolidatedSalesforceWork);

            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesWorkFailureResult>(StoredProcedures.FailConsolidatedSalesforceWork, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesWorkFailureResult());
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<ConsolidatedSalesforceAttemptResult>(StoredProcedures.InsertConsolidatedSalesforceAttempt, It.IsAny<object>())).ReturnsAsync(new ConsolidatedSalesforceAttemptResult());

            SetupWrite(StoredProcedures.RequeueConsolidatedSalesWork);

            var service = CreateService();

            await service.ClaimNextAsync("worker", 60, 3);
            await service.RenewLeaseAsync(WorkId, ClaimToken, 60);
            await service.CompleteLineAsync(WorkId, ClaimToken, "EXT-1", "PROD-1", "PRICE-1", "ITEM-1");
            await service.FailLineAsync(WorkId, ClaimToken, "EXT-2", "Failure");
            await service.CompleteWorkAsync(WorkId, ClaimToken, "ORDER-1", 2);
            await service.FailWorkAsync(WorkId, ClaimToken, "Transient", "Failure", NextAttemptOn, 3);
            await service.InsertAttemptAsync(new ConsolidatedSalesforceAttempt());
            await service.RequeueAsync(WorkId, "Approved replay");

            _dbExecutor.VerifyAll();
        }

        [Fact]
        public async Task Given_Camel_Case_Work_Json_When_Getting_Details_Should_Return_Canonical_And_Salesforce_State()
        {
            const string json = """
                {"salesforceWorkId":"00000000-0000-0000-0000-000000000001","consolidatedInvoiceId":"00000000-0000-0000-0000-000000000002","invoice":{"consolidatedInvoiceNumber":"CON-100","expectedLineCount":1,"parties":[],"components":[],"lines":[{"lineIdentity":"LINE-1"}],"taxSubTotals":[]},"lines":[{"salesforceExternalId":"EXT-1","salesforceLineStatus":"Pending"}]}
                """;

            _dbExecutor.Setup(x => x.ExecuteSingleAsync<string>(StoredProcedures.GetConsolidatedSalesforceWorkDetails, It.IsAny<object>())).ReturnsAsync(json);

            var result = await CreateService().GetDetailsAsync(WorkId, ClaimToken);

            Assert.NotNull(result);
            Assert.Equal("CON-100", result.Invoice.ConsolidatedInvoiceNumber);
            Assert.Single(result.Invoice.Lines);
            Assert.Single(result.Lines);
            Assert.Equal("Pending", result.Lines[0].SalesforceLineStatus);
        }

        [Fact]
        public async Task Given_No_Work_Json_When_Getting_Details_Should_Return_Null()
        {
            _dbExecutor.Setup(x => x.ExecuteSingleAsync<string>(StoredProcedures.GetConsolidatedSalesforceWorkDetails, It.IsAny<object>())).ReturnsAsync((string?)null);

            var result = await CreateService().GetDetailsAsync(WorkId, ClaimToken);

            Assert.Null(result);
        }

        [Fact]
        public async Task Given_A_Cancelled_Token_When_Claiming_Should_Not_Call_The_Database()
        {
            var token = new CancellationToken(true);

            await Assert.ThrowsAsync<OperationCanceledException>(() => CreateService().ClaimNextAsync("worker", 60, 3, cancellationToken: token));

            _dbExecutor.VerifyNoOtherCalls();
        }

        private SalesforceSyncDataService CreateService() => new(_dbExecutor.Object);

        private void SetupWrite(string storedProcedure)
        {
            _dbExecutor.Setup(x => x.ExecuteAsync(storedProcedure, It.IsAny<object>())).ReturnsAsync(1);
        }
    }
}
