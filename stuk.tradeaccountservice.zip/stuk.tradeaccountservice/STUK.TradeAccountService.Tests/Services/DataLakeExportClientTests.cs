using Azure;
using Azure.Storage.Files.DataLake;
using Azure.Storage.Files.DataLake.Models;
using Moq;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Services;
using System.Text;

namespace STUK.TradeAccountService.Tests.Services
{
    /// <summary>
    /// Tests direct ADLS Gen2 dataset and completion-token sequencing
    /// </summary>
    public class DataLakeExportClientTests
    {
        [Fact]
        public async Task Given_NewDataset_When_Writing_Should_PublishTokenOnlyAfterDatasetCompletes()
        {
            var serviceClient = new Mock<DataLakeServiceClient>();
            var fileSystem = new Mock<DataLakeFileSystemClient>();
            var dataset = new Mock<DataLakeFileClient>();
            var token = new Mock<DataLakeFileClient>();
            var sequence = new MockSequence();
            var content = Encoding.UTF8.GetBytes("dataset");
            var tokenContent = Encoding.UTF8.GetBytes("token");
            serviceClient.Setup(client => client.GetFileSystemClient("adls-test")).Returns(fileSystem.Object);

            fileSystem
                .Setup(client => client.GetFileClient("data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv"))
                .Returns(dataset.Object);

            fileSystem
                .Setup(client => client.GetFileClient("operational/token/DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token.Object);

            dataset.InSequence(sequence)
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            dataset.InSequence(sequence)
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((Response<PathInfo>)null!);

            token.InSequence(sequence)
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            token.InSequence(sequence)
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((Response<PathInfo>)null!);

            await using var stream = new MemoryStream(content, writable: false);

            var result = await new DataLakeExportClient(() => serviceClient.Object).WriteAsync(CreateRequest(content.LongLength, tokenContent), stream);

            Assert.Equal("adls-test/data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv", result.DatasetPath);
            Assert.Equal("adls-test/operational/token/DL_F5_ECS_CONSXREF_DATA", result.TokenPath);
            Assert.False(result.DatasetAlreadyExists);

            dataset.VerifyAll();

            token.VerifyAll();
        }

        [Fact]
        public async Task Given_SameDatasetAndToken_When_Retrying_Should_NotRepublishEitherFile()
        {
            var serviceClient = new Mock<DataLakeServiceClient>();
            var fileSystem = new Mock<DataLakeFileSystemClient>();
            var dataset = new Mock<DataLakeFileClient>();
            var token = new Mock<DataLakeFileClient>();
            var content = Encoding.UTF8.GetBytes("dataset");
            var tokenContent = Encoding.UTF8.GetBytes("token");
            var request = CreateRequest(content.LongLength, tokenContent);

            var metadata = new Dictionary<string, string>
            {
                ["ExportRunID"] = request.ExportRunId.ToString("D"),
                ["ExportDestinationID"] = request.ExportDestinationId.ToString("D"),
                ["ContentHash"] = request.ContentHash
            };

            var datasetProperties = CreateProperties(metadata, content.LongLength);
            var tokenProperties = CreateProperties(metadata, tokenContent.LongLength);

            serviceClient.Setup(client => client.GetFileSystemClient("adls-test")).Returns(fileSystem.Object);

            fileSystem
                .Setup(client => client.GetFileClient("data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv"))
                .Returns(dataset.Object);

            fileSystem
                .Setup(client => client.GetFileClient("operational/token/DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token.Object);

            dataset
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(datasetProperties, Mock.Of<Response>()));

            token
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(tokenProperties, Mock.Of<Response>()));

            await using var stream = new MemoryStream(content, writable: false);

            var result = await new DataLakeExportClient(() => serviceClient.Object).WriteAsync(request, stream);

            Assert.True(result.DatasetAlreadyExists);

            dataset.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()), Times.Never);

            token.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [Fact]
        public async Task Given_DatasetUploadFailure_When_Writing_Should_NotPublishCompletionToken()
        {
            var serviceClient = new Mock<DataLakeServiceClient>();
            var fileSystem = new Mock<DataLakeFileSystemClient>();
            var dataset = new Mock<DataLakeFileClient>();
            var token = new Mock<DataLakeFileClient>();
            var content = Encoding.UTF8.GetBytes("dataset");
            var tokenContent = Encoding.UTF8.GetBytes("token");
            serviceClient.Setup(client => client.GetFileSystemClient("adls-test")).Returns(fileSystem.Object);
            fileSystem
                .Setup(client => client.GetFileClient("data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv"))
                .Returns(dataset.Object);
            fileSystem
                .Setup(client => client.GetFileClient("operational/token/DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token.Object);
            dataset
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));
            dataset
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(503, "Data Lake unavailable"));
            await using var stream = new MemoryStream(content, writable: false);

            await Assert.ThrowsAsync<RequestFailedException>(() =>
                new DataLakeExportClient(() => serviceClient.Object).WriteAsync(CreateRequest(content.LongLength, tokenContent), stream));

            token.Verify(
                client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()),
                Times.Never);
            token.Verify(
                client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()),
                Times.Never);
        }

        [Fact]
        public async Task Given_ExistingDatasetWithDifferentEvidence_When_Retrying_Should_RejectWithoutPublishingToken()
        {
            var serviceClient = new Mock<DataLakeServiceClient>();
            var fileSystem = new Mock<DataLakeFileSystemClient>();
            var dataset = new Mock<DataLakeFileClient>();
            var token = new Mock<DataLakeFileClient>();
            var content = Encoding.UTF8.GetBytes("dataset");
            var tokenContent = Encoding.UTF8.GetBytes("token");
            var request = CreateRequest(content.LongLength, tokenContent);
            var mismatchedProperties = CreateProperties(
                new Dictionary<string, string>
                {
                    ["ExportRunID"] = Guid.NewGuid().ToString("D"),
                    ["ExportDestinationID"] = request.ExportDestinationId.ToString("D"),
                    ["ContentHash"] = request.ContentHash
                },
                content.LongLength);
            serviceClient.Setup(client => client.GetFileSystemClient("adls-test")).Returns(fileSystem.Object);
            fileSystem
                .Setup(client => client.GetFileClient("data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv"))
                .Returns(dataset.Object);
            fileSystem
                .Setup(client => client.GetFileClient("operational/token/DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token.Object);
            dataset
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(mismatchedProperties, Mock.Of<Response>()));
            await using var stream = new MemoryStream(content, writable: false);

            var exception = await Assert.ThrowsAsync<InvalidDataException>(() =>
                new DataLakeExportClient(() => serviceClient.Object).WriteAsync(request, stream));

            Assert.Contains("occupied by different export content", exception.Message);
            token.VerifyNoOtherCalls();
        }

        [Fact]
        public async Task Given_Token_Upload_Fails_After_Dataset_Succeeds_When_Retrying_Should_Reuse_Dataset_And_Retry_Only_The_Token()
        {
            var serviceClient = new Mock<DataLakeServiceClient>();
            var fileSystem = new Mock<DataLakeFileSystemClient>();
            var dataset = new Mock<DataLakeFileClient>();
            var token = new Mock<DataLakeFileClient>();
            var content = Encoding.UTF8.GetBytes("dataset");
            var tokenContent = Encoding.UTF8.GetBytes("token");
            var request = CreateRequest(content.LongLength, tokenContent);
            var datasetProperties = CreateProperties(CreateMetadata(request), content.LongLength);
            serviceClient.Setup(client => client.GetFileSystemClient("adls-test")).Returns(fileSystem.Object);

            fileSystem
                .Setup(client => client.GetFileClient("data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv"))
                .Returns(dataset.Object);

            fileSystem
                .Setup(client => client.GetFileClient("operational/token/DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token.Object);

            dataset
                .SetupSequence(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"))
                .ReturnsAsync(Response.FromValue(datasetProperties, Mock.Of<Response>()));

            dataset
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((Response<PathInfo>)null!);

            token
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            token
                .SetupSequence(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(503, "Token endpoint unavailable"))
                .ReturnsAsync((Response<PathInfo>)null!);
            await using var firstStream = new MemoryStream(content, writable: false);

            await Assert.ThrowsAsync<RequestFailedException>(() => new DataLakeExportClient(() => serviceClient.Object).WriteAsync(request, firstStream));

            await using var retryStream = new MemoryStream(content, writable: false);

            var result = await new DataLakeExportClient(() => serviceClient.Object).WriteAsync(request, retryStream);

            Assert.True(result.DatasetAlreadyExists);
            dataset.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()), Times.Once);
            token.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()), Times.Exactly(2));
        }

        [Fact]
        public async Task Given_The_Fixed_Token_Belongs_To_An_Older_Run_When_Writing_Should_Replace_It_With_Current_Evidence()
        {
            var serviceClient = new Mock<DataLakeServiceClient>();
            var fileSystem = new Mock<DataLakeFileSystemClient>();
            var dataset = new Mock<DataLakeFileClient>();
            var token = new Mock<DataLakeFileClient>();
            var content = Encoding.UTF8.GetBytes("dataset");
            var tokenContent = Encoding.UTF8.GetBytes("token");
            var request = CreateRequest(content.LongLength, tokenContent);
            var datasetProperties = CreateProperties(CreateMetadata(request), content.LongLength);
            var oldTokenMetadata = CreateMetadata(request);
            oldTokenMetadata["ExportRunID"] = Guid.NewGuid().ToString("D");
            var oldTokenProperties = CreateProperties(oldTokenMetadata, tokenContent.LongLength);
            serviceClient.Setup(client => client.GetFileSystemClient("adls-test")).Returns(fileSystem.Object);

            fileSystem
                .Setup(client => client.GetFileClient("data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv"))
                .Returns(dataset.Object);

            fileSystem
                .Setup(client => client.GetFileClient("operational/token/DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token.Object);

            dataset
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(datasetProperties, Mock.Of<Response>()));

            token
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(oldTokenProperties, Mock.Of<Response>()));

            token
                .Setup(client => client.UploadAsync(
                    It.IsAny<Stream>(),
                    It.Is<DataLakeFileUploadOptions>(options =>
                        options.Metadata["ExportRunID"] == request.ExportRunId.ToString("D")
                        && options.Metadata["ExportDestinationID"] == request.ExportDestinationId.ToString("D")),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync((Response<PathInfo>)null!);
            await using var stream = new MemoryStream(content, writable: false);

            await new DataLakeExportClient(() => serviceClient.Object).WriteAsync(request, stream);

            token.VerifyAll();
        }

        [Fact]
        public async Task Given_Another_Worker_Wins_The_Dataset_Create_Race_When_Its_Evidence_Matches_Should_Continue_To_The_Token()
        {
            var serviceClient = new Mock<DataLakeServiceClient>();
            var fileSystem = new Mock<DataLakeFileSystemClient>();
            var dataset = new Mock<DataLakeFileClient>();
            var token = new Mock<DataLakeFileClient>();
            var content = Encoding.UTF8.GetBytes("dataset");
            var tokenContent = Encoding.UTF8.GetBytes("token");
            var request = CreateRequest(content.LongLength, tokenContent);
            var datasetProperties = CreateProperties(CreateMetadata(request), content.LongLength);
            serviceClient.Setup(client => client.GetFileSystemClient("adls-test")).Returns(fileSystem.Object);

            fileSystem
                .Setup(client => client.GetFileClient("data/reception/ecs_conxref/2026_ConsXref20260810_003025.csv"))
                .Returns(dataset.Object);

            fileSystem
                .Setup(client => client.GetFileClient("operational/token/DL_F5_ECS_CONSXREF_DATA"))
                .Returns(token.Object);

            dataset
                .SetupSequence(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"))
                .ReturnsAsync(Response.FromValue(datasetProperties, Mock.Of<Response>()));

            dataset
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(412, "Already created"));

            token
                .Setup(client => client.GetPropertiesAsync(It.IsAny<DataLakeRequestConditions>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RequestFailedException(404, "Not found"));

            token
                .Setup(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((Response<PathInfo>)null!);

            await using var stream = new MemoryStream(content, writable: false);

            var result = await new DataLakeExportClient(() => serviceClient.Object).WriteAsync(request, stream);

            Assert.True(result.DatasetAlreadyExists);
            dataset.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()), Times.Once);
            token.Verify(client => client.UploadAsync(It.IsAny<Stream>(), It.IsAny<DataLakeFileUploadOptions>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        private static DataLakeExportWriteRequest CreateRequest(long contentLength, byte[] tokenContent)
        {
            return new DataLakeExportWriteRequest
            {
                FileSystem = "adls-test",
                DatasetDirectory = "data/reception/ecs_conxref",
                DatasetFileName = "2026_ConsXref20260810_003025.csv",
                TokenDirectory = "operational/token",
                TokenFileName = "DL_F5_ECS_CONSXREF_DATA",
                TokenContent = tokenContent,
                ContentLength = contentLength,
                RowCount = 2,
                ContentHash = "content-hash",
                ExportRunId = Guid.NewGuid(),
                ExportDestinationId = Guid.NewGuid(),
                CorrelationId = Guid.NewGuid()
            };
        }

        private static Dictionary<string, string> CreateMetadata(DataLakeExportWriteRequest request)
        {
            return new Dictionary<string, string>
            {
                ["ExportRunID"] = request.ExportRunId.ToString("D"),
                ["ExportDestinationID"] = request.ExportDestinationId.ToString("D"),
                ["ContentHash"] = request.ContentHash
            };
        }

        private static PathProperties CreateProperties(IDictionary<string, string> metadata, long contentLength)
        {
            return DataLakeModelFactory.PathProperties(
                default,
                default,
                metadata,
                default,
                null!,
                null!,
                null!,
                null!,
                default,
                false,
                default,
                default,
                default,
                contentLength,
                null!,
                default,
                null!,
                null!,
                null!,
                null!,
                null!,
                null!,
                false,
                null!,
                null!,
                null!,
                default,
                false);
        }
    }
}
