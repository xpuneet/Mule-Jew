using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using STUK.APIs.Common.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.DependencyInjection;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountService.Tests.DependencyInjection
{
    /// <summary>
    /// Tests Workday-to-Concur dependency-injection registration
    /// </summary>
    public class WorkdayConcurRegistrationTests
    {
        /// <summary>
        /// Verifies that the orchestration service is resolved through its interface
        /// </summary>
        [Fact]
        public void Given_FeatureRegistration_When_ServiceResolved_Should_UseOrchestrationImplementation()
        {
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["WorkdayConcur:WorkdayEndpoint"] = "https://workday.example.test/",
                    ["WorkdayConcur:WorkdayRequestTimeoutSeconds"] = "60"
                })
                .Build();
            var services = new ServiceCollection();
            services.AddLogging();
            services.AddKeyedSingleton("AccountDb", Mock.Of<IDbExecutor>());
            services.AddKeyedSingleton("FileTransferDb", Mock.Of<IDbExecutor>());
            services.AddWorkdayConcur(configuration);

            using var serviceProvider = services.BuildServiceProvider();
            using var scope = serviceProvider.CreateScope();

            var service = scope.ServiceProvider.GetRequiredService<IWorkdayConcurOrchestrationService>();
            var stateService = scope.ServiceProvider.GetRequiredService<IWorkdayConcurStateService>();
            var tm1Service = scope.ServiceProvider.GetRequiredService<IWorkdayConcurTm1Service>();
            var fileTransferService = scope.ServiceProvider.GetRequiredService<IFileTransferConfigurationService>();
            var synapseClient = scope.ServiceProvider.GetRequiredService<ISynapsePipelineClient>();
            var concurSynapseClient = scope.ServiceProvider.GetRequiredService<IConcurSynapsePipelineClient>();
            var blobClient = scope.ServiceProvider.GetRequiredService<IWorkdayConcurBlobClient>();
            var blobClientFactory = scope.ServiceProvider.GetRequiredService<IWorkdayConcurBlobServiceClientFactory>();
            var workdayClient = scope.ServiceProvider.GetRequiredService<IWorkdayWorkersClient>();
            var workdayRequestFactory = scope.ServiceProvider.GetRequiredService<IWorkdaySoapRequestFactory>();
            var workdayParser = scope.ServiceProvider.GetRequiredService<IWorkdayWorkerResponseParser>();
            var csvService = scope.ServiceProvider.GetRequiredService<IWorkdayConcurCsvService>();
            var transformationService = scope.ServiceProvider.GetRequiredService<IWorkdayConcurTransformationService>();
            var pgpEncryptionService = scope.ServiceProvider.GetRequiredService<IConcurPgpEncryptionService>();
            var deliveryService = scope.ServiceProvider.GetRequiredService<IWorkdayConcurDeliveryService>();
            var housekeepingService = scope.ServiceProvider.GetRequiredService<IWorkdayConcurHousekeepingService>();
            var timeProvider = scope.ServiceProvider.GetRequiredService<TimeProvider>();

            Assert.IsType<WorkdayConcurOrchestrationService>(service);
            Assert.IsType<WorkdayConcurStateService>(stateService);
            Assert.IsType<WorkdayConcurTm1Service>(tm1Service);
            Assert.IsType<FileTransferConfigurationService>(fileTransferService);
            Assert.IsType<SynapsePipelineClient>(synapseClient);
            Assert.IsType<SynapsePipelineClient>(concurSynapseClient);
            Assert.IsType<WorkdayConcurBlobClient>(blobClient);
            Assert.IsType<WorkdayConcurBlobServiceClientFactory>(blobClientFactory);
            Assert.IsType<WorkdayWorkersClient>(workdayClient);
            Assert.IsType<WorkdaySoapRequestFactory>(workdayRequestFactory);
            Assert.IsType<WorkdayWorkerResponseParser>(workdayParser);
            Assert.IsType<WorkdayConcurCsvService>(csvService);
            Assert.IsType<WorkdayConcurTransformationService>(transformationService);
            Assert.IsType<ConcurPgpEncryptionService>(pgpEncryptionService);
            Assert.IsType<WorkdayConcurDeliveryService>(deliveryService);
            Assert.IsType<WorkdayConcurHousekeepingService>(housekeepingService);
            Assert.Same(TimeProvider.System, timeProvider);
        }
    }
}
