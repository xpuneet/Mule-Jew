using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using STUK.APIs.Common.Filters;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Models;
using STUK.APIs.Common.ViewTemplate;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.WebApi.RequestParams;
using STUK.TradeAccountService.WebApi.RouteParams;
using System.Diagnostics;

namespace STUK.TradeAccountService.WebApi.Controllers.V1
{
    [Route("api/v1")]
    [ApiController]
    public class AccountsController(ITradeAccountsService accountService,
        ITradeAccountInvoicesService invoicesService,
        IStatementService statementService,
        IPreferredBranchService preferredBranchService,
        IAppInsightsLoggerHelper appInsightsLoggerHelper) : BaseApiController
    {
        private readonly ITradeAccountsService _accountService = accountService ?? throw new ArgumentNullException(nameof(accountService));
        private readonly ITradeAccountInvoicesService _invoicesService = invoicesService ?? throw new ArgumentNullException(nameof(invoicesService));
        private readonly IStatementService _statementService = statementService ?? throw new ArgumentNullException(nameof(statementService));
        private readonly IPreferredBranchService _preferredBranchService = preferredBranchService ?? throw new ArgumentNullException(nameof(preferredBranchService));
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper = appInsightsLoggerHelper ?? throw new ArgumentNullException(nameof(appInsightsLoggerHelper));

        #region CLIENT_ENDPOINT
        [UserAccountAuthorize]
        [ProducesResponseType(typeof(AccountResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/{accountCode:regex(^\\S+$)}")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> GetAccount(AccountCodeRouteParams routeParams, CancellationToken cancellationToken)
             => await GetAccountHandler(routeParams.AccountCode, cancellationToken);

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(AccountSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> SearchAccount([FromHeader(Name = "X-Session-Id")] string sessionId, AccountSearchQueryParams request, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            return Ok(await _accountService.SearchAccountBySessionAsync(sessionId, request.PageNumber, request.PageSize, cancellationToken));
        }

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(CreditLimitResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(NotFoundResponse), StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/{accountCode:regex(^\\S+$)}/creditlimit")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> CreditLimit(AccountCodeRouteParams routeParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _accountService.GetCreditLimitByAccountCodeAsync(routeParams.AccountCode, cancellationToken);
            return (result is null || !string.IsNullOrEmpty(result.ErrorCode)) ? CustomNotFound("CREDITINFO_NOT_FOUND", result?.ErrorCode ?? "AccountCode not found")
                : Ok(result);
        }

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(NotFoundResponse), StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/{accountCode:regex(^\\S+$)}/overview")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> Overview(AccountCodeRouteParams routeParams, AccountOverviewQueryParams queryParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            _appInsightsLoggerHelper.LogInformation($"Account overview started at {DateTime.Now} with accountId {routeParams.AccountCode}.");
            var account = await _accountService.GetAccountByAccountCodeAsync(routeParams.AccountCode, cancellationToken);
            if (account == null || account?.Account == null)
            {
                return CustomNotFound("ACCOUNT_NOT_FOUND", $"No account found for '{routeParams.AccountCode}'");
            }
            
            var balancetask = _accountService.GetCreditLimitByAccountCodeAsync(routeParams.AccountCode, cancellationToken);
            
            var invoiceReq = new InvoiceFilterRequest(CustomerAccount:routeParams.AccountCode, SortBy: "issueDate", SortOrder:"desc", PageNumber:1, PageSize: queryParams.RecentInvoicesLimit );
            var invoiceTask = _invoicesService.FilterInvoiceDocumentsAsync(invoiceReq, 'S', cancellationToken);
            
            var cNoteeReq = new InvoiceFilterRequest(CustomerAccount: routeParams.AccountCode, SortBy: "issueDate", SortOrder: "desc", PageNumber: 1, PageSize: queryParams.RecentCreditNotesLimit);
            var creditNotesTask = _invoicesService.FilterInvoiceDocumentsAsync(cNoteeReq, 'C', cancellationToken);
            
            var statementReq = new StatementSearchRequest( AccountCode: routeParams.AccountCode, PageNumber: 1, PageSize: queryParams.RecentStatementsLimit );
            var statementsTask = _statementService.SearchStatementsAsync(statementReq, cancellationToken);

            var branchTask = _preferredBranchService.GetPreferredBranchAsync(routeParams.AccountCode, cancellationToken);

            await Task.WhenAll(balancetask, invoiceTask, creditNotesTask, statementsTask, branchTask);

            var balance = await balancetask;
            var recentInvoices = await invoiceTask as InvoiceSearchResponse;
            var recentCreditNotes = await creditNotesTask as CreditNoteSearchResponse;
            var recentStatements = await statementsTask;
            var branch = await branchTask;
            _appInsightsLoggerHelper.LogInformation($"Account overview completed all tasks at {DateTime.Now} with accountId {routeParams.AccountCode}.");
            return Ok(new { account, balance, recentInvoices, recentCreditNotes, recentStatements, branch });
        }
        #endregion

        #region SERVER_ENDPOINT
        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(AccountResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("accounts/{accountCode:regex(^\\S+$)}")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> GetAccount_Server(AccountCodeRouteParams routeParams, CancellationToken cancellationToken)
            => await GetAccountHandler(routeParams.AccountCode, cancellationToken);

        #region Backward Compatibility
        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(AccountValidateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(NotFoundResponse), StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet("accounts/validate")]       
        public async Task<IActionResult> ValidateAccount(AccountValidateQueryParams request, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var validteInfo = await _accountService.ValidateAccountAsync(request.AccountCode, request.PostCode, request.Brand, cancellationToken);
            return validteInfo is null ? CustomNotFound("ACCOUNT_NOT_FOUND", $"No account found to validate for '{request.AccountCode}'")
                : Ok(validteInfo);
        }

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(CreditLimitResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(NotFoundResponse), StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet("accounts/creditlimit/{accountCode:regex(^\\S+$)}")]
        public async Task<IActionResult> CreditLimit_Server(AccountCodeRouteParams routeParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _accountService.GetCreditLimitByAccountCodeAsync(routeParams.AccountCode, cancellationToken);
            return result is null ? CustomNotFound("CREDITINFO_NOT_FOUND", result?.ErrorCode ?? $"No account found for '{routeParams.AccountCode}'")
                : Ok(new { result.Account, result.CreditLimit, result.ErrorCode });
        }
        #endregion
        #endregion

        private async Task<IActionResult> GetAccountHandler(string accountCode, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _accountService.GetAccountByAccountCodeAsync(accountCode, cancellationToken);
            return (result == null || result?.Account == null) ? CustomNotFound("ACCOUNT_NOT_FOUND", $"No account found for '{accountCode}'"):
                Ok(result);
        }
    }
}
