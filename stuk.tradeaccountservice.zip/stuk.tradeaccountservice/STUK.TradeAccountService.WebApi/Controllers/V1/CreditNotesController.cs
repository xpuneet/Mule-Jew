﻿using Microsoft.AspNetCore.Mvc;
using STUK.APIs.Common.Filters;
using STUK.APIs.Common.Models;
using STUK.APIs.Common.ViewTemplate;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.WebApi.RequestParams;
using STUK.TradeAccountService.WebApi.RouteParams;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace STUK.TradeAccountService.WebApi.Controllers.V1
{
    [Route("api/v1")]
    [ApiController]
    public class CreditNotesController(ITradeAccountInvoicesService invoicesService, IInvoiceDownloadService downloadService) : ControllerBase
    {
        private readonly ITradeAccountInvoicesService _invoicesService = invoicesService ?? throw new ArgumentNullException(nameof(invoicesService));
        private readonly IInvoiceDownloadService _downloadService = downloadService ?? throw new ArgumentNullException(nameof(downloadService));

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(InvoiceSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/documents/{accountCode:regex(^\\S+$)}/credit-notes/filter")]
        public async Task<IActionResult> GetCreditNotes(AccountCodeRouteParams routeParams, InvoiceFilterQueryParams queryParams,
            CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);

            var cNoteRequest = new InvoiceFilterRequest(routeParams.AccountCode, queryParams.SortBy, queryParams.SortOrder, queryParams.PageNumber,
                queryParams.PageSize, queryParams.BranchCode, queryParams.Brand, queryParams.InvoiceDateFrom, queryParams.InvoiceDateTo,
                queryParams.OrderBranchCode, queryParams.OrderNo, queryParams.OrderCreatedDateFrom, queryParams.OrderCreatedDateTo, queryParams.OrderReference,
                queryParams.ItemCode);

            var result = await _invoicesService.FilterInvoiceDocumentsAsync(cNoteRequest, 'C', cancellationToken) as CreditNoteSearchResponse;
            return Ok(result);
        }

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(InvoiceSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/documents/{accountCode:regex(^\\S+$)}/credit-notes")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> SearchCreditNotes(AccountCodeRouteParams routeParams, InvoiceSearchFilterQueryParams queryParams,
            CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);

            var cNoteRequest = new InvoiceSearchFilterRequest(routeParams.AccountCode, queryParams.SortBy, queryParams.SortOrder, queryParams.PageNumber,
                queryParams.PageSize, queryParams.Status, queryParams.SearchParam);

            var result = await _invoicesService.SearchInvoiceByFilterParamAsync(cNoteRequest, 'C', cancellationToken) as CreditNoteSearchResponse;
            return Ok(result);
        }

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(DocumentDownloadRequestResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("capp/accounts/documents/credit-notes/{branchCode:regex(^\\S+$)}/{creditNoteId:regex(^\\S+$)}/download-request")]
        public async Task<IActionResult> RequestCreditNoteDownload(CreditNoteRouteParams routeParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            return Ok(await _downloadService.RequestDownloadAsync(routeParams.CreditNoteId, routeParams.BranchCode, cancellationToken));
        }

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(byte[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(DocumentDownloadResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [HttpGet("capp/accounts/documents/credit-notes/download/{token:regex(^\\S+$)}")]
        public async Task<IActionResult> DownloadCreditNote(
        [FromRoute]
        [Required(ErrorMessage = "Token is required")] Guid token,
        CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _downloadService.DownloadAsync(token, cancellationToken);

            if (result.FileContent != null)
                return File(result.FileContent, result.ContentType!, result.FileName, enableRangeProcessing: true);

            return Ok(new { message = result.Message });
        }
    }
}
