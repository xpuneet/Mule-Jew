using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using STUK.APIs.Common.Exceptions;
using STUK.APIs.Common.Filters;
using STUK.APIs.Common.Models;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace STUK.TradeAccountService.WebApi.Controllers.V1
{
    [Route("api/v1")]
    [ApiController]
    public class PaymentsController(ITradeAccountPaymentService paymentService) : BaseApiController
    {
        private readonly ITradeAccountPaymentService _paymentService = paymentService ?? throw new ArgumentNullException(nameof(paymentService));

        #region CLIENT_ENDPOINT
        [UserAccountAuthorize]
        [ProducesResponseType(typeof(PaymentResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/payments/{paymentReference:regex(^\\S+$)}")]
        public async Task<IActionResult> GetPayment(
        [FromRoute]
        [Required(ErrorMessage = "PaymentReference is required")] Guid paymentReference, CancellationToken cancellationToken)
            => await GetPaymentHandler(paymentReference, cancellationToken);

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("capp/accounts/payments")]
        public async Task<IActionResult> CreatePayment(CreatePaymentRequest request)
            => await CreatePaymentHandler(request);
        #endregion

        #region SERVER_ENDPOINT
        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(PaymentResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("accounts/payments/{paymentReference:regex(^\\S+$)}")]
        public async Task<IActionResult> GetPayment_Server(
        [FromRoute]
        [Required(ErrorMessage = "PaymentReference is required")] Guid paymentReference, CancellationToken cancellationToken)
            => await GetPaymentHandler(paymentReference, cancellationToken);

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("accounts/payments")]       
        public async Task<IActionResult> CreatePayment_Server(CreatePaymentRequest request)
            => await CreatePaymentHandler(request);

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("accounts-payments")]        
        public async Task<IActionResult> CreatePayment_Server_SAPCC(CreatePaymentRequestSAPCC request)
                => await CreatePaymentHandler_SAPCC(request);
        #endregion

        private async Task<IActionResult> GetPaymentHandler(Guid paymentReference, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var paymentDetail = await _paymentService.GetPayementReferenceByRefCodeAsync(paymentReference, cancellationToken);
            return paymentDetail is null ? CustomNotFound("PAYMENTREFERENCE_NOT_FOUND", $"No payment reference found for '{paymentReference}'.") 
                : Ok(new PaymentResponse { Payment = paymentDetail });
        }
        private async Task<IActionResult> CreatePaymentHandler(CreatePaymentRequest request)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var response = await _paymentService.CreatePayementreferenceAsync(request, CancellationToken.None);
            return response!.Success ? Ok(new { reference = response.ApiPaymentReference, success = response.Success, message = response.Message })
                : CustomBadRequest("FAILED_PAYMENT_CREATION", response.Message);
        }
        private async Task<IActionResult> CreatePaymentHandler_SAPCC(CreatePaymentRequestSAPCC request)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);

            var errors = new List<ApiError>();

            // Validate mandatory fields
            if (string.IsNullOrWhiteSpace(request.account))
            {
                errors.Add(new ApiError { code = "MISSING_MANDATORY_FIELD", message = "Account code is required." });
            }

            if (string.IsNullOrWhiteSpace(request.branch))
            {
                errors.Add(new ApiError { code = "MISSING_MANDATORY_FIELD", message = "Branch ID is required." });
            }

            if (request.payments?.payment == null || !request.payments.payment.Any())
            {
                errors.Add(new ApiError { code = "MISSING_MANDATORY_FIELD", message = "At least one payment is required." });
            }
            else
            {
                // Validate each payment
                for (int i = 0; i < request.payments.payment.Count; i++)
                {
                    var paymentDetail = request.payments.payment[i];

                    if (paymentDetail.value <= 0)
                    {
                        errors.Add(new ApiError { code = "INVALID_PAYMENT_AMOUNT", message = $"Payment at index {i} has invalid amount. Amount must be greater than 0." });
                    }

                    if (string.IsNullOrWhiteSpace(paymentDetail.reference))
                    {
                        errors.Add(new ApiError { code = "MISSING_PAYMENT_REFERENCE", message = $"Payment at index {i} is missing reference." });
                    }
                }
            }

            // If any validation errors, return all at once
            if (errors.Any())
            {
                return BadRequest(new ApiErrorResponse
                {
                    success = false,
                    trackingId = Activity.Current?.TraceId.ToString()!,
                    errors = errors
                });
            }

            // Process payments
            var apiPaymentReferences = new List<Guid>();

            foreach (var paymentDetail in request.payments!.payment)
            {
                var singlePaymentRequest = new CreatePaymentRequest
                {
                    AccountCode = request.account,
                    BranchId = request.branch,
                    Source = "SAPCC",
                    Description = paymentDetail.reference,
                    PaymentType = 'I',
                    PaymentAmount = paymentDetail.value,
                    CustomerPaymentReference = paymentDetail.reference
                };

                var response = await _paymentService.CreatePayementreferenceAsync(singlePaymentRequest, CancellationToken.None);

                if (!response!.Success)
                {
                    return BadRequest(new ApiErrorResponse
                    {
                        success = false,
                        trackingId = Activity.Current?.TraceId.ToString()!,
                        errors = new List<ApiError>
                {
                    new ApiError { code = "FAILED_PAYMENT_CREATION", message = $"Payment failed for reference {paymentDetail.reference}: {response.Message}" }
                }
                    });
                }

                if (response.ApiPaymentReference.HasValue)
                {
                    apiPaymentReferences.Add(response.ApiPaymentReference.Value);
                }
            }

            // Success response with all GUIDs
            return Ok(new
            {
                references = apiPaymentReferences.Select(g => g.ToString()).ToList(),
                status = true,
                reason = "Request processed successfully"
            });
        }
    }
}
