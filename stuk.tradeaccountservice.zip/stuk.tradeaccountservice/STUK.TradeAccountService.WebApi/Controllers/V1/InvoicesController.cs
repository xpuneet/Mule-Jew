﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using STUK.APIs.Common.Filters;
using STUK.APIs.Common.Models;
using STUK.APIs.Common.ViewTemplate;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.WebApi.RequestParams;
using STUK.TradeAccountService.WebApi.RouteParams;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace STUK.TradeAccountService.WebApi.Controllers.V1
{
    [Route("api/v1")]
    [ApiController]
    public class InvoicesController(ITradeAccountInvoicesService invoicesService, IInvoiceDownloadService downloadService, IConfiguration cfg) : BaseApiController
    {
        private readonly ITradeAccountInvoicesService _invoicesService = invoicesService ?? throw new ArgumentNullException(nameof(invoicesService));
        private readonly IInvoiceDownloadService _downloadService = downloadService ?? throw new ArgumentNullException(nameof(downloadService));
        private readonly int _maxPageSize = Convert.ToInt16(cfg["MaxPageSize"]);

        #region SERVER_ENDPOINT
        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(InvoiceResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("accounts/documents/invoices/{branchCode:regex(^\\S+$)}/{invoiceId:regex(^\\S+$)}")]
        public async Task<IActionResult> GetInvoiceById_Server(InvoiceRouteParams routeParams, CancellationToken cancellationToken)
            => await GetInvoiceByIdHandler(routeParams.InvoiceId, routeParams.BranchCode, cancellationToken);

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(InvoiceSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]        
        [HttpGet("accounts/documents/{accountCode:regex(^\\S+$)}/invoices/filter")]
        public async Task<IActionResult> GetInvoices_Server(AccountCodeRouteParams routeParams, InvoiceFilterQueryParams queryParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            
            var invoiceRequest = new InvoiceFilterRequest(routeParams.AccountCode, queryParams.SortBy, queryParams.SortOrder, queryParams.PageNumber,
               queryParams.PageSize, queryParams.BranchCode, queryParams.Brand, queryParams.InvoiceDateFrom, queryParams.InvoiceDateTo,
               queryParams.OrderBranchCode, queryParams.OrderNo, queryParams.OrderCreatedDateFrom, queryParams.OrderCreatedDateTo, queryParams.OrderReference,
               queryParams.ItemCode);

            var result = await _invoicesService.FilterInvoiceDocumentsAsync(invoiceRequest, 'S', cancellationToken) as InvoiceSearchResponse;
            return Ok(result);
        }

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(DocumentDownloadRequestResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("accounts/documents/invoices/{branchCode:regex(^\\S+$)}/{invoiceId:regex(^\\S+$)}/download-request")]
        public async Task<IActionResult> RequestInvoiceDownload_Server(InvoiceRouteParams routeParams, CancellationToken cancellationToken)
            => await RequestInvoiceDownloadHandler(routeParams.InvoiceId, routeParams.BranchCode, cancellationToken);

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(byte[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(DocumentDownloadResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [HttpGet("accounts/documents/invoices/download/{token:regex(^\\S+$)}")]
        public async Task<IActionResult> DownloadInvoice_Server(
        [FromRoute]
        [Required(ErrorMessage = "Token is required")] Guid token,
        CancellationToken cancellationToken)
            => await DownloadInvoiceHandler(token, cancellationToken);
        #endregion

        #region CLIENT_ENDPOINT 
        [UserAccountAuthorize]
        [HttpGet("capp/accounts/documents/invoices/{branchCode:regex(^\\S+$)}/{invoiceId:regex(^\\S+$)}")]
        [ProducesResponseType(typeof(InvoiceResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<IActionResult> GetInvoiceById(InvoiceRouteParams routeParams, CancellationToken cancellationToken)
            => await GetInvoiceByIdHandler(routeParams.InvoiceId, routeParams.BranchCode, cancellationToken);

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(InvoiceSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/documents/{accountCode:regex(^\\S+$)}/invoices/filter")]
        public async Task<IActionResult> GetInvoices(AccountCodeRouteParams routeParams, InvoiceFilterQueryParams queryParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            
            var invoiceRequest = new InvoiceFilterRequest(routeParams.AccountCode, queryParams.SortBy, queryParams.SortOrder, queryParams.PageNumber,
                queryParams.PageSize, queryParams.BranchCode, queryParams.Brand, queryParams.InvoiceDateFrom, queryParams.InvoiceDateTo,
                queryParams.OrderBranchCode, queryParams.OrderNo, queryParams.OrderCreatedDateFrom, queryParams.OrderCreatedDateTo, queryParams.OrderReference,
                queryParams.ItemCode);

            var result = await _invoicesService.FilterInvoiceDocumentsAsync(invoiceRequest, 'S', cancellationToken) as InvoiceSearchResponse;
            return Ok(result);
        }

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(InvoiceSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/documents/{accountCode:regex(^\\S+$)}/invoices")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> SearchInvoices(AccountCodeRouteParams routeParams, InvoiceSearchFilterQueryParams queryParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);

            var invoiceRequest = new InvoiceSearchFilterRequest(routeParams.AccountCode, queryParams.SortBy, queryParams.SortOrder, queryParams.PageNumber,
                queryParams.PageSize, queryParams.Status, queryParams.SearchParam);

            var result = await _invoicesService.SearchInvoiceByFilterParamAsync(invoiceRequest, 'S', cancellationToken) as InvoiceSearchResponse;
            return Ok(result);
        }

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(DocumentDownloadRequestResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("capp/accounts/documents/invoices/{branchCode:regex(^\\S+$)}/{invoiceId:regex(^\\S+$)}/download-request")]
        public async Task<IActionResult> RequestInvoiceDownload(InvoiceRouteParams routeParams, CancellationToken cancellationToken)
            => await RequestInvoiceDownloadHandler(routeParams.InvoiceId, routeParams.BranchCode, cancellationToken);

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(byte[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(DocumentDownloadResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [HttpGet("capp/accounts/documents/invoices/download/{token:regex(^\\S+$)}")]
        public async Task<IActionResult> DownloadInvoice(
        [FromRoute]
        [Required(ErrorMessage = "Token is required")] Guid token,
        CancellationToken cancellationToken)
            => await DownloadInvoiceHandler(token, cancellationToken);
        #endregion

        private async Task<IActionResult> GetInvoiceByIdHandler(string standardInvoiceNo, string branchCode, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);

            var invoice = await _invoicesService.GetInvoiceByStandardInvoiceNoAsync(standardInvoiceNo, branchCode, cancellationToken);
            return invoice is null ? CustomNotFound("INVOICE_NOT_FOUND", $"No invoice found for invoiceId '{standardInvoiceNo}' and branchCode '{branchCode}'.")
                : Ok(invoice);
        }

        private async Task<IActionResult> RequestInvoiceDownloadHandler(string standardInvoiceNo, string branchCode, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            return Ok(await _downloadService.RequestDownloadAsync(standardInvoiceNo, branchCode, cancellationToken));
        }

        private async Task<IActionResult> DownloadInvoiceHandler(Guid token, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _downloadService.DownloadAsync(token, cancellationToken);

            if (result.FileContent != null)
                return File(result.FileContent, result.ContentType!, result.FileName, enableRangeProcessing: true);

            return Ok(new { message = result.Message });
        }
    }
}
