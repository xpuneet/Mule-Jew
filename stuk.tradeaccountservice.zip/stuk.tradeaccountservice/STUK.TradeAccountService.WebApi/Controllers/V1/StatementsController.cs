﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using STUK.APIs.Common.Filters;
using STUK.APIs.Common.Models;
using STUK.APIs.Common.ViewTemplate;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.WebApi.RequestParams;
using STUK.TradeAccountService.WebApi.RouteParams;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace STUK.TradeAccountService.WebApi.Controllers.V1
{

    [Route("api/v1")]
    [ApiController]
    public class StatementsController(IStatementService statementService, IStatementDownloadService downloadService) : ControllerBase
    {
        private readonly IStatementService _statementService = statementService ?? throw new ArgumentNullException(nameof(statementService));
        private readonly IStatementDownloadService _downloadService = downloadService ?? throw new ArgumentNullException(nameof(downloadService));

        #region CLIENT_ENDPOINT
        [UserAccountAuthorize]
        [ProducesResponseType(typeof(StatementSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/documents/{accountCode:regex(^\\S+$)}/statements")]
        [TypeFilter(typeof(ResultTransformationFilter))]
        public async Task<IActionResult> SearchStatement(AccountCodeRouteParams routeParams, StatementSearchQueryParams queryParams,
            CancellationToken cancellationToken)
            => await SearchStatementHandler(routeParams.AccountCode, queryParams.PageNumber, queryParams.PageSize,
                queryParams.StatementDateFrom, queryParams.StatementDateTo, cancellationToken);

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(DocumentDownloadRequestResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("capp/accounts/documents/statements/{statementId:long:regex(^\\S+$)}/download-request")]
        public async Task<IActionResult> RequestStatementDownload(
            [FromRoute] 
            [Range(1, long.MaxValue, ErrorMessage ="Invalid statementid")] long statementId, CancellationToken cancellationToken)
            => await RequestDownloadHandler(statementId, cancellationToken);

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(byte[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(DocumentDownloadResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [HttpGet("capp/accounts/documents/statements/download/{token:regex(^\\S+$)}")]
        public async Task<IActionResult> DownloadStatement(
        [FromRoute]
        [Required(ErrorMessage = "Token is required")] Guid token, CancellationToken cancellationToken)
            => await DownloadHandler(token, cancellationToken);
        #endregion

        #region SERVER_ENDPOINT
        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(StatementSearchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpGet("accounts/documents/{accountCode:regex(^\\S+$)}/statements")]
        public async Task<IActionResult> SearchStatement_Server(AccountCodeRouteParams routeParams, StatementSearchQueryParams queryParams,
            CancellationToken cancellationToken)
            => await SearchStatementHandler(routeParams.AccountCode, queryParams.PageNumber, queryParams.PageSize,
                queryParams.StatementDateFrom, queryParams.StatementDateTo, cancellationToken);

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(DocumentDownloadRequestResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost("accounts/documents/statements/{statementId:long:regex(^\\S+$)}/download-request")]       
        public async Task<IActionResult> RequestStatementDownload_Server(
            [FromRoute]
            [Range(1, long.MaxValue, ErrorMessage ="Invalid statementid")] long statementId, CancellationToken cancellationToken)
            => await RequestDownloadHandler(statementId, cancellationToken);

        [Authorize(AuthenticationSchemes = ApiSecuritySettings.AuthenticationSchemes.User)]
        [ProducesResponseType(typeof(byte[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(DocumentDownloadResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [HttpGet("accounts/documents/statements/download/{token:regex(^\\S+$)}")]
        public async Task<IActionResult> DownloadStatement_Server(
        [FromRoute]
        [Required(ErrorMessage = "Token is required")] Guid token, CancellationToken cancellationToken)
            => await DownloadHandler(token, cancellationToken);
        #endregion

        private async Task<IActionResult> SearchStatementHandler(string accountCode, int pageNumber, int pageSize,
            DateOnly? statementDateFrom = null, DateOnly? statementDateTo = null, CancellationToken cancellationToken = default)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var request = new StatementSearchRequest(accountCode, pageNumber, pageSize, statementDateFrom, statementDateTo);
            return Ok(await _statementService.SearchStatementsAsync(request, cancellationToken));
        }

        private async Task<IActionResult> RequestDownloadHandler(long statementHeaderId, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            return Ok(await _downloadService.RequestDownloadAsync(statementHeaderId, null, cancellationToken));
        }

        private async Task<IActionResult> DownloadHandler(Guid token, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _downloadService.DownloadAsync(token, cancellationToken);

            if (result.FileContent != null)
            {
                return File(result.FileContent, result.ContentType!, result.FileName, enableRangeProcessing: true);
            }

            return Ok(new { message = result.Message });
        }
    }
}
