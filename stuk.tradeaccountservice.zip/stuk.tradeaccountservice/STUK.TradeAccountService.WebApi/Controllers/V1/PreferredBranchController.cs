﻿using Microsoft.AspNetCore.Mvc;
using STUK.APIs.Common.Exceptions;
using STUK.APIs.Common.Filters;
using STUK.APIs.Common.Models;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.Common.Data.Constants;
using STUK.TradeAccountService.WebApi.RouteParams;
using System.Diagnostics;

namespace STUK.TradeAccountService.WebApi.Controllers.V1
{
    [Route("api/v1")]
    [ApiController]
    public class PreferredBranchController(IPreferredBranchService preferredBranchService) : BaseApiController
    {
        private readonly IPreferredBranchService _preferredBranchService = preferredBranchService ?? throw new ArgumentNullException(nameof(preferredBranchService));

        [UserAccountAuthorize]
        [ProducesResponseType(typeof(PreferredBranchResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(NotFoundResponse), StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet("capp/accounts/{accountCode:regex(^\\S+$)}/preferred-branch")]
        public async Task<IActionResult> GetBranch(AccountCodeRouteParams routeParams, CancellationToken cancellationToken)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _preferredBranchService.GetPreferredBranchAsync(routeParams.AccountCode, cancellationToken);

            return (result is null || result.PreferredBranch is null) ? CustomNotFound("PREFERREDBRANCH_NOT_FOUND", result?.ErrorCode ?? "Preferred branch not found")
                : Ok(new PreferredBranchResponse(result.PreferredBranch));
        }

        [UserAccountAuthorize]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(NotFoundResponse), StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpPut("capp/accounts/{accountCode:regex(^\\S+$)}/preferred-branch")]
        public async Task<IActionResult> UpdateBranch(AccountCodeRouteParams routeParams,
        [FromBody] PreferredBranchRequest preferredBranchRequest)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _preferredBranchService.SetPreferredBranchAsync(routeParams.AccountCode, preferredBranchRequest.BranchNumber.TrimStart('0'), CancellationToken.None);
            return (result is null || result.PreferredBranch is null) ? CustomBadRequest("UPDATE_FAILED", $"Preferred branch update failed for account '{routeParams.AccountCode}'")
                : NoContent();
        }

        [UserAccountAuthorize]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(UnauthorizedResponse), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(InternalServerErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(NotFoundResponse), StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpDelete("capp/accounts/{accountCode:regex(^\\S+$)}/preferred-branch")]
        public async Task<IActionResult> DeleteBranch(AccountCodeRouteParams routeParams)
        {
            Activity.Current?.AddBaggage("ApiName", ServiceConstants.TradeAccountServiceName);
            var result = await _preferredBranchService.SetPreferredBranchAsync(routeParams.AccountCode, null, CancellationToken.None);
            return (result is null || result.PreferredBranch != null) ? CustomBadRequest("DELETE_FAILED", $"Preferred branch delete failed for account '{routeParams.AccountCode}'")
                : NoContent();
        }
    }
}
