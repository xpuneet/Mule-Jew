﻿using FluentValidation;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class PreferredBranchRequestValidator : AbstractValidator<PreferredBranchRequest>
    {
        public PreferredBranchRequestValidator()
        {
            RuleFor(x => x.BranchNumber)
                .NotEmpty().WithMessage("BranchNumber is required.")
                .MaximumLength(10).WithMessage("BranchNumber cannot exceed 10 characters.")
                .Matches("^\\d+$").WithMessage("BranchNumber must contain number only");
        }
    }
}
