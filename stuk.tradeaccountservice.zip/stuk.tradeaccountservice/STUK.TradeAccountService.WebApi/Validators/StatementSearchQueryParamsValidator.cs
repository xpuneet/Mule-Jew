﻿using FluentValidation;
using STUK.TradeAccountService.WebApi.RequestParams;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class StatementSearchQueryParamsValidator : AbstractValidator<StatementSearchQueryParams>
    {
        public StatementSearchQueryParamsValidator(IConfiguration cfg)
        {
            var maxPageSize = Convert.ToInt32(cfg["MaxPageSize"]);

            RuleFor(x => x)
                .Must(x => !x.StatementDateFrom.HasValue || x.StatementDateFrom <= x.StatementDateTo)
                .WithMessage("StatementDateFrom date must be before or equal to StatementDateTo")
                .When(x => x.StatementDateFrom.HasValue);

            RuleFor(x => x.PageSize).GreaterThan(0)
                .WithMessage("PageSize must be greater than 0.")
                .LessThanOrEqualTo(maxPageSize)
                .WithMessage($"PageSize exceeds the maximum allowed limit of {maxPageSize}.");

            RuleFor(x => x.PageNumber).GreaterThan(0)
                .WithMessage($"PageNumber must be greater than 0.");
        }
    }
}
