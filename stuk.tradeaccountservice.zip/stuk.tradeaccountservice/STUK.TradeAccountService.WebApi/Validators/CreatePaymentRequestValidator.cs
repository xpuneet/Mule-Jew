using FluentValidation;
using STUK.IconIntegration.IconClient;
using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class CreatePaymentRequestValidator : AbstractValidator<CreatePaymentRequest>
    {
        public CreatePaymentRequestValidator()
        {
            RuleFor(x => x.AccountCode)
                .NotEmpty().WithMessage("AccountCode is required.")
                .Matches("^(?=.*[a-zA-Z0-9]).+$").WithMessage("Invalid accountcode")
                .MaximumLength(8).WithMessage("AccountCode cannot exceed 8 characters.");

            RuleFor(x => x.BranchId)
                .NotEmpty().WithMessage("BranchId is required.")
                .Matches("^\\d+$").WithMessage("BranchId is numeric value")
                .MaximumLength(10).WithMessage("BranchId cannot exceed 10 characters.");

            RuleFor(x => x.Source)
                .NotEmpty().WithMessage("Source is required.")
                .MaximumLength(20).WithMessage("Source cannot exceed 20 characters.");

            RuleFor(x => x.Description)
                .NotEmpty().WithMessage("Description is required.")
                .MaximumLength(30).WithMessage("Description cannot exceed 30 characters."); ;

            RuleFor(x => x.PaymentType)
                .NotEmpty().WithMessage("PaymentType is required.")
                .Must(char.IsLetter).WithMessage("PaymentType must be a letter");

            RuleFor(x => x.PaymentAmount)
                .GreaterThan(0).WithMessage("PaymentAmount value must be greater than 0. ")
                .NotNull().WithMessage("PaymentAmount is required.");

            RuleFor(x => x.UserId)
                .MaximumLength(50).WithMessage("UserId cannot exceed 50 characters.")
                .When(x => x.UserId != null);

            RuleFor(x => x.OrderReference)
                .MaximumLength(50).WithMessage("OrderReference cannot exceed 50 characters.")
                .When(x => x.OrderReference != null);

            RuleFor(x => x.OrderNumber)
                .MaximumLength(50).WithMessage("OrderNumber cannot exceed 50 characters.")
                .When(x => x.OrderNumber != null);

            RuleFor(x => x.CreditCardReference)
                .MaximumLength(50).WithMessage("CreditCardReference cannot exceed 50 characters.")
                .When(x => x.CreditCardReference != null);
        }
    }
}
