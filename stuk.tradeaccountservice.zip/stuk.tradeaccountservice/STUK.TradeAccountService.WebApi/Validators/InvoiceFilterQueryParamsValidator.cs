﻿using FluentValidation;
using STUK.TradeAccountService.WebApi.RequestParams;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class InvoiceFilterQueryParamsValidator : AbstractValidator<InvoiceFilterQueryParams>
    {
        private readonly HashSet<string> allowedSortBy = ["issueDate", "dueDate", "amount"];
        private readonly HashSet<string> allowedSortOrder = ["asc", "desc"];

        public InvoiceFilterQueryParamsValidator(IConfiguration cfg)
        {
            var maxPageSize = Convert.ToInt32(cfg["MaxPageSize"]);

            RuleFor(x => x.SortBy)
                .Must(value => value is null || allowedSortBy.Contains(value, StringComparer.OrdinalIgnoreCase))
                .WithMessage("SortBy must be one of: issueDate, dueDate, amount.");

            RuleFor(x => x.SortOrder)
                .Must(value => value is null || allowedSortOrder.Contains(value, StringComparer.OrdinalIgnoreCase))
                .WithMessage("SortOrder must be one of: asc, desc.");

            RuleFor(x => x)
                .Must(x => !x.InvoiceDateFrom.HasValue || x.InvoiceDateFrom <= x.InvoiceDateTo)
                .WithMessage("InvoiceDateFrom date must be before or equal to InvoiceDateTo")
                .When(x => x.InvoiceDateFrom.HasValue);

            RuleFor(x => x.PageSize).GreaterThan(0)
                .WithMessage("PageSize must be greater than 0.")
                .LessThanOrEqualTo(maxPageSize)
                .WithMessage($"PageSize exceeds the maximum allowed limit of {maxPageSize}.");

            RuleFor(x => x.PageNumber).GreaterThan(0)
                .WithMessage($"PageNumber must be greater than 0.");
        }
    }
}
