using FluentValidation;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.WebApi.RequestParams;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class AccountSearchQueryParamsValidator : AbstractValidator<AccountSearchQueryParams>
    {
        public AccountSearchQueryParamsValidator(IConfiguration cfg)
        {
            var maxPageSize = Convert.ToInt32(cfg["MaxPageSize"]);

            RuleFor(x => x.PageSize).GreaterThan(0)
                .WithMessage("PageSize must be greater than 0.")
                .LessThanOrEqualTo(maxPageSize)
                .WithMessage($"PageSize exceeds the maximum allowed limit of {maxPageSize}.");

            RuleFor(x => x.PageNumber).GreaterThan(0)
                .WithMessage($"PageNumber must be greater than 0.");
        }
    }
}
