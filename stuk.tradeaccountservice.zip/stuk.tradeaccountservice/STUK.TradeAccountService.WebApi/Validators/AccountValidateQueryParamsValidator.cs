﻿using FluentValidation;
using STUK.TradeAccountService.Common.Contracts.Models;
using STUK.TradeAccountService.WebApi.RequestParams;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class AccountValidateQueryParamsValidator : AbstractValidator<AccountValidateQueryParams>
    {
        public AccountValidateQueryParamsValidator()
        {
            RuleFor(x => x.AccountCode)
                .NotEmpty().WithMessage("AccountCode is required.")
                .Matches("^(?=.*[a-zA-Z0-9]).+$").WithMessage("Invalid accountcode")
                .MaximumLength(50).WithMessage("AccountCode cannot exceed 50 characters.");

            RuleFor(x => x.PostCode)
                .NotEmpty().WithMessage("PostCode is required.")
                .MaximumLength(10).WithMessage("PostCode cannot exceed 10 characters.");

            RuleFor(x => x.Brand)
                .NotEmpty().WithMessage("Brand is required.")
                .MaximumLength(100).WithMessage("Brand cannot exceed 100 characters.");
        }
    }
}
