﻿using FluentValidation;
using STUK.TradeAccountService.WebApi.RequestParams;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class InvoiceSearchFilterQueryParamsValidator : AbstractValidator<InvoiceSearchFilterQueryParams>
    {
        private readonly HashSet<string> allowedSortBy = ["issueDate", "dueDate", "amount"];
        private readonly HashSet<string> allowedSortOrder = ["asc", "desc"];
        private readonly HashSet<string> allowedStatuses = ["overdue", "dueSoon", "notYetDue", "paid"];
        public InvoiceSearchFilterQueryParamsValidator(IConfiguration cfg)
        {
            var maxPageSize = Convert.ToInt32(cfg["MaxPageSize"]);

            RuleFor(x => x.SearchParam)
                    .MinimumLength(3)
                    .MaximumLength(100);

            RuleFor(x => x.SortBy)
                .Must(value => value is null || allowedSortBy.Contains(value, StringComparer.OrdinalIgnoreCase))
                .WithMessage("SortBy must be one of: issueDate, dueDate, amount.");

            RuleFor(x => x.SortOrder)
                .Must(value => value is null || allowedSortOrder.Contains(value, StringComparer.OrdinalIgnoreCase))
                .WithMessage("SortOrder must be one of: asc, desc.");

            RuleFor(x => x.Status)
                .Must(BeValidStatuses)
                .WithMessage("Status can only contain distinct: overdue, dueSoon, notYetDue, paid.");

            RuleFor(x => x.PageSize).GreaterThan(0)
                .WithMessage("PageSize must be greater than 0.")
                .LessThanOrEqualTo(maxPageSize)
                .WithMessage($"PageSize exceeds the maximum allowed limit of {maxPageSize}.");

            RuleFor(x => x.PageNumber).GreaterThan(0)
                .WithMessage("PageNumber must be greater than 0.");
        }

        private bool BeValidStatuses(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return true;
            
            var statuses = value.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            return statuses.All(allowedStatuses.Contains)
            && statuses.Distinct(StringComparer.OrdinalIgnoreCase).Count() == statuses.Length;
        }
    }
}
