﻿using FluentValidation;
using STUK.TradeAccountService.WebApi.RequestParams;

namespace STUK.TradeAccountService.WebApi.Validators
{
    public class AccountOverviewQueryParamsValidator : AbstractValidator<AccountOverviewQueryParams>
    {
        public AccountOverviewQueryParamsValidator()
        {
            RuleFor(x => x.RecentInvoicesLimit)
                .InclusiveBetween(1, 10)
                .WithMessage("RecentInvoicesLimit must be 1-10");

            RuleFor(x => x.RecentCreditNotesLimit)
                .InclusiveBetween(1, 10)
                .WithMessage("RecentCreditNotesLimit must be 1-10");

            RuleFor(x => x.RecentStatementsLimit)
                .InclusiveBetween(1, 12)
                .WithMessage("RecentStatementsLimit must be 1-12");
        }
    }
}
