using Azure.Identity;
using FluentValidation;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi;
using STUK.APIs.Common.ApiLayer.Services.Swagger;
using STUK.APIs.Common.DependencyInjection;
using STUK.APIs.Common.Exceptions;
using STUK.APIs.Common.Filters;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Logging;
using STUK.APIs.Common.Models;
using STUK.ConfigurationProviders;
using STUK.TradeAccountService.Common.Contracts.Config;
using STUK.TradeAccountService.Common.Data.DependencyInjection;
using Swashbuckle.AspNetCore.Filters;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

var env = builder.Environment.EnvironmentName;
// Only use SQL configuration in Production
if (env.Equals("Production", StringComparison.OrdinalIgnoreCase))
{
  // Add configuration from SQL Server
  builder.Configuration.AddSqlServerConfiguration(
  "TradeAccountServiceDb",
  "GetApplicationSettings",
  "ConfigReload",
  ["TradeAccountService_ReloadInterval", "TradeAccountService_Pagination"]
  );
}

var keyVaultUrl = builder.Configuration["KeyVaultUrl"] ?? "";
builder.Configuration.AddAzureKeyVault(
    new Uri(keyVaultUrl),
    new DefaultAzureCredential()
);

// Pass directly to common library
builder.Services.AddCommonLogging();
builder.Services.AddSingleton<IAppInsightsLoggerHelper, AppInsightsLoggerHelper>();

// Add session validator
string sessionValidatorApiUrl = builder.Configuration["WebApi:SessionValidatorApiUrl"]!;
builder.Services.AddUserAccountAuthorization(sessionValidatorApiUrl);

//server app authentication
var apiSecuritySettings = builder.Configuration.GetSection("ApiSecuritySettings").Get<ApiSecuritySettings>()!;
var authenticationBuilder = builder.Services.AddAuthentication(options =>
{
  options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
  options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
  options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;

});
foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
{
  authenticationBuilder.AddJwtBearer(scheme, options =>
  {
    options.Authority = apiSecuritySettings.OpenIdAuthority;
    options.RequireHttpsMetadata = false;
    options.Audience = apiSecuritySettings.SchemeToScopeMappings[scheme];
  });
}

builder.Services.AddAuthorization(options =>
{
  foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
  {
    options.AddPolicy(scheme, p =>
    {
      p.RequireAuthenticatedUser();
      p.AuthenticationSchemes = [scheme];
    });
  }
});

builder.Services.AddControllers(options =>
{
  options.Filters.Add<ValidationFilter>();
}).AddJsonOptions(options =>
{
  options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

// Suppress default ModelState validation so our ValidationFilter handles it
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
  options.SuppressModelStateInvalidFilter = true;
});

// Register FluentValidation validators
builder.Services.AddValidatorsFromAssemblyContaining<Program>();

var connectionString = builder.Configuration.GetConnectionString("TradeAccountServiceDb");
var orderConnectionString = builder.Configuration.GetConnectionString("OrderServiceDb");
builder.Services.AddSharedDatabase(connectionString!, "AccountDb");
builder.Services.AddSharedDatabase(orderConnectionString!, "OrderDb");

builder.Services.AddTradeAccountServices(builder.Configuration);

//Template view
builder.Services.AddTemplateView(builder.Configuration);
// --- Swagger Configuration ---
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
  c.SwaggerDoc("v1", new OpenApiInfo { Title = "STUK.TradeAccountService.WebApi", Version = "v1" });

  // XML docs, BaseRequest params, Bearer/XSessionId schemes + per-op security (with host document).
  c.AddApiLayerSwaggerGen();

  // Add header parameters globally if needed
  c.OperationFilter<AddResponseHeadersFilter>();
  c.OperationFilter<AppendAuthorizeToSummaryOperationFilter>();
  c.OperationFilter<SecurityRequirementsOperationFilter>();

  // Support examples
  c.ExampleFilters();
});
// Add Swashbuckle Filters
builder.Services.AddSwaggerExamplesFromAssemblies(System.Reflection.Assembly.GetExecutingAssembly());
builder.Services.AddSwaggerExamplesFromAssemblyOf<InternalServerErrorResponse>();

var app = builder.Build();

// Swagger middleware
app.UseSwagger();
var generateSwagger = Convert.ToBoolean(builder.Configuration["AllowSwagger"]);
if (generateSwagger)
{
  app.UseSwaggerUI(c =>
  {
    c.SwaggerEndpoint("v1/swagger.json", "STUK.TradeAccountService.WebApi v1");
  });
}
app.UseMiddleware<GlobalExceptionHandler>();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
