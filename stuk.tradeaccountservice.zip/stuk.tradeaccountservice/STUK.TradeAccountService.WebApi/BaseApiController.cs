﻿using Microsoft.AspNetCore.Mvc;
using STUK.APIs.Common.Models;
using System.Diagnostics;

namespace STUK.TradeAccountService.WebApi
{
    public abstract class BaseApiController : ControllerBase
    {
        protected IActionResult CustomNotFound(string code, string message)
        {
            return NotFound(new ApiErrorResponse
            {
                success = false,
                trackingId = Activity.Current?.TraceId.ToString()!,
                errors = [new() { code = code, message = message }]
            });
        }

        protected IActionResult CustomBadRequest(string code, string message)
        {
            return BadRequest(new ApiErrorResponse
            {
                success = false,
                trackingId = Activity.Current?.TraceId.ToString()!,
                errors = [new() { code = code, message = message }]
            });
        }
    }
}
