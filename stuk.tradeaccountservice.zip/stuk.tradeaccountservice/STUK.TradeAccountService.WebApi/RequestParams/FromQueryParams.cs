﻿using Microsoft.AspNetCore.Mvc;

namespace STUK.TradeAccountService.WebApi.RequestParams
{
    public record PaginationQueryParams
    {
        [FromQuery(Name = "pageNumber")]
        public int PageNumber { get; set; } = 1;

        [FromQuery(Name = "pageSize")]
        public int PageSize { get; set; } = 10;
    }

    public record InvoiceFilterQueryParams : PaginationQueryParams
    {
        [FromQuery(Name = "branchCode")]
        public string? BranchCode { get; set; }

        [FromQuery(Name = "brand")]
        public string? Brand { get; set; }

        [FromQuery(Name = "invoiceDateFrom")]
        public DateTimeOffset? InvoiceDateFrom { get; set; }

        [FromQuery(Name = "invoiceDateTo")]
        public DateTimeOffset? InvoiceDateTo { get; set; }

        [FromQuery(Name = "orderBranchCode")]
        public string? OrderBranchCode { get; set; }

        [FromQuery(Name = "orderNo")]
        public int? OrderNo { get; set; }

        [FromQuery(Name = "orderCreatedDateFrom")]
        public DateTimeOffset? OrderCreatedDateFrom { get; set; }

        [FromQuery(Name = "orderCreatedDateTo")]
        public DateTimeOffset? OrderCreatedDateTo { get; set; }

        [FromQuery(Name = "orderReference")]
        public string? OrderReference { get; set; }

        [FromQuery(Name = "itemCode")]
        public string? ItemCode { get; set; }

        [FromQuery(Name = "sortBy")]
        public string SortBy { get; set; } = "issueDate";
        
        [FromQuery(Name = "sortOrder")]
        public string SortOrder { get; set; } = "desc";
    }

    public record InvoiceSearchFilterQueryParams : PaginationQueryParams
    {
        [FromQuery(Name = "status")]
        public string? Status { get; set; }

        [FromQuery(Name = "q")]
        public string? SearchParam { get; set; }

        [FromQuery(Name = "sortBy")]
        public string SortBy { get; set; } = "issueDate";

        [FromQuery(Name = "sortOrder")]
        public string SortOrder { get; set; } = "desc";
    }

    public record StatementSearchQueryParams : PaginationQueryParams
    {
        [FromQuery(Name = "statementDateFrom")]
        public DateOnly? StatementDateFrom { get; set; }

        [FromQuery(Name = "statementDateTo")]
        public DateOnly? StatementDateTo { get; set; }
    }

    public record AccountSearchQueryParams: PaginationQueryParams { }

    public record AccountValidateQueryParams
    {
        [FromQuery(Name = "accountCode")]
        public string AccountCode { get; set; } = null!;

        [FromQuery(Name = "postCode")]
        public string PostCode { get; set; } = null!;

        [FromQuery(Name = "brand")]
        public string Brand { get; set; } = null!;
    }

    public record AccountOverviewQueryParams
    {
        [FromQuery(Name = "recentInvoicesLimit")]
        public int RecentInvoicesLimit { get; set; } = 5;

        [FromQuery(Name = "recentCreditNotesLimit")]
        public int RecentCreditNotesLimit { get; set; } = 5;

        [FromQuery(Name = "recentStatementsLimit")]
        public int RecentStatementsLimit { get; set; } = 3;
    }
}
