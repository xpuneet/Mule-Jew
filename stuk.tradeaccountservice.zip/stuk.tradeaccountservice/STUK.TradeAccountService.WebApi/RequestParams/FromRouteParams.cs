﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace STUK.TradeAccountService.WebApi.RouteParams
{
    public record BaseRouteParams
    {
        [FromRoute(Name = "branchCode")]
        [Required(ErrorMessage = "Branchcode is required")]
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Length of branchcode must be 1-10")]
        [RegularExpression(@"^(?=.*[a-zA-Z0-9]).+$", ErrorMessage = "Invalid branchcode")]
        public string BranchCode { get; init; } = null!;
    }
    public record InvoiceRouteParams : BaseRouteParams
    {
        [FromRoute(Name = "invoiceId")]
        [Required(ErrorMessage = "InvoiceId is required")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Length of invoiceid must be 1-50")]
        [RegularExpression(@"^(?=.*[a-zA-Z0-9]).+$", ErrorMessage = "Invalid invoiceid")]
        public string InvoiceId { get; init; } = null!;
    }

    public record CreditNoteRouteParams : BaseRouteParams
    {
        [FromRoute(Name = "creditNoteId")]
        [Required(ErrorMessage = "Creditnoteid is required")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Length of creditnoteid must be 1-50")]
        [RegularExpression(@"^(?=.*[a-zA-Z0-9]).+$", ErrorMessage = "Invalid creditnoteid")]
        public string CreditNoteId { get; init; } = null!;
    }

    public record AccountCodeRouteParams
    {
        [FromRoute(Name = "accountCode")]
        [Required(ErrorMessage = "Accountcode is required")]
        [StringLength(25, MinimumLength = 1, ErrorMessage = "Length of accountcode must be 1-25")]
        [RegularExpression(@"^(?=.*[a-zA-Z0-9]).+$", ErrorMessage = "Invalid accountcode")]
        public string AccountCode { get; init; } = null!;
    }
}
