namespace STUK.TradeAccountService.Common.Contracts.Config
{
    /// <summary>
    /// Provides the feature settings for the Workday-to-Concur integration
    /// </summary>
    public class WorkdayConcurOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "WorkdayConcur";

        /// <summary>
        /// Gets or sets whether scheduled Workday-to-Concur processing is enabled
        /// </summary>
        public bool Enabled { get; set; }

        /// <summary>
        /// Gets or sets the timer schedule as a NCRONTAB expression
        /// </summary>
        public string Cron { get; set; } = "0 0 7 * * *";

        /// <summary>
        /// Gets or sets the duration of the database-backed orchestration lease in seconds
        /// </summary>
        public int LeaseDurationSeconds { get; set; } = 300;

        /// <summary>
        /// Gets or sets how frequently the active database lease is renewed
        /// </summary>
        public int LeaseRenewalIntervalSeconds { get; set; } = 60;

        /// <summary>
        /// Gets or sets the existing managed file-transfer Synapse workspace name
        /// </summary>
        public string SynapseWorkspaceName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the existing Concur transformation Synapse workspace name
        /// </summary>
        public string ConcurSynapseWorkspaceName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the existing File Transfer integration identifier for TM1 pickup
        /// </summary>
        public string Tm1PickupIntegrationKeyId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the existing File Transfer action name for TM1 pickup
        /// </summary>
        public string Tm1PickupActionName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets how often an active Synapse run is checked
        /// </summary>
        public int SynapsePollIntervalSeconds { get; set; } = 5;

        /// <summary>
        /// Gets or sets the maximum time spent waiting for one Synapse run
        /// </summary>
        public int SynapseRunTimeoutSeconds { get; set; } = 600;

        /// <summary>
        /// Gets or sets the published Mule-free Concur parent pipeline name
        /// </summary>
        public string ConcurTransformationPipelineName { get; set; } = "pl-concur-parent";

        /// <summary>
        /// Gets or sets the Workday Human Resources SOAP endpoint
        /// </summary>
        public string WorkdayEndpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Workday integration-system username
        /// </summary>
        public string WorkdayUsername { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Workday integration-system password supplied through secure configuration
        /// </summary>
        public string WorkdayPassword { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the number of worker references requested from Workday per page
        /// </summary>
        public int WorkdayPageSize { get; set; } = 100;

        /// <summary>
        /// Gets or sets the number of employee identifiers requested in each Workday detail call
        /// </summary>
        public int WorkdayDetailBatchSize { get; set; } = 100;

        /// <summary>
        /// Gets or sets the Workday SOAP request timeout in seconds
        /// </summary>
        public int WorkdayRequestTimeoutSeconds { get; set; } = 60;

        /// <summary>
        /// Gets or sets the Azure Blob service endpoint hosting the Concur integration container
        /// </summary>
        public string ConcurBlobServiceEndpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the environment-specific Concur integration Blob container
        /// </summary>
        public string ConcurBlobContainerName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Concur SFTP destination folder, using the production folder by default
        /// </summary>
        public string ConcurDestinationPath { get; set; } = "/in";

        /// <summary>
        /// Gets or sets the ledger code written to each Concur employee row
        /// </summary>
        public string ConcurLedgerCode { get; set; } = "SGBD";

        /// <summary>
        /// Gets or sets the fallback approval value used when Workday supplies no integration override
        /// </summary>
        public string ConcurApprovalDefault { get; set; } = "N";

        /// <summary>
        /// Gets or sets the ASCII-armored Concur public key supplied through secure configuration
        /// </summary>
        public string ConcurPgpPublicKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the hexadecimal Concur public-key identifier expected in the configured keyring
        /// </summary>
        public string ConcurPgpKeyId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the existing File Transfer integration identifier for Concur delivery
        /// </summary>
        public string ConcurDeliveryIntegrationKeyId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the existing File Transfer action name for Concur delivery
        /// </summary>
        public string ConcurDeliveryActionName { get; set; } = string.Empty;
    }
}
