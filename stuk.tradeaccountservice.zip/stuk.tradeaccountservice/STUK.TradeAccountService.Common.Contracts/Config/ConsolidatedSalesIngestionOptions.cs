namespace STUK.TradeAccountService.Common.Contracts.Config
{
    /// <summary>
    /// Provides the runtime settings for HX consolidated sales ingestion
    /// </summary>
    public class ConsolidatedSalesIngestionOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "ConsolidatedSales:Ingestion";

        /// <summary>
        /// Gets or sets the source-system identifier recorded for HX files
        /// </summary>
        public string SourceSystem { get; set; } = "HX";

        /// <summary>
        /// Gets or sets the file suffix accepted by the ingestion Function
        /// </summary>
        public string FileSuffix { get; set; } = ".con.xml";

        /// <summary>
        /// Gets or sets the Blob container containing staged HX files
        /// </summary>
        public string ContainerName { get; set; } = "datalake";

        /// <summary>
        /// Gets or sets the Blob prefix containing files ready for ingestion
        /// </summary>
        public string ReadyPrefix { get; set; } = "hx/delivery-staging";

        /// <summary>
        /// Gets or sets the maximum number of claimed files processed by one scheduled run
        /// </summary>
        public int MaximumFilesPerRun { get; set; } = 10;

        /// <summary>
        /// Gets or sets the duration of a source-file processing lease in seconds
        /// </summary>
        public int LeaseDurationSeconds { get; set; } = 900;

        /// <summary>
        /// Gets or sets how frequently an active source-file processing lease is renewed
        /// </summary>
        public int LeaseRenewalIntervalSeconds { get; set; } = 300;

        /// <summary>
        /// Gets or sets the delay before a failed source file becomes eligible for retry
        /// </summary>
        public int RetryDelaySeconds { get; set; } = 30;

        /// <summary>
        /// Gets or sets the maximum number of failed ingestion attempts
        /// </summary>
        public int MaximumRetryCount { get; set; } = 2;
    }
}
