﻿namespace STUK.TradeAccountService.Common.Contracts.Config
{
    public class TradeAcnSyncOptions
    {
        public const string SectionName = "TradeAccountFunction";
        public int PaymentRefMaxDegreeOfParallelism { get; set; }
        public int PaymentRefMaxDelayPerThread { get; set; }
        public int StatementBatchSize { get; set; }
        public int IconApiMaxRetries { get; set; }
        public int PaymentRefBatchSize { get; set; }
    }
}
