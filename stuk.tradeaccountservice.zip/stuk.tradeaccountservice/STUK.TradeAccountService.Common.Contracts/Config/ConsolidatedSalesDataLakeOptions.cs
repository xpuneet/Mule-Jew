namespace STUK.TradeAccountService.Common.Contracts.Config
{
    /// <summary>
    /// Provides bounded worker and destination settings for the Consolidated Sales Data Lake export
    /// </summary>
    public class ConsolidatedSalesDataLakeOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "ConsolidatedSales:Export:DataLake";

        /// <summary>
        /// Gets or sets the environment-specific ADLS Gen2 DFS service endpoint
        /// </summary>
        public string ServiceUri { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the environment-specific Data Lake filesystem
        /// </summary>
        public string FileSystem { get; set; } = string.Empty;
    }
}
