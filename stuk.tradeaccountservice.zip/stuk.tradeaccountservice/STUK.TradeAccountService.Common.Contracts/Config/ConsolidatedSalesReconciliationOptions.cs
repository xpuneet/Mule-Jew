namespace STUK.TradeAccountService.Common.Contracts.Config
{
    /// <summary>
    /// Provides bounded worker and retry settings for existing-invoice reconciliation
    /// </summary>
    public class ConsolidatedSalesReconciliationOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "ConsolidatedSales:Reconciliation";

        /// <summary>
        /// Gets or sets the maximum work items claimed during one Function invocation
        /// </summary>
        public int MaximumWorkItemsPerRun { get; set; } = 2;

        /// <summary>
        /// Gets or sets the duration of each SQL processing lease in seconds
        /// </summary>
        public int LeaseDurationSeconds { get; set; } = 120;

        /// <summary>
        /// Gets or sets the delay before an unmatched invoice becomes eligible for another attempt
        /// </summary>
        public int NoMatchRetryDelaySeconds { get; set; } = 300;

        /// <summary>
        /// Gets or sets the delay before failed work becomes eligible for another attempt
        /// </summary>
        public int FailureRetryDelaySeconds { get; set; } = 30;

        /// <summary>
        /// Gets or sets the maximum durable reconciliation failure attempts
        /// </summary>
        public int MaximumRetryCount { get; set; } = 2;
    }
}
