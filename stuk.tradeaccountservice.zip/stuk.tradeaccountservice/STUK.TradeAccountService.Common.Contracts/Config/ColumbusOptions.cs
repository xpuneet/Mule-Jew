namespace STUK.TradeAccountService.Common.Contracts.Config
{
    /// <summary>
    /// Provides fallback settings for deferring Salesforce after Trade Account first reads an HX file
    /// </summary>
    public class ColumbusOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "Columbus";

        /// <summary>
        /// Gets or sets whether Salesforce synchronisation is deferred after Trade Account first reads the source file
        /// </summary>
        public bool EnableSalesforceCooloff { get; set; }

        /// <summary>
        /// Gets or sets the number of hours Salesforce work remains ineligible after Trade Account first reads the source file
        /// </summary>
        public int SalesforceCooloffHours { get; set; } = 48;
    }
}
