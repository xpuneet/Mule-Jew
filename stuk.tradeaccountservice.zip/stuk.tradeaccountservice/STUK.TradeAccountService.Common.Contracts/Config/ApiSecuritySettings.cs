﻿namespace STUK.TradeAccountService.Common.Contracts.Config
{
    public class ApiSecuritySettings
    {
        public static class AuthenticationSchemes
        {
            public const string User = "User";
        }

        public string OpenIdAuthority { get; init; } = null!;
        public Dictionary<string, string> SchemeToScopeMappings { get; init; } = [];
    }
}
