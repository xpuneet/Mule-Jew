namespace STUK.TradeAccountService.Common.Contracts.Config
{
    /// <summary>
    /// Provides environment-specific destination settings for the Phocas Blob hand-off
    /// </summary>
    public class PhocasBlobStagingOptions
    {
        /// <summary>
        /// Gets the configuration section name
        /// </summary>
        public const string SectionName = "ConsolidatedSales:Export:Phocas";

        /// <summary>
        /// Gets or sets the existing Phocas Function Blob trigger path as container and optional prefix
        /// </summary>
        public string BlobStagingPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the FileActions identifier prepended to the staged Blob filename
        /// </summary>
        public string FileActionId { get; set; } = string.Empty;
    }
}
