﻿namespace STUK.TradeAccountService.Common.Contracts.Config
{
    public class DownloadSettings : Dictionary<string, DocumentTypeDownloadSettings> { }

    public class DocumentTypeDownloadSettings
    {
        public string ContainerName { get; set; } = null!;
        public string? FilePrepareUrl { get; set; }
        public int DownloadDelayHours { get; set; }
        public int TokenRefreshIntervalHours { get; set; } = 2;
    }

    public class BlobStorage
    {
        public string StorageAccountUrl { get; set; } = null!;
    }
}
