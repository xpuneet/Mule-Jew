namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the source-item state returned after a failed processing attempt
    /// </summary>
    public class ConsolidatedSalesSourceFailureResult
    {
        /// <summary>
        /// Gets or sets the resulting processing status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the resulting retry count
        /// </summary>
        public int RetryCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible processing time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }
    }
}
