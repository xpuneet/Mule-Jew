namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents one invoice read from an HX consolidated invoice file
    /// </summary>
    public class HxInvoiceDto
    {
        /// <summary>
        /// Gets or sets the HX invoice header values
        /// </summary>
        public HxInvoiceHeaderDto Header { get; set; } = new();

        /// <summary>
        /// Gets or sets the source invoice and order references
        /// </summary>
        public HxInvoiceReferencesDto References { get; set; } = new();

        /// <summary>
        /// Gets or sets the HX consolidated-invoice header extension
        /// </summary>
        public HxConsolidatedHeaderDto? Consolidated { get; set; }

        /// <summary>
        /// Gets or sets the invoice business date
        /// </summary>
        public DateOnly? InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets the date on which tax applies to the invoice
        /// </summary>
        public DateOnly? TaxPointDate { get; set; }

        /// <summary>
        /// Gets or sets the supplier details supplied by HX
        /// </summary>
        public HxPartyDto? Supplier { get; set; }

        /// <summary>
        /// Gets or sets the buyer details supplied by HX
        /// </summary>
        public HxPartyDto? Buyer { get; set; }

        /// <summary>
        /// Gets or sets the party to which the invoice is addressed
        /// </summary>
        public HxPartyDto? InvoiceTo { get; set; }

        /// <summary>
        /// Gets or sets the invoice lines in their source order
        /// </summary>
        public List<HxInvoiceLineDto> Lines { get; set; } = [];

        /// <summary>
        /// Gets or sets the invoice tax subtotals grouped by tax rate
        /// </summary>
        public List<HxTaxSubTotalDto> TaxSubTotals { get; set; } = [];

        /// <summary>
        /// Gets or sets the totals reported for the complete invoice
        /// </summary>
        public HxInvoiceTotalsDto? Totals { get; set; }
    }
}
