namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Describes a classified HX invoice parsing failure without exposing source document content
    /// </summary>
    public class HxInvoiceParseException : Exception
    {
        /// <summary>
        /// Initialises a classified HX invoice parsing exception
        /// </summary>
        /// <param name="category">The category of parsing failure</param>
        /// <param name="message">A safe description of the failure</param>
        /// <param name="elementPath">The logical XML path associated with the failure</param>
        /// <param name="invoiceNumber">The source invoice number, when known</param>
        /// <param name="lineNumber">The source invoice line number, when known</param>
        /// <param name="sanitisationAttempted">Whether the sanitisation fallback was attempted</param>
        /// <param name="innerException">The underlying XML exception, when available</param>
        public HxInvoiceParseException(
            HxInvoiceParseErrorCategory category,
            string message,
            string? elementPath = null,
            string? invoiceNumber = null,
            string? lineNumber = null,
            bool sanitisationAttempted = false,
            Exception? innerException = null)
            : base(message, innerException)
        {
            Category = category;
            ElementPath = elementPath;
            InvoiceNumber = invoiceNumber;
            LineNumber = lineNumber;
            SanitisationAttempted = sanitisationAttempted;
        }

        /// <summary>
        /// Gets the category of parsing failure
        /// </summary>
        public HxInvoiceParseErrorCategory Category { get; }

        /// <summary>
        /// Gets the logical XML path associated with the failure, when known
        /// </summary>
        public string? ElementPath { get; }

        /// <summary>
        /// Gets the source invoice number associated with the failure, when known
        /// </summary>
        public string? InvoiceNumber { get; }

        /// <summary>
        /// Gets the source invoice line number associated with the failure, when known
        /// </summary>
        public string? LineNumber { get; }

        /// <summary>
        /// Gets a value indicating whether the sanitisation fallback was attempted
        /// </summary>
        public bool SanitisationAttempted { get; }
    }
}
