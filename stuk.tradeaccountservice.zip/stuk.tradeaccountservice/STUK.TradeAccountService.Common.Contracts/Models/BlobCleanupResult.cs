﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class BlobCleanupResult

    {
        public int Deleted { get; set; }
        public int Retained { get; set; }
        public int Skipped { get; set; }
        public int Failed { get; set; }
        public List<string> DeletedBlobs { get; set; } = new();

    }
}
