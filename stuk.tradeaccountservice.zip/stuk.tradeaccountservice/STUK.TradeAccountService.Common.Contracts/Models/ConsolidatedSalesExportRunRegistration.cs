namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Defines an idempotent weekly Consolidated Sales export run
    /// </summary>
    public class ConsolidatedSalesExportRunRegistration
    {
        /// <summary>
        /// Gets or sets the stable logical run key
        /// </summary>
        public string LogicalRunKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the end-to-end correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the calendar year represented by the export
        /// </summary>
        public int ExportYear { get; set; }

        /// <summary>
        /// Gets or sets the first date included by the Salesforce extraction
        /// </summary>
        public DateOnly ExtractFromDate { get; set; }

        /// <summary>
        /// Gets or sets the scheduled time represented by the logical run
        /// </summary>
        public DateTimeOffset ScheduledFor { get; set; }

        /// <summary>
        /// Gets or sets the optional UTC registration time
        /// </summary>
        public DateTimeOffset? Now { get; set; }
    }
}
