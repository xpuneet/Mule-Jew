namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a supplier, buyer or invoice recipient in the HX document
    /// </summary>
    public class HxPartyDto
    {
        /// <summary>
        /// Gets or sets the account code used to identify the party
        /// </summary>
        public string? AccountCode { get; set; }

        /// <summary>
        /// Gets or sets the party name
        /// </summary>
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the party's postal address
        /// </summary>
        public HxAddressDto? Address { get; set; }
    }
}
