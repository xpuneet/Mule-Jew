namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents order and delivery references supplied for an invoice line
    /// </summary>
    public class HxInvoiceLineReferencesDto
    {
        /// <summary>
        /// Gets or sets the source order line number
        /// </summary>
        public string? OrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number associated with the line
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note line number
        /// </summary>
        public string? DeliveryNoteLineNumber { get; set; }
    }
}
