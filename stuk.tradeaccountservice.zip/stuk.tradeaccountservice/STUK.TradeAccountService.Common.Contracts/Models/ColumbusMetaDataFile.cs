using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    [XmlRoot("m4cdwxmlarchivecontrolfile")]
    public class ColumbusMetaDataFile
    {
        [XmlElement("input")]
        public ArchiveInput? Input { get; set; }
    }

    public class ArchiveInput
    {
        [XmlElement("multidocumentfile")]
        public MultiDocumentFile? MultiDocumentFile { get; set; }
    }

    public class MultiDocumentFile
    {
        [XmlElement("file")]
        public string? File { get; set; }

        [XmlArray("documents")]
        [XmlArrayItem("document")]
        public List<ArchiveDocument>? Documents { get; set; }
    }

    public class ArchiveDocument
    {
        [XmlAttribute("typename")]
        public string? TypeName { get; set; }

        [XmlArray("indexes")]
        [XmlArrayItem("index")]
        public List<ArchiveIndex>? Indexes { get; set; }

        public string? GetIndex(string shortname) =>
            Indexes?.Find(i => string.Equals(i.ShortName, shortname, StringComparison.OrdinalIgnoreCase))?.Value;

        private Dictionary<string, string>? _indexCache;

        private Dictionary<string, string> IndexCache =>
            _indexCache ??= Indexes?.Where(i => i.ShortName != null).ToDictionary(i => i.ShortName!, i => i.Value ?? string.Empty, StringComparer.OrdinalIgnoreCase)
                ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public string? this[string shortname] => IndexCache.TryGetValue(shortname, out var v) ? v : null;
    }

    public class ArchiveIndex
    {
        [XmlAttribute("shortname")]
        public string? ShortName { get; set; }

        [XmlText]
        public string? Value { get; set; }
    }
}