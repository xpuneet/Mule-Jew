namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the Workday employee values consumed by the Concur employee export
    /// </summary>
    public class WorkdayWorker
    {
        /// <summary>
        /// Gets or sets the Workday employee identifier
        /// </summary>
        public string EmployeeId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the primary work email address
        /// </summary>
        public string PrimaryWorkEmail { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the preferred first name
        /// </summary>
        public string PreferredFirstName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the preferred last name
        /// </summary>
        public string PreferredLastName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the current position title
        /// </summary>
        public string PositionTitle { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the worker organisation name used as the Concur cost centre
        /// </summary>
        public string OrganizationName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Workday termination date text when present
        /// </summary>
        public string TerminationDate { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the first unfiltered integration override value used by the current Concur mapping
        /// </summary>
        public string? FirstIntegrationFieldOverrideValue { get; set; }

        /// <summary>
        /// Gets or sets integration-field values keyed by their Workday field identifier
        /// </summary>
        public IReadOnlyDictionary<string, string> IntegrationFieldOverrides { get; set; } = new Dictionary<string, string>(StringComparer.Ordinal);

        /// <summary>
        /// Gets or sets custom identifiers keyed by their Workday identifier type
        /// </summary>
        public IReadOnlyDictionary<string, string> CustomIds { get; set; } = new Dictionary<string, string>(StringComparer.Ordinal);
    }
}
