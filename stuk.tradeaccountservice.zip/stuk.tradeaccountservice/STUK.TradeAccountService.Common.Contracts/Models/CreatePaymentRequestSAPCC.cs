﻿namespace STUK.TradeAccountService.Common.Contracts.Models
{
  public class CreatePaymentRequestSAPCC
  {
    public string account { get; set; } = null!;
    public string branch { get; set; } = null!;
    public PaymentsWrapper payments { get; set; } = null!;
  }
  public class PaymentsWrapper
  {
    public List<PaymentDetails> payment { get; set; } = new List<PaymentDetails>();
  }

  public class PaymentDetails
  {
    public decimal value { get; set; }
    public string reference { get; set; } = null!;
  }
}
