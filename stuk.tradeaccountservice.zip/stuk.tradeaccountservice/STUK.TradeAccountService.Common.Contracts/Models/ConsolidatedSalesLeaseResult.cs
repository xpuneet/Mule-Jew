namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the renewed expiry time for a processing lease
    /// </summary>
    public class ConsolidatedSalesLeaseResult
    {
        /// <summary>
        /// Gets or sets the renewed lease expiry time
        /// </summary>
        public DateTimeOffset LeaseExpiresOn { get; set; }
    }
}
