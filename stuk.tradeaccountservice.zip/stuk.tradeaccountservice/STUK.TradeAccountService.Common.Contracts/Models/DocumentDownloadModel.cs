﻿using Microsoft.VisualBasic;
using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class DocumentMetadata
    {
        public string? BlobUri { get; set; }
        public string? FileName { get; set; }
    }

    public class DocumentDownloadCacheEntry
    {
        public Guid Token { get; set; }
        public string Identifier { get; set; } = null!;
        public string? AdditionalParam { get; set; }
        public string DocumentType { get; set; } = null!;
        public string DownloadStatus { get; set; } = null!;
        public DateTimeOffset CreatedOn { get; set; }
        public DateTimeOffset ExpiresOn { get; set; }
        public bool IsExpired { get; set; }      
    }

    public class DocumentDownloadRequestResponse
    {
        [JsonPropertyName("token")]
        public Guid Token { get; set; }

        [JsonPropertyName("message")]
        public string Message { get; set; } = null!;

        [JsonPropertyName("expiresAt")]
        public DateTimeOffset ExpiresAt { get; set; }
    }

    public class DocumentDownloadResponse
    {
        [JsonPropertyName("message")]
        public string? Message { get; set; }

        [JsonPropertyName("fileName")]
        public string? FileName { get; set; }

        [JsonPropertyName("contentType")]
        public string? ContentType { get; set; }

        public Stream? FileContent { get; set; }
    }
}
