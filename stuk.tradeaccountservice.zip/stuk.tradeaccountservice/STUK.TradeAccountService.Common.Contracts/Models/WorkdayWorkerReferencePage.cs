namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents one Workday page of employee references
    /// </summary>
    public class WorkdayWorkerReferencePage
    {
        /// <summary>
        /// Gets or sets the employee identifiers returned on the page
        /// </summary>
        public IReadOnlyList<string> EmployeeIds { get; set; } = Array.Empty<string>();

        /// <summary>
        /// Gets or sets the one-based page number returned by Workday
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// Gets or sets the total number of pages reported by Workday
        /// </summary>
        public int TotalPages { get; set; }
    }
}
