﻿namespace STUK.TradeAccountService.Common.Contracts.Models
{
  public class CreatePaymentRequest
  {
    //Required parameters
    public string AccountCode { get; set; } = null!;
    public string BranchId { get; set; } = null!;
    public string Source { get; set; } = null!;
    public string Description { get; set; } = null!;
    public char PaymentType { get; set; }
    public decimal? PaymentAmount { get; set; }

    //Optional parameters
    public string? UserId { get; set; }
    public string? OrderReference { get; set; }
    public string? OrderNumber { get; set; }
    public string? CreditCardReference { get; set; }
    public string? CustomerPaymentReference { get; set; }
  }

  public class CreatePaymentResponse
  {
    public bool Success { get; set; }
    public int? PaymentId { get; set; }
    public required string Message { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public Guid? ApiPaymentReference { get; set; }
  }
}
