﻿using System;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public enum DocumentType
    {
        Invoice,
        Statement
    }

    public class DocumentMetadataUpdate
    {
        public DocumentType DocType { get; set; }

        public string? OriginalFileName { get; set; }
        public string? Extension { get; set; }
        public string? CalculatedFileName { get; set; }
        public string? ContentMd5 { get; set; }
        public long? ContentLength { get; set; }
        public string? BlobUri { get; set; }
        public bool? IsSynchronized { get; set; }

        // Statement-specific
        public string? OwningBranch { get; set; }
        public DateTimeOffset? StatementDate { get; set; }
        public string? AccountCode { get; set; }

        // Invoice-specific
        public string? BranchCode { get; set; }
        public DateTimeOffset? InvoiceDateTime { get; set; }
        public string? CustomerAccount { get; set; }
        public string? StandardInvoiceNo { get; set; }
    }
}