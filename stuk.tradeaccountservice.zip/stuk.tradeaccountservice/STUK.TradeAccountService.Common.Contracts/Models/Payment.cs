﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class Payment
    {
        [JsonPropertyName("accountCode")]
        public string AccountCode { get; set; } = null!;

        [JsonPropertyName("userId")]
        public string? UserId { get; set; }

        [JsonPropertyName("branchId")]
        public string BranchId { get; set; } = null!;

        [JsonPropertyName("source")]
        public string Source { get; set; } = null!;

        [JsonPropertyName("orderReference")]
        public string? OrderReference { get; set; }

        [JsonPropertyName("orderNumber")]
        public string? OrderNumber { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; } = null!;

        [JsonPropertyName("customerPaymentReference")]
        public string? CustomerPaymentReference { get; set; }

        [JsonPropertyName("creditCardReference")]
        public string? CreditCardReference { get; set; }

        [JsonPropertyName("paymentType")]
        public string PaymentType { get; set; } = null!;

        [JsonPropertyName("paymentAmount")]
        public decimal PaymentAmount { get; set; }

        [JsonPropertyName("apiPaymentReference")]
        public Guid? ApiPaymentReference { get; set; }

        [JsonPropertyName("erpPaymentReference")]
        public string? ErpPaymentReference { get; set; }
    }
}
