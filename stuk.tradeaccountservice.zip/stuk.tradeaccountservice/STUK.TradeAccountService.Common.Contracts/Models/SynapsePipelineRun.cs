namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the observed state of an Azure Synapse pipeline run
    /// </summary>
    public class SynapsePipelineRun
    {
        /// <summary>
        /// Gets or sets the Synapse pipeline run identifier
        /// </summary>
        public string RunId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Synapse run status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Synapse failure message when supplied
        /// </summary>
        public string? Message { get; set; }
    }
}
