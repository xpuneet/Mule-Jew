namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Identifies the persisted processing stage of a Workday-to-Concur run
    /// </summary>
    public enum WorkdayConcurRunStage
    {
        /// <summary>
        /// The run has been created with a fixed Workday window
        /// </summary>
        Pending,

        /// <summary>
        /// The integration is collecting the TM1 and Workday inputs
        /// </summary>
        CollectingInputs,

        /// <summary>
        /// Synapse is transforming the prepared input files
        /// </summary>
        Transforming,

        /// <summary>
        /// The generated output files are being encrypted and delivered
        /// </summary>
        Delivering,

        /// <summary>
        /// Successfully delivered input and output files are being moved
        /// </summary>
        MovingFiles,

        /// <summary>
        /// The Workday query returned no worker detail rows for the fixed window
        /// </summary>
        NoData,

        /// <summary>
        /// The run and its committed Workday watermark have completed
        /// </summary>
        Completed,

        /// <summary>
        /// The run stopped at a recoverable processing boundary
        /// </summary>
        Failed
    }
}
