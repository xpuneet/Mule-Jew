namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents claimed work for delivering a consolidated invoice to Salesforce
    /// </summary>
    public class ConsolidatedSalesforceWork
    {
        /// <summary>
        /// Gets or sets the work identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the canonical invoice identifier
        /// </summary>
        public Guid ConsolidatedInvoiceId { get; set; }

        /// <summary>
        /// Gets or sets the processing correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the current status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the expected line count
        /// </summary>
        public int ExpectedLineCount { get; set; }

        /// <summary>
        /// Gets or sets the attempt count
        /// </summary>
        public int AttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible processing time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }

        /// <summary>
        /// Gets or sets the durable UTC time at which the Salesforce cool-off started
        /// </summary>
        public DateTimeOffset SalesforceCooloffStartedOn { get; set; }

        /// <summary>
        /// Gets or sets the configured Salesforce cool-off duration captured for this work item
        /// </summary>
        public int SalesforceCooloffHours { get; set; }

        /// <summary>
        /// Gets or sets the UTC time at which Salesforce synchronisation becomes eligible
        /// </summary>
        public DateTimeOffset SalesforceEligibleOn { get; set; }

        /// <summary>
        /// Gets or sets the current claim token
        /// </summary>
        public Guid? ClaimToken { get; set; }

        /// <summary>
        /// Gets or sets the lease owner
        /// </summary>
        public string? LeaseOwner { get; set; }

        /// <summary>
        /// Gets or sets the lease expiry time
        /// </summary>
        public DateTimeOffset? LeaseExpiresOn { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce order identifier
        /// </summary>
        public string? SalesforceOrderId { get; set; }

        /// <summary>
        /// Gets or sets the last error category
        /// </summary>
        public string? LastErrorCategory { get; set; }

        /// <summary>
        /// Gets or sets the last error message
        /// </summary>
        public string? LastErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the creation time
        /// </summary>
        public DateTimeOffset CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the last update time
        /// </summary>
        public DateTimeOffset UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the completion time
        /// </summary>
        public DateTimeOffset? CompletedOn { get; set; }

        /// <summary>
        /// Gets or sets the consolidated invoice number
        /// </summary>
        public string ConsolidatedInvoiceNumber { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the customer account code
        /// </summary>
        public string? CustomerAccountCode { get; set; }
    }
}
