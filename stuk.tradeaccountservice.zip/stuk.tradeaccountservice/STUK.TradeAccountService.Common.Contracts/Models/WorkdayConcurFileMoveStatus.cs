using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Identifies the persisted state of one Synapse copy or delete operation
    /// </summary>
    [JsonConverter(typeof(JsonStringEnumConverter<WorkdayConcurFileMoveStatus>))]
    public enum WorkdayConcurFileMoveStatus
    {
        /// <summary>
        /// The operation has not been attempted
        /// </summary>
        Pending,

        /// <summary>
        /// The intent to start Synapse is persisted but its run identifier is not yet recorded
        /// </summary>
        Starting,

        /// <summary>
        /// Synapse accepted the operation and its run identifier is persisted
        /// </summary>
        InProgress,

        /// <summary>
        /// The operation and its required validation succeeded
        /// </summary>
        Succeeded,

        /// <summary>
        /// Synapse reported a terminal operation failure
        /// </summary>
        Failed,

        /// <summary>
        /// Synapse reported that the operation was cancelled
        /// </summary>
        Cancelled,

        /// <summary>
        /// Synapse succeeded but the required Blob result was invalid
        /// </summary>
        ValidationFailed
    }
}
