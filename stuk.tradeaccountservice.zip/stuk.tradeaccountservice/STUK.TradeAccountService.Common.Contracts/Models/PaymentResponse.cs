﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class PaymentResponse
    {
        [JsonPropertyName("payment")]
        public Payment? Payment { get; set; }
    }
}
