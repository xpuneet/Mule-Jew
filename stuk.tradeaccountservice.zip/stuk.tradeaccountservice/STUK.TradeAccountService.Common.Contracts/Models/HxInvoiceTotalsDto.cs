namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the totals reported for an HX invoice
    /// </summary>
    public class HxInvoiceTotalsDto
    {
        /// <summary>
        /// Gets or sets the number of lines reported by HX
        /// </summary>
        public int? NumberOfLines { get; set; }

        /// <summary>
        /// Gets or sets the number of tax rates represented on the invoice
        /// </summary>
        public int? NumberOfTaxRates { get; set; }

        /// <summary>
        /// Gets or sets the sum of the invoice line values
        /// </summary>
        public decimal? LineValueTotal { get; set; }

        /// <summary>
        /// Gets or sets the total value on which tax is charged
        /// </summary>
        public decimal? TaxableTotal { get; set; }

        /// <summary>
        /// Gets or sets the total tax charged
        /// </summary>
        public decimal? TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets the net payment total
        /// </summary>
        public decimal? NetPaymentTotal { get; set; }

        /// <summary>
        /// Gets or sets the gross payment total
        /// </summary>
        public decimal? GrossPaymentTotal { get; set; }
    }
}
