namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Records one restart-safe Synapse copy-then-delete operation
    /// </summary>
    public class WorkdayConcurFileMove
    {
        /// <summary>
        /// Gets or sets the immutable source Blob identity
        /// </summary>
        public WorkdayConcurFileIdentity SourceFile { get; set; } = new();

        /// <summary>
        /// Gets or sets the source path containing the Blob container and virtual folder
        /// </summary>
        public string SourcePath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the source Blob filename
        /// </summary>
        public string SourceFileName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the destination path containing the Blob container and virtual folder
        /// </summary>
        public string DestinationPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the timestamped destination Blob filename
        /// </summary>
        public string DestinationFileName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the persisted copy state
        /// </summary>
        public WorkdayConcurFileMoveStatus CopyStatus { get; set; }

        /// <summary>
        /// Gets or sets the Synapse copy run identifier
        /// </summary>
        public string? CopySynapseRunId { get; set; }

        /// <summary>
        /// Gets or sets when the Synapse copy was started
        /// </summary>
        public DateTimeOffset? CopyStartedOn { get; set; }

        /// <summary>
        /// Gets or sets the validated copied Blob identity
        /// </summary>
        public WorkdayConcurFileIdentity? DestinationFile { get; set; }

        /// <summary>
        /// Gets or sets the persisted source-delete state
        /// </summary>
        public WorkdayConcurFileMoveStatus DeleteStatus { get; set; }

        /// <summary>
        /// Gets or sets the Synapse delete run identifier
        /// </summary>
        public string? DeleteSynapseRunId { get; set; }

        /// <summary>
        /// Gets or sets when the Synapse delete was started
        /// </summary>
        public DateTimeOffset? DeleteStartedOn { get; set; }

        /// <summary>
        /// Gets or sets the last terminal failure or validation message
        /// </summary>
        public string? FailureMessage { get; set; }
    }
}
