namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the durable processing state for a staged HX file
    /// </summary>
    public class ConsolidatedSalesSourceItem
    {
        /// <summary>
        /// Gets or sets the source-item identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the processing correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the source-system name
        /// </summary>
        public string SourceSystem { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Blob container name
        /// </summary>
        public string BlobContainer { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the path of the source file within the Blob container
        /// </summary>
        public string BlobPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the original source-file name
        /// </summary>
        public string SourceFileName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the source content length in bytes
        /// </summary>
        public long ContentLength { get; set; }

        /// <summary>
        /// Gets or sets the Blob last-modified time that identifies this file version
        /// </summary>
        public DateTimeOffset BlobLastModifiedOn { get; set; }

        /// <summary>
        /// Gets or sets the source content checksum
        /// </summary>
        public string? ContentChecksum { get; set; }

        /// <summary>
        /// Gets or sets the Blob entity tag identifying the exact source version
        /// </summary>
        public string ETag { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the current processing status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the number of failed processing attempts
        /// </summary>
        public int RetryCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible processing time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }

        /// <summary>
        /// Gets or sets the token that owns the current processing lease
        /// </summary>
        public Guid? ClaimToken { get; set; }

        /// <summary>
        /// Gets or sets the current lease owner
        /// </summary>
        public string? LeaseOwner { get; set; }

        /// <summary>
        /// Gets or sets the time at which the current lease expires
        /// </summary>
        public DateTimeOffset? LeaseExpiresOn { get; set; }

        /// <summary>
        /// Gets or sets whether sanitisation was required to parse the source file
        /// </summary>
        public bool SanitisationUsed { get; set; }

        /// <summary>
        /// Gets or sets the time at which the source item was discovered
        /// </summary>
        public DateTimeOffset DiscoveredOn { get; set; }

        /// <summary>
        /// Gets or sets the first UTC time at which Trade Account successfully read the complete source file
        /// </summary>
        public DateTimeOffset? FirstReadOn { get; set; }

        /// <summary>
        /// Gets or sets the time at which processing completed
        /// </summary>
        public DateTimeOffset? CompletedOn { get; set; }

        /// <summary>
        /// Gets or sets whether this registration created a new source item
        /// </summary>
        public bool IsNew { get; set; }
    }
}
