using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Identifies the persisted state of encrypted Concur delivery
    /// </summary>
    [JsonConverter(typeof(JsonStringEnumConverter<WorkdayConcurDeliveryStatus>))]
    public enum WorkdayConcurDeliveryStatus
    {
        /// <summary>
        /// Every encrypted file is staged and no Synapse start has been attempted
        /// </summary>
        Staged,

        /// <summary>
        /// The intent to start Synapse is persisted but its run identifier is not yet recorded
        /// </summary>
        Starting,

        /// <summary>
        /// Synapse accepted the delivery and its run identifier is persisted
        /// </summary>
        InProgress,

        /// <summary>
        /// Synapse delivered every staged file and removed it from active staging
        /// </summary>
        Succeeded,

        /// <summary>
        /// Synapse reported a terminal delivery failure
        /// </summary>
        Failed,

        /// <summary>
        /// Synapse reported that delivery was cancelled
        /// </summary>
        Cancelled,

        /// <summary>
        /// Synapse succeeded but the required post-delivery state was not present
        /// </summary>
        ValidationFailed
    }
}
