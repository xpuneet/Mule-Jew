namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Identifies one validated Workday-to-Concur Blob without copying its content
    /// </summary>
    public class WorkdayConcurFileIdentity
    {
        /// <summary>
        /// Gets or sets the Blob path including its container
        /// </summary>
        public string Path { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Blob content length
        /// </summary>
        public long ContentLength { get; set; }

        /// <summary>
        /// Gets or sets the Blob entity tag
        /// </summary>
        public string ETag { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Blob service last-modified time
        /// </summary>
        public DateTimeOffset LastModifiedOn { get; set; }
    }
}
