namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents customer and job details associated with an HX invoice line
    /// </summary>
    public class HxCustomerInformationDto
    {
        /// <summary>
        /// Gets or sets the customer's job number
        /// </summary>
        public string? JobNumber { get; set; }

        /// <summary>
        /// Gets or sets the address at which the job is being performed
        /// </summary>
        public HxAddressDto? JobAddress { get; set; }

        /// <summary>
        /// Gets or sets the customer's contract number
        /// </summary>
        public string? ContractNumber { get; set; }

        /// <summary>
        /// Gets or sets the buyer location value supplied by HX
        /// </summary>
        public string? BuyerLocation { get; set; }

        /// <summary>
        /// Gets or sets the operative associated with the order
        /// </summary>
        public string? Operative { get; set; }

        /// <summary>
        /// Gets or sets the site code supplied by HX
        /// </summary>
        public string? SiteCode { get; set; }

        /// <summary>
        /// Gets or sets the plot number supplied by HX
        /// </summary>
        public string? PlotNumber { get; set; }

        /// <summary>
        /// Gets or sets the vehicle registration associated with the order
        /// </summary>
        public string? VehicleRegistration { get; set; }

        /// <summary>
        /// Gets or sets the house type supplied by HX
        /// </summary>
        public string? HouseType { get; set; }

        /// <summary>
        /// Gets or sets the product group supplied by HX
        /// </summary>
        public string? ProductGroup { get; set; }

        /// <summary>
        /// Gets or sets the source order-authorisation value
        /// </summary>
        public string? OrderAuthorised { get; set; }
    }
}
