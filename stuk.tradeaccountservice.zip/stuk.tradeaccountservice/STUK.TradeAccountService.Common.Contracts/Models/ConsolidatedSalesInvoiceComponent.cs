namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents an ordinary invoice component within a consolidated invoice
    /// </summary>
    public class ConsolidatedSalesInvoiceComponent
    {
        /// <summary>
        /// Gets or sets the component identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the stable component reference key
        /// </summary>
        public string ComponentReferenceKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the ordinary invoice number
        /// </summary>
        public string? StandardInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets the branch code
        /// </summary>
        public string? BranchCode { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the buyer order number
        /// </summary>
        public string? BuyersOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier order reference
        /// </summary>
        public string? SuppliersOrderReference { get; set; }
    }
}
