namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Describes one dataset and completion-token write to Data Lake
    /// </summary>
    public class DataLakeExportWriteRequest
    {
        /// <summary>
        /// Gets or sets the target Data Lake filesystem
        /// </summary>
        public string FileSystem { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the dataset directory
        /// </summary>
        public string DatasetDirectory { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the timestamped dataset filename
        /// </summary>
        public string DatasetFileName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the completion-token directory
        /// </summary>
        public string TokenDirectory { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the completion-token filename
        /// </summary>
        public string TokenFileName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the completed token bytes
        /// </summary>
        public byte[] TokenContent { get; set; } = [];

        /// <summary>
        /// Gets or sets the expected generated dataset length
        /// </summary>
        public long ContentLength { get; set; }

        /// <summary>
        /// Gets or sets the generated dataset row count
        /// </summary>
        public long RowCount { get; set; }

        /// <summary>
        /// Gets or sets the lowercase SHA-256 dataset hash
        /// </summary>
        public string ContentHash { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the export run identifier
        /// </summary>
        public Guid ExportRunId { get; set; }

        /// <summary>
        /// Gets or sets the destination work identifier
        /// </summary>
        public Guid ExportDestinationId { get; set; }

        /// <summary>
        /// Gets or sets the end-to-end correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }
    }
}
