namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents destination state returned after a failed delivery attempt
    /// </summary>
    public class ConsolidatedSalesExportDestinationFailureResult
    {
        /// <summary>
        /// Gets or sets the resulting delivery status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the resulting delivery-attempt count
        /// </summary>
        public int AttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible delivery time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }
    }
}
