namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a decimal source value with its associated code
    /// </summary>
    public class HxCodedDecimalDto
    {
        /// <summary>
        /// Gets or sets the source code associated with the value
        /// </summary>
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the decimal source value
        /// </summary>
        public decimal? Value { get; set; }
    }
}
