namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents tax values reported for an HX invoice line
    /// </summary>
    public class HxTaxDto
    {
        /// <summary>
        /// Gets or sets the coded tax percentage applied to the line
        /// </summary>
        public HxCodedDecimalDto? TaxRate { get; set; }

        /// <summary>
        /// Gets or sets the tax value charged for the line
        /// </summary>
        public decimal? TaxValue { get; set; }
    }
}
