namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the result of committing a canonical consolidated invoice
    /// </summary>
    public class ConsolidatedSalesCommitResult
    {
        /// <summary>
        /// Gets or sets the canonical consolidated-invoice identifier
        /// </summary>
        public Guid ConsolidatedInvoiceId { get; set; }

        /// <summary>
        /// Gets or sets whether the operation created a new invoice
        /// </summary>
        public bool IsNew { get; set; }
    }
}
