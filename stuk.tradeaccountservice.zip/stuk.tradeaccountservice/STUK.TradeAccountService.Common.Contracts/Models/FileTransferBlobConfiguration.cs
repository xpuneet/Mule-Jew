namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the existing Blob connection used by the generic Synapse pipeline
    /// </summary>
    public class FileTransferBlobConfiguration
    {
        /// <summary>
        /// Gets or sets the Azure Blob service endpoint
        /// </summary>
        public string ServiceEndPoint { get; set; } = string.Empty;
    }
}
