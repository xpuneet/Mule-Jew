namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents claimed delivery work for one completed export snapshot
    /// </summary>
    public class ConsolidatedSalesExportDestinationWork
    {
        /// <summary>
        /// Gets or sets the destination work identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the parent export run identifier
        /// </summary>
        public Guid ExportRunId { get; set; }

        /// <summary>
        /// Gets or sets the parent logical run key
        /// </summary>
        public string LogicalRunKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the end-to-end correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the calendar year represented by the export
        /// </summary>
        public int ExportYear { get; set; }

        /// <summary>
        /// Gets or sets the completed snapshot row count
        /// </summary>
        public long? ExtractedRowCount { get; set; }

        /// <summary>
        /// Gets or sets the destination name
        /// </summary>
        public string Destination { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the current delivery status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the delivery-attempt count
        /// </summary>
        public int AttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the delivery-attempt count within the current automatic or approved replay cycle
        /// </summary>
        public int RetryCycleAttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible delivery time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }

        /// <summary>
        /// Gets or sets the current delivery claim token
        /// </summary>
        public Guid? ClaimToken { get; set; }

        /// <summary>
        /// Gets or sets the delivery lease owner
        /// </summary>
        public string? LeaseOwner { get; set; }

        /// <summary>
        /// Gets or sets the delivery lease expiry time
        /// </summary>
        public DateTimeOffset? LeaseExpiresOn { get; set; }

        /// <summary>
        /// Gets or sets the generated file name
        /// </summary>
        public string? FileName { get; set; }

        /// <summary>
        /// Gets or sets the destination or staging path
        /// </summary>
        public string? FilePath { get; set; }

        /// <summary>
        /// Gets or sets the generated-file content hash
        /// </summary>
        public string? ContentHash { get; set; }

        /// <summary>
        /// Gets or sets the generated-file row count
        /// </summary>
        public long? FileRowCount { get; set; }

        /// <summary>
        /// Gets or sets the generated-file byte count
        /// </summary>
        public long? FileByteCount { get; set; }

        /// <summary>
        /// Gets or sets the external platform execution identifier
        /// </summary>
        public string? ExternalExecutionId { get; set; }

        /// <summary>
        /// Gets or sets the last delivery error category
        /// </summary>
        public string? LastErrorCategory { get; set; }

        /// <summary>
        /// Gets or sets the last delivery error detail
        /// </summary>
        public string? LastErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the creation time
        /// </summary>
        public DateTimeOffset CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the last update time
        /// </summary>
        public DateTimeOffset UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the delivery completion time
        /// </summary>
        public DateTimeOffset? CompletedOn { get; set; }
    }
}
