namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents one ordered row in the completed Salesforce export snapshot
    /// </summary>
    public class ConsolidatedSalesExportRow
    {
        /// <summary>
        /// Gets or sets the stable one-based row sequence
        /// </summary>
        public long RowSequence { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce account number
        /// </summary>
        public string? AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce invoice number
        /// </summary>
        public string? InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets the invoice date
        /// </summary>
        public DateOnly? InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note line number
        /// </summary>
        public string? DeliveryNoteLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the despatch date
        /// </summary>
        public DateOnly? DespatchDate { get; set; }

        /// <summary>
        /// Gets or sets the product code
        /// </summary>
        public string? ProductCode { get; set; }

        /// <summary>
        /// Gets or sets the invoiced quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Gets or sets the total line price
        /// </summary>
        public decimal? TotalPrice { get; set; }
    }
}
