﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class Order
    {
        [JsonPropertyName("header")]
        public OrderHeader Header { get; set; } = new();

        [JsonPropertyName("lines")]
        public List<OrderLine> Lines { get; set; } = [];
    }

    public class OrderHeader
    {
        [JsonPropertyName("orderId")]
        public string? OrderId { get; set; }

        [JsonPropertyName("source")]
        public string? Source { get; set; }

        [JsonPropertyName("branchCode")]
        public string? BranchCode { get; set; }

        [JsonPropertyName("customerAccount")]
        public string? CustomerAccount { get; set; }

        [JsonPropertyName("accountType")]
        public string? AccountType { get; set; }

        [JsonPropertyName("orderNo")]
        public int OrderNo { get; set; }

        [JsonPropertyName("orderCategory")]
        public string? OrderCategory { get; set; }

        [JsonPropertyName("deliveryMethod")]
        public string? DeliveryMethod { get; set; }

        [JsonPropertyName("orderType")]
        public string? OrderType { get; set; }

        [JsonPropertyName("custOrderReference")]
        public string? CustOrderReference { get; set; }

        [JsonPropertyName("custOrderReference2")]
        public string? CustOrderReference2 { get; set; }

        [JsonPropertyName("erpReferenceSwapped")]
        public bool? ErpReferenceSwapped { get; set; }

        [JsonPropertyName("requiredByDateTime")]
        public DateTimeOffset? RequiredByDateTime { get; set; }

        [JsonPropertyName("requestedDateTime")]
        public DateTimeOffset? RequestedDateTime { get; set; }

        [JsonPropertyName("createdDateTime")]
        public DateTimeOffset? CreatedDateTime { get; set; }

        [JsonPropertyName("originalOrderDateTime")]
        public DateTimeOffset? OriginalOrderDateTime { get; set; }

        [JsonPropertyName("orderTotalValue")]
        public decimal? OrderTotalValue { get; set; }

        [JsonPropertyName("orderTotalVAT")]
        public decimal? OrderTotalVat { get; set; }

        [JsonPropertyName("instructions")]
        public string? Instructions { get; set; }

        [JsonPropertyName("internalInstructions")]
        public string? InternalInstructions { get; set; }

        [JsonPropertyName("suspendOrder")]
        public bool? SuspendOrder { get; set; }

        [JsonPropertyName("suspendUser")]
        public string? SuspendUser { get; set; }

        [JsonPropertyName("suspendMessage")]
        public string? SuspendMessage { get; set; }

        [JsonPropertyName("adviceMethod")]
        public string? AdviceMethod { get; set; }

        [JsonPropertyName("isWebOrder")]
        public bool? IsWebOrder { get; set; }

        [JsonPropertyName("contacts")]
        public List<OrderContact> Contacts { get; set; } = [];

        [JsonPropertyName("address")]
        public List<OrderAddress> Addresses { get; set; } = [];

        [JsonPropertyName("payments")]
        public List<OrderPayment> Payments { get; set; } = [];

        [JsonPropertyName("extensionAttributes")]
        public List<OrderExtensionAttribute> ExtensionAttributes { get; set; } = [];

        [JsonPropertyName("datacapture")]
        public List<OrderDataCapture> DataCaptures { get; set; } = [];
    }

    public class OrderContact
    {
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        // JSON field is "id" (int), matching Orders_Contacts.contactId in the DB
        [JsonPropertyName("id")]
        public int? ContactId { get; set; }

        [JsonPropertyName("email")]
        public string? Email { get; set; }

        [JsonPropertyName("phone")]
        public string? Phone { get; set; }

        [JsonPropertyName("mobile")]
        public string? Mobile { get; set; }
    }

    public class OrderAddress
    {
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("recipientName")]
        public string? RecipientName { get; set; }

        [JsonPropertyName("line1")]
        public string? Line1 { get; set; }

        [JsonPropertyName("line2")]
        public string? Line2 { get; set; }

        [JsonPropertyName("line3")]
        public string? Line3 { get; set; }

        [JsonPropertyName("line4")]
        public string? Line4 { get; set; }

        [JsonPropertyName("postcode")]
        public string? Postcode { get; set; }
    }

    public class OrderPayment
    {
        [JsonPropertyName("paymentType")]
        public string? PaymentType { get; set; }

        [JsonPropertyName("value")]
        public decimal? Value { get; set; }

        [JsonPropertyName("reference")]
        public string? Reference { get; set; }
    }

    public class OrderExtensionAttribute
    {
        [JsonPropertyName("name")]
        public string Name { get; set; } = null!;

        [JsonPropertyName("value")]
        public string? Value { get; set; }
    }

    public class OrderDataCapture
    {
        [JsonPropertyName("key")]
        public string Key { get; set; } = null!;

        [JsonPropertyName("value")]
        public string? Value { get; set; }

        [JsonPropertyName("position")]
        public int? Position { get; set; }
    }

    public class OrderLine
    {
        [JsonPropertyName("invoiceHeaderId")]
        public string InvoiceHeaderId { get; set; } = null!;

        [JsonPropertyName("orderNo")]
        public int OrderNo { get; set; }

        [JsonPropertyName("lineNumber")]
        public string LineNumber { get; set; } = null!;

        [JsonPropertyName("itemCode")]
        public string? ItemCode { get; set; }

        [JsonPropertyName("originalQuantity")]
        public int? OriginalQuantity { get; set; }

        [JsonPropertyName("manufacturer")]
        public string? Manufacturer { get; set; }

        [JsonPropertyName("specialDescription")]
        public string? SpecialDescription { get; set; }

        [JsonPropertyName("orderCategory")]
        public string? OrderCategory { get; set; }

        [JsonPropertyName("deliveryMethod")]
        public string? DeliveryMethod { get; set; }

        [JsonPropertyName("returnReasonCode")]
        public string? ReturnReasonCode { get; set; }

        [JsonPropertyName("alternateItemCode")]
        public string? AlternateItemCode { get; set; }

        [JsonPropertyName("goodsValue")]
        public decimal? GoodsValue { get; set; }

        [JsonPropertyName("pieces")]
        public int? Pieces { get; set; }

        [JsonPropertyName("supplierCode")]
        public string? SupplierCode { get; set; }

        [JsonPropertyName("defaultSupplier")]
        public string? DefaultSupplier { get; set; }

        [JsonPropertyName("quoteBranch")]
        public int? QuoteBranch { get; set; }

        [JsonPropertyName("quoteNumber")]
        public int? QuoteNumber { get; set; }

        [JsonPropertyName("requiredByDateTime")]
        public DateTimeOffset? RequiredByDateTime { get; set; }

        [JsonPropertyName("expectedByDateTime")]
        public DateTimeOffset? ExpectedByDateTime { get; set; }

        [JsonPropertyName("internalInstructions")]
        public string? InternalInstructions { get; set; }

        [JsonPropertyName("purchaseorder")]
        public int? PurchaseOrder { get; set; }

        [JsonPropertyName("pricing")]
        public OrderLinePricing? Pricing { get; set; }

        [JsonPropertyName("tally")]
        public List<OrderLineTally> Tally { get; set; } = [];

        [JsonPropertyName("extensionAttributes")]
        public List<OrderLineExtensionAttribute> ExtensionAttributes { get; set; } = [];

        [JsonPropertyName("statusCode")]
        public string? StatusCode { get; set; }

        [JsonPropertyName("statusDesc")]
        public string? StatusDesc { get; set; }

        [JsonPropertyName("sqlCreatedDateTime")]
        public DateTimeOffset? SqlCreatedDateTime { get; set; }

    }

    public class OrderLinePricing
    {
        [JsonPropertyName("unitForSale")]
        public string? UnitForSale { get; set; }

        [JsonPropertyName("listPrice")]
        public decimal? ListPrice { get; set; }

        [JsonPropertyName("vatCode")]
        public string? VatCode { get; set; }

        [JsonPropertyName("vatAmount")]
        public decimal? VatAmount { get; set; }
    }

    public class OrderLineTally
    {
        [JsonPropertyName("tallyQuantity")]
        public decimal? TallyQuantity { get; set; }

        [JsonPropertyName("length")]
        public decimal? Length { get; set; }

        [JsonPropertyName("width")]
        public decimal? Width { get; set; }
    }

    public class OrderLineExtensionAttribute
    {
        [JsonPropertyName("name")]
        public string Name { get; set; } = null!;

        [JsonPropertyName("value")]
        public string? Value { get; set; }
    }
}