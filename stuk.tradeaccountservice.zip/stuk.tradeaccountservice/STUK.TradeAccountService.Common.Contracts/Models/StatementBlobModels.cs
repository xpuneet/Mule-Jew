﻿namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class StatementHeaderData
    {
        public string AccountCode { get; set; } = null!;
        public string? OwningBranch { get; set; }
        public DateTime StatementDate { get; set; }
        public string? StatementMonth { get; set; }
        public DateTime? EndOfNextMonth { get; set; }
        public string CurrencyCode { get; set; } = null!;
        public int? LineCount { get; set; }
        public decimal? TotalVAT { get; set; }
        public decimal? SettDiscountTotal { get; set; }
        public decimal? StatementTotal { get; set; }
        public decimal? StatementDiscountTotal { get; set; }
        public decimal? QueriedBalance { get; set; }
        public decimal? BalanceAfterQueries { get; set; }
        public decimal? VATThisPeriod { get; set; }
    }

    public class StatementMetadataData
    {
        // Parent natural key – used inside the SP to resolve statementHeaderId
        public string AccountCode { get; set; } = null!;
        public DateTime StatementDate { get; set; }

        public string? OriginalFileName { get; set; }
        public string? Extension { get; set; }
        public string? CalculatedFileName { get; set; }
        public string? ContentMd5 { get; set; }
        public long? ContentLength { get; set; }
        public string? BlobUri { get; set; }
        public string? CreatedBy { get; set; }
    }
}
