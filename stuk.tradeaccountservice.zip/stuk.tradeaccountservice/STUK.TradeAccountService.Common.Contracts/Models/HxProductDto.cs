namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents product details supplied for an HX invoice line
    /// </summary>
    public class HxProductDto
    {
        /// <summary>
        /// Gets or sets the supplier's product code
        /// </summary>
        public string? SuppliersProductCode { get; set; }

        /// <summary>
        /// Gets or sets the source product description
        /// </summary>
        public string? Description { get; set; }
    }
}
