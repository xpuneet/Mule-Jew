﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class ColumbusStatementHeader
    {
        public long StatementHeaderId { get; set; }
        public required string AccountCode { get; set; }
        public DateTime StatementDate { get; set; }
        public string? StatementMonth { get; set; }
        public DateTime EndOfNextMonth { get; set; }
        public string? CurrencyCode { get; set; }
        public required string OwningBranch { get; set; }

        public int? LineCount { get; set; }
        public decimal? TotalVAT { get; set; }
        public decimal? SettDiscountTotal { get; set; }
        public decimal? StatementTotal { get; set; }
        public decimal? StatementDiscountTotal { get; set; }
        public decimal? QueriedBalance { get; set; }
        public decimal? BalanceAfterQueries { get; set; }
        public decimal? VatThisPeriod { get; set; }
        public bool IsSynchronized { get; set; }
    }

    public class ColumbusStatementHeaderMetadataRequest
    {
        public long StatementHeaderId { get; set; }
        public string? OriginalFileName { get; set; }
        public string? Extension { get; set; }
        public string? CalculatedFileName { get; set; }
        public string? ContentMd5 { get; set; }
        public long? ContentLength { get; set; }
        public string? BlobUri { get; set; }
        public DateTimeOffset? CreatedOn { get; set; }
        public string? CreatedBy { get; set; }
        public DateTimeOffset? LastDownloaded { get; set; }
        public string? DownloadedBy { get; set; }
        public bool IsSynchronized { get; set; }

    }
}