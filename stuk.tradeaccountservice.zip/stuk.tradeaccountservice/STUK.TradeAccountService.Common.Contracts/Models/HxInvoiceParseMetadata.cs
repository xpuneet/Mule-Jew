namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Describes how an HX consolidated invoice stream was prepared for parsing
    /// </summary>
    public class HxInvoiceParseMetadata
    {
        /// <summary>
        /// Gets or sets whether the approved sanitisation fallback was required
        /// </summary>
        public bool SanitisationUsed { get; set; }
    }
}
