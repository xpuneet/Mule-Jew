namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents an address supplied in an HX invoice
    /// </summary>
    public class HxAddressDto
    {
        /// <summary>
        /// Gets or sets the unstructured address lines in source order
        /// </summary>
        public List<string> AddressLines { get; set; } = [];

        /// <summary>
        /// Gets or sets the street value
        /// </summary>
        public string? Street { get; set; }

        /// <summary>
        /// Gets or sets the city value
        /// </summary>
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the county, region or state value
        /// </summary>
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postcode value
        /// </summary>
        public string? PostCode { get; set; }
    }
}
