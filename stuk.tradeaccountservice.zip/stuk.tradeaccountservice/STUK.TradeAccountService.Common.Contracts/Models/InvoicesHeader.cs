﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class InvoiceDocument
    {
        [JsonPropertyName("header")]

        public InvoiceHeader Header { get; set; } = new();

        [JsonPropertyName("orders")]
        public List<Order> Orders { get; set; } = [];
    }
    public class InvoiceHeader
    {
        [JsonPropertyName("metadata")]
        public InvoiceMetadata Metadata { get; set; } = new();

        [JsonPropertyName("id")]
        public string Id { get; set; } = null!;

        [JsonPropertyName("branchCode")]
        public string BranchCode { get; set; } = null!;

        [JsonPropertyName("customerAccount")]
        public string CustomerAccount { get; set; } = null!;

        [JsonPropertyName("accountType")]
        public string? AccountType { get; set; }

        [JsonPropertyName("searchBrand")]
        public string? SearchBrand { get; set; }

        [JsonPropertyName("invoiceBrand")]
        public string? InvoiceBrand { get; set; }

        [JsonPropertyName("standardInvoiceNo")]
        public string StandardInvoiceNo { get; set; } = null!;

        [JsonPropertyName("consolidatedInvoiceNo")]
        public string? ConsolidatedInvoiceNo { get; set; }

        [JsonPropertyName("consolidatedInvoiceDate")]
        public DateTimeOffset? ConsolidatedInvoiceDate { get; set; }

        [JsonPropertyName("invoiceDateTime")]
        public DateTimeOffset? InvoiceDateTime { get; set; }

        [JsonPropertyName("dueDate")]
        public DateTimeOffset? DueDate { get; set; }

        [JsonPropertyName("documentType")]
        public string? DocumentType { get; set; }

        [JsonPropertyName("netAmount")]
        public decimal? NetAmount { get; set; }

        [JsonPropertyName("vatAmount")]
        public decimal? VatAmount { get; set; }

        [JsonPropertyName("totalAmount")]
        public decimal? TotalAmount { get; set; }

        [JsonPropertyName("vatRate")]
        public decimal? VatRate { get; set; }

        [JsonPropertyName("address")]
        public List<InvoiceAddress> Addresses { get; set; } = [];
    }

    public class InvoiceMetadata
    {
        [JsonPropertyName("originalFileName")]
        public string? OriginalFileName { get; set; }

        [JsonPropertyName("extension")]
        public string? Extension { get; set; }

        [JsonPropertyName("calculatedFileName")]
        public string? CalculatedFileName { get; set; }

        [JsonPropertyName("contentMd5")]
        public string? ContentMd5 { get; set; }

        [JsonPropertyName("contentLength")]
        public int? ContentLength { get; set; }

        [JsonPropertyName("blobUri")]
        public string? BlobUri { get; set; }

        [JsonPropertyName("createdOn")]
        public DateTimeOffset CreatedOn { get; set; }

        [JsonPropertyName("createdBy")]
        public string? CreatedBy { get; set; }

        [JsonPropertyName("lastDownloaded")]
        public DateTimeOffset? LastDownloaded { get; set; }

        [JsonPropertyName("downloadedBy")]
        public string? DownloadedBy { get; set; }
    }

    public class InvoiceAddress
    {
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("recipientName")]
        public string? RecipientName { get; set; }

        [JsonPropertyName("line1")]
        public string? Line1 { get; set; }

        [JsonPropertyName("line2")]
        public string? Line2 { get; set; }

        [JsonPropertyName("line3")]
        public string? Line3 { get; set; }

        [JsonPropertyName("line4")]
        public string? Line4 { get; set; }

        [JsonPropertyName("postcode")]
        public string? Postcode { get; set; }

    }
}
