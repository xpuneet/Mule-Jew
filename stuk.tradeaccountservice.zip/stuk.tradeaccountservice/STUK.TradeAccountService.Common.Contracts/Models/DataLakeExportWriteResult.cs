namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Describes a completed Data Lake dataset and token write
    /// </summary>
    public class DataLakeExportWriteResult
    {
        /// <summary>
        /// Gets or sets the complete dataset path
        /// </summary>
        public string DatasetPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the complete completion-token path
        /// </summary>
        public string TokenPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets whether the same dataset was already present during a retry
        /// </summary>
        public bool DatasetAlreadyExists { get; set; }
    }
}
