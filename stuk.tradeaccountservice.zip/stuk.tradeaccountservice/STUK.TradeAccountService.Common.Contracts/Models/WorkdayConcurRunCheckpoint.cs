namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Records the restart-safe file and external-run state of one Workday-to-Concur run
    /// </summary>
    public class WorkdayConcurRunCheckpoint
    {
        /// <summary>
        /// Gets or sets the managed TM1 pickup state
        /// </summary>
        public WorkdayConcurTm1Checkpoint? Tm1 { get; set; }

        /// <summary>
        /// Gets or sets the staged Workday employee file identity
        /// </summary>
        public WorkdayConcurFileIdentity? WorkdayEmployeeFile { get; set; }

        /// <summary>
        /// Gets or sets the number of employees written to the staged file
        /// </summary>
        public int? WorkdayEmployeeCount { get; set; }

        /// <summary>
        /// Gets or sets the Concur transformation state and selected output files
        /// </summary>
        public WorkdayConcurTransformationCheckpoint? Transformation { get; set; }

        /// <summary>
        /// Gets or sets the encrypted Concur delivery state
        /// </summary>
        public WorkdayConcurDeliveryCheckpoint? Delivery { get; set; }

        /// <summary>
        /// Gets or sets the post-delivery output and input move state
        /// </summary>
        public WorkdayConcurHousekeepingCheckpoint? Housekeeping { get; set; }
    }
}
