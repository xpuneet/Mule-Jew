namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents HX order type, category and delivery method classifications
    /// </summary>
    public class HxSupplierOrderFlagsDto
    {
        /// <summary>
        /// Gets or sets the coded order type
        /// </summary>
        public HxCodedValueDto? OrderType { get; set; }

        /// <summary>
        /// Gets or sets the coded order category
        /// </summary>
        public HxCodedValueDto? OrderCategory { get; set; }

        /// <summary>
        /// Gets or sets the coded delivery method
        /// </summary>
        public HxCodedValueDto? DeliveryMethod { get; set; }
    }
}
