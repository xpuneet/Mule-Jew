namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the type and currency values in the HX invoice header
    /// </summary>
    public class HxInvoiceHeaderDto
    {
        /// <summary>
        /// Gets or sets the coded source invoice type
        /// </summary>
        public HxCodedValueDto? InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets the coded invoice currency
        /// </summary>
        public HxCodedValueDto? Currency { get; set; }
    }
}
