﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class Statement
    {
        [JsonPropertyName("header")]
        public required StatementHeader Header { get; set; }
    }

    public class StatementHeader
    {
        [JsonPropertyName("metadata")]
        public StatementMetadata? Metadata { get; set; }

        [JsonPropertyName("ID")]
        public long ID { get; set; }

        [JsonPropertyName("accountCode")]
        public required string AccountCode { get; set; }

        [JsonPropertyName("statementDate")]
        public required string StatementDate { get; set; }

        [JsonPropertyName("statementMonth")]
        public string? StatementMonth { get; set; }

        [JsonPropertyName("endOfNextMonth")]
        public string? EndOfNextMonth { get; set; }

        [JsonPropertyName("currencyCode")]
        public required string CurrencyCode { get; set; }

        [JsonPropertyName("lineCount")]
        public int? LineCount { get; set; }

        [JsonPropertyName("totalVAT")]
        public decimal? TotalVAT { get; set; }

        [JsonPropertyName("settDiscountTotal")]
        public decimal? SettDiscountTotal { get; set; }

        [JsonPropertyName("statementTotal")]
        public decimal? StatementTotal { get; set; }

        [JsonPropertyName("statementDiscountTotal")]
        public decimal? StatementDiscountTotal { get; set; }

        [JsonPropertyName("queriedBalance")]
        public decimal? QueriedBalance { get; set; }

        [JsonPropertyName("balanceAfterQueries")]
        public decimal? BalanceAfterQueries { get; set; }

        [JsonPropertyName("vatThisPeriod")]
        public decimal? VatThisPeriod { get; set; }
    }
    public class StatementMetadata
    {
        [JsonPropertyName("originalFileName")]
        public string? OriginalFileName { get; set; }

        [JsonPropertyName("extension")]
        public string? Extension { get; set; }

        [JsonPropertyName("calculatedFileName")]
        public string? CalculatedFileName { get; set; }

        [JsonPropertyName("contentMd5")]
        public string? ContentMd5 { get; set; }

        [JsonPropertyName("contentLength")]
        public long? ContentLength { get; set; }

        [JsonPropertyName("blobUri")]
        public string? BlobUri { get; set; }

        [JsonPropertyName("createdOn")]
        public DateTimeOffset CreatedOn { get; set; }

        [JsonPropertyName("createdBy")]
        public string? CreatedBy { get; set; }

        [JsonPropertyName("lastDownloaded")]
        public DateTimeOffset? LastDownloaded { get; set; }

        [JsonPropertyName("downloadedBy")]
        public string? DownloadedBy { get; set; }
    }
}
