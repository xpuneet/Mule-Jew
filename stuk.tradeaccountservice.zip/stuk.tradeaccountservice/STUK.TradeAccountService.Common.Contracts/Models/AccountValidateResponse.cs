﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class AccountValidateResponse
    {
        [JsonPropertyName("accountCode")]
        public required string AccountCode { get; set; }
        
        [JsonPropertyName("postcodeIsValid")]
        public bool PostcodeIsValid { get; set; }

        [JsonPropertyName("brandIsValid")]
        public bool BrandIsValid { get; set; }

        [JsonPropertyName("onStop")]
        public bool? OnStop { get; set; }

        [JsonPropertyName("email")]
        public string? Email { get; set; }
    }
}
