namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the existing SFTP connection values consumed by the generic Synapse pipeline
    /// </summary>
    public class SynapseSftpConfiguration
    {
        /// <summary>
        /// Gets or sets the SFTP host supplied to Synapse
        /// </summary>
        public string IpAddress { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the SFTP username supplied to Synapse
        /// </summary>
        public string Username { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Key Vault secret name used by Synapse for the SFTP password
        /// </summary>
        public string PasswordKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Key Vault secret name used by Synapse for the SSH private-key passphrase
        /// </summary>
        public string PassPhraseKey { get; set; } = string.Empty;
    }
}
