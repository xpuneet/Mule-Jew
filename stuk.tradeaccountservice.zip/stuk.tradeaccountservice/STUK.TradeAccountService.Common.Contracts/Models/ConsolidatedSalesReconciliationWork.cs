namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents claimed work for matching a component to an existing invoice
    /// </summary>
    public class ConsolidatedSalesReconciliationWork
    {
        /// <summary>
        /// Gets or sets the work identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the consolidated invoice identifier
        /// </summary>
        public Guid ConsolidatedInvoiceId { get; set; }

        /// <summary>
        /// Gets or sets the component identifier
        /// </summary>
        public Guid ComponentId { get; set; }

        /// <summary>
        /// Gets or sets the correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the branch code
        /// </summary>
        public string? BranchCode { get; set; }

        /// <summary>
        /// Gets or sets the ordinary invoice number
        /// </summary>
        public string? StandardInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets the current status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the attempt count
        /// </summary>
        public int AttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible processing time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }

        /// <summary>
        /// Gets or sets the claim token
        /// </summary>
        public Guid? ClaimToken { get; set; }

        /// <summary>
        /// Gets or sets the lease owner
        /// </summary>
        public string? LeaseOwner { get; set; }

        /// <summary>
        /// Gets or sets the lease expiry time
        /// </summary>
        public DateTimeOffset? LeaseExpiresOn { get; set; }

        /// <summary>
        /// Gets or sets the matched existing invoice header identifier
        /// </summary>
        public Guid? MatchedInvoiceHeaderId { get; set; }

        /// <summary>
        /// Gets or sets the last error category
        /// </summary>
        public string? LastErrorCategory { get; set; }

        /// <summary>
        /// Gets or sets the last error message
        /// </summary>
        public string? LastErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the consolidated invoice number
        /// </summary>
        public string ConsolidatedInvoiceNumber { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the consolidated invoice date
        /// </summary>
        public DateOnly? ConsolidatedInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets the stable component reference key
        /// </summary>
        public string ComponentReferenceKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }
    }
}
