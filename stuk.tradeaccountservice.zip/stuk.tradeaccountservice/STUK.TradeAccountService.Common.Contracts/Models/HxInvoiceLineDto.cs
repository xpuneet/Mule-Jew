namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents one source line within an HX invoice
    /// </summary>
    public class HxInvoiceLineDto
    {
        /// <summary>
        /// Gets or sets the action requested by HX for the line
        /// </summary>
        public string? Action { get; set; }

        /// <summary>
        /// Gets or sets the source invoice line number
        /// </summary>
        public string? LineNumber { get; set; }

        /// <summary>
        /// Gets or sets whether the source line number must be preserved
        /// </summary>
        public bool? PreserveLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the order and delivery references for the line
        /// </summary>
        public HxInvoiceLineReferencesDto References { get; set; } = new();

        /// <summary>
        /// Gets or sets the HX consolidated-line extension values
        /// </summary>
        public HxConsolidatedLineDto? Consolidated { get; set; }

        /// <summary>
        /// Gets or sets the source product details
        /// </summary>
        public HxProductDto? Product { get; set; }

        /// <summary>
        /// Gets or sets the invoiced quantity and its unit of measure
        /// </summary>
        public HxQuantityDto? Quantity { get; set; }

        /// <summary>
        /// Gets or sets the unit price and its unit of measure
        /// </summary>
        public HxPriceDto? Price { get; set; }

        /// <summary>
        /// Gets or sets the percentage discount applied to the line
        /// </summary>
        public decimal? PercentageDiscount { get; set; }

        /// <summary>
        /// Gets or sets the tax values reported for the line
        /// </summary>
        public HxTaxDto? Tax { get; set; }

        /// <summary>
        /// Gets or sets the total value reported for the line
        /// </summary>
        public decimal? LineTotal { get; set; }
    }
}
