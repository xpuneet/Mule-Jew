namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Describes the committed Phocas Blob hand-off
    /// </summary>
    public class PhocasBlobStageResult
    {
        /// <summary>
        /// Gets or sets the full container-relative staging path
        /// </summary>
        public string BlobPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the committed Blob entity tag
        /// </summary>
        public string ETag { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets whether the same run and content had already been staged
        /// </summary>
        public bool AlreadyStaged { get; set; }
    }
}
