namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents HX-specific consolidated sales information attached to an invoice line
    /// </summary>
    public class HxConsolidatedLineDto
    {
        /// <summary>
        /// Gets or sets whether the line contains document text rather than a normal product
        /// </summary>
        public bool? DocumentTextLine { get; set; }

        /// <summary>
        /// Gets or sets the original order line number
        /// </summary>
        public string? OriginalOrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier part analysis code
        /// </summary>
        public string? SupplierPartAnalysisCode { get; set; }

        /// <summary>
        /// Gets or sets whether HX identifies the product as a special product
        /// </summary>
        public bool? SpecialProduct { get; set; }

        /// <summary>
        /// Gets or sets the buyer's order number associated with the line
        /// </summary>
        public string? BuyersOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier's order reference associated with the line
        /// </summary>
        public string? SuppliersOrderReference { get; set; }

        /// <summary>
        /// Gets or sets the date on which the supplier dispatched the goods
        /// </summary>
        public DateOnly? SupplierDespatchDate { get; set; }

        /// <summary>
        /// Gets or sets the supplier account code used for delivery
        /// </summary>
        public string? SupplierCodeForDelivery { get; set; }

        /// <summary>
        /// Gets or sets the coded order classifications supplied by HX
        /// </summary>
        public HxSupplierOrderFlagsDto? SupplierOrderFlags { get; set; }

        /// <summary>
        /// Gets or sets the job and customer information associated with the line
        /// </summary>
        public HxCustomerInformationDto? CustomerInformation { get; set; }
    }
}
