namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents document references supplied for an HX invoice
    /// </summary>
    public class HxInvoiceReferencesDto
    {
        /// <summary>
        /// Gets or sets the buyer's order number
        /// </summary>
        public string? BuyersOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier's invoice number
        /// </summary>
        public string? SuppliersInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier's order reference
        /// </summary>
        public string? SuppliersOrderReference { get; set; }
    }
}
