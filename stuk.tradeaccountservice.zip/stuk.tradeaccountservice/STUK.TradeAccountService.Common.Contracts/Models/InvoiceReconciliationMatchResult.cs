namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the result of matching one consolidated component to existing invoices
    /// </summary>
    public class InvoiceReconciliationMatchResult
    {
        /// <summary>
        /// Gets or sets the number of existing invoice headers matching the confirmed business key
        /// </summary>
        public int MatchCount { get; set; }

        /// <summary>
        /// Gets or sets the matched existing invoice header identifier when exactly one match exists
        /// </summary>
        public Guid? MatchedInvoiceHeaderId { get; set; }
    }
}
