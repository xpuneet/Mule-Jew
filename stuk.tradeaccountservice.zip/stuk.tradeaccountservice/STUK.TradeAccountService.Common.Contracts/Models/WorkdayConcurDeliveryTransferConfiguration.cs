namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Combines the existing action, Blob source and Concur SFTP destination used by Synapse
    /// </summary>
    public class WorkdayConcurDeliveryTransferConfiguration
    {
        /// <summary>
        /// Gets or sets the managed delivery action
        /// </summary>
        public FileTransferActionConfiguration Action { get; set; } = new();

        /// <summary>
        /// Gets or sets the managed Blob source connection
        /// </summary>
        public FileTransferBlobConfiguration Blob { get; set; } = new();

        /// <summary>
        /// Gets or sets the managed Concur SFTP destination connection
        /// </summary>
        public SynapseSftpConfiguration Sftp { get; set; } = new();
    }
}
