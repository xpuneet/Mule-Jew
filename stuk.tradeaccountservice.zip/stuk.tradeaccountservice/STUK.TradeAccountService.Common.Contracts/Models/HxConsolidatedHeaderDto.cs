namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents HX-specific values attached to a consolidated invoice header
    /// </summary>
    public class HxConsolidatedHeaderDto
    {
        /// <summary>
        /// Gets or sets the coded document brand
        /// </summary>
        public HxCodedValueDto? DocumentBrand { get; set; }

        /// <summary>
        /// Gets or sets the coded supplier branch
        /// </summary>
        public HxCodedValueDto? SupplierBranch { get; set; }

        /// <summary>
        /// Gets or sets the coded supplier credit terms
        /// </summary>
        public HxCodedValueDto? CreditTerms { get; set; }
    }
}
