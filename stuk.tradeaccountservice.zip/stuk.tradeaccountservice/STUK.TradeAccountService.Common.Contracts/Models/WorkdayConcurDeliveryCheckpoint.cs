namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Records the staged files and external Synapse state for one Concur delivery
    /// </summary>
    public class WorkdayConcurDeliveryCheckpoint
    {
        /// <summary>
        /// Gets or sets the Synapse delivery run identifier
        /// </summary>
        public string SynapseRunId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets when the delivery pipeline was started
        /// </summary>
        public DateTimeOffset StartedOn { get; set; }

        /// <summary>
        /// Gets or sets when delivery reached a terminal state
        /// </summary>
        public DateTimeOffset? CompletedOn { get; set; }

        /// <summary>
        /// Gets or sets the Blob service endpoint containing the encrypted staging folder
        /// </summary>
        public string BlobServiceEndpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Blob container containing the encrypted staging folder
        /// </summary>
        public string StagingContainer { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the correlation-specific folder supplied to Synapse
        /// </summary>
        public string StagingFolderPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets every encrypted Blob staged for this delivery
        /// </summary>
        public IReadOnlyCollection<WorkdayConcurFileIdentity> StagedFiles { get; set; } = Array.Empty<WorkdayConcurFileIdentity>();

        /// <summary>
        /// Gets or sets the current delivery status
        /// </summary>
        public WorkdayConcurDeliveryStatus Status { get; set; }

        /// <summary>
        /// Gets or sets the terminal failure or validation message
        /// </summary>
        public string? FailureMessage { get; set; }
    }
}
