namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a source value containing both a code and a description
    /// </summary>
    public class HxCodedValueDto
    {
        /// <summary>
        /// Gets or sets the source code
        /// </summary>
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the source description
        /// </summary>
        public string? Description { get; set; }
    }
}
