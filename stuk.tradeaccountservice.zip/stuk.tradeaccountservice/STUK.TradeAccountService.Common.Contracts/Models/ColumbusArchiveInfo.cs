﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class ColumbusArchiveInfo
    {
        public int ArchiveId { get; set; }
        public string? Title { get; set; }
        public string? Filename { get; set; }
        public string? Role { get; set; }
    }
}
