namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Records the restart-safe state of the TM1 Synapse pickup
    /// </summary>
    public class WorkdayConcurTm1Checkpoint
    {
        /// <summary>
        /// Gets or sets the Synapse run identifier
        /// </summary>
        public string SynapseRunId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets when the pipeline request was started
        /// </summary>
        public DateTimeOffset StartedOn { get; set; }

        /// <summary>
        /// Gets or sets the Blob service endpoint selected for this pickup
        /// </summary>
        public string BlobServiceEndpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the destination Blob container selected for this pickup
        /// </summary>
        public string DestinationContainer { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the destination Blob name selected for this pickup
        /// </summary>
        public string DestinationBlobName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the latest pipeline or validation status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets when successful validation completed
        /// </summary>
        public DateTimeOffset? CompletedOn { get; set; }

        /// <summary>
        /// Gets or sets the validated TM1 Blob identity
        /// </summary>
        public WorkdayConcurFileIdentity? File { get; set; }

        /// <summary>
        /// Gets or sets terminal failure information
        /// </summary>
        public string? FailureMessage { get; set; }
    }
}
