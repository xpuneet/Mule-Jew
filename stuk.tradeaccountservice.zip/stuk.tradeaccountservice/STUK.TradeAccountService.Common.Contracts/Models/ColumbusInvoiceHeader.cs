﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class UpdateInvoiceHeaderRequest
    {
        public Guid InvoiceId { get; set; }
        public string? BranchCode { get; set; }
        public string? OriginalFileName { get; set; }
        public string? Extension { get; set; }
        public string? CalculatedFileName { get; set; }
        public string? ContentMd5 { get; set; }
        public long? ContentLength { get; set; }
        public string? BlobUri { get; set; }
        public DateTimeOffset? CreatedOn { get; set; }
        public string? CreatedBy { get; set; }
        public DateTimeOffset? LastDownloaded { get; set; }
        public string? DownloadedBy { get; set; }
        public DateTimeOffset? ConsolidatedInvoiceDate { get; set; }
        public bool? IsSynchronized { get; set; }
    }
    public class ColumbusInvoiceHeader
    {
        public Guid Id { get; set; }
        public required string BranchCode { get; set; }
        public required string CustomerAccount { get; set; }
        public char? AccountType { get; set; }
        public string? SearchBrand { get; set; }
        public string? InvoiceBrand { get; set; }
        public required string StandardInvoiceNo { get; set; }
        public string? ConsolidatedInvoiceNo { get; set; }
        public DateTimeOffset? InvoiceDateTime { get; set; }
        public char? DocumentType { get; set; }
        public string? OriginalFileName { get; set; }
        public string? Extension { get; set; }
        public string? CalculatedFileName { get; set; }
        public string? ContentMd5 { get; set; }
        public int? ContentLength { get; set; }
        public string? BlobUri { get; set; }
        public DateTimeOffset? CreatedOn { get; set; }
        public string? CreatedBy { get; set; }
        public DateTimeOffset? LastDownloaded { get; set; }
        public string? DownloadedBy { get; set; }
        public DateTimeOffset? ConsolidatedInvoiceDate { get; set; }
        public bool IsSynchronized { get; set; }
    }
}