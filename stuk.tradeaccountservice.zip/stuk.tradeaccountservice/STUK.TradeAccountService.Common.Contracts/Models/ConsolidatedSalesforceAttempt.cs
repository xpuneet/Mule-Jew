namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents an immutable audit record for one Salesforce operation
    /// </summary>
    public class ConsolidatedSalesforceAttempt
    {
        /// <summary>
        /// Gets or sets the Salesforce work identifier
        /// </summary>
        public Guid SalesforceWorkId { get; set; }

        /// <summary>
        /// Gets or sets the processing correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the operation name
        /// </summary>
        public string Operation { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the entity key
        /// </summary>
        public string? EntityKey { get; set; }

        /// <summary>
        /// Gets or sets the attempt number
        /// </summary>
        public int AttemptNumber { get; set; }

        /// <summary>
        /// Gets or sets the attempt outcome
        /// </summary>
        public string Outcome { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the HTTP status code
        /// </summary>
        public int? HttpStatusCode { get; set; }

        /// <summary>
        /// Gets or sets the approved request payload
        /// </summary>
        public string? RequestPayload { get; set; }

        /// <summary>
        /// Gets or sets the approved response payload
        /// </summary>
        public string? ResponsePayload { get; set; }

        /// <summary>
        /// Gets or sets the error category
        /// </summary>
        public string? ErrorCategory { get; set; }

        /// <summary>
        /// Gets or sets the safe error message
        /// </summary>
        public string? ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the operation start time
        /// </summary>
        public DateTimeOffset StartedOn { get; set; }

        /// <summary>
        /// Gets or sets the operation completion time
        /// </summary>
        public DateTimeOffset CompletedOn { get; set; }
    }
}
