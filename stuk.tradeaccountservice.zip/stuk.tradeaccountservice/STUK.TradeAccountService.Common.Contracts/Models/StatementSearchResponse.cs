﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class StatementSearchResponse
    {
        [JsonPropertyName("pages")]
        public PaginationInfo Pages { get; set; } = null!;

        [JsonPropertyName("statements")]
        public List<StatemetRoot> Statements { get; set; } = null!;
    }

    public class StatemetRoot
    {
        [JsonPropertyName("statement")]
        public Statement Statement { get; set; } = null!;
    }
}
