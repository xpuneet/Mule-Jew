namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Records the restart-safe state of the Mule-free Concur transformation
    /// </summary>
    public class WorkdayConcurTransformationCheckpoint
    {
        /// <summary>
        /// Gets or sets the Synapse pipeline run identifier
        /// </summary>
        public string SynapseRunId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets when the Synapse pipeline was started
        /// </summary>
        public DateTimeOffset StartedOn { get; set; }

        /// <summary>
        /// Gets or sets the current transformation status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets when the transformation reached a terminal result
        /// </summary>
        public DateTimeOffset? CompletedOn { get; set; }

        /// <summary>
        /// Gets or sets the terminal failure or validation message
        /// </summary>
        public string? FailureMessage { get; set; }

        /// <summary>
        /// Gets or sets every non-directory Blob selected from the output path
        /// </summary>
        public IReadOnlyCollection<WorkdayConcurFileIdentity> OutputFiles { get; set; } = Array.Empty<WorkdayConcurFileIdentity>();
    }
}
