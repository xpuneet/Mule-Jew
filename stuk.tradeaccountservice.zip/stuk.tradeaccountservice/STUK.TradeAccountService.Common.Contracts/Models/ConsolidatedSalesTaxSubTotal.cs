namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a tax subtotal for a consolidated sales invoice
    /// </summary>
    public class ConsolidatedSalesTaxSubTotal
    {
        /// <summary>
        /// Gets or sets the tax rate code
        /// </summary>
        public string? TaxRateCode { get; set; }

        /// <summary>
        /// Gets or sets the tax rate
        /// </summary>
        public decimal? TaxRate { get; set; }

        /// <summary>
        /// Gets or sets the number of lines at the rate
        /// </summary>
        public int? NumberOfLinesAtRate { get; set; }

        /// <summary>
        /// Gets or sets the total value at the rate
        /// </summary>
        public decimal? TotalValueAtRate { get; set; }

        /// <summary>
        /// Gets or sets the taxable value at the rate
        /// </summary>
        public decimal? TaxableValueAtRate { get; set; }

        /// <summary>
        /// Gets or sets the tax at the rate
        /// </summary>
        public decimal? TaxAtRate { get; set; }

        /// <summary>
        /// Gets or sets the net payment at the rate
        /// </summary>
        public decimal? NetPaymentAtRate { get; set; }

        /// <summary>
        /// Gets or sets the gross payment at the rate
        /// </summary>
        public decimal? GrossPaymentAtRate { get; set; }
    }
}
