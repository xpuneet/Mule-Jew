namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Combines the existing File Transfer action and connection values required for TM1 pickup
    /// </summary>
    public class WorkdayConcurTm1TransferConfiguration
    {
        /// <summary>
        /// Gets or sets the managed file-transfer action
        /// </summary>
        public FileTransferActionConfiguration Action { get; set; } = new();

        /// <summary>
        /// Gets or sets the managed SFTP connection
        /// </summary>
        public SynapseSftpConfiguration Sftp { get; set; } = new();

        /// <summary>
        /// Gets or sets the managed Blob connection
        /// </summary>
        public FileTransferBlobConfiguration Blob { get; set; } = new();
    }
}
