﻿namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public sealed record PreferredBranchResponse(string BranchNumber);

    public sealed record PreferredBranchData(string PreferredBranch, string ErrorCode);

    public record PreferredBranchRequest
    {
        public required string BranchNumber { get; init; }
    }
}
