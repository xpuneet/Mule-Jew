namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents one immutable persisted page of Salesforce export rows
    /// </summary>
    public class ConsolidatedSalesExportPage
    {
        /// <summary>
        /// Gets or sets the export page identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the parent export run identifier
        /// </summary>
        public Guid ExportRunId { get; set; }

        /// <summary>
        /// Gets or sets the one-based page number
        /// </summary>
        public int PageNumber { get; set; }

        /// <summary>
        /// Gets or sets the one-based sequence assigned to the first page row
        /// </summary>
        public long FirstRowSequence { get; set; }

        /// <summary>
        /// Gets or sets the number of rows in the page
        /// </summary>
        public int RowCount { get; set; }

        /// <summary>
        /// Gets or sets the SHA-256 page-content hash
        /// </summary>
        public byte[] PageHash { get; set; } = Array.Empty<byte>();

        /// <summary>
        /// Gets or sets whether Salesforce reported another page
        /// </summary>
        public bool HasMore { get; set; }

        /// <summary>
        /// Gets or sets the persistence time
        /// </summary>
        public DateTimeOffset PersistedOn { get; set; }

        /// <summary>
        /// Gets or sets whether this operation inserted the page
        /// </summary>
        public bool IsNew { get; set; }
    }
}
