namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Summarises a completed Salesforce extraction and persisted snapshot
    /// </summary>
    public class ConsolidatedSalesExportExtractionResult
    {
        /// <summary>
        /// Gets or sets the export run identifier
        /// </summary>
        public Guid ExportRunId { get; set; }

        /// <summary>
        /// Gets or sets the end-to-end correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the number of Salesforce pages persisted
        /// </summary>
        public int PageCount { get; set; }

        /// <summary>
        /// Gets or sets the number of Salesforce records persisted
        /// </summary>
        public long RowCount { get; set; }

        /// <summary>
        /// Gets or sets the complete extraction duration
        /// </summary>
        public TimeSpan Duration { get; set; }
    }
}
