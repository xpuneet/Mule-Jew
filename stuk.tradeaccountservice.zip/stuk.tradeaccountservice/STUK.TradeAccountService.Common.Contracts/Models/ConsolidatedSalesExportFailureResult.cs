namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents extraction state returned after a failed Salesforce attempt
    /// </summary>
    public class ConsolidatedSalesExportFailureResult
    {
        /// <summary>
        /// Gets or sets the resulting extraction status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the resulting extraction-attempt count
        /// </summary>
        public int ExtractionAttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible extraction time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }
    }
}
