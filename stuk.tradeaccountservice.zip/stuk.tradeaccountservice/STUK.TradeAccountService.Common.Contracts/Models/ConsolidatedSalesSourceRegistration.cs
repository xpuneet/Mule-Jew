namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Describes a staged HX file that must be registered for ingestion
    /// </summary>
    public class ConsolidatedSalesSourceRegistration
    {
        /// <summary>
        /// Gets or sets the correlation identifier for the processing flow
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the source-system name
        /// </summary>
        public string SourceSystem { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Blob container name
        /// </summary>
        public string BlobContainer { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the path of the file within the Blob container
        /// </summary>
        public string BlobPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the original source-file name
        /// </summary>
        public string SourceFileName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the content length in bytes
        /// </summary>
        public long ContentLength { get; set; }

        /// <summary>
        /// Gets or sets the Blob last-modified time used to identify the exact file version
        /// </summary>
        public DateTimeOffset BlobLastModifiedOn { get; set; }

        /// <summary>
        /// Gets or sets the immutable content checksum when available
        /// </summary>
        public string? ContentChecksum { get; set; }

        /// <summary>
        /// Gets or sets the Blob entity tag identifying the exact source version
        /// </summary>
        public string ETag { get; set; } = string.Empty;
    }
}
