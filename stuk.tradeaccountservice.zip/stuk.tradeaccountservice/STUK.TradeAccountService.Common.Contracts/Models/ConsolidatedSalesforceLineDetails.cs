namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a canonical line and its independent Salesforce delivery state
    /// </summary>
    public class ConsolidatedSalesforceLineDetails
    {
        /// <summary>
        /// Gets or sets the deterministic Salesforce OrderItem external identifier
        /// </summary>
        public string SalesforceExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce line status
        /// </summary>
        public string SalesforceLineStatus { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the Salesforce product identifier
        /// </summary>
        public string? SalesforceProductId { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce pricebook entry identifier
        /// </summary>
        public string? SalesforcePricebookEntryId { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce order item identifier
        /// </summary>
        public string? SalesforceOrderItemId { get; set; }
    }
}
