namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Records the immutable post-delivery move plan and its restart-safe progress
    /// </summary>
    public class WorkdayConcurHousekeepingCheckpoint
    {
        /// <summary>
        /// Gets or sets the Blob service endpoint containing input and output files
        /// </summary>
        public string BlobServiceEndpoint { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets every planned output and input move
        /// </summary>
        public IReadOnlyCollection<WorkdayConcurFileMove> Moves { get; set; } = Array.Empty<WorkdayConcurFileMove>();

        /// <summary>
        /// Gets or sets the overall housekeeping status
        /// </summary>
        public WorkdayConcurHousekeepingStatus Status { get; set; }

        /// <summary>
        /// Gets or sets when every planned move completed
        /// </summary>
        public DateTimeOffset? CompletedOn { get; set; }
    }
}
