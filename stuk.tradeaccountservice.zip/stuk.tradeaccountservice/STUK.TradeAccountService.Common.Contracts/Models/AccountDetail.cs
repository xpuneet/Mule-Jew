﻿using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class AccountDetail
    {
        [JsonPropertyName("accountCode")]
        public required string AccountCode { get; set; }

        [JsonPropertyName("name")]
        public required string Name { get; set; }

        [JsonPropertyName("parentAccountCode")]
        public string? ParentAccountCode { get; set; }

        [JsonPropertyName("accountType")]
        public string? AccountType { get; set; }

        [JsonPropertyName("accountLevel")]
        public string? AccountLevel { get; set; }

        [JsonPropertyName("owningBranch")]
        public string? OwningBranch { get; set; }

        [JsonPropertyName("owningBrand")]
        public string? OwningBrand { get; set; }

        [JsonPropertyName("contacts")]
        public List<Contact> Contacts { get; set; } = [];

        [JsonPropertyName("addresses")]
        public List<Address> Addresses { get; set; } = [];

        [JsonPropertyName("paymentProfile")]
        public PaymentProfile PaymentProfile { get; set; } = new();

        [JsonPropertyName("extensionAttributes")]
        public List<JsonNode> ExtensionAttributes { get; set; } = [];
    }
    public class Address
    {
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("lines")]
        public List<string> Lines { get; set; } = [];

        [JsonPropertyName("town")]
        public string? Town { get; set; }

        [JsonPropertyName("postCode")]
        public string? PostCode { get; set; }
    }
    public class Contact
    {
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("name")]
        public required string Name { get; set; }

        [JsonPropertyName("phone")]
        public string? Phone { get; set; }

        [JsonPropertyName("email")]
        public string? Email { get; set; }
    }
    public class PaymentProfile
    {
        [JsonPropertyName("paymentOnCredit")]
        public bool? PaymentOnCredit { get; set; }

        [JsonPropertyName("paymentOnCard")]
        public bool? PaymentOnCard { get; set; }

        [JsonPropertyName("accountOnStop")]
        public bool? AccountOnStop { get; set; }

        [JsonPropertyName("creditAttributes")]
        public List<CreditAttribute> CreditAttributes { get; set; } = [];

        [JsonPropertyName("creditStatus")]
        public List<CreditStatus> CreditStatuses { get; set; } = [];
    }
    public class CreditAttribute
    {
        [JsonPropertyName("name")]
        public required string Name { get; set; }

        [JsonPropertyName("code")]
        public string? Code { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }
    }
    public class CreditStatus
    {
        [JsonPropertyName("name")]
        public required string Name { get; set; }

        [JsonPropertyName("amount")]
        public required decimal Amount { get; set; }

        [JsonPropertyName("lastUpdatedDate")]
        public DateTime LastUpdatedDate { get; set; }
    }
}
