namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents durable Salesforce extraction state for one logical export run
    /// </summary>
    public class ConsolidatedSalesExportRun
    {
        /// <summary>
        /// Gets or sets the export run identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the stable logical run key
        /// </summary>
        public string LogicalRunKey { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the end-to-end correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the calendar year represented by the export
        /// </summary>
        public int ExportYear { get; set; }

        /// <summary>
        /// Gets or sets the first date included by the Salesforce extraction
        /// </summary>
        public DateOnly ExtractFromDate { get; set; }

        /// <summary>
        /// Gets or sets the scheduled time represented by the run
        /// </summary>
        public DateTimeOffset ScheduledFor { get; set; }

        /// <summary>
        /// Gets or sets the current extraction status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the number of extraction attempts
        /// </summary>
        public int ExtractionAttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the number of pages in the completed snapshot
        /// </summary>
        public int? ExtractedPageCount { get; set; }

        /// <summary>
        /// Gets or sets the number of rows in the completed snapshot
        /// </summary>
        public long? ExtractedRowCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible extraction time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }

        /// <summary>
        /// Gets or sets the current extraction claim token
        /// </summary>
        public Guid? ClaimToken { get; set; }

        /// <summary>
        /// Gets or sets the worker holding the extraction lease
        /// </summary>
        public string? LeaseOwner { get; set; }

        /// <summary>
        /// Gets or sets the extraction lease expiry time
        /// </summary>
        public DateTimeOffset? LeaseExpiresOn { get; set; }

        /// <summary>
        /// Gets or sets the last extraction error category
        /// </summary>
        public string? LastErrorCategory { get; set; }

        /// <summary>
        /// Gets or sets the last extraction error detail
        /// </summary>
        public string? LastErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the creation time
        /// </summary>
        public DateTimeOffset CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the extraction start time
        /// </summary>
        public DateTimeOffset? ExtractionStartedOn { get; set; }

        /// <summary>
        /// Gets or sets the extraction completion time
        /// </summary>
        public DateTimeOffset? ExtractionCompletedOn { get; set; }

        /// <summary>
        /// Gets or sets the terminal failure time
        /// </summary>
        public DateTimeOffset? FailedOn { get; set; }

        /// <summary>
        /// Gets or sets the last update time
        /// </summary>
        public DateTimeOffset UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets whether this registration created the run
        /// </summary>
        public bool IsNew { get; set; }
    }
}
