namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a unit price and its unit of measure
    /// </summary>
    public class HxPriceDto
    {
        /// <summary>
        /// Gets or sets the price charged for one unit
        /// </summary>
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure code
        /// </summary>
        public string? UomCode { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure description
        /// </summary>
        public string? UomDescription { get; set; }
    }
}
