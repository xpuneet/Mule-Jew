﻿using STUK.IconIntegration.IconClient;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class PendingPaymentReference
    {
        public long PaymentId { get; init; }
        public string AccountCode { get; init; } = null!;
        public string BranchId { get; init; } = null!;
        public string Description { get; init; } = null!;
        public char PaymentType { get; init; }
        public decimal PaymentAmount { get; init; }
        public Guid ApiPaymentReference { get; init; }
    }
    public class UpdatePaymentReference
    {
        public long PaymentId { get; init; }
        public string? ErpPaymentReference { get; init; }
        public string ErpStatus { get; init; } = null!;
        public string? ErpReason { get; init; }
    }

    public class ErpApiResult
    {
        //true: call succeeded or return known error, false: network error
        public bool IsDefinitive { get; init; }
        public IconMakeAccountPaymentResponse? Response { get; init; }
        public string? ErrorMessage { get; init; }
        public int? StatusCode { get; init; }
    }
}
