namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the retry state returned after operational work fails or is deferred
    /// </summary>
    public class ConsolidatedSalesWorkFailureResult
    {
        /// <summary>
        /// Gets or sets the resulting status
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the attempt count
        /// </summary>
        public int AttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the next eligible processing time
        /// </summary>
        public DateTimeOffset? NextAttemptOn { get; set; }
    }
}
