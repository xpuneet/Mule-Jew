﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public abstract class DocumentSearchResponse
    {
        [JsonPropertyName("pages")]
        public PaginationInfo Pages { get; set; } = null!;
    }
    public class InvoiceResponse
    {
        [JsonPropertyName("invoice")]
        public InvoiceDocument Invoice { get; set; } = null!;
    }
    public class InvoiceSearchResponse : DocumentSearchResponse
    {
        [JsonPropertyName("invoices")]
        public List<InvoiceDocument> Invoices { get; set; } = null!;
    }

    public class CreditNoteSearchResponse : DocumentSearchResponse
    {
        [JsonPropertyName("creditNotes")]
        public List<InvoiceDocument> CreditNotes { get; set; } = null!;
    }

    public record InvoiceFilterRequest(string CustomerAccount, string SortBy , string SortOrder, int PageNumber, int PageSize,
        string? BranchCode = null, string? Brand = null, DateTimeOffset? InvoiceDateFrom = null, DateTimeOffset? InvoiceDateTo = null, string? OrderBranchCode =null,
        int? OrderNo = null, DateTimeOffset? OrderCreatedDateFrom = null, DateTimeOffset? OrderCreatedDateTo = null, string? OrderReference = null, string? ItemCode = null
        );

    public record InvoiceSearchFilterRequest(string CustomerAccount, string SortBy, string SortOrder, int PageNumber, int PageSize,
        string? InvoiceStatus = null, string? SearchParam = null);
}
