namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the identifier returned for a Salesforce attempt audit record
    /// </summary>
    public class ConsolidatedSalesforceAttemptResult
    {
        /// <summary>
        /// Gets or sets the Salesforce attempt identifier
        /// </summary>
        public Guid SalesforceAttemptId { get; set; }
    }
}
