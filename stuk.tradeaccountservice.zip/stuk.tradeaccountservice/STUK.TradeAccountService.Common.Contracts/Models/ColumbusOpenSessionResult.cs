﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class ColumbusOpenSessionResult
    {
        public string SessionId { get; set; } = string.Empty;
        public int ErrorNumber { get; set; }
        public string? ErrorMessage { get; set; }
        public ColumbusArchiveInfo? Archive { get; set; }
    }
}
