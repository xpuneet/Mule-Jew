namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a canonical consolidated sales invoice line
    /// </summary>
    public class ConsolidatedSalesInvoiceLine
    {
        /// <summary>
        /// Gets or sets the line identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the component reference key
        /// </summary>
        public string? ComponentReferenceKey { get; set; }

        /// <summary>
        /// Gets or sets the stable line identity
        /// </summary>
        public string LineIdentity { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the deterministic Salesforce external identifier
        /// </summary>
        public string SalesforceExternalId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the line sequence
        /// </summary>
        public int LineSequence { get; set; }

        /// <summary>
        /// Gets or sets the source line number
        /// </summary>
        public string? SourceLineNumber { get; set; }

        /// <summary>
        /// Gets or sets whether the source line number must be preserved
        /// </summary>
        public bool? PreserveLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the source action
        /// </summary>
        public string? SourceAction { get; set; }

        /// <summary>
        /// Gets or sets the order line number
        /// </summary>
        public string? OrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the original order line number
        /// </summary>
        public string? OriginalOrderLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note line number
        /// </summary>
        public string? DeliveryNoteLineNumber { get; set; }

        /// <summary>
        /// Gets or sets the buyer order number
        /// </summary>
        public string? BuyersOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier order reference
        /// </summary>
        public string? SuppliersOrderReference { get; set; }

        /// <summary>
        /// Gets or sets the supplier despatch date
        /// </summary>
        public DateOnly? SupplierDespatchDate { get; set; }

        /// <summary>
        /// Gets or sets the supplier delivery code
        /// </summary>
        public string? SupplierCodeForDelivery { get; set; }

        /// <summary>
        /// Gets or sets the order type code
        /// </summary>
        public string? OrderTypeCode { get; set; }

        /// <summary>
        /// Gets or sets the order type description
        /// </summary>
        public string? OrderTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the order category code
        /// </summary>
        public string? OrderCategoryCode { get; set; }

        /// <summary>
        /// Gets or sets the order category description
        /// </summary>
        public string? OrderCategoryDescription { get; set; }

        /// <summary>
        /// Gets or sets the delivery method code
        /// </summary>
        public string? DeliveryMethodCode { get; set; }

        /// <summary>
        /// Gets or sets the delivery method description
        /// </summary>
        public string? DeliveryMethodDescription { get; set; }

        /// <summary>
        /// Gets or sets the supplier part analysis code
        /// </summary>
        public string? SupplierPartAnalysisCode { get; set; }

        /// <summary>
        /// Gets or sets whether the line represents a special product
        /// </summary>
        public bool? IsSpecialProduct { get; set; }

        /// <summary>
        /// Gets or sets whether the line contains qualifying text
        /// </summary>
        public bool IsTextLine { get; set; }

        /// <summary>
        /// Gets or sets the product code
        /// </summary>
        public string? ProductCode { get; set; }

        /// <summary>
        /// Gets or sets the product description
        /// </summary>
        public string? ProductDescription { get; set; }

        /// <summary>
        /// Gets or sets the quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure code
        /// </summary>
        public string? QuantityUomCode { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure description
        /// </summary>
        public string? QuantityUomDescription { get; set; }

        /// <summary>
        /// Gets or sets the unit price
        /// </summary>
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure code
        /// </summary>
        public string? PriceUomCode { get; set; }

        /// <summary>
        /// Gets or sets the price unit-of-measure description
        /// </summary>
        public string? PriceUomDescription { get; set; }

        /// <summary>
        /// Gets or sets the percentage discount
        /// </summary>
        public decimal? PercentageDiscount { get; set; }

        /// <summary>
        /// Gets or sets the tax rate code
        /// </summary>
        public string? TaxRateCode { get; set; }

        /// <summary>
        /// Gets or sets the tax rate
        /// </summary>
        public decimal? TaxRate { get; set; }

        /// <summary>
        /// Gets or sets the tax value
        /// </summary>
        public decimal? TaxValue { get; set; }

        /// <summary>
        /// Gets or sets the line total
        /// </summary>
        public decimal? LineTotal { get; set; }

        /// <summary>
        /// Gets or sets the job number
        /// </summary>
        public string? JobNumber { get; set; }

        /// <summary>
        /// Gets or sets the contract number
        /// </summary>
        public string? ContractNumber { get; set; }

        /// <summary>
        /// Gets or sets the buyer location
        /// </summary>
        public string? BuyerLocation { get; set; }

        /// <summary>
        /// Gets or sets the operative
        /// </summary>
        public string? Operative { get; set; }

        /// <summary>
        /// Gets or sets the site code
        /// </summary>
        public string? SiteCode { get; set; }

        /// <summary>
        /// Gets or sets the plot number
        /// </summary>
        public string? PlotNumber { get; set; }

        /// <summary>
        /// Gets or sets the vehicle registration
        /// </summary>
        public string? VehicleRegistration { get; set; }

        /// <summary>
        /// Gets or sets the house type
        /// </summary>
        public string? HouseType { get; set; }

        /// <summary>
        /// Gets or sets the product group
        /// </summary>
        public string? ProductGroup { get; set; }

        /// <summary>
        /// Gets or sets the order authorisation
        /// </summary>
        public string? OrderAuthorised { get; set; }

        /// <summary>
        /// Gets or sets the original job address lines JSON
        /// </summary>
        public string? JobAddressLinesJson { get; set; }

        /// <summary>
        /// Gets or sets job address line one
        /// </summary>
        public string? JobAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets job address line two
        /// </summary>
        public string? JobAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets job address line three
        /// </summary>
        public string? JobAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets job address line four
        /// </summary>
        public string? JobAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets the job street
        /// </summary>
        public string? JobStreet { get; set; }

        /// <summary>
        /// Gets or sets the job city
        /// </summary>
        public string? JobCity { get; set; }

        /// <summary>
        /// Gets or sets the job state
        /// </summary>
        public string? JobState { get; set; }

        /// <summary>
        /// Gets or sets the job postcode
        /// </summary>
        public string? JobPostcode { get; set; }
    }
}
