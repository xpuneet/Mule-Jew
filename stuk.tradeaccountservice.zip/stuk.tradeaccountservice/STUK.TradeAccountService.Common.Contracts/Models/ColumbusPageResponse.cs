﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class ColumbusPageResponse
    {
        public int ErrorNumber { get; set; }
        public string? ErrorMessage { get; set; }
        public string OperationStatus { get; set; } = string.Empty;
        public int OperationErrorNumber { get; set; }
        public string? BlobUrl { get; set; }
        public string? Extension { get; set; }

        public string? CalculatedFileName { get; set; }
        public long Size { get; set; }
        public string? SourceFileName { get; set; }
        public long FileSize { get; set; }
        public string? FileTime { get; set; }
        public string? CreationTime { get; set; }
        public int? FileAttributes { get; set; }
        public int? NumberOfBlocks { get; set; }
        public string? ContentMd5 { get; set; }

    }
}
