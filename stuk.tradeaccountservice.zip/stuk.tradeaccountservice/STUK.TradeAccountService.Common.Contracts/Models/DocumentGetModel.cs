﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class StatementHeaderMetadata
    {
        [JsonPropertyName("blobUri")]
        public string? BlobUri { get; set; }

        [JsonPropertyName("originalFileName")]
        public string? OriginalFileName { get; set; }

        [JsonPropertyName("calculatedFileName")]
        public string? CalculatedFileName { get; set; }
    }

    public class InvoiceHeaderMetadata
    {
        public string? BlobUri { get; set; }
        public string? CalculatedFileName { get; set; }
    }
}
