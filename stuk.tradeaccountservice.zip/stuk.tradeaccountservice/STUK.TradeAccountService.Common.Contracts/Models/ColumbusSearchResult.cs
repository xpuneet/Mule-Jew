﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class ColumbusSearchResult
    {
        public int ErrorNumber { get; set; }
        public string? ErrorMessage { get; set; }
        public string? ContinueSearch { get; set; }
        public int TotalDocuments { get; set; }  
        public string OperationStatus { get; set; } = string.Empty;
        public int OperationErrorNumber { get; set; }
    }
}
