using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Identifies the persisted overall state of post-delivery Blob housekeeping
    /// </summary>
    [JsonConverter(typeof(JsonStringEnumConverter<WorkdayConcurHousekeepingStatus>))]
    public enum WorkdayConcurHousekeepingStatus
    {
        /// <summary>
        /// The immutable move plan has been created
        /// </summary>
        Pending,

        /// <summary>
        /// At least one planned move remains incomplete
        /// </summary>
        InProgress,

        /// <summary>
        /// Every planned copy and source deletion succeeded
        /// </summary>
        Succeeded
    }
}
