namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents an existing managed file-transfer action
    /// </summary>
    public class FileTransferActionConfiguration
    {
        /// <summary>
        /// Gets or sets the file action identifier
        /// </summary>
        public string Id { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the source connection identifier
        /// </summary>
        public string SourceId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the destination connection identifier
        /// </summary>
        public string DestinationId { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the configured Synapse pipeline name
        /// </summary>
        public string PipeLineName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the source filename contract
        /// </summary>
        public string? SourceFileNameFormat { get; set; }

        /// <summary>
        /// Gets or sets the source folder
        /// </summary>
        public string? SourceFolderPath { get; set; }

        /// <summary>
        /// Gets or sets whether Synapse archives a successfully copied source
        /// </summary>
        public bool? SourceArchive { get; set; }

        /// <summary>
        /// Gets or sets the configured source archive path
        /// </summary>
        public string? SourceArchivePath { get; set; }

        /// <summary>
        /// Gets or sets the destination filename contract
        /// </summary>
        public string? DestinationFileNameFormat { get; set; }

        /// <summary>
        /// Gets or sets the destination Blob container or path
        /// </summary>
        public string? DestinationFolderPath { get; set; }

        /// <summary>
        /// Gets or sets the configured source error path
        /// </summary>
        public string? SourceErrorPath { get; set; }

        /// <summary>
        /// Gets or sets whether Synapse deletes the source after a successful copy
        /// </summary>
        public bool? SourceDelete { get; set; }
    }
}
