﻿namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public record StatementSearchRequest(string AccountCode, int PageNumber, int PageSize, DateOnly? StatementDateFrom = null,
        DateOnly? StatementDateTo = null);
}
