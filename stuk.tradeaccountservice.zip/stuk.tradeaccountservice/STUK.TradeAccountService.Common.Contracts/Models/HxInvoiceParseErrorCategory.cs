namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Identifies the type of failure encountered while reading an HX invoice document
    /// </summary>
    public enum HxInvoiceParseErrorCategory
    {
        /// <summary>
        /// The source is not well-formed XML after the permitted sanitisation attempt
        /// </summary>
        MalformedXml,

        /// <summary>
        /// The source does not contain the expected HX/BASDA document structure
        /// </summary>
        UnsupportedDocument,

        /// <summary>
        /// A source value cannot be converted to its required data type
        /// </summary>
        InvalidValue
    }
}
