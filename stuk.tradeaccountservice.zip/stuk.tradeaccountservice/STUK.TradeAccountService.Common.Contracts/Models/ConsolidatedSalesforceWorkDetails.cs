namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the canonical and operational data needed for Salesforce delivery
    /// </summary>
    public class ConsolidatedSalesforceWorkDetails
    {
        /// <summary>
        /// Gets or sets the Salesforce work identifier
        /// </summary>
        public Guid SalesforceWorkId { get; set; }

        /// <summary>
        /// Gets or sets the canonical invoice identifier
        /// </summary>
        public Guid ConsolidatedInvoiceId { get; set; }

        /// <summary>
        /// Gets or sets the current attempt count
        /// </summary>
        public int AttemptCount { get; set; }

        /// <summary>
        /// Gets or sets the Salesforce order identifier
        /// </summary>
        public string? SalesforceOrderId { get; set; }

        /// <summary>
        /// Gets or sets the committed canonical invoice to project to Salesforce
        /// </summary>
        public ConsolidatedSalesInvoice Invoice { get; set; } = new();

        /// <summary>
        /// Gets or sets the independent Salesforce delivery state for the canonical lines
        /// </summary>
        public List<ConsolidatedSalesforceLineDetails> Lines { get; set; } = [];
    }
}
