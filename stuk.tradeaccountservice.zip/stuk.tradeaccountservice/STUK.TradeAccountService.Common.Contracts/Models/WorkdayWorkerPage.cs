namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents one Workday page of complete employee records
    /// </summary>
    public class WorkdayWorkerPage
    {
        /// <summary>
        /// Gets or sets the employees returned on the page
        /// </summary>
        public IReadOnlyList<WorkdayWorker> Workers { get; set; } = Array.Empty<WorkdayWorker>();

        /// <summary>
        /// Gets or sets the one-based page number returned by Workday
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// Gets or sets the total number of pages reported by Workday
        /// </summary>
        public int TotalPages { get; set; }
    }
}
