﻿namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class CreditLimitResponse
    {
        public required string Account { get; set; }
        public decimal? CreditLimit { get; set; }
        public decimal? CreditBalance { get; set; }
        public decimal? OutstandingBalance { get; set; }
        public decimal? UsedCredit { get; set; }
        public decimal? PendingOrders { get; set; }
        public DateTimeOffset? BalanceUpdatedAt { get; set; }
        public string? ErrorCode { get; set; }
    }
}
