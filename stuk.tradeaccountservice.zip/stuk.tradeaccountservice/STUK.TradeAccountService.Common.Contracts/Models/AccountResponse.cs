﻿using System.Text.Json.Serialization;

namespace STUK.TradeAccountService.Common.Contracts.Models
{
    public class AccountResponse
    {
        [JsonPropertyName("account")]
        public AccountDetail? Account { get; set; }
    }
    public class AccountSearchResponse
    {
        [JsonPropertyName("pages")]
        public PaginationInfo Pages { get; set; } = null!;

        [JsonPropertyName("accounts")]
        public List<AccountDetail> Accounts { get; set; } = null!;
    }

}
