namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a canonical consolidated sales invoice and its complete hierarchy
    /// </summary>
    public class ConsolidatedSalesInvoice
    {
        /// <summary>
        /// Gets or sets the persisted invoice identifier
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets the processing correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the consolidated invoice business number
        /// </summary>
        public string ConsolidatedInvoiceNumber { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the invoice type code
        /// </summary>
        public string? InvoiceTypeCode { get; set; }

        /// <summary>
        /// Gets or sets the invoice type description
        /// </summary>
        public string? InvoiceTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the invoice date
        /// </summary>
        public DateOnly? InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets the tax point date
        /// </summary>
        public DateOnly? TaxPointDate { get; set; }

        /// <summary>
        /// Gets or sets the buyer order number
        /// </summary>
        public string? BuyersOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the source supplier invoice number
        /// </summary>
        public string? SourceSuppliersInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets the delivery note number
        /// </summary>
        public string? DeliveryNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets the supplier order reference
        /// </summary>
        public string? SuppliersOrderReference { get; set; }

        /// <summary>
        /// Gets or sets the customer account code
        /// </summary>
        public string? CustomerAccountCode { get; set; }

        /// <summary>
        /// Gets or sets the document brand code
        /// </summary>
        public string? DocumentBrandCode { get; set; }

        /// <summary>
        /// Gets or sets the document brand description
        /// </summary>
        public string? DocumentBrandDescription { get; set; }

        /// <summary>
        /// Gets or sets the supplier branch code
        /// </summary>
        public string? SupplierBranchCode { get; set; }

        /// <summary>
        /// Gets or sets the supplier branch description
        /// </summary>
        public string? SupplierBranchDescription { get; set; }

        /// <summary>
        /// Gets or sets the currency code
        /// </summary>
        public string? CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets the currency description
        /// </summary>
        public string? CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets the credit terms code
        /// </summary>
        public string? CreditTermsCode { get; set; }

        /// <summary>
        /// Gets or sets the credit terms description
        /// </summary>
        public string? CreditTermsDescription { get; set; }

        /// <summary>
        /// Gets or sets the expected line count
        /// </summary>
        public int ExpectedLineCount { get; set; }

        /// <summary>
        /// Gets or sets the number of tax rates
        /// </summary>
        public int? NumberOfTaxRates { get; set; }

        /// <summary>
        /// Gets or sets the total line value
        /// </summary>
        public decimal? LineValueTotal { get; set; }

        /// <summary>
        /// Gets or sets the taxable total
        /// </summary>
        public decimal? TaxableTotal { get; set; }

        /// <summary>
        /// Gets or sets the tax total
        /// </summary>
        public decimal? TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets the net payment total
        /// </summary>
        public decimal? NetPaymentTotal { get; set; }

        /// <summary>
        /// Gets or sets the gross payment total
        /// </summary>
        public decimal? GrossPaymentTotal { get; set; }

        /// <summary>
        /// Gets or sets the creation time
        /// </summary>
        public DateTimeOffset CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the last update time
        /// </summary>
        public DateTimeOffset UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets the invoice parties
        /// </summary>
        public List<ConsolidatedSalesInvoiceParty> Parties { get; set; } = [];

        /// <summary>
        /// Gets or sets the component invoices
        /// </summary>
        public List<ConsolidatedSalesInvoiceComponent> Components { get; set; } = [];

        /// <summary>
        /// Gets or sets the invoice lines
        /// </summary>
        public List<ConsolidatedSalesInvoiceLine> Lines { get; set; } = [];

        /// <summary>
        /// Gets or sets the tax subtotals
        /// </summary>
        public List<ConsolidatedSalesTaxSubTotal> TaxSubTotals { get; set; } = [];
    }
}
