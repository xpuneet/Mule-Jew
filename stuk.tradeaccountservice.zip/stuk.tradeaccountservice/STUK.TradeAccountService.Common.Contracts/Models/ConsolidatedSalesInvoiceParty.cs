namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents a party associated with a consolidated sales invoice
    /// </summary>
    public class ConsolidatedSalesInvoiceParty
    {
        /// <summary>
        /// Gets or sets the party role
        /// </summary>
        public string PartyRole { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the party account code
        /// </summary>
        public string? AccountCode { get; set; }

        /// <summary>
        /// Gets or sets the party name
        /// </summary>
        public string? PartyName { get; set; }

        /// <summary>
        /// Gets or sets the original address lines JSON
        /// </summary>
        public string? AddressLinesJson { get; set; }

        /// <summary>
        /// Gets or sets address line one
        /// </summary>
        public string? AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets address line two
        /// </summary>
        public string? AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets address line three
        /// </summary>
        public string? AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets address line four
        /// </summary>
        public string? AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets the street
        /// </summary>
        public string? Street { get; set; }

        /// <summary>
        /// Gets or sets the city
        /// </summary>
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state
        /// </summary>
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postcode
        /// </summary>
        public string? Postcode { get; set; }
    }
}
