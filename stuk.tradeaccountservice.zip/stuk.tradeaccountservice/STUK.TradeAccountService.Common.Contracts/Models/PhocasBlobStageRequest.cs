namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Describes one atomic ConsXref Blob staging request
    /// </summary>
    public class PhocasBlobStageRequest
    {
        /// <summary>
        /// Gets or sets the configured container and optional prefix
        /// </summary>
        public string BlobStagingPath { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the action-prefixed Blob filename
        /// </summary>
        public string BlobName { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the expected generated content length
        /// </summary>
        public long ContentLength { get; set; }

        /// <summary>
        /// Gets or sets the number of data rows in the generated file
        /// </summary>
        public long RowCount { get; set; }

        /// <summary>
        /// Gets or sets the lowercase SHA-256 generated-content hash
        /// </summary>
        public string ContentHash { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the export run identifier
        /// </summary>
        public Guid ExportRunId { get; set; }

        /// <summary>
        /// Gets or sets the export destination work identifier
        /// </summary>
        public Guid ExportDestinationId { get; set; }

        /// <summary>
        /// Gets or sets the end-to-end correlation identifier
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the zero-based durable retry count exposed to the Phocas Function
        /// </summary>
        public int RetryCount { get; set; }
    }
}
