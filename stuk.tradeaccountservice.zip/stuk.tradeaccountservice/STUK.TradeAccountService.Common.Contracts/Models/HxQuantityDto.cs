namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents an invoiced quantity and its unit of measure
    /// </summary>
    public class HxQuantityDto
    {
        /// <summary>
        /// Gets or sets the quantity amount
        /// </summary>
        public decimal? Amount { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure code
        /// </summary>
        public string? UomCode { get; set; }

        /// <summary>
        /// Gets or sets the quantity unit-of-measure description
        /// </summary>
        public string? UomDescription { get; set; }
    }
}
