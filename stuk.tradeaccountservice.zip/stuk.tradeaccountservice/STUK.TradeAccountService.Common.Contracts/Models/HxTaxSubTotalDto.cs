namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents invoice totals for a single tax rate
    /// </summary>
    public class HxTaxSubTotalDto
    {
        /// <summary>
        /// Gets or sets the coded tax rate
        /// </summary>
        public HxCodedDecimalDto? TaxRate { get; set; }

        /// <summary>
        /// Gets or sets the number of invoice lines charged at the tax rate
        /// </summary>
        public int? NumberOfLinesAtRate { get; set; }

        /// <summary>
        /// Gets or sets the total line value at the tax rate
        /// </summary>
        public decimal? TotalValueAtRate { get; set; }

        /// <summary>
        /// Gets or sets the taxable value at the tax rate
        /// </summary>
        public decimal? TaxableValueAtRate { get; set; }

        /// <summary>
        /// Gets or sets the tax charged at the tax rate
        /// </summary>
        public decimal? TaxAtRate { get; set; }

        /// <summary>
        /// Gets or sets the net payment value at the tax rate
        /// </summary>
        public decimal? NetPaymentAtRate { get; set; }

        /// <summary>
        /// Gets or sets the gross payment value at the tax rate
        /// </summary>
        public decimal? GrossPaymentAtRate { get; set; }
    }
}
