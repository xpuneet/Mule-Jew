namespace STUK.TradeAccountService.Common.Contracts.Models
{
    /// <summary>
    /// Represents the durable state of one Workday-to-Concur integration run
    /// </summary>
    public class WorkdayConcurRun
    {
        /// <summary>
        /// Gets or sets the integration run identifier
        /// </summary>
        public Guid RunId { get; set; }

        /// <summary>
        /// Gets or sets the correlation identifier retained for the complete run
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the inclusive lower boundary of the frozen Workday extraction window
        /// </summary>
        public DateTimeOffset ExtractFrom { get; set; }

        /// <summary>
        /// Gets or sets the upper boundary of the frozen Workday extraction window
        /// </summary>
        public DateTimeOffset ExtractThrough { get; set; }

        /// <summary>
        /// Gets or sets the run status stored by the database contract
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the current resumable processing stage
        /// </summary>
        public string CurrentStage { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the stage-specific file identity and state represented as JSON
        /// </summary>
        public string? FileStateJson { get; set; }

        /// <summary>
        /// Gets or sets the Synapse run identifier for TM1 collection
        /// </summary>
        public string? Tm1SynapseRunId { get; set; }

        /// <summary>
        /// Gets or sets the Synapse run identifier for the Concur transformation
        /// </summary>
        public string? TransformSynapseRunId { get; set; }

        /// <summary>
        /// Gets or sets the Synapse run identifier for Concur delivery
        /// </summary>
        public string? DeliverySynapseRunId { get; set; }

        /// <summary>
        /// Gets or sets the Synapse run identifier for file housekeeping
        /// </summary>
        public string? HousekeepingSynapseRunId { get; set; }

        /// <summary>
        /// Gets or sets the number of times this run has been acquired for processing
        /// </summary>
        public int RetryCount { get; set; }

        /// <summary>
        /// Gets or sets the most recent failure category
        /// </summary>
        public string? LastErrorCategory { get; set; }

        /// <summary>
        /// Gets or sets the most recent failure message
        /// </summary>
        public string? LastErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the active processing claim token
        /// </summary>
        public Guid? ClaimToken { get; set; }

        /// <summary>
        /// Gets or sets the Function invocation that owns the active lease
        /// </summary>
        public string? LeaseOwner { get; set; }

        /// <summary>
        /// Gets or sets when the active processing lease expires
        /// </summary>
        public DateTimeOffset? LeaseExpiresOn { get; set; }

        /// <summary>
        /// Gets or sets when the run was created
        /// </summary>
        public DateTimeOffset CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets when the run was most recently updated
        /// </summary>
        public DateTimeOffset UpdatedOn { get; set; }

        /// <summary>
        /// Gets or sets when the run was completed or closed as having no data
        /// </summary>
        public DateTimeOffset? ClosedOn { get; set; }

        /// <summary>
        /// Gets or sets whether this acquisition created the run
        /// </summary>
        public bool IsNew { get; set; }
    }
}
