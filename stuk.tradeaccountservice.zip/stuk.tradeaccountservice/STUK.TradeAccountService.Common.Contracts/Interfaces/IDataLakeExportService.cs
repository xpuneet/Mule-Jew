namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Processes eligible Data Lake destination work from immutable Consolidated Sales snapshots
    /// </summary>
    public interface IDataLakeExportService
    {
        /// <summary>
        /// Claims and processes a bounded number of eligible Data Lake destinations
        /// </summary>
        /// <param name="leaseOwner">The worker instance claiming destination work</param>
        /// <param name="exportDestinationId">The optional destination identifier for a controlled targeted replay</param>
        /// <param name="cancellationToken">Token used to cancel the asynchronous operation</param>
        Task RunAsync(string leaseOwner, Guid? exportDestinationId = null, CancellationToken cancellationToken = default);
    }
}
