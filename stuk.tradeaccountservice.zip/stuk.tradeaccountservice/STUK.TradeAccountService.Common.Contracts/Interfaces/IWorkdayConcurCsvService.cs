using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Maps Workday workers to the Concur employee CSV and stages the result in Azure Blob Storage
    /// </summary>
    public interface IWorkdayConcurCsvService
    {
        /// <summary>
        /// Generates and stages the employee CSV using the reverse-engineered Mule mapping contract
        /// </summary>
        /// <param name="workers">Workday employees to map</param>
        /// <param name="cancellationToken">Token used to cancel the Blob write</param>
        /// <returns>The immutable identity of the staged employee file</returns>
        /// <exception cref="ArgumentException">Thrown when no workers are supplied</exception>
        /// <exception cref="InvalidOperationException">Thrown when required staging configuration is invalid</exception>
        Task<WorkdayConcurFileIdentity> StageAsync(IReadOnlyCollection<WorkdayWorker> workers, CancellationToken cancellationToken = default);
    }
}
