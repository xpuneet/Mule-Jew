using STUK.TradeAccountService.Common.Contracts.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IBlobService
    {
        public Task<List<string>> GetBlobFilesEndingWithAsync(
            string storageAccountName,
            string containerName,
            string endsWith);
        Task<Stream?> GetBlobAsync(string storageAccountName, string containerName, string blobName);

        Task<ColumbusMetaDataFile?> ReadArchiveXmlAsync(
            string storageAccountName,
            string containerName,
            string blobName);

        Task<bool> CopyBlobAsync(
             string storageAccountName,
             string sourceContainer,
             string sourceBlobName,
             string targetContainer,
             string targetBlobName);
        Task<bool> DeleteBlobAsync(
    string storageAccountName,
    string containerName,
    string blobName);
        Task<DocumentMetadataUpdate> GetDocumentMetadataAsync(string storageAccountName, string blobUri, DocumentType docType);
        Task<BlobCleanupResult> DeleteBlobsBeforeRetentionAsync(string storageAccountName, string containerName, int retentionDays);
            Task<int> DeleteEmptyDirectoriesBeforeRetentionAsync(string storageAccountName, string containerName, int retentionDays, CancellationToken cancellationToken = default);
    }
}