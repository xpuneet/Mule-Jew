using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Coordinates the existing Synapse Blob copy and delete pipelines after Concur delivery
    /// </summary>
    public interface IWorkdayConcurHousekeepingService
    {
        /// <summary>
        /// Freezes the output-to-collected and input-to-archive move plan for one completed delivery
        /// </summary>
        /// <param name="outputFiles">Output identities delivered to Concur</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The restart-safe housekeeping checkpoint</returns>
        Task<WorkdayConcurHousekeepingCheckpoint> PrepareAsync(IReadOnlyCollection<WorkdayConcurFileIdentity> outputFiles, CancellationToken cancellationToken = default);

        /// <summary>
        /// Starts the existing Synapse Blob copy pipeline for one persisted move
        /// </summary>
        /// <param name="correlationId">Workday-to-Concur run correlation identifier</param>
        /// <param name="move">Persisted file move marked as copy-starting</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The move containing the copy pipeline run identifier</returns>
        Task<WorkdayConcurFileMove> StartCopyAsync(Guid correlationId, WorkdayConcurFileMove move, CancellationToken cancellationToken = default);

        /// <summary>
        /// Waits for and validates one persisted Synapse Blob copy
        /// </summary>
        /// <param name="move">File move containing the copy pipeline run identifier</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The move updated with the terminal copy result</returns>
        Task<WorkdayConcurFileMove> CompleteCopyAsync(WorkdayConcurFileMove move, CancellationToken cancellationToken = default);

        /// <summary>
        /// Starts the separate Synapse Blob delete pipeline after a validated copy
        /// </summary>
        /// <param name="correlationId">Workday-to-Concur run correlation identifier</param>
        /// <param name="move">Persisted file move marked as delete-starting</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The move containing the delete pipeline run identifier</returns>
        Task<WorkdayConcurFileMove> StartDeleteAsync(Guid correlationId, WorkdayConcurFileMove move, CancellationToken cancellationToken = default);

        /// <summary>
        /// Waits for one persisted Synapse Blob delete
        /// </summary>
        /// <param name="move">File move containing the delete pipeline run identifier</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The move updated with the terminal delete result</returns>
        Task<WorkdayConcurFileMove> CompleteDeleteAsync(WorkdayConcurFileMove move, CancellationToken cancellationToken = default);
    }
}
