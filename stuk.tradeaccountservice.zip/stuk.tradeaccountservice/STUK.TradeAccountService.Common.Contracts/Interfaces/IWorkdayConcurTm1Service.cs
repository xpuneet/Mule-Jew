using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Coordinates the managed Synapse pickup of IBM TM1.csv
    /// </summary>
    public interface IWorkdayConcurTm1Service
    {
        /// <summary>
        /// Starts a new managed TM1 pickup
        /// </summary>
        /// <param name="correlationId">Workday-to-Concur run correlation identifier</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The initial restart-safe checkpoint</returns>
        Task<WorkdayConcurTm1Checkpoint> StartAsync(
            Guid correlationId,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Waits for the managed pickup and validates the resulting input/TM1.csv Blob
        /// </summary>
        /// <param name="checkpoint">Previously persisted Synapse checkpoint</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The completed or terminally failed checkpoint</returns>
        Task<WorkdayConcurTm1Checkpoint> CompleteAsync(
            WorkdayConcurTm1Checkpoint checkpoint,
            CancellationToken cancellationToken = default);
    }
}
