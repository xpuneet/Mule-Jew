using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Retrieves the Workday employees changed within a fixed integration window
    /// </summary>
    public interface IWorkdayWorkersClient
    {
        /// <summary>
        /// Retrieves full employee details for effective and updated workers in the supplied window
        /// </summary>
        /// <param name="from">Inclusive lower boundary of the fixed integration window</param>
        /// <param name="through">Inclusive upper boundary of the fixed integration window</param>
        /// <param name="cancellationToken">Token used to cancel the Workday requests</param>
        /// <returns>Distinct Workday employee details in source discovery order</returns>
        /// <exception cref="ArgumentException">Thrown when the integration window is invalid</exception>
        /// <exception cref="HttpRequestException">Thrown when Workday rejects or cannot complete a request</exception>
        /// <exception cref="InvalidDataException">Thrown when Workday returns an invalid response</exception>
        Task<IReadOnlyList<WorkdayWorker>> GetWorkersAsync(DateTimeOffset from, DateTimeOffset through, CancellationToken cancellationToken = default);
    }
}
