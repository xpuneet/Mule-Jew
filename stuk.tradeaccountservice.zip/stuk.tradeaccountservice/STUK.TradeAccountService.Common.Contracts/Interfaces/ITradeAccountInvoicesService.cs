﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface ITradeAccountInvoicesService
    {
        Task<InvoiceResponse?> GetInvoiceByStandardInvoiceNoAsync(string invoiceId, string branchCode, CancellationToken cancellationToken = default);
        Task<DocumentSearchResponse?> FilterInvoiceDocumentsAsync(InvoiceFilterRequest request, char documentType = 'S', CancellationToken cancellationToken = default);
        Task<DocumentSearchResponse?> SearchInvoiceByFilterParamAsync(InvoiceSearchFilterRequest request, char documentType = 'S', CancellationToken cancellationToken = default);
    }
}
