namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Orchestrates the ingestion of a staged HX consolidated sales file
    /// </summary>
    public interface IConsolidatedSalesIngestionService
    {
        /// <summary>
        /// Discovers staged files and processes eligible SQL-backed ingestion work
        /// </summary>
        /// <param name="leaseOwner">The Function invocation that owns the processing lease</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task RunAsync(string leaseOwner, CancellationToken cancellationToken = default);
    }
}
