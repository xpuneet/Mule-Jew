namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Coordinates a scheduled Workday-to-Concur integration run
    /// </summary>
    public interface IWorkdayConcurOrchestrationService
    {
        /// <summary>
        /// Starts or resumes Workday-to-Concur processing for a Function invocation
        /// </summary>
        /// <param name="correlationId">The Function invocation identifier used to correlate the run</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task RunAsync(string correlationId, CancellationToken cancellationToken = default);
    }
}
