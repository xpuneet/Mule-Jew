using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Provides canonical consolidated sales invoice persistence operations
    /// </summary>
    public interface IConsolidatedInvoiceDataService
    {
        /// <summary>
        /// Commits a complete canonical invoice hierarchy for a claimed source file
        /// </summary>
        /// <param name="sourceItemId">The claimed source-item identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="invoice">The complete canonical consolidated invoice</param>
        /// <param name="salesforceCooloffStartedOn">The durable UTC time at which Trade Account first read the complete source file</param>
        /// <param name="salesforceCooloffHours">The effective configured Salesforce cool-off duration</param>
        /// <param name="salesforceEligibleOn">The persisted UTC Salesforce eligibility time</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The committed consolidated invoice details</returns>
        Task<ConsolidatedSalesCommitResult> CommitAsync(
            Guid sourceItemId,
            Guid claimToken,
            ConsolidatedSalesInvoice invoice,
            DateTimeOffset salesforceCooloffStartedOn,
            int salesforceCooloffHours,
            DateTimeOffset salesforceEligibleOn,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets a complete canonical invoice hierarchy by consolidated invoice number
        /// </summary>
        /// <param name="consolidatedInvoiceNumber">The consolidated invoice business number</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The matching canonical invoice, or null when it does not exist</returns>
        Task<ConsolidatedSalesInvoice?> GetByNumberAsync(string consolidatedInvoiceNumber, CancellationToken cancellationToken = default);
    }
}
