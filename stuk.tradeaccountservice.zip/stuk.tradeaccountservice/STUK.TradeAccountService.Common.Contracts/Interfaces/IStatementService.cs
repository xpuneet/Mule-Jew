﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IStatementService
    {
        Task<StatementSearchResponse?> SearchStatementsAsync(StatementSearchRequest searchParams, CancellationToken cancellationToken = default);
    }
}
