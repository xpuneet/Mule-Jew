using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Provides durable Salesforce delivery state and audit operations
    /// </summary>
    public interface ISalesforceSyncDataService
    {
        /// <summary>
        /// Claims the next consolidated invoice eligible for Salesforce delivery
        /// </summary>
        /// <param name="leaseOwner">The worker instance claiming the Salesforce work</param>
        /// <param name="leaseDurationSeconds">The duration of the processing lease in seconds</param>
        /// <param name="maximumRetryCount">The maximum permitted delivery attempts</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The claimed Salesforce work, or null when no item is eligible</returns>
        Task<ConsolidatedSalesforceWork?> ClaimNextAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets the canonical invoice and line state for claimed Salesforce work
        /// </summary>
        /// <param name="salesforceWorkId">The Salesforce work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The complete canonical details required for Salesforce delivery</returns>
        Task<ConsolidatedSalesforceWorkDetails?> GetDetailsAsync(Guid salesforceWorkId, Guid claimToken, CancellationToken cancellationToken = default);

        /// <summary>
        /// Renews the lease held for Salesforce work
        /// </summary>
        /// <param name="salesforceWorkId">The Salesforce work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="leaseDurationSeconds">The renewed lease duration in seconds</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The renewed lease details</returns>
        Task<ConsolidatedSalesLeaseResult> RenewLeaseAsync(Guid salesforceWorkId, Guid claimToken, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Marks one Salesforce line as completed
        /// </summary>
        /// <param name="salesforceWorkId">The Salesforce work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="externalId">The deterministic Salesforce line external identifier</param>
        /// <param name="salesforceProductId">The Salesforce Product2 identifier</param>
        /// <param name="salesforcePricebookEntryId">The Salesforce PricebookEntry identifier</param>
        /// <param name="salesforceOrderItemId">The Salesforce OrderItem identifier</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task CompleteLineAsync(Guid salesforceWorkId, Guid claimToken, string externalId, string salesforceProductId, string salesforcePricebookEntryId, string salesforceOrderItemId, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Records a Salesforce line failure
        /// </summary>
        /// <param name="salesforceWorkId">The Salesforce work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="externalId">The deterministic Salesforce line external identifier</param>
        /// <param name="errorMessage">The Salesforce failure detail</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task FailLineAsync(Guid salesforceWorkId, Guid claimToken, string externalId, string errorMessage, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Marks Salesforce work as completed after the expected line count is verified
        /// </summary>
        /// <param name="salesforceWorkId">The Salesforce work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="salesforceOrderId">The Salesforce Order identifier</param>
        /// <param name="actualLineCount">The verified Salesforce OrderItem count</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task CompleteWorkAsync(Guid salesforceWorkId, Guid claimToken, string salesforceOrderId, int actualLineCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Records an invoice-level Salesforce failure and schedules retry or terminal failure
        /// </summary>
        /// <param name="salesforceWorkId">The Salesforce work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="errorCategory">The failure category</param>
        /// <param name="errorMessage">The failure detail</param>
        /// <param name="nextAttemptOn">The UTC time at which the item becomes eligible for retry</param>
        /// <param name="maximumRetryCount">The maximum permitted failed attempts</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The resulting failure and retry state</returns>
        Task<ConsolidatedSalesWorkFailureResult> FailWorkAsync(Guid salesforceWorkId, Guid claimToken, string errorCategory, string errorMessage, DateTimeOffset? nextAttemptOn, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Appends an immutable audit record for one Salesforce operation
        /// </summary>
        /// <param name="attempt">The Salesforce request and response audit details</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The inserted audit identifier and timestamp</returns>
        Task<ConsolidatedSalesforceAttemptResult> InsertAttemptAsync(ConsolidatedSalesforceAttempt attempt, CancellationToken cancellationToken = default);

        /// <summary>
        /// Requeues Salesforce work following an approved operational action
        /// </summary>
        /// <param name="salesforceWorkId">The Salesforce work identifier</param>
        /// <param name="reason">The approved reason for requeuing the item</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task RequeueAsync(Guid salesforceWorkId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default);
    }
}
