﻿namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IStatementDownloadService : IDocumentDownloadHandler<long, string?> { }
    public interface IInvoiceDownloadService : IDocumentDownloadHandler<string, string> { }
}
