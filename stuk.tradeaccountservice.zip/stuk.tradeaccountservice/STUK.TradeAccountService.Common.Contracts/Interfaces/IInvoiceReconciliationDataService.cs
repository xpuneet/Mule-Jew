using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Provides durable delayed matching operations for existing invoice records
    /// </summary>
    public interface IInvoiceReconciliationDataService
    {
        /// <summary>
        /// Claims the next component invoice eligible for reconciliation
        /// </summary>
        /// <param name="leaseOwner">The worker instance claiming the reconciliation work</param>
        /// <param name="leaseDurationSeconds">The duration of the processing lease in seconds</param>
        /// <param name="maximumRetryCount">The attempt ceiling used to terminally fail abandoned reconciliation work</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The claimed reconciliation work, or null when no item is eligible</returns>
        Task<ConsolidatedSalesReconciliationWork?> ClaimNextAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Matches an existing invoice by standard invoice number and branch code and updates the two approved consolidated-invoice fields when exactly one match exists
        /// </summary>
        /// <param name="standardInvoiceNumber">The ordinary invoice number</param>
        /// <param name="branchCode">The branch code</param>
        /// <param name="consolidatedInvoiceNumber">The consolidated invoice number to apply</param>
        /// <param name="consolidatedInvoiceDate">The consolidated invoice date to apply</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The number of matching invoice headers and matched identifier</returns>
        Task<InvoiceReconciliationMatchResult> MatchAndUpdateInvoiceAsync(string standardInvoiceNumber, string branchCode, string consolidatedInvoiceNumber, DateOnly? consolidatedInvoiceDate, CancellationToken cancellationToken = default);

        /// <summary>
        /// Completes claimed reconciliation work after the existing invoice update succeeds
        /// </summary>
        /// <param name="reconciliationWorkId">The reconciliation work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="matchedInvoiceHeaderId">The matched existing invoice header identifier</param>
        /// <param name="now">The optional UTC completion time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task CompleteAsync(Guid reconciliationWorkId, Guid claimToken, Guid matchedInvoiceHeaderId, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Defers reconciliation when the ordinary invoice has not arrived yet
        /// </summary>
        /// <param name="reconciliationWorkId">The reconciliation work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="nextAttemptOn">The UTC time at which the item becomes eligible for retry</param>
        /// <param name="reason">The reason that matching could not yet complete</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The resulting deferred work state</returns>
        Task<ConsolidatedSalesWorkFailureResult> DeferAsync(Guid reconciliationWorkId, Guid claimToken, DateTimeOffset nextAttemptOn, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Records a reconciliation failure and schedules retry or terminal failure
        /// </summary>
        /// <param name="reconciliationWorkId">The reconciliation work identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="errorCategory">The failure category</param>
        /// <param name="errorMessage">The failure detail</param>
        /// <param name="nextAttemptOn">The UTC time at which the item becomes eligible for retry</param>
        /// <param name="maximumRetryCount">The maximum permitted failed attempts</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The resulting failure and retry state</returns>
        Task<ConsolidatedSalesWorkFailureResult> FailAsync(Guid reconciliationWorkId, Guid claimToken, string errorCategory, string errorMessage, DateTimeOffset? nextAttemptOn, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Requeues reconciliation work following an approved operational action
        /// </summary>
        /// <param name="reconciliationWorkId">The reconciliation work identifier</param>
        /// <param name="reason">The approved reason for requeuing the item</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task RequeueAsync(Guid reconciliationWorkId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default);
    }
}
