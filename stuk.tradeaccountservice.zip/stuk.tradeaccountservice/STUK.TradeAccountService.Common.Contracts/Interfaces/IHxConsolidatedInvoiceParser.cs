using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Parses consolidated invoice files produced by HX into source-specific invoice DTOs
    /// </summary>
    public interface IHxConsolidatedInvoiceParser
    {
        /// <summary>
        /// Reads an HX consolidated invoice stream and returns each contained invoice in source order
        /// The input is processed without loading the complete file into memory. If normal XML parsing
        /// fails, the parser applies the approved narrow sanitisation rules and retries once
        /// </summary>
        /// <param name="source">The readable HX consolidated invoice stream</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>An asynchronous sequence of HX invoice DTOs</returns>
        /// <exception cref="ArgumentException">Thrown when <paramref name="source"/> is not readable</exception>
        /// <exception cref="HxInvoiceParseException">
        /// Thrown when the document is unsupported, remains malformed after sanitisation, or contains
        /// a typed value that cannot be converted safely
        /// </exception>
        IAsyncEnumerable<HxInvoiceDto> ParseAsync(Stream source, CancellationToken cancellationToken = default);

        /// <summary>
        /// Reads an HX consolidated invoice stream and reports whether sanitisation was required
        /// </summary>
        /// <param name="source">The readable HX consolidated invoice stream</param>
        /// <param name="metadata">The metadata populated while preparing the source stream</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>An asynchronous sequence of HX invoice DTOs</returns>
        /// <exception cref="ArgumentException">Thrown when <paramref name="source"/> is not readable</exception>
        /// <exception cref="HxInvoiceParseException">
        /// Thrown when the document is unsupported, remains malformed after sanitisation, or contains
        /// a typed value that cannot be converted safely
        /// </exception>
        IAsyncEnumerable<HxInvoiceDto> ParseAsync(Stream source, HxInvoiceParseMetadata metadata, CancellationToken cancellationToken = default);
    }
}
