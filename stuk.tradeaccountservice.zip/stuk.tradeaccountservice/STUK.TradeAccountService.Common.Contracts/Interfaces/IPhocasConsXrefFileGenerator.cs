using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Generates the legacy-compatible annual Phocas ConsXref file
    /// </summary>
    public interface IPhocasConsXrefFileGenerator
    {
        /// <summary>
        /// Writes a completed immutable Salesforce snapshot to the supplied stream
        /// </summary>
        /// <param name="exportRunId">The completed export run identifier</param>
        /// <param name="exportYear">The year represented by the annual Phocas file</param>
        /// <param name="destination">The writable output stream</param>
        /// <param name="cancellationToken">Token used to cancel the asynchronous operation</param>
        /// <returns>The generated filename and content evidence</returns>
        /// <exception cref="ArgumentException">Thrown when the export year or stream is invalid</exception>
        /// <exception cref="InvalidDataException">Thrown when the durable snapshot violates the legacy file contract</exception>
        Task<ConsolidatedSalesExportFileResult> GenerateAsync(
            Guid exportRunId,
            int exportYear,
            Stream destination,
            CancellationToken cancellationToken = default);
    }
}
