using Azure.Storage.Blobs;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Creates authenticated Blob service clients for File Transfer endpoints
    /// </summary>
    public interface IWorkdayConcurBlobServiceClientFactory
    {
        /// <summary>
        /// Creates a Blob service client for the supplied endpoint
        /// </summary>
        /// <param name="serviceEndpoint">Azure Blob service endpoint</param>
        /// <returns>An authenticated Blob service client</returns>
        BlobServiceClient Create(Uri serviceEndpoint);
    }
}
