using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Provides durable source-file processing operations for consolidated sales ingestion
    /// </summary>
    public interface IConsolidatedSalesFileDataService
    {
        /// <summary>
        /// Registers a staged HX file idempotently
        /// </summary>
        /// <param name="registration">The staged HX file registration details</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The registered source item</returns>
        Task<ConsolidatedSalesSourceItem> RegisterAsync(ConsolidatedSalesSourceRegistration registration, CancellationToken cancellationToken = default);

        /// <summary>
        /// Claims the next source file eligible for ingestion
        /// </summary>
        /// <param name="leaseOwner">The worker instance claiming the source file</param>
        /// <param name="leaseDurationSeconds">The duration of the processing lease in seconds</param>
        /// <param name="maximumRetryCount">The maximum permitted processing attempts</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The claimed source item, or null when no item is eligible</returns>
        Task<ConsolidatedSalesSourceItem?> ClaimNextAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Records and returns the immutable first successful read time for a claimed source file
        /// </summary>
        /// <param name="sourceItemId">The claimed source-item identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="now">The optional UTC read-completion time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The durable first successful read time</returns>
        Task<DateTimeOffset> RecordFirstReadAsync(Guid sourceItemId, Guid claimToken, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Renews the lease held for a claimed source file
        /// </summary>
        /// <param name="sourceItemId">The claimed source-item identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="leaseDurationSeconds">The renewed lease duration in seconds</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The renewed lease details</returns>
        Task<ConsolidatedSalesLeaseResult> RenewLeaseAsync(Guid sourceItemId, Guid claimToken, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Marks a claimed source file as successfully processed
        /// </summary>
        /// <param name="sourceItemId">The claimed source-item identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="sanitisationUsed">Whether sanitisation was required to parse the source file</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        Task CompleteAsync(Guid sourceItemId, Guid claimToken, bool sanitisationUsed, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Records a source-file failure and schedules retry or terminal failure
        /// </summary>
        /// <param name="sourceItemId">The claimed source-item identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="errorCategory">The failure category</param>
        /// <param name="errorMessage">The failure detail</param>
        /// <param name="nextAttemptOn">The UTC time at which the item becomes eligible for retry</param>
        /// <param name="maximumRetryCount">The maximum permitted failed attempts</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The resulting failure and retry state</returns>
        Task<ConsolidatedSalesSourceFailureResult> FailAsync(Guid sourceItemId, Guid claimToken, string errorCategory, string errorMessage, DateTimeOffset? nextAttemptOn, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Records an unparseable source-file version and waits for support to replace or edit the Blob
        /// </summary>
        /// <param name="sourceItemId">The claimed source-item identifier</param>
        /// <param name="claimToken">The token proving ownership of the current claim</param>
        /// <param name="errorCategory">The parsing failure category</param>
        /// <param name="errorMessage">The safe parsing failure detail</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The resulting correction state</returns>
        Task<ConsolidatedSalesSourceFailureResult> AwaitCorrectionAsync(
            Guid sourceItemId,
            Guid claimToken,
            string errorCategory,
            string errorMessage,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Requeues a source file following an approved operational action
        /// </summary>
        /// <param name="sourceItemId">The source-item identifier</param>
        /// <param name="reason">The approved reason for requeuing the item</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        Task RequeueAsync(Guid sourceItemId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default);
    }
}
