﻿using STUK.TradeAccountService.Common.Contracts.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IColumbusWebService
    {
      Task<ColumbusOpenSessionResult> OpenSessionAsync(string username, string password);
        Task<int> CloseSessionAsync(string sessionId);
        Task<(int ErrorNumber, string? ErrorMessage)> BeginSearchOperationAsync(string sessionId,int archiveId, int maxMatches, string docType, string accountCode,string branchNo,string? documentNo,string startDate,string endDate, string? continueSearch = null);
        Task<ColumbusSearchResult> GetSearchResultsAsync(string sessionId);
        Task<(int ErrorNumber, string? ErrorMessage)> BeginPageOperationAsync(string sessionId, int matchlistEntryNumber);
        Task<ColumbusPageResponse> GetPageResultsAndUploadToBlobAsync(string sessionId,string accountCode,string branchNo,string? documentNo,int pageNo,int totalPages,string date,string storageAccountUrl,string containerName);
    }
}
