using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Starts and observes pipeline runs in the existing Concur Synapse workspace
    /// </summary>
    public interface IConcurSynapsePipelineClient
    {
        /// <summary>
        /// Starts a named Concur Synapse pipeline
        /// </summary>
        /// <param name="pipelineName">Published pipeline name</param>
        /// <param name="parameters">Pipeline parameters</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The Synapse run identifier</returns>
        Task<string> StartAsync(string pipelineName, IReadOnlyDictionary<string, object?> parameters, CancellationToken cancellationToken = default);

        /// <summary>
        /// Waits until a Concur Synapse run reaches a terminal state
        /// </summary>
        /// <param name="runId">Synapse run identifier</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The terminal Synapse run state</returns>
        Task<SynapsePipelineRun> WaitForCompletionAsync(string runId, CancellationToken cancellationToken = default);
    }
}
