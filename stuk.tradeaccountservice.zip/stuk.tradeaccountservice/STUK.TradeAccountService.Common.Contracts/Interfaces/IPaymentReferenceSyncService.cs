﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IPaymentReferenceSyncService
    {
        Task<IEnumerable<PendingPaymentReference>> GetPendingPaymentsAsync(CancellationToken cancellationToken = default);
        Task UpdatePendingPaymentsAsync(IEnumerable<UpdatePaymentReference> results, CancellationToken cancellationToken = default);
    }
}
