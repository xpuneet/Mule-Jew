using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Encrypts selected Concur output files and delivers them through the managed Synapse transfer pipeline
    /// </summary>
    public interface IWorkdayConcurDeliveryService
    {
        /// <summary>
        /// Encrypts and stages every selected output in one correlation-specific Blob folder
        /// </summary>
        /// <param name="correlationId">Workday-to-Concur run correlation identifier</param>
        /// <param name="outputFiles">Immutable output identities selected after transformation</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The restart-safe delivery checkpoint</returns>
        Task<WorkdayConcurDeliveryCheckpoint> PrepareAsync(Guid correlationId, IReadOnlyCollection<WorkdayConcurFileIdentity> outputFiles, CancellationToken cancellationToken = default);

        /// <summary>
        /// Starts one managed Synapse delivery for an already persisted staging checkpoint
        /// </summary>
        /// <param name="correlationId">Workday-to-Concur run correlation identifier</param>
        /// <param name="checkpoint">Persisted encrypted staging checkpoint</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The checkpoint containing the external Synapse run identifier</returns>
        Task<WorkdayConcurDeliveryCheckpoint> StartAsync(Guid correlationId, WorkdayConcurDeliveryCheckpoint checkpoint, CancellationToken cancellationToken = default);

        /// <summary>
        /// Waits for the managed delivery and verifies that Synapse processed every staged encrypted file
        /// </summary>
        /// <param name="checkpoint">Previously persisted delivery checkpoint</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The updated terminal delivery checkpoint</returns>
        Task<WorkdayConcurDeliveryCheckpoint> CompleteAsync(WorkdayConcurDeliveryCheckpoint checkpoint, CancellationToken cancellationToken = default);
    }
}
