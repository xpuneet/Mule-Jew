﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IDocumentDownloadHandler<TId, TId2>
    {
        Task<DocumentDownloadRequestResponse> RequestDownloadAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default);
        Task<DocumentDownloadResponse> DownloadAsync(Guid token, CancellationToken cancellationToken = default);
    }
}
