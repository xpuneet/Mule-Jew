using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Provides access to staged HX consolidated sales files in Blob Storage
    /// </summary>
    public interface IConsolidatedSalesBlobSource
    {
        /// <summary>
        /// Discovers supported staged HX files and returns their immutable registration details
        /// </summary>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The supported staged HX files</returns>
        IAsyncEnumerable<ConsolidatedSalesSourceRegistration> DiscoverAsync(CancellationToken cancellationToken = default);

        /// <summary>
        /// Opens a staged HX file as a readable stream
        /// </summary>
        /// <param name="containerName">The Blob container name</param>
        /// <param name="blobPath">The path of the file within the Blob container</param>
        /// <param name="expectedETag">The entity tag of the exact Blob version claimed in SQL</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The readable Blob stream</returns>
        Task<Stream> OpenReadAsync(
            string containerName,
            string blobPath,
            string expectedETag,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Renames a successfully processed Blob by appending the processed suffix to its full path
        /// </summary>
        /// <param name="containerName">The Blob container name</param>
        /// <param name="blobPath">The path of the source file within the Blob container</param>
        /// <param name="expectedContentLength">The expected source-file length used to verify the copied Blob</param>
        /// <param name="expectedETag">The entity tag of the exact Blob version claimed in SQL</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        Task RenameAsProcessedAsync(
            string containerName,
            string blobPath,
            long expectedContentLength,
            string expectedETag,
            CancellationToken cancellationToken = default);
    }
}
