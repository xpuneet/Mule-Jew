namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Generates the legacy-compatible Data Lake completion token
    /// </summary>
    public interface IDataLakeCompletionTokenGenerator
    {
        /// <summary>
        /// Generates the five-field pipe-separated completion token
        /// </summary>
        /// <param name="completedOn">The UTC dataset completion time</param>
        /// <param name="tokenFileName">The established token filename</param>
        /// <returns>The UTF-8 token bytes</returns>
        byte[] Generate(DateTimeOffset completedOn, string tokenFileName);
    }
}
