namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Encrypts Concur file content using the recipient's OpenPGP public key
    /// </summary>
    public interface IConcurPgpEncryptionService
    {
        /// <summary>
        /// Writes an ASCII-armored AES-256 OpenPGP message with integrity protection
        /// </summary>
        /// <param name="source">Plaintext source positioned at the content to encrypt</param>
        /// <param name="destination">Writable destination for the encrypted content</param>
        /// <param name="publicKey">ASCII-armored Concur public key</param>
        /// <param name="keyId">Expected hexadecimal key identifier</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous encryption operation</returns>
        /// <exception cref="ArgumentException">Thrown when a required input is invalid</exception>
        /// <exception cref="InvalidDataException">Thrown when the expected key is absent from the supplied keyring</exception>
        Task EncryptAsync(Stream source, Stream destination, string publicKey, string keyId, CancellationToken cancellationToken = default);
    }
}
