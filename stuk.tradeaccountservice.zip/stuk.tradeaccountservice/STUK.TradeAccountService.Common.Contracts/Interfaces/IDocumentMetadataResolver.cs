﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IDocumentMetadataResolver<TId, TId2>
    {
        Task<DocumentMetadata?> GetMetadataAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default);
        Task RequestDocumentAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default);
        Task<DocumentDownloadCacheEntry?> GetCacheByIdentifierAsync(TId identifier, TId2? param1, CancellationToken cancellationToken = default);
        Task<(Guid Token, DateTimeOffset ExpiresOn)> InsertCacheAsync(TId identifier, TId2? param1, string downloadStatus, CancellationToken cancellationToken = default);
        Task<DocumentDownloadCacheEntry?> GetCacheByTokenAsync(Guid token, CancellationToken cancellationToken = default);
        Task DeleteCacheByTokenAsync(Guid token, CancellationToken cancellationToken);
        string DocumentType { get; }
        string ContainerName { get; }
        string? FilePrepareRequestUrl { get; }
        string DefaultFileName { get; }
        TId ParseIdentifier(string identifier);
        TId2? ParseParam1(string? param1);
    }
}
