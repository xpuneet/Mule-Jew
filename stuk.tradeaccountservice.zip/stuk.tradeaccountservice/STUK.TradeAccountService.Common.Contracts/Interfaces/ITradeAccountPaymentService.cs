﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
  public interface ITradeAccountPaymentService
  {
    Task<Payment?> GetPayementReferenceByRefCodeAsync(Guid paymentRef, CancellationToken cancellationToken = default);
    Task<CreatePaymentResponse?> CreatePayementreferenceAsync(CreatePaymentRequest request, CancellationToken cancellationToken = default);
  }
}
