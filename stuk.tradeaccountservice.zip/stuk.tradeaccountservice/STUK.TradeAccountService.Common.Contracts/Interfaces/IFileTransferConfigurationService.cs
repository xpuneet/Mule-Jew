using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Reads managed transfer configuration from the existing File Transfer Database
    /// </summary>
    public interface IFileTransferConfigurationService
    {
        /// <summary>
        /// Gets the action and connections used for the TM1 pickup
        /// </summary>
        /// <param name="integrationKeyId">Existing file-transfer integration identifier</param>
        /// <param name="actionName">Existing pickup action name</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The managed TM1 transfer configuration</returns>
        Task<WorkdayConcurTm1TransferConfiguration> GetTm1PickupAsync(
            string integrationKeyId,
            string actionName,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets the action and both connections used for Concur delivery
        /// </summary>
        /// <param name="integrationKeyId">Existing file-transfer integration identifier</param>
        /// <param name="actionName">Existing delivery action name</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The managed Concur delivery configuration</returns>
        Task<WorkdayConcurDeliveryTransferConfiguration> GetConcurDeliveryAsync(string integrationKeyId, string actionName, CancellationToken cancellationToken = default);
    }
}
