using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Provides stored-procedure access to durable Workday-to-Concur run state
    /// </summary>
    public interface IWorkdayConcurStateService
    {
        /// <summary>
        /// Atomically resumes the incomplete run or creates and claims the next frozen window
        /// </summary>
        /// <param name="correlationId">Correlation identifier used when a new run is created</param>
        /// <param name="leaseOwner">Function invocation that will own the processing lease</param>
        /// <param name="extractThrough">Upper boundary to freeze if a new run is created</param>
        /// <param name="leaseDurationSeconds">Duration of the processing lease in seconds</param>
        /// <param name="now">Optional deterministic operation time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The claimed run, or <see langword="null"/> when another invocation owns it</returns>
        Task<WorkdayConcurRun?> CreateOrResumeRunAsync(Guid correlationId, string leaseOwner, DateTimeOffset extractThrough, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets the current incomplete run without acquiring it
        /// </summary>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The incomplete run, or <see langword="null"/> when none exists</returns>
        Task<WorkdayConcurRun?> GetIncompleteRunAsync(CancellationToken cancellationToken = default);

        /// <summary>
        /// Extends the lease held by the current Function invocation
        /// </summary>
        /// <param name="runId">Run identifier</param>
        /// <param name="claimToken">Current claim token</param>
        /// <param name="leaseDurationSeconds">Duration of the renewed lease in seconds</param>
        /// <param name="now">Optional deterministic operation time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task RenewLeaseAsync(Guid runId, Guid claimToken, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Moves a claimed run between resumable stages and records related external state
        /// </summary>
        /// <param name="runId">Run identifier</param>
        /// <param name="claimToken">Current claim token</param>
        /// <param name="expectedStage">Stage that must currently be persisted</param>
        /// <param name="newStage">Stage to persist</param>
        /// <param name="fileStateJson">Optional stage-specific file identity and state JSON</param>
        /// <param name="tm1SynapseRunId">Optional TM1 transfer Synapse run identifier</param>
        /// <param name="transformSynapseRunId">Optional transformation Synapse run identifier</param>
        /// <param name="deliverySynapseRunId">Optional delivery Synapse run identifier</param>
        /// <param name="housekeepingSynapseRunId">Optional housekeeping Synapse run identifier</param>
        /// <param name="now">Optional deterministic operation time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task UpdateStageAsync(
            Guid runId,
            Guid claimToken,
            WorkdayConcurRunStage expectedStage,
            WorkdayConcurRunStage newStage,
            string? fileStateJson = null,
            string? tm1SynapseRunId = null,
            string? transformSynapseRunId = null,
            string? deliverySynapseRunId = null,
            string? housekeepingSynapseRunId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Records a recoverable failure and releases the active lease
        /// </summary>
        /// <param name="runId">Run identifier</param>
        /// <param name="claimToken">Current claim token</param>
        /// <param name="errorCategory">Stable failure category</param>
        /// <param name="errorMessage">Failure description</param>
        /// <param name="now">Optional deterministic operation time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task FailRunAsync(Guid runId, Guid claimToken, string errorCategory, string errorMessage, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Releases the active lease without closing or changing the run stage
        /// </summary>
        /// <param name="runId">Run identifier</param>
        /// <param name="claimToken">Current claim token</param>
        /// <param name="now">Optional deterministic operation time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task ReleaseLeaseAsync(Guid runId, Guid claimToken, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Closes a no-data run without advancing the committed Workday watermark
        /// </summary>
        /// <param name="runId">Run identifier</param>
        /// <param name="claimToken">Current claim token</param>
        /// <param name="now">Optional deterministic operation time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task CompleteNoDataRunAsync(Guid runId, Guid claimToken, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Completes a run and atomically advances the committed Workday watermark
        /// </summary>
        /// <param name="runId">Run identifier</param>
        /// <param name="claimToken">Current claim token</param>
        /// <param name="now">Optional deterministic operation time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        Task CommitRunAsync(Guid runId, Guid claimToken, DateTimeOffset? now = null, CancellationToken cancellationToken = default);
    }
}
