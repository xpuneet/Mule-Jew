﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IPreferredBranchService
    {
        Task<PreferredBranchData?> GetPreferredBranchAsync(string accountCode, CancellationToken cancellationToken = default);
        Task<PreferredBranchData?> SetPreferredBranchAsync(string accountCode, string? preferredBranch, CancellationToken cancellationToken = default);
    }
}
