using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Parses Workday Get_Workers SOAP responses into integration models
    /// </summary>
    public interface IWorkdayWorkerResponseParser
    {
        /// <summary>
        /// Parses employee identifiers and paging metadata from a worker-reference response
        /// </summary>
        /// <param name="responseXml">Workday SOAP response content</param>
        /// <returns>The employee identifiers and paging metadata returned by Workday</returns>
        /// <exception cref="IOException">Thrown when the response is a SOAP fault or has an invalid shape</exception>
        WorkdayWorkerReferencePage ParseReferencePage(string responseXml);

        /// <summary>
        /// Parses complete worker records and paging metadata from a worker-detail response
        /// </summary>
        /// <param name="responseXml">Workday SOAP response content</param>
        /// <returns>The worker details and paging metadata returned by Workday</returns>
        /// <exception cref="IOException">Thrown when the response is a SOAP fault or has an invalid shape</exception>
        WorkdayWorkerPage ParseWorkerPage(string responseXml);
    }
}
