using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Starts and observes Azure Synapse pipeline runs without using a callback
    /// </summary>
    public interface ISynapsePipelineClient
    {
        /// <summary>
        /// Starts a named Synapse pipeline
        /// </summary>
        /// <param name="pipelineName">Published pipeline name</param>
        /// <param name="parameters">Pipeline parameters</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The Synapse run identifier</returns>
        Task<string> StartAsync(
            string pipelineName,
            IReadOnlyDictionary<string, object?> parameters,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Waits until a Synapse run reaches a terminal state
        /// </summary>
        /// <param name="runId">Synapse run identifier</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The terminal Synapse run state</returns>
        Task<SynapsePipelineRun> WaitForCompletionAsync(
            string runId,
            CancellationToken cancellationToken = default);
    }
}
