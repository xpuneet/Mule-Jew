﻿using STUK.TradeAccountService.Common.Contracts.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IColumbusStatementDownloadService
    {

        Task DownloadAndSyncStatementsAsync();

        Task<IEnumerable<ColumbusStatementHeader>> SearchUnSynchronizedStatementDocuments();

        Task<int> UpdateStatementHeader(ColumbusStatementHeaderMetadataRequest request);

        Task<ColumbusStatementHeaderMetadataRequest?> DownloadStatementByStatementHeaderIdAsync(long statementHeaderId);

        bool DownloadStatementByStatementHeaderId(long statementHeaderId);

    }
}
