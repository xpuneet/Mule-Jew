using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Maps HX consolidated invoice data into the canonical Consolidated Sales model
    /// </summary>
    public interface IHxInvoiceMapper
    {
        /// <summary>
        /// Maps one parsed HX invoice into its source-neutral canonical representation
        /// </summary>
        /// <param name="source">The parsed HX invoice</param>
        /// <param name="correlationId">The correlation identifier for the ingestion operation</param>
        /// <returns>The canonical Consolidated Sales invoice</returns>
        ConsolidatedSalesInvoice Map(HxInvoiceDto source, Guid correlationId);
    }
}
