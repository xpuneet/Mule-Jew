using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Atomically commits generated ConsXref content to the watched Phocas Blob location
    /// </summary>
    public interface IPhocasBlobStagingClient
    {
        /// <summary>
        /// Stages a complete Blob or returns the matching existing hand-off idempotently
        /// </summary>
        /// <param name="request">The Blob path, identity and content evidence</param>
        /// <param name="content">The complete seekable generated file content</param>
        /// <param name="cancellationToken">Token used to cancel the asynchronous operation</param>
        /// <returns>The committed Blob identity</returns>
        Task<PhocasBlobStageResult> StageAsync(PhocasBlobStageRequest request, Stream content, CancellationToken cancellationToken = default);
    }
}
