namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Claims and stages eligible Phocas destination work from immutable export snapshots
    /// </summary>
    public interface IPhocasExportStagingService
    {
        /// <summary>
        /// Processes the configured maximum number of eligible Phocas staging items
        /// </summary>
        /// <param name="leaseOwner">The Function invocation identifier owning each SQL lease</param>
        /// <param name="exportDestinationId">The optional destination identifier for a controlled targeted replay</param>
        /// <param name="cancellationToken">Token used to cancel the operation</param>
        /// <returns>A task representing the asynchronous operation</returns>
        /// <exception cref="ArgumentException">Thrown when the lease owner is empty</exception>
        /// <exception cref="InvalidOperationException">Thrown when required staging configuration is invalid</exception>
        Task RunAsync(string leaseOwner, Guid? exportDestinationId = null, CancellationToken cancellationToken = default);
    }
}
