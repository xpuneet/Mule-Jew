using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Starts the Mule-free Synapse Concur transformation and selects its output files
    /// </summary>
    public interface IWorkdayConcurTransformationService
    {
        /// <summary>
        /// Starts the configured Mule-free Concur parent pipeline
        /// </summary>
        /// <param name="correlationId">Correlation identifier retained across the integration run</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The in-progress transformation checkpoint</returns>
        Task<WorkdayConcurTransformationCheckpoint> StartAsync(Guid correlationId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Waits for the existing Synapse run and selects every non-directory output Blob
        /// </summary>
        /// <param name="checkpoint">The persisted transformation checkpoint</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The completed or failed transformation checkpoint</returns>
        Task<WorkdayConcurTransformationCheckpoint> CompleteAsync(WorkdayConcurTransformationCheckpoint checkpoint, CancellationToken cancellationToken = default);
    }
}
