﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces;

public interface IColumbusInvoiceDownloadService
{
    Task DownloadAndSyncInvoicesAsync();
    Task<int> UpdateInvoiceHeader(UpdateInvoiceHeaderRequest request);
    Task<ColumbusInvoiceHeader?> GetInvoiceByStandardInvoiceNumberAndBranchCode(string invoiceId,string branchCode);
    Task<ColumbusInvoiceHeader?> DownloadInvoiceByStandardInvoiceNumberAndBranchCodeAsync(string invoiceId,string branchCode);
    Task<IEnumerable<ColumbusInvoiceHeader>> SearchUnSynchronizedInvoiceDocuments();
    bool DownloadInvoiceByInvoiceIdAndBranchCode(string invoiceId,string branchCode);


}