﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IColumbusFilesService
    {
        Task UploadColumbusFileAsync(string metaDataFileName,string columbusStagingContainer);
        Task<int> UpdateDocumentMetadata(DocumentMetadataUpdate request, string? relativeContainerPath);

    }
}
