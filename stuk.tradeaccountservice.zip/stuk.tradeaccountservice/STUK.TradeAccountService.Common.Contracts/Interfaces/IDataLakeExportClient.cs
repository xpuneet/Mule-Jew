using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Writes a complete ConsXref dataset followed by its Data Lake completion token
    /// </summary>
    public interface IDataLakeExportClient
    {
        /// <summary>
        /// Writes a complete dataset and only then publishes its completion token
        /// </summary>
        /// <param name="request">The dataset, token and correlation contract</param>
        /// <param name="datasetContent">The complete readable and seekable dataset stream</param>
        /// <param name="cancellationToken">Token used to cancel the asynchronous operation</param>
        /// <returns>The completed dataset and token paths</returns>
        Task<DataLakeExportWriteResult> WriteAsync(DataLakeExportWriteRequest request, Stream datasetContent, CancellationToken cancellationToken = default);
    }
}
