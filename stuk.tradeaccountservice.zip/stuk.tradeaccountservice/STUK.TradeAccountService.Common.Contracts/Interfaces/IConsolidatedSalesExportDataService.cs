using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Provides durable extraction, snapshot and destination state for the Consolidated Sales export
    /// </summary>
    public interface IConsolidatedSalesExportDataService
    {
        /// <summary>
        /// Creates or returns an idempotent logical export run
        /// </summary>
        /// <param name="registration">The logical run registration</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The existing or newly created export run</returns>
        Task<ConsolidatedSalesExportRun> CreateRunAsync(ConsolidatedSalesExportRunRegistration registration, CancellationToken cancellationToken = default);

        /// <summary>
        /// Claims the next export run eligible for Salesforce extraction
        /// </summary>
        /// <param name="leaseOwner">The worker instance claiming the run</param>
        /// <param name="leaseDurationSeconds">The extraction lease duration in seconds</param>
        /// <param name="maximumRetryCount">The maximum permitted extraction attempts</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The claimed run, or null when no run is eligible</returns>
        Task<ConsolidatedSalesExportRun?> ClaimNextRunAsync(string leaseOwner, int leaseDurationSeconds, int maximumRetryCount, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Renews the lease held for a Salesforce extraction
        /// </summary>
        /// <param name="exportRunId">The claimed export run identifier</param>
        /// <param name="claimToken">The token proving ownership of the claim</param>
        /// <param name="leaseDurationSeconds">The renewed lease duration in seconds</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The renewed lease details</returns>
        Task<ConsolidatedSalesLeaseResult> RenewRunLeaseAsync(Guid exportRunId, Guid claimToken, int leaseDurationSeconds, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Persists one ordered Salesforce result page atomically
        /// </summary>
        /// <param name="exportRunId">The claimed export run identifier</param>
        /// <param name="claimToken">The token proving ownership of the claim</param>
        /// <param name="pageNumber">The one-based page number</param>
        /// <param name="firstRowSequence">The one-based sequence assigned to the first page row</param>
        /// <param name="pageHash">The SHA-256 page-content hash</param>
        /// <param name="hasMore">Whether Salesforce reported a following page</param>
        /// <param name="rowsJson">The canonical JSON array containing the page rows</param>
        /// <param name="now">The optional UTC persistence time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The persisted page metadata</returns>
        Task<ConsolidatedSalesExportPage> AppendPageAsync(
            Guid exportRunId,
            Guid claimToken,
            int pageNumber,
            long firstRowSequence,
            byte[] pageHash,
            bool hasMore,
            string rowsJson,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Publishes a complete Salesforce snapshot for destination processing
        /// </summary>
        /// <param name="exportRunId">The claimed export run identifier</param>
        /// <param name="claimToken">The token proving ownership of the claim</param>
        /// <param name="expectedPageCount">The expected persisted page count</param>
        /// <param name="expectedRowCount">The expected persisted row count</param>
        /// <param name="queryHash">The SHA-256 hash of the executed SOQL contract</param>
        /// <param name="now">The optional UTC completion time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        Task CompleteExtractionAsync(
            Guid exportRunId,
            Guid claimToken,
            int expectedPageCount,
            long expectedRowCount,
            byte[] queryHash,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Records an extraction failure and schedules retry or terminal failure
        /// </summary>
        /// <param name="exportRunId">The claimed export run identifier</param>
        /// <param name="claimToken">The token proving ownership of the claim</param>
        /// <param name="errorCategory">The classified failure category</param>
        /// <param name="errorMessage">The safe failure detail</param>
        /// <param name="isTransient">Whether the failure remains eligible for retry</param>
        /// <param name="nextAttemptOn">The next retry time when retry remains possible</param>
        /// <param name="maximumRetryCount">The maximum permitted extraction attempts</param>
        /// <param name="now">The optional UTC failure time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The resulting extraction state</returns>
        Task<ConsolidatedSalesExportFailureResult> FailExtractionAsync(
            Guid exportRunId,
            Guid claimToken,
            string errorCategory,
            string errorMessage,
            bool isTransient,
            DateTimeOffset? nextAttemptOn,
            int maximumRetryCount,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Claims the next eligible delivery for one destination
        /// </summary>
        /// <param name="destination">The Phocas or DataLake destination</param>
        /// <param name="leaseOwner">The worker instance claiming the delivery</param>
        /// <param name="leaseDurationSeconds">The delivery lease duration in seconds</param>
        /// <param name="maximumRetryCount">The maximum permitted delivery attempts</param>
        /// <param name="exportDestinationId">The optional destination identifier for a controlled targeted replay</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The claimed destination work, or null when no work is eligible</returns>
        Task<ConsolidatedSalesExportDestinationWork?> ClaimNextDestinationAsync(
            string destination,
            string leaseOwner,
            int leaseDurationSeconds,
            int maximumRetryCount,
            Guid? exportDestinationId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Renews the lease held for a destination delivery
        /// </summary>
        /// <param name="exportDestinationId">The claimed destination work identifier</param>
        /// <param name="claimToken">The token proving ownership of the claim</param>
        /// <param name="leaseDurationSeconds">The renewed lease duration in seconds</param>
        /// <param name="now">The optional UTC processing time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The renewed lease details</returns>
        Task<ConsolidatedSalesLeaseResult> RenewDestinationLeaseAsync(
            Guid exportDestinationId,
            Guid claimToken,
            int leaseDurationSeconds,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Records successful completion and file evidence for a destination
        /// </summary>
        /// <param name="exportDestinationId">The claimed destination work identifier</param>
        /// <param name="claimToken">The token proving ownership of the claim</param>
        /// <param name="fileName">The delivered file name</param>
        /// <param name="filePath">The destination or staging path</param>
        /// <param name="contentHash">The generated-file content hash</param>
        /// <param name="fileRowCount">The delivered data-row count</param>
        /// <param name="fileByteCount">The delivered byte count</param>
        /// <param name="externalExecutionId">The optional external platform execution identifier</param>
        /// <param name="now">The optional UTC completion time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        Task CompleteDestinationAsync(
            Guid exportDestinationId,
            Guid claimToken,
            string fileName,
            string filePath,
            string contentHash,
            long fileRowCount,
            long fileByteCount,
            string? externalExecutionId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Records a destination failure and schedules retry or terminal failure
        /// </summary>
        /// <param name="exportDestinationId">The claimed destination work identifier</param>
        /// <param name="claimToken">The token proving ownership of the claim</param>
        /// <param name="errorCategory">The classified failure category</param>
        /// <param name="errorMessage">The safe failure detail</param>
        /// <param name="nextAttemptOn">The next retry time when retry remains possible</param>
        /// <param name="maximumRetryCount">The maximum permitted delivery attempts</param>
        /// <param name="externalExecutionId">The optional external platform execution identifier</param>
        /// <param name="now">The optional UTC failure time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The resulting destination state</returns>
        Task<ConsolidatedSalesExportDestinationFailureResult> FailDestinationAsync(
            Guid exportDestinationId,
            Guid claimToken,
            string errorCategory,
            string errorMessage,
            DateTimeOffset? nextAttemptOn,
            int maximumRetryCount,
            string? externalExecutionId = null,
            DateTimeOffset? now = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Requeues a terminally failed destination following approval
        /// </summary>
        /// <param name="exportDestinationId">The destination work identifier</param>
        /// <param name="reason">The approved replay reason</param>
        /// <param name="now">The optional UTC replay time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        Task RequeueDestinationAsync(Guid exportDestinationId, string reason, DateTimeOffset? now = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets one bounded page of ordered rows from a completed immutable snapshot
        /// </summary>
        /// <param name="exportRunId">The completed export run identifier</param>
        /// <param name="afterRowSequence">The last row sequence already consumed, or zero for the first page</param>
        /// <param name="pageSize">The maximum number of rows to return</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The next completed snapshot page in stable sequence order</returns>
        Task<IReadOnlyCollection<ConsolidatedSalesExportRow>> GetRowsAsync(
            Guid exportRunId,
            long afterRowSequence,
            int pageSize,
            CancellationToken cancellationToken = default);
    }
}
