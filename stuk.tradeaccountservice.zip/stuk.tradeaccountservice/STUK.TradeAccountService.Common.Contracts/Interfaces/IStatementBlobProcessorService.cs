﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface IStatementBlobProcessorService
    {
        Task UpsertBatchAsync(
            IReadOnlyList<StatementHeaderData> documents,
            IReadOnlyList<StatementMetadataData> metadata);
    }
}
