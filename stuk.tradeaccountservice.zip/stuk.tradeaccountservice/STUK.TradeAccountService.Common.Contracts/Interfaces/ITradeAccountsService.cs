﻿using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    public interface ITradeAccountsService
    {
        Task<AccountResponse?> GetAccountByAccountCodeAsync(string accountCode, CancellationToken cancellationToken = default);
        Task<AccountSearchResponse?> SearchAccountBySessionAsync(string sessionId, int pageNumber, int pageSize, CancellationToken cancellationToken = default);
        Task LinkUnlinkAccountAsync(string accountCode, CancellationToken cancellationToken = default);
        Task<AccountValidateResponse?> ValidateAccountAsync(string accountCode, string postCode, string brand, CancellationToken cancellationToken = default);
        Task<CreditLimitResponse?> GetCreditLimitByAccountCodeAsync(string accountCode, CancellationToken cancellationToken = default);
    }
}
