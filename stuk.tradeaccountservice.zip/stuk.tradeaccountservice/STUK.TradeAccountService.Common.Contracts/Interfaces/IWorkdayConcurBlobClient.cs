using STUK.TradeAccountService.Common.Contracts.Models;

namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Reads Workday-to-Concur Blob identity and freshness evidence
    /// </summary>
    public interface IWorkdayConcurBlobClient
    {
        /// <summary>
        /// Gets and validates one non-empty Blob written no earlier than the supplied boundary
        /// </summary>
        /// <param name="serviceEndpoint">Azure Blob service endpoint</param>
        /// <param name="containerName">Blob container</param>
        /// <param name="blobName">Blob name</param>
        /// <param name="notBefore">Earliest acceptable last-modified time</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The validated Blob identity</returns>
        Task<WorkdayConcurFileIdentity> GetRequiredFreshFileAsync(Uri serviceEndpoint, string containerName, string blobName, DateTimeOffset notBefore, CancellationToken cancellationToken = default);

        /// <summary>
        /// Overwrites one Blob with the supplied content and returns its immutable identity
        /// </summary>
        /// <param name="serviceEndpoint">Azure Blob service endpoint</param>
        /// <param name="containerName">Blob container</param>
        /// <param name="blobName">Blob name including any virtual folder</param>
        /// <param name="content">Content to upload from its current position</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The uploaded Blob identity</returns>
        Task<WorkdayConcurFileIdentity> UploadAsync(Uri serviceEndpoint, string containerName, string blobName, Stream content, CancellationToken cancellationToken = default);

        /// <summary>
        /// Lists every non-directory Blob beneath a virtual folder
        /// </summary>
        /// <param name="serviceEndpoint">Azure Blob service endpoint</param>
        /// <param name="containerName">Blob container</param>
        /// <param name="folderPath">Virtual folder path</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The immutable identities of the selected Blobs</returns>
        Task<IReadOnlyCollection<WorkdayConcurFileIdentity>> ListFilesAsync(Uri serviceEndpoint, string containerName, string folderPath, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets the current identity of one Blob when it exists
        /// </summary>
        /// <param name="serviceEndpoint">Azure Blob service endpoint</param>
        /// <param name="containerName">Blob container</param>
        /// <param name="blobName">Blob name including any virtual folder</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>The current Blob identity, or <see langword="null"/> when the Blob does not exist</returns>
        Task<WorkdayConcurFileIdentity?> GetFileAsync(Uri serviceEndpoint, string containerName, string blobName, CancellationToken cancellationToken = default);

        /// <summary>
        /// Opens one Blob for streaming and requires its recorded entity tag to remain unchanged
        /// </summary>
        /// <param name="serviceEndpoint">Azure Blob service endpoint</param>
        /// <param name="containerName">Blob container</param>
        /// <param name="blobName">Blob name including any virtual folder</param>
        /// <param name="eTag">Entity tag recorded when the Blob was selected</param>
        /// <param name="cancellationToken">A token used to cancel the asynchronous operation</param>
        /// <returns>A readable stream for the selected Blob content</returns>
        Task<Stream> OpenReadAsync(Uri serviceEndpoint, string containerName, string blobName, string eTag, CancellationToken cancellationToken = default);
    }
}
