namespace STUK.TradeAccountService.Common.Contracts.Interfaces
{
    /// <summary>
    /// Creates the Workday Get_Workers SOAP requests used by the Concur integration
    /// </summary>
    public interface IWorkdaySoapRequestFactory
    {
        /// <summary>
        /// Creates a request for workers with effective changes in the supplied window
        /// </summary>
        /// <param name="from">Inclusive lower boundary of the integration window</param>
        /// <param name="through">Inclusive upper boundary of the integration window</param>
        /// <param name="page">One-based Workday page number</param>
        /// <param name="pageSize">Maximum number of workers requested on the page</param>
        /// <returns>Complete SOAP request XML</returns>
        string CreateEffectiveWorkerRequest(DateTimeOffset from, DateTimeOffset through, int page, int pageSize);

        /// <summary>
        /// Creates a request for workers updated in the supplied window
        /// </summary>
        /// <param name="from">Inclusive lower boundary of the integration window</param>
        /// <param name="through">Inclusive upper boundary of the integration window</param>
        /// <param name="page">One-based Workday page number</param>
        /// <param name="pageSize">Maximum number of workers requested on the page</param>
        /// <returns>Complete SOAP request XML</returns>
        string CreateUpdatedWorkerRequest(DateTimeOffset from, DateTimeOffset through, int page, int pageSize);

        /// <summary>
        /// Creates a request for full details for the supplied Workday employees
        /// </summary>
        /// <param name="employeeIds">Workday Employee_ID values</param>
        /// <param name="page">One-based Workday page number</param>
        /// <param name="pageSize">Maximum number of workers requested on the page</param>
        /// <returns>Complete SOAP request XML</returns>
        string CreateWorkerDetailRequest(IReadOnlyCollection<string> employeeIds, int page, int pageSize);
    }
}
