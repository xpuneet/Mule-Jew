﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Logging;
using STUK.APIs.Common.Models;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.Services;

namespace STUK.TradeAccountColumbusService.WebApi.Controllers
{
    [Route("api/v1")]
    [ApiController]
    public class ColumbusFilesController : ControllerBase
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly IColumbusFilesService _columbusFilesService;
        private readonly IBlobService _blobService;
        private readonly string _storageAccount;
        private readonly string _columbusInvoiceStagingContainerName;
        private readonly string _columbusStatementStagingContainerName;
        private readonly int _maxDegreeOfParallelism;
        private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
        private readonly IColumbusInvoiceDownloadService _columbusInvoiceDownloadService;
        private readonly IColumbusStatementDownloadService _columbusStatementDownloadService;
        private readonly int _maxPollingAttempts;


        public ColumbusFilesController(IAppInsightsLoggerHelper appInsightsLoggerHelper, IServiceScopeFactory scopeFactory, IColumbusFilesService columbusFilesService, IBlobService blobService, IConfiguration configuration, IColumbusInvoiceDownloadService columbusInvoiceDownloadService, IColumbusStatementDownloadService columbusStatementDownloadService)
        {
            _scopeFactory = scopeFactory;
            _columbusFilesService = columbusFilesService;
            _blobService = blobService;
            _maxPollingAttempts = configuration.GetValue<int>("Columbus:MaxRetryAttempts");
            _storageAccount = configuration["ColumbusFilesStorageAccount"]
          ?? throw new InvalidOperationException("ColumbusFilesStorageAccount:StorageAccount is not configured.");
            _columbusInvoiceStagingContainerName = configuration["ColumbusInvoiceStagingContainer"]
                ?? throw new InvalidOperationException("ColumbusInvoiceStagingContainer:ContainerName is not configured.");
            _columbusStatementStagingContainerName = configuration["ColumbusStatementStagingContainer"]
                ?? throw new InvalidOperationException("ColumbusStatementStagingContainer:ContainerName is not configured.");

            _maxDegreeOfParallelism = configuration.GetValue<int>("Columbus:MaxDegreeOfParallelism", 1);
            _appInsightsLoggerHelper = appInsightsLoggerHelper;
            _columbusInvoiceDownloadService = columbusInvoiceDownloadService;
            _columbusStatementDownloadService = columbusStatementDownloadService;

        }

        [HttpPost("uploadColumbusInvoiceFiles")]
        public IActionResult UploadColumbusInvoiceFiles()
        {
            Task.Run(async () =>
            {
                try
                {
                    var files = await _blobService.GetBlobFilesEndingWithAsync(
                        _storageAccount,
                        _columbusInvoiceStagingContainerName,
                        ".xml");

                    if (!files.Any())
                    {
                        _appInsightsLoggerHelper.LogInformation("No files found.");
                        return;
                    }

                    await Parallel.ForEachAsync(
                        files,
                        new ParallelOptions
                        {
                            MaxDegreeOfParallelism = _maxDegreeOfParallelism
                        },
                        async (file, cancellationToken) =>
                        {
                            try
                            {
                                // ✅ SAFE scope creation
                                using var scope = _scopeFactory.CreateScope();

                                var service = scope.ServiceProvider
                                    .GetRequiredService<IColumbusFilesService>();

                                await ProcessWithRetry(service, file,_columbusInvoiceStagingContainerName);
                            }
                            catch (Exception ex)
                            {
                                _appInsightsLoggerHelper.LogError(ex, $"Error processing {file}");
                            }
                        });

                    _appInsightsLoggerHelper.LogInformation("Finished processing files.");
                }
                catch (Exception ex)
                {
                    _appInsightsLoggerHelper.LogError(ex, "Background job failed");
                }
            });

            return Ok("Started Processing Columbus Files.");
        }

        [HttpPost("uploadColumbusStatementFiles")]
        public IActionResult UploadColumbusStatementFiles()
        {
            Task.Run(async () =>
            {
                try
                {
                    var files = await _blobService.GetBlobFilesEndingWithAsync(
                        _storageAccount,
                        _columbusStatementStagingContainerName,
                        ".xml");

                    if (!files.Any())
                    {
                        _appInsightsLoggerHelper.LogInformation("No files found.");
                        return;
                    }

                    await Parallel.ForEachAsync(
                        files,
                        new ParallelOptions
                        {
                            MaxDegreeOfParallelism = _maxDegreeOfParallelism
                        },
                        async (file, cancellationToken) =>
                        {
                            try
                            {
                                // ✅ SAFE scope creation
                                using var scope = _scopeFactory.CreateScope();

                                var service = scope.ServiceProvider
                                    .GetRequiredService<IColumbusFilesService>();

                                await ProcessWithRetry(service, file,_columbusStatementStagingContainerName);
                            }
                            catch (Exception ex)
                            {
                                _appInsightsLoggerHelper.LogError(ex, $"Error processing {file}");
                            }
                        });

                    _appInsightsLoggerHelper.LogInformation("Finished processing files.");
                }
                catch (Exception ex)
                {
                    _appInsightsLoggerHelper.LogError(ex, "Background job failed");
                }
            });

            return Ok("Started Processing Columbus Files.");
        }

        //[HttpPost("invoice/{invoiceId}")]
        //[ProducesResponseType(typeof(string), StatusCodes.Status200OK)]

        //public Task<IActionResult> DownloadInvoiceByInvoiceId(string invoiceId)
        //{

        //    Task.Run(async () =>
        //    {
        //        await _columbusInvoiceDownloadService
        //            .DownloadInvoiceByStandardInvoiceNumberAsync(invoiceId);
        //    });

        //    return Task.FromResult<IActionResult>(
        //           Ok("Initiated download process")
        //       );
        //}

        //[HttpPost("statement/{statementHeaderId}")]
        //[ProducesResponseType(typeof(string), StatusCodes.Status200OK)]

        //public Task<IActionResult> DownloadStatementByStatementHeaderId(long statementHeaderId)
        //{
        //    Task.Run(async () =>
        //    {
        //        await _columbusStatementDownloadService
        //                         .DownloadStatementByStatementHeaderIdAsync(statementHeaderId);
        //    });
        //    return Task.FromResult<IActionResult>(
        //           Ok("Initiated download process")
        //       );
        //}
        private async Task ProcessWithRetry(IColumbusFilesService service, string file,string columbusStagingContainer)
        {
            int maxRetries = _maxPollingAttempts;
            int delayMs = 2000;

            for (int attempt = 1; attempt <= maxRetries; attempt++)
            {
                try
                {
                    await service.UploadColumbusFileAsync(file, columbusStagingContainer);
                    return;
                }
                catch (Exception)
                {
                    if (attempt == maxRetries)
                    {
                        throw;
                    }

                    _appInsightsLoggerHelper.LogWarning(
                        $"Retry {attempt} failed for {file}. Retrying...");

                    await Task.Delay(delayMs);
                }
            }

        }
    }
}
