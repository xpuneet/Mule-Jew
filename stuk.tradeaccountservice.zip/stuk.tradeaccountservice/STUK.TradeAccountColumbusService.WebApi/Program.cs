
using Azure.Identity;
using STUK.APIs.Common.DependencyInjection;
using STUK.APIs.Common.Interfaces;
using STUK.APIs.Common.Logging;
using STUK.TradeAccountService.Common.Contracts.Interfaces;
using STUK.TradeAccountService.Common.Data.DependencyInjection;
using STUK.TradeAccountService.Common.Data.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var keyVaultUrl = builder.Configuration["KeyVaultUrl"]??"";

builder.Configuration.AddAzureKeyVault(
    new Uri(keyVaultUrl),
    new DefaultAzureCredential()
);


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCommonLogging();
var connectionString = builder.Configuration.GetConnectionString("OrderServiceDb");
builder.Services.AddSharedDatabase(connectionString!, "OrderDb");
builder.Services.AddSingleton<IAppInsightsLoggerHelper, AppInsightsLoggerHelper>();
builder.Services.AddHttpClient();
builder.Services.AddHttpClient<IColumbusWebService, ColumbusWebService>(); builder.Services.AddScoped<IColumbusInvoiceDownloadService, ColumbusInvoiceDownloadService>();
builder.Services.AddScoped<IColumbusStatementDownloadService, ColumbusStatementDownloadService>();
builder.Services.AddSingleton<IBlobService, BlobService>();
builder.Services.AddScoped<IColumbusFilesService, ColumbusFilesService>();
var app = builder.Build();

// Swagger middleware
app.UseSwagger();
var generateSwagger = Convert.ToBoolean(builder.Configuration["AllowSwagger"]);
if(generateSwagger)
{
  app.UseSwagger();
  app.UseSwaggerUI(c =>
  {
    c.SwaggerEndpoint("v1/swagger.json", "STUK.TradeAccountColumbusService.WebApi v1");
  });
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
