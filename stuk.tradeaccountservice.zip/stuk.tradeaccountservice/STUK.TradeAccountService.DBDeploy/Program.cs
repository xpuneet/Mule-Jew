using DbUp;
using DbUp.Helpers;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Reflection;

const string AccountDatabase = "AccountDb";
const string OrderDatabase = "OrderDb";
const string FileTransferDatabase = "FileTransferDb";

var noPrompt = args.Any(argument => argument.Equals("--noprompt", StringComparison.OrdinalIgnoreCase));

using IHost host = Host.CreateDefaultBuilder(args).Build();
IConfiguration configuration = host.Services.GetRequiredService<IConfiguration>();

var patchDatabase = bool.Parse(configuration["PatchDatabase"] ?? "false");
var validateDatabase = bool.Parse(configuration["ValidateDatabase"] ?? "false");
var accountConnectionString = configuration.GetConnectionString("TradeAccountServiceDb");
var orderConnectionString = configuration.GetConnectionString("OrderServiceDb");
var fileTransferConnectionString = configuration.GetConnectionString("FileTransferDb");
var assembly = Assembly.GetExecutingAssembly();
var hasOrderDatabaseScripts = HasScripts(assembly, OrderDatabase);
var hasFileTransferDatabaseScripts = HasScripts(assembly, FileTransferDatabase);

WriteToConsole($"Trade Account Service Database Patch Deploy. Version={assembly.GetName().Version}");

if (!patchDatabase && !validateDatabase)
{
    WriteToConsole("Database patching and validation are disabled", ConsoleColor.Yellow);
    return 0;
}

if (string.IsNullOrWhiteSpace(accountConnectionString))
{
    throw new InvalidOperationException("Connection string 'TradeAccountServiceDb' is required");
}

if (hasOrderDatabaseScripts && string.IsNullOrWhiteSpace(orderConnectionString))
{
    throw new InvalidOperationException("Connection string 'OrderServiceDb' is required because OrderDb scripts are present");
}

if (hasFileTransferDatabaseScripts && string.IsNullOrWhiteSpace(fileTransferConnectionString))
{
    throw new InvalidOperationException("Connection string 'FileTransferDb' is required because FileTransferDb scripts are present");
}

var targets = new List<SqlConnectionStringBuilder>
{
    new(accountConnectionString)
};

if (hasOrderDatabaseScripts)
{
    targets.Add(new SqlConnectionStringBuilder(orderConnectionString));
}

if (hasFileTransferDatabaseScripts)
{
    targets.Add(new SqlConnectionStringBuilder(fileTransferConnectionString));
}

if (!noPrompt)
{
    foreach (var target in targets)
    {
        WriteToConsole($"Target database '{target.InitialCatalog}' on '{target.DataSource}'", ConsoleColor.Yellow);
    }

    WriteToConsole("Enter 'Yes' to continue", ConsoleColor.Yellow);

    if (!string.Equals(Console.ReadLine(), "Yes", StringComparison.OrdinalIgnoreCase))
    {
        WriteToConsole("No database changes or validation were performed", ConsoleColor.Yellow);
        return 0;
    }
}

try
{
    if (patchDatabase)
    {
        RunDatabaseDeployment(assembly, accountConnectionString, AccountDatabase);

        if (hasOrderDatabaseScripts)
        {
            RunDatabaseDeployment(assembly, orderConnectionString!, OrderDatabase);
        }

        if (hasFileTransferDatabaseScripts)
        {
            RunDatabaseDeployment(assembly, fileTransferConnectionString!, FileTransferDatabase);
        }
    }

    if (validateDatabase)
    {
        RunScriptStep(assembly, accountConnectionString, AccountDatabase, "Validation", alwaysRun: true);

        if (hasOrderDatabaseScripts)
        {
            RunScriptStep(assembly, orderConnectionString!, OrderDatabase, "Validation", alwaysRun: true);
        }

        if (hasFileTransferDatabaseScripts)
        {
            RunScriptStep(assembly, fileTransferConnectionString!, FileTransferDatabase, "Validation", alwaysRun: true);
        }
    }

    return 0;
}
catch (Exception exception)
{
    WriteToConsole(exception.Message, ConsoleColor.Red);
    return -1;
}

static void RunDatabaseDeployment(Assembly assembly, string connectionString, string databaseName)
{
    RunScriptStep(assembly, connectionString, databaseName, "PreDeployment", alwaysRun: true);
    RunScriptStep(assembly, connectionString, databaseName, "Migrations", alwaysRun: false);
    RunScriptStep(assembly, connectionString, databaseName, "PostDeployment", alwaysRun: true);
}

static void RunScriptStep(Assembly assembly, string connectionString, string databaseName, string stepName, bool alwaysRun)
{
    var resourcePrefix = $"{assembly.GetName().Name}.{databaseName}.{stepName}";

    if (!assembly.GetManifestResourceNames().Any(name => name.StartsWith(resourcePrefix, StringComparison.OrdinalIgnoreCase)))
    {
        return;
    }

    var builder = DeployChanges.To
        .SqlDatabase(connectionString)
        .WithScriptsEmbeddedInAssembly(assembly, name => name.StartsWith(resourcePrefix, StringComparison.OrdinalIgnoreCase))
        .LogToConsole();

    if (alwaysRun)
    {
        builder.JournalTo(new NullJournal());
    }
    else
    {
        builder.JournalToSqlTable("dbo", "SchemaVersions");
    }

    var result = builder.Build().PerformUpgrade();

    if (!result.Successful)
    {
        throw result.Error;
    }
}

static bool HasScripts(Assembly assembly, string databaseName)
{
    var resourcePrefix = $"{assembly.GetName().Name}.{databaseName}.";
    return assembly.GetManifestResourceNames().Any(name => name.StartsWith(resourcePrefix, StringComparison.OrdinalIgnoreCase));
}

static void WriteToConsole(string message, ConsoleColor color = ConsoleColor.Green)
{
    Console.ForegroundColor = color;
    Console.WriteLine(message);
    Console.ResetColor();
}
