/*
Purpose:
  Creates the durable run, immutable snapshot and destination-delivery tables for the weekly
  Consolidated Sales Salesforce export.

Deployment:
  Run after 001-CreateConsolidatedSalesTables.sql and before the export stored-procedure scripts.

Rollback guidance:
  Drop the tables in reverse dependency order only when no export data must be retained:
  ConsolidatedSales_ExportDeliveryAttempts, ConsolidatedSales_ExportDestinations,
  ConsolidatedSales_ExportRows, ConsolidatedSales_ExportPages, ConsolidatedSales_ExportRuns.

Notes:
  These objects are additive and do not change the existing HX ingestion or Salesforce sync tables.
  Physical names and the owning database remain subject to DBA approval.
*/

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.ConsolidatedSales_ExportRuns', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_ExportRuns
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_ExportRuns PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_ExportRuns_Id DEFAULT NEWID(),
        logicalRunKey nvarchar(100) NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        exportYear int NOT NULL,
        extractFromDate date NOT NULL,
        scheduledFor datetimeoffset(7) NOT NULL,
        status nvarchar(30) NOT NULL,
        extractionAttemptCount int NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportRuns_ExtractionAttemptCount DEFAULT 0,
        extractedPageCount int NULL,
        extractedRowCount bigint NULL,
        queryHash binary(32) NULL,
        nextAttemptOn datetimeoffset(7) NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        createdOn datetimeoffset(7) NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportRuns_CreatedOn DEFAULT SYSUTCDATETIME(),
        extractionStartedOn datetimeoffset(7) NULL,
        extractionCompletedOn datetimeoffset(7) NULL,
        failedOn datetimeoffset(7) NULL,
        updatedOn datetimeoffset(7) NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportRuns_UpdatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_ConsolidatedSales_ExportRuns_LogicalRunKey UNIQUE (logicalRunKey),
        CONSTRAINT CK_ConsolidatedSales_ExportRuns_ExportYear CHECK (exportYear BETWEEN 2000 AND 9999),
        CONSTRAINT CK_ConsolidatedSales_ExportRuns_ExtractFromDate CHECK
            (YEAR(extractFromDate) = exportYear AND MONTH(extractFromDate) = 1 AND DAY(extractFromDate) = 1),
        CONSTRAINT CK_ConsolidatedSales_ExportRuns_Attempts CHECK (extractionAttemptCount >= 0),
        CONSTRAINT CK_ConsolidatedSales_ExportRuns_Counts CHECK
            ((extractedPageCount IS NULL OR extractedPageCount >= 0)
             AND (extractedRowCount IS NULL OR extractedRowCount >= 0)),
        CONSTRAINT CK_ConsolidatedSales_ExportRuns_Status CHECK
        (
            status IN (N'Pending', N'Extracting', N'Retry', N'Extracted', N'TerminallyFailed')
        )
    );

    CREATE INDEX IX_ConsolidatedSales_ExportRuns_Claim
        ON dbo.ConsolidatedSales_ExportRuns(status, nextAttemptOn, leaseExpiresOn, scheduledFor)
        INCLUDE (correlationId, extractionAttemptCount, exportYear);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_ExportPages', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_ExportPages
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_ExportPages PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_ExportPages_Id DEFAULT NEWID(),
        exportRunId uniqueidentifier NOT NULL,
        pageNumber int NOT NULL,
        firstRowSequence bigint NOT NULL,
        [rowCount] int NOT NULL,
        pageHash binary(32) NOT NULL,
        hasMore bit NOT NULL,
        persistedOn datetimeoffset(7) NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportPages_PersistedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_ConsolidatedSales_ExportPages_Run FOREIGN KEY (exportRunId)
            REFERENCES dbo.ConsolidatedSales_ExportRuns(id) ON DELETE CASCADE,
        CONSTRAINT UQ_ConsolidatedSales_ExportPages_Number UNIQUE (exportRunId, pageNumber),
        CONSTRAINT CK_ConsolidatedSales_ExportPages_PageNumber CHECK (pageNumber > 0),
        CONSTRAINT CK_ConsolidatedSales_ExportPages_FirstSequence CHECK (firstRowSequence > 0),
        CONSTRAINT CK_ConsolidatedSales_ExportPages_RowCount CHECK ([rowCount] >= 0)
    );
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_ExportRows', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_ExportRows
    (
        id bigint IDENTITY(1, 1) NOT NULL CONSTRAINT PK_ConsolidatedSales_ExportRows PRIMARY KEY,
        exportRunId uniqueidentifier NOT NULL,
        exportPageId uniqueidentifier NOT NULL,
        rowSequence bigint NOT NULL,
        accountNumber nvarchar(100) NULL,
        invoiceNumber nvarchar(100) NULL,
        invoiceDate date NULL,
        deliveryNoteNumber nvarchar(100) NULL,
        deliveryNoteLineNumber nvarchar(50) NULL,
        despatchDate date NULL,
        productCode nvarchar(100) NULL,
        quantity decimal(19, 6) NULL,
        totalPrice decimal(38, 18) NULL,
        createdOn datetimeoffset(7) NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportRows_CreatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_ConsolidatedSales_ExportRows_Run FOREIGN KEY (exportRunId)
            REFERENCES dbo.ConsolidatedSales_ExportRuns(id),
        CONSTRAINT FK_ConsolidatedSales_ExportRows_Page FOREIGN KEY (exportPageId)
            REFERENCES dbo.ConsolidatedSales_ExportPages(id) ON DELETE CASCADE,
        CONSTRAINT UQ_ConsolidatedSales_ExportRows_Sequence UNIQUE (exportRunId, rowSequence),
        CONSTRAINT CK_ConsolidatedSales_ExportRows_Sequence CHECK (rowSequence > 0)
    );

    CREATE INDEX IX_ConsolidatedSales_ExportRows_Page
        ON dbo.ConsolidatedSales_ExportRows(exportPageId, rowSequence);
END;

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.ConsolidatedSales_ExportRows')
      AND name = N'totalPrice'
      AND (precision <> 38 OR scale <> 18)
)
BEGIN
    ALTER TABLE dbo.ConsolidatedSales_ExportRows
        ALTER COLUMN totalPrice decimal(38, 18) NULL;
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_ExportDestinations', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_ExportDestinations
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_ExportDestinations PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_ExportDestinations_Id DEFAULT NEWID(),
        exportRunId uniqueidentifier NOT NULL,
        destination nvarchar(30) NOT NULL,
        status nvarchar(30) NOT NULL,
        attemptCount int NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportDestinations_AttemptCount DEFAULT 0,
        retryCycleAttemptCount int NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportDestinations_RetryCycleAttemptCount DEFAULT 0,
        nextAttemptOn datetimeoffset(7) NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        fileName nvarchar(510) NULL,
        filePath nvarchar(1000) NULL,
        contentHash nvarchar(128) NULL,
        fileRowCount bigint NULL,
        fileByteCount bigint NULL,
        externalExecutionId nvarchar(255) NULL,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        createdOn datetimeoffset(7) NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportDestinations_CreatedOn DEFAULT SYSUTCDATETIME(),
        updatedOn datetimeoffset(7) NOT NULL
            CONSTRAINT DF_ConsolidatedSales_ExportDestinations_UpdatedOn DEFAULT SYSUTCDATETIME(),
        completedOn datetimeoffset(7) NULL,
        CONSTRAINT FK_ConsolidatedSales_ExportDestinations_Run FOREIGN KEY (exportRunId)
            REFERENCES dbo.ConsolidatedSales_ExportRuns(id) ON DELETE CASCADE,
        CONSTRAINT UQ_ConsolidatedSales_ExportDestinations_RunDestination UNIQUE (exportRunId, destination),
        CONSTRAINT CK_ConsolidatedSales_ExportDestinations_Destination CHECK
            (destination IN (N'Phocas', N'DataLake')),
        CONSTRAINT CK_ConsolidatedSales_ExportDestinations_Status CHECK
        (
            status IN (N'Blocked', N'Pending', N'Claimed', N'Retry', N'Completed', N'TerminallyFailed')
        ),
        CONSTRAINT CK_ConsolidatedSales_ExportDestinations_Attempts CHECK (attemptCount >= 0),
        CONSTRAINT CK_ConsolidatedSales_ExportDestinations_RetryCycleAttempts CHECK (retryCycleAttemptCount >= 0),
        CONSTRAINT CK_ConsolidatedSales_ExportDestinations_FileCounts CHECK
            ((fileRowCount IS NULL OR fileRowCount >= 0) AND (fileByteCount IS NULL OR fileByteCount >= 0))
    );

    CREATE INDEX IX_ConsolidatedSales_ExportDestinations_Claim
        ON dbo.ConsolidatedSales_ExportDestinations(destination, status, nextAttemptOn, leaseExpiresOn, createdOn)
        INCLUDE (exportRunId, attemptCount);
END;

IF COL_LENGTH(N'dbo.ConsolidatedSales_ExportDestinations', N'retryCycleAttemptCount') IS NULL
BEGIN
    ALTER TABLE dbo.ConsolidatedSales_ExportDestinations
        ADD retryCycleAttemptCount int NULL;

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET retryCycleAttemptCount = attemptCount;

    ALTER TABLE dbo.ConsolidatedSales_ExportDestinations
        ALTER COLUMN retryCycleAttemptCount int NOT NULL;

    ALTER TABLE dbo.ConsolidatedSales_ExportDestinations
        ADD CONSTRAINT DF_ConsolidatedSales_ExportDestinations_RetryCycleAttemptCount
            DEFAULT 0 FOR retryCycleAttemptCount;
END;

IF OBJECT_ID(N'dbo.CK_ConsolidatedSales_ExportDestinations_RetryCycleAttempts', N'C') IS NULL
BEGIN
    ALTER TABLE dbo.ConsolidatedSales_ExportDestinations WITH CHECK
        ADD CONSTRAINT CK_ConsolidatedSales_ExportDestinations_RetryCycleAttempts
            CHECK (retryCycleAttemptCount >= 0);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_ExportDeliveryAttempts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_ExportDeliveryAttempts
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_ExportDeliveryAttempts PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_ExportDeliveryAttempts_Id DEFAULT NEWID(),
        exportDestinationId uniqueidentifier NOT NULL,
        attemptNumber int NOT NULL,
        claimToken uniqueidentifier NOT NULL,
        status nvarchar(30) NOT NULL,
        externalExecutionId nvarchar(255) NULL,
        errorCategory nvarchar(100) NULL,
        errorMessage nvarchar(2000) NULL,
        startedOn datetimeoffset(7) NOT NULL,
        completedOn datetimeoffset(7) NULL,
        CONSTRAINT FK_ConsolidatedSales_ExportDeliveryAttempts_Destination FOREIGN KEY (exportDestinationId)
            REFERENCES dbo.ConsolidatedSales_ExportDestinations(id) ON DELETE CASCADE,
        CONSTRAINT UQ_ConsolidatedSales_ExportDeliveryAttempts_Number UNIQUE
            (exportDestinationId, attemptNumber),
        CONSTRAINT CK_ConsolidatedSales_ExportDeliveryAttempts_Number CHECK (attemptNumber > 0),
        CONSTRAINT CK_ConsolidatedSales_ExportDeliveryAttempts_Status CHECK
            (status IN (N'Started', N'Completed', N'Failed'))
    );
END;

COMMIT TRANSACTION;
