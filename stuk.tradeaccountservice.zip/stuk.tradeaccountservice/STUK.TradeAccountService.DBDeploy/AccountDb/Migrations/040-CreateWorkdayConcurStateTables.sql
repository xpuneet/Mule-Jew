/*
Purpose:
  Creates the durable watermark and resumable run-state tables for the Workday-to-Concur integration.

Deployment:
  Run against the Trade Account database before the Workday-to-Concur stored-procedure scripts.

Rollback guidance:
  Drop dbo.WorkdayConcurRun before dbo.WorkdayConcurWatermark only when the integration state is no longer required.

Notes:
  No initial watermark is guessed by this script. The approved production boundary must be supplied through
  dbo.InitialiseWorkdayConcurWatermark before the feature is enabled.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.WorkdayConcurWatermark', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.WorkdayConcurWatermark
    (
        integrationName nvarchar(100) NOT NULL
            CONSTRAINT PK_WorkdayConcurWatermark PRIMARY KEY,
        committedThrough datetimeoffset(7) NOT NULL,
        completedRunId uniqueidentifier NULL,
        updatedOn datetimeoffset(7) NOT NULL
            CONSTRAINT DF_WorkdayConcurWatermark_UpdatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_WorkdayConcurWatermark_IntegrationName CHECK (integrationName = N'WorkdayConcur')
    );
END;

IF OBJECT_ID(N'dbo.WorkdayConcurRun', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.WorkdayConcurRun
    (
        runId uniqueidentifier NOT NULL CONSTRAINT PK_WorkdayConcurRun PRIMARY KEY,
        integrationName nvarchar(100) NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        extractFrom datetimeoffset(7) NOT NULL,
        extractThrough datetimeoffset(7) NOT NULL,
        status nvarchar(32) NOT NULL,
        currentStage nvarchar(32) NOT NULL,
        fileStateJson nvarchar(max) NULL,
        tm1SynapseRunId nvarchar(100) NULL,
        transformSynapseRunId nvarchar(100) NULL,
        deliverySynapseRunId nvarchar(100) NULL,
        housekeepingSynapseRunId nvarchar(100) NULL,
        retryCount int NOT NULL CONSTRAINT DF_WorkdayConcurRun_RetryCount DEFAULT 0,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        createdOn datetimeoffset(7) NOT NULL,
        updatedOn datetimeoffset(7) NOT NULL,
        closedOn datetimeoffset(7) NULL,
        CONSTRAINT UQ_WorkdayConcurRun_CorrelationId UNIQUE (correlationId),
        CONSTRAINT FK_WorkdayConcurRun_Watermark FOREIGN KEY (integrationName) REFERENCES dbo.WorkdayConcurWatermark(integrationName),
        CONSTRAINT CK_WorkdayConcurRun_IntegrationName CHECK (integrationName = N'WorkdayConcur'),
        CONSTRAINT CK_WorkdayConcurRun_Window CHECK (extractThrough > extractFrom),
        CONSTRAINT CK_WorkdayConcurRun_Status CHECK (status IN (N'Active', N'Failed', N'Completed', N'NoData')),
        CONSTRAINT CK_WorkdayConcurRun_Stage CHECK
        (
            currentStage IN
            (
                N'Pending', N'CollectingInputs', N'Transforming', N'Delivering',
                N'MovingFiles', N'NoData', N'Completed'
            )
        ),
        CONSTRAINT CK_WorkdayConcurRun_FileStateJson CHECK (fileStateJson IS NULL OR ISJSON(fileStateJson) = 1),
        CONSTRAINT CK_WorkdayConcurRun_RetryCount CHECK (retryCount >= 0),
        CONSTRAINT CK_WorkdayConcurRun_Lease CHECK
        (
            (claimToken IS NULL AND leaseOwner IS NULL AND leaseExpiresOn IS NULL)
            OR (claimToken IS NOT NULL AND leaseOwner IS NOT NULL AND leaseExpiresOn IS NOT NULL)
        ),
        CONSTRAINT CK_WorkdayConcurRun_Closure CHECK
        (
            (status IN (N'Completed', N'NoData') AND closedOn IS NOT NULL)
            OR (status IN (N'Active', N'Failed') AND closedOn IS NULL)
        )
    );

    CREATE UNIQUE INDEX UX_WorkdayConcurRun_OpenIntegration
        ON dbo.WorkdayConcurRun(integrationName)
        WHERE closedOn IS NULL;

    CREATE INDEX IX_WorkdayConcurRun_Status
        ON dbo.WorkdayConcurRun(status, leaseExpiresOn, updatedOn)
        INCLUDE (currentStage, extractFrom, extractThrough);
END;

COMMIT TRANSACTION;
