/*
Purpose:
  Adds the durable Trade Account cool-off start and configurable Salesforce eligibility
  timestamps to Salesforce work.

Deployment:
  Run immediately after 001-CreateConsolidatedSalesTables.sql and before 002 and every
  subsequent stored-procedure script that references the added columns.

Rollback guidance:
  Do not remove these columns after cutover while Salesforce work depends on the eligibility gate.
  Before a pre-cutover rollback, drop the cool-off constraints/index and then the added columns.

Notes:
  The fallback cool-off starts from the durable first successful read time of the exact Trade Account
  Blob version. If the superseded Columbus-metadata version of this script was applied, its values
  are preserved as the safest available start for existing work and its obsolete columns are removed.
  Older work with no durable start remains ineligible; the migration does not invent a timestamp.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.CK_ConsolidatedSales_SourceItems_ColumbusEvidence', N'C') IS NOT NULL
    ALTER TABLE dbo.ConsolidatedSales_SourceItems DROP CONSTRAINT CK_ConsolidatedSales_SourceItems_ColumbusEvidence;

IF OBJECT_ID(N'dbo.CK_ConsolidatedSales_SourceItems_ColumbusDeliveredOnUtc', N'C') IS NOT NULL
    ALTER TABLE dbo.ConsolidatedSales_SourceItems DROP CONSTRAINT CK_ConsolidatedSales_SourceItems_ColumbusDeliveredOnUtc;

IF COL_LENGTH(N'dbo.ConsolidatedSales_SourceItems', N'firstReadOn') IS NULL
    ALTER TABLE dbo.ConsolidatedSales_SourceItems ADD firstReadOn datetimeoffset(7) NULL;

IF COL_LENGTH(N'dbo.ConsolidatedSales_SourceItems', N'columbusDeliveredOn') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        UPDATE dbo.ConsolidatedSales_SourceItems
        SET firstReadOn = COALESCE(firstReadOn, columbusDeliveredOn)
        WHERE columbusDeliveredOn IS NOT NULL;';

    ALTER TABLE dbo.ConsolidatedSales_SourceItems DROP COLUMN columbusDeliveredOn;
END;

IF OBJECT_ID(N'dbo.CK_ConsolidatedSales_SourceItems_FirstReadOnUtc', N'C') IS NULL
    ALTER TABLE dbo.ConsolidatedSales_SourceItems WITH CHECK ADD CONSTRAINT CK_ConsolidatedSales_SourceItems_FirstReadOnUtc
        CHECK (firstReadOn IS NULL OR DATEPART(TZOFFSET, firstReadOn) = 0);

IF COL_LENGTH(N'dbo.ConsolidatedSales_SalesforceWork', N'salesforceCooloffStartedOn') IS NULL
    ALTER TABLE dbo.ConsolidatedSales_SalesforceWork ADD salesforceCooloffStartedOn datetimeoffset(7) NULL;

IF COL_LENGTH(N'dbo.ConsolidatedSales_SalesforceWork', N'salesforceCooloffHours') IS NULL
    ALTER TABLE dbo.ConsolidatedSales_SalesforceWork ADD salesforceCooloffHours int NULL;

IF COL_LENGTH(N'dbo.ConsolidatedSales_SalesforceWork', N'salesforceEligibleOn') IS NULL
    ALTER TABLE dbo.ConsolidatedSales_SalesforceWork ADD salesforceEligibleOn datetimeoffset(7) NULL;

IF OBJECT_ID(N'dbo.CK_ConsolidatedSales_SalesforceWork_Eligibility', N'C') IS NOT NULL
    ALTER TABLE dbo.ConsolidatedSales_SalesforceWork DROP CONSTRAINT CK_ConsolidatedSales_SalesforceWork_Eligibility;

IF COL_LENGTH(N'dbo.ConsolidatedSales_SalesforceWork', N'columbusDeliveredOn') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        UPDATE dbo.ConsolidatedSales_SalesforceWork
        SET salesforceCooloffStartedOn = COALESCE(salesforceCooloffStartedOn, columbusDeliveredOn)
        WHERE columbusDeliveredOn IS NOT NULL;';

    ALTER TABLE dbo.ConsolidatedSales_SalesforceWork DROP COLUMN columbusDeliveredOn;
END;

IF OBJECT_ID(N'dbo.CK_ConsolidatedSales_SalesforceWork_Cooloff', N'C') IS NULL
    ALTER TABLE dbo.ConsolidatedSales_SalesforceWork WITH CHECK ADD CONSTRAINT CK_ConsolidatedSales_SalesforceWork_Cooloff
        CHECK (salesforceCooloffHours IS NULL OR salesforceCooloffHours >= 0);

ALTER TABLE dbo.ConsolidatedSales_SalesforceWork WITH CHECK ADD CONSTRAINT CK_ConsolidatedSales_SalesforceWork_Eligibility
    CHECK
    (
        (
            salesforceCooloffStartedOn IS NULL
            AND salesforceCooloffHours IS NULL
            AND salesforceEligibleOn IS NULL
        )
        OR
        (
            salesforceCooloffStartedOn IS NOT NULL
            AND salesforceCooloffHours IS NOT NULL
            AND salesforceEligibleOn = DATEADD(HOUR, salesforceCooloffHours, salesforceCooloffStartedOn)
        )
    );

IF EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ConsolidatedSales_SalesforceWork')
      AND name = N'IX_ConsolidatedSales_SalesforceWork_Claim'
)
    DROP INDEX IX_ConsolidatedSales_SalesforceWork_Claim ON dbo.ConsolidatedSales_SalesforceWork;

CREATE INDEX IX_ConsolidatedSales_SalesforceWork_Claim
    ON dbo.ConsolidatedSales_SalesforceWork(status, salesforceEligibleOn, nextAttemptOn, leaseExpiresOn, createdOn)
    INCLUDE (attemptCount, correlationId, consolidatedInvoiceId);

COMMIT TRANSACTION;
