/*
Purpose:
  Creates the canonical and operational tables owned by the Consolidated Sales feature.

Deployment:
  Run before the Consolidated Sales stored-procedure scripts.

Notes:
  Existing invoice, Columbus and Data Lake tables are intentionally not changed.
  Physical names remain subject to DBA approval.
*/

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.ConsolidatedSales_SourceItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_SourceItems
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_SourceItems PRIMARY KEY CONSTRAINT DF_ConsolidatedSales_SourceItems_Id DEFAULT NEWID(),
        correlationId uniqueidentifier NOT NULL,
        sourceSystem nvarchar(50) NOT NULL,
        blobContainer nvarchar(255) NOT NULL,
        blobPath nvarchar(1000) NOT NULL,
        blobIdentityHash binary(32) NOT NULL,
        sourceFileName nvarchar(510) NOT NULL,
        contentLength bigint NOT NULL,
        blobLastModifiedOn datetimeoffset(7) NOT NULL,
        contentChecksum nvarchar(128) NULL,
        eTag nvarchar(255) NOT NULL,
        status nvarchar(30) NOT NULL,
        retryCount int NOT NULL CONSTRAINT DF_ConsolidatedSales_SourceItems_RetryCount DEFAULT 0,
        nextAttemptOn datetimeoffset(7) NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        sanitisationUsed bit NOT NULL CONSTRAINT DF_ConsolidatedSales_SourceItems_SanitisationUsed DEFAULT 0,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        discoveredOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_SourceItems_DiscoveredOn DEFAULT SYSUTCDATETIME(),
        firstReadOn datetimeoffset(7) NULL,
        claimedOn datetimeoffset(7) NULL,
        completedOn datetimeoffset(7) NULL,
        failedOn datetimeoffset(7) NULL,
        updatedOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_SourceItems_UpdatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_ConsolidatedSales_SourceItems_ContentLength CHECK (contentLength >= 0),
        CONSTRAINT CK_ConsolidatedSales_SourceItems_FirstReadOnUtc CHECK (firstReadOn IS NULL OR DATEPART(TZOFFSET, firstReadOn) = 0),
        CONSTRAINT CK_ConsolidatedSales_SourceItems_RetryCount CHECK (retryCount >= 0),
        CONSTRAINT CK_ConsolidatedSales_SourceItems_Status CHECK
        (
            status IN (N'Ready', N'Claimed', N'Retry', N'AwaitingCorrection', N'Completed', N'TerminallyFailed')
        )
    );

    CREATE UNIQUE INDEX UX_ConsolidatedSales_SourceItems_BlobVersion
        ON dbo.ConsolidatedSales_SourceItems(blobIdentityHash, blobLastModifiedOn);

    CREATE INDEX IX_ConsolidatedSales_SourceItems_Claim
        ON dbo.ConsolidatedSales_SourceItems(status, nextAttemptOn, leaseExpiresOn, discoveredOn)
        INCLUDE (retryCount, correlationId);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_Invoices', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_Invoices
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_Invoices PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_Invoices_Id DEFAULT NEWID(),
        sourceItemId uniqueidentifier NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        consolidatedInvoiceNumber nvarchar(100) NOT NULL,
        invoiceTypeCode nvarchar(20) NULL,
        invoiceTypeDescription nvarchar(100) NULL,
        invoiceDate date NULL,
        taxPointDate date NULL,
        buyersOrderNumber nvarchar(100) NULL,
        sourceSuppliersInvoiceNumber nvarchar(100) NULL,
        deliveryNoteNumber nvarchar(100) NULL,
        suppliersOrderReference nvarchar(100) NULL,
        customerAccountCode nvarchar(100) NULL,
        documentBrandCode nvarchar(50) NULL,
        documentBrandDescription nvarchar(200) NULL,
        supplierBranchCode nvarchar(50) NULL,
        supplierBranchDescription nvarchar(200) NULL,
        currencyCode nvarchar(20) NULL,
        currencyDescription nvarchar(100) NULL,
        creditTermsCode nvarchar(50) NULL,
        creditTermsDescription nvarchar(200) NULL,
        expectedLineCount int NOT NULL,
        numberOfTaxRates int NULL,
        lineValueTotal decimal(19, 4) NULL,
        taxableTotal decimal(19, 4) NULL,
        taxTotal decimal(19, 4) NULL,
        netPaymentTotal decimal(19, 4) NULL,
        grossPaymentTotal decimal(19, 4) NULL,
        createdOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_Invoices_CreatedOn DEFAULT SYSUTCDATETIME(),
        updatedOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_Invoices_UpdatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_ConsolidatedSales_Invoices_SourceItem FOREIGN KEY (sourceItemId)
            REFERENCES dbo.ConsolidatedSales_SourceItems(id),
        CONSTRAINT UQ_ConsolidatedSales_Invoices_InvoiceNumber UNIQUE (consolidatedInvoiceNumber),
        CONSTRAINT CK_ConsolidatedSales_Invoices_ExpectedLineCount CHECK (expectedLineCount >= 0),
        CONSTRAINT CK_ConsolidatedSales_Invoices_NumberOfTaxRates CHECK (numberOfTaxRates IS NULL OR numberOfTaxRates >= 0)
    );

    CREATE INDEX IX_ConsolidatedSales_Invoices_AccountDate
        ON dbo.ConsolidatedSales_Invoices(customerAccountCode, invoiceDate DESC, consolidatedInvoiceNumber);

    CREATE INDEX IX_ConsolidatedSales_Invoices_SourceItem
        ON dbo.ConsolidatedSales_Invoices(sourceItemId);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_InvoiceParties', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_InvoiceParties
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_InvoiceParties PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_InvoiceParties_Id DEFAULT NEWID(),
        consolidatedInvoiceId uniqueidentifier NOT NULL,
        partyRole nvarchar(20) NOT NULL,
        accountCode nvarchar(100) NULL,
        partyName nvarchar(255) NULL,
        addressLinesJson nvarchar(max) NULL,
        addressLine1 nvarchar(255) NULL,
        addressLine2 nvarchar(255) NULL,
        addressLine3 nvarchar(255) NULL,
        addressLine4 nvarchar(255) NULL,
        street nvarchar(255) NULL,
        city nvarchar(100) NULL,
        state nvarchar(100) NULL,
        postcode nvarchar(20) NULL,
        CONSTRAINT FK_ConsolidatedSales_InvoiceParties_Invoice FOREIGN KEY (consolidatedInvoiceId)
            REFERENCES dbo.ConsolidatedSales_Invoices(id) ON DELETE CASCADE,
        CONSTRAINT UQ_ConsolidatedSales_InvoiceParties_Role UNIQUE (consolidatedInvoiceId, partyRole),
        CONSTRAINT CK_ConsolidatedSales_InvoiceParties_AddressLinesJson CHECK
            (addressLinesJson IS NULL OR ISJSON(addressLinesJson) = 1),
        CONSTRAINT CK_ConsolidatedSales_InvoiceParties_Role CHECK
        (
            partyRole IN (N'Supplier', N'Buyer', N'InvoiceTo')
        )
    );
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_InvoiceComponents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_InvoiceComponents
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_InvoiceComponents PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_InvoiceComponents_Id DEFAULT NEWID(),
        consolidatedInvoiceId uniqueidentifier NOT NULL,
        componentReferenceKey nvarchar(200) NOT NULL,
        standardInvoiceNumber nvarchar(100) NULL,
        branchCode nvarchar(50) NULL,
        deliveryNoteNumber nvarchar(100) NULL,
        buyersOrderNumber nvarchar(100) NULL,
        suppliersOrderReference nvarchar(100) NULL,
        createdOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_InvoiceComponents_CreatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_ConsolidatedSales_InvoiceComponents_Invoice FOREIGN KEY (consolidatedInvoiceId)
            REFERENCES dbo.ConsolidatedSales_Invoices(id) ON DELETE CASCADE,
        CONSTRAINT UQ_ConsolidatedSales_InvoiceComponents_Key UNIQUE
            (consolidatedInvoiceId, componentReferenceKey)
    );

    CREATE INDEX IX_ConsolidatedSales_InvoiceComponents_OrdinaryInvoice
        ON dbo.ConsolidatedSales_InvoiceComponents(branchCode, standardInvoiceNumber)
        INCLUDE (consolidatedInvoiceId, componentReferenceKey);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_InvoiceLines', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_InvoiceLines
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_InvoiceLines PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_InvoiceLines_Id DEFAULT NEWID(),
        consolidatedInvoiceId uniqueidentifier NOT NULL,
        componentId uniqueidentifier NULL,
        lineIdentity nvarchar(200) NOT NULL,
        lineSequence int NOT NULL,
        sourceLineNumber nvarchar(50) NULL,
        preserveLineNumber bit NULL,
        sourceAction nvarchar(30) NULL,
        orderLineNumber nvarchar(50) NULL,
        originalOrderLineNumber nvarchar(50) NULL,
        deliveryNoteNumber nvarchar(100) NULL,
        deliveryNoteLineNumber nvarchar(50) NULL,
        buyersOrderNumber nvarchar(100) NULL,
        suppliersOrderReference nvarchar(100) NULL,
        supplierDespatchDate date NULL,
        supplierCodeForDelivery nvarchar(100) NULL,
        orderTypeCode nvarchar(50) NULL,
        orderTypeDescription nvarchar(200) NULL,
        orderCategoryCode nvarchar(50) NULL,
        orderCategoryDescription nvarchar(200) NULL,
        deliveryMethodCode nvarchar(50) NULL,
        deliveryMethodDescription nvarchar(200) NULL,
        supplierPartAnalysisCode nvarchar(100) NULL,
        isSpecialProduct bit NULL,
        isTextLine bit NOT NULL CONSTRAINT DF_ConsolidatedSales_InvoiceLines_IsTextLine DEFAULT 0,
        productCode nvarchar(100) NULL,
        productDescription nvarchar(1000) NULL,
        quantity decimal(19, 6) NULL,
        quantityUomCode nvarchar(50) NULL,
        quantityUomDescription nvarchar(200) NULL,
        unitPrice decimal(19, 6) NULL,
        priceUomCode nvarchar(50) NULL,
        priceUomDescription nvarchar(200) NULL,
        percentageDiscount decimal(9, 4) NULL,
        taxRateCode nvarchar(50) NULL,
        taxRate decimal(9, 4) NULL,
        taxValue decimal(19, 4) NULL,
        lineTotal decimal(19, 4) NULL,
        jobNumber nvarchar(100) NULL,
        contractNumber nvarchar(100) NULL,
        buyerLocation nvarchar(255) NULL,
        operative nvarchar(255) NULL,
        siteCode nvarchar(30) NULL,
        plotNumber nvarchar(30) NULL,
        vehicleRegistration nvarchar(50) NULL,
        houseType nvarchar(30) NULL,
        productGroup nvarchar(30) NULL,
        orderAuthorised nvarchar(100) NULL,
        jobAddressLinesJson nvarchar(max) NULL,
        jobAddressLine1 nvarchar(255) NULL,
        jobAddressLine2 nvarchar(255) NULL,
        jobAddressLine3 nvarchar(255) NULL,
        jobAddressLine4 nvarchar(255) NULL,
        jobStreet nvarchar(255) NULL,
        jobCity nvarchar(100) NULL,
        jobState nvarchar(100) NULL,
        jobPostcode nvarchar(20) NULL,
        createdOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_InvoiceLines_CreatedOn DEFAULT SYSUTCDATETIME(),
        updatedOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_InvoiceLines_UpdatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_ConsolidatedSales_InvoiceLines_Invoice FOREIGN KEY (consolidatedInvoiceId)
            REFERENCES dbo.ConsolidatedSales_Invoices(id) ON DELETE CASCADE,
        CONSTRAINT FK_ConsolidatedSales_InvoiceLines_Component FOREIGN KEY (componentId)
            REFERENCES dbo.ConsolidatedSales_InvoiceComponents(id),
        CONSTRAINT UQ_ConsolidatedSales_InvoiceLines_Identity UNIQUE (consolidatedInvoiceId, lineIdentity),
        CONSTRAINT UQ_ConsolidatedSales_InvoiceLines_Sequence UNIQUE (consolidatedInvoiceId, lineSequence),
        CONSTRAINT CK_ConsolidatedSales_InvoiceLines_JobAddressLinesJson CHECK
            (jobAddressLinesJson IS NULL OR ISJSON(jobAddressLinesJson) = 1),
        CONSTRAINT CK_ConsolidatedSales_InvoiceLines_Sequence CHECK (lineSequence > 0)
    );
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_TaxSubTotals', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_TaxSubTotals
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_TaxSubTotals PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_TaxSubTotals_Id DEFAULT NEWID(),
        consolidatedInvoiceId uniqueidentifier NOT NULL,
        taxRateCode nvarchar(50) NULL,
        taxRate decimal(9, 4) NULL,
        numberOfLinesAtRate int NULL,
        totalValueAtRate decimal(19, 4) NULL,
        taxableValueAtRate decimal(19, 4) NULL,
        taxAtRate decimal(19, 4) NULL,
        netPaymentAtRate decimal(19, 4) NULL,
        grossPaymentAtRate decimal(19, 4) NULL,
        CONSTRAINT FK_ConsolidatedSales_TaxSubTotals_Invoice FOREIGN KEY (consolidatedInvoiceId)
            REFERENCES dbo.ConsolidatedSales_Invoices(id) ON DELETE CASCADE,
        CONSTRAINT CK_ConsolidatedSales_TaxSubTotals_NumberOfLines CHECK
            (numberOfLinesAtRate IS NULL OR numberOfLinesAtRate >= 0)
    );

    CREATE INDEX IX_ConsolidatedSales_TaxSubTotals_Invoice
        ON dbo.ConsolidatedSales_TaxSubTotals(consolidatedInvoiceId);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_SalesforceWork', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_SalesforceWork
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_SalesforceWork PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_SalesforceWork_Id DEFAULT NEWID(),
        consolidatedInvoiceId uniqueidentifier NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        status nvarchar(30) NOT NULL,
        expectedLineCount int NOT NULL,
        attemptCount int NOT NULL CONSTRAINT DF_ConsolidatedSales_SalesforceWork_AttemptCount DEFAULT 0,
        nextAttemptOn datetimeoffset(7) NULL,
        salesforceCooloffStartedOn datetimeoffset(7) NOT NULL,
        salesforceCooloffHours int NOT NULL,
        salesforceEligibleOn datetimeoffset(7) NOT NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        salesforceOrderId nvarchar(50) NULL,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        createdOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_SalesforceWork_CreatedOn DEFAULT SYSUTCDATETIME(),
        updatedOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_SalesforceWork_UpdatedOn DEFAULT SYSUTCDATETIME(),
        completedOn datetimeoffset(7) NULL,
        CONSTRAINT FK_ConsolidatedSales_SalesforceWork_Invoice FOREIGN KEY (consolidatedInvoiceId)
            REFERENCES dbo.ConsolidatedSales_Invoices(id) ON DELETE CASCADE,
        CONSTRAINT UQ_ConsolidatedSales_SalesforceWork_Invoice UNIQUE (consolidatedInvoiceId),
        CONSTRAINT CK_ConsolidatedSales_SalesforceWork_Status CHECK
        (
            status IN (N'Pending', N'Claimed', N'Retry', N'Completed', N'TerminallyFailed')
        ),
        CONSTRAINT CK_ConsolidatedSales_SalesforceWork_Attempts CHECK (attemptCount >= 0),
        CONSTRAINT CK_ConsolidatedSales_SalesforceWork_LineCount CHECK (expectedLineCount >= 0),
        CONSTRAINT CK_ConsolidatedSales_SalesforceWork_Cooloff CHECK
        (
            salesforceCooloffHours >= 0
        ),
        CONSTRAINT CK_ConsolidatedSales_SalesforceWork_Eligibility CHECK
        (
            salesforceEligibleOn = DATEADD(HOUR, salesforceCooloffHours, salesforceCooloffStartedOn)
        )
    );

    CREATE INDEX IX_ConsolidatedSales_SalesforceWork_Claim
        ON dbo.ConsolidatedSales_SalesforceWork(status, salesforceEligibleOn, nextAttemptOn, leaseExpiresOn, createdOn)
        INCLUDE (attemptCount, correlationId, consolidatedInvoiceId);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_SalesforceLineState', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_SalesforceLineState
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_SalesforceLineState PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_SalesforceLineState_Id DEFAULT NEWID(),
        salesforceWorkId uniqueidentifier NOT NULL,
        consolidatedInvoiceLineId uniqueidentifier NOT NULL,
        externalId nvarchar(255) NOT NULL,
        salesforceProductId nvarchar(50) NULL,
        salesforcePricebookEntryId nvarchar(50) NULL,
        salesforceOrderItemId nvarchar(50) NULL,
        status nvarchar(30) NOT NULL CONSTRAINT DF_ConsolidatedSales_SalesforceLineState_Status DEFAULT N'Pending',
        lastErrorMessage nvarchar(2000) NULL,
        updatedOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_SalesforceLineState_UpdatedOn DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_ConsolidatedSales_SalesforceLineState_Work FOREIGN KEY (salesforceWorkId)
            REFERENCES dbo.ConsolidatedSales_SalesforceWork(id) ON DELETE CASCADE,
        CONSTRAINT FK_ConsolidatedSales_SalesforceLineState_Line FOREIGN KEY (consolidatedInvoiceLineId)
            REFERENCES dbo.ConsolidatedSales_InvoiceLines(id),
        CONSTRAINT UQ_ConsolidatedSales_SalesforceLineState_Line UNIQUE (consolidatedInvoiceLineId),
        CONSTRAINT UQ_ConsolidatedSales_SalesforceLineState_ExternalId UNIQUE (externalId),
        CONSTRAINT CK_ConsolidatedSales_SalesforceLineState_Status CHECK
        (
            status IN (N'Pending', N'Completed', N'Failed')
        )
    );
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_SalesforceAttempts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_SalesforceAttempts
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_SalesforceAttempts PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_SalesforceAttempts_Id DEFAULT NEWID(),
        salesforceWorkId uniqueidentifier NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        operation nvarchar(100) NOT NULL,
        entityKey nvarchar(255) NULL,
        attemptNumber int NOT NULL,
        outcome nvarchar(30) NOT NULL,
        httpStatusCode int NULL,
        requestPayload nvarchar(max) NULL,
        responsePayload nvarchar(max) NULL,
        errorCategory nvarchar(100) NULL,
        errorMessage nvarchar(2000) NULL,
        startedOn datetimeoffset(7) NOT NULL,
        completedOn datetimeoffset(7) NOT NULL,
        CONSTRAINT FK_ConsolidatedSales_SalesforceAttempts_Work FOREIGN KEY (salesforceWorkId)
            REFERENCES dbo.ConsolidatedSales_SalesforceWork(id) ON DELETE CASCADE,
        CONSTRAINT CK_ConsolidatedSales_SalesforceAttempts_Number CHECK (attemptNumber > 0),
        CONSTRAINT CK_ConsolidatedSales_SalesforceAttempts_Outcome CHECK
        (
            outcome IN (N'Succeeded', N'Failed', N'AcceptedDuplicate')
        )
    );

    CREATE INDEX IX_ConsolidatedSales_SalesforceAttempts_Work
        ON dbo.ConsolidatedSales_SalesforceAttempts(salesforceWorkId, attemptNumber, startedOn);
END;

IF OBJECT_ID(N'dbo.ConsolidatedSales_ReconciliationWork', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConsolidatedSales_ReconciliationWork
    (
        id uniqueidentifier NOT NULL CONSTRAINT PK_ConsolidatedSales_ReconciliationWork PRIMARY KEY
            CONSTRAINT DF_ConsolidatedSales_ReconciliationWork_Id DEFAULT NEWID(),
        consolidatedInvoiceId uniqueidentifier NOT NULL,
        componentId uniqueidentifier NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        branchCode nvarchar(50) NULL,
        standardInvoiceNumber nvarchar(100) NULL,
        status nvarchar(30) NOT NULL,
        attemptCount int NOT NULL CONSTRAINT DF_ConsolidatedSales_ReconciliationWork_AttemptCount DEFAULT 0,
        nextAttemptOn datetimeoffset(7) NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        matchedInvoiceHeaderId uniqueidentifier NULL,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        createdOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_ReconciliationWork_CreatedOn DEFAULT SYSUTCDATETIME(),
        updatedOn datetimeoffset(7) NOT NULL CONSTRAINT DF_ConsolidatedSales_ReconciliationWork_UpdatedOn DEFAULT SYSUTCDATETIME(),
        completedOn datetimeoffset(7) NULL,
        CONSTRAINT FK_ConsolidatedSales_ReconciliationWork_Invoice FOREIGN KEY (consolidatedInvoiceId)
            REFERENCES dbo.ConsolidatedSales_Invoices(id) ON DELETE CASCADE,
        CONSTRAINT FK_ConsolidatedSales_ReconciliationWork_Component FOREIGN KEY (componentId)
            REFERENCES dbo.ConsolidatedSales_InvoiceComponents(id),
        CONSTRAINT UQ_ConsolidatedSales_ReconciliationWork_Component UNIQUE (componentId),
        CONSTRAINT CK_ConsolidatedSales_ReconciliationWork_Status CHECK
        (
            status IN (N'Pending', N'Claimed', N'Retry', N'Completed', N'TerminallyFailed')
        ),
        CONSTRAINT CK_ConsolidatedSales_ReconciliationWork_Attempts CHECK (attemptCount >= 0)
    );

    CREATE INDEX IX_ConsolidatedSales_ReconciliationWork_Claim
        ON dbo.ConsolidatedSales_ReconciliationWork(status, nextAttemptOn, leaseExpiresOn, createdOn)
        INCLUDE (attemptCount, correlationId, consolidatedInvoiceId, componentId);

    CREATE INDEX IX_ConsolidatedSales_ReconciliationWork_Target
        ON dbo.ConsolidatedSales_ReconciliationWork(branchCode, standardInvoiceNumber, status);
END;

COMMIT TRANSACTION;
