/*
Purpose:
  Exercises representative Consolidated Sales export table and stored-procedure contracts.

Safety:
  The script runs inside a transaction and rolls back all test data.

Expected use:
  Run in a non-production database after scripts 026 through 038.

Rollback guidance:
  No manual rollback is required because this script always rolls back its transaction.
*/

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @ExpectCompletedReplayRejection bit = 0;

BEGIN TRANSACTION;

BEGIN TRY
    DECLARE @Now datetimeoffset(7) = '2026-08-13T09:00:00+00:00';
    DECLARE @LogicalRunKey nvarchar(100) = CONCAT(N'CONTRACT-EXPORT-', CONVERT(nvarchar(36), NEWID()));
    DECLARE @CorrelationId uniqueidentifier = NEWID();
    DECLARE @DuplicateCorrelationId uniqueidentifier = NEWID();
    DECLARE @RetryLogicalRunKey nvarchar(100) = CONCAT(@LogicalRunKey, N'-RETRY');
    DECLARE @RetryCorrelationId uniqueidentifier = NEWID();
    DECLARE @RetryAttemptOn datetimeoffset(7) = DATEADD(MINUTE, 1, @Now);
    DECLARE @ExpiredLogicalRunKey nvarchar(100) = CONCAT(@LogicalRunKey, N'-EXPIRED');
    DECLARE @ConcurrentLogicalRunKey nvarchar(100) = CONCAT(@LogicalRunKey, N'-CONCURRENT');
    DECLARE @ConcurrentCorrelationId uniqueidentifier = NEWID();
    DECLARE @ConcurrentScheduledFor datetimeoffset(7) = DATEADD(DAY, 7, @Now);
    DECLARE @ExpiredCorrelationId uniqueidentifier = NEWID();
    DECLARE @ExportRunId uniqueidentifier;
    DECLARE @RetryExportRunId uniqueidentifier;
    DECLARE @ExpiredExportRunId uniqueidentifier;
    DECLARE @ConcurrentExportRunId uniqueidentifier;
    DECLARE @ExportDestinationId uniqueidentifier;
    DECLARE @ClaimToken uniqueidentifier;
    DECLARE @PageHash binary(32) = HASHBYTES('SHA2_256', CONVERT(varbinary(max), N'contract-page-1'));
    DECLARE @QueryHash binary(32) = HASHBYTES('SHA2_256', CONVERT(varbinary(max), N'contract-soql'));

    DECLARE @Runs TABLE
    (
        id uniqueidentifier NOT NULL,
        logicalRunKey nvarchar(100) NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        exportYear int NOT NULL,
        extractFromDate date NOT NULL,
        scheduledFor datetimeoffset(7) NOT NULL,
        status nvarchar(30) NOT NULL,
        extractionAttemptCount int NOT NULL,
        extractedPageCount int NULL,
        extractedRowCount bigint NULL,
        nextAttemptOn datetimeoffset(7) NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        createdOn datetimeoffset(7) NOT NULL,
        extractionStartedOn datetimeoffset(7) NULL,
        extractionCompletedOn datetimeoffset(7) NULL,
        failedOn datetimeoffset(7) NULL,
        updatedOn datetimeoffset(7) NOT NULL,
        isNew bit NOT NULL
    );

    INSERT @Runs
    EXEC dbo.CreateConsolidatedSalesExportRun
        @LogicalRunKey = @LogicalRunKey,
        @CorrelationId = @CorrelationId,
        @ExportYear = 2026,
        @ExtractFromDate = '2026-01-01',
        @ScheduledFor = @Now,
        @Now = @Now;

    INSERT @Runs
    EXEC dbo.CreateConsolidatedSalesExportRun
        @LogicalRunKey = @LogicalRunKey,
        @CorrelationId = @DuplicateCorrelationId,
        @ExportYear = 2026,
        @ExtractFromDate = '2026-01-01',
        @ScheduledFor = @Now,
        @Now = @Now;

    IF (SELECT COUNT(DISTINCT id) FROM @Runs) <> 1
       OR (SELECT SUM(CONVERT(int, isNew)) FROM @Runs) <> 1
        THROW 51000, 'Export contract test failed: logical run creation was not idempotent.', 1;

    SELECT TOP (1) @ExportRunId = id FROM @Runs;

    IF (SELECT COUNT(*) FROM dbo.ConsolidatedSales_ExportDestinations WHERE exportRunId = @ExportRunId AND status = N'Blocked') <> 2
        THROW 51000, 'Export contract test failed: both destinations were not created as blocked.', 1;

    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.CreateConsolidatedSalesExportRun
        @LogicalRunKey = @RetryLogicalRunKey,
        @CorrelationId = @RetryCorrelationId,
        @ExportYear = 2026,
        @ExtractFromDate = '2026-01-01',
        @ScheduledFor = @Now,
        @Now = @Now;

    SELECT @RetryExportRunId = id FROM @Runs;
    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.ClaimNextConsolidatedSalesExportRun
        @LeaseOwner = N'contract-retry-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 3,
        @ExportRunId = @RetryExportRunId,
        @Now = @Now;

    SELECT @ClaimToken = claimToken FROM @Runs WHERE id = @RetryExportRunId;

    EXEC dbo.FailConsolidatedSalesExportExtraction
        @ExportRunId = @RetryExportRunId,
        @ClaimToken = @ClaimToken,
        @ErrorCategory = N'SalesforceUnavailable',
        @ErrorMessage = N'Contract-test transient failure',
        @IsTransient = 1,
        @NextAttemptOn = @RetryAttemptOn,
        @MaximumRetryCount = 3,
        @Now = @Now;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportRuns
        WHERE id = @RetryExportRunId
          AND status = N'Retry'
          AND extractionAttemptCount = 1
          AND nextAttemptOn = DATEADD(MINUTE, 1, @Now)
    )
        THROW 51000, 'Export contract test failed: transient extraction failure was not scheduled for retry.', 1;

    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.ClaimNextConsolidatedSalesExportRun
        @LeaseOwner = N'contract-retry-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 3,
        @ExportRunId = @RetryExportRunId,
        @Now = @RetryAttemptOn;

    SELECT @ClaimToken = claimToken FROM @Runs WHERE id = @RetryExportRunId;

    EXEC dbo.FailConsolidatedSalesExportExtraction
        @ExportRunId = @RetryExportRunId,
        @ClaimToken = @ClaimToken,
        @ErrorCategory = N'SalesforceRequestRejected',
        @ErrorMessage = N'Contract-test permanent failure',
        @IsTransient = 0,
        @NextAttemptOn = NULL,
        @MaximumRetryCount = 3,
        @Now = @RetryAttemptOn;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportRuns
        WHERE id = @RetryExportRunId
          AND status = N'TerminallyFailed'
          AND extractionAttemptCount = 2
          AND nextAttemptOn IS NULL
          AND failedOn = DATEADD(MINUTE, 1, @Now)
    )
        THROW 51000, 'Export contract test failed: permanent extraction failure was not terminal.', 1;

    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.CreateConsolidatedSalesExportRun
        @LogicalRunKey = @ExpiredLogicalRunKey,
        @CorrelationId = @ExpiredCorrelationId,
        @ExportYear = 2026,
        @ExtractFromDate = '2026-01-01',
        @ScheduledFor = @Now,
        @Now = @Now;

    SELECT @ExpiredExportRunId = id FROM @Runs;
    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.ClaimNextConsolidatedSalesExportRun
        @LeaseOwner = N'contract-expired-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @ExportRunId = @ExpiredExportRunId,
        @Now = @Now;

    UPDATE dbo.ConsolidatedSales_ExportRuns
    SET leaseExpiresOn = DATEADD(SECOND, -1, @Now)
    WHERE id = @ExpiredExportRunId;

    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.ClaimNextConsolidatedSalesExportRun
        @LeaseOwner = N'contract-expired-recovery-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @ExportRunId = @ExpiredExportRunId,
        @Now = @Now;

    IF EXISTS (SELECT 1 FROM @Runs)
       OR NOT EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_ExportRuns
           WHERE id = @ExpiredExportRunId
             AND status = N'TerminallyFailed'
             AND extractionAttemptCount = 1
             AND lastErrorCategory = N'LeaseExpired'
             AND claimToken IS NULL
             AND leaseExpiresOn IS NULL
       )
        THROW 51000, 'Export contract test failed: exhausted extraction was reclaimed after lease expiry.', 1;

    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.ClaimNextConsolidatedSalesExportRun
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 5,
        @ExportRunId = @ExportRunId,
        @Now = @Now;

    SELECT @ClaimToken = claimToken FROM @Runs WHERE id = @ExportRunId;

    IF @ClaimToken IS NULL
        THROW 51000, 'Export contract test failed: the extraction run was not claimed.', 1;

    DECLARE @RowsJson nvarchar(max) = N'[
      {
        "AccountNumber": "ACC001",
        "InvoiceNumber": "INV001",
        "InvoiceDate": "2026-08-01",
        "DeliveryNoteNumber": "DEL001",
        "DeliveryNoteLineNumber": "1",
        "DespatchDate": "2026-07-31",
        "ProductCode": "PRODUCT001",
        "Quantity": 2.000000,
        "TotalPrice": 19.123456789012345678
      },
      {
        "AccountNumber": "ACC002",
        "InvoiceNumber": "INV002",
        "InvoiceDate": "2026-08-02",
        "DeliveryNoteNumber": "DEL002",
        "DeliveryNoteLineNumber": "2",
        "DespatchDate": "2026-08-01",
        "ProductCode": "PRODUCT002",
        "Quantity": 1.000000,
        "TotalPrice": 5.5000
      }
    ]';

    DECLARE @Pages TABLE
    (
        id uniqueidentifier NOT NULL,
        exportRunId uniqueidentifier NOT NULL,
        pageNumber int NOT NULL,
        firstRowSequence bigint NOT NULL,
        [rowCount] int NOT NULL,
        pageHash binary(32) NOT NULL,
        hasMore bit NOT NULL,
        persistedOn datetimeoffset(7) NOT NULL,
        isNew bit NOT NULL
    );

    INSERT @Pages
    EXEC dbo.AppendConsolidatedSalesExportPage
        @ExportRunId = @ExportRunId,
        @ClaimToken = @ClaimToken,
        @PageNumber = 1,
        @FirstRowSequence = 1,
        @PageHash = @PageHash,
        @HasMore = 0,
        @RowsJson = @RowsJson,
        @Now = @Now;

    INSERT @Pages
    EXEC dbo.AppendConsolidatedSalesExportPage
        @ExportRunId = @ExportRunId,
        @ClaimToken = @ClaimToken,
        @PageNumber = 1,
        @FirstRowSequence = 1,
        @PageHash = @PageHash,
        @HasMore = 0,
        @RowsJson = @RowsJson,
        @Now = @Now;

    IF (SELECT COUNT(DISTINCT id) FROM @Pages) <> 1
       OR (SELECT SUM(CONVERT(int, isNew)) FROM @Pages) <> 1
       OR (SELECT COUNT(*) FROM dbo.ConsolidatedSales_ExportRows WHERE exportRunId = @ExportRunId) <> 2
        THROW 51000, 'Export contract test failed: page persistence was not idempotent.', 1;

    EXEC dbo.CompleteConsolidatedSalesExportExtraction
        @ExportRunId = @ExportRunId,
        @ClaimToken = @ClaimToken,
        @ExpectedPageCount = 1,
        @ExpectedRowCount = 2,
        @QueryHash = @QueryHash,
        @Now = @Now;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportRuns
        WHERE id = @ExportRunId AND status = N'Extracted'
          AND extractedPageCount = 1 AND extractedRowCount = 2
    )
        THROW 51000, 'Export contract test failed: the complete snapshot was not published.', 1;

    IF (SELECT COUNT(*) FROM dbo.ConsolidatedSales_ExportDestinations WHERE exportRunId = @ExportRunId AND status = N'Pending') <> 2
        THROW 51000, 'Export contract test failed: both destinations were not released independently.', 1;

    DECLARE @SnapshotRows TABLE
    (
        rowSequence bigint NOT NULL,
        accountNumber nvarchar(100) NULL,
        invoiceNumber nvarchar(100) NULL,
        invoiceDate date NULL,
        deliveryNoteNumber nvarchar(100) NULL,
        deliveryNoteLineNumber nvarchar(50) NULL,
        despatchDate date NULL,
        productCode nvarchar(100) NULL,
        quantity decimal(19, 6) NULL,
        totalPrice decimal(38, 18) NULL
    );

    INSERT @SnapshotRows
    EXEC dbo.GetConsolidatedSalesExportRows @ExportRunId = @ExportRunId;

    IF (SELECT COUNT(*) FROM @SnapshotRows) <> 2
       OR NOT EXISTS
       (
           SELECT 1
           FROM @SnapshotRows
           WHERE rowSequence = 1
             AND accountNumber = N'ACC001'
             AND totalPrice = CONVERT(decimal(38, 18), 19.123456789012345678)
       )
        THROW 51000, 'Export contract test failed: the ordered immutable snapshot was not returned.', 1;

    DELETE FROM @SnapshotRows;

    INSERT @SnapshotRows
    EXEC dbo.GetConsolidatedSalesExportRows
        @ExportRunId = @ExportRunId,
        @AfterRowSequence = 0,
        @PageSize = 1;

    IF (SELECT COUNT(*) FROM @SnapshotRows) <> 1
       OR NOT EXISTS (SELECT 1 FROM @SnapshotRows WHERE rowSequence = 1)
        THROW 51000, 'Export contract test failed: the first bounded snapshot page was not returned.', 1;

    DELETE FROM @SnapshotRows;

    INSERT @SnapshotRows
    EXEC dbo.GetConsolidatedSalesExportRows
        @ExportRunId = @ExportRunId,
        @AfterRowSequence = 1,
        @PageSize = 1;

    IF (SELECT COUNT(*) FROM @SnapshotRows) <> 1
       OR NOT EXISTS (SELECT 1 FROM @SnapshotRows WHERE rowSequence = 2)
        THROW 51000, 'Export contract test failed: the next bounded snapshot page was not returned.', 1;

    SELECT @ExportDestinationId = id
    FROM dbo.ConsolidatedSales_ExportDestinations
    WHERE exportRunId = @ExportRunId AND destination = N'Phocas';

    DECLARE @DestinationWork TABLE
    (
        id uniqueidentifier NOT NULL,
        exportRunId uniqueidentifier NOT NULL,
        logicalRunKey nvarchar(100) NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        exportYear int NOT NULL,
        extractedRowCount bigint NULL,
        destination nvarchar(30) NOT NULL,
        status nvarchar(30) NOT NULL,
        attemptCount int NOT NULL,
        retryCycleAttemptCount int NOT NULL,
        nextAttemptOn datetimeoffset(7) NULL,
        claimToken uniqueidentifier NULL,
        leaseOwner nvarchar(200) NULL,
        leaseExpiresOn datetimeoffset(7) NULL,
        fileName nvarchar(510) NULL,
        filePath nvarchar(1000) NULL,
        contentHash nvarchar(128) NULL,
        fileRowCount bigint NULL,
        fileByteCount bigint NULL,
        externalExecutionId nvarchar(255) NULL,
        lastErrorCategory nvarchar(100) NULL,
        lastErrorMessage nvarchar(2000) NULL,
        createdOn datetimeoffset(7) NOT NULL,
        updatedOn datetimeoffset(7) NOT NULL,
        completedOn datetimeoffset(7) NULL
    );

    INSERT @DestinationWork
    EXEC dbo.ClaimNextConsolidatedSalesExportDestination
        @Destination = N'Phocas',
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 3,
        @ExportDestinationId = @ExportDestinationId,
        @Now = @Now;

    SELECT @ClaimToken = claimToken FROM @DestinationWork WHERE id = @ExportDestinationId;

    DELETE FROM @Runs;

    INSERT @Runs
    EXEC dbo.CreateConsolidatedSalesExportRun
        @LogicalRunKey = @ConcurrentLogicalRunKey,
        @CorrelationId = @ConcurrentCorrelationId,
        @ExportYear = 2026,
        @ExtractFromDate = '2026-01-01',
        @ScheduledFor = @ConcurrentScheduledFor,
        @Now = @Now;

    SELECT @ConcurrentExportRunId = id FROM @Runs;

    UPDATE dbo.ConsolidatedSales_ExportRuns
    SET
        status = N'Extracted',
        extractedPageCount = 0,
        extractedRowCount = 0,
        queryHash = @QueryHash,
        extractionCompletedOn = @Now,
        updatedOn = @Now
    WHERE id = @ConcurrentExportRunId;

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET
        status = N'Pending',
        updatedOn = @Now
    WHERE exportRunId = @ConcurrentExportRunId
      AND destination = N'Phocas';

    DELETE FROM @DestinationWork;

    INSERT @DestinationWork
    EXEC dbo.ClaimNextConsolidatedSalesExportDestination
        @Destination = N'Phocas',
        @LeaseOwner = N'contract-concurrent-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 3,
        @Now = @Now;

    IF EXISTS (SELECT 1 FROM @DestinationWork)
        THROW 51000, 'Export contract test failed: a second Phocas delivery was claimed while one was active.', 1;

    EXEC dbo.FailConsolidatedSalesExportDestination
        @ExportDestinationId = @ExportDestinationId,
        @ClaimToken = @ClaimToken,
        @ErrorCategory = N'SftpUnavailable',
        @ErrorMessage = N'Contract-test transient failure',
        @NextAttemptOn = @Now,
        @MaximumRetryCount = 3,
        @Now = @Now;

    DELETE FROM @DestinationWork;

    INSERT @DestinationWork
    EXEC dbo.ClaimNextConsolidatedSalesExportDestination
        @Destination = N'Phocas',
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 3,
        @ExportDestinationId = @ExportDestinationId,
        @Now = @Now;

    SELECT @ClaimToken = claimToken FROM @DestinationWork WHERE id = @ExportDestinationId;

    EXEC dbo.CompleteConsolidatedSalesExportDestination
        @ExportDestinationId = @ExportDestinationId,
        @ClaimToken = @ClaimToken,
        @FileName = N'2026_ConsXref.txt',
        @FilePath = N'/inbound/2026_ConsXref.txt',
        @ContentHash = N'contract-hash',
        @FileRowCount = 2,
        @FileByteCount = 200,
        @ExternalExecutionId = N'contract-execution',
        @Now = @Now;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportDestinations
        WHERE id = @ExportDestinationId AND status = N'Completed' AND attemptCount = 2
    )
       OR NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportDestinations
        WHERE exportRunId = @ExportRunId AND destination = N'DataLake' AND status = N'Pending'
    )
        THROW 51000, 'Export contract test failed: destination recovery was not independent.', 1;

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET
        status = N'TerminallyFailed',
        lastErrorCategory = N'ContractTestFailure',
        lastErrorMessage = N'Failure approved for replay',
        updatedOn = @Now
    WHERE id = @ExportDestinationId;

    EXEC dbo.RequeueConsolidatedSalesExportDestination
        @ExportDestinationId = @ExportDestinationId,
        @Reason = N'Approved contract-test replay',
        @Now = @Now;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportDestinations
        WHERE id = @ExportDestinationId
          AND status = N'Pending'
          AND attemptCount = 2
          AND retryCycleAttemptCount = 0
    )
        THROW 51000, 'Export contract test failed: approved replay did not reset its retry-cycle budget.', 1;

    DELETE FROM @DestinationWork;

    INSERT @DestinationWork
    EXEC dbo.ClaimNextConsolidatedSalesExportDestination
        @Destination = N'Phocas',
        @LeaseOwner = N'contract-replay-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @ExportDestinationId = @ExportDestinationId,
        @Now = @Now;

    SELECT @ClaimToken = claimToken FROM @DestinationWork WHERE id = @ExportDestinationId;

    IF @ClaimToken IS NULL
       OR NOT EXISTS
       (
           SELECT 1
           FROM @DestinationWork
           WHERE id = @ExportDestinationId
             AND attemptCount = 3
             AND retryCycleAttemptCount = 1
       )
        THROW 51000, 'Export contract test failed: approved replay was not claimable with a fresh retry-cycle budget.', 1;

    EXEC dbo.CompleteConsolidatedSalesExportDestination
        @ExportDestinationId = @ExportDestinationId,
        @ClaimToken = @ClaimToken,
        @FileName = N'2026_ConsXref.txt',
        @FilePath = N'/inbound/2026_ConsXref.txt',
        @ContentHash = N'contract-hash',
        @FileRowCount = 2,
        @FileByteCount = 200,
        @ExternalExecutionId = N'contract-replay-execution',
        @Now = @Now;

    SELECT @ExportDestinationId = id
    FROM dbo.ConsolidatedSales_ExportDestinations
    WHERE exportRunId = @ExportRunId
      AND destination = N'DataLake';

    DELETE FROM @DestinationWork;

    INSERT @DestinationWork
    EXEC dbo.ClaimNextConsolidatedSalesExportDestination
        @Destination = N'DataLake',
        @LeaseOwner = N'contract-expired-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @ExportDestinationId = @ExportDestinationId,
        @Now = @Now;

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET leaseExpiresOn = DATEADD(SECOND, -1, @Now)
    WHERE id = @ExportDestinationId;

    DELETE FROM @DestinationWork;

    INSERT @DestinationWork
    EXEC dbo.ClaimNextConsolidatedSalesExportDestination
        @Destination = N'DataLake',
        @LeaseOwner = N'contract-expired-recovery-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @ExportDestinationId = @ExportDestinationId,
        @Now = @Now;

    IF EXISTS (SELECT 1 FROM @DestinationWork)
       OR NOT EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_ExportDestinations
           WHERE id = @ExportDestinationId
             AND status = N'TerminallyFailed'
             AND attemptCount = 1
             AND lastErrorCategory = N'LeaseExpired'
             AND claimToken IS NULL
             AND leaseExpiresOn IS NULL
       )
       OR NOT EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_ExportDeliveryAttempts
           WHERE exportDestinationId = @ExportDestinationId
             AND attemptNumber = 1
             AND status = N'Failed'
             AND errorCategory = N'LeaseExpired'
    )
        THROW 51000, 'Export contract test failed: exhausted destination was reclaimed after lease expiry.', 1;

    SELECT @ExportDestinationId = id
    FROM dbo.ConsolidatedSales_ExportDestinations
    WHERE exportRunId = @ExportRunId
      AND destination = N'Phocas';

    SET @ExpectCompletedReplayRejection = 1;

    EXEC dbo.RequeueConsolidatedSalesExportDestination
        @ExportDestinationId = @ExportDestinationId,
        @Reason = N'Completed work must not claim force-redelivery',
        @Now = @Now;

    THROW 51000, 'Export contract test failed: completed destination was accepted for an unguaranteed redelivery.', 1;
END TRY
BEGIN CATCH
    IF @ExpectCompletedReplayRejection = 1
       AND ERROR_MESSAGE() = N'The destination is not terminally failed.'
    BEGIN
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        PRINT 'Consolidated Sales export contract tests passed.';
        RETURN;
    END;

    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;
