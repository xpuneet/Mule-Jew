/*
Purpose:
  Exercises representative Consolidated Sales table and stored-procedure contracts.

Safety:
  The script runs inside a transaction and rolls back its test data.

Expected use:
  Run in a non-production database after the table and stored-procedure scripts.
*/

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
-- Expected stored-procedure exceptions are asserted below, so the outer rollback transaction must remain committable.
SET XACT_ABORT OFF;

BEGIN TRANSACTION;

BEGIN TRY
    IF COL_LENGTH(N'dbo.ConsolidatedSales_SourceItems', N'firstReadOn') IS NULL
        THROW 51000, 'Contract test failed: source first-read persistence is not deployed.', 1;

    IF COL_LENGTH(N'dbo.ConsolidatedSales_SalesforceWork', N'salesforceCooloffStartedOn') IS NULL
        THROW 51000, 'Contract test failed: Salesforce cool-off start persistence is not deployed.', 1;

    IF COL_LENGTH(N'dbo.ConsolidatedSales_SourceItems', N'columbusDeliveredOn') IS NOT NULL
        OR COL_LENGTH(N'dbo.ConsolidatedSales_SalesforceWork', N'columbusDeliveredOn') IS NOT NULL
        THROW 51000, 'Contract test failed: superseded Columbus delivery timestamp columns remain deployed.', 1;

    DECLARE @SourceItemId uniqueidentifier = NEWID();
    DECLARE @CorrectionSourceItemId uniqueidentifier = NEWID();
    DECLARE @ReplacementSourceItemId uniqueidentifier = NEWID();
    DECLARE @ExpiredSourceItemId uniqueidentifier = NEWID();
    DECLARE @CorrelationId uniqueidentifier = NEWID();
    DECLARE @ReplacementCorrelationId uniqueidentifier = NEWID();
    DECLARE @ClaimToken uniqueidentifier = NEWID();
    DECLARE @CorrectionClaimToken uniqueidentifier = NEWID();
    DECLARE @ReplacementClaimToken uniqueidentifier = NEWID();
    DECLARE @ReconciliationWorkId uniqueidentifier;
    DECLARE @ReconciliationClaimToken uniqueidentifier;
    DECLARE @ReconciliationNow datetimeoffset(7);
    DECLARE @InvoiceNumber nvarchar(100) = CONCAT(N'CONTRACT-TEST-', CONVERT(nvarchar(36), NEWID()));
    DECLARE @ExternalId nvarchar(255) = CONCAT(@InvoiceNumber, N'-1');
    DECLARE @RegisteredBlobPath nvarchar(1000) = CONCAT(N'contract-tests/registered-', @InvoiceNumber, N'.con.xml');
    DECLARE @RegisteredLastModifiedOn datetimeoffset(7) = '2026-08-07T09:00:00+00:00';
    DECLARE @EditedRegisteredLastModifiedOn datetimeoffset(7) = DATEADD(SECOND, 1, @RegisteredLastModifiedOn);
    DECLARE @SalesforceCooloffStartedOn datetimeoffset(7) = '2026-08-07T09:31:00+00:00';
    DECLARE @SalesforceCooloffHours int = 48;
    DECLARE @SalesforceEligibleOn datetimeoffset(7) = DATEADD(HOUR, @SalesforceCooloffHours, @SalesforceCooloffStartedOn);
    DECLARE @ReplacementSalesforceCooloffStartedOn datetimeoffset(7) = '2026-08-10T09:31:00+00:00';
    DECLARE @ReplacementSalesforceEligibleOn datetimeoffset(7) = DATEADD(HOUR, @SalesforceCooloffHours, @ReplacementSalesforceCooloffStartedOn);
    DECLARE @RepeatedFirstReadOn datetimeoffset(7) = DATEADD(HOUR, 1, @SalesforceCooloffStartedOn);
    DECLARE @MismatchedCooloffStartedOn datetimeoffset(7) = DATEADD(HOUR, 1, @SalesforceCooloffStartedOn);
    DECLARE @MismatchedSalesforceEligibleOn datetimeoffset(7) = DATEADD(HOUR, 49, @SalesforceCooloffStartedOn);
    DECLARE @ImmediatelyBeforeSalesforceEligibleOn datetimeoffset(7) = DATEADD(NANOSECOND, -100, @SalesforceEligibleOn);
    DECLARE @ImmediatelyAfterSalesforceEligibleOn datetimeoffset(7) = DATEADD(NANOSECOND, 100, @SalesforceEligibleOn);

    DECLARE @RegistrationResults TABLE
    (
        id uniqueidentifier NOT NULL,
        correlationId uniqueidentifier NOT NULL,
        sourceSystem nvarchar(50) NOT NULL,
        blobContainer nvarchar(255) NOT NULL,
        blobPath nvarchar(1000) NOT NULL,
        sourceFileName nvarchar(510) NOT NULL,
        contentLength bigint NOT NULL,
        blobLastModifiedOn datetimeoffset(7) NOT NULL,
        contentChecksum nvarchar(128) NULL,
        eTag nvarchar(255) NULL,
        status nvarchar(30) NOT NULL,
        retryCount int NOT NULL,
        sanitisationUsed bit NOT NULL,
        discoveredOn datetimeoffset(7) NOT NULL,
        completedOn datetimeoffset(7) NULL,
        isNew bit NOT NULL
    );

    INSERT @RegistrationResults
    EXEC [dbo].[RegisterConsolidatedSalesSourceItem]
        @CorrelationId = @CorrelationId,
        @SourceSystem = N'HX',
        @BlobContainer = N'contract-tests',
        @BlobPath = @RegisteredBlobPath,
        @SourceFileName = N'registered.con.xml',
        @ContentLength = 100,
        @BlobLastModifiedOn = @RegisteredLastModifiedOn,
        @ETag = N'"contract-etag-1"',
        @ContentChecksum = N'contract-test-checksum';

    INSERT @RegistrationResults
    EXEC [dbo].[RegisterConsolidatedSalesSourceItem]
        @CorrelationId = @CorrelationId,
        @SourceSystem = N'HX',
        @BlobContainer = N'contract-tests',
        @BlobPath = @RegisteredBlobPath,
        @SourceFileName = N'registered.con.xml',
        @ContentLength = 100,
        @BlobLastModifiedOn = @RegisteredLastModifiedOn,
        @ETag = N'"contract-etag-1"',
        @ContentChecksum = N'contract-test-checksum';

    INSERT @RegistrationResults
    EXEC [dbo].[RegisterConsolidatedSalesSourceItem]
        @CorrelationId = @CorrelationId,
        @SourceSystem = N'HX',
        @BlobContainer = N'contract-tests',
        @BlobPath = @RegisteredBlobPath,
        @SourceFileName = N'registered.con.xml',
        @ContentLength = 101,
        @BlobLastModifiedOn = @EditedRegisteredLastModifiedOn,
        @ETag = N'"contract-etag-2"',
        @ContentChecksum = N'contract-test-edited-checksum';

    IF
    (
        SELECT COUNT(*)
        FROM @RegistrationResults
    ) <> 3
        OR
    (
        SELECT COUNT(DISTINCT id)
        FROM @RegistrationResults
    ) <> 2
        OR
    (
        SELECT SUM(CONVERT(int, isNew))
        FROM @RegistrationResults
    ) <> 2
        THROW 51000, 'Contract test failed: source registration did not distinguish Blob versions by last-modified time.', 1;

    INSERT dbo.ConsolidatedSales_SourceItems
    (
        id,
        correlationId,
        sourceSystem,
        blobContainer,
        blobPath,
        blobIdentityHash,
        sourceFileName,
        contentLength,
        blobLastModifiedOn,
        contentChecksum,
        eTag,
        status,
        claimToken,
        leaseOwner,
        leaseExpiresOn,
        claimedOn,
        discoveredOn
    )
    VALUES
    (
        @CorrectionSourceItemId,
        @CorrelationId,
        N'HX',
        N'contract-tests',
        CONCAT(N'contract-tests/correction-', @InvoiceNumber, N'.con.xml'),
        HASHBYTES
        (
            'SHA2_256',
            CONVERT
            (
                varbinary(max),
                CONCAT(N'HX|contract-tests|contract-tests/correction-', @InvoiceNumber, N'.con.xml')
            )
        ),
        CONCAT(N'correction-', @InvoiceNumber, N'.con.xml'),
        100,
        '2026-08-07T09:15:00+00:00',
        CONVERT(nvarchar(36), NEWID()),
        N'"contract-correction-etag"',
        N'Claimed',
        @CorrectionClaimToken,
        N'contract-test',
        DATEADD(MINUTE, 5, SYSUTCDATETIME()),
        SYSUTCDATETIME(),
        @SalesforceCooloffStartedOn
    );

    EXEC [dbo].[AwaitConsolidatedSalesSourceCorrection]
        @SourceItemId = @CorrectionSourceItemId,
        @ClaimToken = @CorrectionClaimToken,
        @ErrorCategory = N'MalformedXml',
        @ErrorMessage = N'Contract-test parsing failure';

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SourceItems
        WHERE id = @CorrectionSourceItemId
          AND status = N'AwaitingCorrection'
          AND nextAttemptOn IS NULL
          AND claimToken IS NULL
          AND leaseExpiresOn IS NULL
          AND retryCount = 1
    )
        THROW 51000, 'Contract test failed: unparseable source version remained automatically retryable.', 1;

    INSERT dbo.ConsolidatedSales_SourceItems
    (
        id,
        correlationId,
        sourceSystem,
        blobContainer,
        blobPath,
        blobIdentityHash,
        sourceFileName,
        contentLength,
        blobLastModifiedOn,
        contentChecksum,
        eTag,
        status,
        claimToken,
        leaseOwner,
        leaseExpiresOn,
        claimedOn,
        discoveredOn
    )
    VALUES
    (
        @SourceItemId,
        @CorrelationId,
        N'HX',
        N'contract-tests',
        CONCAT(N'contract-tests/', @InvoiceNumber, N'.con.xml'),
        HASHBYTES
        (
            'SHA2_256',
            CONVERT
            (
                varbinary(max),
                CONCAT(N'HX|contract-tests|contract-tests/', @InvoiceNumber, N'.con.xml')
            )
        ),
        CONCAT(@InvoiceNumber, N'.con.xml'),
        100,
        '2026-08-07T09:30:00+00:00',
        CONVERT(nvarchar(36), NEWID()),
        N'"contract-source-etag"',
        N'Claimed',
        @ClaimToken,
        N'contract-test',
        DATEADD(MINUTE, 5, SYSUTCDATETIME()),
        SYSUTCDATETIME(),
        @SalesforceCooloffStartedOn
    );

    DECLARE @FirstReadResults TABLE (firstReadOn datetimeoffset(7) NOT NULL);

    INSERT @FirstReadResults
    EXEC [dbo].[RecordConsolidatedSalesSourceFirstRead]
        @SourceItemId = @SourceItemId,
        @ClaimToken = @ClaimToken,
        @Now = @SalesforceCooloffStartedOn;

    INSERT @FirstReadResults
    EXEC [dbo].[RecordConsolidatedSalesSourceFirstRead]
        @SourceItemId = @SourceItemId,
        @ClaimToken = @ClaimToken,
        @Now = @RepeatedFirstReadOn;

    IF (SELECT COUNT(*) FROM @FirstReadResults WHERE firstReadOn = @SalesforceCooloffStartedOn) <> 2
        THROW 51000, 'Contract test failed: repeated source reads changed the durable first-read timestamp.', 1;

    DECLARE @InvoiceJson nvarchar(max) = N'
    {
      "ConsolidatedInvoiceNumber": "' + STRING_ESCAPE(@InvoiceNumber, 'json') + N'",
      "InvoiceDate": "2026-07-12",
      "CustomerAccountCode": "ACC001",
      "ExpectedLineCount": 1,
      "NumberOfTaxRates": 1,
      "LineValueTotal": 19.98,
      "TaxableTotal": 19.98,
      "TaxTotal": 4.00,
      "NetPaymentTotal": 19.98,
      "GrossPaymentTotal": 23.98,
      "Parties": [
        { "PartyRole": "Buyer", "AccountCode": "ACC001", "PartyName": "Contract Test" }
      ],
      "Components": [
        { "ComponentReferenceKey": "0580-DEL-100", "StandardInvoiceNumber": "DEL-100", "BranchCode": "0580" }
      ],
      "Lines": [
        {
          "ComponentReferenceKey": "0580-DEL-100",
          "LineIdentity": "LINE-1",
          "SalesforceExternalId": "' + STRING_ESCAPE(@ExternalId, 'json') + N'",
          "LineSequence": 1,
          "SourceLineNumber": "1",
          "ProductCode": "PRODUCT-1",
          "Quantity": 2,
          "UnitPrice": 9.99,
          "LineTotal": 19.98,
          "SiteCode": "SITE-CODE-1",
          "PlotNumber": "PLOT-1",
          "HouseType": "HOUSE-TYPE-1",
          "ProductGroup": "PRODUCT-GROUP-1"
        }
      ],
      "TaxSubTotals": [
        { "TaxRateCode": "S", "TaxRate": 20, "NumberOfLinesAtRate": 1, "TaxAtRate": 4.00 }
      ]
    }';

    DECLARE @RequiredCommitValueRejected bit = 0;

    BEGIN TRY
        EXEC [dbo].[CommitConsolidatedSalesInvoice]
            @SourceItemId = @SourceItemId,
            @ClaimToken = @ClaimToken,
            @InvoiceJson = @InvoiceJson,
            @SalesforceCooloffStartedOn = NULL,
            @SalesforceCooloffHours = @SalesforceCooloffHours,
            @SalesforceEligibleOn = @SalesforceEligibleOn;
    END TRY
    BEGIN CATCH
        SET @RequiredCommitValueRejected = 1;
    END CATCH;

    IF @RequiredCommitValueRejected = 0
        THROW 51000, 'Contract test failed: a canonical invoice was committed without a Salesforce cool-off start time.', 1;

    SET @RequiredCommitValueRejected = 0;

    BEGIN TRY
        EXEC [dbo].[CommitConsolidatedSalesInvoice]
            @SourceItemId = @SourceItemId,
            @ClaimToken = @ClaimToken,
            @InvoiceJson = @InvoiceJson,
            @SalesforceCooloffStartedOn = @SalesforceCooloffStartedOn,
            @SalesforceCooloffHours = NULL,
            @SalesforceEligibleOn = @SalesforceEligibleOn;
    END TRY
    BEGIN CATCH
        SET @RequiredCommitValueRejected = 1;
    END CATCH;

    IF @RequiredCommitValueRejected = 0
        THROW 51000, 'Contract test failed: a canonical invoice was committed without a Salesforce cool-off duration.', 1;

    SET @RequiredCommitValueRejected = 0;

    BEGIN TRY
        EXEC [dbo].[CommitConsolidatedSalesInvoice]
            @SourceItemId = @SourceItemId,
            @ClaimToken = @ClaimToken,
            @InvoiceJson = @InvoiceJson,
            @SalesforceCooloffStartedOn = @SalesforceCooloffStartedOn,
            @SalesforceCooloffHours = @SalesforceCooloffHours,
            @SalesforceEligibleOn = NULL;
    END TRY
    BEGIN CATCH
        SET @RequiredCommitValueRejected = 1;
    END CATCH;

    IF @RequiredCommitValueRejected = 0
        THROW 51000, 'Contract test failed: a canonical invoice was committed without a Salesforce eligibility time.', 1;

    EXEC [dbo].[CommitConsolidatedSalesInvoice]
        @SourceItemId = @SourceItemId,
        @ClaimToken = @ClaimToken,
        @InvoiceJson = @InvoiceJson,
        @SalesforceCooloffStartedOn = @SalesforceCooloffStartedOn,
        @SalesforceCooloffHours = @SalesforceCooloffHours,
        @SalesforceEligibleOn = @SalesforceEligibleOn;

    IF (SELECT COUNT(*) FROM dbo.ConsolidatedSales_Invoices WHERE sourceItemId = @SourceItemId) <> 1
        THROW 51000, 'Contract test failed: canonical invoice was not committed.', 1;

    IF
    (
        SELECT COUNT(*)
        FROM dbo.ConsolidatedSales_InvoiceLines line
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = line.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
    ) <> 1
        THROW 51000, 'Contract test failed: canonical line was not committed.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_InvoiceLines line
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = line.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND line.siteCode = N'SITE-CODE-1'
          AND line.plotNumber = N'PLOT-1'
          AND line.houseType = N'HOUSE-TYPE-1'
          AND line.productGroup = N'PRODUCT-GROUP-1'
    )
        THROW 51000, 'Contract test failed: HX customer-information fields were not committed.', 1;

    IF
    (
        SELECT COUNT(*)
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId AND work.status = N'Pending'
    ) <> 1
        THROW 51000, 'Contract test failed: Salesforce work was not created.', 1;

    DECLARE @MismatchedCooloffStartRejected bit = 0;

    BEGIN TRY
        EXEC [dbo].[CommitConsolidatedSalesInvoice]
            @SourceItemId = @SourceItemId,
            @ClaimToken = @ClaimToken,
            @InvoiceJson = @InvoiceJson,
            @SalesforceCooloffStartedOn = @MismatchedCooloffStartedOn,
            @SalesforceCooloffHours = @SalesforceCooloffHours,
            @SalesforceEligibleOn = @MismatchedSalesforceEligibleOn;
    END TRY
    BEGIN CATCH
        SET @MismatchedCooloffStartRejected = 1;
    END CATCH;

    IF @MismatchedCooloffStartRejected = 0
        THROW 51000, 'Contract test failed: a retry was able to replace the durable Salesforce cool-off start time.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND work.salesforceCooloffStartedOn = @SalesforceCooloffStartedOn
          AND work.salesforceCooloffHours = @SalesforceCooloffHours
          AND work.salesforceEligibleOn = @SalesforceEligibleOn
    )
        THROW 51000, 'Contract test failed: persisted Salesforce eligibility changed after a rejected cool-off start mismatch.', 1;

    IF
    (
        SELECT COUNT(*)
        FROM dbo.ConsolidatedSales_ReconciliationWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId AND work.status = N'Pending'
    ) <> 1
        THROW 51000, 'Contract test failed: reconciliation work was not created.', 1;

    EXEC [dbo].[CommitConsolidatedSalesInvoice]
        @SourceItemId = @SourceItemId,
        @ClaimToken = @ClaimToken,
        @InvoiceJson = @InvoiceJson,
        @SalesforceCooloffStartedOn = @SalesforceCooloffStartedOn,
        @SalesforceCooloffHours = @SalesforceCooloffHours,
        @SalesforceEligibleOn = @SalesforceEligibleOn;

    IF (SELECT COUNT(*) FROM dbo.ConsolidatedSales_Invoices WHERE sourceItemId = @SourceItemId) <> 1
        THROW 51000, 'Contract test failed: idempotent replay created a duplicate invoice.', 1;

    UPDATE work
    SET createdOn = '1900-01-01T00:00:00+00:00'
    FROM dbo.ConsolidatedSales_SalesforceWork work
    INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
    WHERE invoice.sourceItemId = @SourceItemId;

    UPDATE work
    SET createdOn = '1900-01-01T00:00:00+00:00'
    FROM dbo.ConsolidatedSales_ReconciliationWork work
    INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
    WHERE invoice.sourceItemId = @SourceItemId;

    EXEC [dbo].[ClaimNextConsolidatedSalesforceWork]
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @Now = @ImmediatelyBeforeSalesforceEligibleOn;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND work.status = N'Claimed'
    )
        THROW 51000, 'Contract test failed: Salesforce work was claimable immediately before its eligibility timestamp.', 1;

    EXEC [dbo].[ClaimNextConsolidatedSalesforceWork]
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @Now = @SalesforceEligibleOn;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND work.status = N'Claimed'
    )
        THROW 51000, 'Contract test failed: Salesforce work was claimable before source-file completion.', 1;

    EXEC [dbo].[ClaimNextConsolidatedSalesReconciliationWork]
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ReconciliationWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND work.status = N'Claimed'
    )
        THROW 51000, 'Contract test failed: reconciliation work was claimable before source-file completion.', 1;

    EXEC [dbo].[CompleteConsolidatedSalesSourceItem]
        @SourceItemId = @SourceItemId,
        @ClaimToken = @ClaimToken,
        @SanitisationUsed = 0;

    EXEC [dbo].[ClaimNextConsolidatedSalesforceWork]
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @Now = @SalesforceEligibleOn;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND work.status = N'Claimed'
    )
        THROW 51000, 'Contract test failed: Salesforce work was not claimable exactly at its eligibility timestamp.', 1;

    UPDATE work
    SET
        status = N'Pending',
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL
    FROM dbo.ConsolidatedSales_SalesforceWork work
    INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
    WHERE invoice.sourceItemId = @SourceItemId;

    EXEC [dbo].[ClaimNextConsolidatedSalesforceWork]
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 3,
        @Now = @ImmediatelyAfterSalesforceEligibleOn;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND work.status = N'Claimed'
    )
        THROW 51000, 'Contract test failed: Salesforce work was not claimable after its eligibility timestamp.', 1;

    EXEC [dbo].[ClaimNextConsolidatedSalesReconciliationWork]
        @LeaseOwner = N'contract-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ReconciliationWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND work.status = N'Claimed'
    )
        THROW 51000, 'Contract test failed: reconciliation work was not claimable after source-file completion.', 1;

    SELECT
        @ReconciliationWorkId = work.id,
        @ReconciliationClaimToken = work.claimToken
    FROM dbo.ConsolidatedSales_ReconciliationWork work
    INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
    WHERE invoice.sourceItemId = @SourceItemId;

    SET @ReconciliationNow = SYSUTCDATETIME();
    DECLARE @ReconciliationRetryOn datetimeoffset(7) = DATEADD(MINUTE, 1, @ReconciliationNow);

    EXEC [dbo].[DeferConsolidatedSalesReconciliationWork]
        @ReconciliationWorkId = @ReconciliationWorkId,
        @ClaimToken = @ReconciliationClaimToken,
        @NextAttemptOn = @ReconciliationRetryOn,
        @Reason = N'Contract-test ordinary invoice is not available yet.',
        @Now = @ReconciliationNow;

    EXEC [dbo].[ClaimNextConsolidatedSalesReconciliationWork]
        @LeaseOwner = N'contract-delayed-match-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1,
        @Now = @ReconciliationRetryOn;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ReconciliationWork
        WHERE id = @ReconciliationWorkId
          AND status = N'Claimed'
          AND attemptCount = 2
          AND lastErrorCategory IS NULL
    )
        THROW 51000, 'Contract test failed: an expected delayed match consumed the failure retry ceiling.', 1;

    UPDATE dbo.ConsolidatedSales_SalesforceWork
    SET leaseExpiresOn = DATEADD(SECOND, -1, SYSUTCDATETIME())
    WHERE consolidatedInvoiceId = (SELECT id FROM dbo.ConsolidatedSales_Invoices WHERE sourceItemId = @SourceItemId);

    UPDATE dbo.ConsolidatedSales_ReconciliationWork
    SET leaseExpiresOn = DATEADD(SECOND, -1, SYSUTCDATETIME())
    WHERE consolidatedInvoiceId = (SELECT id FROM dbo.ConsolidatedSales_Invoices WHERE sourceItemId = @SourceItemId);

    EXEC [dbo].[ClaimNextConsolidatedSalesforceWork]
        @LeaseOwner = N'contract-recovery-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1;

    EXEC [dbo].[ClaimNextConsolidatedSalesReconciliationWork]
        @LeaseOwner = N'contract-recovery-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND (work.status <> N'TerminallyFailed' OR work.lastErrorCategory <> N'LeaseExpired')
    )
        THROW 51000, 'Contract test failed: exhausted Salesforce work was reclaimed after lease expiry.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ReconciliationWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE invoice.sourceItemId = @SourceItemId
          AND (work.status <> N'TerminallyFailed' OR work.lastErrorCategory <> N'LeaseExpired')
    )
        THROW 51000, 'Contract test failed: exhausted reconciliation work was reclaimed after lease expiry.', 1;

    DECLARE @OriginalInvoiceId uniqueidentifier;
    DECLARE @OriginalSalesforceWorkId uniqueidentifier;

    SELECT
        @OriginalInvoiceId = invoice.id,
        @OriginalSalesforceWorkId = work.id
    FROM dbo.ConsolidatedSales_Invoices invoice
    INNER JOIN dbo.ConsolidatedSales_SalesforceWork work
        ON work.consolidatedInvoiceId = invoice.id
    WHERE invoice.consolidatedInvoiceNumber = @InvoiceNumber;

    INSERT dbo.ConsolidatedSales_SalesforceAttempts
    (
        id,
        salesforceWorkId,
        correlationId,
        operation,
        entityKey,
        attemptNumber,
        outcome,
        startedOn,
        completedOn
    )
    VALUES
    (
        NEWID(),
        @OriginalSalesforceWorkId,
        @CorrelationId,
        N'ContractTestOriginalDelivery',
        @InvoiceNumber,
        1,
        N'Succeeded',
        SYSUTCDATETIME(),
        SYSUTCDATETIME()
    );

    INSERT dbo.ConsolidatedSales_SourceItems
    (
        id, correlationId, sourceSystem, blobContainer, blobPath, blobIdentityHash,
        sourceFileName, contentLength, blobLastModifiedOn, contentChecksum, eTag,
        status, claimToken, leaseOwner, leaseExpiresOn, claimedOn, firstReadOn
    )
    VALUES
    (
        @ReplacementSourceItemId, @ReplacementCorrelationId, N'HX', N'contract-tests',
        CONCAT(N'contract-tests/replacement-', @InvoiceNumber, N'.con.xml'),
        HASHBYTES('SHA2_256', CONVERT(varbinary(max), CONCAT(N'HX|contract-tests|replacement-', @InvoiceNumber))),
        CONCAT(N'replacement-', @InvoiceNumber, N'.con.xml'), 101, SYSUTCDATETIME(),
        N'contract-replacement-checksum', N'"contract-replacement-etag"', N'Claimed',
        @ReplacementClaimToken, N'contract-test', DATEADD(MINUTE, 5, SYSUTCDATETIME()), SYSUTCDATETIME(),
        @ReplacementSalesforceCooloffStartedOn
    );

    DECLARE @CorrectedInvoiceJson nvarchar(max) = N'
    {
      "ConsolidatedInvoiceNumber": "' + STRING_ESCAPE(@InvoiceNumber, 'json') + N'",
      "InvoiceDate": "2026-07-13",
      "CustomerAccountCode": "ACC-CORRECTED",
      "ExpectedLineCount": 1,
      "NumberOfTaxRates": 1,
      "LineValueTotal": 25.00,
      "TaxableTotal": 25.00,
      "TaxTotal": 5.00,
      "NetPaymentTotal": 25.00,
      "GrossPaymentTotal": 30.00,
      "Parties": [
        { "PartyRole": "Buyer", "AccountCode": "ACC-CORRECTED", "PartyName": "Corrected Contract Test" }
      ],
      "Components": [
        { "ComponentReferenceKey": "0580-DEL-200", "StandardInvoiceNumber": "DEL-200", "BranchCode": "0580" }
      ],
      "Lines": [
        {
          "ComponentReferenceKey": "0580-DEL-200",
          "LineIdentity": "LINE-1",
          "SalesforceExternalId": "' + STRING_ESCAPE(@ExternalId, 'json') + N'",
          "LineSequence": 1,
          "SourceLineNumber": "1",
          "ProductCode": "PRODUCT-CORRECTED",
          "Quantity": 1,
          "UnitPrice": 25.00,
          "LineTotal": 25.00
        }
      ],
      "TaxSubTotals": [
        { "TaxRateCode": "S", "TaxRate": 20, "NumberOfLinesAtRate": 1, "TaxAtRate": 5.00 }
      ]
    }';

    DECLARE @CorrectionCommitResults TABLE
    (
        consolidatedInvoiceId uniqueidentifier NOT NULL,
        isNew bit NOT NULL
    );

    INSERT @CorrectionCommitResults
    EXEC [dbo].[CommitConsolidatedSalesInvoice]
        @SourceItemId = @ReplacementSourceItemId,
        @ClaimToken = @ReplacementClaimToken,
        @InvoiceJson = @CorrectedInvoiceJson,
        @SalesforceCooloffStartedOn = @ReplacementSalesforceCooloffStartedOn,
        @SalesforceCooloffHours = @SalesforceCooloffHours,
        @SalesforceEligibleOn = @ReplacementSalesforceEligibleOn;

    IF NOT EXISTS
    (
        SELECT 1
        FROM @CorrectionCommitResults
        WHERE consolidatedInvoiceId = @OriginalInvoiceId
          AND isNew = 0
    )
        THROW 51000, 'Contract test failed: corrected invoice did not preserve its canonical identity.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_Invoices invoice
        WHERE invoice.id = @OriginalInvoiceId
          AND invoice.sourceItemId = @ReplacementSourceItemId
          AND invoice.correlationId = @ReplacementCorrelationId
          AND invoice.customerAccountCode = N'ACC-CORRECTED'
          AND invoice.invoiceDate = '2026-07-13'
          AND invoice.grossPaymentTotal = 30.00
    )
        THROW 51000, 'Contract test failed: corrected canonical invoice values were not applied.', 1;

    IF (SELECT COUNT(*) FROM dbo.ConsolidatedSales_InvoiceLines WHERE consolidatedInvoiceId = @OriginalInvoiceId) <> 1
       OR NOT EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_InvoiceLines
           WHERE consolidatedInvoiceId = @OriginalInvoiceId
             AND productCode = N'PRODUCT-CORRECTED'
       )
       OR EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_InvoiceComponents
           WHERE consolidatedInvoiceId = @OriginalInvoiceId
             AND componentReferenceKey = N'0580-DEL-100'
       )
        THROW 51000, 'Contract test failed: corrected invoice children did not replace the previous canonical version.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork work
        WHERE work.id = @OriginalSalesforceWorkId
          AND work.correlationId = @ReplacementCorrelationId
          AND work.status = N'Pending'
          AND work.attemptCount = 0
          AND work.completedOn IS NULL
    )
       OR NOT EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_SalesforceLineState lineState
           WHERE lineState.salesforceWorkId = @OriginalSalesforceWorkId
             AND lineState.externalId = @ExternalId
             AND lineState.status = N'Pending'
       )
       OR NOT EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_SalesforceAttempts attempt
           WHERE attempt.salesforceWorkId = @OriginalSalesforceWorkId
             AND attempt.operation = N'ContractTestOriginalDelivery'
       )
        THROW 51000, 'Contract test failed: corrected invoice did not reset Salesforce work while retaining attempt history.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ReconciliationWork work
        INNER JOIN dbo.ConsolidatedSales_InvoiceComponents component ON component.id = work.componentId
        WHERE work.consolidatedInvoiceId = @OriginalInvoiceId
          AND work.correlationId = @ReplacementCorrelationId
          AND work.status = N'Pending'
          AND component.standardInvoiceNumber = N'DEL-200'
    )
        THROW 51000, 'Contract test failed: corrected invoice reconciliation work was not recreated.', 1;

    DECLARE @CompletionWorkId uniqueidentifier;
    DECLARE @CompletionClaimToken uniqueidentifier = NEWID();
    DECLARE @CompletionMatchedInvoiceHeaderId uniqueidentifier = NEWID();

    SELECT TOP (1) @CompletionWorkId = work.id
    FROM dbo.ConsolidatedSales_ReconciliationWork work
    WHERE work.consolidatedInvoiceId = @OriginalInvoiceId
      AND work.correlationId = @ReplacementCorrelationId
      AND work.status = N'Pending';

    UPDATE dbo.ConsolidatedSales_ReconciliationWork
    SET
        status = N'Claimed',
        claimToken = @CompletionClaimToken,
        leaseOwner = N'contract-completion-test',
        leaseExpiresOn = DATEADD(MINUTE, 5, SYSUTCDATETIME()),
        attemptCount = attemptCount + 1,
        updatedOn = SYSUTCDATETIME()
    WHERE id = @CompletionWorkId;

    EXEC [dbo].[CompleteConsolidatedSalesReconciliationWork]
        @ReconciliationWorkId = @CompletionWorkId,
        @ClaimToken = @CompletionClaimToken,
        @MatchedInvoiceHeaderId = @CompletionMatchedInvoiceHeaderId;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ReconciliationWork
        WHERE id = @CompletionWorkId
          AND status = N'Completed'
          AND matchedInvoiceHeaderId = @CompletionMatchedInvoiceHeaderId
          AND claimToken IS NULL
          AND completedOn IS NOT NULL
    )
        THROW 51000, 'Contract test failed: reconciliation completion did not persist the matched invoice identifier.', 1;

    EXEC [dbo].[CompleteConsolidatedSalesReconciliationWork]
        @ReconciliationWorkId = @CompletionWorkId,
        @ClaimToken = @CompletionClaimToken,
        @MatchedInvoiceHeaderId = @CompletionMatchedInvoiceHeaderId;

    INSERT dbo.ConsolidatedSales_SourceItems
    (
        id, correlationId, sourceSystem, blobContainer, blobPath, blobIdentityHash,
        sourceFileName, contentLength, blobLastModifiedOn, contentChecksum, eTag,
        status, retryCount, claimToken, leaseOwner, leaseExpiresOn, claimedOn, discoveredOn
    )
    VALUES
    (
        @ExpiredSourceItemId, NEWID(), N'HX', N'contract-tests',
        CONCAT(N'contract-tests/expired-', @InvoiceNumber, N'.con.xml'),
        HASHBYTES('SHA2_256', CONVERT(varbinary(max), CONCAT(N'HX|contract-tests|expired-', @InvoiceNumber))),
        CONCAT(N'expired-', @InvoiceNumber, N'.con.xml'), 100, SYSUTCDATETIME(),
        N'contract-expired-checksum', N'"contract-expired-etag"', N'Claimed', 0,
        NEWID(), N'contract-test', DATEADD(SECOND, -1, SYSUTCDATETIME()), SYSUTCDATETIME(),
        @SalesforceCooloffStartedOn
    );

    EXEC [dbo].[ClaimNextConsolidatedSalesSourceItem]
        @LeaseOwner = N'contract-recovery-test',
        @LeaseDurationSeconds = 300,
        @MaximumRetryCount = 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SourceItems
        WHERE id = @ExpiredSourceItemId
          AND status = N'TerminallyFailed'
          AND retryCount = 1
          AND lastErrorCategory = N'LeaseExpired'
          AND claimToken IS NULL
          AND leaseExpiresOn IS NULL
    )
        THROW 51000, 'Contract test failed: exhausted source work was reclaimed after lease expiry.', 1;

    ROLLBACK TRANSACTION;
    PRINT 'Consolidated Sales contract tests passed.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;
