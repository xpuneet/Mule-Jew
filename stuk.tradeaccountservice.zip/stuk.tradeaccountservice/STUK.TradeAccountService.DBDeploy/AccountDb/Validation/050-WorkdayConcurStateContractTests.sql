/*
Purpose:
  Exercises the Workday-to-Concur watermark, overlap, restart and completion contracts.

Safety:
  The script refuses to run when an open integration run exists and rolls back all test changes.

Expected use:
  Run in a non-production database after scripts 040 through 049.

Rollback guidance:
  No manual rollback is required because this script always rolls back its transaction.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF EXISTS (SELECT 1 FROM dbo.WorkdayConcurRun WHERE closedOn IS NULL)
    THROW 51000, 'State contract test requires no open Workday-to-Concur run.', 1;

BEGIN TRANSACTION;

BEGIN TRY
    DECLARE @Now datetimeoffset(7) = '2026-09-04T08:30:00+00:00';
    DECLARE @InitialWatermark datetimeoffset(7);
    DECLARE @ExtractThrough datetimeoffset(7);
    DECLARE @LaterExtractThrough datetimeoffset(7);
    DECLARE @LaterNow datetimeoffset(7);
    DECLARE @CorrelationId uniqueidentifier = NEWID();
    DECLARE @OtherCorrelationId uniqueidentifier;
    DECLARE @RunId uniqueidentifier;
    DECLARE @ClaimToken uniqueidentifier;

    SELECT @InitialWatermark = committedThrough
    FROM dbo.WorkdayConcurWatermark
    WHERE integrationName = N'WorkdayConcur';

    IF @InitialWatermark IS NULL
    BEGIN
        SET @InitialWatermark = DATEADD(DAY, -1, @Now);
        EXEC dbo.InitialiseWorkdayConcurWatermark
            @CommittedThrough = @InitialWatermark,
            @Now = @Now;
    END;

    SET @ExtractThrough = DATEADD(DAY, 1, @InitialWatermark);

    DECLARE @Runs TABLE
    (
        runId uniqueidentifier,
        correlationId uniqueidentifier,
        extractFrom datetimeoffset(7),
        extractThrough datetimeoffset(7),
        status nvarchar(32),
        currentStage nvarchar(32),
        fileStateJson nvarchar(max),
        tm1SynapseRunId nvarchar(100),
        transformSynapseRunId nvarchar(100),
        deliverySynapseRunId nvarchar(100),
        housekeepingSynapseRunId nvarchar(100),
        retryCount int,
        lastErrorCategory nvarchar(100),
        lastErrorMessage nvarchar(2000),
        claimToken uniqueidentifier,
        leaseOwner nvarchar(200),
        leaseExpiresOn datetimeoffset(7),
        createdOn datetimeoffset(7),
        updatedOn datetimeoffset(7),
        closedOn datetimeoffset(7),
        isNew bit
    );

    INSERT @Runs
    EXEC dbo.CreateWorkdayConcurRun
        @CorrelationId = @CorrelationId,
        @LeaseOwner = N'contract-first',
        @ExtractThrough = @ExtractThrough,
        @LeaseDurationSeconds = 300,
        @Now = @Now;

    SELECT @RunId = runId, @ClaimToken = claimToken FROM @Runs;

    IF @RunId IS NULL
       OR NOT EXISTS
       (
           SELECT 1 FROM @Runs
           WHERE isNew = 1
             AND extractFrom = @InitialWatermark
             AND extractThrough = @ExtractThrough
             AND currentStage = N'Pending'
       )
        THROW 51000, 'State contract test failed: a frozen run was not created.', 1;

    DELETE FROM @Runs;
    SET @OtherCorrelationId = NEWID();

    INSERT @Runs
    EXEC dbo.CreateWorkdayConcurRun
        @CorrelationId = @OtherCorrelationId,
        @LeaseOwner = N'contract-overlap',
        @ExtractThrough = @ExtractThrough,
        @LeaseDurationSeconds = 300,
        @Now = @Now;

    IF EXISTS (SELECT 1 FROM @Runs)
        THROW 51000, 'State contract test failed: an overlapping invocation acquired the run.', 1;

    EXEC dbo.ReleaseWorkdayConcurRunLease
        @RunId = @RunId,
        @ClaimToken = @ClaimToken,
        @Now = @Now;

    SET @OtherCorrelationId = NEWID();
    SET @LaterExtractThrough = DATEADD(DAY, 2, @ExtractThrough);
    SET @LaterNow = DATEADD(SECOND, 1, @Now);

    INSERT @Runs
    EXEC dbo.CreateWorkdayConcurRun
        @CorrelationId = @OtherCorrelationId,
        @LeaseOwner = N'contract-resume',
        @ExtractThrough = @LaterExtractThrough,
        @LeaseDurationSeconds = 300,
        @Now = @LaterNow;

    IF NOT EXISTS
    (
        SELECT 1 FROM @Runs
        WHERE runId = @RunId
          AND correlationId = @CorrelationId
          AND extractFrom = @InitialWatermark
          AND extractThrough = @ExtractThrough
          AND isNew = 0
          AND retryCount = 2
    )
        THROW 51000, 'State contract test failed: restart did not resume the frozen run.', 1;

    SELECT @ClaimToken = claimToken FROM @Runs;

    EXEC dbo.UpdateWorkdayConcurRunStage
        @RunId, @ClaimToken, N'Pending', N'CollectingInputs', N'{"input":"ready"}', N'tm1-run', NULL, NULL, NULL, @Now;
    EXEC dbo.UpdateWorkdayConcurRunStage
        @RunId, @ClaimToken, N'CollectingInputs', N'Transforming', NULL, NULL, N'transform-run', NULL, NULL, @Now;
    EXEC dbo.UpdateWorkdayConcurRunStage
        @RunId, @ClaimToken, N'Transforming', N'Delivering', NULL, NULL, NULL, N'delivery-run', NULL, @Now;
    EXEC dbo.UpdateWorkdayConcurRunStage
        @RunId, @ClaimToken, N'Delivering', N'MovingFiles', NULL, NULL, NULL, NULL, N'housekeeping-run', @Now;
    EXEC dbo.CommitWorkdayConcurRun @RunId, @ClaimToken, @Now;
    EXEC dbo.CommitWorkdayConcurRun @RunId, @ClaimToken, @Now;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.WorkdayConcurWatermark
        WHERE integrationName = N'WorkdayConcur'
          AND committedThrough = @ExtractThrough
          AND completedRunId = @RunId
    )
        THROW 51000, 'State contract test failed: completion did not advance the watermark.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.WorkdayConcurRun
        WHERE runId = @RunId
          AND status = N'Completed'
          AND currentStage = N'Completed'
          AND closedOn IS NOT NULL
    )
        THROW 51000, 'State contract test failed: the run was not closed as completed.', 1;

    DELETE FROM @Runs;
    SET @CorrelationId = NEWID();
    SET @LaterExtractThrough = DATEADD(DAY, 1, @ExtractThrough);
    SET @LaterNow = DATEADD(DAY, 1, @Now);

    INSERT @Runs
    EXEC dbo.CreateWorkdayConcurRun
        @CorrelationId = @CorrelationId,
        @LeaseOwner = N'contract-no-data',
        @ExtractThrough = @LaterExtractThrough,
        @LeaseDurationSeconds = 300,
        @Now = @LaterNow;

    SELECT @RunId = runId, @ClaimToken = claimToken FROM @Runs;

    EXEC dbo.UpdateWorkdayConcurRunStage
        @RunId, @ClaimToken, N'Pending', N'CollectingInputs', NULL, NULL, NULL, NULL, NULL, @LaterNow;
    EXEC dbo.CompleteWorkdayConcurNoDataRun
        @RunId, @ClaimToken, @LaterNow;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.WorkdayConcurWatermark
        WHERE integrationName = N'WorkdayConcur'
          AND committedThrough = @ExtractThrough
    )
        THROW 51000, 'State contract test failed: a no-data run changed the committed watermark.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.WorkdayConcurRun
        WHERE runId = @RunId
          AND status = N'NoData'
          AND currentStage = N'NoData'
          AND closedOn IS NOT NULL
    )
        THROW 51000, 'State contract test failed: the no-data run was not closed.', 1;

    ROLLBACK TRANSACTION;
    PRINT 'Workday-to-Concur state contract tests passed.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
