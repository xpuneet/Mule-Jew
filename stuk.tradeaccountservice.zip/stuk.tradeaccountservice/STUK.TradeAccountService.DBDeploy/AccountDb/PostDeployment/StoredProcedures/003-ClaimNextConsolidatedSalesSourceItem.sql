/*
Procedure:
  [dbo].[ClaimNextConsolidatedSalesSourceItem]

Purpose:
  Atomically claims the next source item that is ready or eligible for retry.

Used by:
  Consolidated Sales ingestion persistence implementation.

Parameters:
  @LeaseOwner        Worker instance claiming the item. Required.
  @LeaseDurationSeconds Duration of the processing lease. Required.
  @Now               UTC processing time. Defaults to current UTC time.
  @MaximumRetryCount Maximum permitted processing attempts. Defaults to 2 for deployment compatibility.

Returns:
  The claimed source-item row, or no row when no work is available.

Idempotency:
  Claiming is concurrency-safe; only the worker holding the returned claim token may complete or fail it.

Notes:
  An expired lease consumes an attempt. Exhausted expired claims are terminally failed instead of reclaimed.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[ClaimNextConsolidatedSalesSourceItem]
    @LeaseOwner nvarchar(200),
    @LeaseDurationSeconds int,
    @Now datetimeoffset(7) = NULL,
    @MaximumRetryCount int = 2
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @LeaseDurationSeconds <= 0
        THROW 51000, 'Lease duration must be greater than zero.', 1;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());
    DECLARE @ClaimToken uniqueidentifier = NEWID();

    UPDATE dbo.ConsolidatedSales_SourceItems
    SET
        retryCount = retryCount + 1,
        status = N'TerminallyFailed',
        nextAttemptOn = NULL,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        failedOn = @Now,
        lastErrorCategory = N'LeaseExpired',
        lastErrorMessage = N'The processing lease expired after the maximum permitted attempts.',
        updatedOn = @Now
    WHERE status = N'Claimed'
      AND leaseExpiresOn <= @Now
      AND retryCount + 1 >= @MaximumRetryCount;

    DECLARE @Claimed TABLE (id uniqueidentifier NOT NULL);

    ;WITH Candidate AS
    (
        SELECT TOP (1) *
        FROM dbo.ConsolidatedSales_SourceItems WITH (UPDLOCK, READPAST, ROWLOCK)
        WHERE
        (
            (
                status IN (N'Ready', N'Retry')
                AND retryCount < @MaximumRetryCount
                AND (nextAttemptOn IS NULL OR nextAttemptOn <= @Now)
            )
            OR
            (
                status = N'Claimed'
                AND leaseExpiresOn <= @Now
                AND retryCount + 1 < @MaximumRetryCount
            )
        )
        ORDER BY discoveredOn, id
    )
    UPDATE Candidate
    SET
        status = N'Claimed',
        retryCount = retryCount + CASE WHEN status = N'Claimed' THEN 1 ELSE 0 END,
        claimToken = @ClaimToken,
        leaseOwner = @LeaseOwner,
        leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
        claimedOn = @Now,
        updatedOn = @Now
    OUTPUT inserted.id INTO @Claimed(id);

    SELECT sourceItem.*
    FROM dbo.ConsolidatedSales_SourceItems sourceItem
    INNER JOIN @Claimed claimed ON claimed.id = sourceItem.id;
END;
