/*
Procedure:
  [dbo].[RenewConsolidatedSalesSourceItemLease]

Purpose:
  Extends an active source-item lease while a large Blob is being streamed and ingested.

Used by:
  Consolidated Sales ingestion persistence implementation.

Parameters:
  @SourceItemId         Source-item identifier. Required.
  @ClaimToken           Current claim token. Required.
  @LeaseDurationSeconds New duration from the supplied processing time. Required.
  @Now                  UTC processing time. Defaults to current UTC time.

Returns:
  The renewed lease-expiry time.

Idempotency:
  Repeated renewal by the current owner safely moves the expiry forward.

Notes:
  This supports streaming files whose processing time may exceed the initial lease duration.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[RenewConsolidatedSalesSourceItemLease]
    @SourceItemId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @LeaseDurationSeconds int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @LeaseDurationSeconds <= 0
        THROW 51000, 'Lease duration must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_SourceItems
    SET
        leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
        updatedOn = @Now
    WHERE id = @SourceItemId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The source-item lease is no longer held by the supplied claim token.', 1;

    SELECT leaseExpiresOn
    FROM dbo.ConsolidatedSales_SourceItems
    WHERE id = @SourceItemId;
END;
