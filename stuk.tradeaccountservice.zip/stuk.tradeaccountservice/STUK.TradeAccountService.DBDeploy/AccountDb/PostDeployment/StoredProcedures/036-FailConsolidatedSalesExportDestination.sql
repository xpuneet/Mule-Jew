/*
Procedure:
  [dbo].[FailConsolidatedSalesExportDestination]

Purpose:
  Records a destination failure and schedules retry or terminal failure independently.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @ExportDestinationId Destination work identifier. Required.
  @ClaimToken           Current claim token. Required.
  @ErrorCategory        Classified failure category. Required.
  @ErrorMessage         Safe failure description. Required.
  @NextAttemptOn        Next retry time when retry remains possible.
  @MaximumRetryCount    Maximum permitted delivery attempts in the current retry cycle. Required.
  @ExternalExecutionId  Synapse/platform execution identifier when applicable.
  @Now                  UTC failure time. Defaults to current UTC time.

Returns:
  The resulting status, attempt count and next-attempt time.

Idempotency:
  Only the current claim token can record the failure once.

Notes:
  Failure of one destination does not alter the other destination or the extracted snapshot.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[FailConsolidatedSalesExportDestination]
    @ExportDestinationId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ErrorCategory nvarchar(100),
    @ErrorMessage nvarchar(2000),
    @NextAttemptOn datetimeoffset(7) = NULL,
    @MaximumRetryCount int,
    @ExternalExecutionId nvarchar(255) = NULL,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF @NextAttemptOn IS NULL
       AND EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_ExportDestinations
           WHERE id = @ExportDestinationId
             AND status = N'Claimed'
             AND claimToken = @ClaimToken
             AND retryCycleAttemptCount < @MaximumRetryCount
       )
        THROW 51000, 'NextAttemptOn is required while destination delivery remains retryable.', 1;

    BEGIN TRANSACTION;

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET
        status = CASE WHEN retryCycleAttemptCount >= @MaximumRetryCount THEN N'TerminallyFailed' ELSE N'Retry' END,
        nextAttemptOn = CASE WHEN retryCycleAttemptCount >= @MaximumRetryCount THEN NULL ELSE @NextAttemptOn END,
        externalExecutionId = COALESCE(@ExternalExecutionId, externalExecutionId),
        lastErrorCategory = @ErrorCategory,
        lastErrorMessage = @ErrorMessage,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        updatedOn = @Now
    WHERE id = @ExportDestinationId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The destination is not held by the supplied claim token.', 1;

    UPDATE dbo.ConsolidatedSales_ExportDeliveryAttempts
    SET
        status = N'Failed',
        externalExecutionId = @ExternalExecutionId,
        errorCategory = @ErrorCategory,
        errorMessage = @ErrorMessage,
        completedOn = @Now
    WHERE exportDestinationId = @ExportDestinationId
      AND claimToken = @ClaimToken
      AND status = N'Started';

    IF @@ROWCOUNT <> 1
        THROW 51000, 'The active destination attempt was not found.', 1;

    COMMIT TRANSACTION;

    SELECT status, attemptCount, nextAttemptOn
    FROM dbo.ConsolidatedSales_ExportDestinations
    WHERE id = @ExportDestinationId;
END;
