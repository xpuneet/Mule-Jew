/*
Procedure:
  [dbo].[CreateConsolidatedSalesExportRun]

Purpose:
  Creates one idempotent logical weekly export run and its blocked destination rows.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @LogicalRunKey  Stable key for the scheduled logical run. Required.
  @CorrelationId  End-to-end correlation identifier. Required.
  @ExportYear     Calendar year represented by the export. Required.
  @ExtractFromDate First day included by the Salesforce query. Required.
  @ScheduledFor   Scheduled UTC/offset time for the logical run. Required.
  @Now            UTC creation time. Defaults to current UTC time.

Returns:
  The existing or newly created export run and an isNew flag.

Idempotency:
  Idempotent by LogicalRunKey. A repeated call returns the original run.

Notes:
  Destination rows remain blocked until CompleteConsolidatedSalesExportExtraction succeeds.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CreateConsolidatedSalesExportRun]
    @LogicalRunKey nvarchar(100),
    @CorrelationId uniqueidentifier,
    @ExportYear int,
    @ExtractFromDate date,
    @ScheduledFor datetimeoffset(7),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NULLIF(LTRIM(RTRIM(@LogicalRunKey)), N'') IS NULL
        THROW 51000, 'Logical run key is required.', 1;

    IF @ExportYear < 2000 OR @ExportYear > 9999
        THROW 51000, 'Export year is outside the supported range.', 1;

    IF YEAR(@ExtractFromDate) <> @ExportYear OR MONTH(@ExtractFromDate) <> 1 OR DAY(@ExtractFromDate) <> 1
        THROW 51000, 'ExtractFromDate must be 1 January of ExportYear.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    DECLARE @ExportRunId uniqueidentifier;
    DECLARE @IsNew bit = 0;

    BEGIN TRANSACTION;

    SELECT @ExportRunId = id
    FROM dbo.ConsolidatedSales_ExportRuns WITH (UPDLOCK, HOLDLOCK)
    WHERE logicalRunKey = @LogicalRunKey;

    IF @ExportRunId IS NOT NULL
       AND EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_ExportRuns
           WHERE id = @ExportRunId
             AND (exportYear <> @ExportYear
                  OR extractFromDate <> @ExtractFromDate
                  OR scheduledFor <> @ScheduledFor)
       )
        THROW 51000, 'The logical run key already exists with different scheduling or extraction values.', 1;

    IF @ExportRunId IS NULL
    BEGIN
        SET @ExportRunId = NEWID();
        SET @IsNew = 1;

        INSERT dbo.ConsolidatedSales_ExportRuns
        (
            id, logicalRunKey, correlationId, exportYear, extractFromDate,
            scheduledFor, status, createdOn, updatedOn
        )
        VALUES
        (
            @ExportRunId, @LogicalRunKey, @CorrelationId, @ExportYear, @ExtractFromDate,
            @ScheduledFor, N'Pending', @Now, @Now
        );

        INSERT dbo.ConsolidatedSales_ExportDestinations
        (
            exportRunId, destination, status, createdOn, updatedOn
        )
        VALUES
            (@ExportRunId, N'Phocas', N'Blocked', @Now, @Now),
            (@ExportRunId, N'DataLake', N'Blocked', @Now, @Now);
    END;

    COMMIT TRANSACTION;

    SELECT
        run.id,
        run.logicalRunKey,
        run.correlationId,
        run.exportYear,
        run.extractFromDate,
        run.scheduledFor,
        run.status,
        run.extractionAttemptCount,
        run.extractedPageCount,
        run.extractedRowCount,
        run.nextAttemptOn,
        run.claimToken,
        run.leaseOwner,
        run.leaseExpiresOn,
        run.lastErrorCategory,
        run.lastErrorMessage,
        run.createdOn,
        run.extractionStartedOn,
        run.extractionCompletedOn,
        run.failedOn,
        run.updatedOn,
        @IsNew AS isNew
    FROM dbo.ConsolidatedSales_ExportRuns run
    WHERE run.id = @ExportRunId;
END;
