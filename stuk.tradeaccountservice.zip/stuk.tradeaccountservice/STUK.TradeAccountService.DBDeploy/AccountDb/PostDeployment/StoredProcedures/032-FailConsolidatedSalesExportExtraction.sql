/*
Procedure:
  [dbo].[FailConsolidatedSalesExportExtraction]

Purpose:
  Records an extraction failure and schedules a clean retry or terminal failure.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @ExportRunId       Export run identifier. Required.
  @ClaimToken        Current extraction claim token. Required.
  @ErrorCategory     Classified failure category. Required.
  @ErrorMessage      Safe failure description. Required.
  @IsTransient       Whether the failure remains eligible for retry. Required.
  @NextAttemptOn     Next retry time when retry remains possible.
  @MaximumRetryCount Maximum permitted extraction attempts. Required.
  @Now               UTC failure time. Defaults to current UTC time.

Returns:
  The resulting status, attempt count and next-attempt time.

Idempotency:
  Only the current claim token can record the failure once.

Notes:
  Partial pages remain unavailable and are deleted when a later claim starts a clean attempt.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[FailConsolidatedSalesExportExtraction]
    @ExportRunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ErrorCategory nvarchar(100),
    @ErrorMessage nvarchar(2000),
    @IsTransient bit,
    @NextAttemptOn datetimeoffset(7) = NULL,
    @MaximumRetryCount int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF @IsTransient = 1
       AND @NextAttemptOn IS NULL
       AND EXISTS
       (
           SELECT 1
           FROM dbo.ConsolidatedSales_ExportRuns
           WHERE id = @ExportRunId
             AND status = N'Extracting'
             AND claimToken = @ClaimToken
             AND extractionAttemptCount < @MaximumRetryCount
       )
        THROW 51000, 'NextAttemptOn is required while extraction remains retryable.', 1;

    UPDATE dbo.ConsolidatedSales_ExportRuns
    SET
        status = CASE WHEN @IsTransient = 0 OR extractionAttemptCount >= @MaximumRetryCount THEN N'TerminallyFailed' ELSE N'Retry' END,
        nextAttemptOn = CASE WHEN @IsTransient = 0 OR extractionAttemptCount >= @MaximumRetryCount THEN NULL ELSE @NextAttemptOn END,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = @ErrorCategory,
        lastErrorMessage = @ErrorMessage,
        failedOn = CASE WHEN @IsTransient = 0 OR extractionAttemptCount >= @MaximumRetryCount THEN @Now ELSE NULL END,
        updatedOn = @Now
    WHERE id = @ExportRunId
      AND status = N'Extracting'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The export run is not held by the supplied claim token.', 1;

    SELECT status, extractionAttemptCount, nextAttemptOn
    FROM dbo.ConsolidatedSales_ExportRuns
    WHERE id = @ExportRunId;
END;
