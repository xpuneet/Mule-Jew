/*
Procedure:
  dbo.CompleteWorkdayConcurNoDataRun

Purpose:
  Closes a run whose Workday extraction returned no worker detail rows without advancing the watermark.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  @RunId      Run identifier. Required.
  @ClaimToken Active claim token. Required.
  @Now        UTC operation time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Not idempotent after closure; a stale caller cannot close the run again.

Notes:
  The committed Workday boundary is deliberately unchanged so the same interval is considered on the next run.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.CompleteWorkdayConcurNoDataRun
    @RunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.WorkdayConcurRun
    SET status = N'NoData',
        currentStage = N'NoData',
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = NULL,
        lastErrorMessage = NULL,
        updatedOn = @Now,
        closedOn = @Now
    WHERE runId = @RunId
      AND claimToken = @ClaimToken
      AND currentStage = N'CollectingInputs'
      AND closedOn IS NULL
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT <> 1 THROW 51000, 'The Workday-to-Concur run is not in the claimed input-collection stage.', 1;
END;
