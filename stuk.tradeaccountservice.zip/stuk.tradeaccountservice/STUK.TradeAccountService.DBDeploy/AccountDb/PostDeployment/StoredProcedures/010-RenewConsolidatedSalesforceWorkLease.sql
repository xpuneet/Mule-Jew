/*
Procedure:
  [dbo].[RenewConsolidatedSalesforceWorkLease]

Purpose:
  Extends an active Salesforce work lease held by the supplied claim token.

Used by:
  Consolidated Sales Salesforce synchronisation persistence implementation.

Parameters:
  @SalesforceWorkId     Salesforce work identifier. Required.
  @ClaimToken           Current claim token. Required.
  @LeaseDurationSeconds New duration from the supplied processing time. Required.
  @Now                  UTC processing time. Defaults to current UTC time.

Returns:
  The renewed lease-expiry time.

Idempotency:
  Repeated renewal by the current owner safely moves the expiry forward.

Notes:
  An expired lease cannot be renewed after another worker has reclaimed it.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[RenewConsolidatedSalesforceWorkLease]
    @SalesforceWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @LeaseDurationSeconds int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @LeaseDurationSeconds <= 0
        THROW 51000, 'Lease duration must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_SalesforceWork
    SET
        leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
        updatedOn = @Now
    WHERE id = @SalesforceWorkId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The Salesforce work lease is no longer held by the supplied claim token.', 1;

    SELECT leaseExpiresOn
    FROM dbo.ConsolidatedSales_SalesforceWork
    WHERE id = @SalesforceWorkId;
END;
