/*
Procedure:
  [dbo].[RenewConsolidatedSalesExportRunLease]

Purpose:
  Extends an active Salesforce extraction lease held by the supplied claim token.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @ExportRunId          Export run identifier. Required.
  @ClaimToken           Current claim token. Required.
  @LeaseDurationSeconds New duration from the supplied processing time. Required.
  @Now                  UTC processing time. Defaults to current UTC time.

Returns:
  The renewed lease-expiry time.

Idempotency:
  Repeated renewal by the current owner safely moves the expiry forward.

Notes:
  An expired or superseded lease cannot be renewed.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[RenewConsolidatedSalesExportRunLease]
    @ExportRunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @LeaseDurationSeconds int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @LeaseDurationSeconds <= 0
        THROW 51000, 'Lease duration must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_ExportRuns
    SET leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now), updatedOn = @Now
    WHERE id = @ExportRunId
      AND status = N'Extracting'
      AND claimToken = @ClaimToken
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The export-run lease is no longer held by the supplied claim token.', 1;

    SELECT leaseExpiresOn
    FROM dbo.ConsolidatedSales_ExportRuns
    WHERE id = @ExportRunId;
END;
