/*
Procedure:
  [dbo].[GetConsolidatedSalesforceWorkDetails]

Purpose:
  Returns the complete canonical invoice and deterministic line state required for one claimed Salesforce delivery.

Used by:
  Consolidated Sales Salesforce synchronisation persistence implementation.

Parameters:
  @SalesforceWorkId Salesforce work identifier. Required.
  @ClaimToken       Current claim token. Required.

Returns:
  One JSON document in the JsonResult column.

Idempotency:
  Read-only.

Notes:
  The procedure verifies claim ownership so stale workers cannot obtain work after lease reassignment.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[GetConsolidatedSalesforceWorkDetails]
    @SalesforceWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork
        WHERE id = @SalesforceWorkId
          AND status = N'Claimed'
          AND claimToken = @ClaimToken
    )
        THROW 51000, 'The Salesforce work is not held by the supplied claim token.', 1;

    SELECT
    (
        SELECT
            work.id AS salesforceWorkId,
            work.consolidatedInvoiceId,
            work.correlationId,
            work.attemptCount,
            work.expectedLineCount,
            work.salesforceOrderId,
            JSON_QUERY
            (
                (
                    SELECT
                        invoice.*,
                        JSON_QUERY
                        (
                            (
                                SELECT party.*
                                FROM dbo.ConsolidatedSales_InvoiceParties party
                                WHERE party.consolidatedInvoiceId = invoice.id
                                ORDER BY party.partyRole
                                FOR JSON PATH
                            )
                        ) AS parties,
                        JSON_QUERY
                        (
                            (
                                SELECT component.*
                                FROM dbo.ConsolidatedSales_InvoiceComponents component
                                WHERE component.consolidatedInvoiceId = invoice.id
                                ORDER BY component.componentReferenceKey
                                FOR JSON PATH
                            )
                        ) AS components,
                        JSON_QUERY
                        (
                            (
                                SELECT line.*
                                FROM dbo.ConsolidatedSales_InvoiceLines line
                                WHERE line.consolidatedInvoiceId = invoice.id
                                ORDER BY line.lineSequence
                                FOR JSON PATH
                            )
                        ) AS lines,
                        JSON_QUERY
                        (
                            (
                                SELECT tax.*
                                FROM dbo.ConsolidatedSales_TaxSubTotals tax
                                WHERE tax.consolidatedInvoiceId = invoice.id
                                ORDER BY tax.taxRate
                                FOR JSON PATH
                            )
                        ) AS taxSubTotals
                    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
                )
            ) AS invoice,
            JSON_QUERY
            (
                (
                    SELECT
                        lineState.externalId AS salesforceExternalId,
                        lineState.status AS salesforceLineStatus,
                        lineState.salesforceProductId,
                        lineState.salesforcePricebookEntryId,
                        lineState.salesforceOrderItemId
                    FROM dbo.ConsolidatedSales_SalesforceLineState lineState
                    INNER JOIN dbo.ConsolidatedSales_InvoiceLines line
                        ON line.id = lineState.consolidatedInvoiceLineId
                    WHERE lineState.salesforceWorkId = work.id
                    ORDER BY line.lineSequence
                    FOR JSON PATH
                )
            ) AS lines
        FROM dbo.ConsolidatedSales_SalesforceWork work
        INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
        WHERE work.id = @SalesforceWorkId
          AND work.claimToken = @ClaimToken
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    ) AS JsonResult;
END;
