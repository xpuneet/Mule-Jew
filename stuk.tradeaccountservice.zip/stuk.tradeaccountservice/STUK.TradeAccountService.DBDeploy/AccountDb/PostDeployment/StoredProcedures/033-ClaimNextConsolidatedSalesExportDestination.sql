/*
Procedure:
  [dbo].[ClaimNextConsolidatedSalesExportDestination]

Purpose:
  Atomically claims the next eligible Phocas or Data Lake delivery and opens an attempt record.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @Destination          Phocas or DataLake. Required.
  @LeaseOwner           Worker instance identifier. Required.
  @LeaseDurationSeconds Processing lease duration. Required.
  @ExportDestinationId  Optional work restriction used by controlled recovery and contract testing.
  @Now                  UTC claim time. Defaults to current UTC time.
  @MaximumRetryCount    Maximum permitted delivery attempts in the current retry cycle. Defaults to 5 for deployment compatibility.

Returns:
  The claimed destination work and its parent run details, or no row when none is eligible.

Idempotency:
  Not idempotent. A successful claim creates a new attempt and claim token.

Notes:
  Expired attempts are closed as failed before the destination is reclaimed. Exhausted expired
  destinations are terminally failed instead of opening another attempt. The lifetime attempt
  count and its audit rows are retained across approved replay cycles.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[ClaimNextConsolidatedSalesExportDestination]
    @Destination nvarchar(30),
    @LeaseOwner nvarchar(200),
    @LeaseDurationSeconds int,
    @ExportDestinationId uniqueidentifier = NULL,
    @Now datetimeoffset(7) = NULL,
    @MaximumRetryCount int = 5
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @Destination NOT IN (N'Phocas', N'DataLake')
        THROW 51000, 'Destination must be Phocas or DataLake.', 1;

    IF NULLIF(LTRIM(RTRIM(@LeaseOwner)), N'') IS NULL
        THROW 51000, 'Lease owner is required.', 1;

    IF @LeaseDurationSeconds <= 0
        THROW 51000, 'Lease duration must be greater than zero.', 1;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    DECLARE @ClaimedExportDestinationId uniqueidentifier;
    DECLARE @ClaimToken uniqueidentifier = NEWID();
    DECLARE @ApplicationLockResult int;
    DECLARE @ApplicationLockResource nvarchar(255) = CONCAT(N'ConsolidatedSalesExportDestination:', @Destination);

    BEGIN TRANSACTION;

    EXEC @ApplicationLockResult = sys.sp_getapplock
        @Resource = @ApplicationLockResource,
        @LockMode = N'Exclusive',
        @LockOwner = N'Transaction',
        @LockTimeout = 10000;

    IF @ApplicationLockResult < 0
        THROW 51000, 'The destination claim lock could not be acquired.', 1;

    UPDATE attempt
    SET
        status = N'Failed',
        errorCategory = N'LeaseExpired',
        errorMessage = N'The delivery lease expired after the maximum permitted attempts.',
        completedOn = @Now
    FROM dbo.ConsolidatedSales_ExportDeliveryAttempts attempt
    INNER JOIN dbo.ConsolidatedSales_ExportDestinations destination
        ON destination.id = attempt.exportDestinationId
    WHERE destination.destination = @Destination
      AND destination.status = N'Claimed'
      AND destination.leaseExpiresOn <= @Now
      AND destination.retryCycleAttemptCount >= @MaximumRetryCount
      AND (@ExportDestinationId IS NULL OR destination.id = @ExportDestinationId)
      AND attempt.status = N'Started';

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET
        status = N'TerminallyFailed',
        nextAttemptOn = NULL,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = N'LeaseExpired',
        lastErrorMessage = N'The delivery lease expired after the maximum permitted attempts.',
        updatedOn = @Now
    WHERE destination = @Destination
      AND status = N'Claimed'
      AND leaseExpiresOn <= @Now
      AND retryCycleAttemptCount >= @MaximumRetryCount
      AND (@ExportDestinationId IS NULL OR id = @ExportDestinationId);

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportDestinations
        WHERE destination = @Destination
          AND status = N'Claimed'
          AND leaseExpiresOn > @Now
    )
    BEGIN
        SELECT TOP (1) @ClaimedExportDestinationId = destination.id
        FROM dbo.ConsolidatedSales_ExportDestinations destination WITH (UPDLOCK, READPAST, ROWLOCK)
        INNER JOIN dbo.ConsolidatedSales_ExportRuns run ON run.id = destination.exportRunId
        WHERE destination.destination = @Destination
          AND run.status = N'Extracted'
          AND destination.retryCycleAttemptCount < @MaximumRetryCount
          AND (@ExportDestinationId IS NULL OR destination.id = @ExportDestinationId)
          AND
          (
              destination.status = N'Pending'
              OR (destination.status = N'Retry' AND COALESCE(destination.nextAttemptOn, @Now) <= @Now)
              OR (destination.status = N'Claimed' AND destination.leaseExpiresOn <= @Now)
          )
        ORDER BY run.scheduledFor, destination.createdOn;
    END;

    IF @ClaimedExportDestinationId IS NOT NULL
    BEGIN
        UPDATE attempt
        SET
            status = N'Failed',
            errorCategory = N'LeaseExpired',
            errorMessage = N'The delivery lease expired before completion.',
            completedOn = @Now
        FROM dbo.ConsolidatedSales_ExportDeliveryAttempts attempt
        INNER JOIN dbo.ConsolidatedSales_ExportDestinations destination
            ON destination.id = attempt.exportDestinationId
        WHERE destination.id = @ClaimedExportDestinationId
          AND destination.status = N'Claimed'
          AND attempt.status = N'Started';

        UPDATE dbo.ConsolidatedSales_ExportDestinations
        SET
            status = N'Claimed',
            attemptCount = attemptCount + 1,
            retryCycleAttemptCount = retryCycleAttemptCount + 1,
            nextAttemptOn = NULL,
            claimToken = @ClaimToken,
            leaseOwner = @LeaseOwner,
            leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
            lastErrorCategory = NULL,
            lastErrorMessage = NULL,
            updatedOn = @Now
        WHERE id = @ClaimedExportDestinationId;

        INSERT dbo.ConsolidatedSales_ExportDeliveryAttempts
        (
            exportDestinationId, attemptNumber, claimToken, status, startedOn
        )
        SELECT id, attemptCount, @ClaimToken, N'Started', @Now
        FROM dbo.ConsolidatedSales_ExportDestinations
        WHERE id = @ClaimedExportDestinationId;
    END;

    COMMIT TRANSACTION;

    SELECT
        destination.id,
        destination.exportRunId,
        run.logicalRunKey,
        run.correlationId,
        run.exportYear,
        run.extractedRowCount,
        destination.destination,
        destination.status,
        destination.attemptCount,
        destination.retryCycleAttemptCount,
        destination.nextAttemptOn,
        destination.claimToken,
        destination.leaseOwner,
        destination.leaseExpiresOn,
        destination.fileName,
        destination.filePath,
        destination.contentHash,
        destination.fileRowCount,
        destination.fileByteCount,
        destination.externalExecutionId,
        destination.lastErrorCategory,
        destination.lastErrorMessage,
        destination.createdOn,
        destination.updatedOn,
        destination.completedOn
    FROM dbo.ConsolidatedSales_ExportDestinations destination
    INNER JOIN dbo.ConsolidatedSales_ExportRuns run ON run.id = destination.exportRunId
    WHERE destination.id = @ClaimedExportDestinationId;
END;
