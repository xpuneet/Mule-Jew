/*
Procedure:
  [dbo].[CompleteConsolidatedSalesExportExtraction]

Purpose:
  Publishes a fully persisted Salesforce snapshot and releases both destinations for processing.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @ExportRunId      Export run identifier. Required.
  @ClaimToken       Current extraction claim token. Required.
  @ExpectedPageCount Expected number of persisted Salesforce pages. Required.
  @ExpectedRowCount Expected number of persisted rows. Required.
  @QueryHash        SHA-256 hash of the executed SOQL contract. Required.
  @Now              UTC completion time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Completion is accepted once for the current extraction claim.

Notes:
  Page and row counts and their one-based sequences are validated before destinations are unblocked.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CompleteConsolidatedSalesExportExtraction]
    @ExportRunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ExpectedPageCount int,
    @ExpectedRowCount bigint,
    @QueryHash binary(32),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @ExpectedPageCount <= 0
        THROW 51000, 'Expected page count must be greater than zero.', 1;

    IF @ExpectedRowCount < 0
        THROW 51000, 'Expected row count cannot be negative.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    BEGIN TRANSACTION;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportRuns WITH (UPDLOCK, HOLDLOCK)
        WHERE id = @ExportRunId
          AND status = N'Extracting'
          AND claimToken = @ClaimToken
          AND leaseExpiresOn > @Now
    )
        THROW 51000, 'The export run is not held by the supplied claim token.', 1;

    IF
    (
        SELECT COUNT(*)
        FROM dbo.ConsolidatedSales_ExportPages
        WHERE exportRunId = @ExportRunId
    ) <> @ExpectedPageCount
       OR
    (
        SELECT MIN(pageNumber)
        FROM dbo.ConsolidatedSales_ExportPages
        WHERE exportRunId = @ExportRunId
    ) <> 1
       OR
    (
        SELECT MAX(pageNumber)
        FROM dbo.ConsolidatedSales_ExportPages
        WHERE exportRunId = @ExportRunId
    ) <> @ExpectedPageCount
        THROW 51000, 'The persisted Salesforce page sequence is incomplete.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportPages
        WHERE exportRunId = @ExportRunId
          AND ((pageNumber < @ExpectedPageCount AND hasMore = 0)
               OR (pageNumber = @ExpectedPageCount AND hasMore = 1))
    )
        THROW 51000, 'The persisted Salesforce continuation metadata is inconsistent.', 1;

    IF
    (
        SELECT COUNT_BIG(*)
        FROM dbo.ConsolidatedSales_ExportRows
        WHERE exportRunId = @ExportRunId
    ) <> @ExpectedRowCount
        THROW 51000, 'The persisted Salesforce row count is incomplete.', 1;

    IF @ExpectedRowCount > 0
       AND
       (
           (SELECT MIN(rowSequence) FROM dbo.ConsolidatedSales_ExportRows WHERE exportRunId = @ExportRunId) <> 1
           OR
           (SELECT MAX(rowSequence) FROM dbo.ConsolidatedSales_ExportRows WHERE exportRunId = @ExportRunId) <> @ExpectedRowCount
       )
        THROW 51000, 'The persisted Salesforce row sequence is incomplete.', 1;

    UPDATE dbo.ConsolidatedSales_ExportRuns
    SET
        status = N'Extracted',
        extractedPageCount = @ExpectedPageCount,
        extractedRowCount = @ExpectedRowCount,
        queryHash = @QueryHash,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        nextAttemptOn = NULL,
        extractionCompletedOn = @Now,
        failedOn = NULL,
        updatedOn = @Now
    WHERE id = @ExportRunId;

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET status = N'Pending', nextAttemptOn = @Now, updatedOn = @Now
    WHERE exportRunId = @ExportRunId AND status = N'Blocked';

    IF @@ROWCOUNT <> 2
        THROW 51000, 'Both export destinations were not available to release.', 1;

    COMMIT TRANSACTION;
END;
