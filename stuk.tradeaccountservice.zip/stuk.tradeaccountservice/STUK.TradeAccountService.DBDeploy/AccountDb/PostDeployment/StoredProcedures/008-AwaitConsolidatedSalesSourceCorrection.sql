/*
Procedure:
  [dbo].[AwaitConsolidatedSalesSourceCorrection]

Purpose:
  Records an unparseable Blob version and prevents automatic retry until the Blob is edited or replaced.

Used by:
  Consolidated Sales ingestion persistence implementation.

Parameters:
  @SourceItemId       Source-item identifier. Required.
  @ClaimToken         Token returned by the claim procedure. Required.
  @ErrorCategory      Classified parsing error. Required.
  @ErrorMessage       Safe parsing error description. Required.
  @Now                UTC failure time. Defaults to current UTC time.

Returns:
  The resulting status and retry count.

Idempotency:
  Only the current claim token can record the correction state once.

Notes:
  The registered Blob last-modified time prevents the same unchanged bad version from being claimed again.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[AwaitConsolidatedSalesSourceCorrection]
    @SourceItemId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ErrorCategory nvarchar(100),
    @ErrorMessage nvarchar(2000),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_SourceItems
    SET
        retryCount = retryCount + 1,
        status = N'AwaitingCorrection',
        nextAttemptOn = NULL,
        failedOn = @Now,
        lastErrorCategory = @ErrorCategory,
        lastErrorMessage = @ErrorMessage,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        updatedOn = @Now
    WHERE id = @SourceItemId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The source item is not held by the supplied claim token.', 1;

    SELECT status, retryCount, nextAttemptOn
    FROM dbo.ConsolidatedSales_SourceItems
    WHERE id = @SourceItemId;
END;
