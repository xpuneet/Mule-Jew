/*
Procedure:
  [dbo].[CompleteConsolidatedSalesforceLine]

Purpose:
  Records successful Salesforce OrderItem delivery for one canonical line.

Used by:
  Consolidated Sales Salesforce synchronisation persistence implementation.

Parameters:
  @SalesforceWorkId       Salesforce work identifier. Required.
  @ClaimToken             Current invoice-work claim token. Required.
  @ExternalId             Deterministic Salesforce OrderItem external identifier. Required.
  @SalesforceProductId    Resolved Salesforce Product2 identifier. Required.
  @SalesforcePricebookEntryId Resolved Salesforce PricebookEntry identifier. Required.
  @SalesforceOrderItemId  Salesforce OrderItem identifier. Required.
  @Now                    UTC completion time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Idempotent by the deterministic external identifier.

Notes:
  The parent invoice work must be actively claimed by the caller.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CompleteConsolidatedSalesforceLine]
    @SalesforceWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ExternalId nvarchar(255),
    @SalesforceProductId nvarchar(50),
    @SalesforcePricebookEntryId nvarchar(50),
    @SalesforceOrderItemId nvarchar(50),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork
        WHERE id = @SalesforceWorkId
          AND status = N'Claimed'
          AND claimToken = @ClaimToken
    )
        THROW 51000, 'The Salesforce work is not held by the supplied claim token.', 1;

    UPDATE dbo.ConsolidatedSales_SalesforceLineState
    SET
        status = N'Completed',
        salesforceProductId = @SalesforceProductId,
        salesforcePricebookEntryId = @SalesforcePricebookEntryId,
        salesforceOrderItemId = @SalesforceOrderItemId,
        lastErrorMessage = NULL,
        updatedOn = @Now
    WHERE salesforceWorkId = @SalesforceWorkId
      AND externalId = @ExternalId;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The Salesforce line external identifier was not found.', 1;
END;
