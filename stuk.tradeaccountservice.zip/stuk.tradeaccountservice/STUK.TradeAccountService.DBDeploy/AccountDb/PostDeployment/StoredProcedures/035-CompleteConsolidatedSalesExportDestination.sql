/*
Procedure:
  [dbo].[CompleteConsolidatedSalesExportDestination]

Purpose:
  Records successful completion and file evidence for one export destination.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @ExportDestinationId Destination work identifier. Required.
  @ClaimToken           Current claim token. Required.
  @FileName             Delivered file name. Required.
  @FilePath             Destination or staging path. Required.
  @ContentHash          Generated-file content hash. Required.
  @FileRowCount         Delivered data-row count. Required.
  @FileByteCount        Delivered byte count. Required.
  @ExternalExecutionId  Synapse/platform execution identifier when applicable.
  @Now                  UTC completion time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Only the current claim token can complete the destination once.

Notes:
  The corresponding append-only attempt record is completed in the same transaction.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CompleteConsolidatedSalesExportDestination]
    @ExportDestinationId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @FileName nvarchar(510),
    @FilePath nvarchar(1000),
    @ContentHash nvarchar(128),
    @FileRowCount bigint,
    @FileByteCount bigint,
    @ExternalExecutionId nvarchar(255) = NULL,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NULLIF(LTRIM(RTRIM(@FileName)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@FilePath)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@ContentHash)), N'') IS NULL
        THROW 51000, 'File name, path and content hash are required.', 1;

    IF @FileRowCount < 0 OR @FileByteCount < 0
        THROW 51000, 'File row and byte counts cannot be negative.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    BEGIN TRANSACTION;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportDestinations destination
        INNER JOIN dbo.ConsolidatedSales_ExportRuns run ON run.id = destination.exportRunId
        WHERE destination.id = @ExportDestinationId
          AND destination.status = N'Claimed'
          AND destination.claimToken = @ClaimToken
          AND run.status = N'Extracted'
          AND run.extractedRowCount = @FileRowCount
    )
        THROW 51000, 'The delivered row count does not match the completed export snapshot.', 1;

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET
        status = N'Completed',
        fileName = @FileName,
        filePath = @FilePath,
        contentHash = @ContentHash,
        fileRowCount = @FileRowCount,
        fileByteCount = @FileByteCount,
        externalExecutionId = @ExternalExecutionId,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        nextAttemptOn = NULL,
        completedOn = @Now,
        updatedOn = @Now
    WHERE id = @ExportDestinationId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The destination is not held by the supplied claim token.', 1;

    UPDATE dbo.ConsolidatedSales_ExportDeliveryAttempts
    SET status = N'Completed', externalExecutionId = @ExternalExecutionId, completedOn = @Now
    WHERE exportDestinationId = @ExportDestinationId
      AND claimToken = @ClaimToken
      AND status = N'Started';

    IF @@ROWCOUNT <> 1
        THROW 51000, 'The active destination attempt was not found.', 1;

    COMMIT TRANSACTION;
END;
