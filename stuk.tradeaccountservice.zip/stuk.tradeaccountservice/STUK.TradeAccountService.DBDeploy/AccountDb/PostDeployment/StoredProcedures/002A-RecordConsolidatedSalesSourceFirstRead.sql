/*
Procedure:
  [dbo].[RecordConsolidatedSalesSourceFirstRead]

Purpose:
  Records the immutable UTC time at which Trade Account first successfully read the complete
  content of a claimed HX source file.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesFileDataService

Parameters:
  @SourceItemId       Claimed source-item identifier. Required.
  @ClaimToken         Token proving ownership of the current source claim. Required.
  @Now                UTC read-completion time. Defaults to the database UTC time.

Returns:
  The durable firstReadOn timestamp.

Idempotency:
  Idempotent by source item. Repeated calls retain and return the original firstReadOn value.

Notes:
  The caller invokes this only after the complete Blob content has been copied into the ingestion
  stream. The timestamp is the start of the fallback Salesforce cool-off and is not evidence that
  Columbus has completed PDF generation.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[RecordConsolidatedSalesSourceFirstRead]
    @SourceItemId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF DATEPART(TZOFFSET, @Now) <> 0
        THROW 51000, 'Source first-read time must be UTC.', 1;

    UPDATE dbo.ConsolidatedSales_SourceItems
    SET
        firstReadOn = COALESCE(firstReadOn, @Now),
        updatedOn = @Now
    WHERE id = @SourceItemId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT <> 1
        THROW 51000, 'The source item is not held by the supplied claim token.', 1;

    SELECT firstReadOn
    FROM dbo.ConsolidatedSales_SourceItems
    WHERE id = @SourceItemId;
END;
