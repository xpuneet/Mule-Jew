/*
Procedure:
  [dbo].[ClaimNextConsolidatedSalesExportRun]

Purpose:
  Atomically claims the next eligible Salesforce export run and starts a clean extraction attempt.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @LeaseOwner           Worker instance identifier. Required.
  @LeaseDurationSeconds Processing lease duration. Required.
  @ExportRunId          Optional run restriction used by controlled recovery and contract testing.
  @Now                  UTC claim time. Defaults to current UTC time.
  @MaximumRetryCount    Maximum permitted extraction attempts. Defaults to 5 for deployment compatibility.

Returns:
  The claimed export run, or no row when no run is eligible.

Idempotency:
  Not idempotent. A successful claim creates a new claim token and increments the attempt count.

Notes:
  Staged rows from an interrupted attempt are removed before the run is reclaimed. They were never
  a completed snapshot and cannot be combined with a later Salesforce query. An expired claim is
  terminally failed when no permitted extraction attempt remains.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[ClaimNextConsolidatedSalesExportRun]
    @LeaseOwner nvarchar(200),
    @LeaseDurationSeconds int,
    @ExportRunId uniqueidentifier = NULL,
    @Now datetimeoffset(7) = NULL,
    @MaximumRetryCount int = 5
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NULLIF(LTRIM(RTRIM(@LeaseOwner)), N'') IS NULL
        THROW 51000, 'Lease owner is required.', 1;

    IF @LeaseDurationSeconds <= 0
        THROW 51000, 'Lease duration must be greater than zero.', 1;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    DECLARE @ClaimedExportRunId uniqueidentifier;
    DECLARE @ClaimToken uniqueidentifier = NEWID();

    BEGIN TRANSACTION;

    UPDATE dbo.ConsolidatedSales_ExportRuns
    SET
        status = N'TerminallyFailed',
        nextAttemptOn = NULL,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = N'LeaseExpired',
        lastErrorMessage = N'The Salesforce extraction lease expired after the maximum permitted attempts.',
        failedOn = @Now,
        updatedOn = @Now
    WHERE status = N'Extracting'
      AND leaseExpiresOn <= @Now
      AND extractionAttemptCount >= @MaximumRetryCount
      AND (@ExportRunId IS NULL OR id = @ExportRunId);

    SELECT TOP (1) @ClaimedExportRunId = id
    FROM dbo.ConsolidatedSales_ExportRuns WITH (UPDLOCK, READPAST, ROWLOCK)
    WHERE
        (
            status = N'Pending'
            OR (status = N'Retry' AND COALESCE(nextAttemptOn, @Now) <= @Now)
            OR (status = N'Extracting' AND leaseExpiresOn <= @Now)
        )
        AND extractionAttemptCount < @MaximumRetryCount
        AND scheduledFor <= @Now
        AND (@ExportRunId IS NULL OR id = @ExportRunId)
    ORDER BY scheduledFor, createdOn;

    IF @ClaimedExportRunId IS NOT NULL
    BEGIN
        DELETE FROM dbo.ConsolidatedSales_ExportPages
        WHERE exportRunId = @ClaimedExportRunId;

        UPDATE dbo.ConsolidatedSales_ExportRuns
        SET
            status = N'Extracting',
            extractionAttemptCount = extractionAttemptCount + 1,
            extractedPageCount = NULL,
            extractedRowCount = NULL,
            queryHash = NULL,
            nextAttemptOn = NULL,
            claimToken = @ClaimToken,
            leaseOwner = @LeaseOwner,
            leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
            lastErrorCategory = NULL,
            lastErrorMessage = NULL,
            extractionStartedOn = @Now,
            extractionCompletedOn = NULL,
            failedOn = NULL,
            updatedOn = @Now
        WHERE id = @ClaimedExportRunId;
    END;

    COMMIT TRANSACTION;

    SELECT
        id, logicalRunKey, correlationId, exportYear, extractFromDate, scheduledFor,
        status, extractionAttemptCount, extractedPageCount, extractedRowCount,
        nextAttemptOn, claimToken, leaseOwner, leaseExpiresOn,
        lastErrorCategory, lastErrorMessage, createdOn, extractionStartedOn,
        extractionCompletedOn, failedOn, updatedOn,
        CONVERT(bit, 0) AS isNew
    FROM dbo.ConsolidatedSales_ExportRuns
    WHERE id = @ClaimedExportRunId;
END;
