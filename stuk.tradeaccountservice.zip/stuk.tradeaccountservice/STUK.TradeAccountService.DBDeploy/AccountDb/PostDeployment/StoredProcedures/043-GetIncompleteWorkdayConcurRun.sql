/*
Procedure:
  dbo.GetIncompleteWorkdayConcurRun

Purpose:
  Returns the single open Workday-to-Concur run for support and recovery inspection.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  None.

Returns:
  The open run, or no row when none exists.

Idempotency:
  Read-only and idempotent.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.GetIncompleteWorkdayConcurRun
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        runId, correlationId, extractFrom, extractThrough, status, currentStage,
        fileStateJson, tm1SynapseRunId, transformSynapseRunId, deliverySynapseRunId,
        housekeepingSynapseRunId, retryCount, lastErrorCategory, lastErrorMessage,
        claimToken, leaseOwner, leaseExpiresOn, createdOn, updatedOn, closedOn,
        CONVERT(bit, 0) AS isNew
    FROM dbo.WorkdayConcurRun
    WHERE integrationName = N'WorkdayConcur'
      AND closedOn IS NULL;
END;
