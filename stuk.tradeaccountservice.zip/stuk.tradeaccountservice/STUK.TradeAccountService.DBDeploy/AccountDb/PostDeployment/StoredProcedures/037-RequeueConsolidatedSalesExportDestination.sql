/*
Procedure:
  [dbo].[RequeueConsolidatedSalesExportDestination]

Purpose:
  Performs a controlled replay of a terminally failed export destination.

Used by:
  Approved operational support process through ConsolidatedSalesExportDataService.

Parameters:
  @ExportDestinationId Destination work identifier. Required.
  @Reason               Approved replay reason. Required.
  @Now                  UTC replay time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Only terminally failed work can be requeued; a repeated call is rejected.

Notes:
  The immutable Salesforce snapshot, lifetime attempt count and attempt audit are retained. Only
  the selected destination's retry-cycle budget is reset; the other destination is not changed.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[RequeueConsolidatedSalesExportDestination]
    @ExportDestinationId uniqueidentifier,
    @Reason nvarchar(2000),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF NULLIF(LTRIM(RTRIM(@Reason)), N'') IS NULL
        THROW 51000, 'A replay reason is required.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_ExportDestinations
    SET
        status = N'Pending',
        retryCycleAttemptCount = 0,
        nextAttemptOn = @Now,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        fileName = NULL,
        filePath = NULL,
        contentHash = NULL,
        fileRowCount = NULL,
        fileByteCount = NULL,
        externalExecutionId = NULL,
        lastErrorCategory = N'ManualReplay',
        lastErrorMessage = @Reason,
        completedOn = NULL,
        updatedOn = @Now
    WHERE id = @ExportDestinationId
      AND status = N'TerminallyFailed';

    IF @@ROWCOUNT = 0
        THROW 51000, 'The destination is not terminally failed.', 1;
END;
