/*
Procedure:
  [dbo].[RegisterConsolidatedSalesSourceItem]

Purpose:
  Registers one durable source item for each Blob path and last-modified version.

Used by:
  Consolidated Sales ingestion persistence implementation.

Parameters:
  @CorrelationId     Correlation identifier propagated through processing.
  @SourceSystem      Source system name. Required.
  @BlobContainer     Blob container name. Required.
  @BlobPath          Full path within the container. Required.
  @SourceFileName    Original source file name. Required.
  @ContentLength     Blob content length. Required.
  @BlobLastModifiedOn Blob last-modified time. Required.
  @ContentChecksum   Immutable checksum when available.
  @ETag              Blob ETag identifying the exact source version. Required.

Returns:
  The registered source-item row and an IsNew flag.

Idempotency:
  Idempotent by source system, Blob identity and last-modified time.

Notes:
  An edited or replaced Blob is treated as a new version when its last-modified time changes.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[RegisterConsolidatedSalesSourceItem]
    @CorrelationId uniqueidentifier,
    @SourceSystem nvarchar(50),
    @BlobContainer nvarchar(255),
    @BlobPath nvarchar(1000),
    @SourceFileName nvarchar(510),
    @ContentLength bigint,
    @BlobLastModifiedOn datetimeoffset(7),
    @ETag nvarchar(255),
    @ContentChecksum nvarchar(128) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SourceItemId uniqueidentifier;
    DECLARE @IsNew bit = 0;

    IF NULLIF(LTRIM(RTRIM(@ETag)), N'') IS NULL
        THROW 51000, 'ETag is required.', 1;

    DECLARE @BlobIdentityHash binary(32) = HASHBYTES
    (
        'SHA2_256',
        CONVERT(varbinary(max), CONCAT(@SourceSystem, N'|', @BlobContainer, N'|', @BlobPath))
    );

    BEGIN TRANSACTION;

    SELECT @SourceItemId = id
    FROM dbo.ConsolidatedSales_SourceItems WITH (UPDLOCK, HOLDLOCK)
    WHERE blobIdentityHash = @BlobIdentityHash
      AND sourceSystem = @SourceSystem
      AND blobContainer = @BlobContainer
      AND blobPath = @BlobPath
      AND blobLastModifiedOn = @BlobLastModifiedOn;

    IF @SourceItemId IS NULL
    BEGIN
        SET @SourceItemId = NEWID();
        SET @IsNew = 1;

        INSERT dbo.ConsolidatedSales_SourceItems
        (
            id,
            correlationId,
            sourceSystem,
            blobContainer,
            blobPath,
            blobIdentityHash,
            sourceFileName,
            contentLength,
            blobLastModifiedOn,
            contentChecksum,
            eTag,
            status
        )
        VALUES
        (
            @SourceItemId,
            @CorrelationId,
            @SourceSystem,
            @BlobContainer,
            @BlobPath,
            @BlobIdentityHash,
            @SourceFileName,
            @ContentLength,
            @BlobLastModifiedOn,
            @ContentChecksum,
            @ETag,
            N'Ready'
        );
    END;

    COMMIT TRANSACTION;

    SELECT
        id,
        correlationId,
        sourceSystem,
        blobContainer,
        blobPath,
        sourceFileName,
        contentLength,
        blobLastModifiedOn,
        contentChecksum,
        eTag,
        status,
        retryCount,
        sanitisationUsed,
        discoveredOn,
        completedOn,
        @IsNew AS isNew
    FROM dbo.ConsolidatedSales_SourceItems
    WHERE id = @SourceItemId;
END;
