/*
Procedure:
  [dbo].[CompleteConsolidatedSalesSourceItem]

Purpose:
  Marks a claimed source item as successfully ingested.

Used by:
  Consolidated Sales ingestion persistence implementation.

Parameters:
  @SourceItemId       Source-item identifier. Required.
  @ClaimToken         Token returned by the claim procedure. Required.
  @SanitisationUsed   Whether sanitisation fallback was required.
  @Now                UTC completion time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Repeating completion for an already completed item succeeds without changing business data.

Notes:
  A non-completed row can only be changed by the current claim owner.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CompleteConsolidatedSalesSourceItem]
    @SourceItemId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @SanitisationUsed bit,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SourceItems
        WHERE id = @SourceItemId AND status = N'Completed'
    )
        RETURN;

    UPDATE dbo.ConsolidatedSales_SourceItems
    SET
        status = N'Completed',
        sanitisationUsed = @SanitisationUsed,
        completedOn = @Now,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = NULL,
        lastErrorMessage = NULL,
        updatedOn = @Now
    WHERE id = @SourceItemId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The source item is not held by the supplied claim token.', 1;
END;
