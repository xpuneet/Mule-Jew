/*
Procedure:
  dbo.FailWorkdayConcurRun

Purpose:
  Records a recoverable Workday-to-Concur failure at the current stage and releases its lease.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  @RunId        Run identifier. Required.
  @ClaimToken   Active claim token. Required.
  @ErrorCategory Stable failure category. Required.
  @ErrorMessage Failure description. Required.
  @Now          UTC operation time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Not idempotent after the lease is released; a stale caller cannot overwrite newer state.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.FailWorkdayConcurRun
    @RunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ErrorCategory nvarchar(100),
    @ErrorMessage nvarchar(2000),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NULLIF(LTRIM(RTRIM(@ErrorCategory)), N'') IS NULL THROW 51000, 'Error category is required.', 1;
    IF NULLIF(LTRIM(RTRIM(@ErrorMessage)), N'') IS NULL THROW 51000, 'Error message is required.', 1;
    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.WorkdayConcurRun
    SET status = N'Failed',
        lastErrorCategory = @ErrorCategory,
        lastErrorMessage = @ErrorMessage,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        updatedOn = @Now
    WHERE runId = @RunId
      AND claimToken = @ClaimToken
      AND closedOn IS NULL
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT <> 1 THROW 51000, 'The Workday-to-Concur run is no longer owned by this invocation.', 1;
END;
