/*
Procedure:
  [dbo].[RequeueConsolidatedSalesWork]

Purpose:
  Performs a controlled operational requeue of terminally failed Consolidated Sales work.

Used by:
  Approved database support process.

Parameters:
  @WorkType      SourceItem, Salesforce or Reconciliation. Required.
  @WorkId        Work-row identifier. Required.
  @Reason        Support reason for the requeue. Required.
  @Now           UTC requeue time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Only a terminally failed row can be requeued; repeated calls require a new terminal failure.

Notes:
  This procedure is intentionally not exposed as a public or manual-trigger API.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[RequeueConsolidatedSalesWork]
    @WorkType nvarchar(30),
    @WorkId uniqueidentifier,
    @Reason nvarchar(2000),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());
    DECLARE @RowsChanged int = 0;

    IF @WorkType = N'SourceItem'
    BEGIN
        UPDATE dbo.ConsolidatedSales_SourceItems
        SET
            status = N'Retry',
            retryCount = 0,
            nextAttemptOn = @Now,
            lastErrorCategory = N'ManualRequeue',
            lastErrorMessage = @Reason,
            failedOn = NULL,
            updatedOn = @Now
        WHERE id = @WorkId
          AND status = N'TerminallyFailed';

        SET @RowsChanged = @@ROWCOUNT;
    END;
    ELSE IF @WorkType = N'Salesforce'
    BEGIN
        UPDATE dbo.ConsolidatedSales_SalesforceWork
        SET
            status = N'Retry',
            attemptCount = 0,
            nextAttemptOn = @Now,
            lastErrorCategory = N'ManualRequeue',
            lastErrorMessage = @Reason,
            updatedOn = @Now
        WHERE id = @WorkId
          AND status = N'TerminallyFailed';

        SET @RowsChanged = @@ROWCOUNT;
    END;
    ELSE IF @WorkType = N'Reconciliation'
    BEGIN
        UPDATE dbo.ConsolidatedSales_ReconciliationWork
        SET
            status = N'Retry',
            attemptCount = 0,
            nextAttemptOn = @Now,
            lastErrorCategory = N'ManualRequeue',
            lastErrorMessage = @Reason,
            updatedOn = @Now
        WHERE id = @WorkId
          AND status = N'TerminallyFailed';

        SET @RowsChanged = @@ROWCOUNT;
    END;
    ELSE
        THROW 51000, 'WorkType must be SourceItem, Salesforce or Reconciliation.', 1;

    IF @RowsChanged = 0
        THROW 51000, 'The requested work row is not terminally failed or does not exist.', 1;
END;
