/*
Procedure:
  dbo.UpdateWorkdayConcurRunStage

Purpose:
  Persists an allowed Workday-to-Concur stage transition and its external run or file checkpoint.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  @RunId                    Run identifier. Required.
  @ClaimToken               Active claim token. Required.
  @ExpectedStage            Persisted stage expected by the caller. Required.
  @NewStage                 Stage to persist. Required.
  @FileStateJson            Optional file identity and state JSON.
  @Tm1SynapseRunId          Optional TM1 collection run identifier.
  @TransformSynapseRunId    Optional transformation run identifier.
  @DeliverySynapseRunId     Optional delivery run identifier.
  @HousekeepingSynapseRunId Optional housekeeping run identifier.
  @Now                      UTC operation time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  A same-stage update is permitted so an external run identifier can be checkpointed safely.

Notes:
  Completion and no-data closure use dedicated procedures because they have different watermark semantics.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.UpdateWorkdayConcurRunStage
    @RunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ExpectedStage nvarchar(32),
    @NewStage nvarchar(32),
    @FileStateJson nvarchar(max) = NULL,
    @Tm1SynapseRunId nvarchar(100) = NULL,
    @TransformSynapseRunId nvarchar(100) = NULL,
    @DeliverySynapseRunId nvarchar(100) = NULL,
    @HousekeepingSynapseRunId nvarchar(100) = NULL,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @FileStateJson IS NOT NULL AND ISJSON(@FileStateJson) <> 1
        THROW 51000, 'File state must be valid JSON.', 1;

    IF NOT
    (
        @NewStage = @ExpectedStage
        OR (@ExpectedStage = N'Pending' AND @NewStage = N'CollectingInputs')
        OR (@ExpectedStage = N'CollectingInputs' AND @NewStage = N'Transforming')
        OR (@ExpectedStage = N'Transforming' AND @NewStage = N'Delivering')
        OR (@ExpectedStage = N'Delivering' AND @NewStage = N'MovingFiles')
    )
        THROW 51000, 'The requested Workday-to-Concur stage transition is not permitted.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.WorkdayConcurRun
    SET currentStage = @NewStage,
        status = N'Active',
        fileStateJson = COALESCE(@FileStateJson, fileStateJson),
        tm1SynapseRunId = COALESCE(@Tm1SynapseRunId, tm1SynapseRunId),
        transformSynapseRunId = COALESCE(@TransformSynapseRunId, transformSynapseRunId),
        deliverySynapseRunId = COALESCE(@DeliverySynapseRunId, deliverySynapseRunId),
        housekeepingSynapseRunId = COALESCE(@HousekeepingSynapseRunId, housekeepingSynapseRunId),
        lastErrorCategory = NULL,
        lastErrorMessage = NULL,
        updatedOn = @Now
    WHERE runId = @RunId
      AND claimToken = @ClaimToken
      AND currentStage = @ExpectedStage
      AND closedOn IS NULL
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT <> 1 THROW 51000, 'The run stage or active lease no longer matches the requested update.', 1;
END;
