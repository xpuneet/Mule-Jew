/*
Target database:
  TradeAccountServiceDb (keyed executor AccountDb).

Procedure:
  [dbo].[CompleteConsolidatedSalesReconciliationWork]

Purpose:
  Completes one claimed reconciliation work item after the matching invoice header has been updated in OrderServiceDb.

Used by:
  InvoiceReconciliationDataService.

Parameters:
  @ReconciliationWorkId   Reconciliation work identifier. Required.
  @ClaimToken              Current claim token. Required.
  @MatchedInvoiceHeaderId  Identifier returned by OrderServiceDb. Required.
  @Now                     UTC completion time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Repeating completion for the same work item and matched invoice identifier is safe.

Notes:
  Existing invoice data is not stored in this database. The OrderServiceDb update is deliberately completed first and is idempotent, allowing safe recovery between the two database operations.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CompleteConsolidatedSalesReconciliationWork]
    @ReconciliationWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @MatchedInvoiceHeaderId uniqueidentifier,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_ReconciliationWork
    SET
        status = N'Completed',
        matchedInvoiceHeaderId = @MatchedInvoiceHeaderId,
        completedOn = @Now,
        nextAttemptOn = NULL,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = NULL,
        lastErrorMessage = NULL,
        updatedOn = @Now
    WHERE id = @ReconciliationWorkId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 1
        RETURN;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ReconciliationWork
        WHERE id = @ReconciliationWorkId
          AND status = N'Completed'
          AND matchedInvoiceHeaderId = @MatchedInvoiceHeaderId
    )
        RETURN;

    THROW 51000, 'The reconciliation work is not held by the supplied claim token.', 1;
END;
