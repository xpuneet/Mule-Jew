/*
Procedure:
  [dbo].[AppendConsolidatedSalesExportPage]

Purpose:
  Atomically persists one Salesforce result page and its ordered ConsXref rows.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @ExportRunId     Export run identifier. Required.
  @ClaimToken      Current extraction claim token. Required.
  @PageNumber      One-based page number. Required.
  @FirstRowSequence One-based sequence assigned to the first row in the page. Required.
  @PageHash        SHA-256 hash of the canonical page content. Required.
  @HasMore         Whether Salesforce reported a following page. Required.
  @RowsJson        JSON array containing the nine export fields. Required; an empty array is valid.
  @Now             UTC persistence time. Defaults to current UTC time.

Returns:
  The persisted page metadata and an isNew flag.

Idempotency:
  Idempotent by ExportRunId and PageNumber when PageHash and page metadata are unchanged.

Notes:
  A different replay for an existing page number is rejected so a snapshot cannot silently mutate.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[AppendConsolidatedSalesExportPage]
    @ExportRunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @PageNumber int,
    @FirstRowSequence bigint,
    @PageHash binary(32),
    @HasMore bit,
    @RowsJson nvarchar(max),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @PageNumber <= 0
        THROW 51000, 'Page number must be greater than zero.', 1;

    IF @FirstRowSequence <= 0
        THROW 51000, 'First row sequence must be greater than zero.', 1;

    IF ISJSON(@RowsJson) <> 1 OR LEFT(LTRIM(@RowsJson), 1) <> N'['
        THROW 51000, 'RowsJson must be a valid JSON array.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    DECLARE @RowCount int = (SELECT COUNT(*) FROM OPENJSON(@RowsJson));
    DECLARE @ExportPageId uniqueidentifier;
    DECLARE @ExistingHash binary(32);
    DECLARE @ExistingFirstSequence bigint;
    DECLARE @ExistingRowCount int;
    DECLARE @ExistingHasMore bit;
    DECLARE @IsNew bit = 0;

    BEGIN TRANSACTION;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportRuns WITH (UPDLOCK, HOLDLOCK)
        WHERE id = @ExportRunId
          AND status = N'Extracting'
          AND claimToken = @ClaimToken
          AND leaseExpiresOn > @Now
    )
        THROW 51000, 'The export run is not held by the supplied claim token.', 1;

    SELECT
        @ExportPageId = id,
        @ExistingHash = pageHash,
        @ExistingFirstSequence = firstRowSequence,
        @ExistingRowCount = [rowCount],
        @ExistingHasMore = hasMore
    FROM dbo.ConsolidatedSales_ExportPages WITH (UPDLOCK, HOLDLOCK)
    WHERE exportRunId = @ExportRunId AND pageNumber = @PageNumber;

    IF @ExportPageId IS NOT NULL
    BEGIN
        IF @ExistingHash <> @PageHash
           OR @ExistingFirstSequence <> @FirstRowSequence
           OR @ExistingRowCount <> @RowCount
           OR @ExistingHasMore <> @HasMore
            THROW 51000, 'The export page already exists with different content or metadata.', 1;
    END;
    ELSE
    BEGIN
        SET @ExportPageId = NEWID();
        SET @IsNew = 1;

        INSERT dbo.ConsolidatedSales_ExportPages
        (
            id, exportRunId, pageNumber, firstRowSequence, [rowCount], pageHash, hasMore, persistedOn
        )
        VALUES
        (
            @ExportPageId, @ExportRunId, @PageNumber, @FirstRowSequence,
            @RowCount, @PageHash, @HasMore, @Now
        );

        INSERT dbo.ConsolidatedSales_ExportRows
        (
            exportRunId, exportPageId, rowSequence, accountNumber, invoiceNumber,
            invoiceDate, deliveryNoteNumber, deliveryNoteLineNumber, despatchDate,
            productCode, quantity, totalPrice, createdOn
        )
        SELECT
            @ExportRunId,
            @ExportPageId,
            @FirstRowSequence + CONVERT(bigint, source.[key]),
            row.accountNumber,
            row.invoiceNumber,
            row.invoiceDate,
            row.deliveryNoteNumber,
            row.deliveryNoteLineNumber,
            row.despatchDate,
            row.productCode,
            row.quantity,
            row.totalPrice,
            @Now
        FROM OPENJSON(@RowsJson) source
        CROSS APPLY OPENJSON(source.[value])
        WITH
        (
            accountNumber nvarchar(100) '$.AccountNumber',
            invoiceNumber nvarchar(100) '$.InvoiceNumber',
            invoiceDate date '$.InvoiceDate',
            deliveryNoteNumber nvarchar(100) '$.DeliveryNoteNumber',
            deliveryNoteLineNumber nvarchar(50) '$.DeliveryNoteLineNumber',
            despatchDate date '$.DespatchDate',
            productCode nvarchar(100) '$.ProductCode',
            quantity decimal(19, 6) '$.Quantity',
            totalPrice decimal(38, 18) '$.TotalPrice'
        ) row;

        UPDATE dbo.ConsolidatedSales_ExportRuns
        SET updatedOn = @Now
        WHERE id = @ExportRunId;
    END;

    COMMIT TRANSACTION;

    SELECT
        id, exportRunId, pageNumber, firstRowSequence, [rowCount],
        pageHash, hasMore, persistedOn, @IsNew AS isNew
    FROM dbo.ConsolidatedSales_ExportPages
    WHERE id = @ExportPageId;
END;
