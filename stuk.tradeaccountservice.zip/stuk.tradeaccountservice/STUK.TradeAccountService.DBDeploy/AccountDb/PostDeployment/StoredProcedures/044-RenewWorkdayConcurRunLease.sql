/*
Procedure:
  dbo.RenewWorkdayConcurRunLease

Purpose:
  Extends the lease held by the active Workday-to-Concur invocation.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  @RunId                Run identifier. Required.
  @ClaimToken           Active claim token. Required.
  @LeaseDurationSeconds Renewal duration. Required.
  @Now                  UTC operation time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Repeated valid renewals extend the lease from the supplied operation time.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.RenewWorkdayConcurRunLease
    @RunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @LeaseDurationSeconds int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @LeaseDurationSeconds <= 0 THROW 51000, 'Lease duration must be greater than zero.', 1;
    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.WorkdayConcurRun
    SET leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
        updatedOn = @Now
    WHERE runId = @RunId
      AND claimToken = @ClaimToken
      AND closedOn IS NULL
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT <> 1 THROW 51000, 'The Workday-to-Concur run lease is no longer owned by this invocation.', 1;
END;
