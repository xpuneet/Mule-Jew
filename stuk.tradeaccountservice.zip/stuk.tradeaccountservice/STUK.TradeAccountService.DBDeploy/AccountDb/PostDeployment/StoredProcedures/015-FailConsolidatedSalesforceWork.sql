/*
Procedure:
  [dbo].[FailConsolidatedSalesforceWork]

Purpose:
  Records an invoice-level Salesforce failure and schedules retry or terminal failure.

Used by:
  Consolidated Sales Salesforce synchronisation persistence implementation.

Parameters:
  @SalesforceWorkId  Salesforce work identifier. Required.
  @ClaimToken        Current claim token. Required.
  @ErrorCategory     Classified error category. Required.
  @ErrorMessage      Safe error description. Required.
  @NextAttemptOn     Next retry time when retry remains possible.
  @MaximumRetryCount Maximum permitted attempts. Required.
  @Now               UTC failure time. Defaults to current UTC time.

Returns:
  The resulting status and attempt count.

Idempotency:
  Only the current claim token can record the failure once.

Notes:
  The attempt count is incremented by ClaimNext rather than this procedure.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[FailConsolidatedSalesforceWork]
    @SalesforceWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ErrorCategory nvarchar(100),
    @ErrorMessage nvarchar(2000),
    @NextAttemptOn datetimeoffset(7) = NULL,
    @MaximumRetryCount int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_SalesforceWork
    SET
        status = CASE WHEN attemptCount >= @MaximumRetryCount THEN N'TerminallyFailed' ELSE N'Retry' END,
        nextAttemptOn = CASE WHEN attemptCount >= @MaximumRetryCount THEN NULL ELSE @NextAttemptOn END,
        lastErrorCategory = @ErrorCategory,
        lastErrorMessage = @ErrorMessage,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        updatedOn = @Now
    WHERE id = @SalesforceWorkId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The Salesforce work is not held by the supplied claim token.', 1;

    SELECT status, attemptCount, nextAttemptOn
    FROM dbo.ConsolidatedSales_SalesforceWork
    WHERE id = @SalesforceWorkId;
END;
