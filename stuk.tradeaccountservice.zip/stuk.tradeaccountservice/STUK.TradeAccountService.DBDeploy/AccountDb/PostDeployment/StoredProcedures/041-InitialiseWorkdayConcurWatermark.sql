/*
Procedure:
  dbo.InitialiseWorkdayConcurWatermark

Purpose:
  Records the explicitly approved initial Workday extraction boundary before the replacement is enabled.

Used by:
  DBA-controlled Workday-to-Concur deployment.

Parameters:
  @CommittedThrough  Approved initial UTC extraction boundary. Required.
  @Now               UTC operation time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Idempotent only when the supplied boundary exactly matches the existing boundary and no run has completed.

Notes:
  This procedure deliberately refuses to overwrite an established or advanced watermark.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.InitialiseWorkdayConcurWatermark
    @CommittedThrough datetimeoffset(7),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @CommittedThrough IS NULL
        THROW 51000, 'The initial Workday-to-Concur watermark is required.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    BEGIN TRANSACTION;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.WorkdayConcurWatermark WITH (UPDLOCK, HOLDLOCK)
        WHERE integrationName = N'WorkdayConcur'
    )
    BEGIN
        INSERT dbo.WorkdayConcurWatermark(integrationName, committedThrough, completedRunId, updatedOn)
        VALUES (N'WorkdayConcur', @CommittedThrough, NULL, @Now);
    END
    ELSE IF EXISTS
    (
        SELECT 1
        FROM dbo.WorkdayConcurWatermark
        WHERE integrationName = N'WorkdayConcur'
          AND (committedThrough <> @CommittedThrough OR completedRunId IS NOT NULL)
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 51000, 'The Workday-to-Concur watermark is already established and cannot be reinitialised.', 1;
    END;

    COMMIT TRANSACTION;
END;
