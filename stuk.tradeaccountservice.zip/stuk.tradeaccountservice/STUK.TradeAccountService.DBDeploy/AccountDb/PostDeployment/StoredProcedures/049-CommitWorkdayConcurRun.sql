/*
Procedure:
  dbo.CommitWorkdayConcurRun

Purpose:
  Atomically completes a delivered Workday-to-Concur run and advances its committed extraction watermark.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  @RunId      Run identifier. Required.
  @ClaimToken Active claim token. Required.
  @Now        UTC operation time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Repeating completion for the same completed run succeeds without advancing the watermark again.

Notes:
  The existing watermark must equal the frozen lower boundary, preventing gaps or out-of-order commits.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.CommitWorkdayConcurRun
    @RunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    DECLARE @ExtractFrom datetimeoffset(7);
    DECLARE @ExtractThrough datetimeoffset(7);

    BEGIN TRANSACTION;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.WorkdayConcurRun runState WITH (UPDLOCK, HOLDLOCK)
        INNER JOIN dbo.WorkdayConcurWatermark watermark WITH (UPDLOCK, HOLDLOCK)
            ON watermark.integrationName = runState.integrationName
        WHERE runState.runId = @RunId
          AND runState.status = N'Completed'
          AND runState.currentStage = N'Completed'
          AND runState.closedOn IS NOT NULL
          AND watermark.completedRunId = runState.runId
          AND watermark.committedThrough = runState.extractThrough
    )
    BEGIN
        COMMIT TRANSACTION;
        RETURN;
    END;

    SELECT
        @ExtractFrom = extractFrom,
        @ExtractThrough = extractThrough
    FROM dbo.WorkdayConcurRun WITH (UPDLOCK, HOLDLOCK)
    WHERE runId = @RunId
      AND claimToken = @ClaimToken
      AND currentStage = N'MovingFiles'
      AND closedOn IS NULL
      AND leaseExpiresOn > @Now;

    IF @ExtractFrom IS NULL
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 51000, 'The Workday-to-Concur run is not in the claimed final stage.', 1;
    END;

    UPDATE dbo.WorkdayConcurWatermark
    SET committedThrough = @ExtractThrough,
        completedRunId = @RunId,
        updatedOn = @Now
    WHERE integrationName = N'WorkdayConcur'
      AND committedThrough = @ExtractFrom;

    IF @@ROWCOUNT <> 1
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 51000, 'The committed watermark no longer matches the run extraction window.', 1;
    END;

    UPDATE dbo.WorkdayConcurRun
    SET status = N'Completed',
        currentStage = N'Completed',
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = NULL,
        lastErrorMessage = NULL,
        updatedOn = @Now,
        closedOn = @Now
    WHERE runId = @RunId;

    COMMIT TRANSACTION;
END;
