/*
Procedure:
  [dbo].[CommitConsolidatedSalesInvoice]

Purpose:
  Atomically commits one canonical consolidated invoice and creates its independent Salesforce and reconciliation work.

Used by:
  Consolidated Sales ingestion persistence implementation.

Parameters:
  @SourceItemId       Claimed source-item identifier. Required.
  @ClaimToken         Token returned by the source-item claim procedure. Required.
  @InvoiceJson        Canonical invoice JSON containing Parties, Components, Lines and TaxSubTotals. Required.
  @SalesforceCooloffStartedOn Durable UTC time at which Trade Account first read the complete source file. Required.
  @SalesforceCooloffHours Effective configured Salesforce cool-off duration. Zero when disabled.
  @SalesforceEligibleOn Persisted UTC time at which Salesforce work becomes claimable. Required.
  @Now                UTC commit time. Defaults to current UTC time.

Returns:
  The canonical invoice identifier and whether the operation created a new invoice.

Idempotency:
  Repeating the same invoice for the same source item returns the existing invoice.
  A newer source item replaces the existing canonical invoice and requeues its Salesforce and reconciliation work.

Notes:
  Replacement retains the canonical invoice and Salesforce work identifiers so existing audit attempts remain attributable.
  Replacement is rejected while Salesforce or reconciliation work is actively claimed and can be retried after that work finishes.
  The expected JSON members are read explicitly by this procedure and exercised by the checked-in contract test.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CommitConsolidatedSalesInvoice]
    @SourceItemId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @InvoiceJson nvarchar(max),
    @SalesforceCooloffStartedOn datetimeoffset(7),
    @SalesforceCooloffHours int,
    @SalesforceEligibleOn datetimeoffset(7),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF ISJSON(@InvoiceJson) <> 1
        THROW 51000, 'InvoiceJson must contain valid JSON.', 1;

    IF @SalesforceCooloffStartedOn IS NULL
        THROW 51000, 'Salesforce cool-off start time is required.', 1;

    IF @SalesforceCooloffHours IS NULL
        THROW 51000, 'Salesforce cool-off hours are required.', 1;

    IF @SalesforceEligibleOn IS NULL
        THROW 51000, 'Salesforce eligibility time is required.', 1;

    IF @SalesforceCooloffHours < 0
        THROW 51000, 'Salesforce cool-off hours cannot be negative.', 1;

    IF DATEPART(TZOFFSET, @SalesforceCooloffStartedOn) <> 0 OR DATEPART(TZOFFSET, @SalesforceEligibleOn) <> 0
        THROW 51000, 'Salesforce cool-off start and eligibility timestamps must be UTC.', 1;

    IF @SalesforceEligibleOn <> DATEADD(HOUR, @SalesforceCooloffHours, @SalesforceCooloffStartedOn)
        THROW 51000, 'Salesforce eligibility must equal the cool-off start time plus the configured cool-off.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    DECLARE @CorrelationId uniqueidentifier;
    DECLARE @SourceFirstReadOn datetimeoffset(7);
    DECLARE @ConsolidatedInvoiceNumber nvarchar(100) = JSON_VALUE(@InvoiceJson, '$.ConsolidatedInvoiceNumber');
    DECLARE @ExpectedLineCount int = TRY_CONVERT(int, JSON_VALUE(@InvoiceJson, '$.ExpectedLineCount'));
    DECLARE @InvoiceId uniqueidentifier;
    DECLARE @ExistingSourceItemId uniqueidentifier;
    DECLARE @IsNew bit = 0;
    DECLARE @SalesforceWorkId uniqueidentifier;
    DECLARE @SalesforceWorkStatus nvarchar(30);
    DECLARE @ClaimedReconciliationCount int = 0;

    IF NULLIF(LTRIM(RTRIM(@ConsolidatedInvoiceNumber)), N'') IS NULL
        THROW 51000, 'ConsolidatedInvoiceNumber is required.', 1;

    IF @ExpectedLineCount IS NULL OR @ExpectedLineCount < 0
        THROW 51000, 'ExpectedLineCount must be zero or greater.', 1;

    IF @ExpectedLineCount <> (SELECT COUNT(*) FROM OPENJSON(@InvoiceJson, '$.Lines'))
        THROW 51000, 'ExpectedLineCount does not match the supplied canonical lines.', 1;

    SELECT
        @CorrelationId = correlationId,
        @SourceFirstReadOn = firstReadOn
    FROM dbo.ConsolidatedSales_SourceItems
    WHERE id = @SourceItemId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @CorrelationId IS NULL
        THROW 51000, 'The source item is not held by the supplied claim token.', 1;

    IF @SourceFirstReadOn IS NULL OR @SourceFirstReadOn <> @SalesforceCooloffStartedOn
        THROW 51000, 'The Salesforce cool-off start time does not match the durable first source read time.', 1;

    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    SELECT
        @InvoiceId = id,
        @ExistingSourceItemId = sourceItemId
    FROM dbo.ConsolidatedSales_Invoices WITH (UPDLOCK, HOLDLOCK)
    WHERE consolidatedInvoiceNumber = @ConsolidatedInvoiceNumber;

    IF @InvoiceId IS NOT NULL
    BEGIN
        IF @ExistingSourceItemId = @SourceItemId
        BEGIN
            COMMIT TRANSACTION;

            SELECT @InvoiceId AS consolidatedInvoiceId, CAST(0 AS bit) AS isNew;
            RETURN;
        END;

        SELECT
            @SalesforceWorkId = id,
            @SalesforceWorkStatus = status
        FROM dbo.ConsolidatedSales_SalesforceWork WITH (UPDLOCK, HOLDLOCK)
        WHERE consolidatedInvoiceId = @InvoiceId;

        SELECT @ClaimedReconciliationCount = COALESCE(SUM(CASE WHEN status = N'Claimed' THEN 1 ELSE 0 END), 0)
        FROM dbo.ConsolidatedSales_ReconciliationWork WITH (UPDLOCK, HOLDLOCK)
        WHERE consolidatedInvoiceId = @InvoiceId;

        IF @SalesforceWorkStatus = N'Claimed' OR @ClaimedReconciliationCount > 0
            THROW 51000, 'The corrected invoice cannot replace canonical data while related work is actively claimed.', 1;

        DELETE lineState
        FROM dbo.ConsolidatedSales_SalesforceLineState lineState
        WHERE lineState.salesforceWorkId = @SalesforceWorkId;

        DELETE FROM dbo.ConsolidatedSales_ReconciliationWork
        WHERE consolidatedInvoiceId = @InvoiceId;

        DELETE FROM dbo.ConsolidatedSales_TaxSubTotals
        WHERE consolidatedInvoiceId = @InvoiceId;

        DELETE FROM dbo.ConsolidatedSales_InvoiceLines
        WHERE consolidatedInvoiceId = @InvoiceId;

        DELETE FROM dbo.ConsolidatedSales_InvoiceComponents
        WHERE consolidatedInvoiceId = @InvoiceId;

        DELETE FROM dbo.ConsolidatedSales_InvoiceParties
        WHERE consolidatedInvoiceId = @InvoiceId;
    END;

    IF @InvoiceId IS NULL
    BEGIN
        SET @InvoiceId = NEWID();
        SET @IsNew = 1;

        INSERT dbo.ConsolidatedSales_Invoices
        (
        id,
        sourceItemId,
        correlationId,
        consolidatedInvoiceNumber,
        invoiceTypeCode,
        invoiceTypeDescription,
        invoiceDate,
        taxPointDate,
        buyersOrderNumber,
        sourceSuppliersInvoiceNumber,
        deliveryNoteNumber,
        suppliersOrderReference,
        customerAccountCode,
        documentBrandCode,
        documentBrandDescription,
        supplierBranchCode,
        supplierBranchDescription,
        currencyCode,
        currencyDescription,
        creditTermsCode,
        creditTermsDescription,
        expectedLineCount,
        numberOfTaxRates,
        lineValueTotal,
        taxableTotal,
        taxTotal,
        netPaymentTotal,
        grossPaymentTotal,
        createdOn,
        updatedOn
        )
        SELECT
        @InvoiceId,
        @SourceItemId,
        @CorrelationId,
        invoice.ConsolidatedInvoiceNumber,
        invoice.InvoiceTypeCode,
        invoice.InvoiceTypeDescription,
        invoice.InvoiceDate,
        invoice.TaxPointDate,
        invoice.BuyersOrderNumber,
        invoice.SourceSuppliersInvoiceNumber,
        invoice.DeliveryNoteNumber,
        invoice.SuppliersOrderReference,
        invoice.CustomerAccountCode,
        invoice.DocumentBrandCode,
        invoice.DocumentBrandDescription,
        invoice.SupplierBranchCode,
        invoice.SupplierBranchDescription,
        invoice.CurrencyCode,
        invoice.CurrencyDescription,
        invoice.CreditTermsCode,
        invoice.CreditTermsDescription,
        invoice.ExpectedLineCount,
        invoice.NumberOfTaxRates,
        invoice.LineValueTotal,
        invoice.TaxableTotal,
        invoice.TaxTotal,
        invoice.NetPaymentTotal,
        invoice.GrossPaymentTotal,
        @Now,
        @Now
        FROM OPENJSON(@InvoiceJson)
        WITH
        (
        ConsolidatedInvoiceNumber nvarchar(100) '$.ConsolidatedInvoiceNumber',
        InvoiceTypeCode nvarchar(20) '$.InvoiceTypeCode',
        InvoiceTypeDescription nvarchar(100) '$.InvoiceTypeDescription',
        InvoiceDate date '$.InvoiceDate',
        TaxPointDate date '$.TaxPointDate',
        BuyersOrderNumber nvarchar(100) '$.BuyersOrderNumber',
        SourceSuppliersInvoiceNumber nvarchar(100) '$.SourceSuppliersInvoiceNumber',
        DeliveryNoteNumber nvarchar(100) '$.DeliveryNoteNumber',
        SuppliersOrderReference nvarchar(100) '$.SuppliersOrderReference',
        CustomerAccountCode nvarchar(100) '$.CustomerAccountCode',
        DocumentBrandCode nvarchar(50) '$.DocumentBrandCode',
        DocumentBrandDescription nvarchar(200) '$.DocumentBrandDescription',
        SupplierBranchCode nvarchar(50) '$.SupplierBranchCode',
        SupplierBranchDescription nvarchar(200) '$.SupplierBranchDescription',
        CurrencyCode nvarchar(20) '$.CurrencyCode',
        CurrencyDescription nvarchar(100) '$.CurrencyDescription',
        CreditTermsCode nvarchar(50) '$.CreditTermsCode',
        CreditTermsDescription nvarchar(200) '$.CreditTermsDescription',
        ExpectedLineCount int '$.ExpectedLineCount',
        NumberOfTaxRates int '$.NumberOfTaxRates',
        LineValueTotal decimal(19, 4) '$.LineValueTotal',
        TaxableTotal decimal(19, 4) '$.TaxableTotal',
        TaxTotal decimal(19, 4) '$.TaxTotal',
        NetPaymentTotal decimal(19, 4) '$.NetPaymentTotal',
            GrossPaymentTotal decimal(19, 4) '$.GrossPaymentTotal'
        ) invoice;
    END
    ELSE
    BEGIN
        UPDATE target
        SET
            sourceItemId = @SourceItemId,
            correlationId = @CorrelationId,
            invoiceTypeCode = invoice.InvoiceTypeCode,
            invoiceTypeDescription = invoice.InvoiceTypeDescription,
            invoiceDate = invoice.InvoiceDate,
            taxPointDate = invoice.TaxPointDate,
            buyersOrderNumber = invoice.BuyersOrderNumber,
            sourceSuppliersInvoiceNumber = invoice.SourceSuppliersInvoiceNumber,
            deliveryNoteNumber = invoice.DeliveryNoteNumber,
            suppliersOrderReference = invoice.SuppliersOrderReference,
            customerAccountCode = invoice.CustomerAccountCode,
            documentBrandCode = invoice.DocumentBrandCode,
            documentBrandDescription = invoice.DocumentBrandDescription,
            supplierBranchCode = invoice.SupplierBranchCode,
            supplierBranchDescription = invoice.SupplierBranchDescription,
            currencyCode = invoice.CurrencyCode,
            currencyDescription = invoice.CurrencyDescription,
            creditTermsCode = invoice.CreditTermsCode,
            creditTermsDescription = invoice.CreditTermsDescription,
            expectedLineCount = invoice.ExpectedLineCount,
            numberOfTaxRates = invoice.NumberOfTaxRates,
            lineValueTotal = invoice.LineValueTotal,
            taxableTotal = invoice.TaxableTotal,
            taxTotal = invoice.TaxTotal,
            netPaymentTotal = invoice.NetPaymentTotal,
            grossPaymentTotal = invoice.GrossPaymentTotal,
            updatedOn = @Now
        FROM dbo.ConsolidatedSales_Invoices target
        CROSS APPLY OPENJSON(@InvoiceJson)
        WITH
        (
            InvoiceTypeCode nvarchar(20) '$.InvoiceTypeCode',
            InvoiceTypeDescription nvarchar(100) '$.InvoiceTypeDescription',
            InvoiceDate date '$.InvoiceDate',
            TaxPointDate date '$.TaxPointDate',
            BuyersOrderNumber nvarchar(100) '$.BuyersOrderNumber',
            SourceSuppliersInvoiceNumber nvarchar(100) '$.SourceSuppliersInvoiceNumber',
            DeliveryNoteNumber nvarchar(100) '$.DeliveryNoteNumber',
            SuppliersOrderReference nvarchar(100) '$.SuppliersOrderReference',
            CustomerAccountCode nvarchar(100) '$.CustomerAccountCode',
            DocumentBrandCode nvarchar(50) '$.DocumentBrandCode',
            DocumentBrandDescription nvarchar(200) '$.DocumentBrandDescription',
            SupplierBranchCode nvarchar(50) '$.SupplierBranchCode',
            SupplierBranchDescription nvarchar(200) '$.SupplierBranchDescription',
            CurrencyCode nvarchar(20) '$.CurrencyCode',
            CurrencyDescription nvarchar(100) '$.CurrencyDescription',
            CreditTermsCode nvarchar(50) '$.CreditTermsCode',
            CreditTermsDescription nvarchar(200) '$.CreditTermsDescription',
            ExpectedLineCount int '$.ExpectedLineCount',
            NumberOfTaxRates int '$.NumberOfTaxRates',
            LineValueTotal decimal(19, 4) '$.LineValueTotal',
            TaxableTotal decimal(19, 4) '$.TaxableTotal',
            TaxTotal decimal(19, 4) '$.TaxTotal',
            NetPaymentTotal decimal(19, 4) '$.NetPaymentTotal',
            GrossPaymentTotal decimal(19, 4) '$.GrossPaymentTotal'
        ) invoice
        WHERE target.id = @InvoiceId;
    END;

    INSERT dbo.ConsolidatedSales_InvoiceParties
    (
        consolidatedInvoiceId,
        partyRole,
        accountCode,
        partyName,
        addressLinesJson,
        addressLine1,
        addressLine2,
        addressLine3,
        addressLine4,
        street,
        city,
        state,
        postcode
    )
    SELECT
        @InvoiceId,
        party.PartyRole,
        party.AccountCode,
        party.PartyName,
        party.AddressLinesJson,
        party.AddressLine1,
        party.AddressLine2,
        party.AddressLine3,
        party.AddressLine4,
        party.Street,
        party.City,
        party.State,
        party.Postcode
    FROM OPENJSON(@InvoiceJson, '$.Parties')
    WITH
    (
        PartyRole nvarchar(20) '$.PartyRole',
        AccountCode nvarchar(100) '$.AccountCode',
        PartyName nvarchar(255) '$.PartyName',
        AddressLinesJson nvarchar(max) '$.AddressLinesJson',
        AddressLine1 nvarchar(255) '$.AddressLine1',
        AddressLine2 nvarchar(255) '$.AddressLine2',
        AddressLine3 nvarchar(255) '$.AddressLine3',
        AddressLine4 nvarchar(255) '$.AddressLine4',
        Street nvarchar(255) '$.Street',
        City nvarchar(100) '$.City',
        State nvarchar(100) '$.State',
        Postcode nvarchar(20) '$.Postcode'
    ) party;

    DECLARE @Components TABLE
    (
        id uniqueidentifier NOT NULL,
        componentReferenceKey nvarchar(200) NOT NULL,
        standardInvoiceNumber nvarchar(100) NULL,
        branchCode nvarchar(50) NULL,
        deliveryNoteNumber nvarchar(100) NULL,
        buyersOrderNumber nvarchar(100) NULL,
        suppliersOrderReference nvarchar(100) NULL
    );

    INSERT @Components
    (
        id,
        componentReferenceKey,
        standardInvoiceNumber,
        branchCode,
        deliveryNoteNumber,
        buyersOrderNumber,
        suppliersOrderReference
    )
    SELECT
        NEWID(),
        component.ComponentReferenceKey,
        component.StandardInvoiceNumber,
        component.BranchCode,
        component.DeliveryNoteNumber,
        component.BuyersOrderNumber,
        component.SuppliersOrderReference
    FROM OPENJSON(@InvoiceJson, '$.Components')
    WITH
    (
        ComponentReferenceKey nvarchar(200) '$.ComponentReferenceKey',
        StandardInvoiceNumber nvarchar(100) '$.StandardInvoiceNumber',
        BranchCode nvarchar(50) '$.BranchCode',
        DeliveryNoteNumber nvarchar(100) '$.DeliveryNoteNumber',
        BuyersOrderNumber nvarchar(100) '$.BuyersOrderNumber',
        SuppliersOrderReference nvarchar(100) '$.SuppliersOrderReference'
    ) component;

    IF EXISTS (SELECT componentReferenceKey FROM @Components GROUP BY componentReferenceKey HAVING COUNT(*) > 1)
        THROW 51000, 'ComponentReferenceKey must be unique within a consolidated invoice.', 1;

    INSERT dbo.ConsolidatedSales_InvoiceComponents
    (
        id,
        consolidatedInvoiceId,
        componentReferenceKey,
        standardInvoiceNumber,
        branchCode,
        deliveryNoteNumber,
        buyersOrderNumber,
        suppliersOrderReference,
        createdOn
    )
    SELECT
        id,
        @InvoiceId,
        componentReferenceKey,
        standardInvoiceNumber,
        branchCode,
        deliveryNoteNumber,
        buyersOrderNumber,
        suppliersOrderReference,
        @Now
    FROM @Components;

    DECLARE @Lines TABLE
    (
        id uniqueidentifier NOT NULL,
        componentReferenceKey nvarchar(200) NULL,
        lineIdentity nvarchar(200) NOT NULL,
        salesforceExternalId nvarchar(255) NOT NULL,
        lineJson nvarchar(max) NOT NULL
    );

    INSERT @Lines (id, componentReferenceKey, lineIdentity, salesforceExternalId, lineJson)
    SELECT
        NEWID(),
        JSON_VALUE(line.[value], '$.ComponentReferenceKey'),
        JSON_VALUE(line.[value], '$.LineIdentity'),
        JSON_VALUE(line.[value], '$.SalesforceExternalId'),
        line.[value]
    FROM OPENJSON(@InvoiceJson, '$.Lines') line;

    IF EXISTS
    (
        SELECT 1 FROM @Lines
        WHERE NULLIF(LTRIM(RTRIM(lineIdentity)), N'') IS NULL
           OR NULLIF(LTRIM(RTRIM(salesforceExternalId)), N'') IS NULL
    )
        THROW 51000, 'Every line requires LineIdentity and SalesforceExternalId.', 1;

    IF EXISTS (SELECT lineIdentity FROM @Lines GROUP BY lineIdentity HAVING COUNT(*) > 1)
        THROW 51000, 'LineIdentity must be unique within a consolidated invoice.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM @Lines line
        WHERE line.componentReferenceKey IS NOT NULL
          AND NOT EXISTS
          (
              SELECT 1 FROM @Components component
              WHERE component.componentReferenceKey = line.componentReferenceKey
          )
    )
        THROW 51000, 'A line references an unknown ComponentReferenceKey.', 1;

    INSERT dbo.ConsolidatedSales_InvoiceLines
    (
        id,
        consolidatedInvoiceId,
        componentId,
        lineIdentity,
        lineSequence,
        sourceLineNumber,
        preserveLineNumber,
        sourceAction,
        orderLineNumber,
        originalOrderLineNumber,
        deliveryNoteNumber,
        deliveryNoteLineNumber,
        buyersOrderNumber,
        suppliersOrderReference,
        supplierDespatchDate,
        supplierCodeForDelivery,
        orderTypeCode,
        orderTypeDescription,
        orderCategoryCode,
        orderCategoryDescription,
        deliveryMethodCode,
        deliveryMethodDescription,
        supplierPartAnalysisCode,
        isSpecialProduct,
        isTextLine,
        productCode,
        productDescription,
        quantity,
        quantityUomCode,
        quantityUomDescription,
        unitPrice,
        priceUomCode,
        priceUomDescription,
        percentageDiscount,
        taxRateCode,
        taxRate,
        taxValue,
        lineTotal,
        jobNumber,
        contractNumber,
        buyerLocation,
        operative,
        siteCode,
        plotNumber,
        vehicleRegistration,
        houseType,
        productGroup,
        orderAuthorised,
        jobAddressLinesJson,
        jobAddressLine1,
        jobAddressLine2,
        jobAddressLine3,
        jobAddressLine4,
        jobStreet,
        jobCity,
        jobState,
        jobPostcode,
        createdOn,
        updatedOn
    )
    SELECT
        sourceLine.id,
        @InvoiceId,
        component.id,
        sourceLine.lineIdentity,
        line.LineSequence,
        line.SourceLineNumber,
        line.PreserveLineNumber,
        line.SourceAction,
        line.OrderLineNumber,
        line.OriginalOrderLineNumber,
        line.DeliveryNoteNumber,
        line.DeliveryNoteLineNumber,
        line.BuyersOrderNumber,
        line.SuppliersOrderReference,
        line.SupplierDespatchDate,
        line.SupplierCodeForDelivery,
        line.OrderTypeCode,
        line.OrderTypeDescription,
        line.OrderCategoryCode,
        line.OrderCategoryDescription,
        line.DeliveryMethodCode,
        line.DeliveryMethodDescription,
        line.SupplierPartAnalysisCode,
        line.IsSpecialProduct,
        COALESCE(line.IsTextLine, 0),
        line.ProductCode,
        line.ProductDescription,
        line.Quantity,
        line.QuantityUomCode,
        line.QuantityUomDescription,
        line.UnitPrice,
        line.PriceUomCode,
        line.PriceUomDescription,
        line.PercentageDiscount,
        line.TaxRateCode,
        line.TaxRate,
        line.TaxValue,
        line.LineTotal,
        line.JobNumber,
        line.ContractNumber,
        line.BuyerLocation,
        line.Operative,
        line.SiteCode,
        line.PlotNumber,
        line.VehicleRegistration,
        line.HouseType,
        line.ProductGroup,
        line.OrderAuthorised,
        line.JobAddressLinesJson,
        line.JobAddressLine1,
        line.JobAddressLine2,
        line.JobAddressLine3,
        line.JobAddressLine4,
        line.JobStreet,
        line.JobCity,
        line.JobState,
        line.JobPostcode,
        @Now,
        @Now
    FROM @Lines sourceLine
    CROSS APPLY OPENJSON(sourceLine.lineJson)
    WITH
    (
        LineSequence int '$.LineSequence',
        SourceLineNumber nvarchar(50) '$.SourceLineNumber',
        PreserveLineNumber bit '$.PreserveLineNumber',
        SourceAction nvarchar(30) '$.SourceAction',
        OrderLineNumber nvarchar(50) '$.OrderLineNumber',
        OriginalOrderLineNumber nvarchar(50) '$.OriginalOrderLineNumber',
        DeliveryNoteNumber nvarchar(100) '$.DeliveryNoteNumber',
        DeliveryNoteLineNumber nvarchar(50) '$.DeliveryNoteLineNumber',
        BuyersOrderNumber nvarchar(100) '$.BuyersOrderNumber',
        SuppliersOrderReference nvarchar(100) '$.SuppliersOrderReference',
        SupplierDespatchDate date '$.SupplierDespatchDate',
        SupplierCodeForDelivery nvarchar(100) '$.SupplierCodeForDelivery',
        OrderTypeCode nvarchar(50) '$.OrderTypeCode',
        OrderTypeDescription nvarchar(200) '$.OrderTypeDescription',
        OrderCategoryCode nvarchar(50) '$.OrderCategoryCode',
        OrderCategoryDescription nvarchar(200) '$.OrderCategoryDescription',
        DeliveryMethodCode nvarchar(50) '$.DeliveryMethodCode',
        DeliveryMethodDescription nvarchar(200) '$.DeliveryMethodDescription',
        SupplierPartAnalysisCode nvarchar(100) '$.SupplierPartAnalysisCode',
        IsSpecialProduct bit '$.IsSpecialProduct',
        IsTextLine bit '$.IsTextLine',
        ProductCode nvarchar(100) '$.ProductCode',
        ProductDescription nvarchar(1000) '$.ProductDescription',
        Quantity decimal(19, 6) '$.Quantity',
        QuantityUomCode nvarchar(50) '$.QuantityUomCode',
        QuantityUomDescription nvarchar(200) '$.QuantityUomDescription',
        UnitPrice decimal(19, 6) '$.UnitPrice',
        PriceUomCode nvarchar(50) '$.PriceUomCode',
        PriceUomDescription nvarchar(200) '$.PriceUomDescription',
        PercentageDiscount decimal(9, 4) '$.PercentageDiscount',
        TaxRateCode nvarchar(50) '$.TaxRateCode',
        TaxRate decimal(9, 4) '$.TaxRate',
        TaxValue decimal(19, 4) '$.TaxValue',
        LineTotal decimal(19, 4) '$.LineTotal',
        JobNumber nvarchar(100) '$.JobNumber',
        ContractNumber nvarchar(100) '$.ContractNumber',
        BuyerLocation nvarchar(255) '$.BuyerLocation',
        Operative nvarchar(255) '$.Operative',
        SiteCode nvarchar(30) '$.SiteCode',
        PlotNumber nvarchar(30) '$.PlotNumber',
        VehicleRegistration nvarchar(50) '$.VehicleRegistration',
        HouseType nvarchar(30) '$.HouseType',
        ProductGroup nvarchar(30) '$.ProductGroup',
        OrderAuthorised nvarchar(100) '$.OrderAuthorised',
        JobAddressLinesJson nvarchar(max) '$.JobAddressLinesJson',
        JobAddressLine1 nvarchar(255) '$.JobAddressLine1',
        JobAddressLine2 nvarchar(255) '$.JobAddressLine2',
        JobAddressLine3 nvarchar(255) '$.JobAddressLine3',
        JobAddressLine4 nvarchar(255) '$.JobAddressLine4',
        JobStreet nvarchar(255) '$.JobStreet',
        JobCity nvarchar(100) '$.JobCity',
        JobState nvarchar(100) '$.JobState',
        JobPostcode nvarchar(20) '$.JobPostcode'
    ) line
    LEFT JOIN @Components component
        ON component.componentReferenceKey = sourceLine.componentReferenceKey;

    INSERT dbo.ConsolidatedSales_TaxSubTotals
    (
        consolidatedInvoiceId,
        taxRateCode,
        taxRate,
        numberOfLinesAtRate,
        totalValueAtRate,
        taxableValueAtRate,
        taxAtRate,
        netPaymentAtRate,
        grossPaymentAtRate
    )
    SELECT
        @InvoiceId,
        tax.TaxRateCode,
        tax.TaxRate,
        tax.NumberOfLinesAtRate,
        tax.TotalValueAtRate,
        tax.TaxableValueAtRate,
        tax.TaxAtRate,
        tax.NetPaymentAtRate,
        tax.GrossPaymentAtRate
    FROM OPENJSON(@InvoiceJson, '$.TaxSubTotals')
    WITH
    (
        TaxRateCode nvarchar(50) '$.TaxRateCode',
        TaxRate decimal(9, 4) '$.TaxRate',
        NumberOfLinesAtRate int '$.NumberOfLinesAtRate',
        TotalValueAtRate decimal(19, 4) '$.TotalValueAtRate',
        TaxableValueAtRate decimal(19, 4) '$.TaxableValueAtRate',
        TaxAtRate decimal(19, 4) '$.TaxAtRate',
        NetPaymentAtRate decimal(19, 4) '$.NetPaymentAtRate',
        GrossPaymentAtRate decimal(19, 4) '$.GrossPaymentAtRate'
    ) tax;

    IF @SalesforceWorkId IS NULL
    BEGIN
        SET @SalesforceWorkId = NEWID();

        INSERT dbo.ConsolidatedSales_SalesforceWork
        (
            id,
            consolidatedInvoiceId,
            correlationId,
            status,
            expectedLineCount,
            salesforceCooloffStartedOn,
            salesforceCooloffHours,
            salesforceEligibleOn,
            createdOn,
            updatedOn
        )
        VALUES
        (
            @SalesforceWorkId,
            @InvoiceId,
            @CorrelationId,
            N'Pending',
            @ExpectedLineCount,
            @SalesforceCooloffStartedOn,
            @SalesforceCooloffHours,
            @SalesforceEligibleOn,
            @Now,
            @Now
        );
    END
    ELSE
    BEGIN
        UPDATE dbo.ConsolidatedSales_SalesforceWork
        SET
            correlationId = @CorrelationId,
            status = N'Pending',
            expectedLineCount = @ExpectedLineCount,
            salesforceCooloffStartedOn = @SalesforceCooloffStartedOn,
            salesforceCooloffHours = @SalesforceCooloffHours,
            salesforceEligibleOn = @SalesforceEligibleOn,
            attemptCount = 0,
            nextAttemptOn = NULL,
            claimToken = NULL,
            leaseOwner = NULL,
            leaseExpiresOn = NULL,
            salesforceOrderId = NULL,
            lastErrorCategory = NULL,
            lastErrorMessage = NULL,
            updatedOn = @Now,
            completedOn = NULL
        WHERE id = @SalesforceWorkId;
    END;

    INSERT dbo.ConsolidatedSales_SalesforceLineState
    (
        salesforceWorkId,
        consolidatedInvoiceLineId,
        externalId,
        status,
        updatedOn
    )
    SELECT
        @SalesforceWorkId,
        id,
        salesforceExternalId,
        N'Pending',
        @Now
    FROM @Lines;

    INSERT dbo.ConsolidatedSales_ReconciliationWork
    (
        consolidatedInvoiceId,
        componentId,
        correlationId,
        branchCode,
        standardInvoiceNumber,
        status,
        createdOn,
        updatedOn
    )
    SELECT
        @InvoiceId,
        component.id,
        @CorrelationId,
        component.branchCode,
        component.standardInvoiceNumber,
        N'Pending',
        @Now,
        @Now
    FROM @Components component;

    COMMIT TRANSACTION;

    SELECT @InvoiceId AS consolidatedInvoiceId, @IsNew AS isNew;
END;
