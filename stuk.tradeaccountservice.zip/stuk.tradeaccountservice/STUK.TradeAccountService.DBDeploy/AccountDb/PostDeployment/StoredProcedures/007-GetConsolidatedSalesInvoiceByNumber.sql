/*
Procedure:
  [dbo].[GetConsolidatedSalesInvoiceByNumber]

Purpose:
  Returns one complete canonical consolidated invoice hierarchy by business number.

Used by:
  Consolidated Sales Salesforce and reconciliation workers.

Parameters:
  @ConsolidatedInvoiceNumber Consolidated invoice business number. Required.

Returns:
  One JSON document in the JsonResult column, or no row when the invoice is not found.

Idempotency:
  Read-only.

Notes:
  Operational Salesforce and reconciliation state are intentionally excluded.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[GetConsolidatedSalesInvoiceByNumber]
    @ConsolidatedInvoiceNumber nvarchar(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
    (
        SELECT
            invoice.id,
            invoice.correlationId,
            invoice.consolidatedInvoiceNumber,
            invoice.invoiceTypeCode,
            invoice.invoiceTypeDescription,
            invoice.invoiceDate,
            invoice.taxPointDate,
            invoice.buyersOrderNumber,
            invoice.sourceSuppliersInvoiceNumber,
            invoice.deliveryNoteNumber,
            invoice.suppliersOrderReference,
            invoice.customerAccountCode,
            invoice.documentBrandCode,
            invoice.documentBrandDescription,
            invoice.supplierBranchCode,
            invoice.supplierBranchDescription,
            invoice.currencyCode,
            invoice.currencyDescription,
            invoice.creditTermsCode,
            invoice.creditTermsDescription,
            invoice.expectedLineCount,
            invoice.numberOfTaxRates,
            invoice.lineValueTotal,
            invoice.taxableTotal,
            invoice.taxTotal,
            invoice.netPaymentTotal,
            invoice.grossPaymentTotal,
            invoice.createdOn,
            invoice.updatedOn,
            JSON_QUERY
            (
                (
                    SELECT party.*
                    FROM dbo.ConsolidatedSales_InvoiceParties party
                    WHERE party.consolidatedInvoiceId = invoice.id
                    ORDER BY party.partyRole
                    FOR JSON PATH
                )
            ) AS parties,
            JSON_QUERY
            (
                (
                    SELECT component.*
                    FROM dbo.ConsolidatedSales_InvoiceComponents component
                    WHERE component.consolidatedInvoiceId = invoice.id
                    ORDER BY component.componentReferenceKey
                    FOR JSON PATH
                )
            ) AS components,
            JSON_QUERY
            (
                (
                    SELECT line.*
                    FROM dbo.ConsolidatedSales_InvoiceLines line
                    WHERE line.consolidatedInvoiceId = invoice.id
                    ORDER BY line.lineSequence
                    FOR JSON PATH
                )
            ) AS lines,
            JSON_QUERY
            (
                (
                    SELECT tax.*
                    FROM dbo.ConsolidatedSales_TaxSubTotals tax
                    WHERE tax.consolidatedInvoiceId = invoice.id
                    ORDER BY tax.taxRate
                    FOR JSON PATH
                )
            ) AS taxSubTotals
        FROM dbo.ConsolidatedSales_Invoices invoice
        WHERE invoice.consolidatedInvoiceNumber = @ConsolidatedInvoiceNumber
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    ) AS JsonResult
    WHERE EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_Invoices
        WHERE consolidatedInvoiceNumber = @ConsolidatedInvoiceNumber
    );
END;
