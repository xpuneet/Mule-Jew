/*
Procedure:
  [dbo].[DeferConsolidatedSalesReconciliationWork]

Purpose:
  Defers unmatched reconciliation work so it can be retried after ordinary invoice data arrives.

Used by:
  Consolidated Sales existing-invoice reconciliation persistence implementation.

Parameters:
  @ReconciliationWorkId Reconciliation work identifier. Required.
  @ClaimToken            Current claim token. Required.
  @NextAttemptOn         Next permitted matching time. Required.
  @Reason                Safe explanation for the deferral. Required.
  @Now                   UTC deferral time. Defaults to current UTC time.

Returns:
  The resulting status, attempt count and next-attempt time.

Idempotency:
  Only the current claim token can defer the work once.

Notes:
  A missing ordinary invoice is an expected timing condition rather than a terminal failure.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[DeferConsolidatedSalesReconciliationWork]
    @ReconciliationWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @NextAttemptOn datetimeoffset(7),
    @Reason nvarchar(2000),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF @NextAttemptOn <= @Now
        THROW 51000, 'NextAttemptOn must be in the future.', 1;

    UPDATE dbo.ConsolidatedSales_ReconciliationWork
    SET
        status = N'Retry',
        nextAttemptOn = @NextAttemptOn,
        lastErrorCategory = N'OrdinaryInvoiceNotAvailable',
        lastErrorMessage = @Reason,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        updatedOn = @Now
    WHERE id = @ReconciliationWorkId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The reconciliation work is not held by the supplied claim token.', 1;

    SELECT status, attemptCount, nextAttemptOn
    FROM dbo.ConsolidatedSales_ReconciliationWork
    WHERE id = @ReconciliationWorkId;
END;
