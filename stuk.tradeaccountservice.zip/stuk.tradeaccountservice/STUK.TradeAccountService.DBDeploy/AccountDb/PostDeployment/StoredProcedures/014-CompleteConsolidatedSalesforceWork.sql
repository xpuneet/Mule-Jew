/*
Procedure:
  [dbo].[CompleteConsolidatedSalesforceWork]

Purpose:
  Completes invoice-level Salesforce delivery after the expected OrderItem count has been proven.

Used by:
  Consolidated Sales Salesforce synchronisation persistence implementation.

Parameters:
  @SalesforceWorkId  Salesforce work identifier. Required.
  @ClaimToken        Current claim token. Required.
  @SalesforceOrderId Salesforce Order identifier. Required.
  @ActualLineCount   Salesforce OrderItem count observed after upsert. Required.
  @Now               UTC completion time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Repeating completion for already completed work succeeds.

Notes:
  Completion is rejected unless the observed and locally completed line counts equal the expected count.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[CompleteConsolidatedSalesforceWork]
    @SalesforceWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @SalesforceOrderId nvarchar(50),
    @ActualLineCount int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF EXISTS
    (
        SELECT 1 FROM dbo.ConsolidatedSales_SalesforceWork
        WHERE id = @SalesforceWorkId AND status = N'Completed'
    )
        RETURN;

    DECLARE @ExpectedLineCount int;

    SELECT @ExpectedLineCount = expectedLineCount
    FROM dbo.ConsolidatedSales_SalesforceWork
    WHERE id = @SalesforceWorkId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @ExpectedLineCount IS NULL
        THROW 51000, 'The Salesforce work is not held by the supplied claim token.', 1;

    IF @ActualLineCount <> @ExpectedLineCount
        THROW 51000, 'The Salesforce OrderItem count does not match the expected line count.', 1;

    IF @ExpectedLineCount <>
    (
        SELECT COUNT(*)
        FROM dbo.ConsolidatedSales_SalesforceLineState
        WHERE salesforceWorkId = @SalesforceWorkId
          AND status = N'Completed'
    )
        THROW 51000, 'Not all local line deliveries are complete.', 1;

    UPDATE dbo.ConsolidatedSales_SalesforceWork
    SET
        status = N'Completed',
        salesforceOrderId = @SalesforceOrderId,
        completedOn = @Now,
        nextAttemptOn = NULL,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = NULL,
        lastErrorMessage = NULL,
        updatedOn = @Now
    WHERE id = @SalesforceWorkId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;
END;
