/*
Procedure:
  [dbo].[GetConsolidatedSalesExportRows]

Purpose:
  Returns the immutable ordered snapshot used to generate destination files.

Used by:
  STUK.TradeAccountService.Common.Data.Services.ConsolidatedSalesExportDataService

Parameters:
  @ExportRunId       Export run identifier. Required.
  @AfterRowSequence  Last row sequence already consumed. Defaults to zero.
  @PageSize          Maximum rows returned. Defaults to all rows for existing-caller compatibility.

Returns:
  The nine ConsXref fields ordered by their persisted row sequence.

Idempotency:
  Read-only and deterministic for a completed extraction.

Notes:
  Rows are never returned for a pending, partial or failed extraction.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[GetConsolidatedSalesExportRows]
    @ExportRunId uniqueidentifier,
    @AfterRowSequence bigint = 0,
    @PageSize int = 2147483647
AS
BEGIN
    SET NOCOUNT ON;

    IF @AfterRowSequence < 0
        THROW 51000, 'AfterRowSequence cannot be negative.', 1;

    IF @PageSize <= 0
        THROW 51000, 'PageSize must be greater than zero.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_ExportRuns
        WHERE id = @ExportRunId AND status = N'Extracted'
    )
        THROW 51000, 'The export snapshot is not complete.', 1;

    SELECT TOP (@PageSize)
        rowSequence,
        accountNumber,
        invoiceNumber,
        invoiceDate,
        deliveryNoteNumber,
        deliveryNoteLineNumber,
        despatchDate,
        productCode,
        quantity,
        totalPrice
    FROM dbo.ConsolidatedSales_ExportRows
    WHERE exportRunId = @ExportRunId
      AND rowSequence > @AfterRowSequence
    ORDER BY rowSequence;
END;
