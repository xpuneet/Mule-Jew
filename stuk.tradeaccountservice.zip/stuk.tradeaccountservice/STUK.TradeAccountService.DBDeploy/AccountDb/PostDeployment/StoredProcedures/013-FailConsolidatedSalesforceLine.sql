/*
Procedure:
  [dbo].[FailConsolidatedSalesforceLine]

Purpose:
  Records the latest Salesforce failure for one canonical line.

Used by:
  Consolidated Sales Salesforce synchronisation persistence implementation.

Parameters:
  @SalesforceWorkId Salesforce work identifier. Required.
  @ClaimToken       Current invoice-work claim token. Required.
  @ExternalId       Deterministic Salesforce OrderItem external identifier. Required.
  @ErrorMessage     Safe error description. Required.
  @Now              UTC failure time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Repeated failure recording replaces only the latest line error.

Notes:
  Attempt history is recorded independently by SalesforceAttempt_Record.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[FailConsolidatedSalesforceLine]
    @SalesforceWorkId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ExternalId nvarchar(255),
    @ErrorMessage nvarchar(2000),
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ConsolidatedSales_SalesforceWork
        WHERE id = @SalesforceWorkId
          AND status = N'Claimed'
          AND claimToken = @ClaimToken
    )
        THROW 51000, 'The Salesforce work is not held by the supplied claim token.', 1;

    UPDATE dbo.ConsolidatedSales_SalesforceLineState
    SET
        status = N'Failed',
        lastErrorMessage = @ErrorMessage,
        updatedOn = @Now
    WHERE salesforceWorkId = @SalesforceWorkId
      AND externalId = @ExternalId;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The Salesforce line external identifier was not found.', 1;
END;
