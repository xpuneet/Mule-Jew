/*
Procedure:
  [dbo].[ClaimNextConsolidatedSalesReconciliationWork]

Purpose:
  Atomically claims the next component invoice eligible for matching to an existing invoice record.

Used by:
  Consolidated Sales existing-invoice reconciliation persistence implementation.

Parameters:
  @LeaseOwner            Worker instance claiming the item. Required.
  @LeaseDurationSeconds  Duration of the processing lease. Required.
  @Now                   UTC processing time. Defaults to current UTC time.
  @MaximumRetryCount     Maximum permitted processing attempts before an abandoned claim is terminal. Defaults to 2 for deployment compatibility.

Returns:
  The claimed reconciliation row and consolidated invoice date/number, or no row when no work is available.

Idempotency:
  Claiming is concurrency-safe and expired claims are reclaimable.

Notes:
  Missing ordinary invoices remain eligible beyond the normal attempt ceiling. Exhausted expired claims are terminally failed.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[ClaimNextConsolidatedSalesReconciliationWork]
    @LeaseOwner nvarchar(200),
    @LeaseDurationSeconds int,
    @Now datetimeoffset(7) = NULL,
    @MaximumRetryCount int = 2
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @LeaseDurationSeconds <= 0
        THROW 51000, 'Lease duration must be greater than zero.', 1;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());
    DECLARE @ClaimToken uniqueidentifier = NEWID();
    DECLARE @Claimed TABLE (id uniqueidentifier NOT NULL);

    UPDATE dbo.ConsolidatedSales_ReconciliationWork
    SET
        status = N'TerminallyFailed',
        nextAttemptOn = NULL,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        lastErrorCategory = N'LeaseExpired',
        lastErrorMessage = N'The reconciliation lease expired after the maximum permitted attempts.',
        updatedOn = @Now
    WHERE status = N'Claimed'
      AND leaseExpiresOn <= @Now
      AND attemptCount >= @MaximumRetryCount;

    ;WITH Candidate AS
    (
        SELECT TOP (1) *
        FROM dbo.ConsolidatedSales_ReconciliationWork WITH (UPDLOCK, READPAST, ROWLOCK)
        WHERE EXISTS
        (
            SELECT 1
            FROM dbo.ConsolidatedSales_Invoices invoice
            INNER JOIN dbo.ConsolidatedSales_SourceItems sourceItem
                ON sourceItem.id = invoice.sourceItemId
            WHERE invoice.id = ConsolidatedSales_ReconciliationWork.consolidatedInvoiceId
              AND sourceItem.status = N'Completed'
        )
        AND
        (
            (
                (
                    status = N'Pending'
                    OR
                    (
                        status = N'Retry'
                        AND
                        (
                            lastErrorCategory = N'OrdinaryInvoiceNotAvailable'
                            OR attemptCount < @MaximumRetryCount
                        )
                    )
                )
                AND (nextAttemptOn IS NULL OR nextAttemptOn <= @Now)
            )
            OR
            (
                status = N'Claimed'
                AND leaseExpiresOn <= @Now
                AND attemptCount < @MaximumRetryCount
            )
        )
        ORDER BY createdOn, id
    )
    UPDATE Candidate
    SET
        status = N'Claimed',
        claimToken = @ClaimToken,
        leaseOwner = @LeaseOwner,
        leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
        attemptCount = attemptCount + 1,
        nextAttemptOn = NULL,
        lastErrorCategory = NULL,
        lastErrorMessage = NULL,
        updatedOn = @Now
    OUTPUT inserted.id INTO @Claimed(id);

    SELECT
        work.*,
        invoice.consolidatedInvoiceNumber,
        invoice.invoiceDate AS consolidatedInvoiceDate,
        component.componentReferenceKey,
        component.deliveryNoteNumber
    FROM dbo.ConsolidatedSales_ReconciliationWork work
    INNER JOIN @Claimed claimed ON claimed.id = work.id
    INNER JOIN dbo.ConsolidatedSales_Invoices invoice ON invoice.id = work.consolidatedInvoiceId
    INNER JOIN dbo.ConsolidatedSales_InvoiceComponents component ON component.id = work.componentId;
END;
