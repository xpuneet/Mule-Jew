/*
Procedure:
  dbo.ReleaseWorkdayConcurRunLease

Purpose:
  Releases a Workday-to-Concur processing lease without changing its durable stage.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  @RunId      Run identifier. Required.
  @ClaimToken Active claim token. Required.
  @Now        UTC operation time. Defaults to current UTC time.

Returns:
  No result set.

Idempotency:
  Not idempotent after release; a stale caller cannot release a newer claim.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.ReleaseWorkdayConcurRunLease
    @RunId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.WorkdayConcurRun
    SET claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        updatedOn = @Now
    WHERE runId = @RunId
      AND claimToken = @ClaimToken
      AND closedOn IS NULL
      AND leaseExpiresOn > @Now;

    IF @@ROWCOUNT <> 1 THROW 51000, 'The Workday-to-Concur run is no longer owned by this invocation.', 1;
END;
