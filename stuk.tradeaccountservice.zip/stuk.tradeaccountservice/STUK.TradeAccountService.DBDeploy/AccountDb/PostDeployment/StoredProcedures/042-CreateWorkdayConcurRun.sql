/*
Procedure:
  dbo.CreateWorkdayConcurRun

Purpose:
  Atomically claims the incomplete Workday-to-Concur run or creates the next run with a frozen extraction window.

Used by:
  STUK.TradeAccountService.Common.Data.Services.WorkdayConcurStateService

Parameters:
  @CorrelationId       Correlation identifier used only when a new run is created. Required.
  @LeaseOwner          Function invocation that owns the processing lease. Required.
  @ExtractThrough      Upper extraction boundary used only when a new run is created. Required.
  @LeaseDurationSeconds Processing lease duration. Required.
  @Now                 UTC operation time. Defaults to current UTC time.

Returns:
  The claimed run, or no row when another invocation holds its unexpired lease.

Idempotency:
  Resumes the single open run without changing its frozen extraction window.

Notes:
  An application lock and a filtered unique index prevent overlapping open runs.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE dbo.CreateWorkdayConcurRun
    @CorrelationId uniqueidentifier,
    @LeaseOwner nvarchar(200),
    @ExtractThrough datetimeoffset(7),
    @LeaseDurationSeconds int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @CorrelationId IS NULL THROW 51000, 'Correlation identifier is required.', 1;
    IF NULLIF(LTRIM(RTRIM(@LeaseOwner)), N'') IS NULL THROW 51000, 'Lease owner is required.', 1;
    IF @ExtractThrough IS NULL THROW 51000, 'Extraction upper boundary is required.', 1;
    IF @LeaseDurationSeconds <= 0 THROW 51000, 'Lease duration must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    DECLARE @RunId uniqueidentifier;
    DECLARE @ClaimToken uniqueidentifier = NEWID();
    DECLARE @IsNew bit = 0;
    DECLARE @CommittedThrough datetimeoffset(7);
    DECLARE @LockResult int;

    BEGIN TRANSACTION;

    EXEC @LockResult = sys.sp_getapplock
        @Resource = N'WorkdayConcurRun',
        @LockMode = N'Exclusive',
        @LockOwner = N'Transaction',
        @LockTimeout = 10000;

    IF @LockResult < 0
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 51000, 'Could not acquire the Workday-to-Concur run lock.', 1;
    END;

    SELECT @RunId = runId
    FROM dbo.WorkdayConcurRun WITH (UPDLOCK, HOLDLOCK)
    WHERE integrationName = N'WorkdayConcur'
      AND closedOn IS NULL;

    IF @RunId IS NOT NULL
       AND EXISTS
       (
           SELECT 1
           FROM dbo.WorkdayConcurRun
           WHERE runId = @RunId
             AND leaseExpiresOn > @Now
       )
    BEGIN
        COMMIT TRANSACTION;
        RETURN;
    END;

    IF @RunId IS NULL
    BEGIN
        SELECT @CommittedThrough = committedThrough
        FROM dbo.WorkdayConcurWatermark WITH (UPDLOCK, HOLDLOCK)
        WHERE integrationName = N'WorkdayConcur';

        IF @CommittedThrough IS NULL
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 51000, 'The Workday-to-Concur watermark has not been initialised.', 1;
        END;

        IF @ExtractThrough <= @CommittedThrough
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 51000, 'The extraction upper boundary must be later than the committed watermark.', 1;
        END;

        SET @RunId = NEWID();
        SET @IsNew = 1;

        INSERT dbo.WorkdayConcurRun
        (
            runId, integrationName, correlationId, extractFrom, extractThrough,
            status, currentStage, retryCount, claimToken, leaseOwner, leaseExpiresOn,
            createdOn, updatedOn, closedOn
        )
        VALUES
        (
            @RunId, N'WorkdayConcur', @CorrelationId, @CommittedThrough, @ExtractThrough,
            N'Active', N'Pending', 1, @ClaimToken, @LeaseOwner,
            DATEADD(SECOND, @LeaseDurationSeconds, @Now), @Now, @Now, NULL
        );
    END
    ELSE
    BEGIN
        UPDATE dbo.WorkdayConcurRun
        SET status = N'Active',
            retryCount = retryCount + 1,
            claimToken = @ClaimToken,
            leaseOwner = @LeaseOwner,
            leaseExpiresOn = DATEADD(SECOND, @LeaseDurationSeconds, @Now),
            lastErrorCategory = NULL,
            lastErrorMessage = NULL,
            updatedOn = @Now
        WHERE runId = @RunId;
    END;

    COMMIT TRANSACTION;

    SELECT
        runId, correlationId, extractFrom, extractThrough, status, currentStage,
        fileStateJson, tm1SynapseRunId, transformSynapseRunId, deliverySynapseRunId,
        housekeepingSynapseRunId, retryCount, lastErrorCategory, lastErrorMessage,
        claimToken, leaseOwner, leaseExpiresOn, createdOn, updatedOn, closedOn,
        @IsNew AS isNew
    FROM dbo.WorkdayConcurRun
    WHERE runId = @RunId;
END;
