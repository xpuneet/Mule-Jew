/*
Procedure:
  [dbo].[FailConsolidatedSalesSourceItem]

Purpose:
  Records a source-item failure and schedules retry or terminal failure.

Used by:
  Consolidated Sales ingestion persistence implementation.

Parameters:
  @SourceItemId       Source-item identifier. Required.
  @ClaimToken         Token returned by the claim procedure. Required.
  @ErrorCategory      Classified error category. Required.
  @ErrorMessage       Safe error description. Required.
  @NextAttemptOn      Next retry time when retry remains possible.
  @MaximumRetryCount  Maximum permitted failed attempts. Required.
  @Now                UTC failure time. Defaults to current UTC time.

Returns:
  The resulting status and retry count.

Idempotency:
  Only the current claim token can record the failure once.

Notes:
  Raw source data and secrets must not be written to ErrorMessage.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[FailConsolidatedSalesSourceItem]
    @SourceItemId uniqueidentifier,
    @ClaimToken uniqueidentifier,
    @ErrorCategory nvarchar(100),
    @ErrorMessage nvarchar(2000),
    @NextAttemptOn datetimeoffset(7) = NULL,
    @MaximumRetryCount int,
    @Now datetimeoffset(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @MaximumRetryCount <= 0
        THROW 51000, 'Maximum retry count must be greater than zero.', 1;

    SET @Now = COALESCE(@Now, SYSUTCDATETIME());

    UPDATE dbo.ConsolidatedSales_SourceItems
    SET
        retryCount = retryCount + 1,
        status = CASE WHEN retryCount + 1 >= @MaximumRetryCount THEN N'TerminallyFailed' ELSE N'Retry' END,
        nextAttemptOn = CASE WHEN retryCount + 1 >= @MaximumRetryCount THEN NULL ELSE @NextAttemptOn END,
        failedOn = @Now,
        lastErrorCategory = @ErrorCategory,
        lastErrorMessage = @ErrorMessage,
        claimToken = NULL,
        leaseOwner = NULL,
        leaseExpiresOn = NULL,
        updatedOn = @Now
    WHERE id = @SourceItemId
      AND status = N'Claimed'
      AND claimToken = @ClaimToken;

    IF @@ROWCOUNT = 0
        THROW 51000, 'The source item is not held by the supplied claim token.', 1;

    SELECT status, retryCount, nextAttemptOn
    FROM dbo.ConsolidatedSales_SourceItems
    WHERE id = @SourceItemId;
END;
