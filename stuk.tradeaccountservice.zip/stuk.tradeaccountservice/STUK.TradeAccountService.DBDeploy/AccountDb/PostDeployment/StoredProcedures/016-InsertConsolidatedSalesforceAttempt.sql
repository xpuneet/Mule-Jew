/*
Procedure:
  [dbo].[InsertConsolidatedSalesforceAttempt]

Purpose:
  Appends an immutable audit record for one Salesforce operation attempt.

Used by:
  Consolidated Sales Salesforce synchronisation persistence implementation.

Parameters:
  @SalesforceWorkId Salesforce work identifier. Required.
  @CorrelationId    Correlation identifier. Required.
  @Operation        Salesforce operation name. Required.
  @EntityKey        Target business or external identifier.
  @AttemptNumber    Positive attempt number. Required.
  @Outcome          Succeeded, Failed or AcceptedDuplicate. Required.
  @HttpStatusCode   Salesforce HTTP response status where available.
  @RequestPayload   Approved and redacted request payload where retention is permitted.
  @ResponsePayload  Approved and redacted response payload where retention is permitted.
  @ErrorCategory    Classified error category.
  @ErrorMessage     Safe error description.
  @StartedOn        UTC operation start time. Required.
  @CompletedOn      UTC operation completion time. Required.

Returns:
  The created attempt identifier.

Idempotency:
  Append-only by design.

Notes:
  Secrets and unapproved personal data must not be persisted in payload fields.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [dbo].[InsertConsolidatedSalesforceAttempt]
    @SalesforceWorkId uniqueidentifier,
    @CorrelationId uniqueidentifier,
    @Operation nvarchar(100),
    @EntityKey nvarchar(255) = NULL,
    @AttemptNumber int,
    @Outcome nvarchar(30),
    @HttpStatusCode int = NULL,
    @RequestPayload nvarchar(max) = NULL,
    @ResponsePayload nvarchar(max) = NULL,
    @ErrorCategory nvarchar(100) = NULL,
    @ErrorMessage nvarchar(2000) = NULL,
    @StartedOn datetimeoffset(7),
    @CompletedOn datetimeoffset(7)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @AttemptId uniqueidentifier = NEWID();

    INSERT dbo.ConsolidatedSales_SalesforceAttempts
    (
        id,
        salesforceWorkId,
        correlationId,
        operation,
        entityKey,
        attemptNumber,
        outcome,
        httpStatusCode,
        requestPayload,
        responsePayload,
        errorCategory,
        errorMessage,
        startedOn,
        completedOn
    )
    VALUES
    (
        @AttemptId,
        @SalesforceWorkId,
        @CorrelationId,
        @Operation,
        @EntityKey,
        @AttemptNumber,
        @Outcome,
        @HttpStatusCode,
        @RequestPayload,
        @ResponsePayload,
        @ErrorCategory,
        @ErrorMessage,
        @StartedOn,
        @CompletedOn
    );

    SELECT @AttemptId AS salesforceAttemptId;
END;
