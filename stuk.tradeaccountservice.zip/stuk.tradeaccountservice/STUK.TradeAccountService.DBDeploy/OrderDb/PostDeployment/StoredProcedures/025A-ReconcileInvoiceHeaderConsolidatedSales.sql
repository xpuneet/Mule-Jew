/*
Target database:
  OrderServiceDb (keyed executor OrderDb).

Procedure:
  [dbo].[ReconcileInvoiceHeaderConsolidatedSales]

Purpose:
  Matches an existing invoice header and applies the two approved consolidated-invoice fields when exactly one match exists.

Used by:
  InvoiceReconciliationDataService.

Parameters:
  @StandardInvoiceNumber       Existing standard invoice number. Required.
  @BranchCode                  Existing invoice branch code. Required.
  @ConsolidatedInvoiceNumber   Consolidated invoice number to apply. Required.
  @ConsolidatedInvoiceDate     Consolidated invoice date to apply. Optional.

Returns:
  MatchCount and MatchedInvoiceHeaderId. The identifier is populated only for exactly one match.

Idempotency:
  Repeating the same update produces the same values and matched identifier.

Notes:
  Zero or multiple matches do not update Invoices_Headers. Only consolidatedInvoiceNo and consolidatedInvoiceDate are updated.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
IF OBJECT_ID(N'dbo.Invoices_Headers', N'U') IS NULL
BEGIN
    THROW 51000, 'dbo.Invoices_Headers must exist in OrderServiceDb before ReconcileInvoiceHeaderConsolidatedSales is deployed.', 1;
END;
GO
CREATE OR ALTER PROCEDURE [dbo].[ReconcileInvoiceHeaderConsolidatedSales]
    @StandardInvoiceNumber nvarchar(100),
    @BranchCode nvarchar(50),
    @ConsolidatedInvoiceNumber nvarchar(100),
    @ConsolidatedInvoiceDate date = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NULLIF(LTRIM(RTRIM(@StandardInvoiceNumber)), N'') IS NULL
        THROW 51000, 'Standard invoice number is required.', 1;

    IF NULLIF(LTRIM(RTRIM(@BranchCode)), N'') IS NULL
        THROW 51000, 'Branch code is required.', 1;

    IF NULLIF(LTRIM(RTRIM(@ConsolidatedInvoiceNumber)), N'') IS NULL
        THROW 51000, 'Consolidated invoice number is required.', 1;

    DECLARE @MatchedInvoiceHeaderId uniqueidentifier;
    DECLARE @MatchCount int;

    BEGIN TRANSACTION;

    SELECT @MatchCount = COUNT(*)
    FROM dbo.Invoices_Headers WITH (UPDLOCK, HOLDLOCK)
    WHERE standardInvoiceNo = @StandardInvoiceNumber
      AND branchCode = @BranchCode;

    IF @MatchCount = 1
    BEGIN
        SELECT @MatchedInvoiceHeaderId = id
        FROM dbo.Invoices_Headers
        WHERE standardInvoiceNo = @StandardInvoiceNumber
          AND branchCode = @BranchCode;

        UPDATE dbo.Invoices_Headers
        SET
            consolidatedInvoiceNo = @ConsolidatedInvoiceNumber,
            consolidatedInvoiceDate = @ConsolidatedInvoiceDate
        WHERE id = @MatchedInvoiceHeaderId;
    END;

    COMMIT TRANSACTION;

    SELECT
        @MatchCount AS MatchCount,
        @MatchedInvoiceHeaderId AS MatchedInvoiceHeaderId;
END;
