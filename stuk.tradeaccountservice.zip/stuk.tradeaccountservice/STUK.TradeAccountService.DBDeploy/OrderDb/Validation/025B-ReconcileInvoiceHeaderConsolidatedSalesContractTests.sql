/*
Target database:
  OrderServiceDb.

Purpose:
  Rolled-back contract checks for dbo.ReconcileInvoiceHeaderConsolidatedSales.

Safety:
  Uses an existing uniquely keyed invoice header inside a transaction and always rolls the update back.

Execution:
  Run separately in a non-production environment after 025A-ReconcileInvoiceHeaderConsolidatedSales.sql.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

BEGIN TRY
    DECLARE @StandardInvoiceNumber nvarchar(100);
    DECLARE @BranchCode nvarchar(50);
    DECLARE @TestConsolidatedInvoiceNumber nvarchar(100) = CONCAT(N'CONTRACT-TEST-', CONVERT(nvarchar(36), NEWID()));
    DECLARE @TestConsolidatedInvoiceDate date = '2026-08-25';
    DECLARE @Result TABLE
    (
        MatchCount int NOT NULL,
        MatchedInvoiceHeaderId uniqueidentifier NULL
    );

    SELECT TOP (1)
        @StandardInvoiceNumber = standardInvoiceNo,
        @BranchCode = branchCode
    FROM dbo.Invoices_Headers
    WHERE NULLIF(LTRIM(RTRIM(standardInvoiceNo)), N'') IS NOT NULL
      AND NULLIF(LTRIM(RTRIM(branchCode)), N'') IS NOT NULL
    GROUP BY standardInvoiceNo, branchCode
    HAVING COUNT(*) = 1
    ORDER BY standardInvoiceNo, branchCode;

    IF @StandardInvoiceNumber IS NULL OR @BranchCode IS NULL
        THROW 51000, 'Contract test requires one uniquely keyed invoice header in OrderServiceDb.', 1;

    INSERT @Result (MatchCount, MatchedInvoiceHeaderId)
    EXEC [dbo].[ReconcileInvoiceHeaderConsolidatedSales]
        @StandardInvoiceNumber = @StandardInvoiceNumber,
        @BranchCode = @BranchCode,
        @ConsolidatedInvoiceNumber = @TestConsolidatedInvoiceNumber,
        @ConsolidatedInvoiceDate = @TestConsolidatedInvoiceDate;

    IF NOT EXISTS
    (
        SELECT 1
        FROM @Result
        WHERE MatchCount = 1
          AND MatchedInvoiceHeaderId IS NOT NULL
    )
        THROW 51000, 'Contract test failed: the unique invoice match was not returned.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Invoices_Headers
        WHERE standardInvoiceNo = @StandardInvoiceNumber
          AND branchCode = @BranchCode
          AND consolidatedInvoiceNo = @TestConsolidatedInvoiceNumber
          AND CONVERT(date, consolidatedInvoiceDate) = @TestConsolidatedInvoiceDate
    )
        THROW 51000, 'Contract test failed: the approved consolidated invoice fields were not updated.', 1;

    DELETE FROM @Result;

    INSERT @Result (MatchCount, MatchedInvoiceHeaderId)
    EXEC [dbo].[ReconcileInvoiceHeaderConsolidatedSales]
        @StandardInvoiceNumber = @StandardInvoiceNumber,
        @BranchCode = @BranchCode,
        @ConsolidatedInvoiceNumber = @TestConsolidatedInvoiceNumber,
        @ConsolidatedInvoiceDate = @TestConsolidatedInvoiceDate;

    IF NOT EXISTS
    (
        SELECT 1
        FROM @Result
        WHERE MatchCount = 1
          AND MatchedInvoiceHeaderId IS NOT NULL
    )
        THROW 51000, 'Contract test failed: repeating the invoice update was not idempotent.', 1;

    ROLLBACK TRANSACTION;
    PRINT 'Existing invoice reconciliation contract tests passed.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;
