/*
Validation:
  Workday-to-Concur managed file-transfer contract

Purpose:
  Fails deployment validation when the Workday-to-Concur File Transfer records
  are absent or differ from the non-production contract expected by the service

Returns:
  No result set. Throws on validation failure
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.BlobConnectionConfigs
    WHERE ID = N'BLOB-WORKDAY-CONCUR'
      AND StorageName = N'statstukconcur01'
      AND ServiceEndPoint = N'https://statstukconcur01.blob.core.windows.net/'
      AND ContainerName = N'stdl-concur-tst-uks'
)
    THROW 51000, 'Workday-to-Concur Blob connection configuration is missing or invalid', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.SFTPConnectionConfigs
    WHERE ID = N'SFTP-WORKDAY-TM1'
      AND IPAddress = N'sftp-eu.planning-analytics.ibmcloud.com'
      AND Port = 22
      AND Username = N'fs_sgukprod_admin'
      AND FolderPath = N'/prod/tm1serv/Exports'
      AND PasswordKey = N'WorkdayConcur-Tm1SftpPassword'
)
    THROW 51000, 'Workday-to-Concur TM1 SFTP configuration is missing or invalid', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.SFTPConnectionConfigs
    WHERE ID = N'SFTP-WORKDAY-CONCUR'
      AND IPAddress = N'mft-eu2.concursolutions.com'
      AND Port = 22
      AND Username = N'p0601672mekx'
      AND FolderPath = N'/in/test'
      AND PasswordKey = N'WorkdayConcur-ConcurSshPrivateKey'
      AND SSHKey = N'1'
      AND PassPhraseKey = N'WorkdayConcur-ConcurSshPrivateKeyPassPhrase'
)
    THROW 51000, 'Workday-to-Concur destination SFTP configuration is missing or invalid', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.FilesIntegration
    WHERE ID = N'FI-WORKDAY-CONCUR'
      AND ProjectName = N'WorkdayConcur'
      AND SchedulerName = N'WorkdayConcurTimerFunction'
)
    THROW 51000, 'Workday-to-Concur integration configuration is missing or invalid', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.FileActions
    WHERE ID = N'FA-WORKDAY-TM1'
      AND IntegrationKeyID = N'FI-WORKDAY-CONCUR'
      AND ActionName = N'PICKUP'
      AND SourceID = N'SFTP-WORKDAY-TM1'
      AND DestinationID = N'BLOB-WORKDAY-CONCUR'
      AND PipelineName = N'SFTP_To_Blob'
      AND SourceFileNameFormat = N'TM1.csv'
      AND SourceFolderPath = N'/prod/tm1serv/Exports'
      AND DestinationFileNameFormat = N'TM1.csv'
      AND DestinationFolderPath = N'stdl-concur-tst-uks/input'
)
    THROW 51000, 'Workday-to-Concur TM1 pickup action is missing or invalid', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.FileActions
    WHERE ID = N'FA-WORKDAY-CONCUR'
      AND IntegrationKeyID = N'FI-WORKDAY-CONCUR'
      AND ActionName = N'DROP'
      AND SourceID = N'BLOB-WORKDAY-CONCUR'
      AND DestinationID = N'SFTP-WORKDAY-CONCUR'
      AND PipelineName = N'Blob_To_SFTP_SSH'
      AND SourceFolderPath = N'stdl-concur-tst-uks/delivery-staging'
      AND DestinationFolderPath = N'/in/test'
      AND SourceArchive = 0
      AND SourceDelete = 1
)
    THROW 51000, 'Workday-to-Concur delivery action is missing or invalid', 1;
