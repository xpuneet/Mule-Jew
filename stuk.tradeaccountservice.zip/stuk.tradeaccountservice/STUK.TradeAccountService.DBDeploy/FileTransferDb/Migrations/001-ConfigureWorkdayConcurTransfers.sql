/*
Migration:
  Configure Workday-to-Concur managed file transfers

Purpose:
  Registers the existing non-production TM1 SFTP source, Concur Blob staging
  storage and Concur SFTP destination used by the Workday export

Used by:
  WorkdayConcurTm1Service
  WorkdayConcurDeliveryService

Security:
  Secret values are not stored in this database. PasswordKey and PassPhraseKey
  contain Azure Key Vault secret names resolved by the existing Synapse pipelines

Idempotency:
  Repeatable by the stable Workday-to-Concur identifiers

Notes:
  This migration configures DEV and QA to use the existing non-production Concur
  workspace and storage. It contains no production configuration
*/
SET XACT_ABORT ON;

BEGIN TRANSACTION;

DECLARE @Now datetime = GETUTCDATE();

IF EXISTS (SELECT 1 FROM dbo.BlobConnectionConfigs WHERE ID = N'BLOB-WORKDAY-CONCUR')
BEGIN
    UPDATE dbo.BlobConnectionConfigs
    SET StorageName = N'statstukconcur01',
        ServiceEndPoint = N'https://statstukconcur01.blob.core.windows.net/',
        ContainerName = N'stdl-concur-tst-uks',
        ServicePrincipal = NULL,
        URL = NULL,
        ClientId = NULL,
        ClientSecretKey = NULL,
        UpdationDateTime = @Now
    WHERE ID = N'BLOB-WORKDAY-CONCUR';
END
ELSE
BEGIN
    INSERT dbo.BlobConnectionConfigs
    (
        ID,
        StorageName,
        ServiceEndPoint,
        ContainerName,
        ServicePrincipal,
        URL,
        ClientId,
        ClientSecretKey,
        CreationDateTime,
        UpdationDateTime
    )
    VALUES
    (
        N'BLOB-WORKDAY-CONCUR',
        N'statstukconcur01',
        N'https://statstukconcur01.blob.core.windows.net/',
        N'stdl-concur-tst-uks',
        NULL,
        NULL,
        NULL,
        NULL,
        @Now,
        @Now
    );
END;

IF EXISTS (SELECT 1 FROM dbo.SFTPConnectionConfigs WHERE ID = N'SFTP-WORKDAY-TM1')
BEGIN
    UPDATE dbo.SFTPConnectionConfigs
    SET IPAddress = N'sftp-eu.planning-analytics.ibmcloud.com',
        Port = 22,
        Username = N'fs_sgukprod_admin',
        Password = NULL,
        FolderPath = N'/prod/tm1serv/Exports',
        PasswordKey = N'WorkdayConcur-Tm1SftpPassword',
        RSABase64Key = NULL,
        SSHKey = N'0',
        PassPhraseKey = NULL,
        UpdationDateTime = @Now
    WHERE ID = N'SFTP-WORKDAY-TM1';
END
ELSE
BEGIN
    INSERT dbo.SFTPConnectionConfigs
    (
        ID,
        IPAddress,
        Port,
        Username,
        Password,
        FolderPath,
        CreationDateTime,
        UpdationDateTime,
        PasswordKey,
        RSABase64Key,
        SSHKey,
        PassPhraseKey
    )
    VALUES
    (
        N'SFTP-WORKDAY-TM1',
        N'sftp-eu.planning-analytics.ibmcloud.com',
        22,
        N'fs_sgukprod_admin',
        NULL,
        N'/prod/tm1serv/Exports',
        @Now,
        @Now,
        N'WorkdayConcur-Tm1SftpPassword',
        NULL,
        0,
        NULL
    );
END;

IF EXISTS (SELECT 1 FROM dbo.SFTPConnectionConfigs WHERE ID = N'SFTP-WORKDAY-CONCUR')
BEGIN
    UPDATE dbo.SFTPConnectionConfigs
    SET IPAddress = N'mft-eu2.concursolutions.com',
        Port = 22,
        Username = N'p0601672mekx',
        Password = NULL,
        FolderPath = N'/in/test',
        PasswordKey = N'WorkdayConcur-ConcurSshPrivateKey',
        RSABase64Key = NULL,
        SSHKey = N'1',
        PassPhraseKey = N'WorkdayConcur-ConcurSshPrivateKeyPassPhrase',
        UpdationDateTime = @Now
    WHERE ID = N'SFTP-WORKDAY-CONCUR';
END
ELSE
BEGIN
    INSERT dbo.SFTPConnectionConfigs
    (
        ID,
        IPAddress,
        Port,
        Username,
        Password,
        FolderPath,
        CreationDateTime,
        UpdationDateTime,
        PasswordKey,
        RSABase64Key,
        SSHKey,
        PassPhraseKey
    )
    VALUES
    (
        N'SFTP-WORKDAY-CONCUR',
        N'mft-eu2.concursolutions.com',
        22,
        N'p0601672mekx',
        NULL,
        N'/in/test',
        @Now,
        @Now,
        N'WorkdayConcur-ConcurSshPrivateKey',
        NULL,
        1,
        N'WorkdayConcur-ConcurSshPrivateKeyPassPhrase'
    );
END;

IF EXISTS (SELECT 1 FROM dbo.FilesIntegration WHERE ID = N'FI-WORKDAY-CONCUR')
BEGIN
    UPDATE dbo.FilesIntegration
    SET IntegrationKey = N'TM1.csv',
        SourceSystem = N'Workday-TM1',
        Description = N'Workday employee export to Concur',
        ProjectName = N'WorkdayConcur',
        SchedulerName = N'WorkdayConcurTimerFunction',
        TokenAckRequired = 0,
        TokenFileName = NULL,
        UpdationDateTime = @Now,
        StartsWith = N'TM1',
        EndsWith = N'.csv',
        IsSynchronizedToken = 0,
        FileContainsFilter = N'TM1.csv'
    WHERE ID = N'FI-WORKDAY-CONCUR';
END
ELSE
BEGIN
    INSERT dbo.FilesIntegration
    (
        ID,
        IntegrationKey,
        SourceSystem,
        Description,
        ProjectName,
        SchedulerName,
        TokenAckRequired,
        TokenFileName,
        CreationDateTime,
        UpdationDateTime,
        StartsWith,
        EndsWith,
        IsSynchronizedToken,
        FileContainsFilter
    )
    VALUES
    (
        N'FI-WORKDAY-CONCUR',
        N'TM1.csv',
        N'Workday-TM1',
        N'Workday employee export to Concur',
        N'WorkdayConcur',
        N'WorkdayConcurTimerFunction',
        0,
        NULL,
        @Now,
        @Now,
        N'TM1',
        N'.csv',
        0,
        N'TM1.csv'
    );
END;

IF EXISTS (SELECT 1 FROM dbo.FileActions WHERE ID = N'FA-WORKDAY-TM1')
BEGIN
    UPDATE dbo.FileActions
    SET IntegrationKeyID = N'FI-WORKDAY-CONCUR',
        ActionName = N'PICKUP',
        SourceID = N'SFTP-WORKDAY-TM1',
        DestinationID = N'BLOB-WORKDAY-CONCUR',
        PipelineName = N'SFTP_To_Blob',
        SourceFileNameFormat = N'TM1.csv',
        SourceFolderPath = N'/prod/tm1serv/Exports',
        SourceArchive = 0,
        SourceArchivePath = NULL,
        DestinationFileNameFormat = N'TM1.csv',
        DestinationFolderPath = N'stdl-concur-tst-uks/input',
        RetryCount = 3,
        BlobTriggerPath = NULL,
        UpdationDateTime = @Now,
        SourceErrorPath = NULL,
        RetentionNoofDays = NULL,
        RetentionNoofFiles = NULL,
        SourceDelete = 0
    WHERE ID = N'FA-WORKDAY-TM1';
END
ELSE
BEGIN
    INSERT dbo.FileActions
    (
        ID,
        IntegrationKeyID,
        ActionName,
        SourceID,
        DestinationID,
        PipelineName,
        SourceFileNameFormat,
        SourceFolderPath,
        SourceArchive,
        SourceArchivePath,
        DestinationFileNameFormat,
        DestinationFolderPath,
        RetryCount,
        BlobTriggerPath,
        CreationDateTime,
        UpdationDateTime,
        SourceErrorPath,
        RetentionNoofDays,
        RetentionNoofFiles,
        SourceDelete
    )
    VALUES
    (
        N'FA-WORKDAY-TM1',
        N'FI-WORKDAY-CONCUR',
        N'PICKUP',
        N'SFTP-WORKDAY-TM1',
        N'BLOB-WORKDAY-CONCUR',
        N'SFTP_To_Blob',
        N'TM1.csv',
        N'/prod/tm1serv/Exports',
        0,
        NULL,
        N'TM1.csv',
        N'stdl-concur-tst-uks/input',
        3,
        NULL,
        @Now,
        @Now,
        NULL,
        NULL,
        NULL,
        0
    );
END;

IF EXISTS (SELECT 1 FROM dbo.FileActions WHERE ID = N'FA-WORKDAY-CONCUR')
BEGIN
    UPDATE dbo.FileActions
    SET IntegrationKeyID = N'FI-WORKDAY-CONCUR',
        ActionName = N'DROP',
        SourceID = N'BLOB-WORKDAY-CONCUR',
        DestinationID = N'SFTP-WORKDAY-CONCUR',
        PipelineName = N'Blob_To_SFTP_SSH',
        SourceFileNameFormat = N'*.pgp',
        SourceFolderPath = N'stdl-concur-tst-uks/delivery-staging',
        SourceArchive = 0,
        SourceArchivePath = NULL,
        DestinationFileNameFormat = NULL,
        DestinationFolderPath = N'/in/test',
        RetryCount = 3,
        BlobTriggerPath = NULL,
        UpdationDateTime = @Now,
        SourceErrorPath = NULL,
        RetentionNoofDays = NULL,
        RetentionNoofFiles = NULL,
        SourceDelete = 1
    WHERE ID = N'FA-WORKDAY-CONCUR';
END
ELSE
BEGIN
    INSERT dbo.FileActions
    (
        ID,
        IntegrationKeyID,
        ActionName,
        SourceID,
        DestinationID,
        PipelineName,
        SourceFileNameFormat,
        SourceFolderPath,
        SourceArchive,
        SourceArchivePath,
        DestinationFileNameFormat,
        DestinationFolderPath,
        RetryCount,
        BlobTriggerPath,
        CreationDateTime,
        UpdationDateTime,
        SourceErrorPath,
        RetentionNoofDays,
        RetentionNoofFiles,
        SourceDelete
    )
    VALUES
    (
        N'FA-WORKDAY-CONCUR',
        N'FI-WORKDAY-CONCUR',
        N'DROP',
        N'BLOB-WORKDAY-CONCUR',
        N'SFTP-WORKDAY-CONCUR',
        N'Blob_To_SFTP_SSH',
        N'*.pgp',
        N'stdl-concur-tst-uks/delivery-staging',
        0,
        NULL,
        NULL,
        N'/in/test',
        3,
        NULL,
        @Now,
        @Now,
        NULL,
        NULL,
        NULL,
        1
    );
END;

COMMIT TRANSACTION;
