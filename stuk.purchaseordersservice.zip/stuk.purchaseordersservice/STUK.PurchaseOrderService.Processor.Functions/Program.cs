using Azure.Identity;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.Processor;
using STUK.PurchaseOrderService.Processor.Email.Relex;
using Utilities.Repo.Contracts;
using Utilities.Repo.Services;
using Utility.Repo.Contracts;
using Utility.Repo.Services;

var builder = FunctionsApplication.CreateBuilder(args);
builder.ConfigureFunctionsWebApplication();

var azureKeyVaultUri = builder.Configuration[ConfigConstants.AzureKeyVaultUriSettingKey];
if (!string.IsNullOrWhiteSpace(azureKeyVaultUri))
{
    builder.Configuration.AddAzureKeyVault(
        new Uri(azureKeyVaultUri),
        new DefaultAzureCredential());
}

builder.Services.AddPurchaseOrderProcessor(builder.Configuration);
if (!string.IsNullOrWhiteSpace(
        builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"]))
{
    builder.Services.AddApplicationInsightsTelemetryWorkerService();
    builder.Services.ConfigureFunctionsApplicationInsights();
}
var sqlConnectionString = builder.Configuration["SqlConnectionString"];
if (string.IsNullOrEmpty(sqlConnectionString))
{
    throw new InvalidOperationException("The SQL connection string is not configured.");
}
builder.Services.AddSingleton<Utilities.Repo.Services.SqlConnectionFactory>(sp => async () =>
{
    var conn = new SqlConnection(sqlConnectionString);
    var credential = new DefaultAzureCredential();
    var token = await credential.GetTokenAsync(
       new Azure.Core.TokenRequestContext(new[] { "https://database.windows.net/.default" }));
    conn.AccessToken = token.Token;
    await conn.OpenAsync();
    return conn;
});
builder.Services.AddScoped<IDBSchedulerHandler, DBSchedulerHandler>();

builder.Services.AddScoped<ISynapseAnalyticsHelper, SynapseAnalyticsHelper>();

// Fixing the syntax issues and ensuring proper scoping
var azureMonitorDce = builder.Configuration["AZURE_MONITOR_DCE"];
var azureMonitorDcr = builder.Configuration["AZURE_MONITOR_DCR"];
var azureMonitorDcrTableName = builder.Configuration["AZURE_MONITOR_DCR_TableName"];

if (string.IsNullOrEmpty(azureMonitorDce) || string.IsNullOrEmpty(azureMonitorDcr) || string.IsNullOrEmpty(azureMonitorDcrTableName))
{
    throw new InvalidOperationException("One or more required configuration values are missing.");
}

builder.Services.AddScoped<ILogAnalyticsLoggerHelper>(LogAnalyticsLoggerHelper =>
    new LogAnalyticsLoggerHelper(
        azureMonitorDce,
        azureMonitorDcr,
        azureMonitorDcrTableName,
        new AppInsightsLoggerHelper()
    ));
var storageConnectionString = builder.Configuration["StorageConnectionString"];
if (string.IsNullOrEmpty(storageConnectionString))
{
    throw new InvalidOperationException("The storage Connection string is not configured.");
}
builder.Services.AddSingleton<SqlCacheConnectionFactory>(async () =>
{
    var conn = new SqlConnection(sqlConnectionString);
    var credential = new DefaultAzureCredential();
    var token = await credential.GetTokenAsync(
        new Azure.Core.TokenRequestContext(new[] { "https://database.windows.net/.default" }));
    conn.AccessToken = token.Token;
    await conn.OpenAsync();
    return conn;
});

builder.Services.AddSingleton<ISqlCacheService, SqlCacheService>();
builder.Services.AddSingleton<IAppInsightsLoggerHelper, AppInsightsLoggerHelper>();
builder.Services.AddScoped<IBlobServiceHelper, BlobServiceHelper>();
//builder.Services.AddScoped<IRelexNotificationProducer, RelexNotificationProducer>();
builder.Services.Configure<EmailSenderSettings>(
    builder.Configuration.GetSection("EmailSender"));

builder.Services.AddScoped<IEmailService, EmailService>();

//builder.Services.AddScoped<IStoredProcedureExecutor, StoredProcedureExecutor>();
builder.Build().Run();
