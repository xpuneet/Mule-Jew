using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Processor.Processing;

namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public sealed class ReadyPurchaseOrdersProcessor
{
    private readonly ILogger<ReadyPurchaseOrdersProcessor> _logger;
    private readonly IPurchaseOrderProcessor _purchaseOrderProcessor;

    public ReadyPurchaseOrdersProcessor(
        IPurchaseOrderProcessor purchaseOrderProcessor,
        ILogger<ReadyPurchaseOrdersProcessor> logger)
    {
        _purchaseOrderProcessor = purchaseOrderProcessor;
        _logger = logger;
    }

    [Function(nameof(ReadyPurchaseOrdersProcessor))]
    public async Task Run(
        [TimerTrigger("%ReadyCandidatesProcessorCronExpression%")] TimerInfo timerInfo,
        CancellationToken cancellationToken)
    {
        _logger.LogInformation("Ready purchase order candidate processor fired at {Timestamp}.", DateTimeOffset.UtcNow);

        var result = await _purchaseOrderProcessor.ProcessReadyCandidatesAsync(cancellationToken);

        _logger.LogInformation(
            "Ready purchase order candidate processor completed. Processed={ProcessedCount}, Submitted={SubmittedCount}, Failed={FailedCount}.",
            result.ProcessedCount,
            result.SubmittedCount,
            result.FailedCount);
    }
}
