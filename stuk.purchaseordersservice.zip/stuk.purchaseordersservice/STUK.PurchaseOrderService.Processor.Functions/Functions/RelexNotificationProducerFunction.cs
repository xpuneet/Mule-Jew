using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Email.Relex;

namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public sealed class RelexNotificationProducerFunction
{
    private readonly IRelexNotificationProducer _producer;
    private readonly ILogger<RelexNotificationProducerFunction> _logger;

    public RelexNotificationProducerFunction(
        IRelexNotificationProducer producer,
        ILogger<RelexNotificationProducerFunction> logger)
    {
        _producer = producer;
        _logger = logger;
    }

    [Function(nameof(RelexNotificationProducerFunction))]
    public async Task Run(
        [TimerTrigger("%" + ConfigConstants.RelexNotificationProducerCronExpressionSettingKey + "%")] TimerInfo timerInfo,
        CancellationToken cancellationToken)
    {
        var result = await _producer.ProcessAsync(cancellationToken);
        _logger.LogInformation(
            "Relex notification producer run completed. Claimed={ClaimedCount}, Enqueued={EnqueuedCount}, Failed={FailedCount}.",
            result.ClaimedCount,
            result.EnqueuedCount,
            result.FailedCount);
    }
}
