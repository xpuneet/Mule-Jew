using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Processor.Email.Processing;

namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public sealed class EmailNotificationSenderFunction
{
    private readonly IEmailNotificationProcessor _processor;
    private readonly ILogger<EmailNotificationSenderFunction> _logger;

    public EmailNotificationSenderFunction(
        IEmailNotificationProcessor processor,
        ILogger<EmailNotificationSenderFunction> logger)
    {
        _processor = processor;
        _logger = logger;
    }

    [Function(nameof(EmailNotificationSenderFunction))]
    public async Task Run(
        [TimerTrigger("%EmailNotificationSenderCronExpression%")] TimerInfo timerInfo,
        CancellationToken cancellationToken)
    {
        _logger.LogInformation("Email notification sender run started.");
        await _processor.ProcessAsync(cancellationToken);
    }
}
