using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Processor.Relex.Processing;

namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public sealed class RelexPurchaseOrderIngestionFunction
{
    private readonly IRelexIngestionService _service;
    private readonly ILogger<RelexPurchaseOrderIngestionFunction> _logger;

    public RelexPurchaseOrderIngestionFunction(
        IRelexIngestionService service,
        ILogger<RelexPurchaseOrderIngestionFunction> logger)
    {
        _service = service;
        _logger = logger;
    }

    [Function(nameof(RelexPurchaseOrderIngestionFunction))]
    public async Task Run(
        [TimerTrigger("%RelexIngestionCronExpression%")] TimerInfo timerInfo,
        CancellationToken cancellationToken)
    {
        _logger.LogInformation("Relex ingestion run started.");
        var result = await _service.RunAsync(cancellationToken);
        _logger.LogInformation(
            "Relex ingestion run completed. Discovered={Discovered}, Deferred={Deferred}, Ignored={Ignored}, Archived={Archived}, FailedFiles={FailedFiles}, TransientFailures={TransientFailures}.",
            result.Discovered,
            result.Deferred,
            result.Ignored,
            result.Archived,
            result.FailedFiles,
            result.TransientFailures);
    }
}
