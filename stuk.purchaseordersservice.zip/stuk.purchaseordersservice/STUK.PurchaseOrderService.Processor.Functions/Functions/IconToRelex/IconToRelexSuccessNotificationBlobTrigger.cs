using Azure.Storage.Blobs.Models;
using Microsoft.Azure.Functions.Worker;
using Newtonsoft.Json;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Relex;
using Utilities.Model.Models;
using Utilities.Models;
using Utilities.Repo.Contracts;
using Utilities.Repo.Services;
using Utility.Repo.Contracts;
using static Utility.Repo.Constants.Constants;


namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public class IconToRelexSuccessNotificationBlobTrigger
{
    private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
    private readonly IDBSchedulerHandler _dbSchedulerHandler;
    private readonly ISynapseAnalyticsHelper _synapseAnalyticsHelper;
    private readonly ILogAnalyticsLoggerHelper _logAnalyticsLoggerHelper;
    private readonly IBlobServiceHelper _blobServiceHelper;
    private readonly IEmailService _emailService;


    public IconToRelexSuccessNotificationBlobTrigger(IEmailService emailService, IAppInsightsLoggerHelper appInsightsLoggerHelper, IDBSchedulerHandler dbSchedulerHandler, ISynapseAnalyticsHelper synapseAnalyticsHelper, ILogAnalyticsLoggerHelper logAnalyticsLoggerHelper, IBlobServiceHelper blobServiceHelper)
    {
        _dbSchedulerHandler = dbSchedulerHandler;
        _synapseAnalyticsHelper = synapseAnalyticsHelper;
        _logAnalyticsLoggerHelper = logAnalyticsLoggerHelper;
        _appInsightsLoggerHelper = appInsightsLoggerHelper;
        _blobServiceHelper = blobServiceHelper;
        _emailService = emailService;

    }

    [Function(nameof(IconToRelexSuccessNotificationBlobTrigger))]
    public async Task Run([BlobTrigger("%IconToRelexBlobTokenPath%/{name}", Connection = "StorageConnectionString")] Stream stream, string name)
    {
        var loggerDataList = new List<LogDataCollector>();
        string? correlationId = null;
        string? retryCount = string.Empty;

        try
        {
            var stagingPath = Environment.GetEnvironmentVariable("IconToRelexBlobTokenPath");
            // Get storage account URL from configuration or environment variable
            var storageAccountUrl = Environment.GetEnvironmentVariable("StorageAccountUrl");
            if (string.IsNullOrEmpty(storageAccountUrl))
                throw new InvalidOperationException("StorageAccountUrl is not configured.");
            if (string.IsNullOrEmpty(stagingPath))
                throw new InvalidOperationException("stagingPath is not configured.");

            var connectionString = Environment.GetEnvironmentVariable("StorageConnectionString");
            var blob = new Azure.Storage.Blobs.BlobClient(connectionString, stagingPath, name);
            BlobProperties properties = await blob.GetPropertiesAsync();

            // Try to get CorrelationID from metadata, fallback to new GUID if not found
            if (properties.Metadata.TryGetValue("CorrelationID", out var metaCorrelationId) && !string.IsNullOrWhiteSpace(metaCorrelationId))
            {
                correlationId = metaCorrelationId;
            }
            else
            {
                correlationId = Guid.NewGuid().ToString();
            }
            if (properties.Metadata.TryGetValue("RetryCount", out var metaRetryCount) && !string.IsNullOrWhiteSpace(metaRetryCount))
            {
                retryCount = metaRetryCount;
            }

            _appInsightsLoggerHelper.LogTrace(correlationId, FileIntegrationConstants.ServiceName, FileIntegrationConstants.SourceSystemStaging, "Run", "BlobTrigger", "Icon To Relex BlobTrigger function started.");
            loggerDataList.Add(new LogDataCollector
            {
                CorrelationId = correlationId,
                TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                ServiceName = FileIntegrationConstants.ServiceName,
                FileActionType = FunctionNames.DROP,
                SourceSystemFilePath = "",
                OperationName = "Run",
                LogMessage = "Icon To Relex Success Notification blob trigger started.",
                LogDetail = $"Icon To Relex Success Notification started execution at {DateTime.UtcNow}",
                LogType = FunctionNames.Info,
                InputFileName = name,
                OutputFileName = "",
                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                TargetSystem = "",
                TargetSystemFilePath = "",
                ReceivedDatetime = DateTime.UtcNow,
                ProcessedDatetime = DateTime.UtcNow,
                SentDatetime = DateTime.UtcNow,
                IsEmailNotification = false,
                FileProcessingStatus = FileStatus.Started.ToString(),
                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
            });
            string datetime= DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fff") + " [Europe/London]";

        string htmlTemplate = 
                $"""
                                <html><head> 
                <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
                </head> 
                <body bgcolor="White" text="Black">
                <table style="font-family : Arial, Helvetica, sans-serif; padding: 5pt; border-collapse: collapse; width: 740px"> 
                <tbody><tr> 
                <td style="font-family : Arial, Helvetica, sans-serif; font-size:180%; border: 1px solid black; font-weight: bold; text-align: left; vertical-align: top; background-color: #009e22; color: white; height: 23px;" colspan="2">Relex File Movement Success</td> 
                </tr>
                <tr> 
                <td style="font-family : Arial, Helvetica, sans-serif; font-weight: bold; border-left: 1px solid black; border-right: 1px solid black; text-align: left; vertical-align: top; background-color: #ffffff; color: black; height: 23px;">Filename:</td><td style="font-family : Arial, Helvetica, sans-serif; font-weight: normal; border-left: 1px solid black; border-right: 1px solid black; text-align: left; vertical-align: top; background-color: #ffffff; color: black; height: 23px;">{name}</td>
                </tr>
                <tr> 
                <td style="font-family : Arial, Helvetica, sans-serif; font-weight: bold; border-left: 1px solid black; border-right: 1px solid black; text-align: left; vertical-align: top; background-color: #ffffff; color: black; height: 23px;">Date and Time:</td><td style="font-family : Arial, Helvetica, sans-serif; font-weight: normal; border-left: 1px solid black; border-right: 1px solid black; text-align: left; vertical-align: top; background-color: #ffffff; color: black; height: 23px;">{datetime}</td> 
                </tr>
                </tbody></table> 
                <table style="font-family : Arial, Helvetica, sans-serif; padding: 5pt; border: 1px solid black; border-collapse: collapse; width: 740px"> 
                <tbody> 
                <tr> 
                <td style="font-family : Arial, Helvetica, sans-serif; font-weight: bold; text-align: left; vertical-align: top; background-color: #ffffff; color: black; height: 23px;" colspan="12">Message:</td> 
                </tr> 
                <tr> 
                <td style="font-family : Arial, Helvetica, sans-serif; font-weight: normal; text-align: left; vertical-align: top; background-color: #ffffff; color: black; height: 23px;" colspan="12">The file has processed successfully. No further action is required.</td> 
                </tr>
                </tbody></table> 
                </body></html>
                """;

            string emailSubject = Environment.GetEnvironmentVariable("IconToRelexSuccessSubject");
            var recipients = Environment
                .GetEnvironmentVariable("RelexNotifications__Recipients")?
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                ?? Array.Empty<string>();            //_producer.EnqueueEmailAsync(correlationId, "mulesoft.stuk@erp.starkbuild.co.uk", new[] { "ext.ramaraju.jampanaswamyvenkata@starkbuild.co.uk" }, "Success Mail", htmlTemplate, "Relex_success", DateTimeOffset.UtcNow, new CancellationToken());
            int maxRetries = int.TryParse(
    Environment.GetEnvironmentVariable("EmailNotificationMaxRetry"),
    out var retries)
        ? retries
        : 3;

            int retryDelaySeconds = int.TryParse(
                Environment.GetEnvironmentVariable("EmailNotificationRetryDelay"),
                out var delay)
                    ? delay
                    : 30;
            loggerDataList.Add(new LogDataCollector
            {
                CorrelationId = correlationId,
                TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                ServiceName = FileIntegrationConstants.ServiceName,
                FileActionType = FunctionNames.DROP,
                SourceSystemFilePath = "",
                OperationName = "Run",
                LogMessage = "Initiating Mail for Icon To Relex Success Notification",
                LogDetail = "Initiating Mail for Icon To Relex Success Notification",
                LogType = FunctionNames.Info,
                InputFileName = name,
                OutputFileName = "",
                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                TargetSystem = "",
                TargetSystemFilePath = "",
                ReceivedDatetime = DateTime.UtcNow,
                ProcessedDatetime = DateTime.UtcNow,
                SentDatetime = DateTime.UtcNow,
                IsEmailNotification = false,
                FileProcessingStatus = FileStatus.Started.ToString(),
                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
            });
            EmailSendResponse emailResponse;
            for (int attempt = 1; attempt <= maxRetries; attempt++)
            {
                try
                {
                    emailResponse=await _emailService.SendAsync(
                        emailSubject,
                        recipients,
                        htmlTemplate);
                    if (emailResponse.IsSuccess)
                    {
                        await blob.DeleteIfExistsAsync();
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = correlationId,
                            TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                            ServiceName = FileIntegrationConstants.ServiceName,
                            FileActionType = FunctionNames.DROP,
                            OperationName = "SendEmail",
                            LogMessage = "Email notification sent successfully.",
                            LogDetail = $"Email sent successfully on attempt {attempt}.",
                            LogType = FunctionNames.Info,
                            InputFileName = name,
                            SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                            ReceivedDatetime = DateTime.UtcNow,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = true,
                            FileProcessingStatus = FileStatus.Completed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                        });

                        break;
                    }
                    else
                    {
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = correlationId,
                            TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                            ServiceName = FileIntegrationConstants.ServiceName,
                            FileActionType = FunctionNames.DROP,
                            OperationName = "SendEmail",
                            LogMessage = $"Email send attempt {attempt} failed with reason {emailResponse.Message}",
                            LogDetail = $"{emailResponse.Message}",
                            LogType = FunctionNames.Error,
                            InputFileName = name,
                            SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                            ReceivedDatetime = DateTime.UtcNow,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = true,
                            FileProcessingStatus = FileStatus.Failed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                        });

                    }
                }
                catch (Exception ex)
                {
                    loggerDataList.Add(new LogDataCollector
                    {
                        CorrelationId = correlationId,
                        TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                        ServiceName = FileIntegrationConstants.ServiceName,
                        FileActionType = FunctionNames.DROP,
                        OperationName = "SendEmail",
                        LogMessage = $"Email send attempt {attempt} failed.",
                        LogDetail = ex.ToString(),
                        LogType = FunctionNames.Error,
                        InputFileName = name,
                        SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                        ReceivedDatetime = DateTime.UtcNow,
                        ProcessedDatetime = DateTime.UtcNow,
                        SentDatetime = DateTime.UtcNow,
                        IsEmailNotification = true,
                        FileProcessingStatus = FileStatus.Failed.ToString(),
                        SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                    });
                    if (attempt == maxRetries)
                    {
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = correlationId,
                            TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                            ServiceName = FileIntegrationConstants.ServiceName,
                            FileActionType = FunctionNames.DROP,
                            OperationName = "SendEmail",
                            LogMessage = "Email notification failed after all retry attempts.",
                            LogDetail = ex.ToString(),
                            LogType = FunctionNames.Error,
                            InputFileName = name,
                            SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                            ReceivedDatetime = DateTime.UtcNow,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = true,
                            FileProcessingStatus = FileStatus.Failed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                        });

                        break; // don't throw
                    }


                    await Task.Delay(TimeSpan.FromSeconds(retryDelaySeconds));
                }
            }
        }

        catch (Exception ex)
        {
            // Log: Exception
            loggerDataList.Add(new LogDataCollector
            {
                CorrelationId = correlationId,
                TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                ServiceName = FileIntegrationConstants.ServiceName,
                FileActionType = FunctionNames.DROP,
                SourceSystemFilePath = "",
                OperationName = "Run",
                LogMessage = "Exception in Icon To Relex Blob Trigger function.",
                LogDetail = $"Function failed with exception: {ex}",
                LogType = FunctionNames.Error,
                InputFileName = "",
                OutputFileName = "",
                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                TargetSystem = FunctionNames.DeliveryStaging,
                TargetSystemFilePath = "",
                ReceivedDatetime = DateTime.UtcNow,
                ProcessedDatetime = DateTime.UtcNow,
                SentDatetime = DateTime.UtcNow,
                IsEmailNotification = false,
                FileProcessingStatus = FileStatus.Failed.ToString(),
                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
            });
            _appInsightsLoggerHelper.LogTrace(correlationId!, FileIntegrationConstants.ServiceName, FileIntegrationConstants.SourceSystemStaging, "Run", "BlobTrigger", $"An error occurred while processing the Blob trigger {ex.Message}.");

        }
        finally
        {
            _logAnalyticsLoggerHelper.SendLogEntriesAsync(JsonConvert.SerializeObject(loggerDataList));
            _appInsightsLoggerHelper.LogTrace(correlationId!, FileIntegrationConstants.ServiceName, FileIntegrationConstants.SourceSystemStaging, "Run", "BlobTrigger", $"Icon To Relex Blob trigger function completed at: {DateTime.UtcNow}");

        }
    }
}