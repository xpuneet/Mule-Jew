using Microsoft.Azure.Functions.Worker;
using Newtonsoft.Json;
using Utilities.Model.Models;
using Utilities.Models;
using Utilities.Repo.Contracts;
using Utility.Repo.Contracts;
using static Utility.Repo.Constants.Constants;
using STUK.PurchaseOrderService.Common.Contracts.Config;
namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public class RetryFailedFilesTimerTrigger
{
    private readonly IBlobServiceHelper _blobServiceHelper;
    private readonly ILogAnalyticsLoggerHelper _logAnalyticsLoggerHelper;
    public RetryFailedFilesTimerTrigger(IBlobServiceHelper blobServiceHelper, ILogAnalyticsLoggerHelper logAnalyticsLoggerHelper)
    {
        _blobServiceHelper = blobServiceHelper;
        _logAnalyticsLoggerHelper = logAnalyticsLoggerHelper;
    }

    [Function("RetryFailedFilesTimerTrigger")]
    public async Task Run([TimerTrigger("%RetryFailedFilesTimerTriggerCron%")] TimerInfo myTimer)
    {
        var loggerDataList = new List<LogDataCollector>();
        string? correlationId = null;
        var thresholdStr = Environment.GetEnvironmentVariable("BlobFileAgeThresholdMinutes");
        if (thresholdStr == null)
            thresholdStr = "15";
        int.TryParse(thresholdStr, out int ageThresholdMinutes);
        var logContext = new LoggingContext
        {
            CorrelationId = correlationId,
            LoggerDataList = loggerDataList,
            SchedulerName = "",
            ServiceName = FileIntegrationConstants.ServiceName,
            TriggerName = "RetryFailedFilesTimerTrigger",
            FileActionType = ""
        };
        var schedulersName = new List<string>
                            {
                                FileIntegrationConstants.IconToRelexSchedulerName
        };
                               
        // Get the excludeSchedulers environment variable (a comma-separated list of schedulers to exclude)
        var excludeSchedulers = Environment.GetEnvironmentVariable("excludeSchedulers");
        if (!string.IsNullOrEmpty(excludeSchedulers))
        {
            // Convert the excludeSchedulers string into a list of strings
            var excludeList = excludeSchedulers.Split('|', StringSplitOptions.RemoveEmptyEntries)
                                               .Select(s => s.Trim())
                                               .ToList();

            // Exclude the schedulers listed in the excludeList from schedulersName
            schedulersName = schedulersName.Where(scheduler => !excludeList.Contains(scheduler)).ToList();
        }

        string storageAccountUrl = Environment.GetEnvironmentVariable("StorageAccountUrl")!;
        try
        {
            await _blobServiceHelper.ReProcessStagedFile(schedulersName, storageAccountUrl, ageThresholdMinutes, logContext);
        }
        catch (Exception ex)
        {
            loggerDataList.Add(new LogDataCollector
            {
                CorrelationId = logContext.CorrelationId,
                ServiceName = FileIntegrationConstants.ServiceName,
                OperationName = "Run",
                LogMessage = "Exception in RetryFailedFilesTimerTrigger function.",
                LogDetail = $"Function failed with exception: {ex}",
                LogType = FunctionNames.Error,
                InputFileName = "",
                OutputFileName = "",
                SourceSystem = "",
                TargetSystem = "",
                TargetSystemFilePath = "",
                ReceivedDatetime = null,
                ProcessedDatetime = DateTime.UtcNow,
                SentDatetime = DateTime.UtcNow,
                IsEmailNotification = false,
                FileProcessingStatus = FileStatus.Failed.ToString(),
                SchedulerName = "",
                TriggerName = logContext.TriggerName,
                SourceSystemFilePath = logContext.SourceSystemFilePath,
                FileActionType = logContext.FileActionType
            });
        }
        finally
        {
            _logAnalyticsLoggerHelper.SendLogEntriesAsync(JsonConvert.SerializeObject(loggerDataList));

        }
    }
}
