using Microsoft.Azure.Functions.Worker;
using Newtonsoft.Json;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using Utilities.Model.Models;
using Utilities.Models;
using Utilities.Repo.Contracts;
using Utilities.Repo.Services;
using Utility.Repo.Contracts;
using static Utility.Repo.Constants.Constants;
namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public class IconToRelexTimerTrigger
{
    private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
    private readonly IDBSchedulerHandler _dbSchedulerHandler;
    private readonly ISynapseAnalyticsHelper _synapseAnalyticsHelper;
    private readonly ILogAnalyticsLoggerHelper _logAnalyticsLoggerHelper;
    private readonly ISqlCacheService _sqlCacheService;
    public IconToRelexTimerTrigger(IAppInsightsLoggerHelper appInsightsLoggerHelper, IDBSchedulerHandler dbSchedulerHandler, ISynapseAnalyticsHelper synapseAnalyticsHelper, ILogAnalyticsLoggerHelper logAnalyticsLoggerHelper, ISqlCacheService sqlCacheService)
    {
        _dbSchedulerHandler = dbSchedulerHandler;
        _synapseAnalyticsHelper = synapseAnalyticsHelper;
        _logAnalyticsLoggerHelper = logAnalyticsLoggerHelper;
        _appInsightsLoggerHelper = appInsightsLoggerHelper;
        _sqlCacheService = sqlCacheService;
    }

    [Function("IconToRelexTimerTrigger")]
    public async Task RunAsync([TimerTrigger("%IconToRelexTimerTrigger%")] TimerInfo myTimer)
    {
        var loggerDataList = new List<LogDataCollector>();
        var correlationId = Guid.NewGuid().ToString();
        _appInsightsLoggerHelper.LogTrace(correlationId, FileIntegrationConstants.ServiceName, FileIntegrationConstants.SourceSystemIcon, "Run", "TimerTrigger", "Icon To Relex function started.");

        loggerDataList.Add(new LogDataCollector
        {
            CorrelationId = correlationId,
            TriggerName = "IconToRelexTimerTrigger",
            ServiceName = FileIntegrationConstants.ServiceName,
            FileActionType = FunctionNames.PICKUP,
            SourceSystemFilePath = "",
            OperationName = "Run",
            LogDetail = "Icon To Relex TimerTrigger started execution.",
            LogMessage = $"Icon To Relex timer trigger started execution at {DateTime.UtcNow}.",
            LogType = FunctionNames.Info,
            InputFileName = "",
            OutputFileName = "",
            SourceSystem = FileIntegrationConstants.SourceSystemIcon,
            TargetSystem = "",
            TargetSystemFilePath = "",
            ReceivedDatetime = DateTime.UtcNow,
            ProcessedDatetime = null,
            SentDatetime = DateTime.UtcNow,
            IsEmailNotification = false,
            FileProcessingStatus = FileStatus.Started.ToString(),
            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
        });
        var logContext = new LoggingContext
        {
            CorrelationId = correlationId,
            LoggerDataList = loggerDataList,
            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName,
            ServiceName = FileIntegrationConstants.ServiceName,
            TriggerName = "IconToRelexTimerTrigger",
            FileActionType = FunctionNames.PICKUP
        };

        try
        {
            List<FilesIntegration> filesIntegration = await _dbSchedulerHandler.GetFilesIntegrationKeysAsync(FileIntegrationConstants.IconToRelexSchedulerName, logContext);

            foreach (var integration in filesIntegration)
            {
                if (!string.Equals(integration.SourceSystem, FileIntegrationConstants.SourceSystemIcon, StringComparison.OrdinalIgnoreCase))
                    continue;
                var fileActions = await _dbSchedulerHandler.GetFTConnectionByIntegrationKeyAsync(integration.ID, FunctionNames.PICKUP, logContext);
                if (fileActions == null)
                {
                    loggerDataList.Add(new LogDataCollector
                    {
                        CorrelationId = correlationId,
                        TriggerName = "IconToRelexTimerTrigger",
                        ServiceName = FileIntegrationConstants.ServiceName,
                        FileActionType = FunctionNames.PICKUP,
                        SourceSystemFilePath = fileActions?.SourceFolderPath ?? string.Empty,
                        OperationName = "Run",
                        LogMessage = $"No FileActions found for IntegrationKey: {integration.IntegrationKey}",
                        LogDetail = "No FileActions returned from DB.",
                        LogType = FunctionNames.Error,
                        InputFileName = integration.IntegrationKey,
                        OutputFileName = "",
                        SourceSystem = FileIntegrationConstants.SourceSystemIcon,
                        TargetSystem = "",
                        TargetSystemFilePath = "",
                        ReceivedDatetime = DateTime.UtcNow,
                        ProcessedDatetime = DateTime.UtcNow,
                        SentDatetime = DateTime.UtcNow,
                        IsEmailNotification = false,
                        FileProcessingStatus = FileStatus.Failed.ToString(),
                        SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                    });
                    continue;
                }

                var fileActionExecutions = new FileActionExecutions
                {
                    FileActionID = fileActions.ID,
                    CorrelationID = Guid.Parse(correlationId),
                    ProcessDate = DateOnly.FromDateTime(DateTime.UtcNow),
                    Status = FileStatus.Started,
                    TokenFileName = null,
                    TokenSent = false
                };

                var executionId = await _dbSchedulerHandler.InsertExecutionStatus(fileActionExecutions, logContext);
                var sftpConnectionConfig = await _dbSchedulerHandler.GetSFTPConnectionConfigBySourceID(fileActions.SourceID, logContext);
                var blobConnectionConfig = await _dbSchedulerHandler.GetBlobConnectionConfigByDestinationID(fileActions.DestinationID, logContext);

                if (sftpConnectionConfig == null || blobConnectionConfig == null)
                {
                    loggerDataList.Add(new LogDataCollector
                    {
                        CorrelationId = correlationId,
                        TriggerName = "IconToRelexTimerTrigger",
                        ServiceName = FileIntegrationConstants.ServiceName,
                        FileActionType = FunctionNames.PICKUP,
                        SourceSystemFilePath = fileActions?.SourceFolderPath ?? string.Empty,
                        OperationName = "Run",
                        LogMessage = $"Missing connection config for IntegrationKey: {integration.IntegrationKey}",
                        LogDetail = $"SFTP or Blob config is null. SFTP: {(sftpConnectionConfig == null ? "null" : "ok")}, Blob: {(blobConnectionConfig == null ? "null" : "ok")}",
                        LogType = FunctionNames.Error,
                        InputFileName = integration.IntegrationKey,
                        OutputFileName = "",
                        SourceSystem = FileIntegrationConstants.SourceSystemIcon,
                        TargetSystem = "",
                        TargetSystemFilePath = "",
                        ReceivedDatetime = DateTime.UtcNow,
                        ProcessedDatetime = DateTime.UtcNow,
                        SentDatetime = DateTime.UtcNow,
                        IsEmailNotification = false,
                        FileProcessingStatus = FileStatus.Failed.ToString(),
                        SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                    });
                    continue;
                }

                var parameter = new
                {
                    SourceFilePath = fileActions.SourceFolderPath,
                    DestinationFilePath = fileActions.DestinationFolderPath,
                    Id = executionId,
                    DestinationFileFormat = fileActions.DestinationFileNameFormat,
                    fileActionExecutions.CorrelationID,
                    IsArchive = fileActions.SourceArchive,
                    ArchivePath = fileActions.SourceArchivePath,
                    FileStartFilter = integration.StartsWith ?? "",
                    FileEndFilter = integration.EndsWith ?? "",
                    ErrorPath = fileActions.SourceErrorPath,
                    SourceHost = sftpConnectionConfig!.IPAddress,
                    SourceUsername = sftpConnectionConfig!.Username,
                    SourcePassword = sftpConnectionConfig!.PasswordKey,
                    DestinationAccountName = blobConnectionConfig!.StorageName,
                    DestinationAccountKey = blobConnectionConfig!.ClientSecretKey,
                    DestinationStorageAccountEndPoint = blobConnectionConfig.ServiceEndPoint,
                    FileAction = FunctionNames.PICKUP,
                    fileActions.SourceDelete,
                    TriggeredByFnApp = Environment.GetEnvironmentVariable("functionAppName"),
                    TriggeredBySchedulerName = "IconToRelexTimerTrigger",
                    integration.FileContainsFilter
                };

                var synapseWorkspace = Environment.GetEnvironmentVariable("Synapse_Workspace");
                if (string.IsNullOrEmpty(synapseWorkspace))
                {
                    loggerDataList.Add(new LogDataCollector
                    {
                        CorrelationId = logContext.CorrelationId,
                        ServiceName = FileIntegrationConstants.ServiceName,
                        OperationName = "Run",
                        LogMessage = "Synapse workspace environment variable is not set.",
                        LogDetail = "Environment variable 'Synapse-workspace' is null or empty.",
                        LogType = FunctionNames.Error,
                        InputFileName = fileActions.SourceFileNameFormat,
                        OutputFileName = fileActions.DestinationFileNameFormat,
                        SourceSystem = FileIntegrationConstants.SourceSystemIcon,
                        TargetSystem = FunctionNames.DeliveryStaging,
                        TargetSystemFilePath = fileActions.DestinationFolderPath,
                        ReceivedDatetime = null,
                        ProcessedDatetime = DateTime.UtcNow,
                        SentDatetime = null,
                        IsEmailNotification = false,
                        FileProcessingStatus = FileStatus.Failed.ToString(),
                        SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName,
                        TriggerName = logContext.TriggerName,
                        SourceSystemFilePath = logContext.SourceSystemFilePath,
                        FileActionType = FunctionNames.PICKUP
                    });
                    continue;
                }
                string? prevRunId = await _sqlCacheService.GetFromCache(fileActions.ID);
                string? prevRunStatus = null;
                if (!string.IsNullOrEmpty(prevRunId))
                {
                    prevRunStatus = await _synapseAnalyticsHelper.GetPipelineStatus(prevRunId, synapseWorkspace!);
                }
                if ((prevRunStatus != "InProgress" && prevRunStatus != "Queued") || prevRunStatus == null)
                {
                    var runid = await _synapseAnalyticsHelper.TriggerSynapsePipelineWithRunId(synapseWorkspace, fileActions.PipeLineName, parameter, logContext);
                    await _sqlCacheService.SetCacheAsync(fileActions.ID, runid, TimeSpan.FromDays(1));
                    if (runid != null)
                    {
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = logContext.CorrelationId,
                            ServiceName = FileIntegrationConstants.ServiceName,
                            OperationName = "Run",
                            LogMessage = "Synapse pipeline triggered successfully and function is completed.",
                            LogDetail = $"Synapse pipeline triggered at {DateTime.UtcNow}",
                            LogType = FunctionNames.Info,
                            InputFileName = fileActions.SourceFileNameFormat,
                            OutputFileName = fileActions.DestinationFileNameFormat,
                            SourceSystem = FileIntegrationConstants.SourceSystemIcon,
                            TargetSystem = FunctionNames.DeliveryStaging,
                            TargetSystemFilePath = fileActions.DestinationFolderPath ?? string.Empty,
                            ReceivedDatetime = null,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = false,
                            FileProcessingStatus = FileStatus.Completed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName,
                            TriggerName = logContext.TriggerName,
                            SourceSystemFilePath = logContext.SourceSystemFilePath,
                            FileActionType = FunctionNames.PICKUP
                        });
                        fileActionExecutions = new FileActionExecutions
                        {
                            FileActionID = fileActions.ID,
                            CorrelationID = Guid.Parse(correlationId),
                            ProcessDate = DateOnly.FromDateTime(DateTime.UtcNow),
                            Status = FileStatus.Completed,
                            TokenFileName = null,
                            TokenSent = false
                        };
                        await _dbSchedulerHandler.InsertExecutionStatus(fileActionExecutions, logContext);
                    }
                    else
                    {
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = logContext.CorrelationId,
                            ServiceName = FileIntegrationConstants.ServiceName,
                            OperationName = "Run",
                            LogMessage = "Synapse pipeline trigger failed.",
                            LogDetail = $"Synapse pipeline triggered at {DateTime.UtcNow}",
                            LogType = FunctionNames.Error,
                            InputFileName = fileActions.SourceFileNameFormat,
                            OutputFileName = fileActions.DestinationFileNameFormat,
                            SourceSystem = FileIntegrationConstants.SourceSystemIcon,
                            TargetSystem = FunctionNames.DeliveryStaging,
                            TargetSystemFilePath = fileActions.DestinationFolderPath ?? string.Empty,
                            ReceivedDatetime = null,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = false,
                            FileProcessingStatus = FileStatus.Failed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName,
                            TriggerName = logContext.TriggerName,
                            SourceSystemFilePath = logContext.SourceSystemFilePath,
                            FileActionType = FunctionNames.PICKUP
                        });
                    }
                    _appInsightsLoggerHelper.LogTrace(correlationId, FileIntegrationConstants.ServiceName, logContext.TriggerName, "Run", "TimerTrigger", $"Processed IntegrationKey: {integration.IntegrationKey}");
                }
                else
                {
                    loggerDataList.Add(new LogDataCollector
                    {
                        CorrelationId = logContext.CorrelationId,
                        ServiceName = FileIntegrationConstants.ServiceName,
                        OperationName = "Run",
                        LogMessage = "Synapse pipeline trigger Skipped.",
                        LogDetail = $"Synapse pipeline triggered Skipped due to previous pipeline is running",
                        LogType = FunctionNames.Error,
                        InputFileName = fileActions.SourceFileNameFormat,
                        OutputFileName = fileActions.DestinationFileNameFormat,
                        SourceSystem = FileIntegrationConstants.SourceSystemIcon,
                        TargetSystem = FunctionNames.DeliveryStaging,
                        TargetSystemFilePath = fileActions.DestinationFolderPath ?? string.Empty,
                        ReceivedDatetime = null,
                        ProcessedDatetime = DateTime.UtcNow,
                        SentDatetime = DateTime.UtcNow,
                        IsEmailNotification = false,
                        FileProcessingStatus = "Skipped",
                        SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName,
                        TriggerName = logContext.TriggerName,
                        SourceSystemFilePath = logContext.SourceSystemFilePath,
                        FileActionType = FunctionNames.PICKUP
                    });

                }
            }
        }
        catch (Exception ex)
        {
            loggerDataList.Add(new LogDataCollector
            {
                CorrelationId = correlationId,
                TriggerName = "IconToRelexTimerTrigger",
                ServiceName = FileIntegrationConstants.ServiceName,
                FileActionType = FunctionNames.PICKUP,
                SourceSystemFilePath = "",
                OperationName = "Run",
                LogMessage = "Exception in Icon To Relex function.",
                LogDetail = $"Function failed with exception: {ex}",
                LogType = FunctionNames.Error,
                InputFileName = "",
                OutputFileName = "",
                SourceSystem = FileIntegrationConstants.SourceSystemIcon,
                TargetSystem = FunctionNames.DeliveryStaging,
                TargetSystemFilePath = "",
                ReceivedDatetime = DateTime.UtcNow,
                ProcessedDatetime = DateTime.UtcNow,
                SentDatetime = DateTime.UtcNow,
                IsEmailNotification = false,
                FileProcessingStatus = FileStatus.Failed.ToString(),
                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
            });
            _appInsightsLoggerHelper.LogTrace(correlationId, FileIntegrationConstants.ServiceName, FileIntegrationConstants.IconToRelexTimerTriggerName, "Run", "TimerTrigger", $"An error occurred while processing the timer trigger {ex.Message}.");
        }
        finally
        {
            _logAnalyticsLoggerHelper.SendLogEntriesAsync(JsonConvert.SerializeObject(loggerDataList));
            _appInsightsLoggerHelper.LogTrace(correlationId, FileIntegrationConstants.ServiceName, FileIntegrationConstants.IconToRelexTimerTriggerName, "Run", $"TimerTrigger", $"Icon To Relex TimerTrigger function completed at: {DateTime.UtcNow}");
        }
    }

}
