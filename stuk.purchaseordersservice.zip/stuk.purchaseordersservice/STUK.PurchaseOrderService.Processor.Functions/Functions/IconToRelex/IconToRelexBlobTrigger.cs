using Azure.Storage.Blobs.Models;
using Microsoft.Azure.Functions.Worker;
using Newtonsoft.Json;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using Utilities.Model.Models;
using Utilities.Models;
using Utilities.Repo.Contracts;
using Utilities.Repo.Services;
using Utility.Repo.Contracts;
using static Utility.Repo.Constants.Constants;


namespace STUK.PurchaseOrderService.Processor.Functions.Functions;

public class IconToRelexBlobTrigger
{
    private readonly IAppInsightsLoggerHelper _appInsightsLoggerHelper;
    private readonly IDBSchedulerHandler _dbSchedulerHandler;
    private readonly ISynapseAnalyticsHelper _synapseAnalyticsHelper;
    private readonly ILogAnalyticsLoggerHelper _logAnalyticsLoggerHelper;
    private readonly IBlobServiceHelper _blobServiceHelper;
    private readonly IEmailService _emailService;
    public IconToRelexBlobTrigger(IEmailService emailService,IAppInsightsLoggerHelper appInsightsLoggerHelper, IDBSchedulerHandler dbSchedulerHandler, ISynapseAnalyticsHelper synapseAnalyticsHelper, ILogAnalyticsLoggerHelper logAnalyticsLoggerHelper, IBlobServiceHelper blobServiceHelper)
    {
        _dbSchedulerHandler = dbSchedulerHandler;
        _synapseAnalyticsHelper = synapseAnalyticsHelper;
        _logAnalyticsLoggerHelper = logAnalyticsLoggerHelper;
        _appInsightsLoggerHelper = appInsightsLoggerHelper;
        _blobServiceHelper = blobServiceHelper;
        _emailService = emailService;

    }

    [Function(nameof(IconToRelexBlobTrigger))]
    public async Task Run([BlobTrigger("%IconToRelexBlobStagingPath%/{name}", Connection = "StorageConnectionString")] Stream stream, string name)
    {
        var loggerDataList = new List<LogDataCollector>();
        string? correlationId = null;
        string? retryCount = string.Empty;

        try
        {
            var stagingPath = Environment.GetEnvironmentVariable("IconToRelexBlobStagingPath");
            // Get storage account URL from configuration or environment variable
            var storageAccountUrl = Environment.GetEnvironmentVariable("StorageAccountUrl");
            if (string.IsNullOrEmpty(storageAccountUrl))
                throw new InvalidOperationException("StorageAccountUrl is not configured.");
            if (string.IsNullOrEmpty(stagingPath))
                throw new InvalidOperationException("stagingPath is not configured.");

            var connectionString = Environment.GetEnvironmentVariable("StorageConnectionString");
            var blob = new Azure.Storage.Blobs.BlobClient(connectionString, stagingPath, name);
            BlobProperties properties = await blob.GetPropertiesAsync();

            // Try to get CorrelationID from metadata, fallback to new GUID if not found
            if (properties.Metadata.TryGetValue("CorrelationID", out var metaCorrelationId) && !string.IsNullOrWhiteSpace(metaCorrelationId))
            {
                correlationId = metaCorrelationId;
            }
            else
            {
                correlationId = Guid.NewGuid().ToString();
            }
            if (properties.Metadata.TryGetValue("RetryCount", out var metaRetryCount) && !string.IsNullOrWhiteSpace(metaRetryCount))
            {
                retryCount = metaRetryCount;
            }

            int idx = name.IndexOf('_');
            string dropFileActionID = idx >= 0 ? name.Substring(0, idx) : name;
            string blobName = idx > 0 ? name.Substring(idx + 1) : string.Empty;
            _appInsightsLoggerHelper.LogTrace(correlationId, FileIntegrationConstants.ServiceName, FileIntegrationConstants.SourceSystemStaging, "Run", "BlobTrigger", "Icon To Relex BlobTrigger function started.");
            loggerDataList.Add(new LogDataCollector
            {
                CorrelationId = correlationId,
                TriggerName = "IconToRelexBlobTrigger",
                ServiceName = FileIntegrationConstants.ServiceName,
                FileActionType = FunctionNames.DROP,
                SourceSystemFilePath = "",
                OperationName = "Run",
                LogMessage = "Icon To Relex blob trigger started.",
                LogDetail = $"Icon To Relex started execution at {DateTime.UtcNow}",
                LogType = FunctionNames.Info,
                InputFileName = blobName,
                OutputFileName = "",
                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                TargetSystem = "",
                TargetSystemFilePath = "",
                ReceivedDatetime = DateTime.UtcNow,
                ProcessedDatetime = DateTime.UtcNow,
                SentDatetime = DateTime.UtcNow,
                IsEmailNotification = false,
                FileProcessingStatus = FileStatus.Started.ToString(),
                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
            });
            if (properties.ContentLength < 1024)
            {
                // File is less than 1 KB
                var parentPath = stagingPath[..stagingPath.LastIndexOf('/')];
                var invalidPath = $"{parentPath}/delivery-staging-invalid";

                var invalidBlob = new Azure.Storage.Blobs.BlobClient(
                    connectionString,
                    invalidPath,
                    name);

                // Copy blob to delivery-invalid
                await invalidBlob.StartCopyFromUriAsync(blob.Uri);

                // Delete original after copy
                await blob.DeleteIfExistsAsync();
                loggerDataList.Add(new LogDataCollector
                {
                    CorrelationId = correlationId,
                    TriggerName = "IconToRelexBlobTrigger",
                    ServiceName = FileIntegrationConstants.ServiceName,
                    FileActionType = FunctionNames.DROP,
                    SourceSystemFilePath = "",
                    OperationName = "Run",
                    LogMessage = "File Size is Less Than 1KB",
                    LogDetail = $"Icon To Relex Flow: {blobName} File Size is Less Than 1KB",
                    LogType = FunctionNames.Warning,
                    InputFileName = blobName,
                    OutputFileName = "",
                    SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                    TargetSystem = "",
                    TargetSystemFilePath = "",
                    ReceivedDatetime = DateTime.UtcNow,
                    ProcessedDatetime = DateTime.UtcNow,
                    SentDatetime = DateTime.UtcNow,
                    IsEmailNotification = false,
                    FileProcessingStatus = FileStatus.Started.ToString(),
                    SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                });


                string htmlTemplate = $"""
                                        <html>
                    <body bgcolor="White" text="Black">
                    <p>Warning - Issue with ICON end of day reports for Relex. Mulesoft has checked the size of the files generated by ICON, and the following file/s are below 1Kb: {blobName}</p>
                    </body>
                    </html>
                    """;
                string emailSubject = Environment.GetEnvironmentVariable("IconToRelexInvalidFileSubject");
                var recipients = Environment
                    .GetEnvironmentVariable("RelexNotifications__Recipients")?
                    .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    ?? Array.Empty<string>();            //_producer.EnqueueEmailAsync(correlationId, "mulesoft.stuk@erp.starkbuild.co.uk", new[] { "ext.ramaraju.jampanaswamyvenkata@starkbuild.co.uk" }, "Success Mail", htmlTemplate, "Relex_success", DateTimeOffset.UtcNow, new CancellationToken());

                int maxRetries = int.TryParse(
    Environment.GetEnvironmentVariable("EmailNotificationMaxRetry"),
    out var retries)
        ? retries
        : 3;

                int retryDelaySeconds = int.TryParse(
                    Environment.GetEnvironmentVariable("EmailNotificationRetryDelay"),
                    out var delay)
                        ? delay
                        : 30;

                loggerDataList.Add(new LogDataCollector
                {
                    CorrelationId = correlationId,
                    TriggerName = "IconToRelexBlobTrigger",
                    ServiceName = FileIntegrationConstants.ServiceName,
                    FileActionType = FunctionNames.DROP,
                    SourceSystemFilePath = "",
                    OperationName = "Run",
                    LogMessage = "Initiating Mail for Icon To Relex less than 1kb Notification",
                    LogDetail = "Initiating Mail for Icon To Relex less than 1kb Notification",
                    LogType = FunctionNames.Info,
                    InputFileName = name,
                    OutputFileName = "",
                    SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                    TargetSystem = "",
                    TargetSystemFilePath = "",
                    ReceivedDatetime = DateTime.UtcNow,
                    ProcessedDatetime = DateTime.UtcNow,
                    SentDatetime = DateTime.UtcNow,
                    IsEmailNotification = false,
                    FileProcessingStatus = FileStatus.Started.ToString(),
                    SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                });
                EmailSendResponse emailResponse;
                for (int attempt = 1; attempt <= maxRetries; attempt++)
                {
                    try
                    {
                        emailResponse = await _emailService.SendAsync(
                            emailSubject,
                            recipients,
                            htmlTemplate);
                        if (emailResponse.IsSuccess)
                        {
                            await blob.DeleteIfExistsAsync();
                            loggerDataList.Add(new LogDataCollector
                            {
                                CorrelationId = correlationId,
                                TriggerName = "IconToRelexBlobTrigger",
                                ServiceName = FileIntegrationConstants.ServiceName,
                                FileActionType = FunctionNames.DROP,
                                OperationName = "SendEmail",
                                LogMessage = "Email notification sent successfully.",
                                LogDetail = $"Email sent successfully on attempt {attempt}.",
                                LogType = FunctionNames.Info,
                                InputFileName = name,
                                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                                ReceivedDatetime = DateTime.UtcNow,
                                ProcessedDatetime = DateTime.UtcNow,
                                SentDatetime = DateTime.UtcNow,
                                IsEmailNotification = true,
                                FileProcessingStatus = FileStatus.Completed.ToString(),
                                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                            });

                            break;
                        }
                        else
                        {
                            loggerDataList.Add(new LogDataCollector
                            {
                                CorrelationId = correlationId,
                                TriggerName = "IconToRelexBlobTrigger",
                                ServiceName = FileIntegrationConstants.ServiceName,
                                FileActionType = FunctionNames.DROP,
                                OperationName = "SendEmail",
                                LogMessage = $"Email send attempt {attempt} failed with reason {emailResponse.Message}",
                                LogDetail = $"{emailResponse.Message}",
                                LogType = FunctionNames.Error,
                                InputFileName = name,
                                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                                ReceivedDatetime = DateTime.UtcNow,
                                ProcessedDatetime = DateTime.UtcNow,
                                SentDatetime = DateTime.UtcNow,
                                IsEmailNotification = true,
                                FileProcessingStatus = FileStatus.Failed.ToString(),
                                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                            });

                        }
                    }
                    catch (Exception ex)
                    {
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = correlationId,
                            TriggerName = "IconToRelexBlobTrigger",
                            ServiceName = FileIntegrationConstants.ServiceName,
                            FileActionType = FunctionNames.DROP,
                            OperationName = "SendEmail",
                            LogMessage = $"Email send attempt {attempt} failed.",
                            LogDetail = ex.ToString(),
                            LogType = FunctionNames.Error,
                            InputFileName = name,
                            SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                            ReceivedDatetime = DateTime.UtcNow,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = true,
                            FileProcessingStatus = FileStatus.Failed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                        });
                        if (attempt == maxRetries)
                        {
                            loggerDataList.Add(new LogDataCollector
                            {
                                CorrelationId = correlationId,
                                TriggerName = "IconToRelexSuccessNotificationBlobTrigger",
                                ServiceName = FileIntegrationConstants.ServiceName,
                                FileActionType = FunctionNames.DROP,
                                OperationName = "SendEmail",
                                LogMessage = "Email notification failed after all retry attempts.",
                                LogDetail = ex.ToString(),
                                LogType = FunctionNames.Error,
                                InputFileName = name,
                                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                                ReceivedDatetime = DateTime.UtcNow,
                                ProcessedDatetime = DateTime.UtcNow,
                                SentDatetime = DateTime.UtcNow,
                                IsEmailNotification = true,
                                FileProcessingStatus = FileStatus.Failed.ToString(),
                                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                            });

                            break; 
                        }


                        await Task.Delay(TimeSpan.FromSeconds(retryDelaySeconds));
                    }
                }

            }
            else
            {
                // Log: Trigger started

                var logContext = new LoggingContext
                {
                    CorrelationId = correlationId,
                    LoggerDataList = loggerDataList,
                    SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName,
                    ServiceName = FileIntegrationConstants.ServiceName,
                    TriggerName = "IconToRelexBlobTrigger",
                    FileActionType = FunctionNames.DROP
                };

                var action = await _dbSchedulerHandler.GetFTConnectionByID(dropFileActionID, logContext);

                if (string.Equals(action!.ActionName, FunctionNames.DROP, StringComparison.OrdinalIgnoreCase))
                {
                    var fileActionExecutions = new FileActionExecutions
                    {
                        FileActionID = action.ID,
                        CorrelationID = Guid.Parse(correlationId),
                        ProcessDate = DateOnly.FromDateTime(DateTime.UtcNow),
                        Status = FileStatus.Started,
                        CreationDateTime = DateTime.UtcNow,
                        UpdationDateTime = DateTime.UtcNow,
                        TokenFileName = null,
                        TokenSent = false
                    };

                    Guid executionId = await _dbSchedulerHandler.InsertExecutionStatus(fileActionExecutions, logContext);
                    var blobConnectionConfig = await _dbSchedulerHandler.GetBlobConnectionConfigBySourceID(action.SourceID, logContext);
                    var sftpConnectionConfig = await _dbSchedulerHandler.GetSFTPConnectionConfigByDestinationID(action.DestinationID, logContext);
                    if (sftpConnectionConfig == null || blobConnectionConfig == null)
                    {
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = correlationId,
                            TriggerName = "IconToRelexBlobTrigger",
                            ServiceName = FileIntegrationConstants.ServiceName,
                            FileActionType = FunctionNames.DROP,
                            SourceSystemFilePath = action.SourceFolderPath ?? string.Empty,
                            OperationName = "Run",
                            LogMessage = $"Missing connection config for IntegrationKey: {action.IntegrationKeyID}",
                            LogDetail = $"SFTP or blob config is null. SFTP: {(sftpConnectionConfig == null ? "null" : "ok")}, Blob: {(blobConnectionConfig == null ? "null" : "ok")}",
                            LogType = FunctionNames.Error,
                            InputFileName = action.ID,
                            OutputFileName = "",
                            SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                            TargetSystem = "",
                            TargetSystemFilePath = action.DestinationFolderPath ?? string.Empty,
                            ReceivedDatetime = DateTime.UtcNow,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = false,
                            FileProcessingStatus = FileStatus.Failed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                        });
                    }

                    var parameter = new
                    {
                        RetryCount = retryCount,
                        Id = executionId,
                        fileActionExecutions.CorrelationID,
                        SourceAccountName = blobConnectionConfig!.StorageName,
                        SourceAccountKey = blobConnectionConfig.ClientSecretKey,
                        SourceFilePath = action.SourceFolderPath,
                        FileStartFilter = name,
                        FileEndFilter = "",
                        DestinationHost = sftpConnectionConfig!.IPAddress, // Host of sftp
                        DestinationUsername = sftpConnectionConfig.Username, // Username of sftp
                        DestinationPassword = sftpConnectionConfig.PasswordKey, // Password Secret of sftp
                        DestinationFilePath = action.DestinationFolderPath,
                        DestinationFileFormat = action.DestinationFileNameFormat ?? blobName,
                        IsArchive = action.SourceArchive,
                        ArchivePath = action.SourceArchivePath,
                        ErrorPath = action.SourceErrorPath,
                        LastRunTotalAmount = 0,
                        FileAction = FunctionNames.DROP,
                        action.SourceDelete,
                        IsTokenRequired=true,
                        TokenName=blobName,
                        TokenFilePath= Environment.GetEnvironmentVariable("IconToRelexBlobTokenPath"),
                        SourceStorageAccountEndPoint = blobConnectionConfig!.ServiceEndPoint,
                        TriggeredByFnApp = Environment.GetEnvironmentVariable("functionAppName"),
                        TriggeredBySchedulerName = "IconToRelexBlobTrigger"
                    };
                    var synapseWorkSpaceName = Environment.GetEnvironmentVariable("Synapse_Workspace");
                    bool res = await _synapseAnalyticsHelper.TriggerSynapsePipeline(synapseWorkSpaceName!, action.PipeLineName, parameter, logContext);
                    if (res)
                    {
                        if (action.SourceArchive != null && action.SourceArchive == true)
                        {
                            int idx_staggingPath = action.SourceArchivePath!.IndexOf('/');
                            string containerName = idx_staggingPath >= 0 ? action.SourceArchivePath.Substring(0, idx_staggingPath) : action.SourceArchivePath;
                            string archivedirectoryPath = idx_staggingPath >= 0 ? action.SourceArchivePath.Substring(idx_staggingPath + 1) : string.Empty;
                            await _blobServiceHelper.ClearStagingFilesAsync(storageAccountUrl, containerName, action.RetentionNoofFiles, TimeSpan.FromDays((double)action!.RetentionNoofDays!), archivedirectoryPath, logContext);
                        }
                        // Log: Pipeline triggered
                        loggerDataList.Add(new LogDataCollector
                        {
                            CorrelationId = correlationId,
                            TriggerName = "IconToRelexBlobTrigger",
                            ServiceName = FileIntegrationConstants.ServiceName,
                            FileActionType = FunctionNames.DROP,
                            SourceSystemFilePath = action.SourceFolderPath ?? string.Empty,
                            OperationName = "Run",
                            LogMessage = $"Synapse pipeline triggered successfully at {DateTime.UtcNow}.",
                            LogDetail = $"Synapse pipeline triggered with parameter: {JsonConvert.SerializeObject(parameter)} at {DateTime.UtcNow}",
                            LogType = FunctionNames.Info,
                            InputFileName = action.ID,
                            OutputFileName = "",
                            SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                            TargetSystem = FunctionNames.DeliveryStaging,
                            TargetSystemFilePath = action.DestinationFolderPath ?? string.Empty,
                            ReceivedDatetime = DateTime.UtcNow,
                            ProcessedDatetime = DateTime.UtcNow,
                            SentDatetime = DateTime.UtcNow,
                            IsEmailNotification = false,
                            FileProcessingStatus = FileStatus.Completed.ToString(),
                            SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
                        });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log: Exception
            loggerDataList.Add(new LogDataCollector
            {
                CorrelationId = correlationId,
                TriggerName = "IconToRelexBlobTrigger",
                ServiceName = FileIntegrationConstants.ServiceName,
                FileActionType = FunctionNames.DROP,
                SourceSystemFilePath = "",
                OperationName = "Run",
                LogMessage = "Exception in Icon To Relex Blob Trigger function.",
                LogDetail = $"Function failed with exception: {ex}",
                LogType = FunctionNames.Error,
                InputFileName = "",
                OutputFileName = "",
                SourceSystem = FileIntegrationConstants.SourceSystemStaging,
                TargetSystem = FunctionNames.DeliveryStaging,
                TargetSystemFilePath = "",
                ReceivedDatetime = DateTime.UtcNow,
                ProcessedDatetime = DateTime.UtcNow,
                SentDatetime = DateTime.UtcNow,
                IsEmailNotification = false,
                FileProcessingStatus = FileStatus.Failed.ToString(),
                SchedulerName = FileIntegrationConstants.IconToRelexSchedulerName
            });
            _appInsightsLoggerHelper.LogTrace(correlationId!, FileIntegrationConstants.ServiceName, FileIntegrationConstants.SourceSystemStaging, "Run", "BlobTrigger", $"An error occurred while processing the Blob trigger {ex.Message}.");

        }
        finally
        {
            _logAnalyticsLoggerHelper.SendLogEntriesAsync(JsonConvert.SerializeObject(loggerDataList));
            _appInsightsLoggerHelper.LogTrace(correlationId!, FileIntegrationConstants.ServiceName, FileIntegrationConstants.SourceSystemStaging, "Run", "BlobTrigger", $"Icon To Relex Blob trigger function completed at: {DateTime.UtcNow}");

        }
    }
}