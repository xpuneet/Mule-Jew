# Local Development with .NET Aspire

The Aspire AppHost runs the implemented Purchase Order happy path on one developer machine:

```text
canonical POST -> Web API -> local SQL Server -> Processor Functions
               -> mocked ICON activation -> mocked CreatePurchaseOrder
               -> COMPLETED candidate and SUCCEEDED submission attempt
```

The Web API still persists only. ICON activation, CDM-to-ICON mapping, dispatch, and outcome persistence run in the Processor Functions host.

## Prerequisites

### Common prerequisites

- A .NET SDK that can build `net8.0` projects.
- Azure Functions Core Tools 4 installed, with `func` available on the same `PATH` used by the terminal, Rider, or Visual Studio. Verify with `func --version`; the version must start with `4.`.
- Authenticated access to the existing STARK Azure Artifacts feed when the private `STUK.IconIntegration` package is not already in the local NuGet cache. Use the approved developer authentication flow; do not put credentials in `nuget.config`.
- Enough Docker memory for SQL Server and Azurite. At least 4 GB assigned to Docker Desktop is recommended for this topology.

Quick prerequisite checks:

```console
dotnet --list-sdks
docker info
func --version
```

### macOS on Apple Silicon

- Run Docker Desktop on Apple Silicon.
- Enable Docker Desktop's **Use Rosetta for x86_64/amd64 emulation on Apple Silicon** option. The AppHost deliberately runs SQL Server 2022 as `linux/amd64`; it does not substitute a different database engine or ARM image.

On macOS, Azure Functions Core Tools 4 can be installed using Microsoft's supported Homebrew package:

```bash
brew tap azure/functions
brew install azure-functions-core-tools@4
```

If Homebrew rejects the formula because the Azure tap is not trusted, keep trust scoped to the
two formula definitions that Homebrew evaluates and retry the installation:

```bash
brew trust --formula azure/functions/azure-functions-core-tools@4
brew trust --formula azure/functions/azure-functions-core-tools
brew install azure-functions-core-tools@4
```

Do not disable Homebrew tap-trust checks or trust unrelated taps. If an interrupted installation
has already placed the versioned formula in the Homebrew cellar but `func` is still unavailable,
link that formula explicitly:

```bash
brew link azure/functions/azure-functions-core-tools@4
```

Restart Rider or open a new terminal after installation if `func` is not immediately visible on `PATH`.

### Windows x64 with Visual Studio

- Use Windows 10 or Windows 11 x64 with hardware virtualization and WSL 2 enabled.
- Configure Docker Desktop to use the WSL 2 engine and Linux containers. Windows Containers mode is not supported by this topology.
- Install a current Visual Studio version that supports the checked-in .NET and Aspire SDKs. In Visual Studio Installer, include the **ASP.NET and web development** workload and the available .NET Aspire tooling.
- Install the Microsoft Azure Functions Core Tools 4 Windows x64 package. Restart Visual Studio after installation so its processes inherit the updated `PATH`.
- In a new Visual Studio terminal, run `where.exe func` and `func --version`. The resolved executable must be available to Visual Studio and report a `4.x` version.

The AppHost still requests the `linux/amd64` SQL Server image on Windows x64, but Rosetta is not required. Windows ARM64 is not covered by this guide. The Windows workflow is structurally supported by the portable project paths and Docker topology, but the current live E2E evidence was captured on macOS; run the E2E command below on the target Windows workstation before treating that workstation as verified.

## Start the complete local environment

### Command line

From the repository root:

```bash
dotnet run --project STUK.PurchaseOrderService.AppHost
```

Open the Aspire dashboard URL printed by the AppHost. The dashboard shows resource state, logs, and the allocated HTTP endpoints. Startup is ready when `PurchaseOrdersServiceDB` is healthy and the Web API, ICON mock, Processor Functions, and WebApp are running. The first run can take several minutes while Docker downloads SQL Server and Azurite images.

### Visual Studio on Windows x64

1. Start Docker Desktop and confirm that it is using the WSL 2 engine and Linux containers.
2. Open `STUK.PurchaseOrderService.sln` in Visual Studio. Complete package restore using the approved STARK Azure Artifacts authentication flow if Visual Studio prompts for access.
3. In Solution Explorer, right-click `STUK.PurchaseOrderService.AppHost` and select **Set as Startup Project**.
4. Select the AppHost `http` launch profile in the Visual Studio run-target selector.
5. Press **F5** to debug or **Ctrl+F5** to run without the debugger. The AppHost starts the Docker resources and all local application hosts; do not start the Web API or Functions project separately.
6. Open the Aspire dashboard when Visual Studio launches the browser. If it does not open automatically, use the dashboard URL shown in the AppHost output.
7. Confirm that `sql`, `PurchaseOrdersServiceDB`, `functions-storage`, `icon-mock`, `web-api`, `processor-functions`, and `web-app` are healthy or running as appropriate.

The AppHost starts:

| Resource | Local role |
| --- | --- |
| `sql` / `PurchaseOrdersServiceDB` | SQL Server 2022 x64 container and physical `Orders` database, created by Aspire from the ordered checked-in SQL scripts |
| `functions-storage` | Azurite storage required by the Functions host |
| `icon-mock` | Deterministic local-purpose activation and Create Purchase Order endpoints |
| `web-api` | Canonical Purchase Order API with Development authentication behavior |
| `processor-functions` | Five-second local candidate processor; submission is enabled only by AppHost |
| `web-app` | Local support/admin portal with an AppHost-enabled synthetic `PurchaseOrderViewer` / `PurchaseOrderManager` identity |

Aspire generates the local SQL password and persists it in the AppHost user-secrets store so the persistent SQL volume remains accessible across restarts. Do not clear that generated secret while retaining the volume. The AppHost supplies synthetic ICON tokens; they are not live credentials and must never be reused outside this local environment. No Application Insights endpoint is configured locally.

The WebApp local identity is fail-closed outside this topology: the AppHost supplies `WebApp__EnableLocalDevelopmentAuthentication=true`, and the WebApp also requires the ASP.NET environment to be `Development`. In other environments the portal uses the normal CoreUI middleware and role checks; the local layout and identity are not selected.

## Emulate the Relex input folders locally

The AppHost uses ordinary local directories to emulate the Relex file-transfer boundary. On Unix,
the default root is `/tmp/stuk-purchase-orders/relex`; on Windows it is created under the platform
temporary directory. Set an explicit root to override that location:

```bash
export STUK_RELEX_LOCAL_ROOT="/tmp/stuk-purchase-orders/relex"
dotnet run --project STUK.PurchaseOrderService.AppHost/STUK.PurchaseOrderService.AppHost.csproj
```

The AppHost creates these directories before starting Processor Functions:

```text
/tmp/stuk-purchase-orders/relex/data/input
/tmp/stuk-purchase-orders/relex/data/output/archive
/tmp/stuk-purchase-orders/relex/data/output/error
```

In another terminal, copy a synthetic file to the input directory. The local timer runs every five
seconds, and a file becomes eligible after it has remained unchanged for at least two seconds:

```bash
cp STUK.PurchaseOrderService.UnitTests/TestData/Relex/SG_OrderProposal_synthetic.csv \
  /tmp/stuk-purchase-orders/relex/data/input/SG_OrderProposal_local.csv
```

A valid file moves to `data/output/archive`; a deterministic CSV-format failure moves to
`data/output/error`. A technical dependency failure leaves the file in `data/input` for a later
run. To demonstrate oldest-first ordering, prepare two files and assign distinct timestamps:

```bash
cp STUK.PurchaseOrderService.UnitTests/TestData/Relex/SG_OrderProposal_synthetic.csv \
  /tmp/stuk-purchase-orders/relex/data/input/SG_OrderProposal_older.csv
cp STUK.PurchaseOrderService.UnitTests/TestData/Relex/SG_OrderProposal_synthetic.csv \
  /tmp/stuk-purchase-orders/relex/data/input/SG_OrderProposal_newer.csv
touch -t 202608170900.00 /tmp/stuk-purchase-orders/relex/data/input/SG_OrderProposal_older.csv
touch -t 202608170901.00 /tmp/stuk-purchase-orders/relex/data/input/SG_OrderProposal_newer.csv
```

These folders emulate file discovery and movement, not the SFTP protocol itself. The isolated SFTP
adapter test covers the protocol boundary. AppHost enables downstream submission to the local ICON
mock by default; set `STUK_PROCESSOR_SUBMISSION_ENABLED=false` when you only want to inspect
ingestion and the resulting database rows.

## Run the automated happy path

The Docker-backed acceptance test is intentionally outside `STUK.PurchaseOrderService.sln`, so ordinary unit-test runs do not start containers:

```console
dotnet test STUK.PurchaseOrderService.EndToEndTests/STUK.PurchaseOrderService.EndToEndTests.csproj --configuration Release --logger "console;verbosity=normal"
```

On Windows, run this command from **View > Terminal** in Visual Studio after stopping any interactive AppHost run. Because the E2E project is intentionally outside the solution, it is not shown in Test Explorer when only `STUK.PurchaseOrderService.sln` is open.

The test uses an isolated, disposable SQL data volume rather than the interactive development volume. It:

1. starts the AppHost and waits for initialization;
2. posts the canonical fixture with a unique reference and `source: Relex`;
3. polls the API until the candidate is `COMPLETED` with ICON order `900001`;
4. verifies that the mocked activation and Create Purchase Order calls occurred with the expected account, reference, and `contactID: 1`;
5. queries SQL directly and verifies a `SUCCEEDED` submission attempt.

If the test reports `Azure Functions Core Tools 4 ('func') must be installed and available on PATH`, install Core Tools 4 and rerun it. The test does not replace the Functions host with an in-process shortcut.

## Interactive database persistence and reset

Interactive AppHost runs preserve SQL data in an Aspire-generated volume scoped to the AppHost and `sql` resource. The exact Docker volume name is intentionally not hard-coded. Find it from the active SQL container shown in the Aspire dashboard or `docker ps`, then inspect that container's `/var/opt/mssql` mount.

The status-storage simplification is fresh-schema-only. If this volume was created by a revision
that used the legacy status lookup tables, `010-preflight.sql` intentionally stops initialization.
There is no local in-place migration; remove the volume once so Aspire can build the current schema.

To recreate the local database from the checked-in Aspire creation script, first stop the AppHost, substitute the SQL container name observed before shutdown, confirm the exact volume, remove only that volume, and start the AppHost again:

```bash
docker inspect sql-example --format '{{range .Mounts}}{{if eq .Destination "/var/opt/mssql"}}{{.Name}}{{end}}{{end}}'
docker volume inspect confirmed-apphost-sql-volume
docker volume rm confirmed-apphost-sql-volume
dotnet run --project STUK.PurchaseOrderService.AppHost
```

Removing that confirmed volume permanently deletes only the local interactive `Orders` database stored in it. The automated E2E test uses an isolated volume. A legacy `stuk-purchase-orders-sql-data` volume from an older checkout is not reused or deleted automatically.

## Local-only boundary

This topology does not connect to live ICON, Relex SFTP, ICON SFTP, Retarus, Azure SQL, Key Vault, or production Application Insights. It does not prove that the proposed SQL package is deployed in any shared environment. Normal checked-in Processor settings remain fail-closed with submission disabled; only the local AppHost enables submission and routes it to the deterministic ICON mock.

The local environment is evidence for the implemented in-repository happy path. Production credentials, schedules, retry policy, database ownership/deployment, real external contracts, and environment readiness remain separate approval and verification work.
