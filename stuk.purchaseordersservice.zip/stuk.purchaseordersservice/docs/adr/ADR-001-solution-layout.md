# ADR-001 - SaleOrdersService-Based Solution Layout

Status: Accepted for foundation slice  
Date: 2026-07-08

## Context

Purchase Order Service should follow the reviewed SaleOrdersService repository shape where one Visual Studio solution contains API, domain, data, processor hosts, admin UI, and tests.

## Decision

Use one repository and one `.sln` with `STUK.PurchaseOrderService.*` projects. Keep deployable boundaries explicit:

- `WebApi` for public/server API;
- `Processor.Functions` for scheduled private synchronization;
- `Processor.WebJob` for manual/support processor runs;
- `WebApp` for support/admin UI.

## Consequences

The solution is buildable before Relex, ICON, Retarus, and SQL scripts are complete. The first implementation slice intentionally keeps private-feed admin packages out until `SgBdApps.Core` usage and feed access are confirmed.
