# Purchase Order Stored Procedure Contract

**Status:** Proposed implementation contract  
**Date:** 2026-08-05  
**Deployment state:** Not deployed or live-verified.

The application accesses Purchase Order data through stored procedures only. The numbered package
contains 35 procedures. The following procedures are wired into the current Web API, WebApp, or
Processor Function.

| Procedure | Consumer | Purpose |
| --- | --- | --- |
| `po.sp_get_application_settings` | SQL configuration provider | Load isolated DB-backed settings by ordered context list. |
| `po.sp_create_purchase_order_candidate` | Web API repository | Persist one canonical candidate and its create audit. |
| `po.sp_search_purchase_order_candidates` | Web API repository | Search persisted candidates with deterministic pagination. |
| `po.sp_get_purchase_order_candidate_summary` | WebApp admin repository | Count current lifecycle statuses for one source and accepted-time range. |
| `po.sp_get_purchase_order_candidate` | WebApp admin repository | Read candidate details, payload, lease state, and rowversion. |
| `po.sp_get_purchase_order_audit` | WebApp support repository | Read newest-first bounded audit history. |
| `po.sp_request_purchase_order_retry` | WebApp support repository | Request a rowversion-protected manual retry. |
| `po.sp_cancel_purchase_order_candidate` | WebApp support repository | Request a rowversion-protected cancellation. |
| `po.sp_enqueue_purchase_order_email_notification` | Processor email outbox | Persist an immutable version-1 email snapshot idempotently. |
| `po.sp_claim_purchase_order_email_notifications` | Processor email sender | Claim due email snapshots under a lease and rolling quota. |
| `po.sp_defer_purchase_order_email_notification` | Processor email sender | Return a claimed snapshot to `PENDING` without consuming the ordinary retry budget. |
| `po.sp_reschedule_purchase_order_email_notification` | Processor email sender | Persist a transient or generic throttled outcome and schedule another attempt. |
| `po.sp_complete_purchase_order_email_notification` | Processor email sender | Complete the active lease as `SENT` or terminal `FAILED`. |
| `po.sp_get_purchase_order_email_notification_queue_summary` | Processor email sender | Return aggregate queue-health counters without email content. |

The complete ingestion, processing, support, notification, transaction, error, and result-set
contracts are defined in
[`purchase-order-database-handoff.md`](purchase-order-database-handoff.md).

## `po.sp_get_application_settings`

Input: `@contextList nvarchar(max)`, a comma-separated ordered list such as `Common,WebApi`.

The procedure reads only `po.ApplicationSetting`; it does not depend on the `orders` schema. It
returns `key nvarchar(256)` and `value nvarchar(max)`, with at most one row per key. When the same
key exists in multiple requested contexts, the last context wins. Null, blank, or effectively empty
context lists are rejected with `51004`.

The numbered deployment creates `po.ApplicationSetting` empty. An approved environment-specific
copy of `database/purchase-order/110-application-settings-seed.template.sql` is executed separately
before application rollout. Only non-secret settings belong in this table.

## `po.sp_create_purchase_order_candidate`

Parameters:

- `@candidateId uniqueidentifier`
- `@account nvarchar(50)`
- `@branch nvarchar(20)`
- `@reference nvarchar(100) = NULL`
- `@status varchar(50)`
- `@acceptedDateTime datetimeoffset(3)`
- `@payloadJson nvarchar(max)`
- `@actor nvarchar(256)`

The procedure rejects a top-level `candidateStatus`, assigns `Source = 'API'`, and inserts the
candidate and its audit row in
one transaction, and returns no result set or output parameter. Repeated business payloads are
allowed when they use different candidate identifiers.

## `po.sp_search_purchase_order_candidates`

Parameters:

- `@source nvarchar(50)`
- `@account nvarchar(50) = NULL`
- `@branch nvarchar(20) = NULL`
- `@reference nvarchar(100) = NULL`
- `@iconPurchaseOrderNumber nvarchar(100) = NULL`
- `@status varchar(50) = NULL`
- `@acceptedAfterDateTimeUtc datetimeoffset(3) = NULL`
- `@acceptedUntilDateTimeUtc datetimeoffset(3) = NULL`
- `@pageNumber int`
- `@pageSize int`

Page numbers start at 1 and page size is limited to `1..50`. Results contain `CandidateId`,
`Source`, `Account`, `Branch`, `Reference`, `IconPurchaseOrderNumber`, `Status`, and
`AcceptedDateTime`, ordered by `AcceptedDateTime DESC, CandidateId`. Non-null accepted-time bounds
must use the UTC offset and form a half-open range: accepted time is greater than or equal to the
lower bound and strictly less than the upper bound.

## `po.sp_get_purchase_order_candidate_summary`

Parameters: required `@source nvarchar(50)`, `@afterDateTimeUtc datetimeoffset(3)`, and
`@untilDateTimeUtc datetimeoffset(3)`. Both timestamps must use the UTC offset and the start must be
before the end. The result contains `Status varchar(50)` and `CandidateCount bigint`, grouped over
the same half-open `AcceptedDateTime` range used by portal search.

## Durable Email Notification Procedures

The email sender uses a complete immutable `EmailEnvelopeV1` JSON snapshot. The snapshot contains
the persisted sender, recipients, subject, body, and Base64 attachments; delivery does not resolve
the optional legacy `TemplateKey`, `RecipientGroupKey`, or `AttachmentBlobName`. The SQL storage
boundary is 20 MiB of UTF-16 JSON by `DATALENGTH`; runtime validation separately limits a
conservative upper bound of the SMTP MIME message to 10 MB and the combined `to`, `cc`, and `bcc`
recipient count to 50.

All supplied `datetimeoffset(3)` values must use UTC offset zero. The email-specific defer,
reschedule, and complete procedures require the active `LeaseId` and exact notification
`RowVersion`, so a stale or reclaimed worker cannot overwrite the current owner. The six
procedures are granted to `po_service_executor`; no direct notification-table grant is added.

### `po.sp_enqueue_purchase_order_email_notification`

Inputs:

- `@notificationId uniqueidentifier`
- `@batchId uniqueidentifier = NULL`
- `@eventType varchar(100)`
- `@businessCorrelationId nvarchar(256)`
- `@emailEnvelopeVersion smallint`
- `@emailEnvelopeJson nvarchar(max)`
- `@templateKey nvarchar(100) = NULL`
- `@recipientGroupKey nvarchar(100) = NULL`
- `@attachmentBlobName nvarchar(512) = NULL`
- `@createdDateTime datetimeoffset(3)`

Result: `NotificationId`, `Status`, `NextAttemptDateTime`, `AttemptCount`, `FailureCount`,
`ThrottleCount`, `PayloadSha256`, and `RowVersion`.

Only envelope version `1` is accepted. The JSON notification ID, business correlation ID, and
schema version must exactly match the relational inputs. The procedure hashes the exact JSON and
inserts a new `EMAIL`/`PENDING` row. Replaying the same notification ID returns the existing row
only when the payload hash and all immutable metadata match; otherwise it raises an idempotency
conflict. `@batchId` is optional, but must identify an existing batch when supplied.

### `po.sp_claim_purchase_order_email_notifications`

Inputs:

- `@asOfDateTime datetimeoffset(3)`
- `@leaseDurationSeconds int`
- `@maxNotifications int`
- `@maxAttemptsPerMinute int`
- `@maxAttemptsPerHour int`

Result, one row per claim: `NotificationId`, `EventType`, `BusinessCorrelationId`,
`EmailEnvelopeVersion`, `EmailEnvelopeJson`, `PayloadSha256`, `AttemptCount`, `FailureCount`,
`ThrottleCount`, `LeaseId`, `LeaseExpiresDateTime`, and `RowVersion`.

The procedure takes the transaction-owned exclusive application lock
`po.email-notification-claim-quota`, counts persisted attempt starts in the rolling minute and
hour, and claims no more than the smallest of the batch limit and remaining quota. This serializes
quota spending across concurrent Function invocations. Each claim creates a `STARTED` attempt and
counts conservatively against both quotas even if delivery is later deferred or the host stops.
Due `PENDING` and expired `SENDING` rows are selected oldest first; active leases and rows without
a supported version-1 snapshot are excluded.

When an expired `SENDING` row is reclaimed, its previous open attempt becomes `LEASE_EXPIRED`, a
new unique lease/attempt ID is assigned, and the attempt number advances atomically. Delivery is
therefore at least once: a crash after the ACS SMTP relay accepts the email but before SQL
completion can result in a duplicate send after lease recovery.

### `po.sp_defer_purchase_order_email_notification`

Inputs: `@notificationId uniqueidentifier`, `@leaseId uniqueidentifier`,
`@nextAttemptDateTime datetimeoffset(3)`, `@completedDateTime datetimeoffset(3)`, and
`@expectedNotificationRowVersion binary(8)`.

Result: `NotificationId`, `Status`, `NextAttemptDateTime`, `FailureCount`, `ThrottleCount`, and
`RowVersion`.

The active `SENDING` lease returns to `PENDING`, its attempt becomes `DEFERRED`, and neither the
failure nor throttle counter changes. The processor uses this transition when the Function run or
lease lacks the configured safe time for a provider operation plus durable completion.

### `po.sp_reschedule_purchase_order_email_notification`

Inputs:

- `@notificationId uniqueidentifier`
- `@leaseId uniqueidentifier`
- `@outcome varchar(50)` (`TRANSIENT_FAILURE` or `THROTTLED`)
- `@failureCategory varchar(50)`
- `@failureCode varchar(100) = NULL`
- `@failureDescription nvarchar(1000) = NULL`
- `@httpStatusCode smallint = NULL`
- `@nextAttemptDateTime datetimeoffset(3)`
- `@completedDateTime datetimeoffset(3)`
- `@expectedNotificationRowVersion binary(8)`

Result: `NotificationId`, `Status`, `NextAttemptDateTime`, `FailureCount`, `ThrottleCount`, and
`RowVersion`.

For the current SMTP adapter, a network, timeout, unclassified SMTP, or SMTP 4xx outcome returns the
row to `PENDING`, records `TRANSIENT_FAILURE`, and increments `FailureCount`; SMTP 5xx is permanent.
The database contract also retains a generic `THROTTLED` transition for a delivery adapter that can
report HTTP 429. The SMTP adapter does not emit that outcome or expose `Retry-After`.

### `po.sp_complete_purchase_order_email_notification`

Inputs:

- `@notificationId uniqueidentifier`
- `@leaseId uniqueidentifier`
- `@status varchar(50)`
- `@attemptOutcome varchar(50)`
- `@incrementFailureCount bit`
- `@providerMessageId nvarchar(256) = NULL`
- `@failureCategory varchar(50) = NULL`
- `@failureCode varchar(100) = NULL`
- `@failureDescription nvarchar(1000) = NULL`
- `@httpStatusCode smallint = NULL`
- `@completedDateTime datetimeoffset(3)`
- `@expectedNotificationRowVersion binary(8)`

Result: `NotificationId`, `Status`, `SentDateTime`, `CompletedDateTime`, `FailureCount`,
`ThrottleCount`, and `RowVersion`.

Allowed terminal combinations are `SENT`/`SUCCEEDED` without a failure increment,
`FAILED`/`PERMANENT_FAILURE` without a failure increment, and
`FAILED`/`TRANSIENT_FAILURE` with a failure increment when the ordinary retry budget is exhausted.
The checked-in default ordinary retry limit is eight counted failures. A generic throttled outcome
cannot be completed through this procedure. Terminal rows have no lease and cannot be claimed
again.

`SENT` means the ACS SMTP relay accepted the SMTP transaction. The current adapter supplies no
provider operation ID. Relay acceptance does not mean that the recipient mailbox received the
message; mailbox delivery, bounce, and delivery-event tracking are not implemented.

### `po.sp_get_purchase_order_email_notification_queue_summary`

Inputs: `@asOfDateTime datetimeoffset(3)` and
`@terminalFailureSinceDateTime datetimeoffset(3)`, where the failure-window start cannot be after
the observation time.

The single-row result contains:

- `ClaimablePendingCount`: version-1 snapshots due now;
- `OldestClaimablePendingDateTime`: creation time of the oldest due snapshot, or null;
- `DelayedPendingCount`: version-1 snapshots scheduled after the observation time;
- `ActiveLeasedCount`: `SENDING` rows whose lease has not expired;
- `ExpiredLeasedCount`: `SENDING` rows eligible for recovery;
- `UnsendableLegacyPendingCount`: pending email rows without an envelope snapshot;
- `TerminalFailureCount`: `FAILED` rows completed inside the requested observation window.

## Email State Transitions and Legacy Isolation

| From | Trigger | To / attempt outcome | Counter effect |
| --- | --- | --- | --- |
| New | Idempotent enqueue | `PENDING` | Counters start at zero. |
| Due `PENDING` | Quota-aware claim | `SENDING` / `STARTED` | `AttemptCount` increments. |
| Expired `SENDING` | Reclaim | `SENDING`; old `LEASE_EXPIRED`, new `STARTED` | `AttemptCount` increments. |
| `SENDING` | Admission-time defer | `PENDING` / `DEFERRED` | Failure and throttle counts unchanged. |
| `SENDING` | Transient failure before retry limit | `PENDING` / `TRANSIENT_FAILURE` | `FailureCount` increments. |
| `SENDING` | Generic adapter reports throttling | `PENDING` / `THROTTLED` | `ThrottleCount` increments only; the current SMTP adapter does not emit this outcome. |
| `SENDING` | ACS SMTP relay accepts the transaction | `SENT` / `SUCCEEDED` | Completion times are stored; provider operation ID remains null. |
| `SENDING` | Permanent failure | `FAILED` / `PERMANENT_FAILURE` | Failure count unchanged. |
| `SENDING` | Counted failure reaches retry limit | `FAILED` / `TRANSIENT_FAILURE` | Final `FailureCount` increment stored. |

`po.sp_register_purchase_order_notification` and
`po.sp_complete_purchase_order_notification` retain their legacy signatures and completed-batch
contract. Registration creates no email envelope, so those rows are never sender-claimable. The
legacy completion procedure rejects any row containing `EmailEnvelopeJson`; email snapshots must
use the leased email procedures. Migration does not invent snapshots for existing legacy rows,
which remain visible through `UnsendableLegacyPendingCount` when applicable.

## Email Sender Configuration

The root timer key is host-resolved; the nested keys bind to the `EmailSender` options section.
Environment variables use `__` in place of `:`. Checked-in defaults keep sending disabled.

| Configuration key | Checked-in default | Operational meaning |
| --- | ---: | --- |
| `EmailNotificationSenderCronExpression` | `0 */1 * * * *` | Required six-field NCRONTAB timer expression, validated even when sending is disabled. |
| `EmailSender:SendingEnabled` | `false` | Feature gate; keep disabled until the environment SMTP configuration and controlled acceptance are independently verified. |
| `EmailSender:DefaultSenderAddress` | empty | Canonical sender stamped only into newly enqueued snapshots; required when enabled. |
| `EmailSender:Smtp:Host` | empty | Must be `smtp.azurecomm.net` when enabled; supplied per environment outside source control. |
| `EmailSender:Smtp:Port` | `0` | Must be submission port `587` when enabled; supplied per environment outside source control. |
| `EmailSender:Smtp:UseStartTls` | `false` | Must be `true` when enabled. |
| `EmailSender:Smtp:Username` | empty | Non-secret SMTP username; supplied per environment outside source control. |
| `EmailSender:Smtp:Password` | empty | SMTP password. It is never mapped from Azure DevOps or checked into settings. |
| `EmailSender:ClaimBatchSize` | `10` | Maximum requested claim size, additionally capped by free concurrency; valid enabled range `1..100`. |
| `EmailSender:MaxConcurrency` | `4` | Maximum concurrent provider calls; valid enabled range `1..20`. |
| `EmailSender:LeaseDurationSeconds` | `120` | SQL lease duration; must exceed provider timeout plus completion margin. |
| `EmailSender:MaxRunDurationSeconds` | `50` | Sender invocation work deadline; must exceed provider timeout plus completion margin. |
| `EmailSender:ProviderOperationTimeoutSeconds` | `30` | Positive timeout applied to one ACS SMTP send attempt. |
| `EmailSender:CompletionSafetyMarginSeconds` | `10` | Positive time reserved for durable outcome persistence. |
| `EmailSender:OutcomePersistenceTimeoutSeconds` | `10` | Positive independent SQL outcome-write timeout; cannot exceed the completion margin. |
| `EmailSender:MaxFailureCount` | `8` | Counted transient failures before terminal `FAILED`; valid enabled range `1..20`. |
| `EmailSender:InitialRetryDelaySeconds` | `60` | Initial exponential retry delay; valid range `0..3600` and cannot exceed `MaxRetryDelaySeconds`. |
| `EmailSender:MaxRetryDelaySeconds` | `3600` | Maximum retry delay after jitter; valid range `0..3600`. |
| `EmailSender:RetryJitterSeconds` | `10` | Symmetric random retry jitter bound; valid range `0..3600`. |
| `EmailSender:ThrottleFallbackDelaySeconds` | `60` | Fallback for a generic throttled outcome; retained by the processor contract but unused by the current SMTP adapter. Valid range `0..3600`. |
| `EmailSender:RateLimit:MaxAttemptsPerMinute` | `0` | Rolling minute quota; must be positive when enabled and match the provisioned domain quota. |
| `EmailSender:RateLimit:MaxAttemptsPerHour` | `0` | Rolling hour quota; must be positive when enabled and match the provisioned domain quota. |

The checked-in `appsettings.json` is deliberately blank for the SMTP contract: `Host`,
`Username`, and `Password` are empty, `Port` is `0`, and `UseStartTls` is `false`. The local
settings file supplies the same blank non-secret shape and intentionally has no password entry.
For DEV, QA, and PROD, Azure DevOps maps `AzureKeyVaultUri`, the non-secret SMTP host, port,
STARTTLS flag, and username, plus the sender, operational, and rate-limit settings. It must not
map `EmailSender__Smtp__Password`. The Functions Key Vault provider resolves that password from
the Key Vault secret alias `EmailSender--Smtp--Password`.

The ACS Communication Services and Email Communication resources, linked verified domain and
MailFrom identity, SMTP username/Entra application permissions and client secret, actual domain
minute/hour quotas, and database encryption/backup access/retention readiness are external. The
Function managed identity requires read access to the environment Key Vault so it can resolve
`EmailSender--Smtp--Password`; it does not authenticate the SMTP session. Do not enable sending or
perform an environment live send until those prerequisites, Key Vault access, and environment
values are independently evidenced. Retention/purge automation is not implemented.

## Status Validation and Storage

The database uses named `CHECK` constraints rather than status lookup tables. Procedure validation,
table constraints, and the verification manifest must change together when a status value changes.
