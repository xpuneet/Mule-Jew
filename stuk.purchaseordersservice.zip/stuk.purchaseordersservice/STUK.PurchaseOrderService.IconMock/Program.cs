using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;

namespace STUK.PurchaseOrderService.IconMock;

public sealed class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        builder.Services
            .AddOptions<IconMockOptions>()
            .Bind(builder.Configuration.GetSection(IconMockOptions.SectionName))
            .Validate(
                static options =>
                    !string.IsNullOrWhiteSpace(options.ActivationAuthToken)
                    && !string.IsNullOrWhiteSpace(options.PurchaseOrderAuthToken),
                "Both synthetic ICON mock tokens are required.")
            .Validate(
                static options => !string.Equals(
                    options.ActivationAuthToken,
                    options.PurchaseOrderAuthToken,
                    StringComparison.Ordinal),
                "The activation and purchase-order tokens must be different.")
            .ValidateOnStart();
        builder.Services.AddSingleton<RecordedIconRequests>();

        var app = builder.Build();

        app.MapGet("/health", static () => Results.Ok());

        app.MapPost(
            "/CF_ICXI0002",
            HandleActivationAsync);
        app.MapPost(
            "/CreatePurchaseOrder",
            HandleCreatePurchaseOrderAsync);

        if (app.Environment.IsDevelopment())
        {
            app.MapGet(
                "/_test/requests/activation",
                static (RecordedIconRequests requests) =>
                    Results.Json(requests.GetActivationRequests()));
            app.MapGet(
                "/_test/requests/purchase-orders",
                static (RecordedIconRequests requests) =>
                    Results.Json(requests.GetCreatePurchaseOrderRequests()));
            app.MapDelete(
                "/_test/requests",
                static (RecordedIconRequests requests) =>
                {
                    requests.Reset();
                    return Results.NoContent();
                });
        }

        app.Run();
    }

    private static async Task<IResult> HandleActivationAsync(
        HttpContext context,
        IOptions<IconMockOptions> options,
        RecordedIconRequests requests)
    {
        if (!HasExpectedToken(
                context.Request,
                options.Value.ActivationAuthToken))
        {
            return Results.Unauthorized();
        }

        var rawJson = await ReadBodyAsync(context.Request, context.RequestAborted);
        if (!TryParse(rawJson, out var document))
        {
            return Results.BadRequest();
        }

        using (document)
        {
            var account = FindString(document.RootElement, "account");
            if (string.IsNullOrWhiteSpace(account))
            {
                return Results.BadRequest();
            }

            requests.RecordActivation(rawJson);
            return Results.Json(new
            {
                response = new
                {
                    results = new[]
                    {
                        new
                        {
                            account_1 = account,
                            action_1 = "activate",
                            bypasstxt_0 = false
                        }
                    }
                }
            });
        }
    }

    private static async Task<IResult> HandleCreatePurchaseOrderAsync(
        HttpContext context,
        IOptions<IconMockOptions> options,
        RecordedIconRequests requests)
    {
        if (!HasExpectedToken(
                context.Request,
                options.Value.PurchaseOrderAuthToken))
        {
            return Results.Unauthorized();
        }

        var rawJson = await ReadBodyAsync(context.Request, context.RequestAborted);
        if (!TryParse(rawJson, out var document))
        {
            return Results.BadRequest();
        }

        using (document)
        {
            if (!TryGetObjectProperty(document.RootElement, "header", out var header))
            {
                return Results.BadRequest();
            }

            var deliveryMethod = FindString(header, "deliveryMethod");
            if (string.IsNullOrWhiteSpace(deliveryMethod))
            {
                return Results.BadRequest();
            }

            var contactId = FindUInt32(header, "contactID");
            requests.RecordCreatePurchaseOrder(rawJson);
            return Results.Json(new
            {
                body = new
                {
                    orderNo = 900001u,
                    createdStatus = "activated",
                    suspended = false,
                    suspendMessage = (string?)null,
                    deliveryMethod = new
                    {
                        deliveryMethodCode = deliveryMethod,
                        deliveryMethodError = (string?)null
                    },
                    contactId = contactId is null
                        ? null
                        : new
                        {
                            contactIdCode = contactId.Value,
                            contactIdError = (string?)null
                        }
                }
            });
        }
    }

    private static bool HasExpectedToken(
        HttpRequest request,
        string expectedToken) =>
        request.Headers.TryGetValue("K8-XI-AuthToken", out var actualToken)
        && actualToken.Count == 1
        && string.Equals(actualToken[0], expectedToken, StringComparison.Ordinal);

    private static async Task<string> ReadBodyAsync(
        HttpRequest request,
        CancellationToken cancellationToken)
    {
        using var reader = new StreamReader(
            request.Body,
            Encoding.UTF8,
            detectEncodingFromByteOrderMarks: true,
            leaveOpen: true);
        return await reader.ReadToEndAsync(cancellationToken);
    }

    private static bool TryParse(
        string rawJson,
        out JsonDocument document)
    {
        try
        {
            document = JsonDocument.Parse(rawJson);
            return true;
        }
        catch (JsonException)
        {
            document = null!;
            return false;
        }
    }

    private static bool TryGetObjectProperty(
        JsonElement element,
        string propertyName,
        out JsonElement value)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in element.EnumerateObject())
            {
                if (string.Equals(
                        property.Name,
                        propertyName,
                        StringComparison.OrdinalIgnoreCase)
                    && property.Value.ValueKind == JsonValueKind.Object)
                {
                    value = property.Value;
                    return true;
                }
            }
        }

        value = default;
        return false;
    }

    private static string? FindString(
        JsonElement element,
        string propertyName)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in element.EnumerateObject())
            {
                if (string.Equals(
                        property.Name,
                        propertyName,
                        StringComparison.OrdinalIgnoreCase)
                    && property.Value.ValueKind == JsonValueKind.String)
                {
                    return property.Value.GetString();
                }

                var nested = FindString(property.Value, propertyName);
                if (nested is not null)
                {
                    return nested;
                }
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var nested = FindString(item, propertyName);
                if (nested is not null)
                {
                    return nested;
                }
            }
        }

        return null;
    }

    private static uint? FindUInt32(
        JsonElement element,
        string propertyName)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in element.EnumerateObject())
            {
                if (string.Equals(
                        property.Name,
                        propertyName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    if (property.Value.ValueKind == JsonValueKind.Number
                        && property.Value.TryGetUInt32(out var numericValue))
                    {
                        return numericValue;
                    }

                    if (property.Value.ValueKind == JsonValueKind.String
                        && uint.TryParse(property.Value.GetString(), out var textValue))
                    {
                        return textValue;
                    }
                }

                var nested = FindUInt32(property.Value, propertyName);
                if (nested is not null)
                {
                    return nested;
                }
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var nested = FindUInt32(item, propertyName);
                if (nested is not null)
                {
                    return nested;
                }
            }
        }

        return null;
    }
}
