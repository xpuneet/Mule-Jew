namespace STUK.PurchaseOrderService.IconMock;

public sealed class RecordedIconRequests
{
    private readonly object _sync = new();
    private readonly List<string> _activationRequests = [];
    private readonly List<string> _createPurchaseOrderRequests = [];

    public void RecordActivation(string rawJson)
    {
        ArgumentNullException.ThrowIfNull(rawJson);
        lock (_sync)
        {
            _activationRequests.Add(rawJson);
        }
    }

    public void RecordCreatePurchaseOrder(string rawJson)
    {
        ArgumentNullException.ThrowIfNull(rawJson);
        lock (_sync)
        {
            _createPurchaseOrderRequests.Add(rawJson);
        }
    }

    public IReadOnlyList<string> GetActivationRequests()
    {
        lock (_sync)
        {
            return _activationRequests.ToArray();
        }
    }

    public IReadOnlyList<string> GetCreatePurchaseOrderRequests()
    {
        lock (_sync)
        {
            return _createPurchaseOrderRequests.ToArray();
        }
    }

    public void Reset()
    {
        lock (_sync)
        {
            _activationRequests.Clear();
            _createPurchaseOrderRequests.Clear();
        }
    }
}
