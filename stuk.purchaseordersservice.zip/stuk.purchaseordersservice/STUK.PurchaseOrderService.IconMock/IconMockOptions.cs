namespace STUK.PurchaseOrderService.IconMock;

public sealed class IconMockOptions
{
    public const string SectionName = "IconMock";

    public string ActivationAuthToken { get; init; } = string.Empty;

    public string PurchaseOrderAuthToken { get; init; } = string.Empty;
}
