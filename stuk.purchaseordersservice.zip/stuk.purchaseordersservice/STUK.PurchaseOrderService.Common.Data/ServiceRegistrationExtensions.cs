using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.DbContexts;
using STUK.PurchaseOrderService.Common.Data.Sql;

namespace STUK.PurchaseOrderService.Common.Data;

public static class ServiceRegistrationExtensions
{
    private const string MissingConnectionStringMessage =
        "Connection string 'PurchaseOrdersServiceDB' is required.";

    public static IServiceCollection AddPurchaseOrderPersistence(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(services);
        ArgumentNullException.ThrowIfNull(configuration);

        var connectionString = configuration.GetConnectionString(
            ConfigConstants.PurchaseOrdersDbConnectionStringName);
        return services.AddPurchaseOrderPersistence(
            RequireConnectionString(connectionString));
    }

    public static IServiceCollection AddPurchaseOrderPersistence(
        this IServiceCollection services,
        string connectionString)
    {
        ArgumentNullException.ThrowIfNull(services);
        connectionString = RequireConnectionString(connectionString);

        services.AddScoped(_ => new PurchaseOrdersDbContext(connectionString));
        services.AddScoped<ISqlConnectionFactory, SqlConnectionFactory>();
        services.AddScoped<IStoredProcedureExecutor, StoredProcedureExecutor>();
        services.AddScoped<IPurchaseOrdersRepository, PurchaseOrdersRepository>();
        services.AddScoped<IPurchaseOrderAdminRepository, PurchaseOrderAdminRepository>();
        services.AddScoped<IPurchaseOrderBatchRepository, PurchaseOrderBatchRepository>();
        services.AddScoped<IPurchaseOrderProcessingRepository, PurchaseOrderProcessingRepository>();
        services.AddScoped<IPurchaseOrderSupportRepository, PurchaseOrderSupportRepository>();
        services.AddScoped<IPurchaseOrderNotificationRepository, PurchaseOrderNotificationRepository>();
        services.AddScoped<IRelexNotificationRepository, RelexNotificationRepository>();

        return services;
    }

    private static string RequireConnectionString(string? connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(MissingConnectionStringMessage);
        }

        return connectionString;
    }
}
