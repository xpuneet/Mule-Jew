using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class PurchaseOrderNotificationRepository : IPurchaseOrderNotificationRepository
{
    private const string RegisterNotificationProcedure =
        "po.sp_register_purchase_order_notification";
    private const string CompleteNotificationProcedure =
        "po.sp_complete_purchase_order_notification";
    private const string EnqueueEmailNotificationProcedure =
        "po.sp_enqueue_purchase_order_email_notification";
    private const string ClaimEmailNotificationsProcedure =
        "po.sp_claim_purchase_order_email_notifications";
    private const string DeferEmailNotificationProcedure =
        "po.sp_defer_purchase_order_email_notification";
    private const string RescheduleEmailNotificationProcedure =
        "po.sp_reschedule_purchase_order_email_notification";
    private const string CompleteEmailNotificationProcedure =
        "po.sp_complete_purchase_order_email_notification";
    private const string GetEmailNotificationQueueSummaryProcedure =
        "po.sp_get_purchase_order_email_notification_queue_summary";

    private readonly IStoredProcedureExecutor _executor;

    public PurchaseOrderNotificationRepository(IStoredProcedureExecutor executor)
    {
        ArgumentNullException.ThrowIfNull(executor);
        _executor = executor;
    }

    public Task<RegisteredPurchaseOrderNotification> RegisterNotificationAsync(
        RegisterPurchaseOrderNotificationCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            RegisterNotificationProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
                SqlParameterFactory.UniqueIdentifier("@batchId", command.BatchId),
                SqlParameterFactory.VarChar("@channel", 50, command.Channel),
                SqlParameterFactory.NVarChar("@templateKey", 100, command.TemplateKey),
                SqlParameterFactory.NVarChar(
                    "@recipientGroupKey",
                    100,
                    command.RecipientGroupKey),
                SqlParameterFactory.NVarChar(
                    "@attachmentBlobName",
                    512,
                    command.AttachmentBlobName),
                SqlParameterFactory.DateTimeOffset3("@createdDateTime", command.CreatedDateTime)
            ]);

        return _executor.QuerySingleAsync(call, MapRegisteredNotification, cancellationToken);
    }

    public Task<CompletedPurchaseOrderNotification> CompleteNotificationAsync(
        CompletePurchaseOrderNotificationCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            CompleteNotificationProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
                SqlParameterFactory.VarChar("@status", 50, command.Status),
                SqlParameterFactory.NVarChar(
                    "@providerMessageId",
                    256,
                    command.ProviderMessageId),
                SqlParameterFactory.VarChar("@failureCode", 100, command.FailureCode),
                SqlParameterFactory.NVarChar(
                    "@failureDescription",
                    1000,
                    command.FailureDescription),
                SqlParameterFactory.DateTimeOffset3(
                    "@completedDateTime",
                    command.CompletedDateTime),
                SqlParameterFactory.Binary(
                    "@expectedNotificationRowVersion",
                    8,
                    command.ExpectedNotificationRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapCompletedNotification, cancellationToken);
    }

    public Task<EnqueuedPurchaseOrderEmailNotification> EnqueueEmailNotificationAsync(
        EnqueuePurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            EnqueueEmailNotificationProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
                SqlParameterFactory.UniqueIdentifier("@batchId", command.BatchId),
                SqlParameterFactory.VarChar("@eventType", 100, command.EventType),
                SqlParameterFactory.NVarChar(
                    "@businessCorrelationId",
                    256,
                    command.BusinessCorrelationId),
                SqlParameterFactory.SmallInt(
                    "@emailEnvelopeVersion",
                    command.EmailEnvelopeVersion),
                SqlParameterFactory.NVarChar("@emailEnvelopeJson", -1, command.EmailEnvelopeJson),
                SqlParameterFactory.NVarChar("@templateKey", 100, command.TemplateKey),
                SqlParameterFactory.NVarChar(
                    "@recipientGroupKey",
                    100,
                    command.RecipientGroupKey),
                SqlParameterFactory.NVarChar(
                    "@attachmentBlobName",
                    512,
                    command.AttachmentBlobName),
                SqlParameterFactory.DateTimeOffset3("@createdDateTime", command.CreatedDateTime)
            ]);

        return _executor.QuerySingleAsync(call, MapEnqueuedEmailNotification, cancellationToken);
    }

    public Task<IReadOnlyList<ClaimedPurchaseOrderEmailNotification>> ClaimDueEmailNotificationsAsync(
        ClaimPurchaseOrderEmailNotificationsCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            ClaimEmailNotificationsProcedure,
            [
                SqlParameterFactory.DateTimeOffset3("@asOfDateTime", command.AsOfDateTime),
                SqlParameterFactory.Int("@leaseDurationSeconds", command.LeaseDurationSeconds),
                SqlParameterFactory.Int("@maxNotifications", command.MaxNotifications),
                SqlParameterFactory.Int(
                    "@maxAttemptsPerMinute",
                    command.MaxAttemptsPerMinute),
                SqlParameterFactory.Int("@maxAttemptsPerHour", command.MaxAttemptsPerHour)
            ]);

        return _executor.QueryAsync(call, MapClaimedEmailNotification, cancellationToken);
    }

    public Task<UpdatedPurchaseOrderEmailNotification> DeferEmailNotificationAsync(
        DeferPurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            DeferEmailNotificationProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
                SqlParameterFactory.UniqueIdentifier("@leaseId", command.LeaseId),
                SqlParameterFactory.DateTimeOffset3(
                    "@nextAttemptDateTime",
                    command.NextAttemptDateTime),
                SqlParameterFactory.DateTimeOffset3(
                    "@completedDateTime",
                    command.CompletedDateTime),
                SqlParameterFactory.Binary(
                    "@expectedNotificationRowVersion",
                    8,
                    command.ExpectedNotificationRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapUpdatedEmailNotification, cancellationToken);
    }

    public Task<UpdatedPurchaseOrderEmailNotification> RescheduleEmailNotificationAsync(
        ReschedulePurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            RescheduleEmailNotificationProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
                SqlParameterFactory.UniqueIdentifier("@leaseId", command.LeaseId),
                SqlParameterFactory.VarChar("@outcome", 50, command.Outcome),
                SqlParameterFactory.VarChar("@failureCategory", 50, command.FailureCategory),
                SqlParameterFactory.VarChar("@failureCode", 100, command.FailureCode),
                SqlParameterFactory.NVarChar(
                    "@failureDescription",
                    1000,
                    command.FailureDescription),
                SqlParameterFactory.SmallInt("@httpStatusCode", command.HttpStatusCode),
                SqlParameterFactory.DateTimeOffset3(
                    "@nextAttemptDateTime",
                    command.NextAttemptDateTime),
                SqlParameterFactory.DateTimeOffset3(
                    "@completedDateTime",
                    command.CompletedDateTime),
                SqlParameterFactory.Binary(
                    "@expectedNotificationRowVersion",
                    8,
                    command.ExpectedNotificationRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapUpdatedEmailNotification, cancellationToken);
    }

    public Task<CompletedPurchaseOrderEmailNotification> CompleteEmailNotificationAsync(
        CompletePurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            CompleteEmailNotificationProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
                SqlParameterFactory.UniqueIdentifier("@leaseId", command.LeaseId),
                SqlParameterFactory.VarChar("@status", 50, command.Status),
                SqlParameterFactory.VarChar("@attemptOutcome", 50, command.AttemptOutcome),
                SqlParameterFactory.Bit("@incrementFailureCount", command.IncrementFailureCount),
                SqlParameterFactory.NVarChar(
                    "@providerMessageId",
                    256,
                    command.ProviderMessageId),
                SqlParameterFactory.VarChar(
                    "@failureCategory",
                    50,
                    command.FailureCategory),
                SqlParameterFactory.VarChar("@failureCode", 100, command.FailureCode),
                SqlParameterFactory.NVarChar(
                    "@failureDescription",
                    1000,
                    command.FailureDescription),
                SqlParameterFactory.SmallInt("@httpStatusCode", command.HttpStatusCode),
                SqlParameterFactory.DateTimeOffset3(
                    "@completedDateTime",
                    command.CompletedDateTime),
                SqlParameterFactory.Binary(
                    "@expectedNotificationRowVersion",
                    8,
                    command.ExpectedNotificationRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapCompletedEmailNotification, cancellationToken);
    }

    public Task<PurchaseOrderEmailNotificationQueueSummary> GetEmailNotificationQueueSummaryAsync(
        GetPurchaseOrderEmailNotificationQueueSummaryQuery query,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetEmailNotificationQueueSummaryProcedure,
            [
                SqlParameterFactory.DateTimeOffset3("@asOfDateTime", query.AsOfDateTime),
                SqlParameterFactory.DateTimeOffset3(
                    "@terminalFailureSinceDateTime",
                    query.TerminalFailureSinceDateTime)
            ]);

        return _executor.QuerySingleAsync(call, MapEmailNotificationQueueSummary, cancellationToken);
    }

    private static RegisteredPurchaseOrderNotification MapRegisteredNotification(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("NotificationId")),
            reader.GetString(reader.GetOrdinal("Status")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static CompletedPurchaseOrderNotification MapCompletedNotification(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("NotificationId")),
            reader.GetString(reader.GetOrdinal("Status")),
            GetNullableValue<DateTimeOffset>(reader, "SentDateTime"),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static EnqueuedPurchaseOrderEmailNotification MapEnqueuedEmailNotification(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("NotificationId")),
            reader.GetString(reader.GetOrdinal("Status")),
            reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("NextAttemptDateTime")),
            reader.GetInt32(reader.GetOrdinal("AttemptCount")),
            reader.GetInt32(reader.GetOrdinal("FailureCount")),
            reader.GetInt32(reader.GetOrdinal("ThrottleCount")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("PayloadSha256")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static ClaimedPurchaseOrderEmailNotification MapClaimedEmailNotification(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("NotificationId")),
            GetRequiredReference<string>(reader, "EventType"),
            GetRequiredReference<string>(reader, "BusinessCorrelationId"),
            GetRequiredValue<short>(reader, "EmailEnvelopeVersion"),
            GetRequiredReference<string>(reader, "EmailEnvelopeJson"),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("PayloadSha256")),
            reader.GetInt32(reader.GetOrdinal("AttemptCount")),
            reader.GetInt32(reader.GetOrdinal("FailureCount")),
            reader.GetInt32(reader.GetOrdinal("ThrottleCount")),
            reader.GetGuid(reader.GetOrdinal("LeaseId")),
            reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("LeaseExpiresDateTime")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static UpdatedPurchaseOrderEmailNotification MapUpdatedEmailNotification(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("NotificationId")),
            reader.GetString(reader.GetOrdinal("Status")),
            reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("NextAttemptDateTime")),
            reader.GetInt32(reader.GetOrdinal("FailureCount")),
            reader.GetInt32(reader.GetOrdinal("ThrottleCount")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static CompletedPurchaseOrderEmailNotification MapCompletedEmailNotification(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("NotificationId")),
            reader.GetString(reader.GetOrdinal("Status")),
            GetNullableValue<DateTimeOffset>(reader, "SentDateTime"),
            reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("CompletedDateTime")),
            reader.GetInt32(reader.GetOrdinal("FailureCount")),
            reader.GetInt32(reader.GetOrdinal("ThrottleCount")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static PurchaseOrderEmailNotificationQueueSummary MapEmailNotificationQueueSummary(
        DbDataReader reader) => new(
            GetInt32Count(reader, "ClaimablePendingCount"),
            GetNullableValue<DateTimeOffset>(reader, "OldestClaimablePendingDateTime"),
            GetInt32Count(reader, "DelayedPendingCount"),
            GetInt32Count(reader, "ActiveLeasedCount"),
            GetInt32Count(reader, "ExpiredLeasedCount"),
            GetInt32Count(reader, "UnsendableLegacyPendingCount"),
            GetInt32Count(reader, "TerminalFailureCount"));

    private static T GetRequiredReference<T>(DbDataReader reader, string columnName)
        where T : class =>
        GetNullableReference<T>(reader, columnName)
        ?? throw new InvalidOperationException($"The {columnName} result column cannot be null.");

    private static T? GetNullableReference<T>(DbDataReader reader, string columnName)
        where T : class
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetFieldValue<T>(ordinal);
    }

    private static T GetRequiredValue<T>(DbDataReader reader, string columnName)
        where T : struct =>
        GetNullableValue<T>(reader, columnName)
        ?? throw new InvalidOperationException($"The {columnName} result column cannot be null.");

    private static int GetInt32Count(DbDataReader reader, string columnName) =>
        checked((int)reader.GetInt64(reader.GetOrdinal(columnName)));

    private static T? GetNullableValue<T>(DbDataReader reader, string columnName)
        where T : struct
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetFieldValue<T>(ordinal);
    }
}
