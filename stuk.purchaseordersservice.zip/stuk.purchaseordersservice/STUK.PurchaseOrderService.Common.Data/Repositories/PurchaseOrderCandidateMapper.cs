using STUK.PurchaseOrderService.Common.Data.Extensions;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

internal static class PurchaseOrderCandidateMapper
{
    internal static PurchaseOrderCandidateDetails MapDetails(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        GetNullableValue<Guid>(reader, "BatchId"),
        reader.GetString(reader.GetOrdinal("Source")),
        reader.GetString(reader.GetOrdinal("Kind")),
        reader.GetString(reader.GetOrdinal("Account")),
        reader.GetString(reader.GetOrdinal("Branch")),
        reader.GetValueOrDefault<string>("Reference"),
        reader.GetValueOrDefault<string>("IconPurchaseOrderNumber"),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("StatusDateTime")),
        reader.GetValueOrDefault<string>("StatusReason"),
        GetNullableValue<int>(reader, "ProcessBatchNo"),
        reader.GetValueOrDefault<string>("PayloadMD5"),
        reader.GetValueOrDefault<string>("MessageCode"),
        reader.GetValueOrDefault<string>("MessageDescription"),
        reader.GetValueOrDefault<string>("PreviousMessageCode"),
        reader.GetValueOrDefault<string>("PreviousMessageDescription"),
        reader.GetString(reader.GetOrdinal("PayloadJson")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("AcceptedDateTime")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("CreatedDateTime")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("UpdatedDateTime")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("RefreshDateTime")),
        reader.GetInt32(reader.GetOrdinal("PendingRetriesCount")),
        reader.GetInt32(reader.GetOrdinal("ProcessingRetriesCount")),
        GetNullableValue<Guid>(reader, "LeaseToken"),
        reader.GetValueOrDefault<string>("LeaseOwner"),
        GetNullableValue<DateTimeOffset>(reader, "LeaseAcquiredDateTime"),
        GetNullableValue<DateTimeOffset>(reader, "LeaseExpiresDateTime"),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static T? GetNullableValue<T>(DbDataReader reader, string columnName)
        where T : struct
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetFieldValue<T>(ordinal);
    }
}
