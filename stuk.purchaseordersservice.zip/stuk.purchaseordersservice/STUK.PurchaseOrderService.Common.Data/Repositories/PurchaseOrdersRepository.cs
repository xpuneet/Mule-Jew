using System.Data.Common;
using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Serialization;
using STUK.PurchaseOrderService.Common.Data.Extensions;
using STUK.PurchaseOrderService.Common.Data.Sql;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class PurchaseOrdersRepository : IPurchaseOrdersRepository
{
    private const string CreateCandidateProcedure = "po.sp_create_purchase_order_candidate";
    private const string SearchCandidatesProcedure = "po.sp_search_purchase_order_candidates";
    private static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.Web)
    {
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    private readonly IStoredProcedureExecutor _executor;

    public PurchaseOrdersRepository(IStoredProcedureExecutor executor)
    {
        ArgumentNullException.ThrowIfNull(executor);
        _executor = executor;
    }

    public async Task AddCandidate(PurchaseOrderCandidate candidate, CancellationToken cancellationToken = default)
    {
        var header = candidate.Payload.PurchaseOrderHeader!;
        var call = new StoredProcedureCall(
            CreateCandidateProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@candidateId", candidate.CandidateId),
                SqlParameterFactory.NVarChar("@account", 50, header.Account),
                SqlParameterFactory.NVarChar(
                    "@branch",
                    20,
                    header.Branch.ToString(CultureInfo.InvariantCulture)),
                SqlParameterFactory.NVarChar("@reference", 100, header.Reference),
                SqlParameterFactory.VarChar(
                    "@status",
                    50,
                    EnumMemberValue.GetSerializedValue(candidate.CandidateStatus.Status)),
                SqlParameterFactory.DateTimeOffset3("@acceptedDateTime", candidate.AcceptedDateTime),
                SqlParameterFactory.NVarChar(
                    "@payloadJson",
                    -1,
                    JsonSerializer.Serialize(candidate.Payload, SerializerOptions)),
                SqlParameterFactory.NVarChar("@actor", 256, header.CreateUser)
            ]);

        await _executor.ExecuteNonQueryAsync(call, cancellationToken);
    }

    public async Task<IReadOnlyCollection<PurchaseOrderSummary>> SearchCandidates(
        PurchaseOrderSearchCriteria criteria,
        CancellationToken cancellationToken = default)
    {
        var status = criteria.Status.HasValue
            ? EnumMemberValue.GetSerializedValue(criteria.Status.Value)
            : null;
        var call = new StoredProcedureCall(
            SearchCandidatesProcedure,
            [
                SqlParameterFactory.NVarChar("@source", 50, criteria.Source),
                SqlParameterFactory.NVarChar("@account", 50, criteria.Account),
                SqlParameterFactory.NVarChar("@branch", 20, criteria.Branch),
                SqlParameterFactory.NVarChar("@reference", 100, criteria.Reference),
                SqlParameterFactory.NVarChar(
                    "@iconPurchaseOrderNumber",
                    100,
                    criteria.IconPurchaseOrderNumber),
                SqlParameterFactory.VarChar("@status", 50, status),
                SqlParameterFactory.DateTimeOffset3(
                    "@acceptedAfterDateTimeUtc",
                    criteria.AcceptedAfterDateTimeUtc),
                SqlParameterFactory.DateTimeOffset3(
                    "@acceptedUntilDateTimeUtc",
                    criteria.AcceptedUntilDateTimeUtc),
                SqlParameterFactory.Int("@pageNumber", criteria.PageNumber),
                SqlParameterFactory.Int("@pageSize", criteria.PageSize)
            ]);

        return await _executor.QueryAsync(call, MapSummary, cancellationToken);
    }

    private static PurchaseOrderSummary MapSummary(DbDataReader reader) => new()
    {
        CandidateId = reader.GetGuid(reader.GetOrdinal("CandidateId")),
        Source = reader.GetString(reader.GetOrdinal("Source")),
        Account = reader.GetString(reader.GetOrdinal("Account")),
        Branch = reader.GetString(reader.GetOrdinal("Branch")),
        Reference = reader.GetValueOrDefault<string>("Reference"),
        IconPurchaseOrderNumber = reader.GetValueOrDefault<string>("IconPurchaseOrderNumber"),
        Status = reader.GetString(reader.GetOrdinal("Status")),
        AcceptedDateTime = reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("AcceptedDateTime"))
    };
}
