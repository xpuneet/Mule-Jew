using Microsoft.Extensions.Configuration;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using System.Configuration;

namespace STUK.PurchaseOrderService.Common.Data.Repositories.DbContexts;

public sealed class PurchaseOrdersDbContext
{
    public PurchaseOrdersDbContext(string connectionString)
    {
        ArgumentNullException.ThrowIfNull(connectionString);
        ConnectionString = connectionString;
    }

    public PurchaseOrdersDbContext(IConfiguration configuration)
    {
        ConnectionString = configuration.GetConnectionString(ConfigConstants.PurchaseOrdersDbConnectionStringName)
            ?? throw new ConfigurationErrorsException($"ConnectionString not found: '{ConfigConstants.PurchaseOrdersDbConnectionStringName}'");
    }

    public string ConnectionString { get; }
}
