﻿using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.PurchaseOrderService.Common.Data.Repositories
{
    public interface IEmailService
    {
        Task<EmailSendResponse> SendAsync(
      string subject,
      IEnumerable<string> recipients,
      string htmlContent,
      IEnumerable<string>? cc = null,
      IEnumerable<string>? bcc = null);


    }

}
