using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.Common.Data.Extensions;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class PurchaseOrderAdminRepository : IPurchaseOrderAdminRepository
{
    private const string SummaryProcedure =
        "po.sp_get_purchase_order_candidate_summary";
    private const string GetCandidateProcedure = "po.sp_get_purchase_order_candidate";
    private const string BatchSummaryProcedure =
        "po.sp_get_purchase_order_batch_summary";
    private const string SearchBatchesProcedure =
        "po.sp_search_purchase_order_batches";
    private const string GetBatchProcedure = "po.sp_get_purchase_order_batch";
    private const string BatchCandidateSummaryProcedure =
        "po.sp_get_purchase_order_batch_candidate_summary";
    private const string SearchBatchCandidatesProcedure =
        "po.sp_search_purchase_order_batch_candidates";

    private readonly IStoredProcedureExecutor _executor;

    public PurchaseOrderAdminRepository(IStoredProcedureExecutor executor)
    {
        ArgumentNullException.ThrowIfNull(executor);
        _executor = executor;
    }

    public Task<IReadOnlyList<PurchaseOrderStatusCount>> GetStatusSummaryAsync(
        PurchaseOrderStatusSummaryQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);
        var call = new StoredProcedureCall(
            SummaryProcedure,
            [
                SqlParameterFactory.NVarChar("@source", 50, query.Source),
                SqlParameterFactory.DateTimeOffset3(
                    "@afterDateTimeUtc",
                    query.AfterDateTimeUtc),
                SqlParameterFactory.DateTimeOffset3(
                    "@untilDateTimeUtc",
                    query.UntilDateTimeUtc)
            ]);

        return _executor.QueryAsync(call, MapStatusCount, cancellationToken);
    }

    public Task<PurchaseOrderCandidateDetails> GetCandidateAsync(
        Guid candidateId,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetCandidateProcedure,
            [SqlParameterFactory.UniqueIdentifier("@candidateId", candidateId)]);

        return _executor.QuerySingleAsync(
            call,
            PurchaseOrderCandidateMapper.MapDetails,
            cancellationToken);
    }

    public Task<IReadOnlyList<PurchaseOrderBatchStatusCount>> GetBatchStatusSummaryAsync(
        PurchaseOrderBatchStatusSummaryQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);
        var call = new StoredProcedureCall(
            BatchSummaryProcedure,
            [
                SqlParameterFactory.NVarChar("@source", 50, query.Source),
                SqlParameterFactory.DateTimeOffset3(
                    "@afterDateTimeUtc",
                    query.AfterDateTimeUtc),
                SqlParameterFactory.DateTimeOffset3(
                    "@untilDateTimeUtc",
                    query.UntilDateTimeUtc)
            ]);

        return _executor.QueryAsync(call, MapBatchStatusCount, cancellationToken);
    }

    public Task<IReadOnlyList<PurchaseOrderBatchSummary>> SearchBatchesAsync(
        PurchaseOrderBatchSearchQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);
        var call = new StoredProcedureCall(
            SearchBatchesProcedure,
            [
                SqlParameterFactory.NVarChar("@source", 50, query.Source),
                SqlParameterFactory.NVarChar(
                    "@originalFileName",
                    260,
                    query.OriginalFileName),
                SqlParameterFactory.VarChar("@status", 50, query.Status),
                SqlParameterFactory.DateTimeOffset3(
                    "@discoveredAfterDateTimeUtc",
                    query.DiscoveredAfterDateTimeUtc),
                SqlParameterFactory.DateTimeOffset3(
                    "@discoveredUntilDateTimeUtc",
                    query.DiscoveredUntilDateTimeUtc),
                SqlParameterFactory.Int("@pageNumber", query.PageNumber),
                SqlParameterFactory.Int("@pageSize", query.PageSize)
            ]);

        return _executor.QueryAsync(call, MapBatchSummary, cancellationToken);
    }

    public Task<PurchaseOrderBatchDetails> GetBatchAsync(
        Guid batchId,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetBatchProcedure,
            [SqlParameterFactory.UniqueIdentifier("@batchId", batchId)]);

        return _executor.QuerySingleAsync(call, MapBatchDetails, cancellationToken);
    }

    public Task<IReadOnlyList<PurchaseOrderStatusCount>> GetBatchCandidateStatusSummaryAsync(
        Guid batchId,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            BatchCandidateSummaryProcedure,
            [SqlParameterFactory.UniqueIdentifier("@batchId", batchId)]);

        return _executor.QueryAsync(call, MapStatusCount, cancellationToken);
    }

    public Task<IReadOnlyList<PurchaseOrderBatchOutcome>> SearchBatchCandidatesAsync(
        PurchaseOrderBatchCandidateSearchQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);
        var call = new StoredProcedureCall(
            SearchBatchCandidatesProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@batchId", query.BatchId),
                SqlParameterFactory.VarChar("@status", 50, query.Status),
                SqlParameterFactory.Int("@pageNumber", query.PageNumber),
                SqlParameterFactory.Int("@pageSize", query.PageSize)
            ]);

        return _executor.QueryAsync(call, MapBatchOutcome, cancellationToken);
    }

    private static PurchaseOrderStatusCount MapStatusCount(DbDataReader reader) => new(
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetInt64(reader.GetOrdinal("CandidateCount")));

    private static PurchaseOrderBatchStatusCount MapBatchStatusCount(DbDataReader reader) => new(
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetInt64(reader.GetOrdinal("BatchCount")));

    private static PurchaseOrderBatchSummary MapBatchSummary(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("BatchId")),
        reader.GetString(reader.GetOrdinal("Source")),
        reader.GetString(reader.GetOrdinal("OriginalFileName")),
        reader.GetString(reader.GetOrdinal("SourceFilePath")),
        reader.GetInt64(reader.GetOrdinal("FileContentLength")),
        reader.GetString(reader.GetOrdinal("Status")),
        GetNullableValue<int>(reader, "ExpectedRowCount"),
        reader.GetInt32(reader.GetOrdinal("ParsedRowCount")),
        reader.GetInt32(reader.GetOrdinal("CandidateCount")),
        reader.GetValueOrDefault<string>("FailureCode"),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("DiscoveredDateTime")),
        GetNullableValue<DateTimeOffset>(reader, "CompletedDateTime"),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("UpdatedDateTime")));

    private static PurchaseOrderBatchDetails MapBatchDetails(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("BatchId")),
        reader.GetString(reader.GetOrdinal("Source")),
        reader.GetString(reader.GetOrdinal("OriginalFileName")),
        reader.GetString(reader.GetOrdinal("SourceFilePath")),
        reader.GetInt64(reader.GetOrdinal("FileContentLength")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("FileSha256")),
        reader.GetString(reader.GetOrdinal("Status")),
        GetNullableValue<int>(reader, "ExpectedRowCount"),
        reader.GetInt32(reader.GetOrdinal("ParsedRowCount")),
        reader.GetInt32(reader.GetOrdinal("CandidateCount")),
        reader.GetValueOrDefault<string>("FailureCode"),
        reader.GetValueOrDefault<string>("FailureDescription"),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("DiscoveredDateTime")),
        GetNullableValue<DateTimeOffset>(reader, "IngestionStartedDateTime"),
        GetNullableValue<DateTimeOffset>(reader, "CompletedDateTime"),
        reader.GetString(reader.GetOrdinal("CreatedBy")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("UpdatedDateTime")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static PurchaseOrderBatchOutcome MapBatchOutcome(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        reader.GetString(reader.GetOrdinal("Account")),
        reader.GetString(reader.GetOrdinal("Branch")),
        reader.GetValueOrDefault<string>("Reference"),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetValueOrDefault<string>("IconPurchaseOrderNumber"),
        reader.GetValueOrDefault<string>("StatusReason"),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("AcceptedDateTime")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("UpdatedDateTime")));

    private static T? GetNullableValue<T>(DbDataReader reader, string columnName)
        where T : struct
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetFieldValue<T>(ordinal);
    }
}
