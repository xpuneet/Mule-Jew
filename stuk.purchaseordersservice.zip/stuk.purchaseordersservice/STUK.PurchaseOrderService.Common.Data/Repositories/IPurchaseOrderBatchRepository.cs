using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public interface IPurchaseOrderBatchRepository
{
    Task<PurchaseOrderBatchState> RegisterBatchAsync(
        RegisterPurchaseOrderBatchCommand command,
        CancellationToken cancellationToken = default);

    Task AddCandidateAsync(
        AddPurchaseOrderCandidateToBatchCommand command,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderBatchPromotionResult> CompleteBatchAsync(
        CompletePurchaseOrderBatchCommand command,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderBatchState> FailBatchAsync(
        FailPurchaseOrderBatchCommand command,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderBatchDetails> GetBatchAsync(
        Guid batchId,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderBatchDetails> GetBatchBySourceHashAsync(
        string source,
        byte[] fileSha256,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PurchaseOrderBatchOutcome>> GetBatchOutcomesAsync(
        Guid batchId,
        CancellationToken cancellationToken = default);
}
