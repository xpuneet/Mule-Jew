using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public interface IPurchaseOrdersRepository
{
    Task AddCandidate(PurchaseOrderCandidate candidate, CancellationToken cancellationToken = default);

    Task<IReadOnlyCollection<PurchaseOrderSummary>> SearchCandidates(
        PurchaseOrderSearchCriteria criteria,
        CancellationToken cancellationToken = default);
}
