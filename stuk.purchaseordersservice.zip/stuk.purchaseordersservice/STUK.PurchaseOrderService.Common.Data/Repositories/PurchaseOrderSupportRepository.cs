using STUK.PurchaseOrderService.Common.Data.Extensions;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class PurchaseOrderSupportRepository : IPurchaseOrderSupportRepository
{
    private const string RequestRetryProcedure = "po.sp_request_purchase_order_retry";
    private const string CancelCandidateProcedure = "po.sp_cancel_purchase_order_candidate";
    private const string GetAuditProcedure = "po.sp_get_purchase_order_audit";

    private readonly IStoredProcedureExecutor _executor;

    public PurchaseOrderSupportRepository(IStoredProcedureExecutor executor)
    {
        ArgumentNullException.ThrowIfNull(executor);
        _executor = executor;
    }

    public Task<PurchaseOrderSupportActionResult> RequestRetryAsync(
        RequestPurchaseOrderRetryCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            RequestRetryProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.NVarChar("@actor", 256, command.Actor),
                SqlParameterFactory.NVarChar("@reason", 1000, command.Reason),
                SqlParameterFactory.DateTimeOffset3(
                    "@requestedDateTime",
                    command.RequestedDateTime),
                SqlParameterFactory.Binary(
                    "@expectedCandidateRowVersion",
                    8,
                    command.ExpectedCandidateRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapSupportAction, cancellationToken);
    }

    public Task<PurchaseOrderSupportActionResult> CancelCandidateAsync(
        CancelPurchaseOrderCandidateCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            CancelCandidateProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.NVarChar("@actor", 256, command.Actor),
                SqlParameterFactory.NVarChar("@reason", 1000, command.Reason),
                SqlParameterFactory.DateTimeOffset3(
                    "@cancelledDateTime",
                    command.CancelledDateTime),
                SqlParameterFactory.Binary(
                    "@expectedCandidateRowVersion",
                    8,
                    command.ExpectedCandidateRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapSupportAction, cancellationToken);
    }

    public Task<IReadOnlyList<PurchaseOrderAuditEntry>> GetAuditAsync(
        GetPurchaseOrderAuditQuery query,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetAuditProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@candidateId", query.CandidateId),
                SqlParameterFactory.Int("@pageNumber", query.PageNumber),
                SqlParameterFactory.Int("@pageSize", query.PageSize)
            ]);

        return _executor.QueryAsync(call, MapAuditEntry, cancellationToken);
    }

    private static PurchaseOrderSupportActionResult MapSupportAction(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static PurchaseOrderAuditEntry MapAuditEntry(DbDataReader reader) => new(
        reader.GetString(reader.GetOrdinal("Action")),
        reader.GetString(reader.GetOrdinal("Method")),
        reader.GetString(reader.GetOrdinal("Actor")),
        reader.GetValueOrDefault<string>("Reason"),
        reader.GetValueOrDefault<string>("PreviousStatus"),
        reader.GetValueOrDefault<string>("CurrentStatus"),
        reader.GetValueOrDefault<string>("PreviousPayloadJson"),
        reader.GetValueOrDefault<string>("CurrentPayloadJson"),
        reader.GetValueOrDefault<byte[]>("BusinessPayloadHash"),
        GetNullableValue<Guid>(reader, "CorrelationId"),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("ChangedDateTime")));

    private static T? GetNullableValue<T>(DbDataReader reader, string columnName)
        where T : struct
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetFieldValue<T>(ordinal);
    }
}
