using STUK.PurchaseOrderService.Common.Data.Extensions;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class PurchaseOrderBatchRepository : IPurchaseOrderBatchRepository
{
    private const string RegisterBatchProcedure = "po.sp_register_purchase_order_batch";
    private const string AddCandidateProcedure = "po.sp_add_purchase_order_candidate_to_batch";
    private const string CompleteBatchProcedure = "po.sp_complete_purchase_order_batch";
    private const string FailBatchProcedure = "po.sp_fail_purchase_order_batch";
    private const string GetBatchProcedure = "po.sp_get_purchase_order_batch";
    private const string GetBatchBySourceHashProcedure =
        "po.sp_get_purchase_order_batch_by_source_hash";
    private const string GetBatchOutcomesProcedure = "po.sp_get_purchase_order_batch_outcomes";

    private readonly IStoredProcedureExecutor _executor;

    public PurchaseOrderBatchRepository(IStoredProcedureExecutor executor)
    {
        ArgumentNullException.ThrowIfNull(executor);
        _executor = executor;
    }

    public Task<PurchaseOrderBatchState> RegisterBatchAsync(
        RegisterPurchaseOrderBatchCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            RegisterBatchProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@batchId", command.BatchId),
                SqlParameterFactory.NVarChar("@originalFileName", 260, command.OriginalFileName),
                SqlParameterFactory.NVarChar(
                    "@sourceFilePath",
                    512,
                    command.SourceFilePath),
                SqlParameterFactory.BigInt("@fileContentLength", command.FileContentLength),
                SqlParameterFactory.Binary("@fileSha256", 32, command.FileSha256),
                SqlParameterFactory.Int("@expectedRowCount", command.ExpectedRowCount),
                SqlParameterFactory.DateTimeOffset3(
                    "@discoveredDateTime",
                    command.DiscoveredDateTime),
                SqlParameterFactory.NVarChar("@actor", 256, command.Actor)
            ]);

        return _executor.QuerySingleAsync(call, MapBatchState, cancellationToken);
    }

    public async Task AddCandidateAsync(
        AddPurchaseOrderCandidateToBatchCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            AddCandidateProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@batchId", command.BatchId),
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.NVarChar("@account", 50, command.Account),
                SqlParameterFactory.NVarChar("@branch", 20, command.Branch),
                SqlParameterFactory.NVarChar("@reference", 100, command.Reference),
                SqlParameterFactory.Int("@sourceRowCount", command.SourceRowCount),
                SqlParameterFactory.DateTimeOffset3("@acceptedDateTime", command.AcceptedDateTime),
                SqlParameterFactory.NVarChar("@payloadJson", -1, command.PayloadJson),
                SqlParameterFactory.NVarChar("@actor", 256, command.Actor)
            ]);

        await _executor.ExecuteNonQueryAsync(call, cancellationToken);
    }

    public Task<PurchaseOrderBatchPromotionResult> CompleteBatchAsync(
        CompletePurchaseOrderBatchCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            CompleteBatchProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@batchId", command.BatchId),
                SqlParameterFactory.Int("@expectedCandidateCount", command.ExpectedCandidateCount),
                SqlParameterFactory.Int("@parsedRowCount", command.ParsedRowCount),
                SqlParameterFactory.DateTimeOffset3("@completedDateTime", command.CompletedDateTime),
                SqlParameterFactory.NVarChar("@actor", 256, command.Actor),
                SqlParameterFactory.Binary(
                    "@expectedBatchRowVersion",
                    8,
                    command.ExpectedBatchRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapBatchPromotion, cancellationToken);
    }

    public Task<PurchaseOrderBatchState> FailBatchAsync(
        FailPurchaseOrderBatchCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            FailBatchProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@batchId", command.BatchId),
                SqlParameterFactory.VarChar("@failureCode", 100, command.FailureCode),
                SqlParameterFactory.NVarChar(
                    "@failureDescription",
                    1000,
                    command.FailureDescription),
                SqlParameterFactory.DateTimeOffset3("@failedDateTime", command.FailedDateTime),
                SqlParameterFactory.NVarChar("@actor", 256, command.Actor),
                SqlParameterFactory.Binary(
                    "@expectedBatchRowVersion",
                    8,
                    command.ExpectedBatchRowVersion)
            ]);

        return _executor.QuerySingleAsync(call, MapBatchState, cancellationToken);
    }

    public Task<PurchaseOrderBatchDetails> GetBatchAsync(
        Guid batchId,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetBatchProcedure,
            [SqlParameterFactory.UniqueIdentifier("@batchId", batchId)]);

        return _executor.QuerySingleAsync(call, MapBatchDetails, cancellationToken);
    }

    public Task<PurchaseOrderBatchDetails> GetBatchBySourceHashAsync(
        string source,
        byte[] fileSha256,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetBatchBySourceHashProcedure,
            [
                SqlParameterFactory.NVarChar("@source", 50, source),
                SqlParameterFactory.Binary("@fileSha256", 32, fileSha256)
            ]);

        return _executor.QuerySingleAsync(call, MapBatchDetails, cancellationToken);
    }

    public Task<IReadOnlyList<PurchaseOrderBatchOutcome>> GetBatchOutcomesAsync(
        Guid batchId,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetBatchOutcomesProcedure,
            [SqlParameterFactory.UniqueIdentifier("@batchId", batchId)]);

        return _executor.QueryAsync(call, MapBatchOutcome, cancellationToken);
    }

    private static PurchaseOrderBatchState MapBatchState(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("BatchId")),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static PurchaseOrderBatchPromotionResult MapBatchPromotion(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("BatchId")),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetInt32(reader.GetOrdinal("PromotedCandidateCount")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static PurchaseOrderBatchDetails MapBatchDetails(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("BatchId")),
        reader.GetString(reader.GetOrdinal("Source")),
        reader.GetString(reader.GetOrdinal("OriginalFileName")),
        reader.GetString(reader.GetOrdinal("SourceFilePath")),
        reader.GetInt64(reader.GetOrdinal("FileContentLength")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("FileSha256")),
        reader.GetString(reader.GetOrdinal("Status")),
        GetNullableValue<int>(reader, "ExpectedRowCount"),
        reader.GetInt32(reader.GetOrdinal("ParsedRowCount")),
        reader.GetInt32(reader.GetOrdinal("CandidateCount")),
        reader.GetValueOrDefault<string>("FailureCode"),
        reader.GetValueOrDefault<string>("FailureDescription"),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("DiscoveredDateTime")),
        GetNullableValue<DateTimeOffset>(reader, "IngestionStartedDateTime"),
        GetNullableValue<DateTimeOffset>(reader, "CompletedDateTime"),
        reader.GetString(reader.GetOrdinal("CreatedBy")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("UpdatedDateTime")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static PurchaseOrderBatchOutcome MapBatchOutcome(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        reader.GetString(reader.GetOrdinal("Account")),
        reader.GetString(reader.GetOrdinal("Branch")),
        reader.GetValueOrDefault<string>("Reference"),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetValueOrDefault<string>("IconPurchaseOrderNumber"),
        reader.GetValueOrDefault<string>("StatusReason"),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("AcceptedDateTime")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("UpdatedDateTime")));

    private static T? GetNullableValue<T>(DbDataReader reader, string columnName)
        where T : struct
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetFieldValue<T>(ordinal);
    }
}
