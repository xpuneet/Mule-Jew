using STUK.PurchaseOrderService.Common.Data.Extensions;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class PurchaseOrderProcessingRepository : IPurchaseOrderProcessingRepository
{
    private const string ClaimCandidatesProcedure = "po.sp_claim_purchase_order_candidates";
    private const string RenewClaimProcedure = "po.sp_renew_purchase_order_claim";
    private const string ReleaseClaimProcedure = "po.sp_release_purchase_order_claim";
    private const string ExpireClaimsProcedure = "po.sp_expire_purchase_order_claims";
    private const string GetCandidateProcedure = "po.sp_get_purchase_order_candidate";
    private const string BeginAttemptProcedure =
        "po.sp_begin_purchase_order_submission_attempt";
    private const string FailCandidatePreDispatchProcedure =
        "po.sp_fail_purchase_order_candidate_pre_dispatch";
    private const string CompleteSubmissionProcedure =
        "po.sp_complete_purchase_order_submission";
    private const string FailSubmissionProcedure = "po.sp_fail_purchase_order_submission";

    private readonly IStoredProcedureExecutor _executor;

    public PurchaseOrderProcessingRepository(IStoredProcedureExecutor executor)
    {
        ArgumentNullException.ThrowIfNull(executor);
        _executor = executor;
    }

    public Task<IReadOnlyList<ClaimedPurchaseOrderCandidate>> ClaimCandidatesAsync(
        ClaimPurchaseOrderCandidatesCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            ClaimCandidatesProcedure,
            [
                SqlParameterFactory.NVarChar("@workerId", 256, command.WorkerId),
                SqlParameterFactory.SmallInt("@maxCandidates", command.MaxCandidates),
                SqlParameterFactory.Int("@leaseDurationSeconds", command.LeaseDurationSeconds)
            ]);

        return _executor.QueryAsync(call, MapClaimedCandidate, cancellationToken);
    }

    public Task<RenewedPurchaseOrderClaim> RenewClaimAsync(
        RenewPurchaseOrderClaimCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            RenewClaimProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.UniqueIdentifier("@leaseToken", command.LeaseToken),
                SqlParameterFactory.NVarChar("@workerId", 256, command.WorkerId),
                SqlParameterFactory.Int("@leaseDurationSeconds", command.LeaseDurationSeconds)
            ]);

        return _executor.QuerySingleAsync(call, MapRenewedClaim, cancellationToken);
    }

    public Task<ReleasedPurchaseOrderClaim> ReleaseClaimAsync(
        ReleasePurchaseOrderClaimCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            ReleaseClaimProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.UniqueIdentifier("@leaseToken", command.LeaseToken),
                SqlParameterFactory.NVarChar("@workerId", 256, command.WorkerId)
            ]);

        return _executor.QuerySingleAsync(call, MapReleasedClaim, cancellationToken);
    }

    public Task<ExpiredPurchaseOrderClaims> ExpireClaimsAsync(
        ExpirePurchaseOrderClaimsCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            ExpireClaimsProcedure,
            [
                SqlParameterFactory.NVarChar("@actor", 256, command.Actor)
            ]);

        return _executor.QuerySingleAsync(call, MapExpiredClaims, cancellationToken);
    }

    public Task<PurchaseOrderCandidateDetails> GetCandidateAsync(
        Guid candidateId,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            GetCandidateProcedure,
            [SqlParameterFactory.UniqueIdentifier("@candidateId", candidateId)]);

        return _executor.QuerySingleAsync(
            call,
            PurchaseOrderCandidateMapper.MapDetails,
            cancellationToken);
    }

    public Task<DispatchedPurchaseOrderSubmissionAttempt> BeginSubmissionAttemptAsync(
        BeginPurchaseOrderSubmissionAttemptCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            BeginAttemptProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@attemptId", command.AttemptId),
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.UniqueIdentifier("@leaseToken", command.LeaseToken),
                SqlParameterFactory.NVarChar("@workerId", 256, command.WorkerId),
                SqlParameterFactory.NVarChar(
                    "@requestPayloadJson",
                    -1,
                    command.RequestPayloadJson)
            ]);

        return _executor.QuerySingleAsync(call, MapDispatchedAttempt, cancellationToken);
    }

    public Task<FailedPurchaseOrderCandidatePreDispatch> FailCandidatePreDispatchAsync(
        FailPurchaseOrderCandidatePreDispatchCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            FailCandidatePreDispatchProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.UniqueIdentifier("@leaseToken", command.LeaseToken),
                SqlParameterFactory.NVarChar("@workerId", 256, command.WorkerId),
                SqlParameterFactory.VarChar("@candidateStatus", 50, command.CandidateStatus),
                SqlParameterFactory.VarChar("@failureCategory", 100, command.FailureCategory),
                SqlParameterFactory.NVarChar("@messageCode", 100, command.MessageCode),
                SqlParameterFactory.NVarChar(
                    "@messageDescription",
                    1000,
                    command.MessageDescription)
            ]);

        return _executor.QuerySingleAsync(
            call,
            MapFailedCandidatePreDispatch,
            cancellationToken);
    }

    public Task<CompletedPurchaseOrderSubmission> CompleteSubmissionAsync(
        CompletePurchaseOrderSubmissionCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            CompleteSubmissionProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@attemptId", command.AttemptId),
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.UniqueIdentifier("@leaseToken", command.LeaseToken),
                SqlParameterFactory.NVarChar("@workerId", 256, command.WorkerId),
                SqlParameterFactory.NVarChar(
                    "@iconPurchaseOrderNumber",
                    100,
                    command.IconPurchaseOrderNumber),
                SqlParameterFactory.VarChar("@iconCreatedStatus", 50, command.IconCreatedStatus),
                SqlParameterFactory.Bit("@iconSuspended", command.IconSuspended),
                SqlParameterFactory.NVarChar(
                    "@iconSuspendMessage",
                    1000,
                    command.IconSuspendMessage),
                SqlParameterFactory.NVarChar(
                    "@responsePayloadJson",
                    -1,
                    command.ResponsePayloadJson)
            ]);

        return _executor.QuerySingleAsync(call, MapCompletedSubmission, cancellationToken);
    }

    public Task<FailedPurchaseOrderSubmission> FailSubmissionAsync(
        FailPurchaseOrderSubmissionCommand command,
        CancellationToken cancellationToken = default)
    {
        var call = new StoredProcedureCall(
            FailSubmissionProcedure,
            [
                SqlParameterFactory.UniqueIdentifier("@attemptId", command.AttemptId),
                SqlParameterFactory.UniqueIdentifier("@candidateId", command.CandidateId),
                SqlParameterFactory.UniqueIdentifier("@leaseToken", command.LeaseToken),
                SqlParameterFactory.NVarChar("@workerId", 256, command.WorkerId),
                SqlParameterFactory.VarChar("@candidateStatus", 50, command.CandidateStatus),
                SqlParameterFactory.VarChar("@failureCategory", 100, command.FailureCategory),
                SqlParameterFactory.NVarChar("@messageCode", 100, command.MessageCode),
                SqlParameterFactory.NVarChar(
                    "@messageDescription",
                    1000,
                    command.MessageDescription),
                SqlParameterFactory.SmallInt("@httpStatusCode", command.HttpStatusCode),
                SqlParameterFactory.NVarChar(
                    "@responsePayloadJson",
                    -1,
                    command.ResponsePayloadJson),
                SqlParameterFactory.VarChar("@attemptStatus", 50, command.AttemptStatus)
            ]);

        return _executor.QuerySingleAsync(call, MapFailedSubmission, cancellationToken);
    }

    private static ClaimedPurchaseOrderCandidate MapClaimedCandidate(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        reader.GetString(reader.GetOrdinal("Source")),
        reader.GetString(reader.GetOrdinal("Account")),
        reader.GetString(reader.GetOrdinal("Branch")),
        reader.GetValueOrDefault<string>("Reference"),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetString(reader.GetOrdinal("PayloadJson")),
        reader.GetGuid(reader.GetOrdinal("LeaseToken")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("LeaseExpiresDateTime")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static RenewedPurchaseOrderClaim MapRenewedClaim(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("LeaseExpiresDateTime")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static ReleasedPurchaseOrderClaim MapReleasedClaim(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static ExpiredPurchaseOrderClaims MapExpiredClaims(DbDataReader reader) => new(
        reader.GetInt32(reader.GetOrdinal("ReleasedBeforeDispatchCount")),
        reader.GetInt32(reader.GetOrdinal("UnknownOutcomeCount")));

    private static DispatchedPurchaseOrderSubmissionAttempt MapDispatchedAttempt(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("AttemptId")),
            reader.GetInt32(reader.GetOrdinal("AttemptNumber")),
            reader.GetString(reader.GetOrdinal("Status")));

    private static FailedPurchaseOrderCandidatePreDispatch MapFailedCandidatePreDispatch(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("CandidateId")),
            reader.GetString(reader.GetOrdinal("Status")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("RowVersion")));

    private static CompletedPurchaseOrderSubmission MapCompletedSubmission(
        DbDataReader reader) => new(
            reader.GetGuid(reader.GetOrdinal("CandidateId")),
            reader.GetString(reader.GetOrdinal("Status")),
            reader.GetString(reader.GetOrdinal("IconPurchaseOrderNumber")),
            reader.GetGuid(reader.GetOrdinal("AttemptId")),
            reader.GetString(reader.GetOrdinal("AttemptStatus")),
            reader.GetFieldValue<byte[]>(reader.GetOrdinal("CandidateRowVersion")));

    private static FailedPurchaseOrderSubmission MapFailedSubmission(DbDataReader reader) => new(
        reader.GetGuid(reader.GetOrdinal("CandidateId")),
        reader.GetString(reader.GetOrdinal("Status")),
        reader.GetValueOrDefault<string>("IconPurchaseOrderNumber"),
        reader.GetGuid(reader.GetOrdinal("AttemptId")),
        reader.GetString(reader.GetOrdinal("AttemptStatus")),
        reader.GetFieldValue<byte[]>(reader.GetOrdinal("CandidateRowVersion")));

}
