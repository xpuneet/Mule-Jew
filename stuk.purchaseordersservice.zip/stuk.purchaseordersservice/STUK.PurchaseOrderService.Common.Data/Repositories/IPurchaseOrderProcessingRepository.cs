using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public interface IPurchaseOrderProcessingRepository
{
    Task<IReadOnlyList<ClaimedPurchaseOrderCandidate>> ClaimCandidatesAsync(
        ClaimPurchaseOrderCandidatesCommand command,
        CancellationToken cancellationToken = default);

    Task<RenewedPurchaseOrderClaim> RenewClaimAsync(
        RenewPurchaseOrderClaimCommand command,
        CancellationToken cancellationToken = default);

    Task<ReleasedPurchaseOrderClaim> ReleaseClaimAsync(
        ReleasePurchaseOrderClaimCommand command,
        CancellationToken cancellationToken = default);

    Task<ExpiredPurchaseOrderClaims> ExpireClaimsAsync(
        ExpirePurchaseOrderClaimsCommand command,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderCandidateDetails> GetCandidateAsync(
        Guid candidateId,
        CancellationToken cancellationToken = default);

    Task<DispatchedPurchaseOrderSubmissionAttempt> BeginSubmissionAttemptAsync(
        BeginPurchaseOrderSubmissionAttemptCommand command,
        CancellationToken cancellationToken = default);

    Task<FailedPurchaseOrderCandidatePreDispatch> FailCandidatePreDispatchAsync(
        FailPurchaseOrderCandidatePreDispatchCommand command,
        CancellationToken cancellationToken = default);

    Task<CompletedPurchaseOrderSubmission> CompleteSubmissionAsync(
        CompletePurchaseOrderSubmissionCommand command,
        CancellationToken cancellationToken = default);

    Task<FailedPurchaseOrderSubmission> FailSubmissionAsync(
        FailPurchaseOrderSubmissionCommand command,
        CancellationToken cancellationToken = default);
}
