namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public sealed record PurchaseOrderStatusSummaryQuery(
    string Source,
    DateTimeOffset AfterDateTimeUtc,
    DateTimeOffset UntilDateTimeUtc);

public sealed record PurchaseOrderStatusCount(
    string Status,
    long CandidateCount);

public sealed record PurchaseOrderCandidateDetails(
    Guid CandidateId,
    Guid? BatchId,
    string Source,
    string Kind,
    string Account,
    string Branch,
    string? Reference,
    string? IconPurchaseOrderNumber,
    string Status,
    DateTimeOffset StatusDateTime,
    string? StatusReason,
    int? ProcessBatchNo,
    string? PayloadMd5,
    string? MessageCode,
    string? MessageDescription,
    string? PreviousMessageCode,
    string? PreviousMessageDescription,
    string PayloadJson,
    DateTimeOffset AcceptedDateTime,
    DateTimeOffset CreatedDateTime,
    DateTimeOffset UpdatedDateTime,
    DateTimeOffset RefreshDateTime,
    int PendingRetriesCount,
    int ProcessingRetriesCount,
    Guid? LeaseToken,
    string? LeaseOwner,
    DateTimeOffset? LeaseAcquiredDateTime,
    DateTimeOffset? LeaseExpiresDateTime,
    byte[] RowVersion);
