﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models
{
    public sealed class EmailSendResponse
    {
        public bool IsSuccess { get; init; }

        public string Message { get; init; } = string.Empty;

        public Exception? Exception { get; init; }
    }
}
