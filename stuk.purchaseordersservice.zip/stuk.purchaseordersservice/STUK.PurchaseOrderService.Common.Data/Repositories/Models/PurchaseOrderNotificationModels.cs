namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public sealed record RegisterPurchaseOrderNotificationCommand(
    Guid NotificationId,
    Guid BatchId,
    string Channel,
    string TemplateKey,
    string RecipientGroupKey,
    string? AttachmentBlobName,
    DateTimeOffset CreatedDateTime);

public sealed record CompletePurchaseOrderNotificationCommand(
    Guid NotificationId,
    string Status,
    string? ProviderMessageId,
    string? FailureCode,
    string? FailureDescription,
    DateTimeOffset CompletedDateTime,
    byte[] ExpectedNotificationRowVersion);

public sealed record RegisteredPurchaseOrderNotification(
    Guid NotificationId,
    string Status,
    byte[] RowVersion);

public sealed record CompletedPurchaseOrderNotification(
    Guid NotificationId,
    string Status,
    DateTimeOffset? SentDateTime,
    byte[] RowVersion);
