namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public sealed record ClaimPurchaseOrderCandidatesCommand(
    string WorkerId,
    short MaxCandidates,
    int LeaseDurationSeconds);

public sealed record RenewPurchaseOrderClaimCommand(
    Guid CandidateId,
    Guid LeaseToken,
    string WorkerId,
    int LeaseDurationSeconds);

public sealed record ReleasePurchaseOrderClaimCommand(
    Guid CandidateId,
    Guid LeaseToken,
    string WorkerId);

public sealed record ExpirePurchaseOrderClaimsCommand(
    string Actor);

public sealed record BeginPurchaseOrderSubmissionAttemptCommand(
    Guid AttemptId,
    Guid CandidateId,
    Guid LeaseToken,
    string WorkerId,
    string RequestPayloadJson);

public sealed record FailPurchaseOrderCandidatePreDispatchCommand(
    Guid CandidateId,
    Guid LeaseToken,
    string WorkerId,
    string CandidateStatus,
    string FailureCategory,
    string? MessageCode,
    string? MessageDescription);

public sealed record CompletePurchaseOrderSubmissionCommand(
    Guid AttemptId,
    Guid CandidateId,
    Guid LeaseToken,
    string WorkerId,
    string IconPurchaseOrderNumber,
    string IconCreatedStatus,
    bool IconSuspended,
    string? IconSuspendMessage,
    string? ResponsePayloadJson);

public sealed record FailPurchaseOrderSubmissionCommand(
    Guid AttemptId,
    Guid CandidateId,
    Guid LeaseToken,
    string WorkerId,
    string CandidateStatus,
    string FailureCategory,
    string? MessageCode,
    string? MessageDescription,
    short? HttpStatusCode,
    string? ResponsePayloadJson,
    string AttemptStatus);

public sealed record ClaimedPurchaseOrderCandidate(
    Guid CandidateId,
    string Source,
    string Account,
    string Branch,
    string? Reference,
    string Status,
    string PayloadJson,
    Guid LeaseToken,
    DateTimeOffset LeaseExpiresDateTime,
    byte[] RowVersion);

public sealed record RenewedPurchaseOrderClaim(
    Guid CandidateId,
    DateTimeOffset LeaseExpiresDateTime,
    byte[] RowVersion);

public sealed record ReleasedPurchaseOrderClaim(
    Guid CandidateId,
    string Status,
    byte[] RowVersion);

public sealed record ExpiredPurchaseOrderClaims(
    int ReleasedBeforeDispatchCount,
    int UnknownOutcomeCount);

public sealed record DispatchedPurchaseOrderSubmissionAttempt(
    Guid AttemptId,
    int AttemptNumber,
    string Status);

public sealed record FailedPurchaseOrderCandidatePreDispatch(
    Guid CandidateId,
    string Status,
    byte[] RowVersion);

public sealed record CompletedPurchaseOrderSubmission(
    Guid CandidateId,
    string Status,
    string IconPurchaseOrderNumber,
    Guid AttemptId,
    string AttemptStatus,
    byte[] CandidateRowVersion);

public sealed record FailedPurchaseOrderSubmission(
    Guid CandidateId,
    string Status,
    string? IconPurchaseOrderNumber,
    Guid AttemptId,
    string AttemptStatus,
    byte[] CandidateRowVersion);
