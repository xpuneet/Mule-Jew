namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public sealed record RequestPurchaseOrderRetryCommand(
    Guid CandidateId,
    string Actor,
    string Reason,
    DateTimeOffset RequestedDateTime,
    byte[] ExpectedCandidateRowVersion);

public sealed record CancelPurchaseOrderCandidateCommand(
    Guid CandidateId,
    string Actor,
    string Reason,
    DateTimeOffset CancelledDateTime,
    byte[] ExpectedCandidateRowVersion);

public sealed record GetPurchaseOrderAuditQuery(
    Guid CandidateId,
    int PageNumber,
    int PageSize);

public sealed record PurchaseOrderSupportActionResult(
    Guid CandidateId,
    string Status,
    byte[] RowVersion);

public sealed record PurchaseOrderAuditEntry(
    string Action,
    string Method,
    string Actor,
    string? Reason,
    string? PreviousStatus,
    string? CurrentStatus,
    string? PreviousPayloadJson,
    string? CurrentPayloadJson,
    byte[]? BusinessPayloadHash,
    Guid? CorrelationId,
    DateTimeOffset ChangedDateTime);
