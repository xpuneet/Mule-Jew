namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public static class PurchaseOrderBatchStatuses
{
    public const string Ingesting = "INGESTING";

    public const string Completed = "COMPLETED";

    public const string Failed = "FAILED";
}
