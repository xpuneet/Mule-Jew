namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public sealed record EnqueuePurchaseOrderEmailNotificationCommand(
    Guid NotificationId,
    Guid? BatchId,
    string EventType,
    string BusinessCorrelationId,
    short EmailEnvelopeVersion,
    string EmailEnvelopeJson,
    string? TemplateKey,
    string? RecipientGroupKey,
    string? AttachmentBlobName,
    DateTimeOffset CreatedDateTime);

public sealed record ClaimPurchaseOrderEmailNotificationsCommand(
    DateTimeOffset AsOfDateTime,
    int LeaseDurationSeconds,
    int MaxNotifications,
    int MaxAttemptsPerMinute,
    int MaxAttemptsPerHour);

public sealed record DeferPurchaseOrderEmailNotificationCommand(
    Guid NotificationId,
    Guid LeaseId,
    DateTimeOffset NextAttemptDateTime,
    DateTimeOffset CompletedDateTime,
    byte[] ExpectedNotificationRowVersion);

public sealed record ReschedulePurchaseOrderEmailNotificationCommand(
    Guid NotificationId,
    Guid LeaseId,
    string Outcome,
    string FailureCategory,
    string? FailureCode,
    string? FailureDescription,
    short? HttpStatusCode,
    DateTimeOffset NextAttemptDateTime,
    DateTimeOffset CompletedDateTime,
    byte[] ExpectedNotificationRowVersion);

public sealed record CompletePurchaseOrderEmailNotificationCommand(
    Guid NotificationId,
    Guid LeaseId,
    string Status,
    string AttemptOutcome,
    bool IncrementFailureCount,
    string? ProviderMessageId,
    string? FailureCategory,
    string? FailureCode,
    string? FailureDescription,
    short? HttpStatusCode,
    DateTimeOffset CompletedDateTime,
    byte[] ExpectedNotificationRowVersion);

public sealed record GetPurchaseOrderEmailNotificationQueueSummaryQuery(
    DateTimeOffset AsOfDateTime,
    DateTimeOffset TerminalFailureSinceDateTime);

public sealed record EnqueuedPurchaseOrderEmailNotification(
    Guid NotificationId,
    string Status,
    DateTimeOffset NextAttemptDateTime,
    int AttemptCount,
    int FailureCount,
    int ThrottleCount,
    byte[] PayloadSha256,
    byte[] RowVersion);

public sealed record ClaimedPurchaseOrderEmailNotification(
    Guid NotificationId,
    string EventType,
    string BusinessCorrelationId,
    short EmailEnvelopeVersion,
    string EmailEnvelopeJson,
    byte[] PayloadSha256,
    int AttemptCount,
    int FailureCount,
    int ThrottleCount,
    Guid LeaseId,
    DateTimeOffset LeaseExpiresDateTime,
    byte[] RowVersion);

public sealed record UpdatedPurchaseOrderEmailNotification(
    Guid NotificationId,
    string Status,
    DateTimeOffset NextAttemptDateTime,
    int FailureCount,
    int ThrottleCount,
    byte[] RowVersion);

public sealed record CompletedPurchaseOrderEmailNotification(
    Guid NotificationId,
    string Status,
    DateTimeOffset? SentDateTime,
    DateTimeOffset CompletedDateTime,
    int FailureCount,
    int ThrottleCount,
    byte[] RowVersion);

public sealed record PurchaseOrderEmailNotificationQueueSummary(
    int ClaimablePendingCount,
    DateTimeOffset? OldestClaimablePendingDateTime,
    int DelayedPendingCount,
    int ActiveLeasedCount,
    int ExpiredLeasedCount,
    int UnsendableLegacyPendingCount,
    int TerminalFailureCount);
