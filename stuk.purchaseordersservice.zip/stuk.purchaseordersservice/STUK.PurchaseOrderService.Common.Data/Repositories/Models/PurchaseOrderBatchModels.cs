namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public sealed record RegisterPurchaseOrderBatchCommand(
    Guid BatchId,
    string OriginalFileName,
    string SourceFilePath,
    long FileContentLength,
    byte[] FileSha256,
    int? ExpectedRowCount,
    DateTimeOffset DiscoveredDateTime,
    string Actor);

public sealed record AddPurchaseOrderCandidateToBatchCommand(
    Guid BatchId,
    Guid CandidateId,
    string Account,
    string Branch,
    string? Reference,
    int SourceRowCount,
    DateTimeOffset AcceptedDateTime,
    string PayloadJson,
    string Actor);

public sealed record CompletePurchaseOrderBatchCommand(
    Guid BatchId,
    int ExpectedCandidateCount,
    int ParsedRowCount,
    DateTimeOffset CompletedDateTime,
    string Actor,
    byte[] ExpectedBatchRowVersion);

public sealed record FailPurchaseOrderBatchCommand(
    Guid BatchId,
    string FailureCode,
    string FailureDescription,
    DateTimeOffset FailedDateTime,
    string Actor,
    byte[] ExpectedBatchRowVersion);

public sealed record PurchaseOrderBatchState(
    Guid BatchId,
    string Status,
    byte[] RowVersion);

public sealed record PurchaseOrderBatchPromotionResult(
    Guid BatchId,
    string Status,
    int PromotedCandidateCount,
    byte[] RowVersion);

public sealed record PurchaseOrderBatchDetails(
    Guid BatchId,
    string Source,
    string OriginalFileName,
    string SourceFilePath,
    long FileContentLength,
    byte[] FileSha256,
    string Status,
    int? ExpectedRowCount,
    int ParsedRowCount,
    int CandidateCount,
    string? FailureCode,
    string? FailureDescription,
    DateTimeOffset DiscoveredDateTime,
    DateTimeOffset? IngestionStartedDateTime,
    DateTimeOffset? CompletedDateTime,
    string CreatedBy,
    DateTimeOffset UpdatedDateTime,
    byte[] RowVersion);

public sealed record PurchaseOrderBatchOutcome(
    Guid CandidateId,
    string Account,
    string Branch,
    string? Reference,
    string Status,
    string? IconPurchaseOrderNumber,
    string? StatusReason,
    DateTimeOffset AcceptedDateTime,
    DateTimeOffset UpdatedDateTime);

public sealed record PurchaseOrderBatchStatusSummaryQuery(
    string Source,
    DateTimeOffset AfterDateTimeUtc,
    DateTimeOffset UntilDateTimeUtc);

public sealed record PurchaseOrderBatchStatusCount(
    string Status,
    long BatchCount);

public sealed record PurchaseOrderBatchSearchQuery(
    string Source,
    string? OriginalFileName,
    string? Status,
    DateTimeOffset DiscoveredAfterDateTimeUtc,
    DateTimeOffset DiscoveredUntilDateTimeUtc,
    int PageNumber,
    int PageSize);

public sealed record PurchaseOrderBatchSummary(
    Guid BatchId,
    string Source,
    string OriginalFileName,
    string SourceFilePath,
    long FileContentLength,
    string Status,
    int? ExpectedRowCount,
    int ParsedRowCount,
    int CandidateCount,
    string? FailureCode,
    DateTimeOffset DiscoveredDateTime,
    DateTimeOffset? CompletedDateTime,
    DateTimeOffset UpdatedDateTime);

public sealed record PurchaseOrderBatchCandidateSearchQuery(
    Guid BatchId,
    string? Status,
    int PageNumber,
    int PageSize);
