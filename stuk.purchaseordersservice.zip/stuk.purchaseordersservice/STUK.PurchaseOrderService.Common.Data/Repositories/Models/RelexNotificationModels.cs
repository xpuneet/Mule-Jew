namespace STUK.PurchaseOrderService.Common.Data.Repositories.Models;

public sealed record PrepareRelexNotificationEventsCommand(
    DateTimeOffset AsOfDateTime,
    int MaxEvents,
    int LeaseDurationSeconds,
    bool ResultsEnabled,
    string CompositionSettingsJson,
    DateTimeOffset? ResultsNotBeforeDateTime,
    DateTimeOffset? MissingCutoffDateTime,
    DateTimeOffset? MissingFreshSinceDateTime,
    string? MissingEventKey);

public sealed record RelexNotificationEvent(
    Guid NotificationId,
    Guid? BatchId,
    string EventType,
    string BusinessCorrelationId,
    string? OriginalFileName,
    DateTimeOffset CreatedDateTime,
    string CompositionSettingsJson,
    string OutcomeRowsJson,
    string? EmailEnvelopeJson,
    Guid LeaseId,
    int FailureCount);

public sealed record SaveRelexNotificationEnvelopeCommand(
    Guid NotificationId,
    Guid LeaseId,
    string EmailEnvelopeJson);

public sealed record CompleteRelexNotificationEventCommand(
    Guid NotificationId,
    Guid LeaseId,
    bool Enqueued,
    bool PermanentFailure,
    DateTimeOffset CompletedDateTime,
    DateTimeOffset? NextAttemptDateTime,
    string? FailureCode,
    int MaxFailureCount);
