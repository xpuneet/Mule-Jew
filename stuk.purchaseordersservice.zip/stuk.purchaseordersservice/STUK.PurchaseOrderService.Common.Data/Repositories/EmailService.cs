﻿using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using System.Net;
using System.Net.Mail;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class EmailService : IEmailService
{
    private readonly EmailSmtpSettings _smtp;
    private readonly EmailSenderSettings _settings;

    public EmailService(IOptions<EmailSenderSettings> options)
    {
        _settings = options.Value;
        _smtp = _settings.Smtp;
    }

    public async Task<EmailSendResponse> SendAsync(
        string subject,
        IEnumerable<string> recipients,
        string htmlContent,
        IEnumerable<string>? cc = null,
        IEnumerable<string>? bcc = null)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(_smtp.Username))
            {
                return new EmailSendResponse
                {
                    IsSuccess = false,
                    Message = "SMTP username is not configured."
                };
            }

            if (string.IsNullOrWhiteSpace(_smtp.Password))
            {
                return new EmailSendResponse
                {
                    IsSuccess = false,
                    Message = "SMTP password is not configured."
                };
            }
            if (!_settings.SendingEnabled)
            {
                return new EmailSendResponse
                {
                    IsSuccess = false,
                    Message = "Email sending is disabled."
                };
            }

            if (string.IsNullOrWhiteSpace(subject))
            {
                return new EmailSendResponse
                {
                    IsSuccess = false,
                    Message = "Subject is required."
                };
            }

            if (string.IsNullOrWhiteSpace(htmlContent))
            {
                return new EmailSendResponse
                {
                    IsSuccess = false,
                    Message = "HTML content is required."
                };
            }

            var recipientList = recipients?.ToList() ?? [];

            if (recipientList.Count == 0)
            {
                return new EmailSendResponse
                {
                    IsSuccess = false,
                    Message = "At least one recipient is required."
                };
            }

            if (string.IsNullOrWhiteSpace(_settings.DefaultSenderAddress))
            {
                return new EmailSendResponse
                {
                    IsSuccess = false,
                    Message = "Default sender address is not configured."
                };
            }

            using var message = new MailMessage
            {
                From = new MailAddress(_settings.DefaultSenderAddress),
                Subject = subject,
                Body = htmlContent,
                IsBodyHtml = true
            };

            foreach (var recipient in recipientList)
            {
                message.To.Add(new MailAddress(recipient));
            }

            if (cc != null)
            {
                foreach (var address in cc)
                {
                    message.CC.Add(new MailAddress(address));
                }
            }

            if (bcc != null)
            {
                foreach (var address in bcc)
                {
                    message.Bcc.Add(new MailAddress(address));
                }
            }

            using var smtp = new SmtpClient(_smtp.Host, _smtp.Port)
            {
                EnableSsl = _smtp.UseStartTls,
                UseDefaultCredentials = false,
                Timeout = _settings.ProviderOperationTimeoutSeconds * 1000
            };

            if (!string.IsNullOrWhiteSpace(_smtp.Username) &&
                !string.IsNullOrWhiteSpace(_smtp.Password))
            {
                smtp.Credentials = new NetworkCredential(
                    _smtp.Username,
                    _smtp.Password);
            }

            await smtp.SendMailAsync(message);

            return new EmailSendResponse
            {
                IsSuccess = true,
                Message = "Email sent successfully."
            };
        }
        catch (SmtpException ex)
        {
            return new EmailSendResponse
            {
                IsSuccess = false,
                Message = $"SMTP Error: {ex.Message}",
                Exception = ex
            };
        }
        catch (Exception ex)
        {
            return new EmailSendResponse
            {
                IsSuccess = false,
                Message = $"Unexpected Error: {ex.Message}",
                Exception = ex
            };
        }
    }    

}