using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public interface IPurchaseOrderNotificationRepository
{
    Task<RegisteredPurchaseOrderNotification> RegisterNotificationAsync(
        RegisterPurchaseOrderNotificationCommand command,
        CancellationToken cancellationToken = default);

    Task<CompletedPurchaseOrderNotification> CompleteNotificationAsync(
        CompletePurchaseOrderNotificationCommand command,
        CancellationToken cancellationToken = default);

    Task<EnqueuedPurchaseOrderEmailNotification> EnqueueEmailNotificationAsync(
        EnqueuePurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<ClaimedPurchaseOrderEmailNotification>> ClaimDueEmailNotificationsAsync(
        ClaimPurchaseOrderEmailNotificationsCommand command,
        CancellationToken cancellationToken = default);

    Task<UpdatedPurchaseOrderEmailNotification> DeferEmailNotificationAsync(
        DeferPurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default);

    Task<UpdatedPurchaseOrderEmailNotification> RescheduleEmailNotificationAsync(
        ReschedulePurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default);

    Task<CompletedPurchaseOrderEmailNotification> CompleteEmailNotificationAsync(
        CompletePurchaseOrderEmailNotificationCommand command,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderEmailNotificationQueueSummary> GetEmailNotificationQueueSummaryAsync(
        GetPurchaseOrderEmailNotificationQueueSummaryQuery query,
        CancellationToken cancellationToken = default);
}
