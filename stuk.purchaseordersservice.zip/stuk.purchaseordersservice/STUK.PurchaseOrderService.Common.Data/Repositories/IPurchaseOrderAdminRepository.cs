using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public interface IPurchaseOrderAdminRepository
{
    Task<IReadOnlyList<PurchaseOrderStatusCount>> GetStatusSummaryAsync(
        PurchaseOrderStatusSummaryQuery query,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderCandidateDetails> GetCandidateAsync(
        Guid candidateId,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PurchaseOrderBatchStatusCount>> GetBatchStatusSummaryAsync(
        PurchaseOrderBatchStatusSummaryQuery query,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PurchaseOrderBatchSummary>> SearchBatchesAsync(
        PurchaseOrderBatchSearchQuery query,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderBatchDetails> GetBatchAsync(
        Guid batchId,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PurchaseOrderStatusCount>> GetBatchCandidateStatusSummaryAsync(
        Guid batchId,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PurchaseOrderBatchOutcome>> SearchBatchCandidatesAsync(
        PurchaseOrderBatchCandidateSearchQuery query,
        CancellationToken cancellationToken = default);
}
