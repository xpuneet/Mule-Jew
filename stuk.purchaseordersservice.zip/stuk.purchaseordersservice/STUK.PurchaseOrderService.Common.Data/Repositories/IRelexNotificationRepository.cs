using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public interface IRelexNotificationRepository
{
    Task<IReadOnlyList<RelexNotificationEvent>> PrepareAndClaimAsync(
        PrepareRelexNotificationEventsCommand command,
        CancellationToken cancellationToken = default);

    Task<string> SaveEnvelopeAsync(
        SaveRelexNotificationEnvelopeCommand command,
        CancellationToken cancellationToken = default);

    Task CompleteAsync(
        CompleteRelexNotificationEventCommand command,
        CancellationToken cancellationToken = default);
}
