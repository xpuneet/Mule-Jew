using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public interface IPurchaseOrderSupportRepository
{
    Task<PurchaseOrderSupportActionResult> RequestRetryAsync(
        RequestPurchaseOrderRetryCommand command,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderSupportActionResult> CancelCandidateAsync(
        CancelPurchaseOrderCandidateCommand command,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PurchaseOrderAuditEntry>> GetAuditAsync(
        GetPurchaseOrderAuditQuery query,
        CancellationToken cancellationToken = default);
}
