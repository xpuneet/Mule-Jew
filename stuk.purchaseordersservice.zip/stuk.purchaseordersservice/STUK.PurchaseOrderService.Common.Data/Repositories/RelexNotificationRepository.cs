using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.Common.Data.Extensions;

namespace STUK.PurchaseOrderService.Common.Data.Repositories;

public sealed class RelexNotificationRepository(IStoredProcedureExecutor executor)
    : IRelexNotificationRepository
{
    public Task<IReadOnlyList<RelexNotificationEvent>> PrepareAndClaimAsync(
        PrepareRelexNotificationEventsCommand command,
        CancellationToken cancellationToken = default) => executor.QueryAsync(
        new StoredProcedureCall("po.sp_prepare_and_claim_relex_notification_events",
        [
            SqlParameterFactory.DateTimeOffset3("@asOfDateTime", command.AsOfDateTime),
            SqlParameterFactory.Int("@maxEvents", command.MaxEvents),
            SqlParameterFactory.Int("@leaseDurationSeconds", command.LeaseDurationSeconds),
            SqlParameterFactory.Bit("@resultsEnabled", command.ResultsEnabled),
            SqlParameterFactory.NVarChar("@compositionSettingsJson", -1, command.CompositionSettingsJson),
            SqlParameterFactory.DateTimeOffset3("@resultsNotBeforeDateTime", command.ResultsNotBeforeDateTime),
            SqlParameterFactory.DateTimeOffset3("@missingCutoffDateTime", command.MissingCutoffDateTime),
            SqlParameterFactory.DateTimeOffset3("@missingFreshSinceDateTime", command.MissingFreshSinceDateTime),
            SqlParameterFactory.NVarChar("@missingEventKey", 100, command.MissingEventKey)
        ]),
        reader => new RelexNotificationEvent(
            reader.GetGuid(reader.GetOrdinal("NotificationId")),
            reader.IsDBNull(reader.GetOrdinal("BatchId")) ? null : reader.GetGuid(reader.GetOrdinal("BatchId")),
            reader.GetString(reader.GetOrdinal("EventType")),
            reader.GetString(reader.GetOrdinal("BusinessCorrelationId")),
            reader.GetValueOrDefault<string>("OriginalFileName"),
            reader.GetFieldValue<DateTimeOffset>(reader.GetOrdinal("CreatedDateTime")),
            reader.GetString(reader.GetOrdinal("CompositionSettingsJson")),
            reader.GetString(reader.GetOrdinal("OutcomeRowsJson")),
            reader.GetValueOrDefault<string>("EmailEnvelopeJson"),
            reader.GetGuid(reader.GetOrdinal("LeaseId")),
            reader.GetInt32(reader.GetOrdinal("FailureCount"))),
        cancellationToken);

    public Task<string> SaveEnvelopeAsync(
        SaveRelexNotificationEnvelopeCommand command,
        CancellationToken cancellationToken = default) => executor.QuerySingleAsync(
        new StoredProcedureCall("po.sp_save_relex_notification_envelope",
        [
            SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
            SqlParameterFactory.UniqueIdentifier("@leaseId", command.LeaseId),
            SqlParameterFactory.NVarChar("@emailEnvelopeJson", -1, command.EmailEnvelopeJson)
        ]),
        reader => reader.GetString(reader.GetOrdinal("EmailEnvelopeJson")),
        cancellationToken);

    public async Task CompleteAsync(
        CompleteRelexNotificationEventCommand command,
        CancellationToken cancellationToken = default) => await executor.ExecuteNonQueryAsync(
        new StoredProcedureCall("po.sp_complete_relex_notification_event",
        [
            SqlParameterFactory.UniqueIdentifier("@notificationId", command.NotificationId),
            SqlParameterFactory.UniqueIdentifier("@leaseId", command.LeaseId),
            SqlParameterFactory.Bit("@enqueued", command.Enqueued),
            SqlParameterFactory.Bit("@permanentFailure", command.PermanentFailure),
            SqlParameterFactory.DateTimeOffset3("@completedDateTime", command.CompletedDateTime),
            SqlParameterFactory.DateTimeOffset3("@nextAttemptDateTime", command.NextAttemptDateTime),
            SqlParameterFactory.VarChar("@failureCode", 100, command.FailureCode),
            SqlParameterFactory.Int("@maxFailureCount", command.MaxFailureCount)
        ]),
        cancellationToken);
}
