using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Sql;

public interface IStoredProcedureExecutor
{
    Task<int> ExecuteNonQueryAsync(
        StoredProcedureCall call,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<T>> QueryAsync<T>(
        StoredProcedureCall call,
        Func<DbDataReader, T> map,
        CancellationToken cancellationToken);

    Task<T> QuerySingleAsync<T>(
        StoredProcedureCall call,
        Func<DbDataReader, T> map,
        CancellationToken cancellationToken);
}
