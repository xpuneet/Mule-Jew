using Microsoft.Data.SqlClient;

namespace STUK.PurchaseOrderService.Common.Data.Sql;

public sealed record StoredProcedureCall(
    string ProcedureName,
    IReadOnlyList<SqlParameter> Parameters);
