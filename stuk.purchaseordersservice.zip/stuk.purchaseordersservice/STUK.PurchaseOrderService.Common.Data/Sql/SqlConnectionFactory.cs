using Microsoft.Data.SqlClient;
using STUK.PurchaseOrderService.Common.Data.Repositories.DbContexts;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Sql;

public sealed class SqlConnectionFactory : ISqlConnectionFactory
{
    private readonly string _connectionString;

    public SqlConnectionFactory(PurchaseOrdersDbContext dbContext)
    {
        ArgumentNullException.ThrowIfNull(dbContext);
        _connectionString = dbContext.ConnectionString;
    }

    public DbConnection Create() => new SqlConnection(_connectionString);
}
