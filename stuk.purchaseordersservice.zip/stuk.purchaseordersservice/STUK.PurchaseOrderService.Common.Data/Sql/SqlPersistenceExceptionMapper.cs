namespace STUK.PurchaseOrderService.Common.Data.Sql;

public static class SqlPersistenceExceptionMapper
{
    public static PurchaseOrderPersistenceException Map(int sqlErrorNumber)
    {
        var error = sqlErrorNumber switch
        {
            51001 => PurchaseOrderPersistenceError.EntityNotFound,
            51002 => PurchaseOrderPersistenceError.ConcurrencyConflict,
            51003 => PurchaseOrderPersistenceError.LeaseConflict,
            51004 => PurchaseOrderPersistenceError.InvalidLifecycleTransition,
            51005 => PurchaseOrderPersistenceError.DuplicateSourceFile,
            51006 => PurchaseOrderPersistenceError.BatchValidationMismatch,
            _ => PurchaseOrderPersistenceError.Unclassified
        };

        return new PurchaseOrderPersistenceException(
            error,
            sqlErrorNumber,
            GetSanitizedMessage(error));
    }

    private static string GetSanitizedMessage(PurchaseOrderPersistenceError error) => error switch
    {
        PurchaseOrderPersistenceError.EntityNotFound =>
            "The requested persistence entity was not found.",
        PurchaseOrderPersistenceError.ConcurrencyConflict =>
            "The persistence operation encountered a concurrency conflict.",
        PurchaseOrderPersistenceError.LeaseConflict =>
            "The persistence operation encountered a lease conflict.",
        PurchaseOrderPersistenceError.InvalidLifecycleTransition =>
            "The persistence operation requested an invalid lifecycle transition.",
        PurchaseOrderPersistenceError.DuplicateSourceFile =>
            "The source file has already been registered.",
        PurchaseOrderPersistenceError.BatchValidationMismatch =>
            "The persistence operation encountered a batch validation mismatch.",
        _ => "The persistence operation failed."
    };
}
