using Microsoft.Data.SqlClient;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Sql;

public sealed class StoredProcedureExecutor : IStoredProcedureExecutor
{
    private const string SingleRowInvariantMessage =
        "The stored procedure result must contain exactly one row.";

    private readonly ISqlConnectionFactory _connectionFactory;

    public StoredProcedureExecutor(ISqlConnectionFactory connectionFactory)
    {
        ArgumentNullException.ThrowIfNull(connectionFactory);
        _connectionFactory = connectionFactory;
    }

    public async Task<int> ExecuteNonQueryAsync(
        StoredProcedureCall call,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(call);

        try
        {
            await using var connection = _connectionFactory.Create();
            await using var command = CreateCommand(connection, call);

            await connection.OpenAsync(cancellationToken);
            return await command.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (SqlException exception)
        {
            throw SqlPersistenceExceptionMapper.Map(exception.Number);
        }
    }

    public async Task<IReadOnlyList<T>> QueryAsync<T>(
        StoredProcedureCall call,
        Func<DbDataReader, T> map,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(call);
        ArgumentNullException.ThrowIfNull(map);

        try
        {
            await using var connection = _connectionFactory.Create();
            await using var command = CreateCommand(connection, call);

            await connection.OpenAsync(cancellationToken);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var results = new List<T>();

            while (await reader.ReadAsync(cancellationToken))
            {
                results.Add(map(reader));
            }

            return results;
        }
        catch (SqlException exception)
        {
            throw SqlPersistenceExceptionMapper.Map(exception.Number);
        }
    }

    public async Task<T> QuerySingleAsync<T>(
        StoredProcedureCall call,
        Func<DbDataReader, T> map,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(call);
        ArgumentNullException.ThrowIfNull(map);

        try
        {
            await using var connection = _connectionFactory.Create();
            await using var command = CreateCommand(connection, call);

            await connection.OpenAsync(cancellationToken);
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
            {
                throw new InvalidOperationException(SingleRowInvariantMessage);
            }

            var result = map(reader);
            if (await reader.ReadAsync(cancellationToken))
            {
                throw new InvalidOperationException(SingleRowInvariantMessage);
            }

            return result;
        }
        catch (SqlException exception)
        {
            throw SqlPersistenceExceptionMapper.Map(exception.Number);
        }
    }

    private static DbCommand CreateCommand(
        DbConnection connection,
        StoredProcedureCall call)
    {
        var command = connection.CreateCommand();
        command.CommandText = call.ProcedureName;
        command.CommandType = CommandType.StoredProcedure;

        foreach (var parameter in call.Parameters)
        {
            command.Parameters.Add(parameter);
        }

        return command;
    }
}
