using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Sql;

public interface ISqlConnectionFactory
{
    DbConnection Create();
}
