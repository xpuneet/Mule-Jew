using Microsoft.Data.SqlClient;
using System.Data;

namespace STUK.PurchaseOrderService.Common.Data.Sql;

public static class SqlParameterFactory
{
    public static SqlParameter NVarChar(string name, int size, string? value)
    {
        ValidateString(size, value);
        return new SqlParameter(name, SqlDbType.NVarChar, size)
        {
            Value = ToDatabaseValue(value)
        };
    }

    public static SqlParameter VarChar(string name, int size, string? value)
    {
        ValidateString(size, value);
        return new SqlParameter(name, SqlDbType.VarChar, size)
        {
            Value = ToDatabaseValue(value)
        };
    }

    public static SqlParameter DateTimeOffset3(string name, DateTimeOffset value) =>
        new(name, SqlDbType.DateTimeOffset)
        {
            Scale = 3,
            Value = value
        };

    public static SqlParameter DateTimeOffset3(string name, DateTimeOffset? value) =>
        new(name, SqlDbType.DateTimeOffset)
        {
            Scale = 3,
            Value = ToDatabaseValue(value)
        };

    public static SqlParameter Binary(string name, int size, byte[]? value)
    {
        if (size <= 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(size),
                "A binary SQL parameter size must be positive.");
        }

        if (value is not null && value.Length != size)
        {
            throw new ArgumentException(
                "A binary SQL parameter value must match its declared size.",
                nameof(value));
        }

        return new SqlParameter(name, SqlDbType.Binary, size)
        {
            Value = ToDatabaseValue(value)
        };
    }

    public static SqlParameter Bit(string name, bool? value) =>
        new(name, SqlDbType.Bit)
        {
            Value = ToDatabaseValue(value)
        };

    public static SqlParameter Int(string name, int? value) =>
        new(name, SqlDbType.Int)
        {
            Value = ToDatabaseValue(value)
        };

    public static SqlParameter SmallInt(string name, short? value) =>
        new(name, SqlDbType.SmallInt)
        {
            Value = ToDatabaseValue(value)
        };

    public static SqlParameter BigInt(string name, long? value) =>
        new(name, SqlDbType.BigInt)
        {
            Value = ToDatabaseValue(value)
        };

    public static SqlParameter UniqueIdentifier(string name, Guid? value) =>
        new(name, SqlDbType.UniqueIdentifier)
        {
            Value = ToDatabaseValue(value)
        };

    private static void ValidateString(int size, string? value)
    {
        if (size == 0 || size < -1)
        {
            throw new ArgumentOutOfRangeException(
                nameof(size),
                "A string SQL parameter size must be -1 or positive.");
        }

        if (size > 0 && value is not null && value.Length > size)
        {
            throw new ArgumentException(
                "A string SQL parameter value exceeds its declared size.",
                nameof(value));
        }
    }

    private static object ToDatabaseValue(object? value) => value ?? DBNull.Value;
}
