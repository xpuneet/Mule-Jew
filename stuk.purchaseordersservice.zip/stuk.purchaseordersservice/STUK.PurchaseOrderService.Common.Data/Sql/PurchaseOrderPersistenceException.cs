namespace STUK.PurchaseOrderService.Common.Data.Sql;

public enum PurchaseOrderPersistenceError
{
    Unclassified = 0,
    EntityNotFound = 51001,
    ConcurrencyConflict = 51002,
    LeaseConflict = 51003,
    InvalidLifecycleTransition = 51004,
    DuplicateSourceFile = 51005,
    BatchValidationMismatch = 51006
}

public sealed class PurchaseOrderPersistenceException : Exception
{
    internal PurchaseOrderPersistenceException(
        PurchaseOrderPersistenceError error,
        int sqlErrorNumber,
        string message)
        : base(message)
    {
        Error = error;
        SqlErrorNumber = sqlErrorNumber;
    }

    public PurchaseOrderPersistenceError Error { get; }

    public int SqlErrorNumber { get; }
}
