using System.Data.Common;

namespace STUK.PurchaseOrderService.Common.Data.Extensions;

public static class DbDataReaderExtensions
{
    public static T? GetValueOrDefault<T>(this DbDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? default : reader.GetFieldValue<T>(ordinal);
    }
}
