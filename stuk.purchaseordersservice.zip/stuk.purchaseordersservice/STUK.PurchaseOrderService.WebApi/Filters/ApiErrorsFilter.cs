using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Diagnostics;

namespace STUK.PurchaseOrderService.WebApi.Filters;

public sealed class ApiErrorsFilter : IExceptionFilter
{
    private readonly ILogger<ApiErrorsFilter> _logger;

    public ApiErrorsFilter(ILogger<ApiErrorsFilter> logger)
    {
        _logger = logger;
    }

    public void OnException(ExceptionContext context)
    {
        var traceId = Activity.Current?.Id ?? context.HttpContext.TraceIdentifier;
        _logger.LogError(
            "Unhandled PurchaseOrderService API failure. TraceId: {TraceId}; ExceptionType: {ExceptionType}.",
            traceId,
            context.Exception.GetType().FullName);

        var problemDetails = new ProblemDetails
        {
            Title = "Service Temporarily Unavailable",
            Detail = "PurchaseOrderService could not complete the request.",
            Status = StatusCodes.Status503ServiceUnavailable,
            Instance = context.HttpContext.Request.Path
        };
        problemDetails.Extensions["traceId"] = traceId;

        context.Result = new ObjectResult(problemDetails)
        {
            StatusCode = StatusCodes.Status503ServiceUnavailable
        };

        context.ExceptionHandled = true;
    }
}
