using Microsoft.AspNetCore.Mvc.Filters;

namespace STUK.PurchaseOrderService.WebApi.Filters;

public sealed class TelemetryFilter : IActionFilter
{
    private readonly ILogger<TelemetryFilter> _logger;

    public TelemetryFilter(ILogger<TelemetryFilter> logger)
    {
        _logger = logger;
    }

    public void OnActionExecuting(ActionExecutingContext context)
    {
        _logger.LogDebug("Handling {Method} {Path}.", context.HttpContext.Request.Method, context.HttpContext.Request.Path);
    }

    public void OnActionExecuted(ActionExecutedContext context)
    {
        _logger.LogDebug("Handled {Method} {Path} with status {StatusCode}.",
            context.HttpContext.Request.Method,
            context.HttpContext.Request.Path,
            context.HttpContext.Response.StatusCode);
    }
}
