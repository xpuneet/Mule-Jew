using Azure.Identity;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using STUK.ConfigurationProviders;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data;
using STUK.PurchaseOrderService.WebApi.Config;
using STUK.PurchaseOrderService.WebApi.Domain.Config;
using STUK.PurchaseOrderService.WebApi.Domain.Services.V1;
using STUK.PurchaseOrderService.WebApi.Filters;
using STUK.PurchaseOrderService.WebApi.Middleware;
using STUK.PurchaseOrderService.WebApi.Swagger;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

var azureKeyVaultUri = builder.Configuration[ConfigConstants.AzureKeyVaultUriSettingKey];
if (!string.IsNullOrWhiteSpace(azureKeyVaultUri))
{
    builder.Configuration.AddAzureKeyVault(new Uri(azureKeyVaultUri), new DefaultAzureCredential());
}

var purchaseOrdersConnectionString =
    PurchaseOrderDatabaseConfiguration.RequireConnectionString(builder.Configuration);
builder.Configuration.AddSqlServerConfiguration(
    ConfigConstants.PurchaseOrdersDbConnectionStringName,
    "po.sp_get_application_settings",
    ConfigConstants.DatabaseConfigurationRefreshInterval,
    [
        ConfigConstants.DatabaseAppSettingCommonContext,
        ConfigConstants.DatabaseAppSettingWebApiContext
    ]);

builder.Services.AddControllers(options =>
{
    options.Filters.Add<ApiErrorsFilter>();
    options.Filters.Add<TelemetryFilter>();
}).AddJsonOptions(options =>
{
    options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

builder.Services.AddEndpointsApiExplorer();
if (!string.IsNullOrWhiteSpace(
        builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"]))
{
    builder.Services.AddApplicationInsightsTelemetry();
}

RegisterSecurity(builder);
RegisterServices(builder, purchaseOrdersConnectionString);

builder.Services.AddPurchaseOrderSwagger();

var app = builder.Build();

if (app.Environment.IsDevelopment() || Convert.ToBoolean(builder.Configuration["AllowSwagger"]))
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<CanonicalPurchaseOrderRequestGuardMiddleware>();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health");

app.Run();

static void RegisterSecurity(WebApplicationBuilder builder)
{
    var apiSecuritySettings = builder.Configuration.GetSection(nameof(ApiSecuritySettings)).Get<ApiSecuritySettings>()
        ?? new ApiSecuritySettings();

    if (apiSecuritySettings.SchemeToScopeMappings.Count == 0 || string.IsNullOrWhiteSpace(apiSecuritySettings.OpenIdAuthority))
    {
        if (!builder.Environment.IsDevelopment())
        {
            throw new InvalidOperationException("ApiSecuritySettings must define OpenIdAuthority and at least one scheme mapping outside Development.");
        }

        builder.Services.AddAuthorization(options =>
        {
            options.AddPolicy(ApiSecuritySettings.AuthenticationSchemes.User, policy => policy.RequireAssertion(_ => true));
        });

        return;
    }

    var authenticationBuilder = builder.Services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
    });

    foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
    {
        authenticationBuilder.AddJwtBearer(scheme, options =>
        {
            options.Authority = apiSecuritySettings.OpenIdAuthority;
            options.RequireHttpsMetadata = false;
            options.Audience = apiSecuritySettings.SchemeToScopeMappings[scheme];
        });
    }

    builder.Services.AddAuthorization(options =>
    {
        foreach (var scheme in apiSecuritySettings.SchemeToScopeMappings.Keys)
        {
            options.AddPolicy(scheme, policy =>
            {
                policy.RequireAuthenticatedUser();
                policy.AuthenticationSchemes = [scheme];
            });
        }
    });
}

static void RegisterServices(
    WebApplicationBuilder builder,
    string purchaseOrdersConnectionString)
{
    builder.Services.Configure<CommonSettings>(builder.Configuration.GetSection(nameof(CommonSettings)));
    builder.Services.AddSingleton<IValidateOptions<WebApiSettings>, WebApiSettingsValidator>();
    builder.Services
        .AddOptions<WebApiSettings>()
        .Bind(builder.Configuration.GetSection(nameof(WebApiSettings)))
        .ValidateOnStart();
    builder.Services.AddSingleton(TimeProvider.System);
    builder.Services.AddScoped<AppSettings>();
    builder.Services.AddPurchaseOrderPersistence(purchaseOrdersConnectionString);
    builder.Services.AddScoped<IPurchaseOrdersService, PurchaseOrdersService>();

    builder.Services
        .AddHealthChecks()
        .AddSqlServer(
            purchaseOrdersConnectionString,
            name: ConfigConstants.PurchaseOrdersDbConnectionStringName);
}
