using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.WebApi.Config;

public static class PurchaseOrderDatabaseConfiguration
{
    private const string MissingConnectionMessage =
        "The Purchase Orders database connection is not configured.";

    public static string RequireConnectionString(IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);
        var connectionString = configuration.GetConnectionString(
            ConfigConstants.PurchaseOrdersDbConnectionStringName);

        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(MissingConnectionMessage);
        }

        return connectionString;
    }
}
