using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.WebApi.Config;

public sealed class WebApiSettingsValidator : IValidateOptions<WebApiSettings>
{
    public ValidateOptionsResult Validate(string? name, WebApiSettings options)
    {
        var failures = new List<string>();

        if (options.PurchaseOrdersMaxPageSize <= 0)
        {
            failures.Add("WebApiSettings:PurchaseOrdersMaxPageSize must be greater than zero.");
        }
        else if (options.PurchaseOrdersMaxPageSize > 50)
        {
            failures.Add("WebApiSettings:PurchaseOrdersMaxPageSize must not exceed 50.");
        }

        if (options.AllowedSources.Count == 0)
        {
            failures.Add("WebApiSettings:AllowedSources must contain at least one source.");
        }

        foreach (var source in options.AllowedSources)
        {
            if (string.IsNullOrWhiteSpace(source))
            {
                failures.Add("WebApiSettings:AllowedSources must not contain blank values.");
            }
        }

        if (string.IsNullOrWhiteSpace(options.ApiCreateUser))
        {
            failures.Add("WebApiSettings:ApiCreateUser must not be blank.");
        }

        return failures.Count == 0
            ? ValidateOptionsResult.Success
            : ValidateOptionsResult.Fail(failures);
    }
}
