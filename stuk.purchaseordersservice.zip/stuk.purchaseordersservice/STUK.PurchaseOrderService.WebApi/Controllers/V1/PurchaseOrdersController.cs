using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.WebApi.Domain.Config;
using STUK.PurchaseOrderService.WebApi.Domain.Services.V1;
using STUK.PurchaseOrderService.WebApi.Domain.Validation;
using STUK.PurchaseOrderService.WebApi.Swagger.Examples.PurchaseOrders;
using Swashbuckle.AspNetCore.Filters;
using System.Diagnostics;
using System.Net;

namespace STUK.PurchaseOrderService.WebApi.Controllers.V1;

[ApiController]
[Route("PurchaseOrderService/[controller]/v1")]
[Authorize(Policy = ApiSecuritySettings.AuthenticationSchemes.User)]
[ApiExplorerSettings(GroupName = "v1")]
public sealed class PurchaseOrdersController : ControllerBase
{
    private readonly ILogger<PurchaseOrdersController> _logger;
    private readonly IPurchaseOrdersService _purchaseOrdersService;

    public PurchaseOrdersController(
        IPurchaseOrdersService purchaseOrdersService,
        ILogger<PurchaseOrdersController> logger)
    {
        _purchaseOrdersService = purchaseOrdersService;
        _logger = logger;
    }

    /// <summary>
    /// Submit one canonical purchase order candidate for asynchronous processing.
    /// </summary>
    /// <remarks>
    /// The request is persisted before a separate processor communicates asynchronously with ICON. The request must be one
    /// JSON object, include Content-Length, use a JSON media type, and be no larger than 10 KB. Arrays and bulk
    /// submissions are not supported. The service assigns the source and create user; acceptance does not mean
    /// that ICON has created the purchase order.
    /// </remarks>
    /// <param name="purchaseOrder">Canonical purchase order header and at least one line.</param>
    /// <param name="cancellationToken">Cancellation token for the HTTP request.</param>
    /// <response code="200">The candidate was persisted for asynchronous processing.</response>
    /// <response code="400">The JSON shape, content type, or canonical purchase order is invalid.</response>
    /// <response code="401">The bearer token is missing or invalid.</response>
    /// <response code="411">The Content-Length header is missing.</response>
    /// <response code="413">The request body exceeds 10 KB.</response>
    /// <response code="418">The request contains an array or bulk payload.</response>
    /// <response code="503">The service could not complete the request.</response>
    [HttpPost]
    [Consumes("application/json")]
    [ProducesResponseType(typeof(SubmitPurchaseOrderResponse), StatusCodes.Status200OK, "application/json")]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest, "application/problem+json")]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status411LengthRequired, "application/problem+json")]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status413PayloadTooLarge, "application/problem+json")]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status418ImATeapot, "application/problem+json")]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status503ServiceUnavailable, "application/problem+json")]
    [SwaggerRequestExample(typeof(PurchaseOrder), typeof(SubmitPurchaseOrderRequestExample))]
    [SwaggerResponseExample(StatusCodes.Status200OK, typeof(SubmitPurchaseOrderResponseExample))]
    [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(PurchaseOrderValidationProblemExample))]
    [SwaggerResponseExample(StatusCodes.Status411LengthRequired, typeof(ContentLengthRequiredProblemExample))]
    [SwaggerResponseExample(StatusCodes.Status413PayloadTooLarge, typeof(PayloadTooLargeProblemExample))]
    [SwaggerResponseExample(StatusCodes.Status418ImATeapot, typeof(BulkRequestProblemExample))]
    [SwaggerResponseExample(StatusCodes.Status503ServiceUnavailable, typeof(ServiceUnavailableProblemExample))]
    public async Task<ActionResult<SubmitPurchaseOrderResponse>> SubmitPurchaseOrder(
        [FromBody] PurchaseOrder purchaseOrder,
        CancellationToken cancellationToken)
    {
        var response = await _purchaseOrdersService.SubmitPurchaseOrder(
            purchaseOrder,
            cancellationToken);

        if (response.Success)
        {
            return Ok(response.Result);
        }

        return BadRequest(GetProblemDetails(HttpStatusCode.BadRequest, response.Message, response.ValidationResult));
    }

    /// <summary>
    /// Search persisted purchase order candidates.
    /// </summary>
    /// <remarks>
    /// Source is required. Page number starts at 1. Page size starts at 1 and cannot exceed the configured maximum,
    /// which is capped at 50. Filters are combined and an empty result is returned as 404.
    /// </remarks>
    /// <param name="request">Source, optional candidate filters, and bounded pagination.</param>
    /// <param name="cancellationToken">Cancellation token for the HTTP request.</param>
    /// <response code="200">One page of matching purchase order candidates.</response>
    /// <response code="400">A source, status, or pagination value is invalid.</response>
    /// <response code="401">The bearer token is missing or invalid.</response>
    /// <response code="404">No candidates matched all supplied filters.</response>
    /// <response code="503">The service could not complete the request.</response>
    [HttpGet]
    [ProducesResponseType(typeof(PurchaseOrderSearchResponse), StatusCodes.Status200OK, "application/json")]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest, "application/problem+json")]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound, "application/problem+json")]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status503ServiceUnavailable, "application/problem+json")]
    [SwaggerResponseExample(StatusCodes.Status200OK, typeof(PurchaseOrderSearchResponseExample))]
    [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(PurchaseOrderSearchValidationProblemExample))]
    [SwaggerResponseExample(StatusCodes.Status404NotFound, typeof(PurchaseOrderNotFoundProblemExample))]
    [SwaggerResponseExample(StatusCodes.Status503ServiceUnavailable, typeof(ServiceUnavailableProblemExample))]
    public async Task<ActionResult<PurchaseOrderSearchResponse>> GetPurchaseOrders(
        [FromQuery] GetPurchaseOrdersRequest request,
        CancellationToken cancellationToken)
    {
        var response = await _purchaseOrdersService.GetPurchaseOrders(request, cancellationToken);

        if (response.Success)
        {
            if (response.Result is not null && response.Result.Orders.Count == 0)
            {
                return NotFound(GetEmptySearchProblemDetails());
            }

            return Ok(response.Result);
        }

        return BadRequest(GetProblemDetails(HttpStatusCode.BadRequest, response.Message, response.ValidationResult));
    }

    private static ProblemDetails GetEmptySearchProblemDetails() => new()
    {
        Type = "https://tools.ietf.org/html/rfc9110#section-15.5.5",
        Title = "Purchase orders were not found.",
        Status = StatusCodes.Status404NotFound,
        Detail = "No purchase orders matched the supplied search criteria."
    };

    private object GetProblemDetails(HttpStatusCode httpStatusCode, string detail, ValidationResult validationResult)
    {
        var statusCode = (int)httpStatusCode;
        var traceId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;

        _logger.LogWarning("{StatusCode} {Detail}", statusCode, detail);

        var problemDetails = new ValidationProblemDetails(
            validationResult.Errors.ToDictionary(error => error.Key, error => error.Value.ToArray()))
        {
            Type = "https://tools.ietf.org/html/rfc9110#section-15.5.1",
            Title = "One or more validation errors occurred.",
            Status = statusCode
        };

        problemDetails.Extensions["traceId"] = traceId;
        problemDetails.Extensions["errorType"] = httpStatusCode.ToString();
        problemDetails.Extensions["errorDescription"] = validationResult.ErrorsString;

        return problemDetails;
    }
}
