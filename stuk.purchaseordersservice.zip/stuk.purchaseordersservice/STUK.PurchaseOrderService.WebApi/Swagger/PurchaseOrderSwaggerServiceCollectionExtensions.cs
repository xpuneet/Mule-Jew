using Microsoft.OpenApi;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.WebApi.Controllers.V1;
using STUK.PurchaseOrderService.WebApi.Swagger.Examples.PurchaseOrders;
using Swashbuckle.AspNetCore.Filters;

namespace STUK.PurchaseOrderService.WebApi.Swagger;

public static class PurchaseOrderSwaggerServiceCollectionExtensions
{
    public static IServiceCollection AddPurchaseOrderSwagger(this IServiceCollection services)
    {
        services.AddSwaggerExamplesFromAssemblyOf<SubmitPurchaseOrderRequestExample>();
        services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "STUK PurchaseOrderService API",
                Version = "v1",
                Description = "Canonical Purchase Order API for persisting purchase order candidates before asynchronous ICON synchronization."
            });

            options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Description = "JWT Authorization header using the Bearer scheme.",
                Name = "Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.Http,
                Scheme = "bearer"
            });

            options.IncludeXmlComments(typeof(PurchaseOrdersController).Assembly);
            options.IncludeXmlComments(typeof(PurchaseOrder).Assembly);
            options.ExampleFilters();
            options.EnableAnnotations();
        });

        return services;
    }
}
