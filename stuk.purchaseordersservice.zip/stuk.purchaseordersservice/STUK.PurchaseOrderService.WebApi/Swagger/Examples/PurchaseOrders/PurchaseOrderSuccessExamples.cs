using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using Swashbuckle.AspNetCore.Filters;

namespace STUK.PurchaseOrderService.WebApi.Swagger.Examples.PurchaseOrders;

public sealed class SubmitPurchaseOrderResponseExample : IExamplesProvider<SubmitPurchaseOrderResponse>
{
    public SubmitPurchaseOrderResponse GetExamples() => new()
    {
        CandidateId = Guid.Parse("00000000-0000-0000-0000-000000000001"),
        Status = PurchaseOrderCandidateStatus.ReadyForSubmission,
        AcceptedDateTime = new DateTimeOffset(2026, 9, 15, 10, 30, 0, TimeSpan.Zero),
        Message = "Purchase order accepted for asynchronous processing."
    };
}

public sealed class PurchaseOrderSearchResponseExample : IExamplesProvider<PurchaseOrderSearchResponse>
{
    public PurchaseOrderSearchResponse GetExamples() => new()
    {
        Orders =
        [
            new PurchaseOrderSummary
            {
                CandidateId = Guid.Parse("00000000-0000-0000-0000-000000000001"),
                Source = PurchaseOrderSources.Api,
                Account = "BRIT186",
                Branch = "385",
                Reference = "20211108",
                IconPurchaseOrderNumber = "PO123456",
                Status = "READY_FOR_SUBMISSION",
                AcceptedDateTime = new DateTimeOffset(2026, 9, 15, 10, 30, 0, TimeSpan.Zero)
            }
        ],
        PageNumber = 1,
        PageSize = 25
    };
}
