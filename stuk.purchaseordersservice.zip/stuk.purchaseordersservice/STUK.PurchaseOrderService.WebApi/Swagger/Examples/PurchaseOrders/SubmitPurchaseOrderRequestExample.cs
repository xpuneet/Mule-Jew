using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using Swashbuckle.AspNetCore.Filters;

namespace STUK.PurchaseOrderService.WebApi.Swagger.Examples.PurchaseOrders;

public sealed class SubmitPurchaseOrderRequestExample : IExamplesProvider<PurchaseOrder>
{
    public PurchaseOrder GetExamples() => new()
    {
        PurchaseOrderHeader = new PurchaseOrderHeader
        {
            Account = "BRIT186",
            Branch = 385,
            StockClass = 1,
            Reference = "20211108",
            DateExpected = new DateOnly(2026, 9, 22),
            Contacts =
            [
                new PurchaseOrderContact
                {
                    Type = PurchaseOrderPartyType.Supplier,
                    Name = "John Smith",
                    Contact = "1",
                    Phone = "+44 1488 662000",
                    Email = "supplier@example.com"
                }
            ],
            Addresses =
            [
                new PurchaseOrderAddress
                {
                    Type = PurchaseOrderPartyType.Supplier,
                    Lines = ["Example Supplier", "10 High Street"],
                    PostCode = "RG17 0YU",
                    Country = "GB"
                }
            ],
            Instructions = "Deliver during goods-in opening hours.",
            Narrative = "Example stock replenishment order.",
            OrderType = PurchaseOrderType.Stock,
            DeliveryMethod = PurchaseOrderDeliveryMethod.Delivery,
            SuspendOrder = false,
            ExtOrderRef = "REF01",
            ReasonPurchase = "STOCK",
            ExtensionAttributes =
            [
                new PurchaseOrderExtensionAttribute
                {
                    Name = "packIgnore",
                    Value = "true"
                }
            ]
        },
        PurchaseOrderLines =
        [
            new PurchaseOrderLine
            {
                ProductId = "A0000201",
                Manufacturer = "Example Manufacturer",
                StockClass = 1,
                ProductDescription = "Red Brick",
                Quantity = 5,
                Unit = "EA",
                DateExpected = new DateOnly(2026, 9, 22),
                SpecialInstructions = "Keep dry.",
                InternalInstructions = "Check packaging on receipt.",
                Pricing = new PurchaseOrderPricing
                {
                    Unit = "EA",
                    Price = 8.45f
                },
                Tally =
                [
                    new PurchaseOrderTallyItem
                    {
                        Quantity = 5,
                        Length = 215,
                        Width = 102
                    }
                ]
            }
        ]
    };
}
