using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Filters;

namespace STUK.PurchaseOrderService.WebApi.Swagger.Examples.PurchaseOrders;

public sealed class PurchaseOrderValidationProblemExample : IExamplesProvider<ValidationProblemDetails>
{
    public ValidationProblemDetails GetExamples()
    {
        var problem = new ValidationProblemDetails(new Dictionary<string, string[]>
        {
            ["purchaseOrderLines[0].quantity"] = ["Quantity must be greater than zero."]
        })
        {
            Type = "https://tools.ietf.org/html/rfc9110#section-15.5.1",
            Title = "One or more validation errors occurred.",
            Status = StatusCodes.Status400BadRequest
        };
        problem.Extensions["traceId"] = "00-example-trace-id-00";
        problem.Extensions["errorType"] = "BadRequest";
        problem.Extensions["errorDescription"] = "purchaseOrderLines[0].quantity: Quantity must be greater than zero.";
        return problem;
    }
}

public sealed class PurchaseOrderSearchValidationProblemExample : IExamplesProvider<ValidationProblemDetails>
{
    public ValidationProblemDetails GetExamples()
    {
        var problem = new ValidationProblemDetails(new Dictionary<string, string[]>
        {
            ["pageSize"] = ["PageSize must be between 1 and the configured maximum of 50."]
        })
        {
            Type = "https://tools.ietf.org/html/rfc9110#section-15.5.1",
            Title = "One or more validation errors occurred.",
            Status = StatusCodes.Status400BadRequest
        };
        problem.Extensions["traceId"] = "00-example-trace-id-00";
        problem.Extensions["errorType"] = "BadRequest";
        problem.Extensions["errorDescription"] = "pageSize: PageSize must be between 1 and the configured maximum of 50.";
        return problem;
    }
}

public sealed class PurchaseOrderNotFoundProblemExample : IExamplesProvider<ProblemDetails>
{
    public ProblemDetails GetExamples() => new()
    {
        Type = "https://tools.ietf.org/html/rfc9110#section-15.5.5",
        Title = "Purchase orders were not found.",
        Status = StatusCodes.Status404NotFound,
        Detail = "No purchase orders matched the supplied search criteria."
    };
}

public sealed class ContentLengthRequiredProblemExample : IExamplesProvider<ProblemDetails>
{
    public ProblemDetails GetExamples() => RequestGuardProblem(
        StatusCodes.Status411LengthRequired,
        "Content-Length is required.");

    private static ProblemDetails RequestGuardProblem(int status, string detail) => new()
    {
        Title = "Purchase order request rejected.",
        Status = status,
        Detail = detail,
        Instance = "/PurchaseOrderService/PurchaseOrders/v1"
    };
}

public sealed class PayloadTooLargeProblemExample : IExamplesProvider<ProblemDetails>
{
    public ProblemDetails GetExamples() => new()
    {
        Title = "Purchase order request rejected.",
        Status = StatusCodes.Status413PayloadTooLarge,
        Detail = "Request body exceeds the 10 KB limit.",
        Instance = "/PurchaseOrderService/PurchaseOrders/v1"
    };
}

public sealed class BulkRequestProblemExample : IExamplesProvider<ProblemDetails>
{
    public ProblemDetails GetExamples() => new()
    {
        Title = "Purchase order request rejected.",
        Status = StatusCodes.Status418ImATeapot,
        Detail = "Bulk purchase-order requests are not supported.",
        Instance = "/PurchaseOrderService/PurchaseOrders/v1"
    };
}

public sealed class ServiceUnavailableProblemExample : IExamplesProvider<ProblemDetails>
{
    public ProblemDetails GetExamples()
    {
        var problem = new ProblemDetails
        {
            Title = "Service Temporarily Unavailable",
            Status = StatusCodes.Status503ServiceUnavailable,
            Detail = "PurchaseOrderService could not complete the request.",
            Instance = "/PurchaseOrderService/PurchaseOrders/v1"
        };
        problem.Extensions["traceId"] = "00-example-trace-id-00";
        return problem;
    }
}
