using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace STUK.PurchaseOrderService.WebApi.Middleware;

public sealed class CanonicalPurchaseOrderRequestGuardMiddleware
{
    public const long MaximumBodySizeBytes = 10_240;

    private static readonly PathString PurchaseOrdersPath =
        new("/PurchaseOrderService/PurchaseOrders/v1");
    private static readonly PathString PurchaseOrdersPathWithTrailingSlash =
        new("/PurchaseOrderService/PurchaseOrders/v1/");

    private static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.Web);
    private readonly RequestDelegate _next;

    public CanonicalPurchaseOrderRequestGuardMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (!HttpMethods.IsPost(context.Request.Method)
            || !IsPurchaseOrdersPath(context.Request.Path))
        {
            await _next(context);
            return;
        }

        if (!context.Request.ContentLength.HasValue)
        {
            await WriteProblem(context, StatusCodes.Status411LengthRequired, "Content-Length is required.");
            return;
        }

        if (context.Request.ContentLength.Value > MaximumBodySizeBytes)
        {
            await WriteProblem(context, StatusCodes.Status413PayloadTooLarge, "Request body exceeds the 10 KB limit.");
            return;
        }

        if (!IsJsonContentType(context.Request.ContentType))
        {
            await WriteProblem(context, StatusCodes.Status400BadRequest, "Content-Type must be application/json.");
            return;
        }

        var firstToken = await ReadFirstNonWhitespaceCharacter(context.Request);
        if (firstToken == '[')
        {
            await WriteProblem(context, StatusCodes.Status418ImATeapot, "Bulk purchase-order requests are not supported.");
            return;
        }

        if (firstToken != '{')
        {
            await WriteProblem(context, StatusCodes.Status400BadRequest, "Request body must contain one JSON object.");
            return;
        }

        await _next(context);
    }

    private static bool IsJsonContentType(string? contentType)
    {
        if (string.IsNullOrWhiteSpace(contentType))
        {
            return false;
        }

        var mediaType = contentType.Split(';', 2, StringSplitOptions.TrimEntries)[0];
        return string.Equals(mediaType, "application/json", StringComparison.OrdinalIgnoreCase)
            || mediaType.EndsWith("+json", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsPurchaseOrdersPath(PathString path)
    {
        return path.Equals(PurchaseOrdersPath)
            || path.Equals(PurchaseOrdersPathWithTrailingSlash);
    }

    private static async Task<char?> ReadFirstNonWhitespaceCharacter(HttpRequest request)
    {
        request.EnableBuffering();
        request.Body.Position = 0;

        try
        {
            using var reader = new StreamReader(
                request.Body,
                Encoding.UTF8,
                detectEncodingFromByteOrderMarks: true,
                bufferSize: 128,
                leaveOpen: true);

            var buffer = new char[1];
            while (await reader.ReadAsync(buffer.AsMemory(), request.HttpContext.RequestAborted) > 0)
            {
                var value = buffer[0];
                if (!char.IsWhiteSpace(value))
                {
                    return value;
                }
            }

            return null;
        }
        finally
        {
            request.Body.Position = 0;
        }
    }

    private static async Task WriteProblem(HttpContext context, int statusCode, string detail)
    {
        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/problem+json";

        var problem = new ProblemDetails
        {
            Title = "Purchase order request rejected.",
            Detail = detail,
            Status = statusCode,
            Instance = context.Request.Path
        };

        await JsonSerializer.SerializeAsync(
            context.Response.Body,
            problem,
            SerializerOptions,
            context.RequestAborted);
    }
}
