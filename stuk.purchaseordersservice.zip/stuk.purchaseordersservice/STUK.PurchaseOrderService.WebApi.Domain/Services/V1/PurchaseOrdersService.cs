using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Serialization;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.WebApi.Domain.Config;
using STUK.PurchaseOrderService.WebApi.Domain.Validation;

namespace STUK.PurchaseOrderService.WebApi.Domain.Services.V1;

public sealed class PurchaseOrdersService : IPurchaseOrdersService
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<PurchaseOrdersService> _logger;
    private readonly IPurchaseOrdersRepository _purchaseOrdersRepository;
    private readonly TimeProvider _timeProvider;

    public PurchaseOrdersService(
        IPurchaseOrdersRepository purchaseOrdersRepository,
        AppSettings appSettings,
        ILogger<PurchaseOrdersService> logger,
        TimeProvider timeProvider)
    {
        _purchaseOrdersRepository = purchaseOrdersRepository;
        _appSettings = appSettings;
        _logger = logger;
        _timeProvider = timeProvider;
    }

    public async Task<ServiceResponse<SubmitPurchaseOrderResponse>> SubmitPurchaseOrder(
        PurchaseOrder purchaseOrder,
        CancellationToken cancellationToken = default)
    {
        var validationResult = PurchaseOrderRequestValidator.ValidatePurchaseOrder(purchaseOrder);
        if (!validationResult.IsValid)
        {
            return ServiceResponse<SubmitPurchaseOrderResponse>.Error(validationResult);
        }

        var candidate = CreateCandidate(purchaseOrder);
        await _purchaseOrdersRepository.AddCandidate(candidate, cancellationToken);

        _logger.LogInformation(
            "Purchase order candidate {CandidateId} accepted from {Source}.",
            candidate.CandidateId,
            candidate.Source);

        return ServiceResponse<SubmitPurchaseOrderResponse>.Ok(new SubmitPurchaseOrderResponse
        {
            CandidateId = candidate.CandidateId,
            Status = candidate.CandidateStatus.Status,
            AcceptedDateTime = candidate.AcceptedDateTime,
            Message = "Purchase order accepted for asynchronous processing."
        });
    }

    public async Task<ServiceResponse<PurchaseOrderSearchResponse>> GetPurchaseOrders(
        GetPurchaseOrdersRequest request,
        CancellationToken cancellationToken = default)
    {
        var validationResult = PurchaseOrderRequestValidator.ValidateGetPurchaseOrdersRequest(request, _appSettings);
        if (!validationResult.IsValid)
        {
            return ServiceResponse<PurchaseOrderSearchResponse>.Error(validationResult);
        }

        EnumMemberValue.TryParse<PurchaseOrderCandidateStatus>(request.Status, out var status);

        var results = await _purchaseOrdersRepository.SearchCandidates(new PurchaseOrderSearchCriteria
        {
            Source = request.Source!,
            Account = request.Account,
            Branch = request.Branch,
            Reference = request.Reference,
            IconPurchaseOrderNumber = request.IconPurchaseOrderNumber,
            Status = string.IsNullOrWhiteSpace(request.Status) ? null : status,
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        }, cancellationToken);

        return ServiceResponse<PurchaseOrderSearchResponse>.Ok(new PurchaseOrderSearchResponse
        {
            Orders = results,
            PageNumber = request.PageNumber,
            PageSize = request.PageSize
        });
    }

    private PurchaseOrderCandidate CreateCandidate(PurchaseOrder purchaseOrder)
    {
        var now = _timeProvider.GetUtcNow();
        purchaseOrder.PurchaseOrderHeader!.CreateUser = _appSettings.WebApiSettings.ApiCreateUser;

        return new PurchaseOrderCandidate
        {
            CandidateId = Guid.NewGuid(),
            Source = PurchaseOrderSources.Api,
            Payload = purchaseOrder,
            CandidateStatus = new CandidateStatus
            {
                Status = PurchaseOrderCandidateStatus.ReadyForSubmission,
                StatusDateTime = now,
                CreatedDateTime = now,
                UpdatedDateTime = now,
                RefreshDateTime = now,
                PendingRetriesCount = 0,
                ProcessingRetriesCount = 0
            },
            AcceptedDateTime = now
        };
    }
}
