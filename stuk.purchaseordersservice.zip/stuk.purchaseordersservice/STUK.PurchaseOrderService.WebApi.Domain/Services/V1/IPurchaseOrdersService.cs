using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.WebApi.Domain.Services.V1;

public interface IPurchaseOrdersService
{
    Task<ServiceResponse<SubmitPurchaseOrderResponse>> SubmitPurchaseOrder(
        PurchaseOrder purchaseOrder,
        CancellationToken cancellationToken = default);

    Task<ServiceResponse<PurchaseOrderSearchResponse>> GetPurchaseOrders(
        GetPurchaseOrdersRequest request,
        CancellationToken cancellationToken = default);
}
