using STUK.PurchaseOrderService.WebApi.Domain.Validation;

namespace STUK.PurchaseOrderService.WebApi.Domain.Services;

public sealed class ServiceResponse<T>
{
    private ServiceResponse(T? result, ValidationResult validationResult, string message)
    {
        Result = result;
        ValidationResult = validationResult;
        Message = message;
    }

    public bool Success => ValidationResult.IsValid;

    public T? Result { get; }

    public string Message { get; }

    public ValidationResult ValidationResult { get; }

    public static ServiceResponse<T> Ok(T result, string message = "")
    {
        return new ServiceResponse<T>(result, new ValidationResult(), message);
    }

    public static ServiceResponse<T> Error(ValidationResult validationResult, string message = "Validation failed.")
    {
        return new ServiceResponse<T>(default, validationResult, message);
    }
}
