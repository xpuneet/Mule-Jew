namespace STUK.PurchaseOrderService.WebApi.Domain.Validation;

public sealed class ValidationResult
{
    public Dictionary<string, List<string>> Errors { get; } = new(StringComparer.OrdinalIgnoreCase);

    public bool MissingKeyData { get; set; }

    public bool IsValid => Errors.Count == 0;

    public string ErrorsString => string.Join("; ", Errors.SelectMany(error => error.Value.Select(value => $"{error.Key}: {value}")));

    public void AddError(string key, string message, bool isKeyField = false)
    {
        if (!Errors.TryGetValue(key, out var values))
        {
            values = [];
            Errors.Add(key, values);
        }

        values.Add(message);
        MissingKeyData |= isKeyField;
    }
}
