using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Serialization;
using STUK.PurchaseOrderService.WebApi.Domain.Config;

namespace STUK.PurchaseOrderService.WebApi.Domain.Validation;

public static class PurchaseOrderRequestValidator
{
    public static ValidationResult ValidatePurchaseOrder(
        PurchaseOrder? purchaseOrder)
    {
        var result = new ValidationResult();

        if (purchaseOrder is null)
        {
            result.AddError("purchaseOrder", "Purchase order is required.", isKeyField: true);
            return result;
        }

        var header = purchaseOrder.PurchaseOrderHeader;
        if (header is null)
        {
            result.AddError("purchaseOrderHeader", "Purchase order header is required.", isKeyField: true);
        }
        else
        {
            ValidateRequired("purchaseOrderHeader.account", header.Account, result);

            if (!header.StockClass.HasValue)
            {
                result.AddError("purchaseOrderHeader.stockClass", "Stock class is required.", isKeyField: true);
            }

            if (!header.SuspendOrder.HasValue)
            {
                result.AddError("purchaseOrderHeader.suspendOrder", "Suspend order is required.", isKeyField: true);
            }

            ValidatePackIgnore(header.ExtensionAttributes, result);
        }

        var lines = purchaseOrder.PurchaseOrderLines;
        if (lines is null || lines.Count == 0)
        {
            result.AddError("purchaseOrderLines", "At least one purchase order line is required.", isKeyField: true);
            return result;
        }

        for (var i = 0; i < lines.Count; i++)
        {
            var line = lines[i];
            if (line is null)
            {
                result.AddError($"purchaseOrderLines[{i}]", "Purchase order line is required.", isKeyField: true);
                continue;
            }

            ValidateRequired($"purchaseOrderLines[{i}].productId", line.ProductId, result);

            if (!line.StockClass.HasValue)
            {
                result.AddError($"purchaseOrderLines[{i}].stockClass", "Stock class is required.", isKeyField: true);
            }

            if (line.Quantity <= 0)
            {
                result.AddError(
                    $"purchaseOrderLines[{i}].quantity",
                    "Quantity must be greater than zero.",
                    isKeyField: line.Quantity == 0);
            }
        }

        return result;
    }

    public static ValidationResult ValidateGetPurchaseOrdersRequest(GetPurchaseOrdersRequest request, AppSettings appSettings)
    {
        var result = new ValidationResult();

        ValidateSource(request.Source, appSettings, result);

        if (request.PageNumber < 1)
        {
            result.AddError(nameof(GetPurchaseOrdersRequest.PageNumber), "PageNumber must be greater than zero.");
        }

        if (request.PageSize < 1 || request.PageSize > appSettings.WebApiSettings.PurchaseOrdersMaxPageSize)
        {
            result.AddError(
                nameof(GetPurchaseOrdersRequest.PageSize),
                $"PageSize must be between 1 and {appSettings.WebApiSettings.PurchaseOrdersMaxPageSize}.");
        }

        if (!string.IsNullOrWhiteSpace(request.Status)
            && !EnumMemberValue.TryParse<PurchaseOrderCandidateStatus>(request.Status, out _))
        {
            result.AddError(nameof(GetPurchaseOrdersRequest.Status), $"Status '{request.Status}' is not supported.");
        }

        return result;
    }

    private static void ValidateSource(string? source, AppSettings appSettings, ValidationResult result)
    {
        if (string.IsNullOrWhiteSpace(source))
        {
            result.AddError("source", "Source is required.", isKeyField: true);
            return;
        }

        if (!appSettings.WebApiSettings.AllowedSources.Contains(source, StringComparer.OrdinalIgnoreCase))
        {
            result.AddError("source", $"Source '{source}' is not configured.", isKeyField: true);
        }
    }

    private static void ValidatePackIgnore(
        IReadOnlyCollection<PurchaseOrderExtensionAttribute>? extensionAttributes,
        ValidationResult result)
    {
        var packIgnore = extensionAttributes?.FirstOrDefault(
            attribute => attribute is not null
                && string.Equals(attribute.Name, "packIgnore", StringComparison.OrdinalIgnoreCase));

        ValidateBooleanString(
            "purchaseOrderHeader.extensionAttributes[packIgnore].value",
            packIgnore?.Value,
            result);
    }

    private static void ValidateBooleanString(string fieldName, string? value, ValidationResult result)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            result.AddError(fieldName, $"{fieldName} is required.", isKeyField: true);
        }
        else if (!bool.TryParse(value, out _))
        {
            result.AddError(fieldName, $"{fieldName} must be 'true' or 'false'.");
        }
    }

    private static void ValidateRequired(string fieldName, string? value, ValidationResult result)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            result.AddError(fieldName, $"{fieldName} is required.", isKeyField: true);
        }
    }
}
