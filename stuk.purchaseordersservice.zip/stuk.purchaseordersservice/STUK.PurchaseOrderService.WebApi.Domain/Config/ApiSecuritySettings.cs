namespace STUK.PurchaseOrderService.WebApi.Domain.Config;

public sealed class ApiSecuritySettings
{
    public string OpenIdAuthority { get; init; } = string.Empty;

    public Dictionary<string, string> SchemeToScopeMappings { get; init; } = new();

    public static class AuthenticationSchemes
    {
        public const string User = "User";
    }
}
