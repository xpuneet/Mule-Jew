using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.WebApi.Domain.Config;

public sealed class AppSettings
{
    public AppSettings(IOptions<CommonSettings> commonSettings, IOptions<WebApiSettings> webApiSettings)
        : this(commonSettings.Value, webApiSettings.Value)
    {
    }

    public AppSettings(CommonSettings commonSettings, WebApiSettings webApiSettings)
    {
        CommonSettings = commonSettings;
        WebApiSettings = webApiSettings;
    }

    public CommonSettings CommonSettings { get; }

    public WebApiSettings WebApiSettings { get; }
}
