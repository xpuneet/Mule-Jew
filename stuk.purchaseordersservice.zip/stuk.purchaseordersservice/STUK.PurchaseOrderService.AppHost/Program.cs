using STUK.PurchaseOrderService.AppHost;

var builder = DistributedApplication.CreateBuilder(args);

var relexLocalRoot = Environment.GetEnvironmentVariable("STUK_RELEX_LOCAL_ROOT");
if (string.IsNullOrWhiteSpace(relexLocalRoot))
{
    var localTempRoot = OperatingSystem.IsWindows()
        ? Path.GetTempPath()
        : Path.Combine(Path.DirectorySeparatorChar.ToString(), "tmp");
    relexLocalRoot = Path.Combine(localTempRoot, "stuk-purchase-orders", "relex");
}
else
{
    relexLocalRoot = Path.GetFullPath(relexLocalRoot);
}

foreach (var relativePath in new[]
{
    Path.Combine("data", "input"),
    Path.Combine("data", "output", "archive"),
    Path.Combine("data", "output", "error")
})
{
    Directory.CreateDirectory(Path.Combine(relexLocalRoot, relativePath));
}

var submissionEnabled =
    Environment.GetEnvironmentVariable("STUK_PROCESSOR_SUBMISSION_ENABLED") ?? "true";

var activationToken = builder.AddParameter(
    "icon-activation-token",
    "local-only-icon-activation-token",
    publishValueAsDefault: false,
    secret: true);
var purchaseOrderToken = builder.AddParameter(
    "icon-purchase-order-token",
    "local-only-icon-purchase-order-token",
    publishValueAsDefault: false,
    secret: true);

var sql = builder
    .AddSqlServer("sql")
    .WithImageTag("2022-latest")
    .WithDataVolume()
    .WithContainerRuntimeArgs("--platform=linux/amd64");
var purchaseOrdersDatabase = sql.AddDatabase(
    "PurchaseOrdersServiceDB",
    "Orders")
    .WithCreationScript(PurchaseOrderCreationScript.Load(
        Path.Combine(AppContext.BaseDirectory, "SqlRoot")));

var functionsStorage = builder
    .AddAzureStorage("functions-storage")
    .RunAsEmulator();

var iconMock = builder
    .AddProject<Projects.STUK_PurchaseOrderService_IconMock>("icon-mock")
    .WithHttpEndpoint(name: "http")
    .WithHttpHealthCheck("/health", endpointName: "http")
    .WithEnvironment("DOTNET_ENVIRONMENT", "Development")
    .WithEnvironment("ASPNETCORE_ENVIRONMENT", "Development")
    .WithEnvironment(
        "IconMock__ActivationAuthToken",
        activationToken)
    .WithEnvironment(
        "IconMock__PurchaseOrderAuthToken",
        purchaseOrderToken);
var iconMockBaseUrl = ReferenceExpression.Create(
    $"{iconMock.GetEndpoint("http")}/");

var webApi = builder
    .AddProject<Projects.STUK_PurchaseOrderService_WebApi>("web-api")
    .WithReference(purchaseOrdersDatabase)
    .WithEnvironment("DOTNET_ENVIRONMENT", "Development")
    .WithEnvironment("ASPNETCORE_ENVIRONMENT", "Development")
    .WithEnvironment("DatabaseConfigurationRefreshInterval", "60")
    .WithHttpHealthCheck("/health")
    .WithExternalHttpEndpoints()
    .WaitFor(purchaseOrdersDatabase);

var processorFunctions = builder
    .AddAzureFunctionsProject<Projects.STUK_PurchaseOrderService_Processor_Functions>(
        "processor-functions")
    .WithHostStorage(functionsStorage)
    .WithEnvironment(
        "ConnectionStrings__PurchaseOrdersServiceDB",
        purchaseOrdersDatabase)
    .WithEnvironment("DOTNET_ENVIRONMENT", "Development")
    .WithEnvironment("AZURE_FUNCTIONS_ENVIRONMENT", "Development")
    .WithEnvironment("FUNCTIONS_WORKER_RUNTIME", "dotnet-isolated")
    .WithEnvironment("ReadyCandidatesProcessorCronExpression", "*/5 * * * * *")
    .WithEnvironment("RelexIngestionCronExpression", "*/5 * * * * *")
    .WithEnvironment("RelexNotificationProducerCronExpression", "0 * * * * *")
    .WithEnvironment("RelexNotifications__ResultsEnabled", "false")
    .WithEnvironment("RelexNotifications__MissingProposalEnabled", "false")
    .WithEnvironment(
        "BatchProcessorSettings__ReadyCandidatesProcessorCronExpression",
        "*/5 * * * * *")
    .WithEnvironment("BatchProcessorSettings__SubmissionEnabled", submissionEnabled)
    .WithEnvironment("BatchProcessorSettings__LeaseDurationSeconds", "120")
    .WithEnvironment(
        "BatchProcessorSettings__OutcomePersistenceTimeoutSeconds",
        "15")
    .WithEnvironment("RelexIngestionSettings__Provider", "Local")
    .WithEnvironment("RelexIngestionSettings__LocalRootPath", relexLocalRoot)
    .WithEnvironment("RelexIngestionSettings__InputPath", "/data/input")
    .WithEnvironment("RelexIngestionSettings__ArchivePath", "/data/output/archive")
    .WithEnvironment("RelexIngestionSettings__ErrorPath", "/data/output/error")
    .WithEnvironment("RelexIngestionSettings__FilePattern", "SG_OrderProposal*.csv")
    .WithEnvironment("RelexIngestionSettings__MinimumFileAgeSeconds", "2")
    .WithEnvironment("IconSettings__HttpRequestTimeoutSeconds", "30")
    .WithEnvironment("IconSettings__BaseUrl", iconMockBaseUrl)
    .WithEnvironment("IconSettings__K8_XI_AuthToken", purchaseOrderToken)
    .WithEnvironment("IconSettings__ReportsBaseUrl", iconMockBaseUrl)
    .WithEnvironment("IconSettings__ReportsAuthToken", activationToken)
    .WithEnvironment(
        "IconSettings__PurchaseOrderActivationOptionsReportName",
        "CF_ICXI0002")
    .WithEnvironment("IconSettings__PurchaseOrderBaseUrl", iconMockBaseUrl)
    .WithEnvironment("IconSettings__PurchaseOrderAuthToken", purchaseOrderToken)
    .WaitFor(purchaseOrdersDatabase)
    .WaitFor(functionsStorage)
    .WaitFor(iconMock);

var purchaseOrderAdmin = builder
    .AddProject<Projects.STUK_PurchaseOrderService_PurchaseOrderAdmin>("web-app")
    .WithReference(purchaseOrdersDatabase)
    .WithEnvironment("DOTNET_ENVIRONMENT", "Development")
    .WithEnvironment("ASPNETCORE_ENVIRONMENT", "Development")
    .WithEnvironment("DatabaseConfigurationRefreshInterval", "60")
    .WithExternalHttpEndpoints()
    .WaitFor(purchaseOrdersDatabase);
var purchaseOrderAdminUrl = ReferenceExpression.Create(
    $"{purchaseOrderAdmin.GetEndpoint("http")}/");
purchaseOrderAdmin
    .WithEnvironment("HostURL", purchaseOrderAdminUrl)
    .WithEnvironment("AppURI", string.Empty)
    .WithEnvironment("WebApp__EnableLocalDevelopmentAuthentication", "true");

builder.Build().Run();
