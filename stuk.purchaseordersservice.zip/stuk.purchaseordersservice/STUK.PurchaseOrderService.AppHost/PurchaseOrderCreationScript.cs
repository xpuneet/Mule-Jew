namespace STUK.PurchaseOrderService.AppHost;

internal static class PurchaseOrderCreationScript
{
    private static readonly string[] RelativeScriptPaths =
    [
        "purchase-order/010-preflight.sql",
        "purchase-order/020-schema.sql",
        "purchase-order/030-operational-tables.sql",
        "purchase-order/040-api-configuration-procedures.sql",
        "purchase-order/050-batch-ingestion-procedures.sql",
        "purchase-order/060-claim-recovery-procedures.sql",
        "purchase-order/070-submission-outcome-procedures.sql",
        "purchase-order/080-support-notification-procedures.sql",
        "purchase-order/085-webapp-procedures.sql",
        "purchase-order/090-security.sql",
        "purchase-order/100-verify.sql",
        "local/001-po-configuration-seed.sql"
    ];

    public static string Load(string sqlRoot)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sqlRoot);

        var sections = new List<string>
        {
            """
            IF DB_ID(N'Orders') IS NULL
            BEGIN
                CREATE DATABASE [Orders];
            END;
            GO
            USE [Orders];
            GO
            """
        };

        foreach (var relativePath in RelativeScriptPaths)
        {
            var path = Path.Combine(
                sqlRoot,
                relativePath.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(path))
            {
                throw new FileNotFoundException(
                    $"Required database creation script was not found: {path}",
                    path);
            }

            sections.Add(File.ReadAllText(path));
        }

        return string.Join(Environment.NewLine, sections);
    }
}
