SET NOCOUNT ON;
SET XACT_ABORT ON;

IF EXISTS
(
    SELECT 1
    FROM sys.schemas
    WHERE [name] = N'po'
      AND [principal_id] <> DATABASE_PRINCIPAL_ID(N'dbo')
)
BEGIN
    ;THROW 51000, 'Existing schema [po] must be owned by [dbo].', 1;
END;

IF OBJECT_ID(N'[po].[ApplicationSetting]', N'U') IS NOT NULL
   AND
   (
       EXISTS
       (
           SELECT 1
           FROM
           (
               VALUES
                   (N'Context', N'nvarchar', CONVERT(smallint, 200), CAST(0 AS bit), CAST(0 AS bit)),
                   (N'Key', N'nvarchar', CONVERT(smallint, 512), CAST(0 AS bit), CAST(0 AS bit)),
                   (N'Value', N'nvarchar', CONVERT(smallint, -1), CAST(0 AS bit), CAST(0 AS bit))
           ) AS expected (ColumnName, TypeName, MaxLength, IsNullable, IsIdentity)
           LEFT JOIN sys.columns AS actualColumn
               ON actualColumn.object_id = OBJECT_ID(N'[po].[ApplicationSetting]', N'U')
              AND actualColumn.name = expected.ColumnName
           LEFT JOIN sys.types AS actualType
               ON actualType.user_type_id = actualColumn.user_type_id
           WHERE actualColumn.column_id IS NULL
              OR actualType.name <> expected.TypeName
              OR actualType.is_user_defined = 1
              OR actualColumn.max_length <> expected.MaxLength
              OR actualColumn.is_nullable <> expected.IsNullable
              OR actualColumn.is_identity <> expected.IsIdentity
       )
       OR
       (
           SELECT COUNT_BIG(*)
           FROM sys.columns
           WHERE object_id = OBJECT_ID(N'[po].[ApplicationSetting]', N'U')
       ) <> 3
   )
BEGIN
    ;THROW 51000, 'Existing [po].[ApplicationSetting] contract mismatch: expected [Context] nvarchar(100), [Key] nvarchar(256), and [Value] nvarchar(max), all NOT NULL.', 1;
END;

IF OBJECT_ID(N'[po].[ApplicationSetting]', N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1
       FROM sys.indexes AS applicationSettingPrimaryKey
       INNER JOIN sys.index_columns AS contextIndexColumn
           ON contextIndexColumn.[object_id] = applicationSettingPrimaryKey.[object_id]
          AND contextIndexColumn.[index_id] = applicationSettingPrimaryKey.[index_id]
       INNER JOIN sys.columns AS contextColumn
           ON contextColumn.[object_id] = contextIndexColumn.[object_id]
          AND contextColumn.[column_id] = contextIndexColumn.[column_id]
       INNER JOIN sys.index_columns AS keyIndexColumn
           ON keyIndexColumn.[object_id] = applicationSettingPrimaryKey.[object_id]
          AND keyIndexColumn.[index_id] = applicationSettingPrimaryKey.[index_id]
       INNER JOIN sys.columns AS keyColumn
           ON keyColumn.[object_id] = keyIndexColumn.[object_id]
          AND keyColumn.[column_id] = keyIndexColumn.[column_id]
       WHERE applicationSettingPrimaryKey.[object_id] =
             OBJECT_ID(N'[po].[ApplicationSetting]', N'U')
         AND applicationSettingPrimaryKey.[name] = N'PK_PO_ApplicationSetting'
         AND applicationSettingPrimaryKey.[is_primary_key] = 1
         AND applicationSettingPrimaryKey.[is_unique] = 1
         AND applicationSettingPrimaryKey.[type_desc] = N'CLUSTERED'
         AND contextIndexColumn.[key_ordinal] = 1
         AND contextColumn.[name] = N'Context'
         AND keyIndexColumn.[key_ordinal] = 2
         AND keyColumn.[name] = N'Key'
         AND NOT EXISTS
         (
             SELECT 1
             FROM sys.index_columns AS additionalKeyColumn
             WHERE additionalKeyColumn.[object_id] = applicationSettingPrimaryKey.[object_id]
               AND additionalKeyColumn.[index_id] = applicationSettingPrimaryKey.[index_id]
               AND additionalKeyColumn.[key_ordinal] > 2
         )
   )
BEGIN
    ;THROW 51000, 'Existing [po].[ApplicationSetting] contract mismatch: expected clustered primary key [PK_PO_ApplicationSetting] on ([Context], [Key]).', 1;
END;

IF OBJECT_ID(N'[po].[PurchaseOrderCandidateStatus]', N'U') IS NOT NULL
   OR OBJECT_ID(N'[po].[PurchaseOrderBatchStatus]', N'U') IS NOT NULL
   OR OBJECT_ID(N'[po].[PurchaseOrderAttemptStatus]', N'U') IS NOT NULL
   OR OBJECT_ID(N'[po].[PurchaseOrderNotificationStatus]', N'U') IS NOT NULL
BEGIN
    ;THROW 51000, 'Legacy status lookup tables were detected. This package does not perform an in-place migration; a fresh database is required.', 1;
END;

IF OBJECT_ID(N'[po].[PurchaseOrderBatch]', N'U') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM
       (
           VALUES
               (N'BatchKey', N'bigint', CAST(0 AS bit), CAST(1 AS bit)),
               (N'BatchId', N'uniqueidentifier', CAST(0 AS bit), CAST(0 AS bit))
       ) AS expected (ColumnName, TypeName, IsNullable, IsIdentity)
       LEFT JOIN sys.columns AS actualColumn
           ON actualColumn.object_id = OBJECT_ID(N'[po].[PurchaseOrderBatch]', N'U')
          AND actualColumn.name = expected.ColumnName
       LEFT JOIN sys.types AS actualType
           ON actualType.user_type_id = actualColumn.user_type_id
       WHERE actualColumn.column_id IS NULL
          OR actualType.name <> expected.TypeName
          OR actualType.is_user_defined = 1
          OR actualColumn.is_nullable <> expected.IsNullable
          OR actualColumn.is_identity <> expected.IsIdentity
   )
BEGIN
    ;THROW 51000, 'Existing [po].[PurchaseOrderBatch] key contract mismatch: expected [BatchKey] bigint NOT NULL IDENTITY and [BatchId] uniqueidentifier NOT NULL.', 1;
END;

IF OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM
       (
           VALUES
               (N'CandidateKey', N'bigint', CAST(0 AS bit), CAST(1 AS bit)),
               (N'CandidateId', N'uniqueidentifier', CAST(0 AS bit), CAST(0 AS bit)),
               (N'BatchKey', N'bigint', CAST(1 AS bit), CAST(0 AS bit))
       ) AS expected (ColumnName, TypeName, IsNullable, IsIdentity)
       LEFT JOIN sys.columns AS actualColumn
           ON actualColumn.object_id = OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U')
          AND actualColumn.name = expected.ColumnName
       LEFT JOIN sys.types AS actualType
           ON actualType.user_type_id = actualColumn.user_type_id
       WHERE actualColumn.column_id IS NULL
          OR actualType.name <> expected.TypeName
          OR actualType.is_user_defined = 1
          OR actualColumn.is_nullable <> expected.IsNullable
          OR actualColumn.is_identity <> expected.IsIdentity
   )
BEGIN
    ;THROW 51000, 'Existing [po].[PurchaseOrderCandidate] key contract mismatch: expected [CandidateKey] bigint NOT NULL IDENTITY, [CandidateId] uniqueidentifier NOT NULL, and [BatchKey] bigint NULL.', 1;
END;

IF OBJECT_ID(N'[po].[PurchaseOrderSubmissionAttempt]', N'U') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM
       (
           VALUES
               (N'AttemptKey', N'bigint', CAST(0 AS bit), CAST(1 AS bit)),
               (N'AttemptId', N'uniqueidentifier', CAST(0 AS bit), CAST(0 AS bit)),
               (N'CandidateKey', N'bigint', CAST(0 AS bit), CAST(0 AS bit))
       ) AS expected (ColumnName, TypeName, IsNullable, IsIdentity)
       LEFT JOIN sys.columns AS actualColumn
           ON actualColumn.object_id = OBJECT_ID(N'[po].[PurchaseOrderSubmissionAttempt]', N'U')
          AND actualColumn.name = expected.ColumnName
       LEFT JOIN sys.types AS actualType
           ON actualType.user_type_id = actualColumn.user_type_id
       WHERE actualColumn.column_id IS NULL
          OR actualType.name <> expected.TypeName
          OR actualType.is_user_defined = 1
          OR actualColumn.is_nullable <> expected.IsNullable
          OR actualColumn.is_identity <> expected.IsIdentity
   )
BEGIN
    ;THROW 51000, 'Existing [po].[PurchaseOrderSubmissionAttempt] key contract mismatch: expected [AttemptKey] bigint NOT NULL IDENTITY, [AttemptId] uniqueidentifier NOT NULL, and [CandidateKey] bigint NOT NULL.', 1;
END;

IF OBJECT_ID(N'[po].[PurchaseOrderAudit]', N'U') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM
       (
           VALUES
               (N'AuditKey', N'bigint', CAST(0 AS bit), CAST(1 AS bit)),
               (N'CandidateKey', N'bigint', CAST(0 AS bit), CAST(0 AS bit))
       ) AS expected (ColumnName, TypeName, IsNullable, IsIdentity)
       LEFT JOIN sys.columns AS actualColumn
           ON actualColumn.object_id = OBJECT_ID(N'[po].[PurchaseOrderAudit]', N'U')
          AND actualColumn.name = expected.ColumnName
       LEFT JOIN sys.types AS actualType
           ON actualType.user_type_id = actualColumn.user_type_id
       WHERE actualColumn.column_id IS NULL
          OR actualType.name <> expected.TypeName
          OR actualType.is_user_defined = 1
          OR actualColumn.is_nullable <> expected.IsNullable
          OR actualColumn.is_identity <> expected.IsIdentity
   )
BEGIN
    ;THROW 51000, 'Existing [po].[PurchaseOrderAudit] key contract mismatch: expected [AuditKey] bigint NOT NULL IDENTITY and [CandidateKey] bigint NOT NULL.', 1;
END;

IF OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM
       (
           VALUES
               (N'NotificationKey', N'bigint', CAST(0 AS bit), CAST(1 AS bit)),
               (N'NotificationId', N'uniqueidentifier', CAST(0 AS bit), CAST(0 AS bit)),
               (N'BatchKey', N'bigint', CAST(0 AS bit), CAST(0 AS bit))
       ) AS expected (ColumnName, TypeName, IsNullable, IsIdentity)
       LEFT JOIN sys.columns AS actualColumn
           ON actualColumn.object_id = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
          AND actualColumn.name = expected.ColumnName
       LEFT JOIN sys.types AS actualType
           ON actualType.user_type_id = actualColumn.user_type_id
       WHERE actualColumn.column_id IS NULL
          OR actualType.name <> expected.TypeName
          OR actualType.is_user_defined = 1
          OR (actualColumn.is_nullable <> expected.IsNullable
              AND NOT (expected.ColumnName = N'BatchKey'
                  AND actualColumn.is_nullable IN (0, 1)))
          OR actualColumn.is_identity <> expected.IsIdentity
   )
BEGIN
    ;THROW 51000, 'Existing [po].[PurchaseOrderNotification] key contract mismatch: expected [NotificationKey] bigint NOT NULL IDENTITY, [NotificationId] uniqueidentifier NOT NULL, and [BatchKey] bigint with legacy NOT NULL or target NULL nullability.', 1;
END;
