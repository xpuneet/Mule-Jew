SET NOCOUNT ON;
SET XACT_ABORT ON;

-- Additive and rerunnable. Existing batch/candidate and email-outbox rows are untouched.
IF OBJECT_ID(N'[po].[RelexNotificationEvent]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[RelexNotificationEvent]
    (
        [EventKey] nvarchar(100) COLLATE Latin1_General_100_BIN2 NOT NULL,
        [NotificationId] uniqueidentifier NOT NULL,
        [BatchKey] bigint NULL,
        [EventType] varchar(100) NOT NULL,
        [BusinessCorrelationId] nvarchar(256) NOT NULL,
        [OriginalFileName] nvarchar(260) NULL,
        [ProcessedFileDateTime] datetimeoffset(3) NULL,
        [ProcessingCompletedDateTime] datetimeoffset(3) NULL,
        [CreatedDateTime] datetimeoffset(3) NOT NULL,
        [CompositionSettingsJson] nvarchar(max) NOT NULL,
        [OutcomeRowsJson] nvarchar(max) NOT NULL,
        [EmailEnvelopeJson] nvarchar(max) NULL,
        [Status] varchar(50) NOT NULL,
        [FailureCount] int NOT NULL CONSTRAINT [DF_PO_RelexEvent_FailureCount] DEFAULT (0),
        [NextAttemptDateTime] datetimeoffset(3) NOT NULL,
        [LeaseId] uniqueidentifier NULL,
        [LeaseExpiresDateTime] datetimeoffset(3) NULL,
        [CompletedDateTime] datetimeoffset(3) NULL,
        [FailureCode] varchar(100) NULL,
        [RowVersion] rowversion NOT NULL,
        CONSTRAINT [PK_PO_RelexEvent] PRIMARY KEY CLUSTERED ([EventKey]),
        CONSTRAINT [UQ_PO_RelexEvent_NotificationId] UNIQUE NONCLUSTERED ([NotificationId]),
        CONSTRAINT [FK_PO_RelexEvent_Batch] FOREIGN KEY ([BatchKey])
            REFERENCES [po].[PurchaseOrderBatch] ([BatchKey]),
        CONSTRAINT [CK_PO_RelexEvent_Status]
            CHECK ([Status] IN ('PENDING', 'PROCESSING', 'ENQUEUED', 'FAILED')),
        CONSTRAINT [CK_PO_RelexEvent_Identity] CHECK
        (
            ([EventType] = 'RELEX_RESULTS' AND [BatchKey] IS NOT NULL
                AND [OriginalFileName] IS NOT NULL AND [ProcessedFileDateTime] IS NOT NULL
                AND [ProcessingCompletedDateTime] IS NOT NULL)
            OR ([EventType] = 'RELEX_MISSING' AND [BatchKey] IS NULL
                AND [OriginalFileName] IS NULL AND [ProcessedFileDateTime] IS NULL
                AND [ProcessingCompletedDateTime] IS NULL)
        ),
        CONSTRAINT [CK_PO_RelexEvent_Json] CHECK
        (
            ISJSON([CompositionSettingsJson]) = 1 AND DATALENGTH([CompositionSettingsJson]) <= 65536
            AND ISJSON([OutcomeRowsJson]) = 1 AND LEFT(LTRIM([OutcomeRowsJson]), 1) = N'['
            AND DATALENGTH([OutcomeRowsJson]) <= 16 * 1024 * 1024
            AND ([EmailEnvelopeJson] IS NULL OR
                (ISJSON([EmailEnvelopeJson]) = 1 AND DATALENGTH([EmailEnvelopeJson]) <= 20 * 1024 * 1024))
        ),
        CONSTRAINT [CK_PO_RelexEvent_State] CHECK
        (
            [FailureCount] >= 0 AND
            (
                ([Status] = 'PENDING' AND [LeaseId] IS NULL AND [LeaseExpiresDateTime] IS NULL
                    AND [CompletedDateTime] IS NULL)
                OR ([Status] = 'PROCESSING' AND [LeaseId] IS NOT NULL
                    AND [LeaseExpiresDateTime] IS NOT NULL AND [CompletedDateTime] IS NULL)
                OR ([Status] IN ('ENQUEUED', 'FAILED') AND [LeaseId] IS NULL
                    AND [LeaseExpiresDateTime] IS NULL AND [CompletedDateTime] IS NOT NULL
                    AND ([Status] <> 'ENQUEUED' OR [EmailEnvelopeJson] IS NOT NULL))
            )
        ),
        CONSTRAINT [CK_PO_RelexEvent_UtcDateTimes] CHECK
        (
            DATEPART(TZOFFSET, [CreatedDateTime]) = 0
            AND DATEPART(TZOFFSET, [NextAttemptDateTime]) = 0
            AND ([ProcessedFileDateTime] IS NULL OR DATEPART(TZOFFSET, [ProcessedFileDateTime]) = 0)
            AND ([ProcessingCompletedDateTime] IS NULL OR DATEPART(TZOFFSET, [ProcessingCompletedDateTime]) = 0)
            AND ([LeaseExpiresDateTime] IS NULL OR DATEPART(TZOFFSET, [LeaseExpiresDateTime]) = 0)
            AND ([CompletedDateTime] IS NULL OR DATEPART(TZOFFSET, [CompletedDateTime]) = 0)
        )
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[po].[RelexNotificationEvent]')
    AND [name] = N'IX_PO_RelexEvent_DueWork')
    CREATE NONCLUSTERED INDEX [IX_PO_RelexEvent_DueWork]
    ON [po].[RelexNotificationEvent] ([Status], [NextAttemptDateTime], [CreatedDateTime])
    INCLUDE ([LeaseExpiresDateTime]);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[po].[RelexNotificationEvent]')
    AND [name] = N'UX_PO_RelexEvent_Batch')
    CREATE UNIQUE NONCLUSTERED INDEX [UX_PO_RelexEvent_Batch]
    ON [po].[RelexNotificationEvent] ([BatchKey]) WHERE [BatchKey] IS NOT NULL;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'[po].[RelexNotificationEvent]')
    AND [name] = N'IX_PO_RelexEvent_ProcessedFile')
    CREATE NONCLUSTERED INDEX [IX_PO_RelexEvent_ProcessedFile]
    ON [po].[RelexNotificationEvent] ([ProcessedFileDateTime], [ProcessingCompletedDateTime]);
GO
