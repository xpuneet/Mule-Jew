CREATE OR ALTER PROCEDURE [po].[sp_get_application_settings]
    @contextList nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;

    IF @contextList IS NULL
       OR NULLIF(LTRIM(RTRIM(@contextList)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The context list is required.', 1;
    END;

    DECLARE @contextJson nvarchar(max) =
        N'["' + REPLACE(STRING_ESCAPE(@contextList, 'json'), N',', N'","') + N'"]';

    IF EXISTS
    (
        SELECT 1
        FROM OPENJSON(@contextJson)
        WHERE LEN(LTRIM(RTRIM(CONVERT(nvarchar(max), [value])))) > 100
    )
    BEGIN
        ;THROW 51004, 'Each application-settings context must be at most 100 characters.', 1;
    END;

    DECLARE @requestedContexts TABLE
    (
        [Context] nvarchar(100) NOT NULL PRIMARY KEY,
        [ContextOrdinal] int NOT NULL
    );

    INSERT INTO @requestedContexts ([Context], [ContextOrdinal])
    SELECT
        LTRIM(RTRIM(CONVERT(nvarchar(100), [value]))),
        MAX(CONVERT(int, [key]))
    FROM OPENJSON(@contextJson)
    WHERE NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(max), [value]))), N'') IS NOT NULL
    GROUP BY LTRIM(RTRIM(CONVERT(nvarchar(100), [value])));

    IF NOT EXISTS (SELECT 1 FROM @requestedContexts)
    BEGIN
        ;THROW 51004, 'At least one application-settings context is required.', 1;
    END;

    ;WITH rankedSettings AS
    (
        SELECT
            setting.[Key],
            setting.[Value],
            ROW_NUMBER() OVER
            (
                PARTITION BY setting.[Key]
                ORDER BY requested.[ContextOrdinal] DESC
            ) AS [SettingRank]
        FROM [po].[ApplicationSetting] AS setting
        INNER JOIN @requestedContexts AS requested
            ON requested.[Context] = setting.[Context]
    )
    SELECT
        [Key] AS [key],
        [Value] AS [value]
    FROM rankedSettings
    WHERE [SettingRank] = 1
    ORDER BY [Key];
END;
GO

ALTER AUTHORIZATION ON OBJECT::[po].[sp_get_application_settings] TO SCHEMA OWNER;
GO

CREATE OR ALTER PROCEDURE [po].[sp_create_purchase_order_candidate]
    @candidateId uniqueidentifier,
    @account nvarchar(50),
    @branch nvarchar(20),
    @reference nvarchar(100) = NULL,
    @status varchar(50),
    @acceptedDateTime datetimeoffset(3),
    @payloadJson nvarchar(max),
    @actor nvarchar(256)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    IF @account IS NULL
       OR NULLIF(LTRIM(RTRIM(@account)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The account is required.', 1;
    END;

    IF @branch IS NULL
       OR NULLIF(LTRIM(RTRIM(@branch)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The branch is required.', 1;
    END;

    IF @status IS NULL
       OR NULLIF(LTRIM(RTRIM(@status)), '') IS NULL
    BEGIN
        ;THROW 51004, 'The status is required.', 1;
    END;

    IF @acceptedDateTime IS NULL
       OR DATEPART(TZOFFSET, @acceptedDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The accepted timestamp must use the UTC offset.', 1;
    END;

    IF @payloadJson IS NULL
       OR ISJSON(@payloadJson, OBJECT) <> 1
    BEGIN
        ;THROW 51004, 'The payload must be a JSON object.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM OPENJSON(@payloadJson) AS jsonProperty
        WHERE jsonProperty.[key] COLLATE Latin1_General_100_BIN2 = N'candidateStatus'
    )
    BEGIN
        ;THROW 51004, 'The payload must not contain candidateStatus.', 1;
    END;

    IF @status NOT IN
       (
           'DRAFT',
           'READY_FOR_SUBMISSION',
           'SUBMISSION_IN_PROGRESS',
           'RECOVERABLE_ERROR',
           'NON_RECOVERABLE_ERROR',
           'RETRY_REQUESTED',
           'COMPLETED',
           'CANCELLED'
       )
    BEGIN
        ;THROW 51004, 'The candidate status is invalid.', 1;
    END;

    DECLARE @candidateKey bigint;

    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO [po].[PurchaseOrderCandidate]
        (
            [CandidateId],
            [BatchKey],
            [Source],
            [Kind],
            [SourceRowCount],
            [Account],
            [Branch],
            [Reference],
            [IconPurchaseOrderNumber],
            [Status],
            [StatusDateTime],
            [StatusReason],
            [ProcessBatchNo],
            [PayloadMD5],
            [MessageCode],
            [MessageDescription],
            [PreviousMessageCode],
            [PreviousMessageDescription],
            [PayloadJson],
            [AcceptedDateTime],
            [CreatedDateTime],
            [UpdatedDateTime],
            [RefreshDateTime],
            [PendingRetriesCount],
            [ProcessingRetriesCount],
            [LeaseToken],
            [LeaseOwner],
            [LeaseAcquiredDateTime],
            [LeaseExpiresDateTime]
        )
        VALUES
        (
            @candidateId,
            NULL,
            N'API',
            'API',
            NULL,
            @account,
            @branch,
            @reference,
            NULL,
            @status,
            @acceptedDateTime,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            @payloadJson,
            @acceptedDateTime,
            @acceptedDateTime,
            @acceptedDateTime,
            @acceptedDateTime,
            0,
            0,
            NULL,
            NULL,
            NULL,
            NULL
        );

        SET @candidateKey = CONVERT(bigint, SCOPE_IDENTITY());

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            'CREATE',
            'API',
            @actor,
            NULL,
            NULL,
            @status,
            NULL,
            @payloadJson,
            NULL,
            @candidateId,
            @acceptedDateTime
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_search_purchase_order_candidates]
    @source nvarchar(50),
    @account nvarchar(50) = NULL,
    @branch nvarchar(20) = NULL,
    @reference nvarchar(100) = NULL,
    @iconPurchaseOrderNumber nvarchar(100) = NULL,
    @status varchar(50) = NULL,
    @acceptedAfterDateTimeUtc datetimeoffset(3) = NULL,
    @acceptedUntilDateTimeUtc datetimeoffset(3) = NULL,
    @pageNumber int,
    @pageSize int
AS
BEGIN
    SET NOCOUNT ON;

    IF @source IS NULL
       OR NULLIF(LTRIM(RTRIM(@source)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The source is required.', 1;
    END;

    IF @pageNumber IS NULL OR @pageNumber < 1
    BEGIN
        ;THROW 51004, 'The page number must be at least one.', 1;
    END;

    IF @pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50
    BEGIN
        ;THROW 51004, 'The page size must be between one and fifty.', 1;
    END;

    IF @status IS NOT NULL
       AND @status NOT IN
       (
           'DRAFT',
           'READY_FOR_SUBMISSION',
           'SUBMISSION_IN_PROGRESS',
           'RECOVERABLE_ERROR',
           'NON_RECOVERABLE_ERROR',
           'RETRY_REQUESTED',
           'COMPLETED',
           'CANCELLED'
       )
    BEGIN
        ;THROW 51004, 'The candidate status is invalid.', 1;
    END;

    IF (@acceptedAfterDateTimeUtc IS NOT NULL
        AND DATEPART(TZOFFSET, @acceptedAfterDateTimeUtc) <> 0)
       OR (@acceptedUntilDateTimeUtc IS NOT NULL
           AND DATEPART(TZOFFSET, @acceptedUntilDateTimeUtc) <> 0)
    BEGIN
        ;THROW 51004, 'The accepted timestamps must use the UTC offset.', 1;
    END;

    IF @acceptedAfterDateTimeUtc IS NOT NULL
       AND @acceptedUntilDateTimeUtc IS NOT NULL
       AND @acceptedAfterDateTimeUtc >= @acceptedUntilDateTimeUtc
    BEGIN
        ;THROW 51004, 'The accepted start must be before the end.', 1;
    END;

    DECLARE @offset bigint =
        (CONVERT(bigint, @pageNumber) - 1) * CONVERT(bigint, @pageSize);

    SELECT
        [CandidateId],
        [Source],
        [Account],
        [Branch],
        [Reference],
        [IconPurchaseOrderNumber],
        [Status],
        [AcceptedDateTime]
    FROM [po].[PurchaseOrderCandidate] AS [candidate]
    WHERE [candidate].[Source] = @source
      AND (@account IS NULL OR [candidate].[Account] = @account)
      AND (@branch IS NULL OR [candidate].[Branch] = @branch)
      AND (@reference IS NULL OR [candidate].[Reference] = @reference)
      AND (@iconPurchaseOrderNumber IS NULL
           OR [candidate].[IconPurchaseOrderNumber] = @iconPurchaseOrderNumber)
      AND (@status IS NULL OR [candidate].[Status] = @status)
      AND (@acceptedAfterDateTimeUtc IS NULL
           OR [candidate].[AcceptedDateTime] >= @acceptedAfterDateTimeUtc)
      AND (@acceptedUntilDateTimeUtc IS NULL
           OR [candidate].[AcceptedDateTime] < @acceptedUntilDateTimeUtc)
    ORDER BY [AcceptedDateTime] DESC, [CandidateId]
    OFFSET @offset ROWS
    FETCH NEXT @pageSize ROWS ONLY;
END;
GO
