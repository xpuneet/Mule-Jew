CREATE OR ALTER PROCEDURE [po].[sp_begin_purchase_order_submission_attempt]
    @attemptId uniqueidentifier,
    @candidateId uniqueidentifier,
    @leaseToken uniqueidentifier,
    @workerId nvarchar(256),
    @requestPayloadJson nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @attemptId IS NULL
    BEGIN
        ;THROW 51004, 'The submission attempt identifier is required.', 1;
    END;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @leaseToken IS NULL
    BEGIN
        ;THROW 51004, 'The lease token is required.', 1;
    END;

    IF @workerId IS NULL
       OR NULLIF(LTRIM(RTRIM(@workerId)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The worker identifier is required.', 1;
    END;

    IF @requestPayloadJson IS NULL
       OR ISJSON(@requestPayloadJson, OBJECT) <> 1
    BEGIN
        ;THROW 51004, 'The ICON request payload must be one JSON object.', 1;
    END;

    DECLARE @now datetimeoffset(3);
    DECLARE @candidateKey bigint;
    DECLARE @candidateStatus varchar(50);
    DECLARE @currentLeaseToken uniqueidentifier;
    DECLARE @currentLeaseOwner nvarchar(256);
    DECLARE @currentLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @attemptNumber int;
    DECLARE @dispatchedAttempt TABLE
    (
        [AttemptId] uniqueidentifier NOT NULL,
        [AttemptNumber] int NOT NULL,
        [Status] varchar(50) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();

        SELECT
            @candidateKey = [CandidateKey],
            @candidateStatus = [Status],
            @currentLeaseToken = [LeaseToken],
            @currentLeaseOwner = [LeaseOwner],
            @currentLeaseExpiresDateTime = [LeaseExpiresDateTime]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @currentLeaseToken IS NULL
           OR @currentLeaseToken <> @leaseToken
           OR @currentLeaseOwner IS NULL
           OR @currentLeaseOwner <> @workerId
           OR @currentLeaseExpiresDateTime IS NULL
           OR @currentLeaseExpiresDateTime <= @now
        BEGIN
            ;THROW 51003, 'The purchase order claim is missing, expired, or does not match.', 1;
        END;

        IF @candidateStatus NOT IN ('READY_FOR_SUBMISSION', 'RETRY_REQUESTED')
        BEGIN
            ;THROW 51004, 'The purchase order candidate is not eligible for dispatch.', 1;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM [po].[PurchaseOrderSubmissionAttempt] WITH (UPDLOCK, HOLDLOCK)
            WHERE [CandidateKey] = @candidateKey
              AND [ClaimToken] = @leaseToken
              AND [Status] = 'DISPATCHED'
              AND [CompletedDateTime] IS NULL
        )
        BEGIN
            ;THROW 51004, 'The current purchase order claim already has an unresolved submission attempt.', 1;
        END;

        SELECT
            @attemptNumber = ISNULL(MAX([AttemptNumber]), 0) + 1
        FROM [po].[PurchaseOrderSubmissionAttempt] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateKey] = @candidateKey;

        INSERT INTO [po].[PurchaseOrderSubmissionAttempt]
        (
            [AttemptId],
            [CandidateKey],
            [AttemptNumber],
            [ClaimToken],
            [Status],
            [RequestPayloadJson],
            [ResponsePayloadJson],
            [HttpStatusCode],
            [IconPurchaseOrderNumber],
            [IconCreatedStatus],
            [IconSuspended],
            [IconSuspendMessage],
            [FailureCategory],
            [MessageCode],
            [MessageDescription],
            [PreparedDateTime],
            [DispatchedDateTime],
            [CompletedDateTime],
            [CreatedBy]
        )
        OUTPUT
            inserted.[AttemptId],
            inserted.[AttemptNumber],
            inserted.[Status]
        INTO @dispatchedAttempt
        VALUES
        (
            @attemptId,
            @candidateKey,
            @attemptNumber,
            @leaseToken,
            'DISPATCHED',
            @requestPayloadJson,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            @now,
            @now,
            NULL,
            @workerId
        );

        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [Status] = 'SUBMISSION_IN_PROGRESS',
            [StatusDateTime] = @now,
            [StatusReason] = NULL,
            [UpdatedDateTime] = @now,
            [RefreshDateTime] = @now
        WHERE [CandidateKey] = @candidateKey;

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            'ATTEMPT_DISPATCHED',
            'PROCESSOR',
            @workerId,
            NULL,
            @candidateStatus,
            'SUBMISSION_IN_PROGRESS',
            NULL,
            NULL,
            NULL,
            @attemptId,
            @now
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [AttemptId],
        [AttemptNumber],
        [Status]
    FROM @dispatchedAttempt;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_fail_purchase_order_candidate_pre_dispatch]
    @candidateId uniqueidentifier,
    @leaseToken uniqueidentifier,
    @workerId nvarchar(256),
    @candidateStatus varchar(50),
    @failureCategory varchar(100),
    @messageCode nvarchar(100) = NULL,
    @messageDescription nvarchar(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @leaseToken IS NULL
    BEGIN
        ;THROW 51004, 'The lease token is required.', 1;
    END;

    IF @workerId IS NULL
       OR NULLIF(LTRIM(RTRIM(@workerId)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The worker identifier is required.', 1;
    END;

    IF @candidateStatus IS NULL
       OR @candidateStatus NOT IN ('RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR')
    BEGIN
        ;THROW 51004, 'The pre-dispatch failure candidate status is invalid.', 1;
    END;

    IF @failureCategory IS NULL
       OR NULLIF(LTRIM(RTRIM(@failureCategory)), '') IS NULL
    BEGIN
        ;THROW 51004, 'The failure category is required.', 1;
    END;

    DECLARE @now datetimeoffset(3);
    DECLARE @candidateKey bigint;
    DECLARE @currentCandidateStatus varchar(50);
    DECLARE @currentLeaseToken uniqueidentifier;
    DECLARE @currentLeaseOwner nvarchar(256);
    DECLARE @currentLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @statusReason nvarchar(1000) =
        COALESCE(NULLIF(@messageDescription, N''), @failureCategory);
    DECLARE @failedCandidate TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();

        SELECT
            @candidateKey = [CandidateKey],
            @currentCandidateStatus = [Status],
            @currentLeaseToken = [LeaseToken],
            @currentLeaseOwner = [LeaseOwner],
            @currentLeaseExpiresDateTime = [LeaseExpiresDateTime]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @currentLeaseToken IS NULL
           OR @currentLeaseToken <> @leaseToken
           OR @currentLeaseOwner IS NULL
           OR @currentLeaseOwner <> @workerId
           OR @currentLeaseExpiresDateTime IS NULL
           OR @currentLeaseExpiresDateTime <= @now
        BEGIN
            ;THROW 51003, 'The purchase order claim is missing, expired, or does not match.', 1;
        END;

        IF @currentCandidateStatus NOT IN ('READY_FOR_SUBMISSION', 'RETRY_REQUESTED')
        BEGIN
            ;THROW 51004, 'The purchase order candidate is not eligible for a pre-dispatch failure.', 1;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM [po].[PurchaseOrderSubmissionAttempt] WITH (UPDLOCK, HOLDLOCK)
            WHERE [CandidateKey] = @candidateKey
              AND [Status] = 'DISPATCHED'
              AND [CompletedDateTime] IS NULL
        )
        BEGIN
            ;THROW 51004, 'A dispatched purchase order attempt requires post-dispatch outcome handling.', 1;
        END;

        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [Status] = @candidateStatus,
            [StatusDateTime] = @now,
            [StatusReason] = @statusReason,
            [PreviousMessageCode] = [MessageCode],
            [PreviousMessageDescription] = [MessageDescription],
            [MessageCode] = @messageCode,
            [MessageDescription] = @messageDescription,
            [UpdatedDateTime] = @now,
            [RefreshDateTime] = @now,
            [LeaseToken] = NULL,
            [LeaseOwner] = NULL,
            [LeaseAcquiredDateTime] = NULL,
            [LeaseExpiresDateTime] = NULL
        OUTPUT
            inserted.[CandidateId],
            inserted.[Status],
            inserted.[RowVersion]
        INTO @failedCandidate
        WHERE [CandidateKey] = @candidateKey;

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            'SUBMISSION_FAILED_BEFORE_DISPATCH',
            'PROCESSOR',
            @workerId,
            @statusReason,
            @currentCandidateStatus,
            @candidateStatus,
            NULL,
            NULL,
            NULL,
            @leaseToken,
            @now
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [Status],
        [RowVersion]
    FROM @failedCandidate;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_complete_purchase_order_submission]
    @attemptId uniqueidentifier,
    @candidateId uniqueidentifier,
    @leaseToken uniqueidentifier,
    @workerId nvarchar(256),
    @iconPurchaseOrderNumber nvarchar(100),
    @iconCreatedStatus varchar(50),
    @iconSuspended bit,
    @iconSuspendMessage nvarchar(1000) = NULL,
    @responsePayloadJson nvarchar(max) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @attemptId IS NULL
    BEGIN
        ;THROW 51004, 'The submission attempt identifier is required.', 1;
    END;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @leaseToken IS NULL
    BEGIN
        ;THROW 51004, 'The lease token is required.', 1;
    END;

    IF @workerId IS NULL
       OR NULLIF(LTRIM(RTRIM(@workerId)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The worker identifier is required.', 1;
    END;

    IF @iconPurchaseOrderNumber IS NULL
       OR NULLIF(LTRIM(RTRIM(@iconPurchaseOrderNumber)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The ICON purchase order number is required.', 1;
    END;

    IF @iconCreatedStatus IS NULL
       OR @iconCreatedStatus NOT IN ('activated', 'notactivated', 'received', 'undefined')
    BEGIN
        ;THROW 51004, 'The ICON created status is invalid.', 1;
    END;

    IF @iconSuspended IS NULL
    BEGIN
        ;THROW 51004, 'The ICON suspended flag is required.', 1;
    END;

    IF @responsePayloadJson IS NOT NULL
       AND ISJSON(@responsePayloadJson) <> 1
    BEGIN
        ;THROW 51004, 'The ICON response payload must be valid JSON when supplied.', 1;
    END;

    DECLARE @now datetimeoffset(3);
    DECLARE @candidateKey bigint;
    DECLARE @candidateStatus varchar(50);
    DECLARE @currentLeaseToken uniqueidentifier;
    DECLARE @currentLeaseOwner nvarchar(256);
    DECLARE @currentLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @attemptKey bigint;
    DECLARE @attemptCandidateKey bigint;
    DECLARE @attemptClaimToken uniqueidentifier;
    DECLARE @attemptStatus varchar(50);
    DECLARE @attemptCompletedDateTime datetimeoffset(3);
    DECLARE @completedCandidate TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NOT NULL,
        [CandidateRowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();

        SELECT
            @candidateKey = [CandidateKey],
            @candidateStatus = [Status],
            @currentLeaseToken = [LeaseToken],
            @currentLeaseOwner = [LeaseOwner],
            @currentLeaseExpiresDateTime = [LeaseExpiresDateTime]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @currentLeaseToken IS NULL
           OR @currentLeaseToken <> @leaseToken
           OR @currentLeaseOwner IS NULL
           OR @currentLeaseOwner <> @workerId
           OR @currentLeaseExpiresDateTime IS NULL
           OR @currentLeaseExpiresDateTime <= @now
        BEGIN
            ;THROW 51003, 'The purchase order claim is missing, expired, or does not match.', 1;
        END;

        IF @candidateStatus <> 'SUBMISSION_IN_PROGRESS'
        BEGIN
            ;THROW 51004, 'The purchase order candidate is not awaiting a submission outcome.', 1;
        END;

        SELECT
            @attemptKey = [AttemptKey],
            @attemptCandidateKey = [CandidateKey],
            @attemptClaimToken = [ClaimToken],
            @attemptStatus = [Status],
            @attemptCompletedDateTime = [CompletedDateTime]
        FROM [po].[PurchaseOrderSubmissionAttempt] WITH (UPDLOCK, HOLDLOCK)
        WHERE [AttemptId] = @attemptId;

        IF @attemptKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order submission attempt was not found.', 1;
        END;

        IF @attemptCandidateKey <> @candidateKey
           OR @attemptClaimToken <> @leaseToken
           OR @attemptStatus <> 'DISPATCHED'
           OR @attemptCompletedDateTime IS NOT NULL
        BEGIN
            ;THROW 51004, 'The purchase order submission attempt cannot be completed.', 1;
        END;

        UPDATE [po].[PurchaseOrderSubmissionAttempt]
        SET
            [Status] = 'SUCCEEDED',
            [ResponsePayloadJson] = @responsePayloadJson,
            [HttpStatusCode] = NULL,
            [IconPurchaseOrderNumber] = @iconPurchaseOrderNumber,
            [IconCreatedStatus] = @iconCreatedStatus,
            [IconSuspended] = @iconSuspended,
            [IconSuspendMessage] = @iconSuspendMessage,
            [FailureCategory] = NULL,
            [MessageCode] = NULL,
            [MessageDescription] = NULL,
            [CompletedDateTime] = @now
        WHERE [AttemptKey] = @attemptKey;

        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [Status] = 'COMPLETED',
            [IconPurchaseOrderNumber] = @iconPurchaseOrderNumber,
            [StatusDateTime] = @now,
            [StatusReason] = NULL,
            [PreviousMessageCode] = [MessageCode],
            [PreviousMessageDescription] = [MessageDescription],
            [MessageCode] = NULL,
            [MessageDescription] = NULL,
            [UpdatedDateTime] = @now,
            [RefreshDateTime] = @now,
            [LeaseToken] = NULL,
            [LeaseOwner] = NULL,
            [LeaseAcquiredDateTime] = NULL,
            [LeaseExpiresDateTime] = NULL
        OUTPUT
            inserted.[CandidateId],
            inserted.[Status],
            inserted.[IconPurchaseOrderNumber],
            inserted.[RowVersion]
        INTO @completedCandidate
        WHERE [CandidateKey] = @candidateKey;

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            'SUBMISSION_SUCCEEDED',
            'PROCESSOR',
            @workerId,
            NULL,
            'SUBMISSION_IN_PROGRESS',
            'COMPLETED',
            NULL,
            NULL,
            NULL,
            @attemptId,
            @now
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [Status],
        [IconPurchaseOrderNumber],
        @attemptId AS [AttemptId],
        'SUCCEEDED' AS [AttemptStatus],
        [CandidateRowVersion]
    FROM @completedCandidate;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_fail_purchase_order_submission]
    @attemptId uniqueidentifier,
    @candidateId uniqueidentifier,
    @leaseToken uniqueidentifier,
    @workerId nvarchar(256),
    @candidateStatus varchar(50),
    @failureCategory varchar(100),
    @messageCode nvarchar(100) = NULL,
    @messageDescription nvarchar(1000) = NULL,
    @httpStatusCode smallint = NULL,
    @responsePayloadJson nvarchar(max) = NULL,
    @attemptStatus varchar(50)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @attemptId IS NULL
    BEGIN
        ;THROW 51004, 'The submission attempt identifier is required.', 1;
    END;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @leaseToken IS NULL
    BEGIN
        ;THROW 51004, 'The lease token is required.', 1;
    END;

    IF @workerId IS NULL
       OR NULLIF(LTRIM(RTRIM(@workerId)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The worker identifier is required.', 1;
    END;

    IF @candidateStatus IS NULL
       OR @candidateStatus NOT IN ('RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR')
    BEGIN
        ;THROW 51004, 'The failure candidate status is invalid.', 1;
    END;

    IF @failureCategory IS NULL
       OR NULLIF(LTRIM(RTRIM(@failureCategory)), '') IS NULL
    BEGIN
        ;THROW 51004, 'The failure category is required.', 1;
    END;

    IF @httpStatusCode IS NOT NULL
       AND @httpStatusCode NOT BETWEEN 100 AND 599
    BEGIN
        ;THROW 51004, 'The HTTP status code must be between 100 and 599 when supplied.', 1;
    END;

    IF @responsePayloadJson IS NOT NULL
       AND ISJSON(@responsePayloadJson) <> 1
    BEGIN
        ;THROW 51004, 'The ICON response payload must be valid JSON when supplied.', 1;
    END;

    IF @attemptStatus IS NULL
       OR @attemptStatus NOT IN ('FAILED', 'UNKNOWN_OUTCOME')
    BEGIN
        ;THROW 51004, 'The submission attempt failure status is invalid.', 1;
    END;

    IF @attemptStatus = 'UNKNOWN_OUTCOME'
       AND @candidateStatus <> 'NON_RECOVERABLE_ERROR'
    BEGIN
        ;THROW 51004, 'An unknown submission outcome must be non-recoverable.', 1;
    END;

    DECLARE @auditAction varchar(100) =
        CASE WHEN @attemptStatus = 'UNKNOWN_OUTCOME' THEN 'SUBMISSION_UNKNOWN_OUTCOME' ELSE 'SUBMISSION_FAILED' END;
    DECLARE @statusReason nvarchar(1000) =
        COALESCE(NULLIF(@messageDescription, N''), @failureCategory);
    DECLARE @now datetimeoffset(3);
    DECLARE @candidateKey bigint;
    DECLARE @candidateCurrentStatus varchar(50);
    DECLARE @currentLeaseToken uniqueidentifier;
    DECLARE @currentLeaseOwner nvarchar(256);
    DECLARE @currentLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @attemptKey bigint;
    DECLARE @attemptCandidateKey bigint;
    DECLARE @attemptClaimToken uniqueidentifier;
    DECLARE @attemptCurrentStatus varchar(50);
    DECLARE @attemptCompletedDateTime datetimeoffset(3);
    DECLARE @failedCandidate TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NULL,
        [CandidateRowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();

        SELECT
            @candidateKey = [CandidateKey],
            @candidateCurrentStatus = [Status],
            @currentLeaseToken = [LeaseToken],
            @currentLeaseOwner = [LeaseOwner],
            @currentLeaseExpiresDateTime = [LeaseExpiresDateTime]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @currentLeaseToken IS NULL
           OR @currentLeaseToken <> @leaseToken
           OR @currentLeaseOwner IS NULL
           OR @currentLeaseOwner <> @workerId
           OR @currentLeaseExpiresDateTime IS NULL
           OR @currentLeaseExpiresDateTime <= @now
        BEGIN
            ;THROW 51003, 'The purchase order claim is missing, expired, or does not match.', 1;
        END;

        IF @candidateCurrentStatus <> 'SUBMISSION_IN_PROGRESS'
        BEGIN
            ;THROW 51004, 'The purchase order candidate is not awaiting a submission outcome.', 1;
        END;

        SELECT
            @attemptKey = [AttemptKey],
            @attemptCandidateKey = [CandidateKey],
            @attemptClaimToken = [ClaimToken],
            @attemptCurrentStatus = [Status],
            @attemptCompletedDateTime = [CompletedDateTime]
        FROM [po].[PurchaseOrderSubmissionAttempt] WITH (UPDLOCK, HOLDLOCK)
        WHERE [AttemptId] = @attemptId;

        IF @attemptKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order submission attempt was not found.', 1;
        END;

        IF @attemptCandidateKey <> @candidateKey
           OR @attemptClaimToken <> @leaseToken
           OR @attemptCurrentStatus <> 'DISPATCHED'
           OR @attemptCompletedDateTime IS NOT NULL
        BEGIN
            ;THROW 51004, 'The purchase order submission attempt cannot be failed.', 1;
        END;

        UPDATE [po].[PurchaseOrderSubmissionAttempt]
        SET
            [Status] = @attemptStatus,
            [ResponsePayloadJson] = @responsePayloadJson,
            [HttpStatusCode] = @httpStatusCode,
            [FailureCategory] = @failureCategory,
            [MessageCode] = @messageCode,
            [MessageDescription] = @messageDescription,
            [CompletedDateTime] = @now
        WHERE [AttemptKey] = @attemptKey;

        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [Status] = @candidateStatus,
            [StatusDateTime] = @now,
            [StatusReason] = @statusReason,
            [PreviousMessageCode] = [MessageCode],
            [PreviousMessageDescription] = [MessageDescription],
            [MessageCode] = @messageCode,
            [MessageDescription] = @messageDescription,
            [UpdatedDateTime] = @now,
            [RefreshDateTime] = @now,
            [LeaseToken] = NULL,
            [LeaseOwner] = NULL,
            [LeaseAcquiredDateTime] = NULL,
            [LeaseExpiresDateTime] = NULL
        OUTPUT
            inserted.[CandidateId],
            inserted.[Status],
            inserted.[IconPurchaseOrderNumber],
            inserted.[RowVersion]
        INTO @failedCandidate
        WHERE [CandidateKey] = @candidateKey;

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            @auditAction,
            'PROCESSOR',
            @workerId,
            @statusReason,
            'SUBMISSION_IN_PROGRESS',
            @candidateStatus,
            NULL,
            NULL,
            NULL,
            @attemptId,
            @now
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [Status],
        [IconPurchaseOrderNumber],
        @attemptId AS [AttemptId],
        @attemptStatus AS [AttemptStatus],
        [CandidateRowVersion]
    FROM @failedCandidate;
END;
GO
