SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [Status] IN ('READY_FOR_SUBMISSION', 'RETRY_REQUESTED')
      AND [LeaseToken] IS NULL
)
BEGIN
    ;THROW 52050, 'Attempt acceptance tests require an isolated database with no pre-existing claimable candidates.', 1;
END;

DECLARE @attemptPayload nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-ATTEMPT","branch":401,"reference":"SYNTHETIC-ATTEMPT"},"purchaseOrderLines":[]}';

-- SCENARIO:ATTEMPT_BEGIN_DISPATCH
DECLARE @successCandidateId uniqueidentifier = 'A4000000-0000-4000-8000-000000000001';
DECLARE @successAttemptId uniqueidentifier = 'A4000000-0000-4000-8000-000000000002';
DECLARE @successClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @dispatchedSuccess TABLE
(
    [AttemptId] uniqueidentifier NOT NULL,
    [AttemptNumber] int NOT NULL,
    [Status] varchar(50) NOT NULL
);
DECLARE @completedSuccess TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [IconPurchaseOrderNumber] nvarchar(100) NULL,
    [AttemptId] uniqueidentifier NOT NULL,
    [AttemptStatus] varchar(50) NOT NULL,
    [CandidateRowVersion] binary(8) NOT NULL
);
DECLARE @successLeaseToken uniqueidentifier;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @successCandidateId,
        @account = N'SYNTHETIC-ATTEMPT',
        @branch = N'401',
        @reference = N'SYNTHETIC-SUCCESS',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-04-01T00:00:00.000+00:00',
        @payloadJson = @attemptPayload,
        @actor = N'acceptance-api';

    INSERT INTO @successClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-attempt-worker',
        @maxCandidates = 1,
        @leaseDurationSeconds = 600;

    SELECT @successLeaseToken = [LeaseToken]
    FROM @successClaims
    WHERE [CandidateId] = @successCandidateId;

    INSERT INTO @dispatchedSuccess
    EXEC [po].[sp_begin_purchase_order_submission_attempt]
        @attemptId = @successAttemptId,
        @candidateId = @successCandidateId,
        @leaseToken = @successLeaseToken,
        @workerId = N'acceptance-attempt-worker',
        @requestPayloadJson = N'{"syntheticRequest":"success"}';

    IF NOT EXISTS
       (
           SELECT 1
           FROM @dispatchedSuccess
           WHERE [AttemptId] = @successAttemptId
             AND [AttemptNumber] = 1
             AND [Status] = 'DISPATCHED'
       )
       OR NOT EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderCandidate]
           WHERE [CandidateId] = @successCandidateId
             AND [Status] = 'SUBMISSION_IN_PROGRESS'
             AND [PayloadJson] = @attemptPayload
       )
    BEGIN
        ;THROW 52051, 'Dispatch attempt and candidate transition were not persisted atomically.', 1;
    END;

    INSERT INTO @completedSuccess
    EXEC [po].[sp_complete_purchase_order_submission]
        @attemptId = @successAttemptId,
        @candidateId = @successCandidateId,
        @leaseToken = @successLeaseToken,
        @workerId = N'acceptance-attempt-worker',
        @iconPurchaseOrderNumber = N'SYNTHETIC-ICON-PO-401',
        @iconCreatedStatus = 'received',
        @iconSuspended = 0,
        @iconSuspendMessage = NULL,
        @responsePayloadJson = N'{"syntheticResponse":"success"}';

    IF NOT EXISTS
    (
        SELECT 1
        FROM @completedSuccess
        WHERE [CandidateId] = @successCandidateId
          AND [Status] = 'COMPLETED'
          AND [AttemptId] = @successAttemptId
          AND [AttemptStatus] = 'SUCCEEDED'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @successCandidateId
          AND [Status] = 'COMPLETED'
          AND [PayloadJson] = @attemptPayload
          AND [LeaseToken] IS NULL
    )
    BEGIN
        ;THROW 52053, 'Successful outcome was not persisted atomically.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

PRINT 'PASS:SCENARIO:ATTEMPT_BEGIN_DISPATCH';

-- SCENARIO:UNKNOWN_OUTCOME_NOT_ELIGIBLE
DECLARE @unknownCandidateId uniqueidentifier = 'A4000000-0000-4000-8000-000000000010';
DECLARE @unknownAttemptId uniqueidentifier = 'A4000000-0000-4000-8000-000000000011';
DECLARE @unknownClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @postUnknownClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @dispatchedUnknown TABLE
(
    [AttemptId] uniqueidentifier NOT NULL,
    [AttemptNumber] int NOT NULL,
    [Status] varchar(50) NOT NULL
);
DECLARE @unknownOutcomeResult TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [IconPurchaseOrderNumber] nvarchar(100) NULL,
    [AttemptId] uniqueidentifier NOT NULL,
    [AttemptStatus] varchar(50) NOT NULL,
    [CandidateRowVersion] binary(8) NOT NULL
);
DECLARE @unknownLeaseToken uniqueidentifier;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @unknownCandidateId,
        @account = N'SYNTHETIC-ATTEMPT',
        @branch = N'401',
        @reference = N'SYNTHETIC-UNKNOWN',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-04-02T00:00:00.000+00:00',
        @payloadJson = @attemptPayload,
        @actor = N'acceptance-api';

    INSERT INTO @unknownClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-unknown-worker',
        @maxCandidates = 1,
        @leaseDurationSeconds = 600;

    SELECT @unknownLeaseToken = [LeaseToken]
    FROM @unknownClaims
    WHERE [CandidateId] = @unknownCandidateId;

    INSERT INTO @dispatchedUnknown
    EXEC [po].[sp_begin_purchase_order_submission_attempt]
        @attemptId = @unknownAttemptId,
        @candidateId = @unknownCandidateId,
        @leaseToken = @unknownLeaseToken,
        @workerId = N'acceptance-unknown-worker',
        @requestPayloadJson = N'{"syntheticRequest":"unknown"}';

    INSERT INTO @unknownOutcomeResult
    EXEC [po].[sp_fail_purchase_order_submission]
        @attemptId = @unknownAttemptId,
        @candidateId = @unknownCandidateId,
        @leaseToken = @unknownLeaseToken,
        @workerId = N'acceptance-unknown-worker',
        @candidateStatus = 'NON_RECOVERABLE_ERROR',
        @failureCategory = 'SYNTHETIC_UNKNOWN_OUTCOME',
        @messageCode = N'SYNTHETIC_UNKNOWN',
        @messageDescription = N'Synthetic unknown outcome acceptance scenario.',
        @httpStatusCode = NULL,
        @responsePayloadJson = NULL,
        @attemptStatus = 'UNKNOWN_OUTCOME';

    IF NOT EXISTS
    (
        SELECT 1
        FROM @unknownOutcomeResult
        WHERE [CandidateId] = @unknownCandidateId
          AND [Status] = 'NON_RECOVERABLE_ERROR'
          AND [AttemptId] = @unknownAttemptId
          AND [AttemptStatus] = 'UNKNOWN_OUTCOME'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderSubmissionAttempt]
        WHERE [AttemptId] = @unknownAttemptId
          AND [Status] = 'UNKNOWN_OUTCOME'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @unknownCandidateId
          AND [Status] = 'NON_RECOVERABLE_ERROR'
          AND [LeaseToken] IS NULL
          AND [PayloadJson] = @attemptPayload
    )
    BEGIN
        ;THROW 52054, 'Unknown outcome did not force non-recoverable durable state.', 1;
    END;

    INSERT INTO @postUnknownClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-post-unknown-worker',
        @maxCandidates = 1,
        @leaseDurationSeconds = 60;

    IF EXISTS
    (
        SELECT 1
        FROM @postUnknownClaims
        WHERE [CandidateId] = @unknownCandidateId
    )
    BEGIN
        ;THROW 52055, 'UNKNOWN_OUTCOME candidate became automatically eligible.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] IN (@successCandidateId, @unknownCandidateId)
)
BEGIN
    ;THROW 52056, 'Attempt outcome acceptance cleanup did not roll back synthetic data.', 1;
END;

PRINT 'PASS:SCENARIO:UNKNOWN_OUTCOME_NOT_ELIGIBLE';

-- SCENARIO:PREDISPATCH_FAILURE_TERMINAL
DECLARE @preDispatchCandidateId uniqueidentifier = 'A4000000-0000-4000-8000-000000000020';
DECLARE @preDispatchClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @postPreDispatchClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @preDispatchFailure TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @preDispatchLeaseToken uniqueidentifier;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @preDispatchCandidateId,
        @account = N'SYNTHETIC-ATTEMPT',
        @branch = N'401',
        @reference = N'SYNTHETIC-PREDISPATCH',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-04-03T00:00:00.000+00:00',
        @payloadJson = @attemptPayload,
        @actor = N'acceptance-api';

    INSERT INTO @preDispatchClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-predispatch-worker',
        @maxCandidates = 1,
        @leaseDurationSeconds = 600;

    SELECT @preDispatchLeaseToken = [LeaseToken]
    FROM @preDispatchClaims
    WHERE [CandidateId] = @preDispatchCandidateId;

    INSERT INTO @preDispatchFailure
    EXEC [po].[sp_fail_purchase_order_candidate_pre_dispatch]
        @candidateId = @preDispatchCandidateId,
        @leaseToken = @preDispatchLeaseToken,
        @workerId = N'acceptance-predispatch-worker',
        @candidateStatus = 'RECOVERABLE_ERROR',
        @failureCategory = 'SYNTHETIC_ACTIVATION_TRANSPORT',
        @messageCode = N'SYNTHETIC_ACTIVATION_FAILED',
        @messageDescription = N'Synthetic activation lookup transport failure.';

    IF NOT EXISTS
    (
        SELECT 1
        FROM @preDispatchFailure
        WHERE [CandidateId] = @preDispatchCandidateId
          AND [Status] = 'RECOVERABLE_ERROR'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @preDispatchCandidateId
          AND [Status] = 'RECOVERABLE_ERROR'
          AND [PayloadJson] = @attemptPayload
          AND [LeaseToken] IS NULL
          AND [LeaseOwner] IS NULL
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @preDispatchCandidateId
          AND audit.[Action] = 'SUBMISSION_FAILED_BEFORE_DISPATCH'
          AND audit.[PreviousStatus] = 'READY_FOR_SUBMISSION'
          AND audit.[CurrentStatus] = 'RECOVERABLE_ERROR'
    )
    OR EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = attempt.[CandidateKey]
        WHERE candidate.[CandidateId] = @preDispatchCandidateId
    )
    BEGIN
        ;THROW 52058, 'Pre-dispatch failure did not preserve payload and atomically persist terminal state and audit.', 1;
    END;

    INSERT INTO @postPreDispatchClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-post-predispatch-worker',
        @maxCandidates = 1,
        @leaseDurationSeconds = 60;

    IF EXISTS
    (
        SELECT 1
        FROM @postPreDispatchClaims
        WHERE [CandidateId] = @preDispatchCandidateId
    )
    BEGIN
        ;THROW 52059, 'A pre-dispatch error candidate became automatically eligible.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @preDispatchCandidateId
)
BEGIN
    ;THROW 52060, 'Pre-dispatch failure acceptance cleanup did not roll back synthetic data.', 1;
END;

PRINT 'PASS:SCENARIO:PREDISPATCH_FAILURE_TERMINAL';

-- SCENARIO:PREDISPATCH_FAILURE_NONRECOVERABLE
DECLARE @preDispatchNonRecoverableCandidateId uniqueidentifier =
    'A4000000-0000-4000-8000-000000000021';
DECLARE @preDispatchNonRecoverableClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @preDispatchNonRecoverableFailure TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @preDispatchNonRecoverableLeaseToken uniqueidentifier;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @preDispatchNonRecoverableCandidateId,
        @account = N'SYNTHETIC-ATTEMPT',
        @branch = N'401',
        @reference = N'SYNTHETIC-PREDISPATCH-NONRECOVERABLE',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-04-04T00:00:00.000+00:00',
        @payloadJson = @attemptPayload,
        @actor = N'acceptance-api';

    INSERT INTO @preDispatchNonRecoverableClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-predispatch-nonrecoverable-worker',
        @maxCandidates = 1,
        @leaseDurationSeconds = 600;

    SELECT @preDispatchNonRecoverableLeaseToken = [LeaseToken]
    FROM @preDispatchNonRecoverableClaims
    WHERE [CandidateId] = @preDispatchNonRecoverableCandidateId;

    IF @preDispatchNonRecoverableLeaseToken IS NULL
    BEGIN
        ;THROW 52077, 'The non-recoverable pre-dispatch candidate was not claimed.', 1;
    END;

    INSERT INTO @preDispatchNonRecoverableFailure
    EXEC [po].[sp_fail_purchase_order_candidate_pre_dispatch]
        @candidateId = @preDispatchNonRecoverableCandidateId,
        @leaseToken = @preDispatchNonRecoverableLeaseToken,
        @workerId = N'acceptance-predispatch-nonrecoverable-worker',
        @candidateStatus = 'NON_RECOVERABLE_ERROR',
        @failureCategory = 'SYNTHETIC_ACTIVATION_CONTRACT',
        @messageCode = N'SYNTHETIC_ACTIVATION_INVALID',
        @messageDescription = N'Synthetic non-recoverable activation lookup failure.';

    IF NOT EXISTS
    (
        SELECT 1
        FROM @preDispatchNonRecoverableFailure
        WHERE [CandidateId] = @preDispatchNonRecoverableCandidateId
          AND [Status] = 'NON_RECOVERABLE_ERROR'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @preDispatchNonRecoverableCandidateId
          AND [Status] = 'NON_RECOVERABLE_ERROR'
          AND [PayloadJson] = @attemptPayload
          AND [LeaseToken] IS NULL
          AND [LeaseOwner] IS NULL
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @preDispatchNonRecoverableCandidateId
          AND audit.[Action] = 'SUBMISSION_FAILED_BEFORE_DISPATCH'
          AND audit.[PreviousStatus] = 'READY_FOR_SUBMISSION'
          AND audit.[CurrentStatus] = 'NON_RECOVERABLE_ERROR'
    )
    OR EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = attempt.[CandidateKey]
        WHERE candidate.[CandidateId] = @preDispatchNonRecoverableCandidateId
    )
    BEGIN
        ;THROW 52078, 'Non-recoverable pre-dispatch failure was not persisted atomically.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @preDispatchNonRecoverableCandidateId
)
BEGIN
    ;THROW 52079, 'Non-recoverable pre-dispatch acceptance cleanup did not roll back synthetic data.', 1;
END;

PRINT 'PASS:SCENARIO:PREDISPATCH_FAILURE_NONRECOVERABLE';

DECLARE @preDispatchGuardCandidateId uniqueidentifier =
    'A4000000-0000-4000-8000-000000000030';
DECLARE @preDispatchGuardAttemptId uniqueidentifier =
    'A4000000-0000-4000-8000-000000000031';
DECLARE @preDispatchWrongLeaseToken uniqueidentifier =
    'A4000000-0000-4000-8000-000000000032';
DECLARE @preDispatchGuardClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @preDispatchGuardDispatchedAttempt TABLE
(
    [AttemptId] uniqueidentifier NOT NULL,
    [AttemptNumber] int NOT NULL,
    [Status] varchar(50) NOT NULL
);
DECLARE @preDispatchGuardLeaseToken uniqueidentifier;
DECLARE @preDispatchGuardCandidateRowVersion binary(8);
DECLARE @preDispatchWrongLeaseRejected bit = 0;
DECLARE @preDispatchIneligibleStatusRejected bit = 0;
DECLARE @preDispatchDispatchedAttemptRejected bit = 0;

BEGIN TRY
    -- These rejection cases must use a committed fixture. The procedure rolls back
    -- its own failed transaction, which would also roll back a caller-owned setup.
    -- CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY
    BEGIN TRANSACTION;

    DELETE attempt
    FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = attempt.[CandidateKey]
    WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId;

    DELETE audit
    FROM [po].[PurchaseOrderAudit] AS audit
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = audit.[CandidateKey]
    WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId;

    DELETE FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @preDispatchGuardCandidateId;

    COMMIT TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @preDispatchGuardCandidateId,
        @account = N'SYNTHETIC-ATTEMPT',
        @branch = N'401',
        @reference = N'SYNTHETIC-PREDISPATCH-GUARDS',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-04-05T00:00:00.000+00:00',
        @payloadJson = @attemptPayload,
        @actor = N'acceptance-api';

    INSERT INTO @preDispatchGuardClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-predispatch-guard-worker',
        @maxCandidates = 1,
        @leaseDurationSeconds = 600;

    SELECT
        @preDispatchGuardLeaseToken = [LeaseToken],
        @preDispatchGuardCandidateRowVersion = [RowVersion]
    FROM @preDispatchGuardClaims
    WHERE [CandidateId] = @preDispatchGuardCandidateId;

    IF @preDispatchGuardLeaseToken IS NULL
       OR @preDispatchGuardCandidateRowVersion IS NULL
    BEGIN
        ;THROW 52080, 'The pre-dispatch guard candidate was not claimed.', 1;
    END;

    -- SCENARIO:PREDISPATCH_FAILURE_REJECTS_WRONG_LEASE
    BEGIN TRY
        EXEC [po].[sp_fail_purchase_order_candidate_pre_dispatch]
            @candidateId = @preDispatchGuardCandidateId,
            @leaseToken = @preDispatchWrongLeaseToken,
            @workerId = N'acceptance-predispatch-guard-worker',
            @candidateStatus = 'RECOVERABLE_ERROR',
            @failureCategory = 'SYNTHETIC_WRONG_LEASE',
            @messageCode = N'SYNTHETIC_WRONG_LEASE',
            @messageDescription = N'Synthetic wrong lease failure.';

        ;THROW 52081, 'Expected pre-dispatch failure with the wrong lease to be rejected.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 51003
           AND ERROR_MESSAGE() = 'The purchase order claim is missing, expired, or does not match.'
        BEGIN
            SET @preDispatchWrongLeaseRejected = 1;
        END
        ELSE
        BEGIN
            THROW;
        END;
    END CATCH;

    IF @preDispatchWrongLeaseRejected = 0
       OR NOT EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderCandidate]
           WHERE [CandidateId] = @preDispatchGuardCandidateId
             AND [Status] = 'READY_FOR_SUBMISSION'
             AND [LeaseToken] = @preDispatchGuardLeaseToken
             AND [LeaseOwner] = N'acceptance-predispatch-guard-worker'
             AND [RowVersion] = @preDispatchGuardCandidateRowVersion
       )
       OR EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderAudit] AS audit
           INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
               ON candidate.[CandidateKey] = audit.[CandidateKey]
           WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId
             AND audit.[Action] = 'SUBMISSION_FAILED_BEFORE_DISPATCH'
       )
    BEGIN
        ;THROW 52082, 'Wrong-lease rejection changed durable candidate state.', 1;
    END;

    PRINT 'PASS:SCENARIO:PREDISPATCH_FAILURE_REJECTS_WRONG_LEASE';

    -- SCENARIO:PREDISPATCH_FAILURE_REJECTS_INELIGIBLE_STATUS
    UPDATE [po].[PurchaseOrderCandidate]
    SET
        [Status] = 'DRAFT',
        [StatusDateTime] = '2099-04-05T00:00:03.000+00:00',
        [UpdatedDateTime] = '2099-04-05T00:00:03.000+00:00',
        [RefreshDateTime] = '2099-04-05T00:00:03.000+00:00'
    WHERE [CandidateId] = @preDispatchGuardCandidateId;

    SELECT @preDispatchGuardCandidateRowVersion = [RowVersion]
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @preDispatchGuardCandidateId;

    BEGIN TRY
        EXEC [po].[sp_fail_purchase_order_candidate_pre_dispatch]
            @candidateId = @preDispatchGuardCandidateId,
            @leaseToken = @preDispatchGuardLeaseToken,
            @workerId = N'acceptance-predispatch-guard-worker',
            @candidateStatus = 'RECOVERABLE_ERROR',
            @failureCategory = 'SYNTHETIC_INELIGIBLE_STATUS',
            @messageCode = N'SYNTHETIC_INELIGIBLE_STATUS',
            @messageDescription = N'Synthetic ineligible status failure.';

        ;THROW 52083, 'Expected pre-dispatch failure for an ineligible status to be rejected.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 51004
           AND ERROR_MESSAGE() = 'The purchase order candidate is not eligible for a pre-dispatch failure.'
        BEGIN
            SET @preDispatchIneligibleStatusRejected = 1;
        END
        ELSE
        BEGIN
            THROW;
        END;
    END CATCH;

    IF @preDispatchIneligibleStatusRejected = 0
       OR NOT EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderCandidate]
           WHERE [CandidateId] = @preDispatchGuardCandidateId
             AND [Status] = 'DRAFT'
             AND [LeaseToken] = @preDispatchGuardLeaseToken
             AND [RowVersion] = @preDispatchGuardCandidateRowVersion
       )
       OR EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderAudit] AS audit
           INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
               ON candidate.[CandidateKey] = audit.[CandidateKey]
           WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId
             AND audit.[Action] = 'SUBMISSION_FAILED_BEFORE_DISPATCH'
       )
    BEGIN
        ;THROW 52084, 'Ineligible-status rejection changed durable candidate state.', 1;
    END;

    PRINT 'PASS:SCENARIO:PREDISPATCH_FAILURE_REJECTS_INELIGIBLE_STATUS';

    UPDATE [po].[PurchaseOrderCandidate]
    SET
        [Status] = 'READY_FOR_SUBMISSION',
        [StatusDateTime] = '2099-04-05T00:00:05.000+00:00',
        [UpdatedDateTime] = '2099-04-05T00:00:05.000+00:00',
        [RefreshDateTime] = '2099-04-05T00:00:05.000+00:00'
    WHERE [CandidateId] = @preDispatchGuardCandidateId;

    INSERT INTO @preDispatchGuardDispatchedAttempt
    EXEC [po].[sp_begin_purchase_order_submission_attempt]
        @attemptId = @preDispatchGuardAttemptId,
        @candidateId = @preDispatchGuardCandidateId,
        @leaseToken = @preDispatchGuardLeaseToken,
        @workerId = N'acceptance-predispatch-guard-worker',
        @requestPayloadJson = N'{"syntheticRequest":"dispatched-guard"}';

    IF NOT EXISTS
    (
        SELECT 1
        FROM @preDispatchGuardDispatchedAttempt
        WHERE [AttemptId] = @preDispatchGuardAttemptId
          AND [Status] = 'DISPATCHED'
    )
    BEGIN
        ;THROW 52085, 'The dispatched-attempt guard fixture was not created.', 1;
    END;

    UPDATE [po].[PurchaseOrderCandidate]
    SET
        [Status] = 'READY_FOR_SUBMISSION',
        [StatusDateTime] = SYSUTCDATETIME(),
        [UpdatedDateTime] = SYSUTCDATETIME(),
        [RefreshDateTime] = SYSUTCDATETIME()
    WHERE [CandidateId] = @preDispatchGuardCandidateId
      AND [Status] = 'SUBMISSION_IN_PROGRESS';

    IF @@ROWCOUNT <> 1
    BEGIN
        ;THROW 52086, 'The dispatched-attempt guard candidate fixture was not reset.', 1;
    END;

    SELECT @preDispatchGuardCandidateRowVersion = [RowVersion]
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @preDispatchGuardCandidateId;

    -- SCENARIO:PREDISPATCH_FAILURE_REJECTS_DISPATCHED_ATTEMPT
    BEGIN TRY
        EXEC [po].[sp_fail_purchase_order_candidate_pre_dispatch]
            @candidateId = @preDispatchGuardCandidateId,
            @leaseToken = @preDispatchGuardLeaseToken,
            @workerId = N'acceptance-predispatch-guard-worker',
            @candidateStatus = 'RECOVERABLE_ERROR',
            @failureCategory = 'SYNTHETIC_DISPATCHED_ATTEMPT',
            @messageCode = N'SYNTHETIC_DISPATCHED_ATTEMPT',
            @messageDescription = N'Synthetic dispatched attempt failure.';

        ;THROW 52087, 'Expected pre-dispatch failure with a dispatched attempt to be rejected.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 51004
           AND ERROR_MESSAGE() = 'A dispatched purchase order attempt requires post-dispatch outcome handling.'
        BEGIN
            SET @preDispatchDispatchedAttemptRejected = 1;
        END
        ELSE
        BEGIN
            THROW;
        END;
    END CATCH;

    IF @preDispatchDispatchedAttemptRejected = 0
       OR NOT EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderCandidate]
           WHERE [CandidateId] = @preDispatchGuardCandidateId
             AND [Status] = 'READY_FOR_SUBMISSION'
             AND [LeaseToken] = @preDispatchGuardLeaseToken
             AND [RowVersion] = @preDispatchGuardCandidateRowVersion
       )
       OR NOT EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderSubmissionAttempt]
           WHERE [AttemptId] = @preDispatchGuardAttemptId
             AND [Status] = 'DISPATCHED'
             AND [CompletedDateTime] IS NULL
       )
       OR EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderAudit] AS audit
           INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
               ON candidate.[CandidateKey] = audit.[CandidateKey]
           WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId
             AND audit.[Action] = 'SUBMISSION_FAILED_BEFORE_DISPATCH'
       )
    BEGIN
        ;THROW 52088, 'Dispatched-attempt rejection changed durable submission state.', 1;
    END;

    PRINT 'PASS:SCENARIO:PREDISPATCH_FAILURE_REJECTS_DISPATCHED_ATTEMPT';

    -- CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY
    BEGIN TRANSACTION;

    DELETE attempt
    FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = attempt.[CandidateKey]
    WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId;

    DELETE audit
    FROM [po].[PurchaseOrderAudit] AS audit
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = audit.[CandidateKey]
    WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId;

    DELETE FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @preDispatchGuardCandidateId;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    BEGIN TRY
        -- CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY
        BEGIN TRANSACTION;

        DELETE attempt
        FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = attempt.[CandidateKey]
        WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId;

        DELETE audit
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @preDispatchGuardCandidateId;

        DELETE FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @preDispatchGuardCandidateId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        ;THROW 52089, 'Pre-dispatch guard acceptance cleanup failed.', 1;
    END CATCH;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @preDispatchGuardCandidateId
)
BEGIN
    ;THROW 52090, 'Pre-dispatch guard acceptance cleanup left synthetic data.', 1;
END;
