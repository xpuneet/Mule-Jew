SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;
SET XACT_ABORT ON;

DECLARE @claimed TABLE
(
    [NotificationId] uniqueidentifier, [EventType] varchar(100), [BusinessCorrelationId] nvarchar(256),
    [EmailEnvelopeVersion] smallint, [EmailEnvelopeJson] nvarchar(max), [PayloadSha256] binary(32),
    [AttemptCount] int, [FailureCount] int, [ThrottleCount] int,
    [LeaseId] uniqueidentifier, [LeaseExpiresDateTime] datetimeoffset(3), [RowVersion] binary(8)
);
DECLARE @asOf datetimeoffset(3) = '2099-07-01T00:00:00.000+00:00';
BEGIN TRY
    -- Observe A's claim without blocking; the seed rows were committed before that claim began.
    IF (SELECT COUNT(*) FROM [po].[PurchaseOrderNotification] WITH (READUNCOMMITTED)
        WHERE [NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002')) <> 2
       OR (SELECT COUNT(*) FROM [po].[PurchaseOrderNotification] WITH (READUNCOMMITTED)
        WHERE [NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002') AND [Status] = 'SENDING') <> 1
    BEGIN
        ;THROW 52132, 'Start Session B immediately after Session A reports SESSION_A_READY.', 1;
    END;

    BEGIN TRANSACTION;
    DECLARE @quotaLockAvailable int = APPLOCK_TEST('public', N'po.email-notification-claim-quota', 'Exclusive', 'Transaction');
    IF @quotaLockAvailable IS NULL OR @quotaLockAvailable <> 0
    BEGIN
        ;THROW 52135, 'Session B must observe the exclusive quota lock held by Session A before claiming.', 1;
    END;
    RAISERROR ('PASS:SESSION_B_QUOTA_LOCK_CONTENTION_CONFIRMED', 10, 1) WITH NOWAIT;

    INSERT INTO @claimed EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @asOf, @leaseDurationSeconds = 60, @maxNotifications = 1,
        @maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 1;
    IF EXISTS (SELECT 1 FROM @claimed)
    BEGIN
        ;THROW 52133, 'Concurrent claimers spent the same rolling quota slot.', 1;
    END;
    IF (SELECT COUNT(*) FROM [po].[PurchaseOrderNotification]
        WHERE [NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002') AND [Status] = 'PENDING' AND [NextAttemptDateTime] <= @asOf) <> 1
       OR (SELECT COUNT(*) FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
           INNER JOIN [po].[PurchaseOrderNotification] AS notification ON notification.[NotificationKey] = attempt.[NotificationKey]
           WHERE notification.[NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002')) <> 1
    BEGIN
        ;THROW 52134, 'Empty claim was not proved against one due row and one committed attempt.', 1;
    END;
    COMMIT TRANSACTION;
    PRINT 'PASS:SESSION_B_QUOTA_NOT_DOUBLE_SPENT';
    BEGIN TRANSACTION;
    -- CLEANUP_SCOPE:FIXED_NOTIFICATION_IDS_ONLY
    DELETE attempt
    FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderNotification] AS notification
        ON notification.[NotificationKey] = attempt.[NotificationKey]
    WHERE notification.[NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    DELETE FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    COMMIT TRANSACTION;
    PRINT 'PASS:CLEANUP_COMPLETE';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    -- CLEANUP_SCOPE:FIXED_NOTIFICATION_IDS_ONLY
    DELETE attempt
    FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderNotification] AS notification
        ON notification.[NotificationKey] = attempt.[NotificationKey]
    WHERE notification.[NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    DELETE FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    THROW;
END CATCH;
