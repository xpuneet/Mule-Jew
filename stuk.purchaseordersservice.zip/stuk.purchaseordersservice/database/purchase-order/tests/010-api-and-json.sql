SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

DECLARE @payloadJson nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-ACCOUNT","branch":101,"reference":"SYNTHETIC-REFERENCE"},"purchaseOrderLines":[]}';

-- SCENARIO:INVALID_JSON_ROLLBACK
DECLARE @invalidJsonCandidateId uniqueidentifier = 'A1000000-0000-4000-8000-000000000001';
BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @invalidJsonCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-INVALID-JSON',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-01-01T00:00:00.000+00:00',
        @payloadJson = N'{invalid-json',
        @actor = N'acceptance-api';

    ;THROW 52001, 'Expected invalid JSON to be rejected.', 1;
END TRY
BEGIN CATCH
    DECLARE @invalidJsonErrorNumber int = ERROR_NUMBER();

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @invalidJsonErrorNumber <> 51004
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @invalidJsonCandidateId
)
BEGIN
    ;THROW 52002, 'Invalid JSON left a candidate row behind.', 1;
END;

PRINT 'PASS:SCENARIO:INVALID_JSON_ROLLBACK';

-- SCENARIO:INVALID_STATUS_ROLLBACK
DECLARE @invalidStatusCandidateId uniqueidentifier = 'A1000000-0000-4000-8000-000000000002';
BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @invalidStatusCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-INVALID-STATUS',
        @status = 'SYNTHETIC_INVALID_STATUS',
        @acceptedDateTime = '2099-01-01T00:01:00.000+00:00',
        @payloadJson = @payloadJson,
        @actor = N'acceptance-api';

    ;THROW 52003, 'Expected an invalid candidate status to be rejected.', 1;
END TRY
BEGIN CATCH
    DECLARE @invalidStatusErrorNumber int = ERROR_NUMBER();

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @invalidStatusErrorNumber <> 51004
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @invalidStatusCandidateId
)
BEGIN
    ;THROW 52004, 'Invalid status left a candidate row behind.', 1;
END;

PRINT 'PASS:SCENARIO:INVALID_STATUS_ROLLBACK';

-- SCENARIO:CANDIDATE_STATUS_REJECTED
DECLARE @candidateStatusCandidateId uniqueidentifier = 'A1000000-0000-4000-8000-000000000003';
BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @candidateStatusCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-CANDIDATE-STATUS',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-01-01T00:02:00.000+00:00',
        @payloadJson = N'{"purchaseOrderHeader":{"account":"SYNTHETIC-ACCOUNT","branch":101},"purchaseOrderLines":[],"candidateStatus":{"status":"READY_FOR_SUBMISSION"}}',
        @actor = N'acceptance-api';

    ;THROW 52005, 'Expected a top-level candidateStatus property to be rejected.', 1;
END TRY
BEGIN CATCH
    DECLARE @candidateStatusErrorNumber int = ERROR_NUMBER();

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @candidateStatusErrorNumber <> 51004
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @candidateStatusCandidateId
)
BEGIN
    ;THROW 52006, 'Rejected candidateStatus payload left a candidate row behind.', 1;
END;

PRINT 'PASS:SCENARIO:CANDIDATE_STATUS_REJECTED';

-- SCENARIO:REPEATED_API_PAYLOAD_DISTINCT_IDS
-- SCENARIO:DETERMINISTIC_SEARCH_PAGING
DECLARE @firstCandidateId uniqueidentifier = 'A1000000-0000-4000-8000-000000000011';
DECLARE @secondCandidateId uniqueidentifier = 'A1000000-0000-4000-8000-000000000012';

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @firstCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-REPEATED-PAYLOAD',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-01-02T00:00:00.000+00:00',
        @payloadJson = @payloadJson,
        @actor = N'acceptance-api';

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @secondCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-REPEATED-PAYLOAD',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-01-01T00:00:00.000+00:00',
        @payloadJson = @payloadJson,
        @actor = N'acceptance-api';

    IF
    (
        SELECT COUNT(*)
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] IN (@firstCandidateId, @secondCandidateId)
          AND [PayloadJson] = @payloadJson
    ) <> 2
    BEGIN
        ;THROW 52007, 'Repeated API payloads were not stored as two distinct candidates.', 1;
    END;

    DECLARE @pageOne TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Source] nvarchar(50) NOT NULL,
        [Account] nvarchar(50) NOT NULL,
        [Branch] nvarchar(20) NOT NULL,
        [Reference] nvarchar(100) NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NULL,
        [Status] varchar(50) NOT NULL,
        [AcceptedDateTime] datetimeoffset(3) NOT NULL
    );
    DECLARE @pageTwo TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Source] nvarchar(50) NOT NULL,
        [Account] nvarchar(50) NOT NULL,
        [Branch] nvarchar(20) NOT NULL,
        [Reference] nvarchar(100) NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NULL,
        [Status] varchar(50) NOT NULL,
        [AcceptedDateTime] datetimeoffset(3) NOT NULL
    );

    INSERT INTO @pageOne
    EXEC [po].[sp_search_purchase_order_candidates]
        @source = N'API',
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-REPEATED-PAYLOAD',
        @iconPurchaseOrderNumber = NULL,
        @status = 'READY_FOR_SUBMISSION',
        @pageNumber = 1,
        @pageSize = 1;

    INSERT INTO @pageTwo
    EXEC [po].[sp_search_purchase_order_candidates]
        @source = N'API',
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-REPEATED-PAYLOAD',
        @iconPurchaseOrderNumber = NULL,
        @status = 'READY_FOR_SUBMISSION',
        @pageNumber = 2,
        @pageSize = 1;

    IF NOT EXISTS (SELECT 1 FROM @pageOne WHERE [CandidateId] = @firstCandidateId)
       OR NOT EXISTS (SELECT 1 FROM @pageTwo WHERE [CandidateId] = @secondCandidateId)
    BEGIN
        ;THROW 52008, 'Search paging did not follow AcceptedDateTime DESC, CandidateId ordering.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE [object_id] = OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U')
          AND [name] = N'IX_PO_Candidate_Source_Status_AcceptedDateTime'
          AND [is_disabled] = 0
          AND [is_hypothetical] = 0
    )
    BEGIN
        ;THROW 52009, 'The documented candidate paging index is not available.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] IN (@firstCandidateId, @secondCandidateId)
)
BEGIN
    ;THROW 52010, 'API acceptance test cleanup did not roll back its synthetic candidates.', 1;
END;

PRINT 'PASS:SCENARIO:REPEATED_API_PAYLOAD_DISTINCT_IDS';
PRINT 'PASS:SCENARIO:DETERMINISTIC_SEARCH_PAGING';
