SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

DECLARE @supportPayload nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-SUPPORT","branch":501,"reference":"SYNTHETIC-SUPPORT"},"purchaseOrderLines":[]}';

-- SCENARIO:RETRY_OPTIMISTIC_CONCURRENCY
DECLARE @staleRetryCandidateId uniqueidentifier = 'A5000000-0000-4000-8000-000000000001';
DECLARE @staleRetryRejected bit = 0;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @staleRetryCandidateId,
        @account = N'SYNTHETIC-SUPPORT',
        @branch = N'501',
        @reference = N'SYNTHETIC-STALE-RETRY',
        @status = 'NON_RECOVERABLE_ERROR',
        @acceptedDateTime = '2099-05-01T00:00:00.000+00:00',
        @payloadJson = @supportPayload,
        @actor = N'acceptance-api';

    EXEC [po].[sp_request_purchase_order_retry]
        @candidateId = @staleRetryCandidateId,
        @actor = N'acceptance-support-actor',
        @reason = N'Synthetic stale retry rowversion.',
        @requestedDateTime = '2099-05-01T00:00:01.000+00:00',
        @expectedCandidateRowVersion = 0x0000000000000000;

    ;THROW 52060, 'Expected retry with a stale rowversion to fail.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 51002
    BEGIN
        SET @staleRetryRejected = 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @staleRetryRejected = 0
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @staleRetryCandidateId
)
BEGIN
    ;THROW 52061, 'Stale retry scenario did not roll back its synthetic candidate.', 1;
END;

DECLARE @validRetryCandidateId uniqueidentifier = 'A5000000-0000-4000-8000-000000000002';
DECLARE @validRetryRowVersion binary(8);

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @validRetryCandidateId,
        @account = N'SYNTHETIC-SUPPORT',
        @branch = N'501',
        @reference = N'SYNTHETIC-VALID-RETRY',
        @status = 'RECOVERABLE_ERROR',
        @acceptedDateTime = '2099-05-01T00:01:00.000+00:00',
        @payloadJson = @supportPayload,
        @actor = N'acceptance-api';

    SELECT @validRetryRowVersion = [RowVersion]
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @validRetryCandidateId;

    EXEC [po].[sp_request_purchase_order_retry]
        @candidateId = @validRetryCandidateId,
        @actor = N'acceptance-support-actor',
        @reason = N'Synthetic valid retry rowversion.',
        @requestedDateTime = '2099-05-01T00:01:01.000+00:00',
        @expectedCandidateRowVersion = @validRetryRowVersion;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @validRetryCandidateId
          AND [Status] = 'RETRY_REQUESTED'
          AND [PayloadJson] = @supportPayload
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @validRetryCandidateId
          AND audit.[Action] = 'MANUAL_RETRY_REQUESTED'
          AND audit.[Actor] = N'acceptance-support-actor'
    )
    BEGIN
        ;THROW 52062, 'Retry with the current rowversion did not update status and audit atomically.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

PRINT 'PASS:SCENARIO:RETRY_OPTIMISTIC_CONCURRENCY';

-- SCENARIO:CANCEL_OPTIMISTIC_CONCURRENCY
DECLARE @staleCancelCandidateId uniqueidentifier = 'A5000000-0000-4000-8000-000000000010';
DECLARE @staleCancelRejected bit = 0;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @staleCancelCandidateId,
        @account = N'SYNTHETIC-SUPPORT',
        @branch = N'501',
        @reference = N'SYNTHETIC-STALE-CANCEL',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-05-02T00:00:00.000+00:00',
        @payloadJson = @supportPayload,
        @actor = N'acceptance-api';

    EXEC [po].[sp_cancel_purchase_order_candidate]
        @candidateId = @staleCancelCandidateId,
        @actor = N'acceptance-support-actor',
        @reason = N'Synthetic stale cancel rowversion.',
        @cancelledDateTime = '2099-05-02T00:00:01.000+00:00',
        @expectedCandidateRowVersion = 0x0000000000000000;

    ;THROW 52063, 'Expected cancel with a stale rowversion to fail.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 51002
    BEGIN
        SET @staleCancelRejected = 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @staleCancelRejected = 0
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @staleCancelCandidateId
)
BEGIN
    ;THROW 52064, 'Stale cancel scenario did not roll back its synthetic candidate.', 1;
END;

DECLARE @validCancelCandidateId uniqueidentifier = 'A5000000-0000-4000-8000-000000000011';
DECLARE @validCancelRowVersion binary(8);

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @validCancelCandidateId,
        @account = N'SYNTHETIC-SUPPORT',
        @branch = N'501',
        @reference = N'SYNTHETIC-VALID-CANCEL',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-05-02T00:01:00.000+00:00',
        @payloadJson = @supportPayload,
        @actor = N'acceptance-api';

    SELECT @validCancelRowVersion = [RowVersion]
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @validCancelCandidateId;

    EXEC [po].[sp_cancel_purchase_order_candidate]
        @candidateId = @validCancelCandidateId,
        @actor = N'acceptance-support-actor',
        @reason = N'Synthetic valid cancel rowversion.',
        @cancelledDateTime = '2099-05-02T00:01:01.000+00:00',
        @expectedCandidateRowVersion = @validCancelRowVersion;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @validCancelCandidateId
          AND [Status] = 'CANCELLED'
          AND [PayloadJson] = @supportPayload
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @validCancelCandidateId
          AND audit.[Action] = 'CANCELLED'
          AND audit.[Actor] = N'acceptance-support-actor'
    )
    BEGIN
        ;THROW 52065, 'Cancel with the current rowversion did not update status and audit atomically.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

PRINT 'PASS:SCENARIO:CANCEL_OPTIMISTIC_CONCURRENCY';

-- SCENARIO:NOTIFICATION_OPTIMISTIC_CONCURRENCY
DECLARE @staleNotificationBatchId uniqueidentifier = 'A5000000-0000-4000-8000-000000000020';
DECLARE @staleNotificationId uniqueidentifier = 'A5000000-0000-4000-8000-000000000021';
DECLARE @staleNotificationRejected bit = 0;

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO [po].[PurchaseOrderBatch]
    (
        [BatchId], [Source], [OriginalFileName], [SourceFilePath], [FileContentLength],
        [FileSha256], [Status], [ExpectedRowCount], [ParsedRowCount], [CandidateCount],
        [FailureCode], [FailureDescription], [DiscoveredDateTime],
        [IngestionStartedDateTime], [CompletedDateTime], [CreatedBy], [UpdatedDateTime]
    )
    VALUES
    (
        @staleNotificationBatchId,
        N'ACCEPTANCE_NOTIFICATION',
        N'synthetic-stale-notification.csv',
        N'acceptance/a520/stale-notification',
        64,
        0xA520A520A520A520A520A520A520A520A520A520A520A520A520A520A520A520,
        'COMPLETED',
        0,
        0,
        0,
        NULL,
        NULL,
        '2099-05-03T00:00:00.000+00:00',
        '2099-05-03T00:00:00.000+00:00',
        '2099-05-03T00:00:01.000+00:00',
        N'acceptance-notification',
        '2099-05-03T00:00:01.000+00:00'
    );

    EXEC [po].[sp_register_purchase_order_notification]
        @notificationId = @staleNotificationId,
        @batchId = @staleNotificationBatchId,
        @channel = 'EMAIL',
        @templateKey = N'SYNTHETIC_TEMPLATE',
        @recipientGroupKey = N'SYNTHETIC_RECIPIENT_GROUP',
        @attachmentBlobName = NULL,
        @createdDateTime = '2099-05-03T00:00:02.000+00:00';

    EXEC [po].[sp_complete_purchase_order_notification]
        @notificationId = @staleNotificationId,
        @status = 'SENT',
        @providerMessageId = N'SYNTHETIC-PROVIDER-MESSAGE',
        @failureCode = NULL,
        @failureDescription = NULL,
        @completedDateTime = '2099-05-03T00:00:03.000+00:00',
        @expectedNotificationRowVersion = 0x0000000000000000;

    ;THROW 52066, 'Expected notification completion with a stale rowversion to fail.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 51002
    BEGIN
        SET @staleNotificationRejected = 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @staleNotificationRejected = 0
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] = @staleNotificationId
)
OR EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @staleNotificationBatchId
)
BEGIN
    ;THROW 52067, 'Stale notification scenario left partial synthetic data.', 1;
END;

DECLARE @validNotificationBatchId uniqueidentifier = 'A5000000-0000-4000-8000-000000000030';
DECLARE @validNotificationId uniqueidentifier = 'A5000000-0000-4000-8000-000000000031';
DECLARE @registeredNotification TABLE
(
    [NotificationId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @validNotificationRowVersion binary(8);

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO [po].[PurchaseOrderBatch]
    (
        [BatchId], [Source], [OriginalFileName], [SourceFilePath], [FileContentLength],
        [FileSha256], [Status], [ExpectedRowCount], [ParsedRowCount], [CandidateCount],
        [FailureCode], [FailureDescription], [DiscoveredDateTime],
        [IngestionStartedDateTime], [CompletedDateTime], [CreatedBy], [UpdatedDateTime]
    )
    VALUES
    (
        @validNotificationBatchId,
        N'ACCEPTANCE_NOTIFICATION',
        N'synthetic-valid-notification.csv',
        N'acceptance/a530/valid-notification',
        64,
        0xA530A530A530A530A530A530A530A530A530A530A530A530A530A530A530A530,
        'COMPLETED',
        0,
        0,
        0,
        NULL,
        NULL,
        '2099-05-04T00:00:00.000+00:00',
        '2099-05-04T00:00:00.000+00:00',
        '2099-05-04T00:00:01.000+00:00',
        N'acceptance-notification',
        '2099-05-04T00:00:01.000+00:00'
    );

    INSERT INTO @registeredNotification
    EXEC [po].[sp_register_purchase_order_notification]
        @notificationId = @validNotificationId,
        @batchId = @validNotificationBatchId,
        @channel = 'EMAIL',
        @templateKey = N'SYNTHETIC_TEMPLATE',
        @recipientGroupKey = N'SYNTHETIC_RECIPIENT_GROUP',
        @attachmentBlobName = N'acceptance/a530/synthetic-attachment',
        @createdDateTime = '2099-05-04T00:00:02.000+00:00';

    SELECT @validNotificationRowVersion = [RowVersion]
    FROM @registeredNotification
    WHERE [NotificationId] = @validNotificationId
      AND [Status] = 'PENDING';

    EXEC [po].[sp_complete_purchase_order_notification]
        @notificationId = @validNotificationId,
        @status = 'SENT',
        @providerMessageId = N'SYNTHETIC-PROVIDER-MESSAGE',
        @failureCode = NULL,
        @failureDescription = NULL,
        @completedDateTime = '2099-05-04T00:00:03.000+00:00',
        @expectedNotificationRowVersion = @validNotificationRowVersion;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderNotification]
        WHERE [NotificationId] = @validNotificationId
          AND [Status] = 'SENT'
          AND [ProviderMessageId] = N'SYNTHETIC-PROVIDER-MESSAGE'
          AND [FailureCode] IS NULL
          AND [FailureDescription] IS NULL
          AND [SentDateTime] = '2099-05-04T00:00:03.000+00:00'
          AND [CompletedDateTime] = '2099-05-04T00:00:03.000+00:00'
          AND [NextAttemptDateTime] = [CreatedDateTime]
          AND [EmailEnvelopeJson] IS NULL
    )
    BEGIN
        ;THROW 52068, 'Notification completion with the current rowversion did not persist the expected state.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] IN
    (
        @validRetryCandidateId,
        @validCancelCandidateId
    )
)
OR EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] = @validNotificationId
)
OR EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @validNotificationBatchId
)
BEGIN
    ;THROW 52069, 'Support and notification acceptance cleanup did not roll back synthetic data.', 1;
END;

PRINT 'PASS:SCENARIO:NOTIFICATION_OPTIMISTIC_CONCURRENCY';

-- SCENARIO:LEGACY_COMPLETION_REJECTS_EMAIL_ENVELOPE
DECLARE @emailIsolationRejected bit = 0;
DECLARE @emailIsolationVersion binary(8);
BEGIN TRY
    BEGIN TRANSACTION;
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5000000-0000-4000-8000-000000000040',
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-LEGACY-ISOLATION',
        @emailEnvelopeVersion = 1,
        @emailEnvelopeJson = N'{"notificationId":"A5000000-0000-4000-8000-000000000040","businessCorrelationId":"SYNTHETIC-LEGACY-ISOLATION","schemaVersion":1}',
        @createdDateTime = '2099-05-04T00:00:00.000+00:00';
    SELECT @emailIsolationVersion = [RowVersion] FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] = 'A5000000-0000-4000-8000-000000000040';
    EXEC [po].[sp_complete_purchase_order_notification]
        @notificationId = 'A5000000-0000-4000-8000-000000000040', @status = 'SENT',
        @completedDateTime = '2099-05-04T00:00:01.000+00:00',
        @expectedNotificationRowVersion = @emailIsolationVersion;
    ;THROW 52122, 'Legacy completion accepted an email envelope without a leased attempt.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 51004 SET @emailIsolationRejected = 1;
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    IF @emailIsolationRejected = 0 THROW;
END CATCH;
PRINT 'PASS:SCENARIO:LEGACY_COMPLETION_REJECTS_EMAIL_ENVELOPE';
