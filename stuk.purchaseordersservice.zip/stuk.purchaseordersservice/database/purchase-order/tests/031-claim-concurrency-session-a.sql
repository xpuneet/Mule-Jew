SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

-- CONCURRENCY_PROTOCOL:SESSION_A
DECLARE @concurrencyCandidateId uniqueidentifier = 'A3100000-0000-4000-8000-000000000001';
DECLARE @concurrencyPayload nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-CONCURRENCY","branch":311,"reference":"SYNTHETIC-CONCURRENCY"},"purchaseOrderLines":[]}';
DECLARE @sessionAClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);

BEGIN TRY
    -- Recover a fixed synthetic identifier left by an interrupted prior Session A run.
    -- CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY
    BEGIN TRANSACTION;

    DELETE attempt
    FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = attempt.[CandidateKey]
    WHERE candidate.[CandidateId] = @concurrencyCandidateId;

    DELETE audit
    FROM [po].[PurchaseOrderAudit] AS audit
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = audit.[CandidateKey]
    WHERE candidate.[CandidateId] = @concurrencyCandidateId;

    DELETE FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @concurrencyCandidateId;

    COMMIT TRANSACTION;

    -- PREFLIGHT:NO_EXISTING_LEASES
    IF EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [LeaseToken] IS NOT NULL
    )
    BEGIN
        ;THROW 52046, 'Concurrency acceptance requires an isolated database with no pre-existing leases.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [Status] IN ('READY_FOR_SUBMISSION', 'RETRY_REQUESTED')
          AND [LeaseToken] IS NULL
    )
    BEGIN
        ;THROW 52041, 'Concurrency acceptance requires an isolated database with no pre-existing claimable candidates.', 1;
    END;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @concurrencyCandidateId,
        @account = N'SYNTHETIC-CONCURRENCY',
        @branch = N'311',
        @reference = N'SYNTHETIC-CONCURRENCY',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-03-10T00:00:00.000+00:00',
        @payloadJson = @concurrencyPayload,
        @actor = N'acceptance-api';

    -- The outer transaction retains the update lock after the procedure's nested commit.
    BEGIN TRANSACTION;

    INSERT INTO @sessionAClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-concurrency-session-a',
        @maxCandidates = 1,
        @leaseDurationSeconds = 300;

    IF
    (
        SELECT COUNT(*)
        FROM @sessionAClaims
        WHERE [CandidateId] = @concurrencyCandidateId
    ) <> 1
    BEGIN
        ;THROW 52042, 'Session A did not exclusively claim the synthetic candidate.', 1;
    END;

    RAISERROR(
        N'PASS:SESSION_A_READY - start Session B now; Session A will hold the claim lock for 45 seconds.',
        10,
        1) WITH NOWAIT;
    WAITFOR DELAY '00:00:45';

    ROLLBACK TRANSACTION;

    -- Documented cleanup protocol: remove the committed fixture after Session B finishes.
    -- CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY
    BEGIN TRANSACTION;

    DELETE attempt
    FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = attempt.[CandidateKey]
    WHERE candidate.[CandidateId] = @concurrencyCandidateId;

    DELETE FROM [po].[PurchaseOrderAudit]
    WHERE [CandidateKey] =
    (
        SELECT [CandidateKey]
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @concurrencyCandidateId
    );

    DELETE FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @concurrencyCandidateId;

    COMMIT TRANSACTION;

    PRINT 'PASS:CLEANUP_COMPLETE - Session A rolled back the claim and removed the synthetic fixture.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    BEGIN TRY
        -- CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY
        BEGIN TRANSACTION;

        DELETE attempt
        FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = attempt.[CandidateKey]
        WHERE candidate.[CandidateId] = @concurrencyCandidateId;

        DELETE audit
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @concurrencyCandidateId;

        DELETE FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @concurrencyCandidateId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        ;THROW 52043, 'Session A failed and could not complete the documented synthetic cleanup.', 1;
    END CATCH;

    THROW;
END CATCH;
