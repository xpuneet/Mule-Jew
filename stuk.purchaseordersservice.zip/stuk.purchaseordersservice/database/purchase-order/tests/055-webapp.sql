SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

-- CLEANUP_SCOPE:FIXED_CANDIDATE_IDS_ONLY
DECLARE @lowerBoundCandidateId uniqueidentifier = 'A5500000-0000-4000-8000-000000000001';
DECLARE @insideRangeCandidateId uniqueidentifier = 'A5500000-0000-4000-8000-000000000002';
DECLARE @upperBoundCandidateId uniqueidentifier = 'A5500000-0000-4000-8000-000000000003';
DECLARE @otherSourceCandidateId uniqueidentifier = 'A5500000-0000-4000-8000-000000000004';
DECLARE @otherSourceBatchId uniqueidentifier = 'A5500000-0000-4000-8000-000000000005';
DECLARE @otherSourceFileHash binary(32) =
    0xA550000000004000800000000000000000000000000000000000000000000006;
DECLARE @payloadJson nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-ACCOUNT","branch":101,"reference":"SYNTHETIC-WEBAPP"},"purchaseOrderLines":[]}';

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] IN
    (
        @lowerBoundCandidateId,
        @insideRangeCandidateId,
        @upperBoundCandidateId,
        @otherSourceCandidateId
    )
)
OR EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @otherSourceBatchId
       OR [FileSha256] = @otherSourceFileHash
)
BEGIN
    ;THROW 52040, 'A fixed WebApp acceptance candidate or batch already exists.', 1;
END;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @lowerBoundCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-LOWER-BOUND',
        @status = 'DRAFT',
        @acceptedDateTime = '2099-02-01T00:00:00.000+00:00',
        @payloadJson = @payloadJson,
        @actor = N'acceptance-api';

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @insideRangeCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-INSIDE-RANGE',
        @status = 'RECOVERABLE_ERROR',
        @acceptedDateTime = '2099-02-01T12:00:00.000+00:00',
        @payloadJson = @payloadJson,
        @actor = N'acceptance-api';

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @upperBoundCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-UPPER-BOUND',
        @status = 'COMPLETED',
        @acceptedDateTime = '2099-02-02T00:00:00.000+00:00',
        @payloadJson = @payloadJson,
        @actor = N'acceptance-api';

    EXEC [po].[sp_register_purchase_order_batch]
        @batchId = @otherSourceBatchId,
        @originalFileName = N'synthetic-webapp-other-source.csv',
        @sourceFilePath = N'/data/input/synthetic-webapp-other-source.csv',
        @fileContentLength = 128,
        @fileSha256 = @otherSourceFileHash,
        @expectedRowCount = 1,
        @discoveredDateTime = '2099-02-01T05:59:00.000+00:00',
        @actor = N'acceptance-ingestion';

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @otherSourceBatchId,
        @candidateId = @otherSourceCandidateId,
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = N'SYNTHETIC-OTHER-SOURCE',
        @sourceRowCount = 1,
        @acceptedDateTime = '2099-02-01T06:00:00.000+00:00',
        @payloadJson = @payloadJson,
        @actor = N'acceptance-ingestion';

    DECLARE @summary TABLE
    (
        [Status] varchar(50) NOT NULL,
        [CandidateCount] bigint NOT NULL
    );

    INSERT INTO @summary ([Status], [CandidateCount])
    EXEC [po].[sp_get_purchase_order_candidate_summary]
        @source = N'API',
        @afterDateTimeUtc = '2099-02-01T00:00:00.000+00:00',
        @untilDateTimeUtc = '2099-02-02T00:00:00.000+00:00';

    -- SCENARIO:WEBAPP_SUMMARY_HALF_OPEN_RANGE
    IF (SELECT COALESCE(SUM([CandidateCount]), 0) FROM @summary) <> 2
       OR NOT EXISTS
       (
           SELECT 1
           FROM @summary
           WHERE [Status] = 'DRAFT'
             AND [CandidateCount] = 1
       )
       OR NOT EXISTS
       (
           SELECT 1
           FROM @summary
           WHERE [Status] = 'RECOVERABLE_ERROR'
             AND [CandidateCount] = 1
       )
       OR EXISTS
       (
           SELECT 1
           FROM @summary
           WHERE [Status] = 'COMPLETED'
       )
    BEGIN
        ;THROW 52041, 'The WebApp summary did not apply the expected half-open accepted-time range.', 1;
    END;

    -- SCENARIO:WEBAPP_SUMMARY_SOURCE_ISOLATION
    IF EXISTS
    (
        SELECT 1
        FROM @summary
        WHERE [Status] = 'DRAFT'
          AND [CandidateCount] <> 1
    )
    BEGIN
        ;THROW 52042, 'The WebApp summary included a candidate from another source.', 1;
    END;

    DECLARE @searchResults TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Source] nvarchar(50) NOT NULL,
        [Account] nvarchar(50) NOT NULL,
        [Branch] nvarchar(20) NOT NULL,
        [Reference] nvarchar(100) NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NULL,
        [Status] varchar(50) NOT NULL,
        [AcceptedDateTime] datetimeoffset(3) NOT NULL
    );

    INSERT INTO @searchResults
    EXEC [po].[sp_search_purchase_order_candidates]
        @source = N'API',
        @account = N'SYNTHETIC-ACCOUNT',
        @branch = N'101',
        @reference = NULL,
        @iconPurchaseOrderNumber = NULL,
        @status = NULL,
        @acceptedAfterDateTimeUtc = '2099-02-01T00:00:00.000+00:00',
        @acceptedUntilDateTimeUtc = '2099-02-02T00:00:00.000+00:00',
        @pageNumber = 1,
        @pageSize = 10;

    -- SCENARIO:WEBAPP_SEARCH_ACCEPTED_RANGE
    IF (SELECT COUNT_BIG(*) FROM @searchResults) <> 2
       OR NOT EXISTS
       (
           SELECT 1
           FROM @searchResults
           WHERE [CandidateId] = @lowerBoundCandidateId
       )
       OR NOT EXISTS
       (
           SELECT 1
           FROM @searchResults
           WHERE [CandidateId] = @insideRangeCandidateId
       )
       OR EXISTS
       (
           SELECT 1
           FROM @searchResults
           WHERE [CandidateId] IN (@upperBoundCandidateId, @otherSourceCandidateId)
       )
    BEGIN
        ;THROW 52043, 'WebApp search did not apply the expected accepted-time range and source.', 1;
    END;

    DECLARE @batchSummary TABLE
    (
        [Status] varchar(50) NOT NULL,
        [BatchCount] bigint NOT NULL
    );

    INSERT INTO @batchSummary ([Status], [BatchCount])
    EXEC [po].[sp_get_purchase_order_batch_summary]
        @source = N'Relex',
        @afterDateTimeUtc = '2099-02-01T00:00:00.000+00:00',
        @untilDateTimeUtc = '2099-02-02T00:00:00.000+00:00';

    -- SCENARIO:WEBAPP_BATCH_SUMMARY_HALF_OPEN_RANGE
    IF (SELECT COALESCE(SUM([BatchCount]), 0) FROM @batchSummary) <> 1
       OR NOT EXISTS
       (
           SELECT 1
           FROM @batchSummary
           WHERE [Status] = 'PROCESSING'
             AND [BatchCount] = 1
       )
    BEGIN
        ;THROW 52045, 'The WebApp file summary did not map the active Relex batch to PROCESSING.', 1;
    END;

    DECLARE @batchSearchResults TABLE
    (
        [BatchId] uniqueidentifier NOT NULL,
        [Source] nvarchar(50) NOT NULL,
        [OriginalFileName] nvarchar(260) NOT NULL,
        [SourceFilePath] nvarchar(512) NOT NULL,
        [FileContentLength] bigint NOT NULL,
        [Status] varchar(50) NOT NULL,
        [ExpectedRowCount] int NULL,
        [ParsedRowCount] int NOT NULL,
        [CandidateCount] int NOT NULL,
        [FailureCode] varchar(100) NULL,
        [DiscoveredDateTime] datetimeoffset(3) NOT NULL,
        [CompletedDateTime] datetimeoffset(3) NULL,
        [UpdatedDateTime] datetimeoffset(3) NOT NULL
    );

    INSERT INTO @batchSearchResults
    EXEC [po].[sp_search_purchase_order_batches]
        @source = N'Relex',
        @originalFileName = N'webapp-other-source',
        @status = 'PROCESSING',
        @discoveredAfterDateTimeUtc = '2099-02-01T00:00:00.000+00:00',
        @discoveredUntilDateTimeUtc = '2099-02-02T00:00:00.000+00:00',
        @pageNumber = 1,
        @pageSize = 1;

    -- SCENARIO:WEBAPP_BATCH_SEARCH_BOUNDED
    IF (SELECT COUNT_BIG(*) FROM @batchSearchResults) <> 1
       OR NOT EXISTS
       (
           SELECT 1
           FROM @batchSearchResults
           WHERE [BatchId] = @otherSourceBatchId
             AND [Status] = 'INGESTING'
       )
    BEGIN
        ;THROW 52046, 'The bounded WebApp file search did not return the selected Relex batch.', 1;
    END;

    DECLARE @batchCandidateSummary TABLE
    (
        [Status] varchar(50) NOT NULL,
        [CandidateCount] bigint NOT NULL
    );

    INSERT INTO @batchCandidateSummary
    EXEC [po].[sp_get_purchase_order_batch_candidate_summary]
        @batchId = @otherSourceBatchId;

    -- SCENARIO:WEBAPP_BATCH_CANDIDATE_SUMMARY
    IF NOT EXISTS
    (
        SELECT 1
        FROM @batchCandidateSummary
        WHERE [Status] = 'DRAFT'
          AND [CandidateCount] = 1
    )
    BEGIN
        ;THROW 52047, 'The WebApp batch candidate summary was not scoped to the selected batch.', 1;
    END;

    DECLARE @batchCandidateSearchResults TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Account] nvarchar(50) NOT NULL,
        [Branch] nvarchar(20) NOT NULL,
        [Reference] nvarchar(100) NULL,
        [Status] varchar(50) NOT NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NULL,
        [StatusReason] nvarchar(1000) NULL,
        [AcceptedDateTime] datetimeoffset(3) NOT NULL,
        [UpdatedDateTime] datetimeoffset(3) NOT NULL
    );

    INSERT INTO @batchCandidateSearchResults
    EXEC [po].[sp_search_purchase_order_batch_candidates]
        @batchId = @otherSourceBatchId,
        @status = 'DRAFT',
        @pageNumber = 1,
        @pageSize = 1;

    -- SCENARIO:WEBAPP_BATCH_CANDIDATE_SEARCH_BOUNDED
    IF (SELECT COUNT_BIG(*) FROM @batchCandidateSearchResults) <> 1
       OR NOT EXISTS
       (
           SELECT 1
           FROM @batchCandidateSearchResults
           WHERE [CandidateId] = @otherSourceCandidateId
       )
    BEGIN
        ;THROW 52048, 'The bounded WebApp batch candidate search returned an unexpected row.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] IN
    (
        @lowerBoundCandidateId,
        @insideRangeCandidateId,
        @upperBoundCandidateId,
        @otherSourceCandidateId
    )
)
OR EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @otherSourceBatchId
)
BEGIN
    ;THROW 52044, 'WebApp acceptance test cleanup did not roll back its fixed candidates.', 1;
END;

PRINT 'PASS:SCENARIO:WEBAPP_SUMMARY_HALF_OPEN_RANGE';
PRINT 'PASS:SCENARIO:WEBAPP_SUMMARY_SOURCE_ISOLATION';
PRINT 'PASS:SCENARIO:WEBAPP_SEARCH_ACCEPTED_RANGE';
PRINT 'PASS:SCENARIO:WEBAPP_BATCH_SUMMARY_HALF_OPEN_RANGE';
PRINT 'PASS:SCENARIO:WEBAPP_BATCH_SEARCH_BOUNDED';
PRINT 'PASS:SCENARIO:WEBAPP_BATCH_CANDIDATE_SUMMARY';
PRINT 'PASS:SCENARIO:WEBAPP_BATCH_CANDIDATE_SEARCH_BOUNDED';
