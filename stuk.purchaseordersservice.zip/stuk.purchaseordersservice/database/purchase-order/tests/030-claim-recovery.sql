SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

-- PREFLIGHT:NO_EXISTING_LEASES
IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [LeaseToken] IS NOT NULL
)
BEGIN
    ;THROW 52029, 'Claim acceptance tests require an isolated database with no pre-existing leases.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [Status] IN ('READY_FOR_SUBMISSION', 'RETRY_REQUESTED')
      AND [LeaseToken] IS NULL
)
BEGIN
    ;THROW 52030, 'Claim acceptance tests require an isolated database with no pre-existing claimable candidates.', 1;
END;

DECLARE @claimPayload nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-CLAIM-ACCOUNT","branch":301,"reference":"SYNTHETIC-CLAIM"},"purchaseOrderLines":[]}';

-- SCENARIO:LEASE_OWNERSHIP
DECLARE @ownershipCandidateId uniqueidentifier = 'A3000000-0000-4000-8000-000000000001';
DECLARE @ownershipRejected bit = 0;
DECLARE @ownershipClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @ownershipLeaseToken uniqueidentifier;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @ownershipCandidateId,
        @account = N'SYNTHETIC-CLAIM-ACCOUNT',
        @branch = N'301',
        @reference = N'SYNTHETIC-OWNERSHIP',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-03-01T00:00:00.000+00:00',
        @payloadJson = @claimPayload,
        @actor = N'acceptance-api';

    INSERT INTO @ownershipClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-worker-owner',
        @maxCandidates = 1,
        @leaseDurationSeconds = 300;

    SELECT @ownershipLeaseToken = [LeaseToken]
    FROM @ownershipClaims
    WHERE [CandidateId] = @ownershipCandidateId;

    IF @ownershipLeaseToken IS NULL
    BEGIN
        ;THROW 52031, 'The synthetic ownership candidate was not claimed.', 1;
    END;

    EXEC [po].[sp_renew_purchase_order_claim]
        @candidateId = @ownershipCandidateId,
        @leaseToken = @ownershipLeaseToken,
        @workerId = N'acceptance-worker-not-owner',
        @leaseDurationSeconds = 600;

    ;THROW 52032, 'Expected lease renewal by another worker to fail.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 51003
    BEGIN
        SET @ownershipRejected = 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @ownershipRejected = 0
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @ownershipCandidateId
)
BEGIN
    ;THROW 52033, 'Lease ownership scenario did not roll back its synthetic candidate.', 1;
END;

PRINT 'PASS:SCENARIO:LEASE_OWNERSHIP';

-- SCENARIO:LEASE_RENEWAL_AND_RELEASE
DECLARE @releaseCandidateId uniqueidentifier = 'A3000000-0000-4000-8000-000000000010';
DECLARE @releaseClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @releaseLeaseToken uniqueidentifier;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @releaseCandidateId,
        @account = N'SYNTHETIC-CLAIM-ACCOUNT',
        @branch = N'301',
        @reference = N'SYNTHETIC-RENEW-RELEASE',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-03-02T00:00:00.000+00:00',
        @payloadJson = @claimPayload,
        @actor = N'acceptance-api';

    INSERT INTO @releaseClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-worker-release',
        @maxCandidates = 1,
        @leaseDurationSeconds = 300;

    SELECT @releaseLeaseToken = [LeaseToken]
    FROM @releaseClaims
    WHERE [CandidateId] = @releaseCandidateId;

    EXEC [po].[sp_renew_purchase_order_claim]
        @candidateId = @releaseCandidateId,
        @leaseToken = @releaseLeaseToken,
        @workerId = N'acceptance-worker-release',
        @leaseDurationSeconds = 600;

    EXEC [po].[sp_release_purchase_order_claim]
        @candidateId = @releaseCandidateId,
        @leaseToken = @releaseLeaseToken,
        @workerId = N'acceptance-worker-release';

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @releaseCandidateId
          AND [Status] = 'READY_FOR_SUBMISSION'
          AND [LeaseToken] IS NULL
          AND [LeaseOwner] IS NULL
          AND [LeaseAcquiredDateTime] IS NULL
          AND [LeaseExpiresDateTime] IS NULL
          AND [PayloadJson] = @claimPayload
    )
    BEGIN
        ;THROW 52034, 'Valid renewal and release did not preserve the eligible candidate.', 1;
    END;

    IF
    (
        SELECT COUNT(*)
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @releaseCandidateId
    ) <> 1
    BEGIN
        ;THROW 52035, 'Pre-dispatch release created unexpected business audit noise.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

PRINT 'PASS:SCENARIO:LEASE_RENEWAL_AND_RELEASE';

-- SCENARIO:EXPIRED_PREDISPATCH_RECOVERY
DECLARE @expiryCandidateId uniqueidentifier = 'A3000000-0000-4000-8000-000000000020';
DECLARE @expiryClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @reclaimedCandidates TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @expiryResult TABLE
(
    [ReleasedBeforeDispatchCount] int NOT NULL,
    [UnknownOutcomeCount] int NOT NULL
);
DECLARE @expiryLeaseToken uniqueidentifier;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_create_purchase_order_candidate]
        @candidateId = @expiryCandidateId,
        @account = N'SYNTHETIC-CLAIM-ACCOUNT',
        @branch = N'301',
        @reference = N'SYNTHETIC-EXPIRED-PREDISPATCH',
        @status = 'READY_FOR_SUBMISSION',
        @acceptedDateTime = '2099-03-03T00:00:00.000+00:00',
        @payloadJson = @claimPayload,
        @actor = N'acceptance-api';

    INSERT INTO @expiryClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-worker-expiry',
        @maxCandidates = 1,
        @leaseDurationSeconds = 10;

    SELECT @expiryLeaseToken = [LeaseToken]
    FROM @expiryClaims
    WHERE [CandidateId] = @expiryCandidateId;

    UPDATE [po].[PurchaseOrderCandidate]
    SET [LeaseExpiresDateTime] = DATEADD(second, -1, SYSUTCDATETIME())
    WHERE [CandidateId] = @expiryCandidateId
      AND [LeaseToken] = @expiryLeaseToken;

    IF @@ROWCOUNT <> 1
    BEGIN
        ;THROW 52036, 'The pre-dispatch expiry fixture was not made stale.', 1;
    END;

    INSERT INTO @expiryResult
    EXEC [po].[sp_expire_purchase_order_claims]
        @actor = N'acceptance-expiry';

    IF NOT EXISTS
    (
        SELECT 1
        FROM @expiryResult
        WHERE [ReleasedBeforeDispatchCount] = 1
          AND [UnknownOutcomeCount] = 0
    )
    BEGIN
        ;THROW 52036, 'Pre-dispatch expiry did not report one released claim.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @expiryCandidateId
          AND [Status] = 'READY_FOR_SUBMISSION'
          AND [LeaseToken] IS NULL
          AND [PayloadJson] = @claimPayload
    )
    OR EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = attempt.[CandidateKey]
        WHERE candidate.[CandidateId] = @expiryCandidateId
    )
    BEGIN
        ;THROW 52037, 'Pre-dispatch expiry did not release the candidate without creating an attempt.', 1;
    END;

    IF
    (
        SELECT COUNT(*)
        FROM [po].[PurchaseOrderAudit] AS audit
        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
            ON candidate.[CandidateKey] = audit.[CandidateKey]
        WHERE candidate.[CandidateId] = @expiryCandidateId
    ) <> 1
    BEGIN
        ;THROW 52038, 'Pre-dispatch expiry created unexpected business audit noise.', 1;
    END;

    INSERT INTO @reclaimedCandidates
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-worker-reclaim',
        @maxCandidates = 1,
        @leaseDurationSeconds = 60;

    IF NOT EXISTS
    (
        SELECT 1
        FROM @reclaimedCandidates
        WHERE [CandidateId] = @expiryCandidateId
    )
    BEGIN
        ;THROW 52039, 'Expired pre-dispatch candidate did not become claimable again.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] IN (@releaseCandidateId, @expiryCandidateId)
)
BEGIN
    ;THROW 52040, 'Claim recovery acceptance cleanup did not roll back synthetic data.', 1;
END;

PRINT 'PASS:SCENARIO:EXPIRED_PREDISPATCH_RECOVERY';
