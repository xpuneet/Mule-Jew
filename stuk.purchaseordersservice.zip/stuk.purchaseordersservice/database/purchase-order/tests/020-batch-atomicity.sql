SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

DECLARE @payloadOne nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-BATCH-ACCOUNT","branch":201,"reference":"SYNTHETIC-BATCH-ONE"},"purchaseOrderLines":[]}';
DECLARE @payloadTwo nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-BATCH-ACCOUNT","branch":201,"reference":"SYNTHETIC-BATCH-TWO"},"purchaseOrderLines":[]}';
DECLARE @payloadThree nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-BATCH-ACCOUNT","branch":201,"reference":"SYNTHETIC-BATCH-THREE"},"purchaseOrderLines":[]}';
DECLARE @payloadFour nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-BATCH-ACCOUNT","branch":201,"reference":"SYNTHETIC-BATCH-FOUR"},"purchaseOrderLines":[]}';
DECLARE @payloadFive nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-BATCH-ACCOUNT","branch":201,"reference":"SYNTHETIC-BATCH-FIVE"},"purchaseOrderLines":[]}';
DECLARE @payloadConflict nvarchar(max) =
    N'{"purchaseOrderHeader":{"account":"SYNTHETIC-BATCH-ACCOUNT","branch":201,"reference":"SYNTHETIC-CONFLICT"},"purchaseOrderLines":[]}';

-- SCENARIO:DUPLICATE_RELEX_FILE
DECLARE @duplicateBatchOne uniqueidentifier = 'A2000000-0000-4000-8000-000000000001';
DECLARE @duplicateBatchTwo uniqueidentifier = 'A2000000-0000-4000-8000-000000000002';
DECLARE @duplicateHash binary(32) =
    0xA201A201A201A201A201A201A201A201A201A201A201A201A201A201A201A201;
DECLARE @duplicateRejected bit = 0;
DECLARE @firstRegistrationConfirmed bit = 0;
DECLARE @secondRegistrationAttempted bit = 0;
DECLARE @firstRegistrationResult TABLE
(
    [BatchId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO @firstRegistrationResult
    EXEC [po].[sp_register_purchase_order_batch]
        @batchId = @duplicateBatchOne,
        @originalFileName = N'SG_OrderProposal_duplicate-one.csv',
        @sourceFilePath = N'/data/input/SG_OrderProposal_duplicate-one.csv',
        @fileContentLength = 128,
        @fileSha256 = @duplicateHash,
        @expectedRowCount = NULL,
        @discoveredDateTime = '2099-02-01T00:00:00.000+00:00',
        @actor = N'acceptance-ingestion';

    IF NOT EXISTS
    (
        SELECT 1
        FROM @firstRegistrationResult
        WHERE [BatchId] = @duplicateBatchOne
          AND [Status] = 'INGESTING'
          AND [RowVersion] IS NOT NULL
    )
    BEGIN
        ;THROW 52026, 'The first Relex source file registration did not return the expected batch.', 1;
    END;

    -- FIRST_REGISTRATION_CONFIRMED
    SET @firstRegistrationConfirmed = 1;
    SET @secondRegistrationAttempted = 1;

    EXEC [po].[sp_register_purchase_order_batch]
        @batchId = @duplicateBatchTwo,
        @originalFileName = N'SG_OrderProposal_duplicate-two.csv',
        @sourceFilePath = N'/data/input/SG_OrderProposal_duplicate-two.csv',
        @fileContentLength = 128,
        @fileSha256 = @duplicateHash,
        @expectedRowCount = NULL,
        @discoveredDateTime = '2099-02-01T00:01:00.000+00:00',
        @actor = N'acceptance-ingestion';

    ;THROW 52020, 'Expected duplicate Relex source file registration to fail.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 51005
       AND @firstRegistrationConfirmed = 1
       AND @secondRegistrationAttempted = 1
    BEGIN
        -- SECOND_REGISTRATION_DUPLICATE_REJECTED
        SET @duplicateRejected = 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @duplicateRejected = 0
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] IN (@duplicateBatchOne, @duplicateBatchTwo)
)
BEGIN
    ;THROW 52021, 'Duplicate-file scenario did not roll back its synthetic batch.', 1;
END;

PRINT 'PASS:SCENARIO:DUPLICATE_RELEX_FILE';

-- SCENARIO:BATCH_DIFFERENT_ROW_AND_CANDIDATE_COUNTS
DECLARE @batchId uniqueidentifier = 'A2000000-0000-4000-8000-000000000010';
DECLARE @candidateOne uniqueidentifier = 'A2000000-0000-4000-8000-000000000011';
DECLARE @candidateTwo uniqueidentifier = 'A2000000-0000-4000-8000-000000000012';
DECLARE @candidateThree uniqueidentifier = 'A2000000-0000-4000-8000-000000000013';
DECLARE @candidateFour uniqueidentifier = 'A2000000-0000-4000-8000-000000000014';
DECLARE @candidateFive uniqueidentifier = 'A2000000-0000-4000-8000-000000000015';
DECLARE @batchHash binary(32) =
    0xA210A210A210A210A210A210A210A210A210A210A210A210A210A210A210A210;
DECLARE @batchRowVersion binary(8);
DECLARE @batchRegistration TABLE
(
    [BatchId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @sourceHashLookup TABLE
(
    [BatchId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [OriginalFileName] nvarchar(260) NOT NULL,
    [SourceFilePath] nvarchar(512) NOT NULL,
    [FileContentLength] bigint NOT NULL,
    [FileSha256] binary(32) NOT NULL,
    [Status] varchar(50) NOT NULL,
    [ExpectedRowCount] int NULL,
    [ParsedRowCount] int NOT NULL,
    [CandidateCount] int NOT NULL,
    [FailureCode] varchar(100) NULL,
    [FailureDescription] nvarchar(1000) NULL,
    [DiscoveredDateTime] datetimeoffset(3) NOT NULL,
    [IngestionStartedDateTime] datetimeoffset(3) NULL,
    [CompletedDateTime] datetimeoffset(3) NULL,
    [CreatedBy] nvarchar(256) NOT NULL,
    [UpdatedDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @completionResult TABLE
(
    [BatchId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [PromotedCandidateCount] int NOT NULL,
    [RowVersion] binary(8) NOT NULL
);

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO @batchRegistration
    EXEC [po].[sp_register_purchase_order_batch]
        @batchId = @batchId,
        @originalFileName = N'SG_OrderProposal_six-rows.csv',
        @sourceFilePath = N'/data/input/SG_OrderProposal_six-rows.csv',
        @fileContentLength = 512,
        @fileSha256 = @batchHash,
        @expectedRowCount = 6,
        @discoveredDateTime = '2099-02-02T00:00:00.000+00:00',
        @actor = N'acceptance-ingestion';

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @batchId,
        @candidateId = @candidateOne,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-BATCH-ONE',
        @sourceRowCount = 2,
        @acceptedDateTime = '2099-02-02T00:01:00.000+00:00',
        @payloadJson = @payloadOne,
        @actor = N'acceptance-ingestion';

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @batchId,
        @candidateId = @candidateTwo,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-BATCH-TWO',
        @sourceRowCount = 1,
        @acceptedDateTime = '2099-02-02T00:02:00.000+00:00',
        @payloadJson = @payloadTwo,
        @actor = N'acceptance-ingestion';

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @batchId,
        @candidateId = @candidateThree,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-BATCH-THREE',
        @sourceRowCount = 1,
        @acceptedDateTime = '2099-02-02T00:03:00.000+00:00',
        @payloadJson = @payloadThree,
        @actor = N'acceptance-ingestion';

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @batchId,
        @candidateId = @candidateFour,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-BATCH-FOUR',
        @sourceRowCount = 1,
        @acceptedDateTime = '2099-02-02T00:04:00.000+00:00',
        @payloadJson = @payloadFour,
        @actor = N'acceptance-ingestion';

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @batchId,
        @candidateId = @candidateFive,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-BATCH-FIVE',
        @sourceRowCount = 1,
        @acceptedDateTime = '2099-02-02T00:05:00.000+00:00',
        @payloadJson = @payloadFive,
        @actor = N'acceptance-ingestion';

    -- Exact idempotent replay: it must not change either stored count.
    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @batchId,
        @candidateId = @candidateOne,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-BATCH-ONE',
        @sourceRowCount = 2,
        @acceptedDateTime = '2099-02-02T00:01:00.000+00:00',
        @payloadJson = @payloadOne,
        @actor = N'acceptance-ingestion';

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderBatch]
        WHERE [BatchId] = @batchId
          AND [Status] = 'INGESTING'
          AND [CandidateCount] = 5
          AND [ParsedRowCount] = 6
    )
    BEGIN
        ;THROW 52022, 'Candidate replay changed the independent batch counts.', 1;
    END;

    INSERT INTO @sourceHashLookup
    EXEC [po].[sp_get_purchase_order_batch_by_source_hash]
        @source = N'Relex',
        @fileSha256 = @batchHash;

    IF NOT EXISTS
    (
        SELECT 1
        FROM @sourceHashLookup
        WHERE [BatchId] = @batchId
          AND [Source] = N'Relex'
          AND [SourceFilePath] = N'/data/input/SG_OrderProposal_six-rows.csv'
          AND [FileContentLength] = 512
          AND [CandidateCount] = 5
          AND [ParsedRowCount] = 6
    )
    BEGIN
        ;THROW 52023, 'Source/hash lookup did not return the registered Relex batch.', 1;
    END;

    SELECT @batchRowVersion = [RowVersion]
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @batchId;

    INSERT INTO @completionResult
    EXEC [po].[sp_complete_purchase_order_batch]
        @batchId = @batchId,
        @expectedCandidateCount = 5,
        @parsedRowCount = 6,
        @completedDateTime = '2099-02-02T00:06:00.000+00:00',
        @actor = N'acceptance-ingestion',
        @expectedBatchRowVersion = @batchRowVersion;

    IF NOT EXISTS
    (
        SELECT 1
        FROM @completionResult
        WHERE [BatchId] = @batchId
          AND [Status] = 'COMPLETED'
          AND [PromotedCandidateCount] = 5
    )
    BEGIN
        ;THROW 52024, 'Five candidates from six source rows were not promoted atomically.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @batchId
)
OR EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] IN
        (@candidateOne, @candidateTwo, @candidateThree, @candidateFour, @candidateFive)
)
BEGIN
    ;THROW 52025, 'Independent-count scenario did not roll back all synthetic rows.', 1;
END;

PRINT 'PASS:BATCH_DIFFERENT_ROW_AND_CANDIDATE_COUNTS';
PRINT 'PASS:BATCH_EXACT_CANDIDATE_REPLAY';
PRINT 'PASS:BATCH_SOURCE_HASH_LOOKUP';

-- SCENARIO:BATCH_CONFLICTING_CANDIDATE_REPLAY_REJECTED
DECLARE @conflictBatchId uniqueidentifier = 'A2000000-0000-4000-8000-000000000030';
DECLARE @conflictCandidateId uniqueidentifier = 'A2000000-0000-4000-8000-000000000031';
DECLARE @conflictHash binary(32) =
    0xA230A230A230A230A230A230A230A230A230A230A230A230A230A230A230A230;
DECLARE @conflictingReplayAttempted bit = 0;
DECLARE @conflictingReplayRejected bit = 0;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC [po].[sp_register_purchase_order_batch]
        @batchId = @conflictBatchId,
        @originalFileName = N'SG_OrderProposal_conflict.csv',
        @sourceFilePath = N'/data/input/SG_OrderProposal_conflict.csv',
        @fileContentLength = 256,
        @fileSha256 = @conflictHash,
        @expectedRowCount = 2,
        @discoveredDateTime = '2099-02-03T00:00:00.000+00:00',
        @actor = N'acceptance-ingestion';

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @conflictBatchId,
        @candidateId = @conflictCandidateId,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-BATCH-ONE',
        @sourceRowCount = 2,
        @acceptedDateTime = '2099-02-03T00:01:00.000+00:00',
        @payloadJson = @payloadOne,
        @actor = N'acceptance-ingestion';

    SET @conflictingReplayAttempted = 1;

    EXEC [po].[sp_add_purchase_order_candidate_to_batch]
        @batchId = @conflictBatchId,
        @candidateId = @conflictCandidateId,
        @account = N'SYNTHETIC-BATCH-ACCOUNT',
        @branch = N'201',
        @reference = N'SYNTHETIC-CONFLICT',
        @sourceRowCount = 1,
        @acceptedDateTime = '2099-02-03T00:02:00.000+00:00',
        @payloadJson = @payloadConflict,
        @actor = N'acceptance-ingestion';

    ;THROW 52027, 'Expected conflicting candidate replay to fail.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() = 51006
       AND @conflictingReplayAttempted = 1
    BEGIN
        SET @conflictingReplayRejected = 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    IF @conflictingReplayRejected = 0
    BEGIN
        THROW;
    END;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @conflictBatchId
)
OR EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate]
    WHERE [CandidateId] = @conflictCandidateId
)
BEGIN
    ;THROW 52028, 'Conflicting-replay scenario left synthetic rows.', 1;
END;

PRINT 'PASS:BATCH_CONFLICTING_CANDIDATE_REPLAY_REJECTED';

-- SCENARIO:BATCH_ZERO_BYTE_FAILURE
DECLARE @zeroBatchId uniqueidentifier = 'A2000000-0000-4000-8000-000000000040';
DECLARE @zeroHash binary(32) =
    0xA240A240A240A240A240A240A240A240A240A240A240A240A240A240A240A240;
DECLARE @zeroRowVersion binary(8);
DECLARE @zeroRegistration TABLE
(
    [BatchId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);
DECLARE @zeroFailure TABLE
(
    [BatchId] uniqueidentifier NOT NULL,
    [Status] varchar(50) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO @zeroRegistration
    EXEC [po].[sp_register_purchase_order_batch]
        @batchId = @zeroBatchId,
        @originalFileName = N'SG_OrderProposal_zero.csv',
        @sourceFilePath = N'/data/input/SG_OrderProposal_zero.csv',
        @fileContentLength = 0,
        @fileSha256 = @zeroHash,
        @expectedRowCount = NULL,
        @discoveredDateTime = '2099-02-04T00:00:00.000+00:00',
        @actor = N'acceptance-ingestion';

    SELECT @zeroRowVersion = [RowVersion]
    FROM @zeroRegistration
    WHERE [BatchId] = @zeroBatchId;

    INSERT INTO @zeroFailure
    EXEC [po].[sp_fail_purchase_order_batch]
        @batchId = @zeroBatchId,
        @failureCode = 'RELEX_EMPTY_FILE',
        @failureDescription = N'Relex CSV file is empty.',
        @failedDateTime = '2099-02-04T00:01:00.000+00:00',
        @actor = N'acceptance-ingestion',
        @expectedBatchRowVersion = @zeroRowVersion;

    IF NOT EXISTS
    (
        SELECT 1
        FROM @zeroFailure
        WHERE [BatchId] = @zeroBatchId
          AND [Status] = 'FAILED'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderBatch]
        WHERE [BatchId] = @zeroBatchId
          AND [FileContentLength] = 0
          AND [Status] = 'FAILED'
          AND [FailureCode] = 'RELEX_EMPTY_FILE'
    )
    BEGIN
        ;THROW 52029, 'Zero-byte Relex batch was not registered and failed safely.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @zeroBatchId
)
BEGIN
    ;THROW 52030, 'Zero-byte failure scenario did not roll back its synthetic batch.', 1;
END;

PRINT 'PASS:BATCH_ZERO_BYTE_FAILURE';
