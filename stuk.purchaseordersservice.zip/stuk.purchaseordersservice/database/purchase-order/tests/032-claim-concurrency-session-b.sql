SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

-- CONCURRENCY_PROTOCOL:SESSION_B
DECLARE @concurrencyCandidateId uniqueidentifier = 'A3100000-0000-4000-8000-000000000001';
DECLARE @sessionBClaims TABLE
(
    [CandidateId] uniqueidentifier NOT NULL,
    [Source] nvarchar(50) NOT NULL,
    [Account] nvarchar(50) NOT NULL,
    [Branch] nvarchar(20) NOT NULL,
    [Reference] nvarchar(100) NULL,
    [Status] varchar(50) NOT NULL,
    [PayloadJson] nvarchar(max) NOT NULL,
    [LeaseToken] uniqueidentifier NOT NULL,
    [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
    [RowVersion] binary(8) NOT NULL
);

IF @@LOCK_TIMEOUT <> -1
BEGIN
    ;THROW 52047, 'Session B requires a fresh dedicated session with the default LOCK_TIMEOUT of -1.', 1;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderCandidate] WITH (READUNCOMMITTED)
    WHERE [CandidateId] = @concurrencyCandidateId
      AND [LeaseOwner] = N'acceptance-concurrency-session-a'
      AND [LeaseToken] IS NOT NULL
)
BEGIN
    ;THROW 52044, 'Session A lease is not visible; wait for SESSION_A_READY and rerun Session B.', 1;
END;

SET LOCK_TIMEOUT 5000;

BEGIN TRY
    -- The outer transaction contains any nested procedure commit and is always rolled back.
    BEGIN TRANSACTION;

    INSERT INTO @sessionBClaims
    EXEC [po].[sp_claim_purchase_order_candidates]
        @workerId = N'acceptance-concurrency-session-b',
        @maxCandidates = 1,
        @leaseDurationSeconds = 300;

    IF EXISTS (SELECT 1 FROM @sessionBClaims)
    BEGIN
        ;THROW 52045, 'Session B claimed a row while Session A held the exclusive claim lock.', 1;
    END;

    -- POST_CLAIM_SESSION_A_LEASE_PROOF
    -- This dirty read is intentionally limited to the fixed synthetic coordination row.
    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate] WITH (READUNCOMMITTED)
        WHERE [CandidateId] = @concurrencyCandidateId
          AND [LeaseOwner] = N'acceptance-concurrency-session-a'
          AND [LeaseToken] IS NOT NULL
    )
    BEGIN
        ;THROW 52048, 'Session A no longer held the synthetic lease after Session B returned no claim.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    SET LOCK_TIMEOUT -1;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    SET LOCK_TIMEOUT -1;
    THROW;
END CATCH;

IF @@LOCK_TIMEOUT <> -1
BEGIN
    ;THROW 52049, 'Session B did not restore the connection LOCK_TIMEOUT.', 1;
END;

PRINT 'PASS:SESSION_B_EXCLUSIVE_CLAIM - READPAST skipped the candidate locked by Session A.';
