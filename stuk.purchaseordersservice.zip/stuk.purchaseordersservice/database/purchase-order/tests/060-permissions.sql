SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;

-- SCENARIO:ROLE_EXECUTE_ALLOWLIST
-- SCENARIO:NO_DIRECT_TABLE_DML
-- SCENARIO:DOCUMENTED_INDEXES
-- SCENARIO:API_CONFIGURATION_ISOLATED_TABLE_EXECUTE_AS_ROLE
DECLARE @expectedRoles TABLE
(
    [RoleName] sysname NOT NULL PRIMARY KEY
);
INSERT INTO @expectedRoles ([RoleName])
VALUES (N'po_service_executor');

DECLARE @expectedGrants TABLE
(
    [RoleName] sysname NOT NULL,
    [ProcedureName] sysname NOT NULL,
    PRIMARY KEY ([RoleName], [ProcedureName])
);
INSERT INTO @expectedGrants ([RoleName], [ProcedureName])
VALUES
    (N'po_service_executor', N'sp_get_application_settings'),
    (N'po_service_executor', N'sp_create_purchase_order_candidate'),
    (N'po_service_executor', N'sp_search_purchase_order_candidates'),
    (N'po_service_executor', N'sp_register_purchase_order_batch'),
    (N'po_service_executor', N'sp_add_purchase_order_candidate_to_batch'),
    (N'po_service_executor', N'sp_complete_purchase_order_batch'),
    (N'po_service_executor', N'sp_fail_purchase_order_batch'),
    (N'po_service_executor', N'sp_get_purchase_order_batch'),
    (N'po_service_executor', N'sp_get_purchase_order_batch_by_source_hash'),
    (N'po_service_executor', N'sp_claim_purchase_order_candidates'),
    (N'po_service_executor', N'sp_renew_purchase_order_claim'),
    (N'po_service_executor', N'sp_release_purchase_order_claim'),
    (N'po_service_executor', N'sp_expire_purchase_order_claims'),
    (N'po_service_executor', N'sp_get_purchase_order_candidate'),
    (N'po_service_executor', N'sp_begin_purchase_order_submission_attempt'),
    (N'po_service_executor', N'sp_fail_purchase_order_candidate_pre_dispatch'),
    (N'po_service_executor', N'sp_complete_purchase_order_submission'),
    (N'po_service_executor', N'sp_fail_purchase_order_submission'),
    (N'po_service_executor', N'sp_request_purchase_order_retry'),
    (N'po_service_executor', N'sp_cancel_purchase_order_candidate'),
    (N'po_service_executor', N'sp_get_purchase_order_audit'),
    (N'po_service_executor', N'sp_get_purchase_order_batch_outcomes'),
    (N'po_service_executor', N'sp_register_purchase_order_notification'),
    (N'po_service_executor', N'sp_complete_purchase_order_notification'),
    (N'po_service_executor', N'sp_enqueue_purchase_order_email_notification'),
    (N'po_service_executor', N'sp_claim_purchase_order_email_notifications'),
    (N'po_service_executor', N'sp_defer_purchase_order_email_notification'),
    (N'po_service_executor', N'sp_reschedule_purchase_order_email_notification'),
    (N'po_service_executor', N'sp_complete_purchase_order_email_notification'),
    (N'po_service_executor', N'sp_get_purchase_order_email_notification_queue_summary'),
    (N'po_service_executor', N'sp_prepare_and_claim_relex_notification_events'),
    (N'po_service_executor', N'sp_save_relex_notification_envelope'),
    (N'po_service_executor', N'sp_complete_relex_notification_event'),
    (N'po_service_executor', N'sp_get_purchase_order_candidate_summary'),
    (N'po_service_executor', N'sp_get_purchase_order_batch_summary'),
    (N'po_service_executor', N'sp_search_purchase_order_batches'),
    (N'po_service_executor', N'sp_get_purchase_order_batch_candidate_summary'),
    (N'po_service_executor', N'sp_search_purchase_order_batch_candidates');

DECLARE @expectedIndexes TABLE
(
    [TableName] sysname NOT NULL,
    [IndexName] sysname NOT NULL,
    PRIMARY KEY ([TableName], [IndexName])
);
INSERT INTO @expectedIndexes ([TableName], [IndexName])
VALUES
    (N'ApplicationSetting', N'PK_PO_ApplicationSetting'),
    (N'PurchaseOrderBatch', N'PK_PO_Batch'),
    (N'PurchaseOrderBatch', N'UQ_PO_Batch_BatchId'),
    (N'PurchaseOrderBatch', N'UX_PO_Batch_Source_FileSha256'),
    (N'PurchaseOrderBatch', N'IX_PO_Batch_Status_DiscoveredDateTime'),
    (N'PurchaseOrderCandidate', N'PK_PO_Candidate'),
    (N'PurchaseOrderCandidate', N'UQ_PO_Candidate_CandidateId'),
    (N'PurchaseOrderCandidate', N'IX_PO_Candidate_Source_Status_AcceptedDateTime'),
    (N'PurchaseOrderCandidate', N'IX_PO_Candidate_Source_Account_Branch_Reference'),
    (N'PurchaseOrderCandidate', N'IX_PO_Candidate_IconPurchaseOrderNumber'),
    (N'PurchaseOrderCandidate', N'IX_PO_Candidate_Status_LeaseExpires_AcceptedDateTime'),
    (N'PurchaseOrderCandidate', N'IX_PO_Candidate_BatchKey_CandidateKey'),
    (N'PurchaseOrderSubmissionAttempt', N'PK_PO_Attempt'),
    (N'PurchaseOrderSubmissionAttempt', N'UQ_PO_Attempt_AttemptId'),
    (N'PurchaseOrderSubmissionAttempt', N'UX_PO_Attempt_CandidateKey_AttemptNumber'),
    (N'PurchaseOrderSubmissionAttempt', N'IX_PO_Attempt_Status_DispatchedDateTime'),
    (N'PurchaseOrderAudit', N'PK_PO_Audit'),
    (N'PurchaseOrderAudit', N'IX_PO_Audit_CandidateKey_ChangedDateTime'),
    (N'PurchaseOrderNotification', N'PK_PO_Notification'),
    (N'PurchaseOrderNotification', N'UQ_PO_Notification_NotificationId'),
    (N'PurchaseOrderNotification', N'IX_PO_Notification_DueWork'),
    (N'PurchaseOrderNotification', N'IX_PO_Notification_BatchKey_CreatedDateTime'),
    (N'PurchaseOrderNotificationAttempt', N'PK_PO_NotificationAttempt'),
    (N'PurchaseOrderNotificationAttempt', N'UQ_PO_NotificationAttempt_AttemptId'),
    (N'PurchaseOrderNotificationAttempt', N'UQ_PO_NotificationAttempt_NotificationKey_AttemptNumber'),
    (N'PurchaseOrderNotificationAttempt', N'IX_PO_NotificationAttempt_StartedDateTime'),
    (N'RelexNotificationEvent', N'PK_PO_RelexEvent'),
    (N'RelexNotificationEvent', N'UQ_PO_RelexEvent_NotificationId'),
    (N'RelexNotificationEvent', N'IX_PO_RelexEvent_DueWork'),
    (N'RelexNotificationEvent', N'UX_PO_RelexEvent_Batch'),
    (N'RelexNotificationEvent', N'IX_PO_RelexEvent_ProcessedFile');

DECLARE @isImpersonating bit = 0;

BEGIN TRY
    BEGIN TRANSACTION;

    IF DATABASE_PRINCIPAL_ID(N'po_acceptance_service_executor') IS NOT NULL
    BEGIN
        ;THROW 52075, 'The guarded synthetic API acceptance user already exists.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM [po].[ApplicationSetting]
        WHERE [Context] IN (N'Common', N'WebApi')
          AND [Key] IN (N'Acceptance:SharedKey', N'Acceptance:CommonOnly')
    )
    BEGIN
        ;THROW 52078, 'A guarded application-settings acceptance fixture already exists.', 1;
    END;

    CREATE USER [po_acceptance_service_executor] WITHOUT LOGIN;
    ALTER ROLE [po_service_executor] ADD MEMBER [po_acceptance_service_executor];

    INSERT INTO [po].[ApplicationSetting] ([Context], [Key], [Value])
    VALUES
        (N'Common', N'Acceptance:SharedKey', N'common-value'),
        (N'WebApi', N'Acceptance:SharedKey', N'web-api-value'),
        (N'Common', N'Acceptance:CommonOnly', N'common-only-value');

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.database_role_members AS roleMembership
        INNER JOIN sys.database_principals AS workloadRole
            ON workloadRole.[principal_id] = roleMembership.[role_principal_id]
        INNER JOIN sys.database_principals AS memberPrincipal
            ON memberPrincipal.[principal_id] = roleMembership.[member_principal_id]
        WHERE workloadRole.[name] = N'po_service_executor'
          AND memberPrincipal.[name] = N'po_acceptance_service_executor'
    )
    OR EXISTS
    (
        SELECT 1
        FROM sys.database_role_members AS roleMembership
        INNER JOIN sys.database_principals AS workloadRole
            ON workloadRole.[principal_id] = roleMembership.[role_principal_id]
        INNER JOIN sys.database_principals AS memberPrincipal
            ON memberPrincipal.[principal_id] = roleMembership.[member_principal_id]
        WHERE workloadRole.[name] <> N'po_service_executor'
          AND memberPrincipal.[name] = N'po_acceptance_service_executor'
    )
    BEGIN
        ;THROW 52076, 'The synthetic service acceptance user must have no explicit role membership except po_service_executor.', 1;
    END;

    EXECUTE AS USER = N'po_acceptance_service_executor';
    SET @isImpersonating = 1;

    CREATE TABLE #applicationSettings
    (
        [key] nvarchar(256) NOT NULL,
        [value] nvarchar(max) NULL
    );

    INSERT INTO #applicationSettings ([key], [value])
    EXEC [po].[sp_get_application_settings]
        @contextList = N'Common,WebApi';

    REVERT;
    SET @isImpersonating = 0;

    IF NOT EXISTS
    (
        SELECT 1
        FROM #applicationSettings
        WHERE [key] = N'Acceptance:SharedKey'
          AND [value] = N'web-api-value'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM #applicationSettings
        WHERE [key] = N'Acceptance:CommonOnly'
          AND [value] = N'common-only-value'
    )
    OR (SELECT COUNT_BIG(*) FROM #applicationSettings) <> 2
    BEGIN
        ;THROW 52077, 'The isolated application-settings procedure did not apply last-context precedence.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM @expectedRoles AS expected
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM sys.database_principals AS principal
            WHERE principal.[name] = expected.[RoleName]
              AND principal.[type] = N'R'
        )
    )
    BEGIN
        ;THROW 52070, 'An expected Purchase Order workload role is missing.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM @expectedGrants AS expected
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM sys.database_permissions AS permission
            INNER JOIN sys.database_principals AS principal
                ON principal.[principal_id] = permission.[grantee_principal_id]
            INNER JOIN sys.objects AS procedureObject
                ON procedureObject.[object_id] = permission.[major_id]
            INNER JOIN sys.schemas AS procedureSchema
                ON procedureSchema.[schema_id] = procedureObject.[schema_id]
            WHERE permission.[class] = 1
              AND permission.[minor_id] = 0
              AND permission.[permission_name] = N'EXECUTE'
              AND permission.[state] = N'G'
              AND principal.[name] = expected.[RoleName]
              AND procedureSchema.[name] = N'po'
              AND procedureObject.[name] = expected.[ProcedureName]
              AND procedureObject.[type] IN (N'P', N'PC')
        )
    )
    BEGIN
        ;THROW 52071, 'An expected Purchase Order procedure EXECUTE grant is missing.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM sys.database_permissions AS permission
        INNER JOIN sys.database_principals AS principal
            ON principal.[principal_id] = permission.[grantee_principal_id]
        LEFT JOIN sys.objects AS procedureObject
            ON permission.[class] = 1
           AND procedureObject.[object_id] = permission.[major_id]
        LEFT JOIN sys.schemas AS procedureSchema
            ON procedureSchema.[schema_id] = procedureObject.[schema_id]
        INNER JOIN @expectedRoles AS workloadRole
            ON workloadRole.[RoleName] = principal.[name]
        WHERE NOT
        (
            permission.[class] = 1
            AND permission.[minor_id] = 0
            AND permission.[permission_name] = N'EXECUTE'
            AND permission.[state] = N'G'
            AND procedureSchema.[name] = N'po'
            AND procedureObject.[type] IN (N'P', N'PC')
            AND EXISTS
            (
                SELECT 1
                FROM @expectedGrants AS expected
                WHERE expected.[RoleName] = principal.[name]
                  AND expected.[ProcedureName] = procedureObject.[name]
            )
        )
    )
    BEGIN
        ;THROW 52072, 'A Purchase Order workload role has a permission outside the exact procedure allowlist.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM sys.database_permissions AS permission
        INNER JOIN sys.database_principals AS principal
            ON principal.[principal_id] = permission.[grantee_principal_id]
        INNER JOIN @expectedRoles AS workloadRole
            ON workloadRole.[RoleName] = principal.[name]
        WHERE permission.[permission_name] IN (N'SELECT', N'INSERT', N'UPDATE', N'DELETE')
          AND permission.[state] IN (N'G', N'W')
          AND
          (
              permission.[class] IN (0, 3)
              OR
              (
                  permission.[class] = 1
                  AND EXISTS
                  (
                      SELECT 1
                      FROM sys.objects AS tableObject
                      WHERE tableObject.[object_id] = permission.[major_id]
                        AND tableObject.[schema_id] = SCHEMA_ID(N'po')
                        AND tableObject.[type] = N'U'
                  )
              )
          )
    )
    BEGIN
        ;THROW 52073, 'A Purchase Order workload role has forbidden direct table DML.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM @expectedIndexes AS expected
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM sys.indexes AS [index]
            INNER JOIN sys.tables AS [table]
                ON [table].[object_id] = [index].[object_id]
            WHERE [table].[schema_id] = SCHEMA_ID(N'po')
              AND [table].[name] = expected.[TableName]
              AND [index].[name] = expected.[IndexName]
              AND [index].[is_disabled] = 0
              AND [index].[is_hypothetical] = 0
        )
    )
    OR
    (
        SELECT COUNT_BIG(*)
        FROM sys.indexes AS [index]
        INNER JOIN sys.tables AS [table]
            ON [table].[object_id] = [index].[object_id]
        WHERE [table].[schema_id] = SCHEMA_ID(N'po')
          AND [index].[index_id] > 0
          AND [index].[name] IS NOT NULL
    ) <> (SELECT COUNT_BIG(*) FROM @expectedIndexes)
    BEGIN
        ;THROW 52074, 'The documented Purchase Order index inventory is not exact and enabled.', 1;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;
END TRY
BEGIN CATCH
    IF @isImpersonating = 1
    BEGIN
        REVERT;
        SET @isImpersonating = 0;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;

PRINT 'PASS:SCENARIO:ROLE_EXECUTE_ALLOWLIST';
PRINT 'PASS:SCENARIO:NO_DIRECT_TABLE_DML';
PRINT 'PASS:SCENARIO:DOCUMENTED_INDEXES';
PRINT 'PASS:SCENARIO:API_CONFIGURATION_ISOLATED_TABLE_EXECUTE_AS_ROLE';
