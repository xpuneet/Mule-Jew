# Purchase Order database acceptance scripts

These scripts are a database-team acceptance pack for an **approved disposable/non-production database** only. They exercise stored procedures and, where needed, inspect or clean synthetic rows directly. Never run them against production or a shared environment containing business data.

The numbered deployment package must already be applied and `100-verify.sql` must pass. Use a database with no pre-existing claimable Purchase Order candidates or active leases. All identifiers, accounts, branches, actors, timestamps, hashes, file names, and payloads in this directory are synthetic.

All Purchase Order processors and writers must be quiesced for the complete execution window of every stateful scenario, including timers, Function App processors, API writers, Relex ingestion, support tools, and manual database sessions. Keep them stopped until each script has rolled back or the two-session protocol has printed `PASS:CLEANUP_COMPLETE`; otherwise a preflight can become stale and the result is invalid.

Every script fails closed unless the SQLCMD variable `AllowDestructiveAcceptanceTests` has the exact value `1`. Do not edit the guard out of a script and do not store credentials in this directory.

## Run with sqlcmd

From `database/purchase-order/tests`, use approved Microsoft Entra authentication (shown with `-G`) or replace only the authentication flags with the database team's approved equivalent:

```bash
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "010-api-and-json.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "020-batch-atomicity.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "030-claim-recovery.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "040-attempt-outcomes.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "050-support-notification.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "055-webapp.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "056-email-notification-outbox.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "059-relex-notification-events.sql"
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "060-permissions.sql"
```

`-b` gives the calling shell a failing exit code after a `THROW`. A successful script prints one or more named `PASS:` lines. Most scenarios wrap synthetic mutations in transactions and roll them back. The pre-dispatch rejection scenarios in `040-attempt-outcomes.sql` must instead commit one fixed-ID fixture because an expected procedure failure rolls back the caller transaction; the script deletes that exact fixture in foreign-key order on both success and failure. No successful script retains synthetic rows. `060-permissions.sql` additionally creates rollback-only synthetic `Common` and `WebApi` settings plus a synthetic `USER WITHOUT LOGIN`, gives the user no explicit role membership except `po_service_executor`, executes `po.sp_get_application_settings` under that user, proves that the last requested context wins, and validates captured settings without emitting key/value data. Rollback removes the settings, user, and role membership.

## Run with SSMS SQLCMD mode

1. Connect SSMS to the approved disposable/non-production database.
2. Enable **Query > SQLCMD Mode**.
3. Save a small driver `.sql` file, set `AcceptanceRoot` to the explicit absolute path of this tests directory, and invoke one script at a time:

```sql
:setvar AcceptanceRoot "C:\absolute\path\to\repository\database\purchase-order\tests"
:setvar AllowDestructiveAcceptanceTests "1"
:r "$(AcceptanceRoot)\010-api-and-json.sql"
```

Do not rely on the SSMS current directory or a relative `:r` path. Change only the `:r` file name for the remaining single-session scripts in the sqlcmd order above. Stop immediately on a `THROW`; retain the complete Messages output for the database-team evidence record.

## Two-session claim exclusivity protocol

The concurrency pair is intentionally separate because Session A must commit a synthetic fixture, hold the claim update lock while Session B attempts a claim, then remove the fixture. Keep all Purchase Order processors and writers quiesced and use two fresh, dedicated terminals or two SSMS query windows connected to the same isolated database. Session B requires the default connection `LOCK_TIMEOUT` of `-1`, temporarily changes it to 5000 milliseconds, and restores `-1` on success and failure.

1. In **Session A**, start `031-claim-concurrency-session-a.sql` with `AllowDestructiveAcceptanceTests=1`.
2. Wait until Session A emits `PASS:SESSION_A_READY` with `RAISERROR ... WITH NOWAIT`. It then waits for 45 seconds while retaining the outer claim transaction and update lock.
3. During that 45-second window, run `032-claim-concurrency-session-b.sql` in **Session B** with the same guard variable. Expect `PASS:SESSION_B_EXCLUSIVE_CLAIM`.
4. Let Session A continue. It rolls back the held claim, deletes the committed synthetic fixture, and prints `PASS:CLEANUP_COMPLETE`.
5. Do not rerun Session B after Session A reports cleanup.

The Session B readiness probe uses `WITH (READUNCOMMITTED)` only to observe the fixed synthetic coordination row without blocking behind Session A. The actual exclusivity assertion is the call to `po.sp_claim_purchase_order_candidates`, whose `READPAST` locking behavior must return no candidate. Session B wraps that call in an outer transaction which it always rolls back, then performs a second nonblocking fixed-row probe to prove Session A still owns a non-null lease. An empty result is not accepted after Session A has rolled back or removed the fixture.

Equivalent sqlcmd commands are:

```bash
# Terminal / Session A
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "031-claim-concurrency-session-a.sql"

# Terminal / Session B, only after SESSION_A_READY
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "032-claim-concurrency-session-b.sql"
```

### Interrupted Session A cleanup

Never cancel Session A during `WAITFOR`; let the script reach `PASS:CLEANUP_COMPLETE`. Session A performs the same fixed-ID cleanup before and after its scenario and also attempts it in its error handler.

If a cancellation is sent while the same Session A connection remains alive, use that same Session A connection and first recover the open transaction with this exact statement:

```sql
IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
```

Only then run the cleanup below. If the client connection is terminated instead, a client disconnect automatically rolls back its open transaction. Wait until the original Session A has ended before using another session for cleanup; cleanup from another session can block while the original transaction is still alive.

Remove only the fixed synthetic candidate identifier `A3100000-0000-4000-8000-000000000001` in foreign-key order:

```sql
BEGIN TRANSACTION;

DELETE attempt
FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
    ON candidate.[CandidateKey] = attempt.[CandidateKey]
WHERE candidate.[CandidateId] = 'A3100000-0000-4000-8000-000000000001';

DELETE audit
FROM [po].[PurchaseOrderAudit] AS audit
INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
    ON candidate.[CandidateKey] = audit.[CandidateKey]
WHERE candidate.[CandidateId] = 'A3100000-0000-4000-8000-000000000001';

DELETE FROM [po].[PurchaseOrderCandidate]
WHERE [CandidateId] = 'A3100000-0000-4000-8000-000000000001';

COMMIT TRANSACTION;
```

Confirm that the candidate no longer exists before starting the pair again. If cleanup fails, stop and ask the database owner to inspect the synthetic identifier; cleanup cannot broaden beyond that exact `CandidateId`, and the delete criteria must never be widened.

## Two-session email quota protocol

Run the email scenarios only against an empty email queue and attempt history in an approved
disposable/non-production database, with every email sender and writer stopped. The single-session
`056-email-notification-outbox.sql` command above proves enqueue replay and identity validation,
optional batch association, ordering and minute/hour capacity including out-of-order caller timestamps,
active/expired leases, deferral,
transient/throttle counters, terminal outcomes including eight transient failures, stale ownership,
legacy isolation, summary metrics, independent attempt-ID uniqueness, and UTC/JSON/state/size guards.
It rejects HTTP 429 on transient reschedule and every completion path, and rejects THROTTLED without
HTTP 429, while the valid throttle path increments only ThrottleCount.
Each expected failure has its own transaction because procedure failure rolls back the caller's
transaction. It retains no fixtures.

The email concurrency pair intentionally commits exactly one quota spend. Use two fresh connections
to the same database:

1. Start Session A with the command below. A alone pre-cleans the two fixed notification IDs,
   deleting attempts before notifications, then seeds and commits two due notifications. A opens
   a separate outer transaction and claims one with both minute and hour quotas set to 1.
2. Immediately when A emits `PASS:SESSION_A_READY`, start Session B. A holds the transaction-owned
   exclusive application lock for five seconds with `WAITFOR DELAY '00:00:05'`.
3. B begins an outer transaction and uses APPLOCK_TEST to prove an exclusive transaction-owned lock
   on po.email-notification-claim-quota is unavailable. It must print
   `PASS:SESSION_B_QUOTA_LOCK_CONTENTION_CONFIRMED` before calling claim; starting B after A commits
   fails this assertion. B then enters claim and blocks until A commits, within the ten-second
   application-lock timeout.
   A prints `PASS:SESSION_A_COMMITTED`. B must return zero rows while proving one notification
   is still due and exactly one attempt was committed, then prints
   `PASS:SESSION_B_QUOTA_NOT_DOUBLE_SPENT` after committing its outer claim transaction.
4. B deletes only the two fixed fixtures in foreign-key order and prints `PASS:CLEANUP_COMPLETE`.
   B never pre-cleans: A owns the seed data until B has performed its claim.

```bash
# Session A
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "057-email-notification-concurrency-session-a.sql"
# Session B, immediately after SESSION_A_READY
sqlcmd -S "<server>" -d "<database>" -G -b -v AllowDestructiveAcceptanceTests=1 -i "058-email-notification-concurrency-session-b.sql"
```

Both scripts use `SET XACT_ABORT ON` and roll back any open transaction in their catch before
repeating idempotent fixed-ID cleanup. The Session B readiness probe uses `READUNCOMMITTED`
only to observe A's uncommitted claim update on committed synthetic fixtures. APPLOCK_TEST separately
proves lock contention, and the actual claim uses the production locks.
Do not cancel A during its five-second wait. If a connection is interrupted, first roll back
any still-open transaction on that connection or let disconnect recovery finish. If B was never
started, or cleanup was interrupted, wait until A has ended and run this exact cleanup:

```sql
BEGIN TRANSACTION;
DELETE attempt
FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
INNER JOIN [po].[PurchaseOrderNotification] AS notification
    ON notification.[NotificationKey] = attempt.[NotificationKey]
WHERE notification.[NotificationId] IN
    ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
DELETE FROM [po].[PurchaseOrderNotification]
WHERE [NotificationId] IN
    ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
COMMIT TRANSACTION;
```

Never broaden these cleanup identifiers. Retain both sessions' output as acceptance evidence.
These scripts have only static repository validation until the database team executes the protocol.

## Coverage and automation boundary

`059-relex-notification-events.sql` additionally requires empty batch, Relex event, and email
outbox tables. Its rollback-only fixtures prove finished-candidate readiness, mixed-success/failure
snapshots, empty/failed/pending/leased/dispatched/incomplete exclusion, freshness equality,
initial-processing history after a manual retry, first-envelope-wins behavior, expired-lease replay
under changed configuration, confirmed-outbox completion, stale-lease rejection, and large-snapshot
isolation. The normal test suite validates repository mappings and deployment inventory; it does
not execute this SQL or establish database/runtime readiness.
Run this acceptance on the database's intended `READ_COMMITTED_SNAPSHOT` setting, including `ON`
for Azure SQL. The claim uses `READCOMMITTEDLOCK` alongside `READPAST` and `UPDLOCK` so an RCSI
database can use the same code. Record `is_read_committed_snapshot_on` in the acceptance evidence.
Claims also cap their aggregate UTF-16 payload at 32 MiB, except that the first individually bounded
event is always admitted to ensure progress. The row-count setting is an upper bound, not a promise.
The first event can contain at most 16 MiB outcomes, 20 MiB envelope, and 64 KiB settings. Batches
above 100,000 candidates are classified before materializing outcome strings.

The new `036-relex-notification-events.sql` migration and `081-relex-notification-procedures.sql`
are part of the complete deployment driver. Re-run `100-verify.sql` after deployment; do not execute
either addition as an incomplete standalone deployment. Producer events freeze configuration and
outcomes separately from delivery status. `ENQUEUED` means the existing durable email outbox owns
delivery; it does not prove SMTP acceptance or mailbox delivery. `FAILED` events, including
`OUTCOME_SNAPSHOT_TOO_LARGE`, need operator investigation and an explicitly reviewed recovery.
Turning off one scenario stops new events of that kind; previously created events remain eligible
while the producer runs. Pausing the whole producer stops event claims.

Before acceptance, use two controlled sessions to check `po.relex-notification-prepare` lock
contention and non-overlapping leases, and inspect candidate/support-retry blocking under a real
SQL execution plan. Preparation takes its application lock before batch/candidate/attempt locks;
business submission and support operations already take candidate locks before attempt locks.
Deadlock/transient SQL failures must be retried by a later timer run. No SMTP call is made inside a
SQL transaction. Keep writers stopped during the scripted acceptance scenarios above; any
concurrency experiment needs a separate approved synthetic fixture and recorded cleanup.

The pack covers JSON/status rollback, repeated API payloads, deterministic paging and index inventory, dashboard status summaries over a half-open accepted-time range, source isolation, accepted-time search filtering, duplicate Relex files, five-candidate/six-source-row batch promotion, exact and conflicting candidate replay, source/hash reconciliation, zero-byte file failure, lease ownership and expiry, two-session exclusivity, attempt ordering and outcomes, pre-dispatch recoverable and non-recoverable failures, wrong-lease/ineligible-status/dispatched-attempt rejection, unknown-outcome non-eligibility, optimistic concurrency for support/notification operations, the exact `po_service_executor` procedure allowlist, absence of direct service-role table DML, and the isolated `po.ApplicationSetting` execution path with last-context precedence. The configuration check relies on same-owner chaining, not `WITH EXECUTE AS OWNER`, and rolls back its synthetic settings, user, and role membership.

The normal `dotnet test` never executes these scripts. Repository tests only inspect their static safety and contract markers. A database engineer must run the SQL manually in the approved environment and retain the named PASS output.

## Required manual query-plan validation

Index inventory checks do not prove which access path the SQL optimizer will choose. After the
guarded scripts pass and before database acceptance is signed off, a database engineer must run a
manual query-plan validation in the same approved non-production environment using representative
synthetic data volume and distribution. This step is not executed by the acceptance SQL scripts or
normal `dotnet test`.

1. Populate or select an approved synthetic dataset whose row counts, status selectivity, lease
   distribution, source/account/branch distribution, and audit/notification history are
   representative enough for plan review. Do not use or retain production payloads.
2. Capture actual execution plans, or the database team's approved Query Store equivalent, for
   representative calls to candidate search, candidate claim, batch lookup/outcomes, audit paging,
   and pending-notification access paths. Parameter values and result data must remain synthetic.
3. Review seeks, scans, sorts, key lookups, estimates, memory grants, and blocking operators against
   the documented index intent. A scan over a deliberately small fixture is not by itself a failure;
   record the optimizer choice and the engineer's assessment instead of forcing an index hint.
4. Retain the reviewed execution-plan evidence, dataset profile, database compatibility level,
   statistics state, UTC capture time, and reviewer sign-off in the database change record. Record
   any required index or procedure change as a reviewed forward fix, then rerun verification,
   guarded acceptance, and this manual plan review.
