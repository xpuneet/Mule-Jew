SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;
SET XACT_ABORT ON;

DECLARE @claimed TABLE
(
    [NotificationId] uniqueidentifier, [EventType] varchar(100), [BusinessCorrelationId] nvarchar(256),
    [EmailEnvelopeVersion] smallint, [EmailEnvelopeJson] nvarchar(max), [PayloadSha256] binary(32),
    [AttemptCount] int, [FailureCount] int, [ThrottleCount] int,
    [LeaseId] uniqueidentifier, [LeaseExpiresDateTime] datetimeoffset(3), [RowVersion] binary(8)
);
DECLARE @asOf datetimeoffset(3) = '2099-07-01T00:00:00.000+00:00';
BEGIN TRY
    -- CLEANUP_SCOPE:FIXED_NOTIFICATION_IDS_ONLY
    DELETE attempt
    FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderNotification] AS notification
        ON notification.[NotificationKey] = attempt.[NotificationKey]
    WHERE notification.[NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    DELETE FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    IF EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [Channel] = 'EMAIL')
       OR EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt])
    BEGIN
        ;THROW 52130, 'Quota concurrency acceptance requires an empty email queue with writers stopped.', 1;
    END;

    BEGIN TRANSACTION;
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5700000-0000-4000-8000-000000000001',
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-QUOTA',
        @emailEnvelopeVersion = 1,
        @emailEnvelopeJson = N'{"notificationId":"A5700000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-QUOTA","schemaVersion":1}',
        @createdDateTime = @asOf;
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5700000-0000-4000-8000-000000000002',
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-QUOTA',
        @emailEnvelopeVersion = 1,
        @emailEnvelopeJson = N'{"notificationId":"A5700000-0000-4000-8000-000000000002","businessCorrelationId":"SYNTHETIC-QUOTA","schemaVersion":1}',
        @createdDateTime = @asOf;
    COMMIT TRANSACTION;

    -- Both seed rows must be committed before the claim holds its locks.
    BEGIN TRANSACTION;
    INSERT INTO @claimed EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @asOf, @leaseDurationSeconds = 60, @maxNotifications = 1,
        @maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 1;
    IF (SELECT COUNT(*) FROM @claimed) <> 1
    BEGIN
        ;THROW 52131, 'Session A did not consume exactly one quota slot.', 1;
    END;
    RAISERROR ('PASS:SESSION_A_READY', 10, 1) WITH NOWAIT;
    WAITFOR DELAY '00:00:05';
    COMMIT TRANSACTION;
    PRINT 'PASS:SESSION_A_COMMITTED';
    -- Session B owns normal post-commit cleanup, after proving the remaining due row cannot be claimed.
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    -- CLEANUP_SCOPE:FIXED_NOTIFICATION_IDS_ONLY
    DELETE attempt
    FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
    INNER JOIN [po].[PurchaseOrderNotification] AS notification
        ON notification.[NotificationKey] = attempt.[NotificationKey]
    WHERE notification.[NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    DELETE FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] IN ('A5700000-0000-4000-8000-000000000001', 'A5700000-0000-4000-8000-000000000002');
    THROW;
END CATCH;
