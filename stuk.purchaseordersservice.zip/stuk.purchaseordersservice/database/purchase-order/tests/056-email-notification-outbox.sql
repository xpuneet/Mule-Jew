SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;
SET XACT_ABORT ON;

-- Require an empty email queue so ordering, global rolling quotas, and metric counts are deterministic.
IF EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [Channel] = 'EMAIL')
   OR EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt])
BEGIN
    ;THROW 52100, 'Email acceptance requires an empty email queue and attempt history with writers stopped.', 1;
END;

DECLARE @now datetimeoffset(3) = '2099-06-01T00:00:00.000+00:00';
DECLARE @at datetimeoffset(3);
DECLARE @next datetimeoffset(3);
DECLARE @envelope nvarchar(max);
DECLARE @lease uniqueidentifier;
DECLARE @oldLease uniqueidentifier;
DECLARE @version binary(8);
DECLARE @originalVersion binary(8);
DECLARE @iteration int;
DECLARE @claimed TABLE
(
    [NotificationId] uniqueidentifier, [EventType] varchar(100), [BusinessCorrelationId] nvarchar(256),
    [EmailEnvelopeVersion] smallint, [EmailEnvelopeJson] nvarchar(max), [PayloadSha256] binary(32),
    [AttemptCount] int, [FailureCount] int, [ThrottleCount] int,
    [LeaseId] uniqueidentifier, [LeaseExpiresDateTime] datetimeoffset(3), [RowVersion] binary(8)
);
DECLARE @summary TABLE
(
    [ClaimablePendingCount] bigint, [OldestClaimablePendingDateTime] datetimeoffset(3),
    [DelayedPendingCount] bigint, [ActiveLeasedCount] bigint, [ExpiredLeasedCount] bigint,
    [UnsendableLegacyPendingCount] bigint, [TerminalFailureCount] bigint
);

BEGIN TRY
    BEGIN TRANSACTION;
    -- SCENARIO:EMAIL_ENQUEUE_REPLAY_AND_CONFLICT (conflicting replays are tested below).

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
    SELECT @originalVersion = [RowVersion] FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
    IF (SELECT COUNT(*) FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001') <> 1
       OR NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001'
           AND [RowVersion] = @originalVersion AND [AttemptCount] = 0 AND [FailureCount] = 0 AND [ThrottleCount] = 0
           AND [NextAttemptDateTime] = @now AND [BatchKey] IS NULL
           AND [PayloadSha256] = HASHBYTES('SHA2_256', CONVERT(varbinary(max), @envelope)))
    BEGIN
        ;THROW 52101, 'Exact enqueue replay changed the immutable row or its initial state.', 1;
    END;

    -- SCENARIO:EMAIL_OPTIONAL_BATCH: an existing non-completed batch is permitted for an operational email.
    INSERT INTO [po].[PurchaseOrderBatch]
        ([BatchId], [Source], [OriginalFileName], [SourceFilePath], [FileContentLength], [FileSha256],
         [Status], [DiscoveredDateTime], [CreatedBy], [UpdatedDateTime])
    VALUES ('A5600000-0000-4000-8000-000000000030', N'ACCEPTANCE_EMAIL', N'synthetic.csv', N'acceptance/email/synthetic.csv', 0,
        HASHBYTES('SHA2_256', N'SYNTHETIC-EMAIL-BATCH'), 'INGESTING', @now, N'acceptance-email', @now);
    SET @at = DATEADD(SECOND, 1, @now);

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000002","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000002', @batchId = 'A5600000-0000-4000-8000-000000000030',
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @at;
    IF NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000002' AND [BatchKey] IS NOT NULL)
    BEGIN
        ;THROW 52102, 'Optional batch association was not persisted.', 1;
    END;

    -- SCENARIO:EMAIL_ORDERING_AND_QUOTA
    SET @at = DATEADD(SECOND, 2, @now);

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 1,
        @maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 100;
    IF (SELECT COUNT(*) FROM @claimed) <> 1 OR NOT EXISTS (SELECT 1 FROM @claimed WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001')
    BEGIN
        ;THROW 52103, 'Claim did not choose the oldest due notification within the minute quota.', 1;
    END;
    SELECT @oldLease = [LeaseId] FROM @claimed;

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 2,
        @maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 100;
    IF EXISTS (SELECT 1 FROM @claimed) BEGIN ;THROW 52104, 'Minute capacity was spent twice.', 1; END;

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 2,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 1;
    IF EXISTS (SELECT 1 FROM @claimed) BEGIN ;THROW 52105, 'Hour capacity was spent twice.', 1; END;

    -- SCENARIO:EMAIL_ACTIVE_AND_EXPIRED_LEASES

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 2,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
    IF (SELECT COUNT(*) FROM @claimed) <> 1 OR NOT EXISTS (SELECT 1 FROM @claimed WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000002')
    BEGIN
        ;THROW 52106, 'An active lease was reclaimed or the second due row was skipped.', 1;
    END;
    SELECT @lease = [LeaseId], @version = [RowVersion] FROM @claimed;
    SET @next = DATEADD(SECOND, 120, @now);

    -- SCENARIO:EMAIL_DEFER_AND_RETRY_COUNTERS
    EXEC [po].[sp_defer_purchase_order_email_notification] @notificationId = 'A5600000-0000-4000-8000-000000000002', @leaseId = @lease,
        @nextAttemptDateTime = @next, @completedDateTime = @at, @expectedNotificationRowVersion = @version;
    IF NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000002'
        AND [Status] = 'PENDING' AND [LeaseId] IS NULL AND [LeaseExpiresDateTime] IS NULL
        AND [FailureCount] = 0 AND [ThrottleCount] = 0)
       OR NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt] WHERE [AttemptId] = @lease AND [Outcome] = 'DEFERRED')
    BEGIN
        ;THROW 52107, 'Deferral did not clear its lease without incrementing failure or throttle counters.', 1;
    END;

    SET @at = DATEADD(SECOND, 32, @now);

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
    IF (SELECT COUNT(*) FROM @claimed) <> 1
       OR NOT EXISTS (SELECT 1 FROM @claimed WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001' AND [LeaseId] <> @oldLease AND [AttemptCount] = 2)
       OR NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt] WHERE [AttemptId] = @oldLease AND [Outcome] = 'LEASE_EXPIRED')
    BEGIN
        ;THROW 52108, 'Reclaim did not close the previous attempt and allocate a new lease/attempt.', 1;
    END;
    SELECT @lease = [LeaseId], @version = [RowVersion] FROM @claimed;
    SET @next = DATEADD(SECOND, 1, @at);
    EXEC [po].[sp_reschedule_purchase_order_email_notification] @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @lease,
        @outcome = 'TRANSIENT_FAILURE', @failureCategory = 'PROVIDER', @httpStatusCode = 503,
        @nextAttemptDateTime = @next, @completedDateTime = @at, @expectedNotificationRowVersion = @version;
    SET @at = @next;

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
    SELECT @lease = [LeaseId], @version = [RowVersion] FROM @claimed;
    SET @next = DATEADD(SECOND, 1, @at);
    EXEC [po].[sp_reschedule_purchase_order_email_notification] @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @lease,
        @outcome = 'THROTTLED', @failureCategory = 'PROVIDER', @httpStatusCode = 429,
        @nextAttemptDateTime = @next, @completedDateTime = @at, @expectedNotificationRowVersion = @version;
    IF NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001'
        AND [FailureCount] = 1 AND [ThrottleCount] = 1 AND [LeaseId] IS NULL AND [LeaseExpiresDateTime] IS NULL)
    BEGIN
        ;THROW 52109, 'Transient and throttle counters were conflated.', 1;
    END;

    -- SCENARIO:EMAIL_TERMINAL_OUTCOMES
    SET @at = @next;

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
    SELECT @lease = [LeaseId], @version = [RowVersion] FROM @claimed;
    EXEC [po].[sp_complete_purchase_order_email_notification] @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @lease,
        @status = 'SENT', @attemptOutcome = 'SUCCEEDED', @incrementFailureCount = 0,
        @providerMessageId = N'SYNTHETIC-PROVIDER-ID', @completedDateTime = @at, @expectedNotificationRowVersion = @version;
    IF NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001'
        AND [Status] = 'SENT' AND [SentDateTime] = @at AND [CompletedDateTime] = @at
        AND [FailureCount] = 1 AND [ThrottleCount] = 1 AND [LeaseId] IS NULL AND [LeaseExpiresDateTime] IS NULL)
       OR NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt] WHERE [AttemptId] = @lease
           AND [Outcome] = 'SUCCEEDED' AND [ProviderMessageId] = N'SYNTHETIC-PROVIDER-ID')
    BEGIN
        ;THROW 52110, 'Success did not atomically persist terminal notification and attempt state.', 1;
    END;
    SET @at = DATEADD(SECOND, 120, @now);

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
    SELECT @lease = [LeaseId], @version = [RowVersion] FROM @claimed;
    EXEC [po].[sp_complete_purchase_order_email_notification] @notificationId = 'A5600000-0000-4000-8000-000000000002', @leaseId = @lease,
        @status = 'FAILED', @attemptOutcome = 'PERMANENT_FAILURE', @incrementFailureCount = 0,
        @failureCategory = 'CONFIGURATION', @completedDateTime = @at, @expectedNotificationRowVersion = @version;
    IF NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000002'
        AND [Status] = 'FAILED' AND [SentDateTime] IS NULL AND [CompletedDateTime] = @at AND [FailureCount] = 0)
       OR NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt] WHERE [AttemptId] = @lease AND [Outcome] = 'PERMANENT_FAILURE')
    BEGIN
        ;THROW 52111, 'Permanent failure incorrectly consumed the ordinary retry count.', 1;
    END;

    -- SCENARIO:EMAIL_EXHAUSTED_TRANSIENT_FAILURE

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000003","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000003', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @at;
    SET @iteration = 1;
    WHILE @iteration <= 8
    BEGIN
        SET @at = DATEADD(SECOND, 1, @at);

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
        SELECT @lease = [LeaseId], @version = [RowVersion] FROM @claimed WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000003';
        SET @next = DATEADD(SECOND, 1, @at);
        IF @iteration < 8
            EXEC [po].[sp_reschedule_purchase_order_email_notification] @notificationId = 'A5600000-0000-4000-8000-000000000003', @leaseId = @lease,
                @outcome = 'TRANSIENT_FAILURE', @failureCategory = 'PROVIDER',
                @nextAttemptDateTime = @next, @completedDateTime = @at, @expectedNotificationRowVersion = @version;
        ELSE
            EXEC [po].[sp_complete_purchase_order_email_notification] @notificationId = 'A5600000-0000-4000-8000-000000000003', @leaseId = @lease,
                @status = 'FAILED', @attemptOutcome = 'TRANSIENT_FAILURE', @incrementFailureCount = 1,
                @failureCategory = 'PROVIDER', @completedDateTime = @at, @expectedNotificationRowVersion = @version;
        SET @iteration += 1;
    END;
    IF NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000003'
        AND [Status] = 'FAILED' AND [FailureCount] = 8 AND [ThrottleCount] = 0 AND [AttemptCount] = 8
        AND [CompletedDateTime] = @at AND [LeaseId] IS NULL AND [LeaseExpiresDateTime] IS NULL)
       OR NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt] WHERE [AttemptId] = @lease
           AND [Outcome] = 'TRANSIENT_FAILURE' AND [AttemptNumber] = 8)
    BEGIN
        ;THROW 52112, 'Exhausted transient failure lost its eighth failure or changed attempt classification.', 1;
    END;

    -- SCENARIO:EMAIL_QUEUE_SUMMARY_AND_LEGACY_ISOLATION
    SET @at = DATEADD(SECOND, 130, @now);

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000004","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000004', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @at;

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 5, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000006","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000006', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @at;

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 100, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000007","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000007', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @at;
    SET @next = DATEADD(SECOND, 300, @now);

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000008","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000008', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @next;
    INSERT INTO [po].[PurchaseOrderNotification]
        ([NotificationId], [Channel], [Status], [CreatedDateTime], [NextAttemptDateTime])
    VALUES ('A5600000-0000-4000-8000-000000000005', 'EMAIL', 'PENDING', @now, @now);
    SET @at = DATEADD(SECOND, 140, @now);
    INSERT INTO @summary EXEC [po].[sp_get_purchase_order_email_notification_queue_summary]
        @asOfDateTime = @at, @terminalFailureSinceDateTime = @now;
    IF NOT EXISTS (SELECT 1 FROM @summary WHERE [ClaimablePendingCount] = 1
        AND [OldestClaimablePendingDateTime] = '2099-06-01T00:02:10.000+00:00'
        AND [DelayedPendingCount] = 1 AND [ActiveLeasedCount] = 1 AND [ExpiredLeasedCount] = 1
        AND [UnsendableLegacyPendingCount] = 1 AND [TerminalFailureCount] = 2)
    BEGIN
        ;THROW 52113, 'Queue metrics mixed delayed, leased, terminal, or legacy rows.', 1;
    END;

    DELETE FROM @claimed;
    INSERT INTO @claimed
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 30, @maxNotifications = 10,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
    IF (SELECT COUNT(*) FROM @claimed) <> 2 OR EXISTS (SELECT 1 FROM @claimed WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000005')
       OR EXISTS (SELECT 1 FROM @claimed AS claimed
           WHERE NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
               WHERE attempt.[AttemptId] = claimed.[LeaseId] AND attempt.[Outcome] = 'STARTED'))
    BEGIN
        ;THROW 52114, 'Claim included legacy work or failed the AttemptId/LeaseId contract.', 1;
    END;

    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    THROW;
END CATCH;
PRINT 'PASS:EMAIL_POSITIVE_STATE_MACHINE';

-- SCENARIO:EMAIL_OUT_OF_ORDER_QUOTA
-- Both rows are already due at t; the first claimant records an attempt at t+1.
BEGIN TRY
    BEGIN TRANSACTION;
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @eventType = 'SYNTHETIC',
        @businessCorrelationId = N'SYNTHETIC-EMAIL', @emailEnvelopeVersion = 1,
        @emailEnvelopeJson = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}',
        @createdDateTime = @now;
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000002', @eventType = 'SYNTHETIC',
        @businessCorrelationId = N'SYNTHETIC-EMAIL', @emailEnvelopeVersion = 1,
        @emailEnvelopeJson = N'{"notificationId":"A5600000-0000-4000-8000-000000000002","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}',
        @createdDateTime = @now;
    SET @at = DATEADD(SECOND, 1, @now);
    DELETE FROM @claimed;
    INSERT INTO @claimed EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @at, @leaseDurationSeconds = 60, @maxNotifications = 1,
        @maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 1;
    IF (SELECT COUNT(*) FROM @claimed) <> 1
    BEGIN
        ;THROW 52140, 'The later caller did not claim exactly one due notification.', 1;
    END;

    DELETE FROM @claimed;
    INSERT INTO @claimed EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @now, @leaseDurationSeconds = 60, @maxNotifications = 1,
        @maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 100;
    IF EXISTS (SELECT 1 FROM @claimed)
    BEGIN
        ;THROW 52141, 'An older caller spent the same minute quota slot twice.', 1;
    END;
    INSERT INTO @claimed EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @now, @leaseDurationSeconds = 60, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 1;
    IF EXISTS (SELECT 1 FROM @claimed)
    BEGIN
        ;THROW 52142, 'An older caller spent the same hour quota slot twice.', 1;
    END;
    IF (SELECT COUNT(*) FROM [po].[PurchaseOrderNotification]
        WHERE [NotificationId] IN ('A5600000-0000-4000-8000-000000000001', 'A5600000-0000-4000-8000-000000000002')
          AND [Status] = 'PENDING' AND [NextAttemptDateTime] <= @now) <> 1
       OR (SELECT COUNT(*) FROM [po].[PurchaseOrderNotificationAttempt]) <> 1
    BEGIN
        ;THROW 52143, 'Out-of-order quota proof requires one due pending row and one recorded attempt.', 1;
    END;
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    THROW;
END CATCH;
PRINT 'PASS:EMAIL_OUT_OF_ORDER_QUOTA';

-- Each expected rejection has its own rollback-only fixture: procedure catches roll back the caller transaction.
-- SCENARIO:EMAIL_ENVELOPE_IDENTITY_REQUIRED
-- SCENARIO:EMAIL_UTC_JSON_STATE_AND_SIZE
DECLARE @invalidCase int = 1;
DECLARE @rejected bit;
DECLARE @invalidEnvelope nvarchar(max);
DECLARE @invalidCreated datetimeoffset(3);
DECLARE @invalidId uniqueidentifier;
DECLARE @invalidBatch uniqueidentifier;
WHILE @invalidCase <= 14
BEGIN
    SET @rejected = 0;
    SET @invalidId = 'A5600000-0000-4000-8000-000000000001';
    SET @invalidBatch = NULL;
    SET @invalidCreated = @now;
    SET @invalidEnvelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    SET @invalidEnvelope = CASE @invalidCase
        WHEN 1 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000099","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}'
        WHEN 2 THEN N'{"businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}'
        WHEN 3 THEN N'{"notificationId":null,"businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}'
        WHEN 4 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"synthetic-email","schemaVersion":1}'
        WHEN 5 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000001","schemaVersion":1}'
        WHEN 6 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":null,"schemaVersion":1}'
        WHEN 7 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":2}'
        WHEN 8 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL"}'
        WHEN 9 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":null}'
        WHEN 10 THEN N'{broken'
        WHEN 11 THEN N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1,"padding":"'
            + REPLICATE(CONVERT(nvarchar(max), N'x'), 10 * 1024 * 1024) + N'"}'
        ELSE @invalidEnvelope END;
    IF @invalidCase = 12 SET @invalidCreated = '2099-06-01T00:00:00.000+01:00';
    IF @invalidCase = 13 SET @invalidId = '00000000-0000-0000-0000-000000000000';
    IF @invalidCase = 14 SET @invalidBatch = 'A5600000-0000-4000-8000-000000000099';

    -- SCENARIO:EMAIL_OVERSIZED_VALID_ENVELOPE
    IF @invalidCase = 11
       AND (ISJSON(@invalidEnvelope) <> 1
            OR DATALENGTH(@invalidEnvelope) <= 20 * 1024 * 1024)
    BEGIN
        ;THROW 52145, 'The oversized-envelope fixture must be valid JSON larger than 20 MiB.', 1;
    END;

    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC [po].[sp_enqueue_purchase_order_email_notification]
            @notificationId = @invalidId, @batchId = @invalidBatch, @eventType = 'SYNTHETIC',
            @businessCorrelationId = N'SYNTHETIC-EMAIL', @emailEnvelopeVersion = 1,
            @emailEnvelopeJson = @invalidEnvelope, @createdDateTime = @invalidCreated;
        ;THROW 52115, 'An invalid email envelope, timestamp, identifier, or missing batch was accepted.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = CASE WHEN @invalidCase = 14 THEN 51001 ELSE 51004 END SET @rejected = 1;
        IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
        IF @rejected = 0 THROW;
    END CATCH;
    SET @invalidCase += 1;
END;
PRINT 'PASS:EMAIL_ENVELOPE_IDENTITY_REQUIRED';
PRINT 'PASS:EMAIL_UTC_JSON_STATE_AND_SIZE';

-- Replay conflicts independently cover payload, relational event, and optional audit fields.
DECLARE @conflictCase int = 1;
DECLARE @conflictEvent varchar(100);
DECLARE @conflictTemplate nvarchar(100);
DECLARE @conflictRecipient nvarchar(100);
DECLARE @conflictAttachment nvarchar(512);
DECLARE @conflictCreated datetimeoffset(3);
WHILE @conflictCase <= 6
BEGIN
    SET @rejected = 0;
    BEGIN TRY
        BEGIN TRANSACTION;

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
        SET @conflictEvent = CASE WHEN @conflictCase = 1 THEN 'OTHER' ELSE 'SYNTHETIC' END;
        SET @conflictTemplate = CASE WHEN @conflictCase = 2 THEN N'OTHER' ELSE NULL END;
        SET @conflictRecipient = CASE WHEN @conflictCase = 3 THEN N'OTHER' ELSE NULL END;
        SET @conflictAttachment = CASE WHEN @conflictCase = 4 THEN N'OTHER' ELSE NULL END;
        SET @conflictCreated = CASE WHEN @conflictCase = 5 THEN DATEADD(SECOND, 1, @now) ELSE @now END;
        IF @conflictCase = 6 SET @envelope = JSON_MODIFY(@envelope, '$.subject', N'CHANGED');
        EXEC [po].[sp_enqueue_purchase_order_email_notification]
            @notificationId = 'A5600000-0000-4000-8000-000000000001', @eventType = @conflictEvent,
            @businessCorrelationId = N'SYNTHETIC-EMAIL', @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope,
            @templateKey = @conflictTemplate, @recipientGroupKey = @conflictRecipient,
            @attachmentBlobName = @conflictAttachment, @createdDateTime = @conflictCreated;
        ;THROW 52116, 'A conflicting immutable notification replay was accepted.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 51004 SET @rejected = 1;
        IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
        IF @rejected = 0 THROW;
    END CATCH;
    SET @conflictCase += 1;
END;
PRINT 'PASS:EMAIL_ENQUEUE_REPLAY_AND_CONFLICT';

-- SCENARIO:EMAIL_STALE_LEASE_AND_ROWVERSION
-- Every writer must reject both stale leases and stale rowversions.
DECLARE @writer int = 1;
DECLARE @badOwnership int;
DECLARE @badLease uniqueidentifier;
DECLARE @badVersion binary(8);
WHILE @writer <= 3
BEGIN
    SET @badOwnership = 1;
    WHILE @badOwnership <= 2
    BEGIN
        SET @rejected = 0;
        BEGIN TRY
            BEGIN TRANSACTION;

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
            EXEC [po].[sp_claim_purchase_order_email_notifications]
                @asOfDateTime = @now, @leaseDurationSeconds = 30, @maxNotifications = 1,
                @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
            SELECT @badLease = [LeaseId], @badVersion = [RowVersion]
            FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';
            IF @badOwnership = 1 SET @badLease = 'A5600000-0000-4000-8000-000000000099';
            IF @badOwnership = 2 SET @badVersion = 0x0000000000000000;
            SET @next = DATEADD(SECOND, 1, @now);
            IF @writer = 1
                EXEC [po].[sp_defer_purchase_order_email_notification]
                    @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @badLease,
                    @nextAttemptDateTime = @next, @completedDateTime = @now, @expectedNotificationRowVersion = @badVersion;
            IF @writer = 2
                EXEC [po].[sp_reschedule_purchase_order_email_notification]
                    @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @badLease,
                    @outcome = 'TRANSIENT_FAILURE', @failureCategory = 'PROVIDER', @nextAttemptDateTime = @next,
                    @completedDateTime = @now, @expectedNotificationRowVersion = @badVersion;
            IF @writer = 3
                EXEC [po].[sp_complete_purchase_order_email_notification]
                    @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @badLease,
                    @status = 'SENT', @attemptOutcome = 'SUCCEEDED', @incrementFailureCount = 0,
                    @completedDateTime = @now, @expectedNotificationRowVersion = @badVersion;
            ;THROW 52117, 'An email writer accepted a stale lease or rowversion.', 1;
        END TRY
        BEGIN CATCH
            IF ERROR_NUMBER() = CASE WHEN @badOwnership = 1 THEN 51003 ELSE 51002 END SET @rejected = 1;
            IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
            IF @rejected = 0 THROW;
        END CATCH;
        SET @badOwnership += 1;
    END;
    SET @writer += 1;
END;
PRINT 'PASS:EMAIL_STALE_LEASE_AND_ROWVERSION';

-- SCENARIO:EMAIL_HTTP_429_CLASSIFICATION
-- Valid THROTTLED + 429 is exercised above; every incompatible outcome is rejected here.
DECLARE @throttleCase int = 1;
DECLARE @throttleOutcome varchar(50);
DECLARE @throttleHttpStatus smallint;
DECLARE @throttleStatus varchar(50);
DECLARE @throttleIncrement bit;
WHILE @throttleCase <= 6
BEGIN
    SET @rejected = 0;
    SET @throttleOutcome = CASE @throttleCase
        WHEN 1 THEN 'TRANSIENT_FAILURE' WHEN 2 THEN 'THROTTLED' WHEN 3 THEN 'THROTTLED'
        WHEN 4 THEN 'TRANSIENT_FAILURE' WHEN 5 THEN 'PERMANENT_FAILURE' ELSE 'SUCCEEDED' END;
    SET @throttleHttpStatus = CASE @throttleCase WHEN 2 THEN 503 WHEN 3 THEN NULL ELSE 429 END;
    SET @throttleStatus = CASE WHEN @throttleCase = 6 THEN 'SENT' ELSE 'FAILED' END;
    SET @throttleIncrement = CASE WHEN @throttleCase = 4 THEN 1 ELSE 0 END;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC [po].[sp_enqueue_purchase_order_email_notification]
            @notificationId = 'A5600000-0000-4000-8000-000000000001', @eventType = 'SYNTHETIC',
            @businessCorrelationId = N'SYNTHETIC-EMAIL', @emailEnvelopeVersion = 1,
            @emailEnvelopeJson = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}',
            @createdDateTime = @now;
        EXEC [po].[sp_claim_purchase_order_email_notifications]
            @asOfDateTime = @now, @leaseDurationSeconds = 30, @maxNotifications = 1,
            @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
        SELECT @lease = [LeaseId], @version = [RowVersion] FROM [po].[PurchaseOrderNotification]
        WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';
        SET @next = DATEADD(SECOND, 1, @now);
        IF @throttleCase <= 3
            EXEC [po].[sp_reschedule_purchase_order_email_notification]
                @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @lease,
                @outcome = @throttleOutcome, @failureCategory = 'PROVIDER', @httpStatusCode = @throttleHttpStatus,
                @nextAttemptDateTime = @next, @completedDateTime = @now, @expectedNotificationRowVersion = @version;
        ELSE
            EXEC [po].[sp_complete_purchase_order_email_notification]
                @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @lease,
                @status = @throttleStatus, @attemptOutcome = @throttleOutcome, @incrementFailureCount = @throttleIncrement,
                @httpStatusCode = @throttleHttpStatus, @completedDateTime = @now, @expectedNotificationRowVersion = @version;
        ;THROW 52144, 'HTTP 429 or a non-429 throttle was accepted with an inconsistent outcome.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 51004 SET @rejected = 1;
        IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
        IF @rejected = 0 THROW;
    END CATCH;
    SET @throttleCase += 1;
END;
PRINT 'PASS:EMAIL_HTTP_429_CLASSIFICATION';

-- Invalid completion pairs must fail before changing notification or attempt state.
DECLARE @badStatus varchar(50);
DECLARE @badOutcome varchar(50);
DECLARE @badIncrement bit;
SET @invalidCase = 1;
WHILE @invalidCase <= 4
BEGIN
    SET @rejected = 0;
    SET @badStatus = CASE WHEN @invalidCase = 1 THEN 'PENDING' WHEN @invalidCase = 2 THEN 'SENT' ELSE 'FAILED' END;
    SET @badOutcome = CASE WHEN @invalidCase = 3 THEN 'TRANSIENT_FAILURE' ELSE 'PERMANENT_FAILURE' END;
    SET @badIncrement = CASE WHEN @invalidCase = 4 THEN 1 ELSE 0 END;
    BEGIN TRY
        BEGIN TRANSACTION;

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
        EXEC [po].[sp_claim_purchase_order_email_notifications]
            @asOfDateTime = @now, @leaseDurationSeconds = 30, @maxNotifications = 1,
            @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
        SELECT @lease = [LeaseId], @version = [RowVersion] FROM [po].[PurchaseOrderNotification]
        WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';
        EXEC [po].[sp_complete_purchase_order_email_notification]
            @notificationId = 'A5600000-0000-4000-8000-000000000001', @leaseId = @lease,
            @status = @badStatus, @attemptOutcome = @badOutcome, @incrementFailureCount = @badIncrement,
            @completedDateTime = @now, @expectedNotificationRowVersion = @version;
        ;THROW 52118, 'An invalid terminal status/outcome/increment combination was accepted.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 51004 SET @rejected = 1;
        IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
        IF @rejected = 0 THROW;
    END CATCH;
    SET @invalidCase += 1;
END;

-- SCENARIO:EMAIL_ATTEMPT_ID_UNIQUENESS: same AttemptId on another notification and attempt number.
SET @rejected = 0;
BEGIN TRY
    BEGIN TRANSACTION;

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
    EXEC [po].[sp_claim_purchase_order_email_notifications]
        @asOfDateTime = @now, @leaseDurationSeconds = 30, @maxNotifications = 1,
        @maxAttemptsPerMinute = 100, @maxAttemptsPerHour = 100;
    SELECT @lease = [LeaseId] FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';
    INSERT INTO [po].[PurchaseOrderNotification] ([NotificationId], [Channel], [Status], [CreatedDateTime], [NextAttemptDateTime])
    VALUES ('A5600000-0000-4000-8000-000000000099', 'EMAIL', 'PENDING', @now, @now);
    INSERT INTO [po].[PurchaseOrderNotificationAttempt] ([AttemptId], [NotificationKey], [AttemptNumber], [StartedDateTime], [Outcome])
    SELECT @lease, [NotificationKey], 2, @now, 'STARTED'
    FROM [po].[PurchaseOrderNotification] WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000099';
    ;THROW 52119, 'AttemptId was not independently unique across notifications and attempt numbers.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() IN (2601, 2627) SET @rejected = 1;
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    IF @rejected = 0 THROW;
END CATCH;
PRINT 'PASS:EMAIL_ATTEMPT_ID_UNIQUENESS';

-- Direct malformed state must also be rejected by the table contract.
SET @invalidCase = 1;
WHILE @invalidCase <= 3
BEGIN
    SET @rejected = 0;
    BEGIN TRY
        BEGIN TRANSACTION;

    SET @envelope = N'{"notificationId":"A5600000-0000-4000-8000-000000000001","businessCorrelationId":"SYNTHETIC-EMAIL","schemaVersion":1}';
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = 'A5600000-0000-4000-8000-000000000001', @batchId = NULL,
        @eventType = 'SYNTHETIC', @businessCorrelationId = N'SYNTHETIC-EMAIL',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
        IF @invalidCase = 1
            UPDATE [po].[PurchaseOrderNotification] SET [Status] = 'SENDING'
            WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';
        IF @invalidCase = 2
            UPDATE [po].[PurchaseOrderNotification] SET [EmailEnvelopeJson] = N'{broken'
            WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';
        IF @invalidCase = 3
            UPDATE [po].[PurchaseOrderNotification] SET [NextAttemptDateTime] = '2099-06-01T00:00:00.000+01:00'
            WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000001';
        ;THROW 52120, 'Malformed email state bypassed a table constraint.', 1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() = 547 SET @rejected = 1;
        IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
        IF @rejected = 0 THROW;
    END CATCH;
    SET @invalidCase += 1;
END;

IF EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification] WHERE [Channel] = 'EMAIL')
   OR EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotificationAttempt])
   OR EXISTS (SELECT 1 FROM [po].[PurchaseOrderBatch] WHERE [BatchId] = 'A5600000-0000-4000-8000-000000000030')
BEGIN
    ;THROW 52121, 'Email acceptance left synthetic fixtures after rollback.', 1;
END;
PRINT 'PASS:EMAIL_OUTBOX_CLEANUP_COMPLETE';

-- SCENARIO:EMAIL_MIGRATION_RERUN_ROWVERSION_STABILITY
-- Rerun the real migration against target-shape rows and retain the pre-rerun rowversions across
-- its SQLCMD batch boundaries in a temporary table. The active SENDING row represents a worker
-- whose completion write still depends on the rowversion returned with its lease.
BEGIN TRY
    BEGIN TRANSACTION;

    CREATE TABLE #migrationRowVersions
    (
        [NotificationId] uniqueidentifier NOT NULL PRIMARY KEY,
        [RowVersion] binary(8) NOT NULL
    );

    DECLARE @migrationDateTime datetimeoffset(3) = '2099-06-02T00:00:00.000+00:00';
    DECLARE @migrationEnvelope nvarchar(max) =
        N'{"notificationId":"A5600000-0000-4000-8000-000000000052","businessCorrelationId":"SYNTHETIC-MIGRATION","schemaVersion":1}';
    DECLARE @migrationLeaseId uniqueidentifier = 'A5600000-0000-4000-8000-000000000062';

    INSERT INTO [po].[PurchaseOrderNotification]
    (
        [NotificationId], [Channel], [EventType], [BusinessCorrelationId],
        [EmailEnvelopeVersion], [EmailEnvelopeJson], [PayloadSha256], [Status],
        [AttemptCount], [FailureCount], [ThrottleCount], [NextAttemptDateTime],
        [LastAttemptDateTime], [LeaseId], [LeaseExpiresDateTime], [ProviderMessageId],
        [CreatedDateTime], [SentDateTime], [CompletedDateTime]
    )
    VALUES
    (
        'A5600000-0000-4000-8000-000000000051', 'EMAIL', NULL, NULL,
        NULL, NULL, NULL, 'PENDING',
        2, 1, 1, @migrationDateTime,
        @migrationDateTime, NULL, NULL, NULL,
        @migrationDateTime, NULL, NULL
    ),
    (
        'A5600000-0000-4000-8000-000000000052', 'EMAIL', 'SYNTHETIC', N'SYNTHETIC-MIGRATION',
        1, @migrationEnvelope, HASHBYTES('SHA2_256', CONVERT(varbinary(max), @migrationEnvelope)), 'SENDING',
        3, 1, 1, @migrationDateTime,
        @migrationDateTime, @migrationLeaseId, DATEADD(MINUTE, 5, @migrationDateTime), NULL,
        @migrationDateTime, NULL, NULL
    ),
    (
        'A5600000-0000-4000-8000-000000000053', 'EMAIL', NULL, NULL,
        NULL, NULL, NULL, 'SENT',
        1, 0, 0, @migrationDateTime,
        @migrationDateTime, NULL, NULL, N'SYNTHETIC-PROVIDER-ID',
        @migrationDateTime, @migrationDateTime, @migrationDateTime
    );

    INSERT INTO [po].[PurchaseOrderNotificationAttempt]
        ([AttemptId], [NotificationKey], [AttemptNumber], [StartedDateTime], [Outcome])
    SELECT
        @migrationLeaseId, [NotificationKey], [AttemptCount], @migrationDateTime, 'STARTED'
    FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] = 'A5600000-0000-4000-8000-000000000052';

    INSERT INTO #migrationRowVersions ([NotificationId], [RowVersion])
    SELECT [NotificationId], [RowVersion]
    FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] IN
        ('A5600000-0000-4000-8000-000000000051',
         'A5600000-0000-4000-8000-000000000052',
         'A5600000-0000-4000-8000-000000000053');
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    THROW;
END CATCH;
GO

:r ..\035-email-notification-outbox-migration.sql

BEGIN TRY
    IF (SELECT COUNT(*) FROM #migrationRowVersions) <> 3
       OR EXISTS
       (
           SELECT 1
           FROM [po].[PurchaseOrderNotification] AS notification
           INNER JOIN #migrationRowVersions AS original
               ON original.[NotificationId] = notification.[NotificationId]
           WHERE notification.[RowVersion] <> original.[RowVersion]
       )
    BEGIN
        ;THROW 52146, 'A migration rerun changed an already-migrated notification rowversion.', 1;
    END;

    IF (SELECT COUNT(*)
        FROM [po].[PurchaseOrderNotification]
        WHERE [NotificationId] IN
            ('A5600000-0000-4000-8000-000000000051',
             'A5600000-0000-4000-8000-000000000052',
             'A5600000-0000-4000-8000-000000000053')) <> 3
    BEGIN
        ;THROW 52147, 'The migration rerun did not preserve every rowversion fixture.', 1;
    END;

    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    THROW;
END CATCH;
GO

IF EXISTS
(
    SELECT 1
    FROM [po].[PurchaseOrderNotification]
    WHERE [NotificationId] IN
        ('A5600000-0000-4000-8000-000000000051',
         'A5600000-0000-4000-8000-000000000052',
         'A5600000-0000-4000-8000-000000000053')
)
BEGIN
    ;THROW 52148, 'The migration-rerun scenario left synthetic fixtures after rollback.', 1;
END;
PRINT 'PASS:EMAIL_MIGRATION_RERUN_ROWVERSION_STABILITY';
