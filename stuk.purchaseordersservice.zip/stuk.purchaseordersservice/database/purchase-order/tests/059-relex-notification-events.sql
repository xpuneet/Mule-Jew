SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;

IF N'$(AllowDestructiveAcceptanceTests)' <> N'1'
BEGIN
    ;THROW 52000, 'Run only in an approved disposable/non-production database with AllowDestructiveAcceptanceTests=1.', 1;
END;
SET XACT_ABORT ON;
-- All fixtures below roll back. Quiesce every processor, API writer and support session.
IF EXISTS (SELECT 1 FROM [po].[PurchaseOrderBatch])
    OR EXISTS (SELECT 1 FROM [po].[RelexNotificationEvent])
    OR EXISTS (SELECT 1 FROM [po].[PurchaseOrderNotification])
BEGIN
    ;THROW 52090, 'Relex notification acceptance requires empty batch, event and outbox tables.', 1;
END;

DECLARE @now datetimeoffset(3) = SYSUTCDATETIME(), @since datetimeoffset(3), @fresh datetimeoffset(3),
    @notification uniqueidentifier, @lease uniqueidentifier, @oldLease uniqueidentifier,
    @envelope nvarchar(max), @snapshot nvarchar(max), @settings nvarchar(max) =
        N'{"schemaVersion":1,"environmentName":"acceptance","recipients":["synthetic@example.invalid"],"senderAddress":"sender@example.invalid"}';
SET @since = DATEADD(DAY, -2, @now);
SET @fresh = DATEADD(HOUR, -6, @now);
DECLARE @claims TABLE
(
    [NotificationId] uniqueidentifier, [BatchId] uniqueidentifier, [EventType] varchar(100),
    [BusinessCorrelationId] nvarchar(256), [OriginalFileName] nvarchar(260), [CreatedDateTime] datetimeoffset(3),
    [CompositionSettingsJson] nvarchar(max), [OutcomeRowsJson] nvarchar(max), [EmailEnvelopeJson] nvarchar(max),
    [LeaseId] uniqueidentifier, [FailureCount] int
);
DECLARE @saved TABLE ([EmailEnvelopeJson] nvarchar(max));

-- SCENARIO:RELEX_INITIAL_READINESS_AND_EMPTY
-- SCENARIO:RELEX_MIXED_OUTCOMES_AND_FROZEN_SNAPSHOT
-- SCENARIO:RELEX_CUTOFF_EQUALITY_AND_RETRY_HISTORY
-- SCENARIO:RELEX_ENVELOPE_REPLAY_AND_COMPLETION
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO [po].[PurchaseOrderBatch]
        ([BatchId], [Source], [OriginalFileName], [SourceFilePath], [FileContentLength], [FileSha256],
        [Status], [ParsedRowCount], [CandidateCount], [DiscoveredDateTime], [CompletedDateTime], [CreatedBy], [UpdatedDateTime])
    SELECT CONVERT(uniqueidentifier, value.[id]), N'Relex', value.[name], N'/synthetic/' + value.[name],
        2048, HASHBYTES('SHA2_256', value.[name]), value.[status], value.[count], value.[count],
        @fresh, @now, N'acceptance', @now
    FROM (VALUES
        ('A5900000-0000-4000-8000-000000000001', N'mixed.csv', 'COMPLETED', 2),
        ('A5900000-0000-4000-8000-000000000002', N'ready.csv', 'COMPLETED', 1),
        ('A5900000-0000-4000-8000-000000000003', N'empty.csv', 'COMPLETED', 0),
        ('A5900000-0000-4000-8000-000000000004', N'failed.csv', 'FAILED', 0),
        ('A5900000-0000-4000-8000-000000000005', N'leased.csv', 'COMPLETED', 1),
        ('A5900000-0000-4000-8000-000000000006', N'dispatched.csv', 'COMPLETED', 1),
        ('A5900000-0000-4000-8000-000000000007', N'incomplete.csv', 'COMPLETED', 2))
        AS value([id], [name], [status], [count]);
    INSERT INTO [po].[PurchaseOrderCandidate]
        ([CandidateId], [BatchKey], [Source], [Kind], [SourceRowCount], [Account], [Branch],
        [Status], [StatusDateTime], [MessageDescription], [PayloadJson], [AcceptedDateTime],
        [CreatedDateTime], [UpdatedDateTime], [RefreshDateTime])
    SELECT NEWID(), batch.[BatchKey], N'Relex', 'RELEX', 1, value.[account], N'001', value.[status],
        DATEADD(MINUTE, -1, @now), value.[message],
        N'{"purchaseOrderHeader":{"createUser":"synthetic-api","deliveryMethod":"D"}}',
        @fresh, @fresh, @now, @now
    FROM (VALUES (N'mixed.csv', N'A-SUPPLIER', 'COMPLETED', CONVERT(nvarchar(1000), NULL)),
        (N'mixed.csv', N'B-SUPPLIER', 'NON_RECOVERABLE_ERROR', N'ICON outcome is unknown; check ICON'),
        (N'ready.csv', N'READY', 'READY_FOR_SUBMISSION', NULL),
        (N'leased.csv', N'LEASED', 'RECOVERABLE_ERROR', NULL),
        (N'dispatched.csv', N'DISPATCHED', 'NON_RECOVERABLE_ERROR', NULL),
        (N'incomplete.csv', N'INCOMPLETE', 'COMPLETED', NULL)) AS value([name], [account], [status], [message])
    INNER JOIN [po].[PurchaseOrderBatch] AS batch ON batch.[OriginalFileName] = value.[name];
    UPDATE [po].[PurchaseOrderCandidate]
    SET [LeaseToken] = NEWID(), [LeaseOwner] = N'acceptance', [LeaseAcquiredDateTime] = @now,
        [LeaseExpiresDateTime] = DATEADD(SECOND, 300, @now) WHERE [Account] = N'LEASED';
    INSERT INTO [po].[PurchaseOrderSubmissionAttempt]
        ([AttemptId], [CandidateKey], [AttemptNumber], [ClaimToken], [Status], [RequestPayloadJson],
        [IconPurchaseOrderNumber], [IconCreatedStatus], [IconSuspended], [IconSuspendMessage],
        [PreparedDateTime], [DispatchedDateTime], [CompletedDateTime], [CreatedBy])
    SELECT NEWID(), [CandidateKey], 1, NEWID(), CASE WHEN [Account] = N'DISPATCHED' THEN 'DISPATCHED' ELSE 'SUCCEEDED' END,
        N'{"header":{"bypass":true,"deliveryMethod":"D","createUser":"actual-api"}}',
        CASE WHEN [Account] = N'A-SUPPLIER' THEN N'12345' ELSE NULL END,
        CASE WHEN [Account] = N'A-SUPPLIER' THEN 'activated' ELSE NULL END,
        CASE WHEN [Account] = N'A-SUPPLIER' THEN CONVERT(bit, 1) ELSE NULL END,
        CASE WHEN [Account] = N'A-SUPPLIER' THEN N'Synthetic suspension' ELSE NULL END,
        @fresh, @fresh, CASE WHEN [Account] = N'A-SUPPLIER' THEN DATEADD(MINUTE, -1, @now) ELSE NULL END, N'acceptance'
    FROM [po].[PurchaseOrderCandidate] WHERE [Account] IN (N'A-SUPPLIER', N'DISPATCHED');

    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @now, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 1,
        @compositionSettingsJson = @settings, @resultsNotBeforeDateTime = @since;
    IF (SELECT COUNT(*) FROM @claims) <> 1 OR NOT EXISTS
        (SELECT 1 FROM @claims WHERE [OriginalFileName] = N'mixed.csv' AND [EventType] = 'RELEX_RESULTS')
        THROW 52091, 'Readiness admitted empty, pending, leased, dispatched or incomplete work.', 1;
    SELECT @notification = [NotificationId], @lease = [LeaseId], @snapshot = [OutcomeRowsJson] FROM @claims;
    IF JSON_VALUE(@snapshot, '$[0].supplier') <> N'A-SUPPLIER'
        OR JSON_VALUE(@snapshot, '$[0].orderNumber') <> N'12345'
        OR JSON_VALUE(@snapshot, '$[0].createStatus') <> N'activated'
        OR JSON_VALUE(@snapshot, '$[0].suspended') <> N'true'
        OR JSON_VALUE(@snapshot, '$[0].bypass') <> N'true'
        OR JSON_VALUE(@snapshot, '$[0].deliveryMode') <> N'D'
        OR JSON_VALUE(@snapshot, '$[0].apiUser') <> N'actual-api'
        OR JSON_VALUE(@snapshot, '$[1].createStatus') <> N'ICON outcome is unknown; check ICON'
        OR JSON_VALUE(@snapshot, '$[1].apiUser') <> N'synthetic-api'
        THROW 52092, 'The frozen result fields differ from persisted outcomes.', 1;
    PRINT 'PASS:SCENARIO:RELEX_INITIAL_READINESS_AND_EMPTY';
    PRINT 'PASS:SCENARIO:RELEX_MIXED_OUTCOMES_AND_FROZEN_SNAPSHOT';

    UPDATE [po].[PurchaseOrderCandidate] SET [Status] = 'RETRY_REQUESTED', [StatusDateTime] = @now
        WHERE [Account] = N'B-SUPPLIER';
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @now, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 1,
        @compositionSettingsJson = @settings, @resultsNotBeforeDateTime = @since,
        @missingCutoffDateTime = @now, @missingFreshSinceDateTime = @fresh,
        @missingEventKey = N'RELEX_MISSING:2026-09-24';
    IF EXISTS (SELECT 1 FROM @claims) OR EXISTS
        (SELECT 1 FROM [po].[RelexNotificationEvent] WHERE [EventType] = 'RELEX_MISSING')
        THROW 52093, 'Freshness equality or persisted processing history was lost after support retry.', 1;
    PRINT 'PASS:SCENARIO:RELEX_CUTOFF_EQUALITY_AND_RETRY_HISTORY';

    SET @envelope = N'{"schemaVersion":1,"notificationId":"' + CONVERT(nvarchar(36), @notification)
        + N'","businessCorrelationId":"Relex:a5900000-0000-4000-8000-000000000001","subject":"original"}';
    INSERT INTO @saved EXEC [po].[sp_save_relex_notification_envelope] @notification, @lease, @envelope;
    DECLARE @replacement nvarchar(max) = REPLACE(@envelope, N'original', N'changed');
    INSERT INTO @saved EXEC [po].[sp_save_relex_notification_envelope] @notification, @lease, @replacement;
    IF (SELECT COUNT(*) FROM @saved WHERE [EmailEnvelopeJson] = @envelope) <> 2
        THROW 52094, 'Saving twice replaced the first envelope.', 1;
    -- Simulate a crash/restart and changed runtime configuration after the first envelope save.
    SET @oldLease = @lease;
    UPDATE [po].[RelexNotificationEvent] SET [LeaseExpiresDateTime] = DATEADD(SECOND, -1, @now)
        WHERE [NotificationId] = @notification;
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @now, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 0,
        @compositionSettingsJson = N'{"schemaVersion":1,"environmentName":"changed"}';
    IF NOT EXISTS (SELECT 1 FROM @claims WHERE [NotificationId] = @notification AND [LeaseId] <> @oldLease
        AND [EmailEnvelopeJson] = @envelope AND [OutcomeRowsJson] = @snapshot AND [CompositionSettingsJson] = @settings)
        THROW 52095, 'Lease recovery changed the frozen snapshot or envelope.', 1;
    SELECT @lease = [LeaseId] FROM @claims;
    EXEC [po].[sp_enqueue_purchase_order_email_notification]
        @notificationId = @notification, @batchId = 'A5900000-0000-4000-8000-000000000001',
        @eventType = 'RELEX_RESULTS', @businessCorrelationId = N'Relex:a5900000-0000-4000-8000-000000000001',
        @emailEnvelopeVersion = 1, @emailEnvelopeJson = @envelope, @createdDateTime = @now;
    EXEC [po].[sp_complete_relex_notification_event] @notificationId = @notification, @leaseId = @lease,
        @enqueued = 1, @permanentFailure = 0, @completedDateTime = @now, @maxFailureCount = 8;
    IF NOT EXISTS (SELECT 1 FROM [po].[RelexNotificationEvent]
        WHERE [NotificationId] = @notification AND [Status] = 'ENQUEUED' AND [LeaseId] IS NULL)
        THROW 52096, 'Enqueued event did not reach its terminal producer state.', 1;
    PRINT 'PASS:SCENARIO:RELEX_ENVELOPE_REPLAY_AND_COMPLETION';

    -- Results-disabled deployments must retain freshness through the candidate audit trail too.
    INSERT INTO [po].[PurchaseOrderAudit]
        ([CandidateKey], [Action], [Method], [Actor], [PreviousStatus], [CurrentStatus], [ChangedDateTime])
    SELECT [CandidateKey], 'SUBMISSION_SUCCEEDED', 'PROCESSOR', N'acceptance', 'SUBMISSION_IN_PROGRESS',
        CASE WHEN [Account] = N'A-SUPPLIER' THEN 'COMPLETED' ELSE 'NON_RECOVERABLE_ERROR' END,
        DATEADD(MINUTE, -1, @now)
    FROM [po].[PurchaseOrderCandidate] WHERE [Account] IN (N'A-SUPPLIER', N'B-SUPPLIER');
    UPDATE [po].[PurchaseOrderCandidate] SET [Status] = 'SUBMISSION_IN_PROGRESS',
        [LeaseToken] = NEWID(), [LeaseOwner] = N'acceptance-retry', [LeaseAcquiredDateTime] = @now,
        [LeaseExpiresDateTime] = DATEADD(SECOND, 300, @now) WHERE [Account] = N'B-SUPPLIER';
    INSERT INTO [po].[PurchaseOrderSubmissionAttempt]
        ([AttemptId], [CandidateKey], [AttemptNumber], [ClaimToken], [Status], [RequestPayloadJson],
        [PreparedDateTime], [DispatchedDateTime], [CreatedBy])
    SELECT NEWID(), [CandidateKey], 1, [LeaseToken], 'DISPATCHED', N'{}', @now, @now, N'acceptance'
        FROM [po].[PurchaseOrderCandidate] WHERE [Account] = N'B-SUPPLIER';
    DELETE FROM [po].[RelexNotificationEvent] WHERE [NotificationId] = @notification;
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @now, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 0,
        @compositionSettingsJson = @settings, @missingCutoffDateTime = @now,
        @missingFreshSinceDateTime = @fresh, @missingEventKey = N'RELEX_MISSING:2026-09-24';
    IF EXISTS (SELECT 1 FROM @claims) OR EXISTS (SELECT 1 FROM [po].[RelexNotificationEvent])
        THROW 52103, 'A manual retry erased audited processing history while result production was disabled.', 1;
    PRINT 'PASS:RELEX_FRESHNESS_FROM_AUDIT_WITHOUT_RESULTS_EVENT';

    -- A later terminal audit cannot retroactively suppress the cutoff, and every candidate is required.
    UPDATE audit SET [ChangedDateTime] = DATEADD(SECOND, 1, @now)
    FROM [po].[PurchaseOrderAudit] AS audit INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = audit.[CandidateKey] WHERE candidate.[Account] = N'B-SUPPLIER';
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @now, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 0,
        @compositionSettingsJson = @settings, @missingCutoffDateTime = @now,
        @missingFreshSinceDateTime = @fresh, @missingEventKey = N'RELEX_MISSING:2026-09-24';
    IF (SELECT COUNT(*) FROM @claims WHERE [EventType] = 'RELEX_MISSING') <> 1
        THROW 52104, 'Post-cutoff audit or one processed candidate incorrectly suppressed a missing alert.', 1;
    DELETE FROM [po].[RelexNotificationEvent] WHERE [EventKey] = N'RELEX_MISSING:2026-09-24';
    PRINT 'PASS:RELEX_CUTOFF_HISTORY_REQUIRES_EVERY_CANDIDATE_BEFORE_CUTOFF';

    -- At a later cutoff all processed history is stale; empty/failed files remain non-refreshing.
    DECLARE @later datetimeoffset(3) = DATEADD(HOUR, 7, @now),
        @laterFresh datetimeoffset(3) = DATEADD(HOUR, 1, @now),
        @retryAt datetimeoffset(3) = DATEADD(HOUR, 8, @now),
        @beforeRetry datetimeoffset(3) = DATEADD(MINUTE, 30, DATEADD(HOUR, 7, @now));
    UPDATE [po].[PurchaseOrderBatch] SET [DiscoveredDateTime] = @later
        WHERE [OriginalFileName] IN (N'empty.csv', N'failed.csv');
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @later, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 0,
        @compositionSettingsJson = @settings, @missingCutoffDateTime = @later,
        @missingFreshSinceDateTime = @laterFresh, @missingEventKey = N'RELEX_MISSING:2026-09-25';
    IF (SELECT COUNT(*) FROM @claims) <> 1 OR NOT EXISTS
        (SELECT 1 FROM @claims WHERE [EventType] = 'RELEX_MISSING' AND [BatchId] IS NULL
            AND [CreatedDateTime] = @later AND [OutcomeRowsJson] = N'[]')
        THROW 52099, 'A stale-file cutoff did not create exactly one missing-proposal event.', 1;
    SELECT @notification = [NotificationId], @lease = [LeaseId] FROM @claims;
    EXEC [po].[sp_complete_relex_notification_event] @notificationId = @notification, @leaseId = @lease,
        @enqueued = 0, @permanentFailure = 0, @completedDateTime = @later,
        @nextAttemptDateTime = @retryAt, @failureCode = 'SYNTHETIC_TRANSIENT', @maxFailureCount = 2;
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @beforeRetry, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 0,
        @compositionSettingsJson = @settings, @missingCutoffDateTime = @later,
        @missingFreshSinceDateTime = @laterFresh, @missingEventKey = N'RELEX_MISSING:2026-09-25';
    IF EXISTS (SELECT 1 FROM @claims)
        OR (SELECT COUNT(*) FROM [po].[RelexNotificationEvent] WHERE [EventType] = 'RELEX_MISSING') <> 1
        THROW 52100, 'Daily deduplication or retry delay was not enforced.', 1;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @retryAt, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 0,
        @compositionSettingsJson = @settings;
    IF NOT EXISTS (SELECT 1 FROM @claims WHERE [NotificationId] = @notification AND [FailureCount] = 1)
        THROW 52101, 'A due producer retry did not retain its failure counter.', 1;
    SELECT @lease = [LeaseId] FROM @claims;
    EXEC [po].[sp_complete_relex_notification_event] @notificationId = @notification, @leaseId = @lease,
        @enqueued = 0, @permanentFailure = 1, @completedDateTime = @retryAt,
        @failureCode = 'SYNTHETIC_PERMANENT', @maxFailureCount = 2;
    IF NOT EXISTS (SELECT 1 FROM [po].[RelexNotificationEvent] WHERE [NotificationId] = @notification
        AND [Status] = 'FAILED' AND [FailureCount] = 2 AND [LeaseId] IS NULL)
        THROW 52102, 'A failed producer event was not terminalized.', 1;
    PRINT 'PASS:RELEX_MISSING_DAILY_DEDUP_AND_RETRY';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    THROW;
END CATCH;

-- A stale-lease failure rolls back its outer transaction, so it has an isolated fixture.
-- SCENARIO:RELEX_STALE_LEASE_REJECTED
DECLARE @rejected bit = 0;
BEGIN TRY
    BEGIN TRANSACTION;
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @now, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 0,
        @compositionSettingsJson = @settings, @missingCutoffDateTime = @now,
        @missingFreshSinceDateTime = @fresh, @missingEventKey = N'RELEX_MISSING:2026-09-24';
    SELECT @notification = [NotificationId], @lease = NEWID() FROM @claims;
    EXEC [po].[sp_complete_relex_notification_event] @notificationId = @notification, @leaseId = @lease,
        @enqueued = 0, @permanentFailure = 1, @completedDateTime = @now,
        @failureCode = 'SYNTHETIC', @maxFailureCount = 8;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    IF ERROR_NUMBER() = 51003 SET @rejected = 1; ELSE THROW;
END CATCH;
IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
IF @rejected = 0 THROW 52097, 'A stale lease unexpectedly completed an event.', 1;
PRINT 'PASS:SCENARIO:RELEX_STALE_LEASE_REJECTED';

-- SCENARIO:RELEX_LARGE_SNAPSHOT_ISOLATION
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO [po].[PurchaseOrderBatch]
        ([BatchId], [Source], [OriginalFileName], [SourceFilePath], [FileContentLength], [FileSha256],
        [Status], [ParsedRowCount], [CandidateCount], [DiscoveredDateTime], [CompletedDateTime], [CreatedBy], [UpdatedDateTime])
    VALUES ('A5900000-0000-4000-8000-000000000010', N'Relex', N'oversize.csv', N'/synthetic/oversize.csv',
        2048, HASHBYTES('SHA2_256', N'oversize.csv'), 'COMPLETED', 9000, 9000, @fresh, @now, N'acceptance', @now),
        ('A5900000-0000-4000-8000-000000000011', N'Relex', N'following.csv', N'/synthetic/following.csv',
        2048, HASHBYTES('SHA2_256', N'following.csv'), 'COMPLETED', 1, 1, @fresh, @now, N'acceptance', @now),
        ('A5900000-0000-4000-8000-000000000012', N'Relex', N'fits.csv', N'/synthetic/fits.csv',
        2048, HASHBYTES('SHA2_256', N'fits.csv'), 'COMPLETED', 2000, 2000, @fresh, @now, N'acceptance', @now);
    ;WITH digits AS (SELECT digit FROM (VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9)) AS d(digit)),
    numbers AS (SELECT TOP (9000) ROW_NUMBER() OVER (ORDER BY a.digit, b.digit, c.digit, d.digit) AS n
        FROM digits a CROSS JOIN digits b CROSS JOIN digits c CROSS JOIN digits d)
    INSERT INTO [po].[PurchaseOrderCandidate]
        ([CandidateId], [BatchKey], [Source], [Kind], [SourceRowCount], [Account], [Branch],
        [Status], [StatusDateTime], [MessageDescription], [PayloadJson], [AcceptedDateTime],
        [CreatedDateTime], [UpdatedDateTime], [RefreshDateTime])
    SELECT NEWID(), batch.[BatchKey], N'Relex', 'RELEX', 1, N'SYNTHETIC', N'001',
        'NON_RECOVERABLE_ERROR', @now, REPLICATE(N'x', 1000), N'{}', @fresh, @fresh, @now, @now
    FROM numbers CROSS JOIN [po].[PurchaseOrderBatch] AS batch
    WHERE batch.[OriginalFileName] = N'oversize.csv'
        OR (batch.[OriginalFileName] = N'fits.csv' AND numbers.n <= 2000);
    INSERT INTO [po].[PurchaseOrderCandidate]
        ([CandidateId], [BatchKey], [Source], [Kind], [SourceRowCount], [Account], [Branch],
        [Status], [StatusDateTime], [PayloadJson], [AcceptedDateTime], [CreatedDateTime], [UpdatedDateTime], [RefreshDateTime])
    SELECT NEWID(), [BatchKey], N'Relex', 'RELEX', 1, N'SYNTHETIC', N'001', 'CANCELLED', @now,
        N'{}', @fresh, @fresh, @now, @now FROM [po].[PurchaseOrderBatch] WHERE [OriginalFileName] = N'following.csv';
    DELETE FROM @claims;
    INSERT INTO @claims EXEC [po].[sp_prepare_and_claim_relex_notification_events]
        @asOfDateTime = @now, @maxEvents = 10, @leaseDurationSeconds = 300, @resultsEnabled = 1,
        @compositionSettingsJson = @settings, @resultsNotBeforeDateTime = @since;
    IF NOT EXISTS (SELECT 1 FROM [po].[RelexNotificationEvent] WHERE [OriginalFileName] = N'oversize.csv'
        AND [Status] = 'FAILED' AND [FailureCode] = 'OUTCOME_SNAPSHOT_TOO_LARGE')
        OR NOT EXISTS (SELECT 1 FROM @claims WHERE [OriginalFileName] = N'following.csv')
        OR NOT EXISTS (SELECT 1 FROM @claims WHERE [OriginalFileName] = N'fits.csv'
            AND DATALENGTH([OutcomeRowsJson]) BETWEEN 4 * 1024 * 1024 AND 16 * 1024 * 1024)
        THROW 52098, 'An oversized batch prevented later notification production.', 1;
    PRINT 'PASS:SCENARIO:RELEX_LARGE_SNAPSHOT_ISOLATION';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 BEGIN ROLLBACK TRANSACTION; END;
    THROW;
END CATCH;
