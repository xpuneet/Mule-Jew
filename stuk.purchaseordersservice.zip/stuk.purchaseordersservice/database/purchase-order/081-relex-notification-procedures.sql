CREATE OR ALTER PROCEDURE [po].[sp_prepare_and_claim_relex_notification_events]
    @asOfDateTime datetimeoffset(3),
    @maxEvents int,
    @leaseDurationSeconds int,
    @resultsEnabled bit,
    @compositionSettingsJson nvarchar(max),
    @resultsNotBeforeDateTime datetimeoffset(3) = NULL,
    @missingCutoffDateTime datetimeoffset(3) = NULL,
    @missingFreshSinceDateTime datetimeoffset(3) = NULL,
    @missingEventKey nvarchar(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @asOfDateTime IS NULL OR DATEPART(TZOFFSET, @asOfDateTime) <> 0
        OR @maxEvents IS NULL OR @maxEvents NOT BETWEEN 1 AND 100
        OR @leaseDurationSeconds IS NULL OR @leaseDurationSeconds NOT BETWEEN 30 AND 3600
        OR @resultsEnabled IS NULL
        OR (@resultsEnabled = 1 AND @resultsNotBeforeDateTime IS NULL)
        OR (@resultsNotBeforeDateTime IS NOT NULL AND DATEPART(TZOFFSET, @resultsNotBeforeDateTime) <> 0)
        OR @compositionSettingsJson IS NULL OR ISJSON(@compositionSettingsJson) <> 1
        OR DATALENGTH(@compositionSettingsJson) > 65536
    BEGIN
        ;THROW 51004, 'The Relex notification preparation settings are invalid.', 1;
    END;
    IF (@missingCutoffDateTime IS NULL AND
            (@missingFreshSinceDateTime IS NOT NULL OR @missingEventKey IS NOT NULL))
        OR (@missingCutoffDateTime IS NOT NULL AND
            (@missingFreshSinceDateTime IS NULL OR @missingEventKey IS NULL
            OR DATEPART(TZOFFSET, @missingCutoffDateTime) <> 0
            OR DATEPART(TZOFFSET, @missingFreshSinceDateTime) <> 0
            OR @missingFreshSinceDateTime > @missingCutoffDateTime
            OR @asOfDateTime < @missingCutoffDateTime
            OR LEN(@missingEventKey) <> 24
            OR LEFT(@missingEventKey, 14) COLLATE Latin1_General_100_BIN2 <> N'RELEX_MISSING:'
            OR TRY_CONVERT(date, RIGHT(@missingEventKey, 10), 23) IS NULL
            OR RIGHT(@missingEventKey, 10) COLLATE Latin1_General_100_BIN2
                <> CONVERT(nvarchar(10), TRY_CONVERT(date, RIGHT(@missingEventKey, 10), 23), 23)))
    BEGIN
        ;THROW 51004, 'The Relex missing-proposal cutoff metadata is invalid.', 1;
    END;

    DECLARE @batchKey bigint, @batchId uniqueidentifier, @fileName nvarchar(260),
        @discovered datetimeoffset(3), @expectedCount int, @outcomes nvarchar(max),
        @processingCompleted datetimeoffset(3), @tooLarge bit, @lockResult int,
        @actualCount bigint, @invalidCount bigint;
    DECLARE @batches TABLE ([BatchKey] bigint PRIMARY KEY);
    DECLARE @rows TABLE
    (
        [CandidateKey] bigint PRIMARY KEY, [Branch] nvarchar(20), [Supplier] nvarchar(50),
        [OrderNumber] nvarchar(100), [CreateStatus] nvarchar(1000), [Suspended] bit,
        [SuspendedMessage] nvarchar(1000), [Bypass] bit, [DeliveryMode] nvarchar(4000),
        [ApiUser] nvarchar(4000), [CandidateStatus] varchar(50), [StatusDateTime] datetimeoffset(3),
        [HasLease] bit, [HasDispatchedAttempt] bit
    );
    DECLARE @claimed TABLE ([NotificationId] uniqueidentifier PRIMARY KEY);

    BEGIN TRY
        BEGIN TRANSACTION;
        -- Serializes event discovery/daily deduplication, not business processing or email sends.
        EXEC @lockResult = sys.sp_getapplock @Resource = N'po.relex-notification-prepare',
            @LockMode = 'Exclusive', @LockOwner = 'Transaction', @LockTimeout = 10000;
        IF @lockResult < 0
            THROW 51003, 'The Relex notification preparation lock is unavailable.', 1;

        IF @resultsEnabled = 1
        BEGIN
            INSERT INTO @batches
            SELECT TOP (@maxEvents) batch.[BatchKey]
            FROM [po].[PurchaseOrderBatch] AS batch
            WHERE batch.[Source] = N'Relex' AND batch.[Status] = 'COMPLETED'
                AND batch.[CandidateCount] > 0 AND batch.[DiscoveredDateTime] >= @resultsNotBeforeDateTime
                AND batch.[DiscoveredDateTime] <= @asOfDateTime
                AND NOT EXISTS (SELECT 1 FROM [po].[RelexNotificationEvent] AS event
                    WHERE event.[BatchKey] = batch.[BatchKey])
                AND batch.[CandidateCount] = (SELECT COUNT_BIG(*) FROM [po].[PurchaseOrderCandidate] AS counted
                    WHERE counted.[BatchKey] = batch.[BatchKey])
                AND NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderCandidate] AS candidate
                    WHERE candidate.[BatchKey] = batch.[BatchKey]
                    AND (candidate.[Status] NOT IN ('COMPLETED', 'RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR', 'CANCELLED')
                        OR candidate.[LeaseToken] IS NOT NULL OR candidate.[StatusDateTime] > @asOfDateTime
                        OR EXISTS (SELECT 1 FROM [po].[PurchaseOrderSubmissionAttempt] AS dispatched
                            WHERE dispatched.[CandidateKey] = candidate.[CandidateKey] AND dispatched.[Status] = 'DISPATCHED')))
            ORDER BY batch.[DiscoveredDateTime], batch.[BatchKey];

            WHILE EXISTS (SELECT 1 FROM @batches)
            BEGIN
                SELECT TOP (1) @batchKey = [BatchKey] FROM @batches ORDER BY [BatchKey];
                DELETE FROM @batches WHERE [BatchKey] = @batchKey;
                DELETE FROM @rows;
                SELECT @batchId = [BatchId], @fileName = [OriginalFileName],
                    @discovered = [DiscoveredDateTime], @expectedCount = [CandidateCount]
                FROM [po].[PurchaseOrderBatch] WITH (UPDLOCK, HOLDLOCK)
                WHERE [BatchKey] = @batchKey;

                SET @tooLarge = 0;
                IF @expectedCount > 100000
                BEGIN
                    -- Establish readiness without loading a potentially unbounded result table.
                    SELECT @actualCount = COUNT_BIG(*), @processingCompleted = MAX([StatusDateTime]),
                        @invalidCount = SUM(CONVERT(bigint, CASE WHEN [Status] NOT IN
                            ('COMPLETED', 'RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR', 'CANCELLED')
                            OR [LeaseToken] IS NOT NULL OR [StatusDateTime] > @asOfDateTime THEN 1 ELSE 0 END))
                    FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK) WHERE [BatchKey] = @batchKey;
                    IF @actualCount <> @expectedCount OR @invalidCount <> 0 OR EXISTS
                        (SELECT 1 FROM [po].[PurchaseOrderSubmissionAttempt] AS pending WITH (HOLDLOCK)
                        INNER JOIN [po].[PurchaseOrderCandidate] AS candidate ON candidate.[CandidateKey] = pending.[CandidateKey]
                        WHERE candidate.[BatchKey] = @batchKey AND pending.[Status] = 'DISPATCHED')
                        CONTINUE;
                    SET @tooLarge = 1;
                END
                ELSE
                BEGIN
                -- Candidate locks cover support retry/cancel and submission. Attempt range locks
                -- prevent a new attempt or changed result from producing a mixed snapshot.
                INSERT INTO @rows
                SELECT candidate.[CandidateKey], candidate.[Branch], candidate.[Account],
                    COALESCE(candidate.[IconPurchaseOrderNumber], attempt.[IconPurchaseOrderNumber]),
                    COALESCE(attempt.[IconCreatedStatus], candidate.[MessageDescription], candidate.[StatusReason],
                        CASE WHEN candidate.[Status] = 'CANCELLED' THEN N'Cancelled' ELSE N'Purchase Order timed out' END),
                    attempt.[IconSuspended], attempt.[IconSuspendMessage],
                    CASE JSON_VALUE(attempt.[RequestPayloadJson], '$.header.bypass')
                        WHEN N'true' THEN CONVERT(bit, 1) WHEN N'false' THEN CONVERT(bit, 0) ELSE NULL END,
                    COALESCE(JSON_VALUE(attempt.[RequestPayloadJson], '$.header.deliveryMethod'),
                        JSON_VALUE(candidate.[PayloadJson], '$.purchaseOrderHeader.deliveryMethod')),
                    COALESCE(JSON_VALUE(attempt.[RequestPayloadJson], '$.header.createUser'),
                        JSON_VALUE(candidate.[PayloadJson], '$.purchaseOrderHeader.createUser')),
                    candidate.[Status], candidate.[StatusDateTime],
                    CONVERT(bit, CASE WHEN candidate.[LeaseToken] IS NULL THEN 0 ELSE 1 END),
                    CONVERT(bit, CASE WHEN EXISTS
                        (SELECT 1 FROM [po].[PurchaseOrderSubmissionAttempt] AS dispatched WITH (HOLDLOCK)
                            WHERE dispatched.[CandidateKey] = candidate.[CandidateKey] AND dispatched.[Status] = 'DISPATCHED')
                        THEN 1 ELSE 0 END)
                FROM [po].[PurchaseOrderCandidate] AS candidate WITH (UPDLOCK, HOLDLOCK)
                OUTER APPLY
                (
                    SELECT TOP (1) history.[RequestPayloadJson], history.[IconPurchaseOrderNumber],
                        history.[IconCreatedStatus], history.[IconSuspended], history.[IconSuspendMessage]
                    FROM [po].[PurchaseOrderSubmissionAttempt] AS history WITH (HOLDLOCK)
                    WHERE history.[CandidateKey] = candidate.[CandidateKey]
                    ORDER BY history.[AttemptNumber] DESC, history.[AttemptKey] DESC
                ) AS attempt
                WHERE candidate.[BatchKey] = @batchKey;
                END;

                IF @tooLarge = 1 OR ((SELECT COUNT_BIG(*) FROM @rows) = @expectedCount
                    AND NOT EXISTS (SELECT 1 FROM @rows WHERE [CandidateStatus] NOT IN
                        ('COMPLETED', 'RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR', 'CANCELLED')
                        OR [HasLease] = 1 OR [HasDispatchedAttempt] = 1 OR [StatusDateTime] > @asOfDateTime))
                BEGIN
                    IF @tooLarge = 0
                    BEGIN
                    SELECT @processingCompleted = MAX([StatusDateTime]) FROM @rows;
                    -- Size each bounded row with the actual SQL JSON encoder. Array brackets and
                    -- separators add 2 * rowCount + 2 UTF-16 bytes. ASCII must not pay a 6x escape estimate.
                    SELECT @tooLarge = CASE WHEN
                        COALESCE(SUM(CONVERT(bigint, DATALENGTH(serialized.[RowJson]))), 0)
                            + 2 * COUNT_BIG(*) + 2 > 16 * 1024 * 1024 THEN 1 ELSE 0 END
                    FROM (SELECT *, CONVERT(int, ROW_NUMBER() OVER
                        (ORDER BY [Supplier], [Branch], [CandidateKey])) AS [Counter] FROM @rows) AS numbered
                    CROSS APPLY
                    (
                        SELECT (SELECT numbered.[Counter] AS [counter], numbered.[Branch] AS [branch],
                            numbered.[Supplier] AS [supplier], numbered.[OrderNumber] AS [orderNumber],
                            numbered.[CreateStatus] AS [createStatus], numbered.[Suspended] AS [suspended],
                            numbered.[SuspendedMessage] AS [suspendedMessage], numbered.[Bypass] AS [bypass],
                            numbered.[DeliveryMode] AS [deliveryMode], numbered.[ApiUser] AS [apiUser],
                            numbered.[CandidateStatus] AS [candidateStatus]
                            FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER) AS [RowJson]
                    ) AS serialized;
                    END;
                    SET @outcomes = N'[]';
                    IF @tooLarge = 0
                        SET @outcomes = (SELECT
                            CONVERT(int, ROW_NUMBER() OVER (ORDER BY [Supplier], [Branch], [CandidateKey])) AS [counter],
                            [Branch] AS [branch], [Supplier] AS [supplier], [OrderNumber] AS [orderNumber],
                            [CreateStatus] AS [createStatus], [Suspended] AS [suspended],
                            [SuspendedMessage] AS [suspendedMessage], [Bypass] AS [bypass],
                            [DeliveryMode] AS [deliveryMode], [ApiUser] AS [apiUser],
                            [CandidateStatus] AS [candidateStatus]
                            FROM @rows ORDER BY [Supplier], [Branch], [CandidateKey] FOR JSON PATH, INCLUDE_NULL_VALUES);
                    IF DATALENGTH(@outcomes) > 16 * 1024 * 1024
                    BEGIN
                        SET @tooLarge = 1;
                        SET @outcomes = N'[]';
                    END;
                    INSERT INTO [po].[RelexNotificationEvent]
                        ([EventKey], [NotificationId], [BatchKey], [EventType], [BusinessCorrelationId],
                        [OriginalFileName], [ProcessedFileDateTime], [ProcessingCompletedDateTime],
                        [CreatedDateTime], [CompositionSettingsJson], [OutcomeRowsJson], [Status],
                        [FailureCount], [NextAttemptDateTime], [CompletedDateTime], [FailureCode])
                    VALUES (N'RELEX_RESULTS:' + LOWER(CONVERT(nvarchar(36), @batchId)), NEWID(), @batchKey,
                        'RELEX_RESULTS', N'Relex:' + LOWER(CONVERT(nvarchar(36), @batchId)), @fileName,
                        @discovered, @processingCompleted, @asOfDateTime, @compositionSettingsJson, @outcomes,
                        CASE WHEN @tooLarge = 1 THEN 'FAILED' ELSE 'PENDING' END,
                        CASE WHEN @tooLarge = 1 THEN 1 ELSE 0 END, @asOfDateTime,
                        CASE WHEN @tooLarge = 1 THEN @asOfDateTime ELSE NULL END,
                        CASE WHEN @tooLarge = 1 THEN 'OUTCOME_SNAPSHOT_TOO_LARGE' ELSE NULL END);
                END;
            END;
        END;

        IF @missingCutoffDateTime IS NOT NULL
            AND NOT EXISTS (SELECT 1 FROM [po].[RelexNotificationEvent] WHERE [EventKey] = @missingEventKey)
            AND NOT EXISTS
            (
                -- Persisted results retain initial processing history after a support retry.
                SELECT 1 FROM [po].[RelexNotificationEvent]
                WHERE [EventType] = 'RELEX_RESULTS' AND [ProcessedFileDateTime] >= @missingFreshSinceDateTime
                    AND [ProcessedFileDateTime] <= @missingCutoffDateTime
                    AND [ProcessingCompletedDateTime] <= @missingCutoffDateTime
            )
            AND NOT EXISTS
            (
                SELECT 1 FROM [po].[PurchaseOrderBatch] AS batch WITH (HOLDLOCK)
                WHERE batch.[Source] = N'Relex' AND batch.[Status] = 'COMPLETED' AND batch.[CandidateCount] > 0
                    AND batch.[DiscoveredDateTime] >= @missingFreshSinceDateTime
                    AND batch.[DiscoveredDateTime] <= @missingCutoffDateTime
                    AND batch.[CandidateCount] = (SELECT COUNT_BIG(*)
                        FROM [po].[PurchaseOrderCandidate] AS counted WITH (HOLDLOCK) WHERE counted.[BatchKey] = batch.[BatchKey])
                    AND NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderCandidate] AS candidate WITH (HOLDLOCK)
                        WHERE candidate.[BatchKey] = batch.[BatchKey]
                            -- Every candidate must have finished its initial processing by cutoff.
                            -- Durable audit also preserves this fact when results production was disabled
                            -- and a subsequent manual retry is now active.
                            AND NOT EXISTS (SELECT 1 FROM [po].[PurchaseOrderAudit] AS audit WITH (HOLDLOCK)
                                WHERE audit.[CandidateKey] = candidate.[CandidateKey]
                                    AND audit.[Method] IN ('PROCESSOR', 'SUPPORT', 'SYSTEM')
                                    AND audit.[CurrentStatus] IN ('COMPLETED', 'RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR', 'CANCELLED')
                                    AND audit.[ChangedDateTime] <= @missingCutoffDateTime)
                            AND (candidate.[Status] NOT IN ('COMPLETED', 'RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR', 'CANCELLED')
                                OR candidate.[LeaseToken] IS NOT NULL OR candidate.[StatusDateTime] > @missingCutoffDateTime
                                OR EXISTS (SELECT 1 FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt WITH (HOLDLOCK)
                                    WHERE attempt.[CandidateKey] = candidate.[CandidateKey] AND attempt.[Status] = 'DISPATCHED')))
            )
        BEGIN
            INSERT INTO [po].[RelexNotificationEvent]
                ([EventKey], [NotificationId], [EventType], [BusinessCorrelationId], [CreatedDateTime],
                [CompositionSettingsJson], [OutcomeRowsJson], [Status], [FailureCount], [NextAttemptDateTime])
            VALUES (@missingEventKey, NEWID(), 'RELEX_MISSING', @missingEventKey, @missingCutoffDateTime,
                @compositionSettingsJson, N'[]', 'PENDING', 0, @asOfDateTime);
        END;

        ;WITH due AS
        (
            SELECT TOP (@maxEvents) [EventKey], [NextAttemptDateTime], [CreatedDateTime],
                CONVERT(bigint, DATALENGTH([CompositionSettingsJson])) + DATALENGTH([OutcomeRowsJson])
                    + COALESCE(DATALENGTH([EmailEnvelopeJson]), 0) AS [PayloadBytes]
            FROM [po].[RelexNotificationEvent] WITH (UPDLOCK, READPAST, READCOMMITTEDLOCK)
            WHERE ([Status] = 'PENDING' AND [NextAttemptDateTime] <= @asOfDateTime)
                OR ([Status] = 'PROCESSING' AND [LeaseExpiresDateTime] <= @asOfDateTime)
            ORDER BY [NextAttemptDateTime], [CreatedDateTime], [EventKey]
        ), sized AS
        (
            SELECT [EventKey], ROW_NUMBER() OVER (ORDER BY [NextAttemptDateTime], [CreatedDateTime], [EventKey]) AS [Ordinal],
                SUM([PayloadBytes]) OVER (ORDER BY [NextAttemptDateTime], [CreatedDateTime], [EventKey]
                    ROWS UNBOUNDED PRECEDING) AS [RunningPayloadBytes]
            FROM due
        )
        UPDATE event SET [Status] = 'PROCESSING', [LeaseId] = NEWID(),
            [LeaseExpiresDateTime] = DATEADD(SECOND, @leaseDurationSeconds, @asOfDateTime)
        OUTPUT inserted.[NotificationId] INTO @claimed
        FROM [po].[RelexNotificationEvent] AS event
        INNER JOIN sized ON sized.[EventKey] = event.[EventKey]
        -- One individually bounded event always makes progress, even above the aggregate budget.
        WHERE sized.[Ordinal] = 1 OR sized.[RunningPayloadBytes] <= 32 * 1024 * 1024;

        COMMIT TRANSACTION;
        SELECT event.[NotificationId], batch.[BatchId], event.[EventType], event.[BusinessCorrelationId],
            event.[OriginalFileName], event.[CreatedDateTime], event.[CompositionSettingsJson],
            event.[OutcomeRowsJson], event.[EmailEnvelopeJson], event.[LeaseId], event.[FailureCount]
        FROM [po].[RelexNotificationEvent] AS event
        INNER JOIN @claimed AS claimed ON claimed.[NotificationId] = event.[NotificationId]
        LEFT JOIN [po].[PurchaseOrderBatch] AS batch ON batch.[BatchKey] = event.[BatchKey]
        ORDER BY event.[NextAttemptDateTime], event.[CreatedDateTime], event.[EventKey];
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_save_relex_notification_envelope]
    @notificationId uniqueidentifier,
    @leaseId uniqueidentifier,
    @emailEnvelopeJson nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @notificationId IS NULL OR @leaseId IS NULL OR @emailEnvelopeJson IS NULL
        OR ISJSON(@emailEnvelopeJson) <> 1 OR DATALENGTH(@emailEnvelopeJson) > 20 * 1024 * 1024
        THROW 51004, 'The Relex email envelope is invalid.', 1;

    DECLARE @correlation nvarchar(256), @saved nvarchar(max), @status varchar(50),
        @currentLease uniqueidentifier, @leaseExpires datetimeoffset(3);
    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @correlation = [BusinessCorrelationId], @saved = [EmailEnvelopeJson], @status = [Status],
            @currentLease = [LeaseId], @leaseExpires = [LeaseExpiresDateTime]
        FROM [po].[RelexNotificationEvent] WITH (UPDLOCK, HOLDLOCK) WHERE [NotificationId] = @notificationId;
        IF @status IS NULL THROW 51001, 'The Relex notification event was not found.', 1;
        IF @status <> 'PROCESSING' OR @currentLease IS NULL OR @currentLease <> @leaseId
            OR @leaseExpires <= SYSUTCDATETIME()
            THROW 51003, 'The Relex notification lease is no longer owned.', 1;
        IF @saved IS NULL
        BEGIN
            IF TRY_CONVERT(uniqueidentifier, JSON_VALUE(@emailEnvelopeJson, '$.notificationId')) IS NULL
                OR TRY_CONVERT(uniqueidentifier, JSON_VALUE(@emailEnvelopeJson, '$.notificationId')) <> @notificationId
                OR DATALENGTH(JSON_VALUE(@emailEnvelopeJson, '$.notificationId')) <> 72
                OR COALESCE(TRY_CONVERT(int, JSON_VALUE(@emailEnvelopeJson, '$.schemaVersion')), 0) <> 1
                OR JSON_VALUE(@emailEnvelopeJson, '$.businessCorrelationId') IS NULL
                OR JSON_VALUE(@emailEnvelopeJson, '$.businessCorrelationId') COLLATE Latin1_General_100_BIN2
                    <> @correlation COLLATE Latin1_General_100_BIN2
                OR DATALENGTH(JSON_VALUE(@emailEnvelopeJson, '$.businessCorrelationId')) <> DATALENGTH(@correlation)
                THROW 51004, 'The Relex email envelope identity differs from its event.', 1;
            UPDATE [po].[RelexNotificationEvent] SET [EmailEnvelopeJson] = @emailEnvelopeJson
                WHERE [NotificationId] = @notificationId;
            SET @saved = @emailEnvelopeJson;
        END;
        COMMIT TRANSACTION;
        SELECT @saved AS [EmailEnvelopeJson];
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_complete_relex_notification_event]
    @notificationId uniqueidentifier,
    @leaseId uniqueidentifier,
    @enqueued bit,
    @permanentFailure bit,
    @completedDateTime datetimeoffset(3),
    @nextAttemptDateTime datetimeoffset(3) = NULL,
    @failureCode varchar(100) = NULL,
    @maxFailureCount int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @notificationId IS NULL OR @leaseId IS NULL OR @enqueued IS NULL OR @permanentFailure IS NULL
        OR @completedDateTime IS NULL OR DATEPART(TZOFFSET, @completedDateTime) <> 0
        OR @maxFailureCount IS NULL OR @maxFailureCount NOT BETWEEN 1 AND 100
        OR (@nextAttemptDateTime IS NOT NULL AND DATEPART(TZOFFSET, @nextAttemptDateTime) <> 0)
        OR (@enqueued = 1 AND (@permanentFailure = 1 OR @failureCode IS NOT NULL OR @nextAttemptDateTime IS NOT NULL))
        OR (@enqueued = 0 AND NULLIF(LTRIM(RTRIM(@failureCode)), '') IS NULL)
        OR (@enqueued = 0 AND @permanentFailure = 0 AND
            (@nextAttemptDateTime IS NULL OR @nextAttemptDateTime <= @completedDateTime))
        THROW 51004, 'The Relex notification completion metadata is invalid.', 1;

    DECLARE @status varchar(50), @currentLease uniqueidentifier, @expires datetimeoffset(3),
        @failures int, @envelope nvarchar(max), @terminal bit, @eventType varchar(100),
        @batchKey bigint, @correlation nvarchar(256), @created datetimeoffset(3);
    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @status = [Status], @currentLease = [LeaseId], @expires = [LeaseExpiresDateTime],
            @failures = [FailureCount], @envelope = [EmailEnvelopeJson], @eventType = [EventType],
            @batchKey = [BatchKey], @correlation = [BusinessCorrelationId], @created = [CreatedDateTime]
        FROM [po].[RelexNotificationEvent] WITH (UPDLOCK, HOLDLOCK) WHERE [NotificationId] = @notificationId;
        IF @status IS NULL THROW 51001, 'The Relex notification event was not found.', 1;
        IF @status <> 'PROCESSING' OR @currentLease IS NULL OR @currentLease <> @leaseId
            OR @expires <= @completedDateTime
            THROW 51003, 'The Relex notification lease is no longer owned.', 1;
        IF @enqueued = 1 AND (@envelope IS NULL OR NOT EXISTS
            (SELECT 1 FROM [po].[PurchaseOrderNotification] WITH (HOLDLOCK)
                WHERE [NotificationId] = @notificationId AND [EmailEnvelopeVersion] = 1
                    AND [EventType] = @eventType AND [BusinessCorrelationId] = @correlation
                    AND [CreatedDateTime] = @created
                    AND ([BatchKey] = @batchKey OR ([BatchKey] IS NULL AND @batchKey IS NULL))
                    AND [PayloadSha256] = HASHBYTES('SHA2_256', CONVERT(varbinary(max), @envelope))))
            THROW 51004, 'The frozen Relex email envelope has not been enqueued.', 1;
        SET @terminal = CASE WHEN @enqueued = 0 AND (@permanentFailure = 1 OR @failures + 1 >= @maxFailureCount)
            THEN 1 ELSE 0 END;
        UPDATE [po].[RelexNotificationEvent]
        SET [Status] = CASE WHEN @enqueued = 1 THEN 'ENQUEUED' WHEN @terminal = 1 THEN 'FAILED' ELSE 'PENDING' END,
            [FailureCount] = @failures + CASE WHEN @enqueued = 1 THEN 0 ELSE 1 END,
            [NextAttemptDateTime] = COALESCE(@nextAttemptDateTime, @completedDateTime),
            [LeaseId] = NULL, [LeaseExpiresDateTime] = NULL,
            [CompletedDateTime] = CASE WHEN @enqueued = 1 OR @terminal = 1 THEN @completedDateTime ELSE NULL END,
            [FailureCode] = CASE WHEN @enqueued = 1 THEN NULL ELSE @failureCode END
        WHERE [NotificationId] = @notificationId;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO
