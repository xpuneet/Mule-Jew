CREATE OR ALTER PROCEDURE [po].[sp_request_purchase_order_retry]
    @candidateId uniqueidentifier,
    @actor nvarchar(256),
    @reason nvarchar(1000),
    @requestedDateTime datetimeoffset(3),
    @expectedCandidateRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    IF @reason IS NULL
       OR NULLIF(LTRIM(RTRIM(@reason)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The retry reason is required.', 1;
    END;

    IF @requestedDateTime IS NULL
       OR DATEPART(TZOFFSET, @requestedDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The requested timestamp must use the UTC offset.', 1;
    END;

    IF @expectedCandidateRowVersion IS NULL
    BEGIN
        ;THROW 51004, 'The expected candidate rowversion is required.', 1;
    END;

    DECLARE @candidateKey bigint;
    DECLARE @candidateStatus varchar(50);
    DECLARE @statusDateTime datetimeoffset(3);
    DECLARE @refreshDateTime datetimeoffset(3);
    DECLARE @leaseToken uniqueidentifier;
    DECLARE @candidateRowVersion binary(8);
    DECLARE @retriedCandidate TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT
            @candidateKey = [CandidateKey],
            @candidateStatus = [Status],
            @statusDateTime = [StatusDateTime],
            @refreshDateTime = [RefreshDateTime],
            @leaseToken = [LeaseToken],
            @candidateRowVersion = [RowVersion]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @candidateRowVersion <> @expectedCandidateRowVersion
        BEGIN
            ;THROW 51002, 'The purchase order candidate has changed.', 1;
        END;

        IF @candidateStatus NOT IN ('RECOVERABLE_ERROR', 'NON_RECOVERABLE_ERROR')
        BEGIN
            ;THROW 51004, 'The purchase order candidate is not eligible for manual retry.', 1;
        END;

        IF @leaseToken IS NOT NULL
        BEGIN
            ;THROW 51004, 'A leased purchase order candidate cannot be retried.', 1;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM [po].[PurchaseOrderSubmissionAttempt] WITH (UPDLOCK, HOLDLOCK)
            WHERE [CandidateKey] = @candidateKey
              AND [Status] = 'DISPATCHED'
              AND [CompletedDateTime] IS NULL
        )
        BEGIN
            ;THROW 51004, 'A purchase order candidate with an unresolved dispatch cannot be retried.', 1;
        END;

        IF @requestedDateTime < @statusDateTime
           OR @requestedDateTime < @refreshDateTime
        BEGIN
            ;THROW 51004, 'The requested timestamp cannot move candidate state backward.', 1;
        END;

        -- RETRY_REQUESTED authorizes one manual claim; it does not establish automatic retry policy.
        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [Status] = 'RETRY_REQUESTED',
            [StatusDateTime] = @requestedDateTime,
            [StatusReason] = @reason,
            [UpdatedDateTime] = @requestedDateTime,
            [RefreshDateTime] = @requestedDateTime
        OUTPUT
            inserted.[CandidateId],
            inserted.[Status],
            inserted.[RowVersion]
        INTO @retriedCandidate
        WHERE [CandidateKey] = @candidateKey;

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            'MANUAL_RETRY_REQUESTED',
            'SUPPORT',
            @actor,
            @reason,
            @candidateStatus,
            'RETRY_REQUESTED',
            NULL,
            NULL,
            NULL,
            @candidateId,
            @requestedDateTime
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [Status],
        [RowVersion]
    FROM @retriedCandidate;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_cancel_purchase_order_candidate]
    @candidateId uniqueidentifier,
    @actor nvarchar(256),
    @reason nvarchar(1000),
    @cancelledDateTime datetimeoffset(3),
    @expectedCandidateRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    IF @reason IS NULL
       OR NULLIF(LTRIM(RTRIM(@reason)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The cancellation reason is required.', 1;
    END;

    IF @cancelledDateTime IS NULL
       OR DATEPART(TZOFFSET, @cancelledDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The cancelled timestamp must use the UTC offset.', 1;
    END;

    IF @expectedCandidateRowVersion IS NULL
    BEGIN
        ;THROW 51004, 'The expected candidate rowversion is required.', 1;
    END;

    DECLARE @candidateKey bigint;
    DECLARE @candidateStatus varchar(50);
    DECLARE @statusDateTime datetimeoffset(3);
    DECLARE @refreshDateTime datetimeoffset(3);
    DECLARE @leaseToken uniqueidentifier;
    DECLARE @candidateRowVersion binary(8);
    DECLARE @cancelledCandidate TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT
            @candidateKey = [CandidateKey],
            @candidateStatus = [Status],
            @statusDateTime = [StatusDateTime],
            @refreshDateTime = [RefreshDateTime],
            @leaseToken = [LeaseToken],
            @candidateRowVersion = [RowVersion]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @candidateRowVersion <> @expectedCandidateRowVersion
        BEGIN
            ;THROW 51002, 'The purchase order candidate has changed.', 1;
        END;

        IF @candidateStatus IN ('COMPLETED', 'CANCELLED')
        BEGIN
            ;THROW 51004, 'A completed or cancelled purchase order candidate cannot be cancelled.', 1;
        END;

        IF @leaseToken IS NOT NULL
        BEGIN
            ;THROW 51004, 'A leased purchase order candidate cannot be cancelled.', 1;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM [po].[PurchaseOrderSubmissionAttempt] WITH (UPDLOCK, HOLDLOCK)
            WHERE [CandidateKey] = @candidateKey
              AND [Status] = 'DISPATCHED'
              AND [CompletedDateTime] IS NULL
        )
        BEGIN
            ;THROW 51004, 'A purchase order candidate with an unresolved dispatch cannot be cancelled.', 1;
        END;

        IF @cancelledDateTime < @statusDateTime
           OR @cancelledDateTime < @refreshDateTime
        BEGIN
            ;THROW 51004, 'The cancelled timestamp cannot move candidate state backward.', 1;
        END;

        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [Status] = 'CANCELLED',
            [StatusDateTime] = @cancelledDateTime,
            [StatusReason] = @reason,
            [UpdatedDateTime] = @cancelledDateTime,
            [RefreshDateTime] = @cancelledDateTime
        OUTPUT
            inserted.[CandidateId],
            inserted.[Status],
            inserted.[RowVersion]
        INTO @cancelledCandidate
        WHERE [CandidateKey] = @candidateKey;

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            'CANCELLED',
            'SUPPORT',
            @actor,
            @reason,
            @candidateStatus,
            'CANCELLED',
            NULL,
            NULL,
            NULL,
            @candidateId,
            @cancelledDateTime
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [Status],
        [RowVersion]
    FROM @cancelledCandidate;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_audit]
    @candidateId uniqueidentifier,
    @pageNumber int,
    @pageSize int
AS
BEGIN
    SET NOCOUNT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @pageNumber IS NULL OR @pageNumber < 1
    BEGIN
        ;THROW 51004, 'The page number must be at least one.', 1;
    END;

    IF @pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50
    BEGIN
        ;THROW 51004, 'The page size must be between one and fifty.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @candidateId
    )
    BEGIN
        ;THROW 51001, 'The purchase order candidate was not found.', 1;
    END;

    DECLARE @offset bigint =
        (CONVERT(bigint, @pageNumber) - 1) * CONVERT(bigint, @pageSize);

    SELECT
        audit.[Action],
        audit.[Method],
        audit.[Actor],
        audit.[Reason],
        audit.[PreviousStatus],
        audit.[CurrentStatus],
        audit.[PreviousPayloadJson],
        audit.[CurrentPayloadJson],
        audit.[BusinessPayloadHash],
        audit.[CorrelationId],
        audit.[ChangedDateTime]
    FROM [po].[PurchaseOrderAudit] AS audit
    INNER JOIN [po].[PurchaseOrderCandidate] AS candidate
        ON candidate.[CandidateKey] = audit.[CandidateKey]
    WHERE candidate.[CandidateId] = @candidateId
    ORDER BY audit.[ChangedDateTime] DESC, audit.[AuditKey] DESC
    OFFSET @offset ROWS
    FETCH NEXT @pageSize ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_batch_outcomes]
    @batchId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    DECLARE @batchKey bigint;

    SELECT @batchKey = [BatchKey]
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @batchId;

    IF @batchKey IS NULL
    BEGIN
        ;THROW 51001, 'The purchase order batch was not found.', 1;
    END;

    SELECT
        candidate.[CandidateId],
        candidate.[Account],
        candidate.[Branch],
        candidate.[Reference],
        candidate.[Status],
        candidate.[IconPurchaseOrderNumber],
        candidate.[StatusReason],
        candidate.[AcceptedDateTime],
        candidate.[UpdatedDateTime]
    FROM [po].[PurchaseOrderCandidate] AS candidate
    WHERE candidate.[BatchKey] = @batchKey
    ORDER BY candidate.[AcceptedDateTime], candidate.[CandidateId];
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_register_purchase_order_notification]
    @notificationId uniqueidentifier,
    @batchId uniqueidentifier,
    @channel varchar(50),
    @templateKey nvarchar(100),
    @recipientGroupKey nvarchar(100),
    @attachmentBlobName nvarchar(512) = NULL,
    @createdDateTime datetimeoffset(3)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @notificationId IS NULL
    BEGIN
        ;THROW 51004, 'The notification identifier is required.', 1;
    END;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    IF @channel IS NULL
       OR NULLIF(LTRIM(RTRIM(@channel)), '') IS NULL
    BEGIN
        ;THROW 51004, 'The notification channel is required.', 1;
    END;

    IF @templateKey IS NULL
       OR NULLIF(LTRIM(RTRIM(@templateKey)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The notification template key is required.', 1;
    END;

    IF @recipientGroupKey IS NULL
       OR NULLIF(LTRIM(RTRIM(@recipientGroupKey)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The notification recipient group key is required.', 1;
    END;

    IF @createdDateTime IS NULL
       OR DATEPART(TZOFFSET, @createdDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The created timestamp must use the UTC offset.', 1;
    END;

    DECLARE @batchKey bigint;
    DECLARE @batchStatus varchar(50);
    DECLARE @batchUpdatedDateTime datetimeoffset(3);
    DECLARE @registeredNotification TABLE
    (
        [NotificationId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT
            @batchKey = [BatchKey],
            @batchStatus = [Status],
            @batchUpdatedDateTime = [UpdatedDateTime]
        FROM [po].[PurchaseOrderBatch] WITH (UPDLOCK, HOLDLOCK)
        WHERE [BatchId] = @batchId;

        IF @batchKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order batch was not found.', 1;
        END;

        IF @batchStatus <> 'COMPLETED'
        BEGIN
            ;THROW 51004, 'Notifications can only be registered for a completed batch.', 1;
        END;

        IF @createdDateTime < @batchUpdatedDateTime
        BEGIN
            ;THROW 51004, 'The created timestamp cannot precede the completed batch state.', 1;
        END;

        INSERT INTO [po].[PurchaseOrderNotification]
        (
            [NotificationId],
            [BatchKey],
            [Channel],
            [TemplateKey],
            [RecipientGroupKey],
            [AttachmentBlobName],
            [Status],
            [ProviderMessageId],
            [FailureCode],
            [FailureDescription],
            [CreatedDateTime],
            [SentDateTime],
            [EventType],
            [BusinessCorrelationId],
            [EmailEnvelopeVersion],
            [EmailEnvelopeJson],
            [PayloadSha256],
            [NextAttemptDateTime]
        )
        OUTPUT
            inserted.[NotificationId],
            inserted.[Status],
            inserted.[RowVersion]
        INTO @registeredNotification
        VALUES
        (
            @notificationId,
            @batchKey,
            @channel,
            @templateKey,
            @recipientGroupKey,
            @attachmentBlobName,
            'PENDING',
            NULL,
            NULL,
            NULL,
            @createdDateTime,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            @createdDateTime
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [NotificationId],
        [Status],
        [RowVersion]
    FROM @registeredNotification;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_complete_purchase_order_notification]
    @notificationId uniqueidentifier,
    @status varchar(50),
    @providerMessageId nvarchar(256) = NULL,
    @failureCode varchar(100) = NULL,
    @failureDescription nvarchar(1000) = NULL,
    @completedDateTime datetimeoffset(3),
    @expectedNotificationRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @notificationId IS NULL
    BEGIN
        ;THROW 51004, 'The notification identifier is required.', 1;
    END;

    IF @status IS NULL OR @status NOT IN ('SENT', 'FAILED')
    BEGIN
        ;THROW 51004, 'The final notification status is invalid.', 1;
    END;

    IF @completedDateTime IS NULL
       OR DATEPART(TZOFFSET, @completedDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The completed timestamp must use the UTC offset.', 1;
    END;

    IF @expectedNotificationRowVersion IS NULL
    BEGIN
        ;THROW 51004, 'The expected notification rowversion is required.', 1;
    END;

    DECLARE @notificationKey bigint;
    DECLARE @currentStatus varchar(50);
    DECLARE @createdDateTime datetimeoffset(3);
    DECLARE @notificationRowVersion binary(8);
    DECLARE @emailEnvelopeJson nvarchar(max);
    DECLARE @completedNotification TABLE
    (
        [NotificationId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [SentDateTime] datetimeoffset(3) NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT
            @notificationKey = [NotificationKey],
            @currentStatus = [Status],
            @createdDateTime = [CreatedDateTime],
            @notificationRowVersion = [RowVersion],
            @emailEnvelopeJson = [EmailEnvelopeJson]
        FROM [po].[PurchaseOrderNotification] WITH (UPDLOCK, HOLDLOCK)
        WHERE [NotificationId] = @notificationId;

        IF @notificationKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order notification was not found.', 1;
        END;

        IF @notificationRowVersion <> @expectedNotificationRowVersion
        BEGIN
            ;THROW 51002, 'The purchase order notification has changed.', 1;
        END;

        IF @emailEnvelopeJson IS NOT NULL
        BEGIN
            ;THROW 51004, 'Email-envelope notifications must use the leased email completion procedure.', 1;
        END;

        IF @currentStatus <> 'PENDING'
        BEGIN
            ;THROW 51004, 'Only a pending purchase order notification can be completed.', 1;
        END;

        IF @completedDateTime < @createdDateTime
        BEGIN
            ;THROW 51004, 'The completed timestamp cannot precede notification creation.', 1;
        END;

        UPDATE [po].[PurchaseOrderNotification]
        SET
            [Status] = @status,
            [ProviderMessageId] = @providerMessageId,
            [FailureCode] = @failureCode,
            [FailureDescription] = @failureDescription,
            [SentDateTime] = CASE WHEN @status = 'SENT' THEN @completedDateTime ELSE NULL END,
            [CompletedDateTime] = @completedDateTime
        OUTPUT
            inserted.[NotificationId],
            inserted.[Status],
            inserted.[SentDateTime],
            inserted.[RowVersion]
        INTO @completedNotification
        WHERE [NotificationKey] = @notificationKey;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [NotificationId],
        [Status],
        [SentDateTime],
        [RowVersion]
    FROM @completedNotification;
END;
GO

DROP PROCEDURE IF EXISTS [po].[sp_complete_purchase_order_batch_processing];
GO

CREATE OR ALTER PROCEDURE [po].[sp_enqueue_purchase_order_email_notification]
    @notificationId uniqueidentifier,
    @batchId uniqueidentifier = NULL,
    @eventType varchar(100),
    @businessCorrelationId nvarchar(256),
    @emailEnvelopeVersion smallint,
    @emailEnvelopeJson nvarchar(max),
    @templateKey nvarchar(100) = NULL,
    @recipientGroupKey nvarchar(100) = NULL,
    @attachmentBlobName nvarchar(512) = NULL,
    @createdDateTime datetimeoffset(3)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @notificationId IS NULL OR @notificationId = '00000000-0000-0000-0000-000000000000'
       OR @emailEnvelopeVersion IS NULL OR @emailEnvelopeVersion <> 1
       OR NULLIF(LTRIM(RTRIM(@eventType)), '') IS NULL
       OR NULLIF(LTRIM(RTRIM(@businessCorrelationId)), N'') IS NULL
       OR (@templateKey IS NOT NULL AND NULLIF(LTRIM(RTRIM(@templateKey)), N'') IS NULL)
       OR (@recipientGroupKey IS NOT NULL AND NULLIF(LTRIM(RTRIM(@recipientGroupKey)), N'') IS NULL)
       OR (@attachmentBlobName IS NOT NULL AND NULLIF(LTRIM(RTRIM(@attachmentBlobName)), N'') IS NULL)
       OR @createdDateTime IS NULL OR DATEPART(TZOFFSET, @createdDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The email notification metadata or UTC timestamp is invalid.', 1;
    END;
    IF @emailEnvelopeJson IS NULL OR ISJSON(@emailEnvelopeJson) <> 1
       OR DATALENGTH(@emailEnvelopeJson) > 20 * 1024 * 1024
    BEGIN
        ;THROW 51004, 'The email envelope must be valid JSON no larger than 20 MiB.', 1;
    END;

    DECLARE @envelopeNotificationId uniqueidentifier = TRY_CONVERT(
        uniqueidentifier, JSON_VALUE(@emailEnvelopeJson, '$.notificationId'));
    DECLARE @envelopeBusinessCorrelationId nvarchar(256) =
        JSON_VALUE(@emailEnvelopeJson, '$.businessCorrelationId');
    DECLARE @envelopeSchemaVersion smallint = TRY_CONVERT(
        smallint, JSON_VALUE(@emailEnvelopeJson, '$.schemaVersion'));

    IF @envelopeNotificationId IS NULL
        OR @envelopeNotificationId <> @notificationId
        OR @envelopeBusinessCorrelationId IS NULL
        OR @envelopeBusinessCorrelationId COLLATE Latin1_General_100_BIN2
            <> @businessCorrelationId COLLATE Latin1_General_100_BIN2
        OR @envelopeSchemaVersion IS NULL
        OR @envelopeSchemaVersion <> @emailEnvelopeVersion
        OR DATALENGTH(JSON_VALUE(@emailEnvelopeJson, '$.notificationId')) <> 72
        OR DATALENGTH(JSON_VALUE(@emailEnvelopeJson, '$.businessCorrelationId')) <> DATALENGTH(@businessCorrelationId)
    BEGIN
        ;THROW 51004, 'Email envelope identity metadata does not match the outbox metadata.', 1;
    END;

    DECLARE @payloadSha256 binary(32) =
        HASHBYTES('SHA2_256', CONVERT(varbinary(max), @emailEnvelopeJson));
    DECLARE @batchKey bigint;
    DECLARE @notificationKey bigint;
    DECLARE @enqueued TABLE
    (
        [NotificationId] uniqueidentifier, [Status] varchar(50),
        [NextAttemptDateTime] datetimeoffset(3), [AttemptCount] int,
        [FailureCount] int, [ThrottleCount] int, [PayloadSha256] binary(32), [RowVersion] binary(8)
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @notificationKey = [NotificationKey]
        FROM [po].[PurchaseOrderNotification] WITH (UPDLOCK, HOLDLOCK)
        WHERE [NotificationId] = @notificationId;

        IF @batchId IS NOT NULL
        BEGIN
            SELECT @batchKey = [BatchKey]
            FROM [po].[PurchaseOrderBatch] WITH (HOLDLOCK)
            WHERE [BatchId] = @batchId;
            IF @batchKey IS NULL
            BEGIN
                ;THROW 51001, 'The purchase order batch was not found.', 1;
            END;
        END;

        IF @notificationKey IS NOT NULL
        BEGIN
            -- EXCEPT is NULL-safe; byte comparisons also distinguish case and trailing whitespace.
            IF EXISTS
            (
                SELECT @payloadSha256, @emailEnvelopeVersion, CONVERT(varbinary(max), @eventType),
                    CONVERT(varbinary(max), @businessCorrelationId), @batchKey,
                    CONVERT(varbinary(max), @templateKey), CONVERT(varbinary(max), @recipientGroupKey),
                    CONVERT(varbinary(max), @attachmentBlobName), @createdDateTime
                EXCEPT
                SELECT [PayloadSha256], [EmailEnvelopeVersion], CONVERT(varbinary(max), [EventType]),
                    CONVERT(varbinary(max), [BusinessCorrelationId]), [BatchKey],
                    CONVERT(varbinary(max), [TemplateKey]), CONVERT(varbinary(max), [RecipientGroupKey]),
                    CONVERT(varbinary(max), [AttachmentBlobName]), [CreatedDateTime]
                FROM [po].[PurchaseOrderNotification]
                WHERE [NotificationKey] = @notificationKey
            )
            BEGIN
                ;THROW 51004, 'The notification identifier already has different immutable content.', 1;
            END;
        END
        ELSE
        BEGIN
            INSERT INTO [po].[PurchaseOrderNotification]
            (
                [NotificationId], [BatchKey], [Channel], [EventType], [BusinessCorrelationId],
                [EmailEnvelopeVersion], [EmailEnvelopeJson], [PayloadSha256], [TemplateKey],
                [RecipientGroupKey], [AttachmentBlobName], [Status], [AttemptCount], [FailureCount],
                [ThrottleCount], [NextAttemptDateTime], [CreatedDateTime]
            )
            VALUES
            (
                @notificationId, @batchKey, 'EMAIL', @eventType, @businessCorrelationId,
                @emailEnvelopeVersion, @emailEnvelopeJson, @payloadSha256, @templateKey,
                @recipientGroupKey, @attachmentBlobName, 'PENDING', 0, 0, 0, @createdDateTime, @createdDateTime
            );
            SET @notificationKey = SCOPE_IDENTITY();
        END;

        INSERT INTO @enqueued
        SELECT [NotificationId], [Status], [NextAttemptDateTime], [AttemptCount],
            [FailureCount], [ThrottleCount], [PayloadSha256], [RowVersion]
        FROM [po].[PurchaseOrderNotification]
        WHERE [NotificationKey] = @notificationKey;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        THROW;
    END CATCH;

    SELECT [NotificationId], [Status], [NextAttemptDateTime], [AttemptCount],
        [FailureCount], [ThrottleCount], [PayloadSha256], [RowVersion]
    FROM @enqueued;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_claim_purchase_order_email_notifications]
    @asOfDateTime datetimeoffset(3),
    @leaseDurationSeconds int,
    @maxNotifications int,
    @maxAttemptsPerMinute int,
    @maxAttemptsPerHour int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @asOfDateTime IS NULL OR DATEPART(TZOFFSET, @asOfDateTime) <> 0
       OR @leaseDurationSeconds IS NULL OR @leaseDurationSeconds <= 0
       OR @maxNotifications IS NULL OR @maxNotifications <= 0
       OR @maxAttemptsPerMinute IS NULL OR @maxAttemptsPerMinute <= 0
       OR @maxAttemptsPerHour IS NULL OR @maxAttemptsPerHour <= 0
    BEGIN
        ;THROW 51004, 'The email claim UTC timestamp and positive bounds are required.', 1;
    END;

    DECLARE @minuteAttempts bigint;
    DECLARE @hourAttempts bigint;
    DECLARE @claimCount int;
    DECLARE @claimed TABLE
    (
        [NotificationKey] bigint PRIMARY KEY, [PreviousLeaseId] uniqueidentifier,
        [NextAttemptDateTime] datetimeoffset(3), [CreatedDateTime] datetimeoffset(3),
        [NotificationId] uniqueidentifier, [EventType] varchar(100), [BusinessCorrelationId] nvarchar(256),
        [EmailEnvelopeVersion] smallint, [EmailEnvelopeJson] nvarchar(max), [PayloadSha256] binary(32),
        [AttemptCount] int, [FailureCount] int, [ThrottleCount] int,
        [LeaseId] uniqueidentifier, [LeaseExpiresDateTime] datetimeoffset(3), [RowVersion] binary(8)
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @applicationLockResult int;

        EXEC @applicationLockResult = sys.sp_getapplock
            @Resource = N'po.email-notification-claim-quota',
            @LockMode = 'Exclusive',
            @LockOwner = 'Transaction',
            @LockTimeout = 10000;

        IF @applicationLockResult < 0
        BEGIN
            ;THROW 51002, 'Could not acquire the email claim quota lock.', 1;
        END;

        -- Count later recorded starts conservatively when callers arrive with out-of-order timestamps.
        SELECT @minuteAttempts = COUNT_BIG(*)
        FROM [po].[PurchaseOrderNotificationAttempt]
        WHERE [StartedDateTime] > DATEADD(MINUTE, -1, @asOfDateTime);
        SELECT @hourAttempts = COUNT_BIG(*)
        FROM [po].[PurchaseOrderNotificationAttempt]
        WHERE [StartedDateTime] > DATEADD(HOUR, -1, @asOfDateTime);

        SELECT @claimCount = CONVERT(int, CASE WHEN MIN(capacity) < 0 THEN 0 ELSE MIN(capacity) END)
        FROM (VALUES (CONVERT(bigint, @maxNotifications)),
            (@maxAttemptsPerMinute - @minuteAttempts), (@maxAttemptsPerHour - @hourAttempts)) AS limits(capacity);

        WITH claimable AS
        (
            SELECT TOP (@claimCount) notification.[NotificationKey]
            FROM [po].[PurchaseOrderNotification] AS notification
                WITH (UPDLOCK, READPAST, READCOMMITTEDLOCK)
            WHERE notification.[Channel] = 'EMAIL'
              AND notification.[EmailEnvelopeVersion] = 1
              AND notification.[EmailEnvelopeJson] IS NOT NULL
              AND
              (
                  (notification.[Status] = 'PENDING'
                      AND notification.[NextAttemptDateTime] <= @asOfDateTime)
                  OR
                  (notification.[Status] = 'SENDING'
                      AND notification.[LeaseExpiresDateTime] <= @asOfDateTime)
              )
            ORDER BY
                notification.[NextAttemptDateTime],
                notification.[CreatedDateTime],
                notification.[NotificationKey]
        )
        UPDATE notification
        SET [Status] = 'SENDING',
            [LeaseId] = NEWID(),
            [LeaseExpiresDateTime] = DATEADD(SECOND, @leaseDurationSeconds, @asOfDateTime),
            [AttemptCount] = notification.[AttemptCount] + 1,
            [LastAttemptDateTime] = @asOfDateTime
        OUTPUT inserted.[NotificationKey], deleted.[LeaseId],
            inserted.[NextAttemptDateTime], inserted.[CreatedDateTime],
            inserted.[NotificationId], inserted.[EventType], inserted.[BusinessCorrelationId],
            inserted.[EmailEnvelopeVersion], inserted.[EmailEnvelopeJson], inserted.[PayloadSha256],
            inserted.[AttemptCount], inserted.[FailureCount], inserted.[ThrottleCount],
            inserted.[LeaseId], inserted.[LeaseExpiresDateTime], inserted.[RowVersion]
        INTO @claimed
        FROM [po].[PurchaseOrderNotification] AS notification
        INNER JOIN claimable ON claimable.[NotificationKey] = notification.[NotificationKey];

        UPDATE attempt
        SET [Outcome] = 'LEASE_EXPIRED', [CompletedDateTime] = @asOfDateTime
        FROM [po].[PurchaseOrderNotificationAttempt] AS attempt
        INNER JOIN @claimed AS claimed
            ON attempt.[AttemptId] = claimed.[PreviousLeaseId]
           AND attempt.[NotificationKey] = claimed.[NotificationKey]
        WHERE attempt.[Outcome] = 'STARTED';
        IF @@ROWCOUNT <> (SELECT COUNT(*) FROM @claimed WHERE [PreviousLeaseId] IS NOT NULL)
        BEGIN
            ;THROW 51003, 'The expired email lease has no matching open attempt.', 1;
        END;

        INSERT INTO [po].[PurchaseOrderNotificationAttempt]
            ([AttemptId], [NotificationKey], [AttemptNumber], [StartedDateTime], [Outcome])
        SELECT [LeaseId], [NotificationKey], [AttemptCount], @asOfDateTime, 'STARTED'
        FROM @claimed;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        THROW;
    END CATCH;

    SELECT [NotificationId], [EventType], [BusinessCorrelationId],
        [EmailEnvelopeVersion], [EmailEnvelopeJson], [PayloadSha256],
        [AttemptCount], [FailureCount], [ThrottleCount],
        [LeaseId], [LeaseExpiresDateTime], [RowVersion]
    FROM @claimed
    ORDER BY [NextAttemptDateTime], [CreatedDateTime], [NotificationKey];
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_defer_purchase_order_email_notification]
    @notificationId uniqueidentifier,
    @leaseId uniqueidentifier,
    @nextAttemptDateTime datetimeoffset(3),
    @completedDateTime datetimeoffset(3),
    @expectedNotificationRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @notificationId IS NULL OR @leaseId IS NULL OR @expectedNotificationRowVersion IS NULL
       OR @completedDateTime IS NULL OR DATEPART(TZOFFSET, @completedDateTime) <> 0
       OR @nextAttemptDateTime IS NULL OR DATEPART(TZOFFSET, @nextAttemptDateTime) <> 0
       OR @nextAttemptDateTime < @completedDateTime
    BEGIN
        ;THROW 51004, 'The email lease, rowversion, and ordered UTC timestamps are required.', 1;
    END;

    DECLARE @notificationKey bigint;
    DECLARE @currentStatus varchar(50);
    DECLARE @currentLeaseId uniqueidentifier;
    DECLARE @notificationRowVersion binary(8);
    DECLARE @lastAttemptDateTime datetimeoffset(3);
    DECLARE @transitioned TABLE
    (
        [NotificationId] uniqueidentifier, [Status] varchar(50),
        [NextAttemptDateTime] datetimeoffset(3),
        [FailureCount] int, [ThrottleCount] int, [RowVersion] binary(8)
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @notificationKey = [NotificationKey], @currentStatus = [Status],
            @currentLeaseId = [LeaseId], @notificationRowVersion = [RowVersion],
            @lastAttemptDateTime = [LastAttemptDateTime]
        FROM [po].[PurchaseOrderNotification] WITH (UPDLOCK, HOLDLOCK)
        WHERE [NotificationId] = @notificationId;

        IF @notificationKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order notification was not found.', 1;
        END;
        IF @notificationRowVersion <> @expectedNotificationRowVersion
        BEGIN
            ;THROW 51002, 'The purchase order notification has changed.', 1;
        END;
        IF @currentStatus <> 'SENDING' OR @currentLeaseId IS NULL OR @currentLeaseId <> @leaseId
        BEGIN
            ;THROW 51003, 'The email lease is not owned by this sender.', 1;
        END;
        IF @lastAttemptDateTime IS NULL OR @completedDateTime < @lastAttemptDateTime
        BEGIN
            ;THROW 51004, 'The completion timestamp cannot precede the email attempt.', 1;
        END;

        UPDATE [po].[PurchaseOrderNotification]
        SET [Status] = 'PENDING',
            [NextAttemptDateTime] = @nextAttemptDateTime,
            [LeaseId] = NULL,
            [LeaseExpiresDateTime] = NULL
        OUTPUT inserted.[NotificationId], inserted.[Status], inserted.[NextAttemptDateTime],
        inserted.[FailureCount], inserted.[ThrottleCount], inserted.[RowVersion]
        INTO @transitioned
        WHERE [NotificationKey] = @notificationKey;

        UPDATE [po].[PurchaseOrderNotificationAttempt]
        SET [Outcome] = 'DEFERRED', [CompletedDateTime] = @completedDateTime
        WHERE [AttemptId] = @leaseId
          AND [NotificationKey] = @notificationKey
          AND [Outcome] = 'STARTED';
        IF @@ROWCOUNT <> 1
        BEGIN
            ;THROW 51003, 'The email lease has no matching open attempt.', 1;
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        THROW;
    END CATCH;

    SELECT [NotificationId], [Status], [NextAttemptDateTime],
        [FailureCount], [ThrottleCount], [RowVersion]
    FROM @transitioned;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_reschedule_purchase_order_email_notification]
    @notificationId uniqueidentifier,
    @leaseId uniqueidentifier,
    @outcome varchar(50),
    @failureCategory varchar(50),
    @failureCode varchar(100) = NULL,
    @failureDescription nvarchar(1000) = NULL,
    @httpStatusCode smallint = NULL,
    @nextAttemptDateTime datetimeoffset(3),
    @completedDateTime datetimeoffset(3),
    @expectedNotificationRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @notificationId IS NULL OR @leaseId IS NULL OR @expectedNotificationRowVersion IS NULL
       OR @completedDateTime IS NULL OR DATEPART(TZOFFSET, @completedDateTime) <> 0
       OR @nextAttemptDateTime IS NULL OR DATEPART(TZOFFSET, @nextAttemptDateTime) <> 0
       OR @nextAttemptDateTime < @completedDateTime
    BEGIN
        ;THROW 51004, 'The email lease, rowversion, and ordered UTC timestamps are required.', 1;
    END;

    IF @outcome IS NULL OR @outcome NOT IN ('TRANSIENT_FAILURE', 'THROTTLED')
       OR NULLIF(LTRIM(RTRIM(@failureCategory)), '') IS NULL
       OR (@httpStatusCode = 429 AND @outcome <> 'THROTTLED')
       OR (@outcome = 'THROTTLED' AND (@httpStatusCode IS NULL OR @httpStatusCode <> 429))
       OR (@httpStatusCode IS NOT NULL AND (@httpStatusCode < 100 OR @httpStatusCode > 599))
    BEGIN
        ;THROW 51004, 'The retry outcome and failure metadata are invalid.', 1;
    END;

    DECLARE @notificationKey bigint;
    DECLARE @currentStatus varchar(50);
    DECLARE @currentLeaseId uniqueidentifier;
    DECLARE @notificationRowVersion binary(8);
    DECLARE @lastAttemptDateTime datetimeoffset(3);
    DECLARE @transitioned TABLE
    (
        [NotificationId] uniqueidentifier, [Status] varchar(50),
        [NextAttemptDateTime] datetimeoffset(3),
        [FailureCount] int, [ThrottleCount] int, [RowVersion] binary(8)
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @notificationKey = [NotificationKey], @currentStatus = [Status],
            @currentLeaseId = [LeaseId], @notificationRowVersion = [RowVersion],
            @lastAttemptDateTime = [LastAttemptDateTime]
        FROM [po].[PurchaseOrderNotification] WITH (UPDLOCK, HOLDLOCK)
        WHERE [NotificationId] = @notificationId;

        IF @notificationKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order notification was not found.', 1;
        END;
        IF @notificationRowVersion <> @expectedNotificationRowVersion
        BEGIN
            ;THROW 51002, 'The purchase order notification has changed.', 1;
        END;
        IF @currentStatus <> 'SENDING' OR @currentLeaseId IS NULL OR @currentLeaseId <> @leaseId
        BEGIN
            ;THROW 51003, 'The email lease is not owned by this sender.', 1;
        END;
        IF @lastAttemptDateTime IS NULL OR @completedDateTime < @lastAttemptDateTime
        BEGIN
            ;THROW 51004, 'The completion timestamp cannot precede the email attempt.', 1;
        END;

        UPDATE [po].[PurchaseOrderNotification]
        SET [Status] = 'PENDING',
            [NextAttemptDateTime] = @nextAttemptDateTime,
            [FailureCount] = [FailureCount] + CASE WHEN @outcome = 'TRANSIENT_FAILURE' THEN 1 ELSE 0 END,
            [ThrottleCount] = [ThrottleCount] + CASE WHEN @outcome = 'THROTTLED' THEN 1 ELSE 0 END,
            [FailureCode] = @failureCode,
            [FailureDescription] = @failureDescription,
            [LeaseId] = NULL,
            [LeaseExpiresDateTime] = NULL
        OUTPUT inserted.[NotificationId], inserted.[Status], inserted.[NextAttemptDateTime],
        inserted.[FailureCount], inserted.[ThrottleCount], inserted.[RowVersion]
        INTO @transitioned
        WHERE [NotificationKey] = @notificationKey;

        UPDATE [po].[PurchaseOrderNotificationAttempt]
        SET [Outcome] = @outcome, [CompletedDateTime] = @completedDateTime,
            [FailureCategory] = @failureCategory, [FailureCode] = @failureCode,
            [HttpStatusCode] = @httpStatusCode
        WHERE [AttemptId] = @leaseId
          AND [NotificationKey] = @notificationKey
          AND [Outcome] = 'STARTED';
        IF @@ROWCOUNT <> 1
        BEGIN
            ;THROW 51003, 'The email lease has no matching open attempt.', 1;
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        THROW;
    END CATCH;

    SELECT [NotificationId], [Status], [NextAttemptDateTime],
        [FailureCount], [ThrottleCount], [RowVersion]
    FROM @transitioned;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_complete_purchase_order_email_notification]
    @notificationId uniqueidentifier,
    @leaseId uniqueidentifier,
    @status varchar(50),
    @attemptOutcome varchar(50),
    @incrementFailureCount bit,
    @providerMessageId nvarchar(256) = NULL,
    @failureCategory varchar(50) = NULL,
    @failureCode varchar(100) = NULL,
    @failureDescription nvarchar(1000) = NULL,
    @httpStatusCode smallint = NULL,
    @completedDateTime datetimeoffset(3),
    @expectedNotificationRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @notificationId IS NULL OR @leaseId IS NULL OR @expectedNotificationRowVersion IS NULL
       OR @completedDateTime IS NULL OR DATEPART(TZOFFSET, @completedDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The email lease, rowversion, and ordered UTC timestamps are required.', 1;
    END;

    IF @status IS NULL OR @attemptOutcome IS NULL OR @incrementFailureCount IS NULL
       OR NOT
       (
           (@status = 'SENT' AND @attemptOutcome = 'SUCCEEDED' AND @incrementFailureCount = 0)
           OR (@status = 'FAILED' AND @attemptOutcome = 'PERMANENT_FAILURE' AND @incrementFailureCount = 0)
           OR (@status = 'FAILED' AND @attemptOutcome = 'TRANSIENT_FAILURE' AND @incrementFailureCount = 1)
       )
       OR @httpStatusCode = 429
       OR (@httpStatusCode IS NOT NULL AND (@httpStatusCode < 100 OR @httpStatusCode > 599))
    BEGIN
        ;THROW 51004, 'The terminal notification status, attempt outcome, or failure increment is invalid.', 1;
    END;

    DECLARE @notificationKey bigint;
    DECLARE @currentStatus varchar(50);
    DECLARE @currentLeaseId uniqueidentifier;
    DECLARE @notificationRowVersion binary(8);
    DECLARE @lastAttemptDateTime datetimeoffset(3);
    DECLARE @transitioned TABLE
    (
        [NotificationId] uniqueidentifier, [Status] varchar(50),
        [SentDateTime] datetimeoffset(3), [CompletedDateTime] datetimeoffset(3),
        [FailureCount] int, [ThrottleCount] int, [RowVersion] binary(8)
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SELECT @notificationKey = [NotificationKey], @currentStatus = [Status],
            @currentLeaseId = [LeaseId], @notificationRowVersion = [RowVersion],
            @lastAttemptDateTime = [LastAttemptDateTime]
        FROM [po].[PurchaseOrderNotification] WITH (UPDLOCK, HOLDLOCK)
        WHERE [NotificationId] = @notificationId;

        IF @notificationKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order notification was not found.', 1;
        END;
        IF @notificationRowVersion <> @expectedNotificationRowVersion
        BEGIN
            ;THROW 51002, 'The purchase order notification has changed.', 1;
        END;
        IF @currentStatus <> 'SENDING' OR @currentLeaseId IS NULL OR @currentLeaseId <> @leaseId
        BEGIN
            ;THROW 51003, 'The email lease is not owned by this sender.', 1;
        END;
        IF @lastAttemptDateTime IS NULL OR @completedDateTime < @lastAttemptDateTime
        BEGIN
            ;THROW 51004, 'The completion timestamp cannot precede the email attempt.', 1;
        END;

        UPDATE [po].[PurchaseOrderNotification]
        SET [Status] = @status,
            [SentDateTime] = CASE WHEN @status = 'SENT' THEN @completedDateTime ELSE NULL END,
            [CompletedDateTime] = @completedDateTime,
            [FailureCount] = [FailureCount] + CONVERT(int, @incrementFailureCount),
            [ProviderMessageId] = @providerMessageId,
            [FailureCode] = @failureCode,
            [FailureDescription] = @failureDescription,
            [LeaseId] = NULL,
            [LeaseExpiresDateTime] = NULL
        OUTPUT inserted.[NotificationId], inserted.[Status], inserted.[SentDateTime], inserted.[CompletedDateTime],
        inserted.[FailureCount], inserted.[ThrottleCount], inserted.[RowVersion]
        INTO @transitioned
        WHERE [NotificationKey] = @notificationKey;

        UPDATE [po].[PurchaseOrderNotificationAttempt]
        SET [Outcome] = @attemptOutcome, [CompletedDateTime] = @completedDateTime,
            [ProviderMessageId] = @providerMessageId, [FailureCategory] = @failureCategory,
            [FailureCode] = @failureCode, [HttpStatusCode] = @httpStatusCode
        WHERE [AttemptId] = @leaseId
          AND [NotificationKey] = @notificationKey
          AND [Outcome] = 'STARTED';
        IF @@ROWCOUNT <> 1
        BEGIN
            ;THROW 51003, 'The email lease has no matching open attempt.', 1;
        END;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;
        THROW;
    END CATCH;

    SELECT [NotificationId], [Status], [SentDateTime], [CompletedDateTime],
        [FailureCount], [ThrottleCount], [RowVersion]
    FROM @transitioned;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_email_notification_queue_summary]
    @asOfDateTime datetimeoffset(3),
    @terminalFailureSinceDateTime datetimeoffset(3)
AS
BEGIN
    SET NOCOUNT ON;

    IF @asOfDateTime IS NULL OR DATEPART(TZOFFSET, @asOfDateTime) <> 0
       OR @terminalFailureSinceDateTime IS NULL OR DATEPART(TZOFFSET, @terminalFailureSinceDateTime) <> 0
       OR @terminalFailureSinceDateTime > @asOfDateTime
    BEGIN
        ;THROW 51004, 'The summary timestamps must be ordered and use the UTC offset.', 1;
    END;

    SELECT
        COUNT_BIG(CASE WHEN [Status] = 'PENDING' AND [EmailEnvelopeVersion] = 1
            AND [EmailEnvelopeJson] IS NOT NULL AND [NextAttemptDateTime] <= @asOfDateTime THEN 1 END) AS [ClaimablePendingCount],
        MIN(CASE WHEN [Status] = 'PENDING' AND [EmailEnvelopeVersion] = 1
            AND [EmailEnvelopeJson] IS NOT NULL AND [NextAttemptDateTime] <= @asOfDateTime
            THEN [CreatedDateTime] END) AS [OldestClaimablePendingDateTime],
        COUNT_BIG(CASE WHEN [Status] = 'PENDING' AND [EmailEnvelopeVersion] = 1
            AND [EmailEnvelopeJson] IS NOT NULL AND [NextAttemptDateTime] > @asOfDateTime THEN 1 END) AS [DelayedPendingCount],
        COUNT_BIG(CASE WHEN [Status] = 'SENDING' AND [LeaseExpiresDateTime] > @asOfDateTime THEN 1 END) AS [ActiveLeasedCount],
        COUNT_BIG(CASE WHEN [Status] = 'SENDING' AND [LeaseExpiresDateTime] <= @asOfDateTime THEN 1 END) AS [ExpiredLeasedCount],
        COUNT_BIG(CASE WHEN [Status] = 'PENDING' AND [EmailEnvelopeJson] IS NULL THEN 1 END) AS [UnsendableLegacyPendingCount],
        COUNT_BIG(CASE WHEN [Status] = 'FAILED' AND [CompletedDateTime] >= @terminalFailureSinceDateTime
            AND [CompletedDateTime] <= @asOfDateTime THEN 1 END) AS [TerminalFailureCount]
    FROM [po].[PurchaseOrderNotification]
    WHERE [Channel] = 'EMAIL';
END;
GO
