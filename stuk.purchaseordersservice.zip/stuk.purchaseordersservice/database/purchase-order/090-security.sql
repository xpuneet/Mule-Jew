SET NOCOUNT ON;
SET XACT_ABORT ON;

IF DATABASE_PRINCIPAL_ID(N'po_service_executor') IS NULL
BEGIN
    EXEC(N'CREATE ROLE [po_service_executor] AUTHORIZATION [dbo];');
END;

GRANT EXECUTE ON OBJECT::[po].[sp_get_application_settings] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_create_purchase_order_candidate] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_search_purchase_order_candidates] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_register_purchase_order_batch] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_add_purchase_order_candidate_to_batch] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_complete_purchase_order_batch] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_fail_purchase_order_batch] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_batch] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_batch_by_source_hash] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_claim_purchase_order_candidates] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_renew_purchase_order_claim] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_release_purchase_order_claim] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_expire_purchase_order_claims] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_candidate] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_begin_purchase_order_submission_attempt] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_fail_purchase_order_candidate_pre_dispatch] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_complete_purchase_order_submission] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_fail_purchase_order_submission] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_request_purchase_order_retry] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_cancel_purchase_order_candidate] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_audit] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_batch_outcomes] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_register_purchase_order_notification] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_complete_purchase_order_notification] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_enqueue_purchase_order_email_notification] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_claim_purchase_order_email_notifications] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_defer_purchase_order_email_notification] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_reschedule_purchase_order_email_notification] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_complete_purchase_order_email_notification] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_email_notification_queue_summary] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_prepare_and_claim_relex_notification_events] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_save_relex_notification_envelope] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_complete_relex_notification_event] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_candidate_summary] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_batch_summary] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_search_purchase_order_batches] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_get_purchase_order_batch_candidate_summary] TO [po_service_executor];
GRANT EXECUTE ON OBJECT::[po].[sp_search_purchase_order_batch_candidates] TO [po_service_executor];
