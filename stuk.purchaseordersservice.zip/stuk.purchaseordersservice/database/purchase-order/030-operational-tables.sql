SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'[po].[ApplicationSetting]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[ApplicationSetting]
    (
        [Context] nvarchar(100) NOT NULL,
        [Key] nvarchar(256) NOT NULL,
        [Value] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_PO_ApplicationSetting]
            PRIMARY KEY CLUSTERED ([Context], [Key])
    );
END;

IF OBJECT_ID(N'[po].[PurchaseOrderBatch]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[PurchaseOrderBatch]
    (
        [BatchKey] bigint IDENTITY(1,1) NOT NULL,
        [BatchId] uniqueidentifier NOT NULL,
        [Source] nvarchar(50) NOT NULL,
        [OriginalFileName] nvarchar(260) NOT NULL,
        [SourceFilePath] nvarchar(512) NOT NULL,
        [FileContentLength] bigint NOT NULL,
        [FileSha256] binary(32) NOT NULL,
        [Status] varchar(50) NOT NULL,
        [ExpectedRowCount] int NULL,
        [ParsedRowCount] int NOT NULL
            CONSTRAINT [DF_PO_Batch_ParsedRowCount] DEFAULT (0),
        [CandidateCount] int NOT NULL
            CONSTRAINT [DF_PO_Batch_CandidateCount] DEFAULT (0),
        [FailureCode] varchar(100) NULL,
        [FailureDescription] nvarchar(1000) NULL,
        [DiscoveredDateTime] datetimeoffset(3) NOT NULL,
        [IngestionStartedDateTime] datetimeoffset(3) NULL,
        [CompletedDateTime] datetimeoffset(3) NULL,
        [CreatedBy] nvarchar(256) NOT NULL,
        [UpdatedDateTime] datetimeoffset(3) NOT NULL,
        [RowVersion] rowversion NOT NULL,
        CONSTRAINT [PK_PO_Batch]
            PRIMARY KEY CLUSTERED ([BatchKey]),
        CONSTRAINT [UQ_PO_Batch_BatchId]
            UNIQUE NONCLUSTERED ([BatchId]),
        CONSTRAINT [CK_PO_Batch_Status]
            CHECK
            (
                [Status] IN
                (
                    'INGESTING',
                    'READY_FOR_SUBMISSION',
                    'PROCESSING',
                    'COMPLETED',
                    'FAILED'
                )
            ),
        CONSTRAINT [CK_PO_Batch_FileContentLength]
            CHECK ([FileContentLength] >= 0),
        CONSTRAINT [CK_PO_Batch_ExpectedRowCount]
            CHECK ([ExpectedRowCount] IS NULL OR [ExpectedRowCount] >= 0),
        CONSTRAINT [CK_PO_Batch_Counts]
            CHECK ([ParsedRowCount] >= 0 AND [CandidateCount] >= 0),
        CONSTRAINT [CK_PO_Batch_UtcDateTimes]
            CHECK
            (
                DATEPART(TZOFFSET, [DiscoveredDateTime]) = 0
                AND ([IngestionStartedDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [IngestionStartedDateTime]) = 0)
                AND ([CompletedDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [CompletedDateTime]) = 0)
                AND DATEPART(TZOFFSET, [UpdatedDateTime]) = 0
            )
    );
END;

IF OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[PurchaseOrderCandidate]
    (
        [CandidateKey] bigint IDENTITY(1,1) NOT NULL,
        [CandidateId] uniqueidentifier NOT NULL,
        [BatchKey] bigint NULL,
        [Source] nvarchar(50) NOT NULL,
        [Kind] varchar(10) NOT NULL,
        [SourceRowCount] int NULL,
        [Account] nvarchar(50) NOT NULL,
        [Branch] nvarchar(20) NOT NULL,
        [Reference] nvarchar(100) NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NULL,
        [Status] varchar(50) NOT NULL,
        [StatusDateTime] datetimeoffset(3) NOT NULL,
        [StatusReason] nvarchar(1000) NULL,
        [ProcessBatchNo] int NULL,
        [PayloadMD5] varchar(64) NULL,
        [MessageCode] nvarchar(100) NULL,
        [MessageDescription] nvarchar(1000) NULL,
        [PreviousMessageCode] nvarchar(100) NULL,
        [PreviousMessageDescription] nvarchar(1000) NULL,
        [PayloadJson] nvarchar(max) NOT NULL,
        [AcceptedDateTime] datetimeoffset(3) NOT NULL,
        [CreatedDateTime] datetimeoffset(3) NOT NULL,
        [UpdatedDateTime] datetimeoffset(3) NOT NULL,
        [RefreshDateTime] datetimeoffset(3) NOT NULL,
        [PendingRetriesCount] int NOT NULL
            CONSTRAINT [DF_PO_Candidate_PendingRetries] DEFAULT (0),
        [ProcessingRetriesCount] int NOT NULL
            CONSTRAINT [DF_PO_Candidate_ProcessingRetries] DEFAULT (0),
        [LeaseToken] uniqueidentifier NULL,
        [LeaseOwner] nvarchar(256) NULL,
        [LeaseAcquiredDateTime] datetimeoffset(3) NULL,
        [LeaseExpiresDateTime] datetimeoffset(3) NULL,
        [RowVersion] rowversion NOT NULL,
        CONSTRAINT [PK_PO_Candidate]
            PRIMARY KEY CLUSTERED ([CandidateKey]),
        CONSTRAINT [UQ_PO_Candidate_CandidateId]
            UNIQUE NONCLUSTERED ([CandidateId]),
        CONSTRAINT [CK_PO_Candidate_Status]
            CHECK
            (
                [Status] IN
                (
                    'DRAFT',
                    'READY_FOR_SUBMISSION',
                    'SUBMISSION_IN_PROGRESS',
                    'RECOVERABLE_ERROR',
                    'NON_RECOVERABLE_ERROR',
                    'RETRY_REQUESTED',
                    'COMPLETED',
                    'CANCELLED'
                )
            ),
        CONSTRAINT [CK_PO_Candidate_Kind]
            CHECK ([Kind] IN ('API', 'RELEX')),
        CONSTRAINT [CK_PO_Candidate_SourceRowCount]
            CHECK
            (
                ([Kind] = 'RELEX' AND [SourceRowCount] > 0)
                OR ([Kind] = 'API' AND [SourceRowCount] IS NULL)
            ),
        CONSTRAINT [CK_PO_Candidate_PayloadJson]
            CHECK (ISJSON([PayloadJson]) = 1),
        CONSTRAINT [CK_PO_Candidate_Retries]
            CHECK ([PendingRetriesCount] >= 0 AND [ProcessingRetriesCount] >= 0),
        CONSTRAINT [CK_PO_Candidate_LeaseFields]
            CHECK
            (
                ([LeaseToken] IS NULL
                    AND [LeaseOwner] IS NULL
                    AND [LeaseAcquiredDateTime] IS NULL
                    AND [LeaseExpiresDateTime] IS NULL)
                OR
                ([LeaseToken] IS NOT NULL
                    AND [LeaseOwner] IS NOT NULL
                    AND [LeaseAcquiredDateTime] IS NOT NULL
                    AND [LeaseExpiresDateTime] IS NOT NULL)
            ),
        CONSTRAINT [CK_PO_Candidate_LeaseWindow]
            CHECK
            (
                [LeaseExpiresDateTime] IS NULL
                OR [LeaseExpiresDateTime] > [LeaseAcquiredDateTime]
            ),
        CONSTRAINT [CK_PO_Candidate_UtcDateTimes]
            CHECK
            (
                DATEPART(TZOFFSET, [StatusDateTime]) = 0
                AND DATEPART(TZOFFSET, [AcceptedDateTime]) = 0
                AND DATEPART(TZOFFSET, [CreatedDateTime]) = 0
                AND DATEPART(TZOFFSET, [UpdatedDateTime]) = 0
                AND DATEPART(TZOFFSET, [RefreshDateTime]) = 0
                AND ([LeaseAcquiredDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [LeaseAcquiredDateTime]) = 0)
                AND ([LeaseExpiresDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [LeaseExpiresDateTime]) = 0)
            ),
        CONSTRAINT [FK_PO_Candidate_Batch]
            FOREIGN KEY ([BatchKey])
            REFERENCES [po].[PurchaseOrderBatch] ([BatchKey])
            ON DELETE NO ACTION
            ON UPDATE NO ACTION
    );
END;

IF OBJECT_ID(N'[po].[PurchaseOrderSubmissionAttempt]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[PurchaseOrderSubmissionAttempt]
    (
        [AttemptKey] bigint IDENTITY(1,1) NOT NULL,
        [AttemptId] uniqueidentifier NOT NULL,
        [CandidateKey] bigint NOT NULL,
        [AttemptNumber] int NOT NULL,
        [ClaimToken] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RequestPayloadJson] nvarchar(max) NOT NULL,
        [ResponsePayloadJson] nvarchar(max) NULL,
        [HttpStatusCode] smallint NULL,
        [IconPurchaseOrderNumber] nvarchar(100) NULL,
        [IconCreatedStatus] varchar(50) NULL,
        [IconSuspended] bit NULL,
        [IconSuspendMessage] nvarchar(1000) NULL,
        [FailureCategory] varchar(100) NULL,
        [MessageCode] nvarchar(100) NULL,
        [MessageDescription] nvarchar(1000) NULL,
        [PreparedDateTime] datetimeoffset(3) NOT NULL,
        [DispatchedDateTime] datetimeoffset(3) NOT NULL,
        [CompletedDateTime] datetimeoffset(3) NULL,
        [CreatedBy] nvarchar(256) NOT NULL,
        CONSTRAINT [PK_PO_Attempt]
            PRIMARY KEY CLUSTERED ([AttemptKey]),
        CONSTRAINT [UQ_PO_Attempt_AttemptId]
            UNIQUE NONCLUSTERED ([AttemptId]),
        CONSTRAINT [CK_PO_Attempt_Status]
            CHECK
            (
                [Status] IN
                (
                    'DISPATCHED',
                    'SUCCEEDED',
                    'FAILED',
                    'UNKNOWN_OUTCOME'
                )
            ),
        CONSTRAINT [CK_PO_Attempt_Number]
            CHECK ([AttemptNumber] >= 1),
        CONSTRAINT [CK_PO_Attempt_RequestPayloadJson]
            CHECK (ISJSON([RequestPayloadJson]) = 1),
        CONSTRAINT [CK_PO_Attempt_ResponsePayloadJson]
            CHECK
            (
                [ResponsePayloadJson] IS NULL
                OR ISJSON([ResponsePayloadJson]) = 1
            ),
        CONSTRAINT [CK_PO_Attempt_HttpStatusCode]
            CHECK
            (
                [HttpStatusCode] IS NULL
                OR [HttpStatusCode] BETWEEN 100 AND 599
            ),
        CONSTRAINT [CK_PO_Attempt_IconCreatedStatus]
            CHECK
            (
                [IconCreatedStatus] IS NULL
                OR [IconCreatedStatus] IN
                (
                    'activated',
                    'notactivated',
                    'received',
                    'undefined'
                )
            ),
        CONSTRAINT [CK_PO_Attempt_UtcDateTimes]
            CHECK
            (
                DATEPART(TZOFFSET, [PreparedDateTime]) = 0
                AND DATEPART(TZOFFSET, [DispatchedDateTime]) = 0
                AND ([CompletedDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [CompletedDateTime]) = 0)
            ),
        CONSTRAINT [FK_PO_Attempt_Candidate]
            FOREIGN KEY ([CandidateKey])
            REFERENCES [po].[PurchaseOrderCandidate] ([CandidateKey])
            ON DELETE NO ACTION
            ON UPDATE NO ACTION
    );
END;

IF OBJECT_ID(N'[po].[PurchaseOrderAudit]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[PurchaseOrderAudit]
    (
        [AuditKey] bigint IDENTITY(1,1) NOT NULL,
        [CandidateKey] bigint NOT NULL,
        [Action] varchar(100) NOT NULL,
        [Method] varchar(20) NOT NULL,
        [Actor] nvarchar(256) NOT NULL,
        [Reason] nvarchar(1000) NULL,
        [PreviousStatus] varchar(50) NULL,
        [CurrentStatus] varchar(50) NULL,
        [PreviousPayloadJson] nvarchar(max) NULL,
        [CurrentPayloadJson] nvarchar(max) NULL,
        [BusinessPayloadHash] binary(32) NULL,
        [CorrelationId] uniqueidentifier NULL,
        [ChangedDateTime] datetimeoffset(3) NOT NULL,
        CONSTRAINT [PK_PO_Audit]
            PRIMARY KEY CLUSTERED ([AuditKey]),
        CONSTRAINT [CK_PO_Audit_Method]
            CHECK ([Method] IN ('API', 'INGESTION', 'PROCESSOR', 'SUPPORT', 'SYSTEM')),
        CONSTRAINT [CK_PO_Audit_PreviousStatus]
            CHECK
            (
                [PreviousStatus] IS NULL
                OR [PreviousStatus] IN
                (
                    'DRAFT',
                    'READY_FOR_SUBMISSION',
                    'SUBMISSION_IN_PROGRESS',
                    'RECOVERABLE_ERROR',
                    'NON_RECOVERABLE_ERROR',
                    'RETRY_REQUESTED',
                    'COMPLETED',
                    'CANCELLED'
                )
            ),
        CONSTRAINT [CK_PO_Audit_CurrentStatus]
            CHECK
            (
                [CurrentStatus] IS NULL
                OR [CurrentStatus] IN
                (
                    'DRAFT',
                    'READY_FOR_SUBMISSION',
                    'SUBMISSION_IN_PROGRESS',
                    'RECOVERABLE_ERROR',
                    'NON_RECOVERABLE_ERROR',
                    'RETRY_REQUESTED',
                    'COMPLETED',
                    'CANCELLED'
                )
            ),
        CONSTRAINT [CK_PO_Audit_PreviousPayloadJson]
            CHECK
            (
                [PreviousPayloadJson] IS NULL
                OR ISJSON([PreviousPayloadJson]) = 1
            ),
        CONSTRAINT [CK_PO_Audit_CurrentPayloadJson]
            CHECK
            (
                [CurrentPayloadJson] IS NULL
                OR ISJSON([CurrentPayloadJson]) = 1
            ),
        CONSTRAINT [CK_PO_Audit_UtcDateTimes]
            CHECK (DATEPART(TZOFFSET, [ChangedDateTime]) = 0),
        CONSTRAINT [FK_PO_Audit_Candidate]
            FOREIGN KEY ([CandidateKey])
            REFERENCES [po].[PurchaseOrderCandidate] ([CandidateKey])
            ON DELETE NO ACTION
            ON UPDATE NO ACTION
    );
END;

IF OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[PurchaseOrderNotification]
    (
        [NotificationKey] bigint IDENTITY(1,1) NOT NULL,
        [NotificationId] uniqueidentifier NOT NULL,
        [BatchKey] bigint NULL,
        [Channel] varchar(50) NOT NULL,
        [TemplateKey] nvarchar(100) NULL,
        [RecipientGroupKey] nvarchar(100) NULL,
        [AttachmentBlobName] nvarchar(512) NULL,
        [EventType] varchar(100) NULL,
        [BusinessCorrelationId] nvarchar(256) NULL,
        [EmailEnvelopeVersion] smallint NULL,
        [EmailEnvelopeJson] nvarchar(max) NULL,
        [PayloadSha256] binary(32) NULL,
        [Status] varchar(50) NOT NULL,
        [AttemptCount] int NOT NULL
            CONSTRAINT [DF_PO_Notification_AttemptCount] DEFAULT (0),
        [FailureCount] int NOT NULL
            CONSTRAINT [DF_PO_Notification_FailureCount] DEFAULT (0),
        [ThrottleCount] int NOT NULL
            CONSTRAINT [DF_PO_Notification_ThrottleCount] DEFAULT (0),
        [NextAttemptDateTime] datetimeoffset(3) NOT NULL
            CONSTRAINT [DF_PO_Notification_NextAttemptDateTime] DEFAULT (SYSUTCDATETIME()),
        [LastAttemptDateTime] datetimeoffset(3) NULL,
        [LeaseId] uniqueidentifier NULL,
        [LeaseExpiresDateTime] datetimeoffset(3) NULL,
        [ProviderMessageId] nvarchar(256) NULL,
        [FailureCode] varchar(100) NULL,
        [FailureDescription] nvarchar(1000) NULL,
        [CreatedDateTime] datetimeoffset(3) NOT NULL,
        [SentDateTime] datetimeoffset(3) NULL,
        [CompletedDateTime] datetimeoffset(3) NULL,
        [RowVersion] rowversion NOT NULL,
        CONSTRAINT [PK_PO_Notification]
            PRIMARY KEY CLUSTERED ([NotificationKey]),
        CONSTRAINT [UQ_PO_Notification_NotificationId]
            UNIQUE NONCLUSTERED ([NotificationId]),
        CONSTRAINT [CK_PO_Notification_Status]
            CHECK
            (
                [Status] IN
                (
                    'PENDING',
                    'SENDING',
                    'SENT',
                    'FAILED'
                )
            ),
        CONSTRAINT [CK_PO_Notification_Counters]
            CHECK
            (
                [AttemptCount] >= 0
                AND [FailureCount] >= 0
                AND [ThrottleCount] >= 0
            ),
        CONSTRAINT [CK_PO_Notification_EnvelopeCompleteness]
            CHECK
            (
                (
                    [EmailEnvelopeVersion] IS NULL
                    AND [EmailEnvelopeJson] IS NULL
                    AND [PayloadSha256] IS NULL
                    AND [EventType] IS NULL
                    AND [BusinessCorrelationId] IS NULL
                )
                OR
                (
                    [EmailEnvelopeVersion] IS NOT NULL
                    AND [EmailEnvelopeJson] IS NOT NULL
                    AND [PayloadSha256] IS NOT NULL
                    AND [EventType] IS NOT NULL
                    AND [BusinessCorrelationId] IS NOT NULL
                )
            ),
        CONSTRAINT [CK_PO_Notification_EnvelopeJson]
            CHECK
            (
                [EmailEnvelopeJson] IS NULL
                OR
                (
                    ISJSON([EmailEnvelopeJson]) = 1
                    AND DATALENGTH([EmailEnvelopeJson]) <= 20 * 1024 * 1024
                )
            ),
        CONSTRAINT [CK_PO_Notification_SenderState]
            CHECK
            (
                (
                    [EmailEnvelopeJson] IS NULL
                    AND [Status] <> 'SENDING'
                    AND [LeaseId] IS NULL
                    AND [LeaseExpiresDateTime] IS NULL
                )
                OR
                (
                    [EmailEnvelopeJson] IS NOT NULL
                    AND
                    (
                        (
                            [Status] = 'PENDING'
                            AND [LeaseId] IS NULL
                            AND [LeaseExpiresDateTime] IS NULL
                            AND [SentDateTime] IS NULL
                            AND [CompletedDateTime] IS NULL
                        )
                        OR
                        (
                            [Status] = 'SENDING'
                            AND [LeaseId] IS NOT NULL
                            AND [LeaseExpiresDateTime] IS NOT NULL
                            AND [SentDateTime] IS NULL
                            AND [CompletedDateTime] IS NULL
                        )
                        OR
                        (
                            [Status] = 'SENT'
                            AND [LeaseId] IS NULL
                            AND [LeaseExpiresDateTime] IS NULL
                            AND [SentDateTime] IS NOT NULL
                            AND [CompletedDateTime] IS NOT NULL
                        )
                        OR
                        (
                            [Status] = 'FAILED'
                            AND [LeaseId] IS NULL
                            AND [LeaseExpiresDateTime] IS NULL
                            AND [SentDateTime] IS NULL
                            AND [CompletedDateTime] IS NOT NULL
                        )
                    )
                )
            ),
        CONSTRAINT [CK_PO_Notification_UtcDateTimes]
            CHECK
            (
                DATEPART(TZOFFSET, [NextAttemptDateTime]) = 0
                AND ([LastAttemptDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [LastAttemptDateTime]) = 0)
                AND ([LeaseExpiresDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [LeaseExpiresDateTime]) = 0)
                AND DATEPART(TZOFFSET, [CreatedDateTime]) = 0
                AND ([SentDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [SentDateTime]) = 0)
                AND ([CompletedDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [CompletedDateTime]) = 0)
            ),
        CONSTRAINT [FK_PO_Notification_Batch]
            FOREIGN KEY ([BatchKey])
            REFERENCES [po].[PurchaseOrderBatch] ([BatchKey])
            ON DELETE NO ACTION
            ON UPDATE NO ACTION
    );
END;

IF OBJECT_ID(N'[po].[PurchaseOrderNotificationAttempt]', N'U') IS NULL
BEGIN
    CREATE TABLE [po].[PurchaseOrderNotificationAttempt]
    (
        [NotificationAttemptKey] bigint IDENTITY(1,1) NOT NULL,
        [AttemptId] uniqueidentifier NOT NULL,
        [NotificationKey] bigint NOT NULL,
        [AttemptNumber] int NOT NULL,
        [StartedDateTime] datetimeoffset(3) NOT NULL,
        [CompletedDateTime] datetimeoffset(3) NULL,
        [Outcome] varchar(50) NOT NULL,
        [ProviderMessageId] nvarchar(256) NULL,
        [FailureCategory] varchar(50) NULL,
        [FailureCode] varchar(100) NULL,
        [HttpStatusCode] smallint NULL,
        CONSTRAINT [PK_PO_NotificationAttempt]
            PRIMARY KEY CLUSTERED ([NotificationAttemptKey]),
        CONSTRAINT [UQ_PO_NotificationAttempt_AttemptId]
            UNIQUE NONCLUSTERED ([AttemptId]),
        CONSTRAINT [UQ_PO_NotificationAttempt_NotificationKey_AttemptNumber]
            UNIQUE NONCLUSTERED ([NotificationKey], [AttemptNumber]),
        CONSTRAINT [CK_PO_NotificationAttempt_AttemptNumber]
            CHECK ([AttemptNumber] >= 1),
        CONSTRAINT [CK_PO_NotificationAttempt_Outcome]
            CHECK
            (
                [Outcome] IN
                (
                    'STARTED',
                    'SUCCEEDED',
                    'TRANSIENT_FAILURE',
                    'THROTTLED',
                    'PERMANENT_FAILURE',
                    'DEFERRED',
                    'LEASE_EXPIRED'
                )
            ),
        CONSTRAINT [CK_PO_NotificationAttempt_HttpStatusCode]
            CHECK
            (
                [HttpStatusCode] IS NULL
                OR [HttpStatusCode] BETWEEN 100 AND 599
            ),
        CONSTRAINT [CK_PO_NotificationAttempt_UtcDateTimes]
            CHECK
            (
                DATEPART(TZOFFSET, [StartedDateTime]) = 0
                AND ([CompletedDateTime] IS NULL
                    OR DATEPART(TZOFFSET, [CompletedDateTime]) = 0)
            ),
        CONSTRAINT [FK_PO_NotificationAttempt_Notification]
            FOREIGN KEY ([NotificationKey])
            REFERENCES [po].[PurchaseOrderNotification] ([NotificationKey])
            ON DELETE NO ACTION
            ON UPDATE NO ACTION
    );
END;

UPDATE [po].[PurchaseOrderBatch]
SET [Status] = 'COMPLETED'
WHERE [Status] IN ('READY_FOR_SUBMISSION', 'PROCESSING');

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderBatch]', N'U')
      AND [name] = N'UX_PO_Batch_Source_FileSha256'
)
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX [UX_PO_Batch_Source_FileSha256]
        ON [po].[PurchaseOrderBatch] ([Source], [FileSha256]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderBatch]', N'U')
      AND [name] = N'IX_PO_Batch_Status_DiscoveredDateTime'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Batch_Status_DiscoveredDateTime]
        ON [po].[PurchaseOrderBatch] ([Status], [DiscoveredDateTime]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U')
      AND [name] = N'IX_PO_Candidate_Source_Status_AcceptedDateTime'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Candidate_Source_Status_AcceptedDateTime]
        ON [po].[PurchaseOrderCandidate] ([Source], [Status], [AcceptedDateTime] DESC)
        INCLUDE ([Account], [Branch], [Reference], [IconPurchaseOrderNumber]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U')
      AND [name] = N'IX_PO_Candidate_Source_Account_Branch_Reference'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Candidate_Source_Account_Branch_Reference]
        ON [po].[PurchaseOrderCandidate] ([Source], [Account], [Branch], [Reference]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U')
      AND [name] = N'IX_PO_Candidate_IconPurchaseOrderNumber'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Candidate_IconPurchaseOrderNumber]
        ON [po].[PurchaseOrderCandidate] ([IconPurchaseOrderNumber])
        WHERE [IconPurchaseOrderNumber] IS NOT NULL;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U')
      AND [name] = N'IX_PO_Candidate_Status_LeaseExpires_AcceptedDateTime'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Candidate_Status_LeaseExpires_AcceptedDateTime]
        ON [po].[PurchaseOrderCandidate]
        (
            [Status],
            [LeaseExpiresDateTime],
            [AcceptedDateTime]
        )
        INCLUDE ([CandidateId], [Branch]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderCandidate]', N'U')
      AND [name] = N'IX_PO_Candidate_BatchKey_CandidateKey'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Candidate_BatchKey_CandidateKey]
        ON [po].[PurchaseOrderCandidate] ([BatchKey], [CandidateKey])
        INCLUDE ([Status], [LeaseToken]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderSubmissionAttempt]', N'U')
      AND [name] = N'UX_PO_Attempt_CandidateKey_AttemptNumber'
)
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX [UX_PO_Attempt_CandidateKey_AttemptNumber]
        ON [po].[PurchaseOrderSubmissionAttempt] ([CandidateKey], [AttemptNumber]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderSubmissionAttempt]', N'U')
      AND [name] = N'IX_PO_Attempt_Status_DispatchedDateTime'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Attempt_Status_DispatchedDateTime]
        ON [po].[PurchaseOrderSubmissionAttempt] ([Status], [DispatchedDateTime]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderAudit]', N'U')
      AND [name] = N'IX_PO_Audit_CandidateKey_ChangedDateTime'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Audit_CandidateKey_ChangedDateTime]
        ON [po].[PurchaseOrderAudit] ([CandidateKey], [ChangedDateTime] DESC);
END;

IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'NextAttemptDateTime') IS NOT NULL
   AND NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'IX_PO_Notification_DueWork'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Notification_DueWork]
        ON [po].[PurchaseOrderNotification]
            ([Status], [NextAttemptDateTime], [CreatedDateTime], [NotificationKey])
        INCLUDE ([LeaseExpiresDateTime], [EmailEnvelopeVersion], [PayloadSha256]);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'IX_PO_Notification_BatchKey_CreatedDateTime'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_Notification_BatchKey_CreatedDateTime]
        ON [po].[PurchaseOrderNotification] ([BatchKey], [CreatedDateTime] DESC);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'[po].[PurchaseOrderNotificationAttempt]', N'U')
      AND [name] = N'IX_PO_NotificationAttempt_StartedDateTime'
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PO_NotificationAttempt_StartedDateTime]
        ON [po].[PurchaseOrderNotificationAttempt] ([StartedDateTime]);
END;
GO
