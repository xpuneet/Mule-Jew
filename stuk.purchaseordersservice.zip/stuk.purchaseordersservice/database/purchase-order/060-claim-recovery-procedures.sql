CREATE OR ALTER PROCEDURE [po].[sp_claim_purchase_order_candidates]
    @workerId nvarchar(256),
    @maxCandidates smallint,
    @leaseDurationSeconds int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @workerId IS NULL
       OR NULLIF(LTRIM(RTRIM(@workerId)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The worker identifier is required.', 1;
    END;

    IF @maxCandidates IS NULL OR @maxCandidates < 1 OR @maxCandidates > 20
    BEGIN
        ;THROW 51004, 'The maximum candidate count must be between 1 and 20.', 1;
    END;

    IF @leaseDurationSeconds IS NULL OR @leaseDurationSeconds <= 0
    BEGIN
        ;THROW 51004, 'The lease duration must be positive.', 1;
    END;

    DECLARE @now datetimeoffset(3);
    DECLARE @claimedCandidates TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Source] nvarchar(50) NOT NULL,
        [Account] nvarchar(50) NOT NULL,
        [Branch] nvarchar(20) NOT NULL,
        [Reference] nvarchar(100) NULL,
        [Status] varchar(50) NOT NULL,
        [PayloadJson] nvarchar(max) NOT NULL,
        [LeaseToken] uniqueidentifier NOT NULL,
        [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();

        ;WITH claimableCandidates AS
        (
            SELECT TOP (@maxCandidates)
                *
            FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, READPAST, READCOMMITTEDLOCK)
            WHERE [Status] IN ('READY_FOR_SUBMISSION', 'RETRY_REQUESTED')
              AND [LeaseToken] IS NULL
            ORDER BY [AcceptedDateTime], [CandidateKey]
        )
        UPDATE claimableCandidates
        SET
            [LeaseToken] = NEWID(),
            [LeaseOwner] = @workerId,
            [LeaseAcquiredDateTime] = @now,
            [LeaseExpiresDateTime] = DATEADD(second, @leaseDurationSeconds, @now),
            [RefreshDateTime] = @now
        OUTPUT
            inserted.[CandidateId],
            inserted.[Source],
            inserted.[Account],
            inserted.[Branch],
            inserted.[Reference],
            inserted.[Status],
            inserted.[PayloadJson],
            inserted.[LeaseToken],
            inserted.[LeaseExpiresDateTime],
            inserted.[RowVersion]
        INTO @claimedCandidates
        (
            [CandidateId],
            [Source],
            [Account],
            [Branch],
            [Reference],
            [Status],
            [PayloadJson],
            [LeaseToken],
            [LeaseExpiresDateTime],
            [RowVersion]
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [Source],
        [Account],
        [Branch],
        [Reference],
        [Status],
        [PayloadJson],
        [LeaseToken],
        [LeaseExpiresDateTime],
        [RowVersion]
    FROM @claimedCandidates;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_renew_purchase_order_claim]
    @candidateId uniqueidentifier,
    @leaseToken uniqueidentifier,
    @workerId nvarchar(256),
    @leaseDurationSeconds int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @leaseToken IS NULL
    BEGIN
        ;THROW 51004, 'The lease token is required.', 1;
    END;

    IF @workerId IS NULL
       OR NULLIF(LTRIM(RTRIM(@workerId)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The worker identifier is required.', 1;
    END;

    IF @leaseDurationSeconds IS NULL OR @leaseDurationSeconds <= 0
    BEGIN
        ;THROW 51004, 'The lease duration must be positive.', 1;
    END;

    DECLARE @now datetimeoffset(3);
    DECLARE @candidateKey bigint;
    DECLARE @currentLeaseToken uniqueidentifier;
    DECLARE @currentLeaseOwner nvarchar(256);
    DECLARE @currentLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @requiredLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @newLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @renewedClaim TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [LeaseExpiresDateTime] datetimeoffset(3) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();
        SET @requiredLeaseExpiresDateTime = DATEADD(second, @leaseDurationSeconds, @now);

        SELECT
            @candidateKey = [CandidateKey],
            @currentLeaseToken = [LeaseToken],
            @currentLeaseOwner = [LeaseOwner],
            @currentLeaseExpiresDateTime = [LeaseExpiresDateTime]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @currentLeaseToken IS NULL
           OR @currentLeaseToken <> @leaseToken
           OR @currentLeaseOwner IS NULL
           OR @currentLeaseOwner <> @workerId
           OR @currentLeaseExpiresDateTime IS NULL
           OR @currentLeaseExpiresDateTime <= @now
        BEGIN
            ;THROW 51003, 'The purchase order claim is missing, expired, or does not match.', 1;
        END;

        SET @newLeaseExpiresDateTime =
            CASE
                WHEN @currentLeaseExpiresDateTime >= @requiredLeaseExpiresDateTime
                    THEN DATEADD(second, 1, @currentLeaseExpiresDateTime)
                ELSE @requiredLeaseExpiresDateTime
            END;

        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [LeaseExpiresDateTime] = @newLeaseExpiresDateTime,
            [RefreshDateTime] = @now
        OUTPUT
            inserted.[CandidateId],
            inserted.[LeaseExpiresDateTime],
            inserted.[RowVersion]
        INTO @renewedClaim
        WHERE [CandidateKey] = @candidateKey;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [LeaseExpiresDateTime],
        [RowVersion]
    FROM @renewedClaim;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_release_purchase_order_claim]
    @candidateId uniqueidentifier,
    @leaseToken uniqueidentifier,
    @workerId nvarchar(256)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @leaseToken IS NULL
    BEGIN
        ;THROW 51004, 'The lease token is required.', 1;
    END;

    IF @workerId IS NULL
       OR NULLIF(LTRIM(RTRIM(@workerId)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The worker identifier is required.', 1;
    END;

    DECLARE @now datetimeoffset(3);
    DECLARE @candidateKey bigint;
    DECLARE @candidateStatus varchar(50);
    DECLARE @currentLeaseToken uniqueidentifier;
    DECLARE @currentLeaseOwner nvarchar(256);
    DECLARE @currentLeaseExpiresDateTime datetimeoffset(3);
    DECLARE @releasedClaim TABLE
    (
        [CandidateId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();

        SELECT
            @candidateKey = [CandidateKey],
            @candidateStatus = [Status],
            @currentLeaseToken = [LeaseToken],
            @currentLeaseOwner = [LeaseOwner],
            @currentLeaseExpiresDateTime = [LeaseExpiresDateTime]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @candidateKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order candidate was not found.', 1;
        END;

        IF @currentLeaseToken IS NULL
           OR @currentLeaseToken <> @leaseToken
           OR @currentLeaseOwner IS NULL
           OR @currentLeaseOwner <> @workerId
           OR @currentLeaseExpiresDateTime IS NULL
           OR @currentLeaseExpiresDateTime <= @now
        BEGIN
            ;THROW 51003, 'The purchase order claim is missing, expired, or does not match.', 1;
        END;

        IF @candidateStatus NOT IN ('READY_FOR_SUBMISSION', 'RETRY_REQUESTED')
        BEGIN
            ;THROW 51004, 'Only a pre-dispatch purchase order claim can be released.', 1;
        END;

        UPDATE [po].[PurchaseOrderCandidate]
        SET
            [LeaseToken] = NULL,
            [LeaseOwner] = NULL,
            [LeaseAcquiredDateTime] = NULL,
            [LeaseExpiresDateTime] = NULL,
            [RefreshDateTime] = @now
        OUTPUT
            inserted.[CandidateId],
            inserted.[Status],
            inserted.[RowVersion]
        INTO @releasedClaim
        WHERE [CandidateKey] = @candidateKey;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [CandidateId],
        [Status],
        [RowVersion]
    FROM @releasedClaim;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_expire_purchase_order_claims]
    @actor nvarchar(256)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    DECLARE @now datetimeoffset(3);
    DECLARE @unknownOutcomeDescription nvarchar(1000) =
        N'The purchase order claim expired after dispatch; the outcome is unknown and requires manual reconciliation.';
    DECLARE @expiredClaims TABLE
    (
        [CandidateKey] bigint NOT NULL PRIMARY KEY,
        [CandidateId] uniqueidentifier NOT NULL,
        [PreviousStatus] varchar(50) NOT NULL,
        [LeaseToken] uniqueidentifier NOT NULL
    );
    DECLARE @unknownOutcomeClaims TABLE
    (
        [CandidateKey] bigint NOT NULL PRIMARY KEY
    );
    DECLARE @beforeDispatchClaims TABLE
    (
        [CandidateKey] bigint NOT NULL PRIMARY KEY
    );
    DECLARE @unknownOutcomesApplied TABLE
    (
        [CandidateKey] bigint NOT NULL PRIMARY KEY
    );
    DECLARE @releasedClaims TABLE
    (
        [CandidateKey] bigint NOT NULL PRIMARY KEY
    );
    DECLARE @releasedBeforeDispatchCount int;
    DECLARE @unknownOutcomeCount int;

    BEGIN TRY
        BEGIN TRANSACTION;
        SET @now = SYSUTCDATETIME();

        INSERT INTO @expiredClaims
        (
            [CandidateKey],
            [CandidateId],
            [PreviousStatus],
            [LeaseToken]
        )
        SELECT
            [CandidateKey],
            [CandidateId],
            [Status],
            [LeaseToken]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, READPAST, READCOMMITTEDLOCK)
        WHERE [LeaseToken] IS NOT NULL
          AND [LeaseExpiresDateTime] IS NOT NULL
          AND [LeaseExpiresDateTime] <= @now;

        INSERT INTO @unknownOutcomeClaims ([CandidateKey])
        SELECT DISTINCT expired.[CandidateKey]
        FROM @expiredClaims AS expired
        INNER JOIN [po].[PurchaseOrderSubmissionAttempt] AS attempt WITH (UPDLOCK, HOLDLOCK)
            ON attempt.[CandidateKey] = expired.[CandidateKey]
           AND attempt.[ClaimToken] = expired.[LeaseToken]
           AND attempt.[Status] = 'DISPATCHED'
           AND attempt.[CompletedDateTime] IS NULL;

        INSERT INTO @beforeDispatchClaims ([CandidateKey])
        SELECT expired.[CandidateKey]
        FROM @expiredClaims AS expired
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM @unknownOutcomeClaims AS unknownOutcome
            WHERE unknownOutcome.[CandidateKey] = expired.[CandidateKey]
        );

        UPDATE attempt
        SET
            [Status] = 'UNKNOWN_OUTCOME',
            [CompletedDateTime] = @now,
            [FailureCategory] = 'LEASE_EXPIRED_AFTER_DISPATCH',
            [MessageCode] = 'UNKNOWN_OUTCOME',
            [MessageDescription] = @unknownOutcomeDescription
        FROM [po].[PurchaseOrderSubmissionAttempt] AS attempt
        INNER JOIN @expiredClaims AS expired
            ON expired.[CandidateKey] = attempt.[CandidateKey]
           AND expired.[LeaseToken] = attempt.[ClaimToken]
        INNER JOIN @unknownOutcomeClaims AS unknownOutcome
            ON unknownOutcome.[CandidateKey] = attempt.[CandidateKey]
        WHERE attempt.[Status] = 'DISPATCHED'
          AND attempt.[CompletedDateTime] IS NULL;

        UPDATE candidate
        SET
            [Status] = 'NON_RECOVERABLE_ERROR',
            [StatusDateTime] = @now,
            [StatusReason] = @unknownOutcomeDescription,
            [PreviousMessageCode] = candidate.[MessageCode],
            [PreviousMessageDescription] = candidate.[MessageDescription],
            [MessageCode] = 'UNKNOWN_OUTCOME',
            [MessageDescription] = @unknownOutcomeDescription,
            [UpdatedDateTime] = @now,
            [RefreshDateTime] = @now,
            [LeaseToken] = NULL,
            [LeaseOwner] = NULL,
            [LeaseAcquiredDateTime] = NULL,
            [LeaseExpiresDateTime] = NULL
        OUTPUT inserted.[CandidateKey]
        INTO @unknownOutcomesApplied
        FROM [po].[PurchaseOrderCandidate] AS candidate
        INNER JOIN @unknownOutcomeClaims AS unknownOutcome
            ON unknownOutcome.[CandidateKey] = candidate.[CandidateKey];

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        SELECT
            expired.[CandidateKey],
            'CLAIM_EXPIRED_UNKNOWN_OUTCOME',
            'SYSTEM',
            @actor,
            @unknownOutcomeDescription,
            expired.[PreviousStatus],
            'NON_RECOVERABLE_ERROR',
            NULL,
            NULL,
            NULL,
            expired.[LeaseToken],
            @now
        FROM @expiredClaims AS expired
        INNER JOIN @unknownOutcomesApplied AS applied
            ON applied.[CandidateKey] = expired.[CandidateKey];

        UPDATE candidate
        SET
            [LeaseToken] = NULL,
            [LeaseOwner] = NULL,
            [LeaseAcquiredDateTime] = NULL,
            [LeaseExpiresDateTime] = NULL,
            [RefreshDateTime] = @now
        OUTPUT inserted.[CandidateKey]
        INTO @releasedClaims
        FROM [po].[PurchaseOrderCandidate] AS candidate
        INNER JOIN @beforeDispatchClaims AS beforeDispatch
            ON beforeDispatch.[CandidateKey] = candidate.[CandidateKey];

        SELECT @releasedBeforeDispatchCount = COUNT(*)
        FROM @releasedClaims;

        SELECT @unknownOutcomeCount = COUNT(*)
        FROM @unknownOutcomesApplied;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        @releasedBeforeDispatchCount AS [ReleasedBeforeDispatchCount],
        @unknownOutcomeCount AS [UnknownOutcomeCount];
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_candidate]
    @candidateId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderCandidate]
        WHERE [CandidateId] = @candidateId
    )
    BEGIN
        ;THROW 51001, 'The purchase order candidate was not found.', 1;
    END;

    SELECT
        candidate.[CandidateId],
        batch.[BatchId],
        candidate.[Source],
        candidate.[Kind],
        candidate.[Account],
        candidate.[Branch],
        candidate.[Reference],
        candidate.[IconPurchaseOrderNumber],
        candidate.[Status],
        candidate.[StatusDateTime],
        candidate.[StatusReason],
        candidate.[ProcessBatchNo],
        candidate.[PayloadMD5],
        candidate.[MessageCode],
        candidate.[MessageDescription],
        candidate.[PreviousMessageCode],
        candidate.[PreviousMessageDescription],
        candidate.[PayloadJson],
        candidate.[AcceptedDateTime],
        candidate.[CreatedDateTime],
        candidate.[UpdatedDateTime],
        candidate.[RefreshDateTime],
        candidate.[PendingRetriesCount],
        candidate.[ProcessingRetriesCount],
        candidate.[LeaseToken],
        candidate.[LeaseOwner],
        candidate.[LeaseAcquiredDateTime],
        candidate.[LeaseExpiresDateTime],
        candidate.[RowVersion]
    FROM [po].[PurchaseOrderCandidate] AS candidate
    LEFT JOIN [po].[PurchaseOrderBatch] AS batch
        ON batch.[BatchKey] = candidate.[BatchKey]
    WHERE candidate.[CandidateId] = @candidateId;
END;
GO
