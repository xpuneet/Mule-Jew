SET NOCOUNT ON;
SET XACT_ABORT ON;

-- This template is intentionally not included by 000-deploy.sql.
-- Copy it into the approved environment change, replace every placeholder,
-- review the non-secret values, and run it before application rollout.
DECLARE @settings TABLE
(
    [Context] nvarchar(100) NOT NULL,
    [Key] nvarchar(256) NOT NULL,
    [Value] nvarchar(max) NOT NULL,
    PRIMARY KEY ([Context], [Key])
);

INSERT INTO @settings ([Context], [Key], [Value])
VALUES
    (N'Common', N'CommonSettings:ServiceName', N'__REPLACE_SERVICE_NAME__'),
    (N'WebApi', N'WebApiSettings:AllowedSources', N'__REPLACE_ALLOWED_SOURCES_JSON_ARRAY__'),
    (N'WebApi', N'WebApiSettings:ApiCreateUser', N'__REPLACE_API_CREATE_USER__'),
    (N'WebApi', N'WebApiSettings:PurchaseOrdersMaxPageSize', N'__REPLACE_MAX_PAGE_SIZE__');

IF EXISTS
(
    SELECT 1
    FROM @settings
    WHERE [Value] LIKE N'__REPLACE[_]%'
)
BEGIN
    ;THROW 51004, 'Replace every application-setting placeholder before execution.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM @settings
    WHERE [Key] = N'WebApiSettings:AllowedSources'
      AND ISJSON([Value], ARRAY) <> 1
)
BEGIN
    ;THROW 51004, 'WebApiSettings:AllowedSources must be a JSON array.', 1;
END;

BEGIN TRY
    BEGIN TRANSACTION;

    UPDATE target
    SET target.[Value] = source.[Value]
    FROM [po].[ApplicationSetting] AS target
    INNER JOIN @settings AS source
        ON source.[Context] = target.[Context]
       AND source.[Key] = target.[Key]
    WHERE target.[Value] <> source.[Value];

    INSERT INTO [po].[ApplicationSetting] ([Context], [Key], [Value])
    SELECT source.[Context], source.[Key], source.[Value]
    FROM @settings AS source
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM [po].[ApplicationSetting] AS target
        WHERE target.[Context] = source.[Context]
          AND target.[Key] = source.[Key]
    );

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
