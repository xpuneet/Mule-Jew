:ON ERROR EXIT
:r .\010-preflight.sql
:r .\020-schema.sql
:r .\030-operational-tables.sql
:r .\035-email-notification-outbox-migration.sql
:r .\036-relex-notification-events.sql
:r .\040-api-configuration-procedures.sql
:r .\050-batch-ingestion-procedures.sql
:r .\060-claim-recovery-procedures.sql
:r .\070-submission-outcome-procedures.sql
:r .\080-support-notification-procedures.sql
:r .\081-relex-notification-procedures.sql
:r .\085-webapp-procedures.sql
:r .\090-security.sql
:r .\100-verify.sql
