CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_candidate_summary]
    @source nvarchar(50),
    @afterDateTimeUtc datetimeoffset(3),
    @untilDateTimeUtc datetimeoffset(3)
AS
BEGIN
    SET NOCOUNT ON;

    IF @source IS NULL
       OR NULLIF(LTRIM(RTRIM(@source)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The source is required.', 1;
    END;

    IF @afterDateTimeUtc IS NULL
       OR @untilDateTimeUtc IS NULL
       OR DATEPART(TZOFFSET, @afterDateTimeUtc) <> 0
       OR DATEPART(TZOFFSET, @untilDateTimeUtc) <> 0
    BEGIN
        ;THROW 51004, 'The summary timestamps must use the UTC offset.', 1;
    END;

    IF @afterDateTimeUtc >= @untilDateTimeUtc
    BEGIN
        ;THROW 51004, 'The summary start must be before the end.', 1;
    END;

    SELECT
        [Status],
        COUNT_BIG(*) AS [CandidateCount]
    FROM [po].[PurchaseOrderCandidate]
    WHERE [Source] = @source
      AND [AcceptedDateTime] >= @afterDateTimeUtc
      AND [AcceptedDateTime] < @untilDateTimeUtc
    GROUP BY [Status];
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_batch_summary]
    @source nvarchar(50),
    @afterDateTimeUtc datetimeoffset(3),
    @untilDateTimeUtc datetimeoffset(3)
AS
BEGIN
    SET NOCOUNT ON;

    IF @source IS NULL
       OR NULLIF(LTRIM(RTRIM(@source)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The source is required.', 1;
    END;

    IF @afterDateTimeUtc IS NULL
       OR @untilDateTimeUtc IS NULL
       OR DATEPART(TZOFFSET, @afterDateTimeUtc) <> 0
       OR DATEPART(TZOFFSET, @untilDateTimeUtc) <> 0
    BEGIN
        ;THROW 51004, 'The summary timestamps must use the UTC offset.', 1;
    END;

    IF @afterDateTimeUtc >= @untilDateTimeUtc
    BEGIN
        ;THROW 51004, 'The summary start must be before the end.', 1;
    END;

    SELECT
        CASE
            WHEN [Status] IN ('INGESTING', 'READY_FOR_SUBMISSION', 'PROCESSING')
                THEN 'PROCESSING'
            ELSE [Status]
        END AS [Status],
        COUNT_BIG(*) AS [BatchCount]
    FROM [po].[PurchaseOrderBatch]
    WHERE [Source] = @source
      AND [DiscoveredDateTime] >= @afterDateTimeUtc
      AND [DiscoveredDateTime] < @untilDateTimeUtc
    GROUP BY
        CASE
            WHEN [Status] IN ('INGESTING', 'READY_FOR_SUBMISSION', 'PROCESSING')
                THEN 'PROCESSING'
            ELSE [Status]
        END;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_search_purchase_order_batches]
    @source nvarchar(50),
    @originalFileName nvarchar(260) = NULL,
    @status varchar(50) = NULL,
    @discoveredAfterDateTimeUtc datetimeoffset(3),
    @discoveredUntilDateTimeUtc datetimeoffset(3),
    @pageNumber int,
    @pageSize int
AS
BEGIN
    SET NOCOUNT ON;

    SET @source = NULLIF(LTRIM(RTRIM(@source)), N'');
    SET @originalFileName = NULLIF(LTRIM(RTRIM(@originalFileName)), N'');
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), '');

    IF @source IS NULL
    BEGIN
        ;THROW 51004, 'The source is required.', 1;
    END;

    IF @status IS NOT NULL
       AND @status NOT IN ('PROCESSING', 'COMPLETED', 'FAILED')
    BEGIN
        ;THROW 51004, 'The file status is invalid.', 1;
    END;

    IF @discoveredAfterDateTimeUtc IS NULL
       OR @discoveredUntilDateTimeUtc IS NULL
       OR DATEPART(TZOFFSET, @discoveredAfterDateTimeUtc) <> 0
       OR DATEPART(TZOFFSET, @discoveredUntilDateTimeUtc) <> 0
       OR @discoveredAfterDateTimeUtc >= @discoveredUntilDateTimeUtc
    BEGIN
        ;THROW 51004, 'The discovered timestamp range is invalid.', 1;
    END;

    IF @pageNumber IS NULL OR @pageNumber < 1
    BEGIN
        ;THROW 51004, 'The page number must be at least one.', 1;
    END;

    IF @pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50
    BEGIN
        ;THROW 51004, 'The page size must be between one and fifty.', 1;
    END;

    DECLARE @offset bigint =
        (CONVERT(bigint, @pageNumber) - 1) * CONVERT(bigint, @pageSize);

    SELECT
        batch.[BatchId],
        batch.[Source],
        batch.[OriginalFileName],
        batch.[SourceFilePath],
        batch.[FileContentLength],
        batch.[Status],
        batch.[ExpectedRowCount],
        batch.[ParsedRowCount],
        batch.[CandidateCount],
        batch.[FailureCode],
        batch.[DiscoveredDateTime],
        batch.[CompletedDateTime],
        batch.[UpdatedDateTime]
    FROM [po].[PurchaseOrderBatch] AS batch
    WHERE batch.[Source] = @source
      AND (@originalFileName IS NULL
          OR CHARINDEX(@originalFileName, batch.[OriginalFileName]) > 0)
      AND
      (
          @status IS NULL
          OR (@status = 'PROCESSING'
              AND batch.[Status] IN ('INGESTING', 'READY_FOR_SUBMISSION', 'PROCESSING'))
          OR batch.[Status] = @status
      )
      AND batch.[DiscoveredDateTime] >= @discoveredAfterDateTimeUtc
      AND batch.[DiscoveredDateTime] < @discoveredUntilDateTimeUtc
    ORDER BY batch.[DiscoveredDateTime] DESC, batch.[BatchId] DESC
    OFFSET @offset ROWS
    FETCH NEXT @pageSize ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_batch_candidate_summary]
    @batchId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    DECLARE @batchKey bigint;

    SELECT @batchKey = [BatchKey]
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @batchId;

    IF @batchKey IS NULL
    BEGIN
        ;THROW 51001, 'The purchase order batch was not found.', 1;
    END;

    SELECT
        candidate.[Status],
        COUNT_BIG(*) AS [CandidateCount]
    FROM [po].[PurchaseOrderCandidate] AS candidate
    WHERE candidate.[BatchKey] = @batchKey
    GROUP BY candidate.[Status];
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_search_purchase_order_batch_candidates]
    @batchId uniqueidentifier,
    @status varchar(50) = NULL,
    @pageNumber int,
    @pageSize int
AS
BEGIN
    SET NOCOUNT ON;

    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), '');

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    IF @status IS NOT NULL
       AND @status NOT IN
       (
           'DRAFT',
           'READY_FOR_SUBMISSION',
           'SUBMISSION_IN_PROGRESS',
           'RECOVERABLE_ERROR',
           'NON_RECOVERABLE_ERROR',
           'RETRY_REQUESTED',
           'COMPLETED',
           'CANCELLED'
       )
    BEGIN
        ;THROW 51004, 'The candidate status is invalid.', 1;
    END;

    IF @pageNumber IS NULL OR @pageNumber < 1
    BEGIN
        ;THROW 51004, 'The page number must be at least one.', 1;
    END;

    IF @pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50
    BEGIN
        ;THROW 51004, 'The page size must be between one and fifty.', 1;
    END;

    DECLARE @batchKey bigint;
    DECLARE @offset bigint =
        (CONVERT(bigint, @pageNumber) - 1) * CONVERT(bigint, @pageSize);

    SELECT @batchKey = [BatchKey]
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @batchId;

    IF @batchKey IS NULL
    BEGIN
        ;THROW 51001, 'The purchase order batch was not found.', 1;
    END;

    SELECT
        candidate.[CandidateId],
        candidate.[Account],
        candidate.[Branch],
        candidate.[Reference],
        candidate.[Status],
        candidate.[IconPurchaseOrderNumber],
        candidate.[StatusReason],
        candidate.[AcceptedDateTime],
        candidate.[UpdatedDateTime]
    FROM [po].[PurchaseOrderCandidate] AS candidate
    WHERE candidate.[BatchKey] = @batchKey
      AND (@status IS NULL OR candidate.[Status] = @status)
    ORDER BY candidate.[AcceptedDateTime] DESC, candidate.[CandidateId] DESC
    OFFSET @offset ROWS
    FETCH NEXT @pageSize ROWS ONLY;
END;
GO
