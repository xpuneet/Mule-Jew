SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;

IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'EventType') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [EventType] varchar(100) NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'BusinessCorrelationId') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [BusinessCorrelationId] nvarchar(256) NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'EmailEnvelopeVersion') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [EmailEnvelopeVersion] smallint NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'EmailEnvelopeJson') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [EmailEnvelopeJson] nvarchar(max) NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'PayloadSha256') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [PayloadSha256] binary(32) NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'AttemptCount') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [AttemptCount] int NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'FailureCount') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [FailureCount] int NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'ThrottleCount') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [ThrottleCount] int NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'NextAttemptDateTime') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [NextAttemptDateTime] datetimeoffset(3) NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'LastAttemptDateTime') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [LastAttemptDateTime] datetimeoffset(3) NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'LeaseId') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [LeaseId] uniqueidentifier NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'LeaseExpiresDateTime') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [LeaseExpiresDateTime] datetimeoffset(3) NULL;
IF COL_LENGTH(N'[po].[PurchaseOrderNotification]', N'CompletedDateTime') IS NULL
    ALTER TABLE [po].[PurchaseOrderNotification] ADD [CompletedDateTime] datetimeoffset(3) NULL;
GO

UPDATE [po].[PurchaseOrderNotification]
SET
    [AttemptCount] = COALESCE([AttemptCount], 0),
    [FailureCount] = COALESCE([FailureCount], 0),
    [ThrottleCount] = COALESCE([ThrottleCount], 0),
    [NextAttemptDateTime] = COALESCE([NextAttemptDateTime], [CreatedDateTime]),
    [CompletedDateTime] = CASE
        WHEN [Status] = 'SENT' THEN COALESCE([CompletedDateTime], [SentDateTime])
        ELSE [CompletedDateTime]
    END
WHERE [AttemptCount] IS NULL
   OR [FailureCount] IS NULL
   OR [ThrottleCount] IS NULL
   OR [NextAttemptDateTime] IS NULL
   OR ([Status] = 'SENT'
       AND [CompletedDateTime] IS NULL
       AND [SentDateTime] IS NOT NULL);

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE [object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'BatchKey'
      AND [is_nullable] = 0
)
    ALTER TABLE [po].[PurchaseOrderNotification] ALTER COLUMN [BatchKey] bigint NULL;

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE [object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'TemplateKey'
      AND [is_nullable] = 0
)
    ALTER TABLE [po].[PurchaseOrderNotification] ALTER COLUMN [TemplateKey] nvarchar(100) NULL;

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE [object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'RecipientGroupKey'
      AND [is_nullable] = 0
)
    ALTER TABLE [po].[PurchaseOrderNotification] ALTER COLUMN [RecipientGroupKey] nvarchar(100) NULL;

ALTER TABLE [po].[PurchaseOrderNotification] ALTER COLUMN [AttemptCount] int NOT NULL;
ALTER TABLE [po].[PurchaseOrderNotification] ALTER COLUMN [FailureCount] int NOT NULL;
ALTER TABLE [po].[PurchaseOrderNotification] ALTER COLUMN [ThrottleCount] int NOT NULL;
ALTER TABLE [po].[PurchaseOrderNotification] ALTER COLUMN [NextAttemptDateTime] datetimeoffset(3) NOT NULL;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'DF_PO_Notification_AttemptCount'
)
    ALTER TABLE [po].[PurchaseOrderNotification]
        ADD CONSTRAINT [DF_PO_Notification_AttemptCount] DEFAULT (0) FOR [AttemptCount];

IF NOT EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'DF_PO_Notification_FailureCount'
)
    ALTER TABLE [po].[PurchaseOrderNotification]
        ADD CONSTRAINT [DF_PO_Notification_FailureCount] DEFAULT (0) FOR [FailureCount];

IF NOT EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'DF_PO_Notification_ThrottleCount'
)
    ALTER TABLE [po].[PurchaseOrderNotification]
        ADD CONSTRAINT [DF_PO_Notification_ThrottleCount] DEFAULT (0) FOR [ThrottleCount];

IF NOT EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'DF_PO_Notification_NextAttemptDateTime'
)
    ALTER TABLE [po].[PurchaseOrderNotification]
        ADD CONSTRAINT [DF_PO_Notification_NextAttemptDateTime]
            DEFAULT (SYSUTCDATETIME()) FOR [NextAttemptDateTime];

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'CK_PO_Notification_Status'
)
    ALTER TABLE [po].[PurchaseOrderNotification] DROP CONSTRAINT [CK_PO_Notification_Status];

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'CK_PO_Notification_UtcDateTimes'
)
    ALTER TABLE [po].[PurchaseOrderNotification] DROP CONSTRAINT [CK_PO_Notification_UtcDateTimes];

ALTER TABLE [po].[PurchaseOrderNotification] WITH CHECK
    ADD CONSTRAINT [CK_PO_Notification_Status]
        CHECK ([Status] IN ('PENDING', 'SENDING', 'SENT', 'FAILED'));

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'CK_PO_Notification_Counters'
)
    ALTER TABLE [po].[PurchaseOrderNotification] WITH CHECK
        ADD CONSTRAINT [CK_PO_Notification_Counters]
            CHECK ([AttemptCount] >= 0 AND [FailureCount] >= 0 AND [ThrottleCount] >= 0);

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'CK_PO_Notification_EnvelopeCompleteness'
)
    ALTER TABLE [po].[PurchaseOrderNotification] WITH CHECK
        ADD CONSTRAINT [CK_PO_Notification_EnvelopeCompleteness]
            CHECK
            (
                ([EmailEnvelopeVersion] IS NULL
                    AND [EmailEnvelopeJson] IS NULL
                    AND [PayloadSha256] IS NULL
                    AND [EventType] IS NULL
                    AND [BusinessCorrelationId] IS NULL)
                OR
                ([EmailEnvelopeVersion] IS NOT NULL
                    AND [EmailEnvelopeJson] IS NOT NULL
                    AND [PayloadSha256] IS NOT NULL
                    AND [EventType] IS NOT NULL
                    AND [BusinessCorrelationId] IS NOT NULL)
            );

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'CK_PO_Notification_EnvelopeJson'
)
    ALTER TABLE [po].[PurchaseOrderNotification] WITH CHECK
        ADD CONSTRAINT [CK_PO_Notification_EnvelopeJson]
            CHECK
            (
                [EmailEnvelopeJson] IS NULL
                OR (ISJSON([EmailEnvelopeJson]) = 1
                    AND DATALENGTH([EmailEnvelopeJson]) <= 20 * 1024 * 1024)
            );

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'CK_PO_Notification_SenderState'
)
    ALTER TABLE [po].[PurchaseOrderNotification] WITH CHECK
        ADD CONSTRAINT [CK_PO_Notification_SenderState]
            CHECK
            (
                ([EmailEnvelopeJson] IS NULL
                    AND [Status] <> 'SENDING'
                    AND [LeaseId] IS NULL
                    AND [LeaseExpiresDateTime] IS NULL)
                OR
                ([EmailEnvelopeJson] IS NOT NULL AND
                    (([Status] = 'PENDING'
                        AND [LeaseId] IS NULL
                        AND [LeaseExpiresDateTime] IS NULL
                        AND [SentDateTime] IS NULL
                        AND [CompletedDateTime] IS NULL)
                    OR ([Status] = 'SENDING'
                        AND [LeaseId] IS NOT NULL
                        AND [LeaseExpiresDateTime] IS NOT NULL
                        AND [SentDateTime] IS NULL
                        AND [CompletedDateTime] IS NULL)
                    OR ([Status] = 'SENT'
                        AND [LeaseId] IS NULL
                        AND [LeaseExpiresDateTime] IS NULL
                        AND [SentDateTime] IS NOT NULL
                        AND [CompletedDateTime] IS NOT NULL)
                    OR ([Status] = 'FAILED'
                        AND [LeaseId] IS NULL
                        AND [LeaseExpiresDateTime] IS NULL
                        AND [SentDateTime] IS NULL
                        AND [CompletedDateTime] IS NOT NULL)))
            );

ALTER TABLE [po].[PurchaseOrderNotification] WITH CHECK
    ADD CONSTRAINT [CK_PO_Notification_UtcDateTimes]
        CHECK
        (
            DATEPART(TZOFFSET, [NextAttemptDateTime]) = 0
            AND ([LastAttemptDateTime] IS NULL
                OR DATEPART(TZOFFSET, [LastAttemptDateTime]) = 0)
            AND ([LeaseExpiresDateTime] IS NULL
                OR DATEPART(TZOFFSET, [LeaseExpiresDateTime]) = 0)
            AND DATEPART(TZOFFSET, [CreatedDateTime]) = 0
            AND ([SentDateTime] IS NULL
                OR DATEPART(TZOFFSET, [SentDateTime]) = 0)
            AND ([CompletedDateTime] IS NULL
                OR DATEPART(TZOFFSET, [CompletedDateTime]) = 0)
        );

IF OBJECT_ID(N'[po].[PurchaseOrderNotificationAttempt]', N'U') IS NULL
BEGIN
    EXEC sys.sp_executesql N'
        CREATE TABLE [po].[PurchaseOrderNotificationAttempt]
        (
            [NotificationAttemptKey] bigint IDENTITY(1,1) NOT NULL,
            [AttemptId] uniqueidentifier NOT NULL,
            [NotificationKey] bigint NOT NULL,
            [AttemptNumber] int NOT NULL,
            [StartedDateTime] datetimeoffset(3) NOT NULL,
            [CompletedDateTime] datetimeoffset(3) NULL,
            [Outcome] varchar(50) NOT NULL,
            [ProviderMessageId] nvarchar(256) NULL,
            [FailureCategory] varchar(50) NULL,
            [FailureCode] varchar(100) NULL,
            [HttpStatusCode] smallint NULL,
            CONSTRAINT [PK_PO_NotificationAttempt]
                PRIMARY KEY CLUSTERED ([NotificationAttemptKey]),
            CONSTRAINT [UQ_PO_NotificationAttempt_AttemptId]
                UNIQUE NONCLUSTERED ([AttemptId]),
            CONSTRAINT [UQ_PO_NotificationAttempt_NotificationKey_AttemptNumber]
                UNIQUE NONCLUSTERED ([NotificationKey], [AttemptNumber]),
            CONSTRAINT [CK_PO_NotificationAttempt_AttemptNumber]
                CHECK ([AttemptNumber] >= 1),
            CONSTRAINT [CK_PO_NotificationAttempt_Outcome]
                CHECK ([Outcome] IN
                    (''STARTED'', ''SUCCEEDED'', ''TRANSIENT_FAILURE'', ''THROTTLED'',
                     ''PERMANENT_FAILURE'', ''DEFERRED'', ''LEASE_EXPIRED'')),
            CONSTRAINT [CK_PO_NotificationAttempt_HttpStatusCode]
                CHECK ([HttpStatusCode] IS NULL OR [HttpStatusCode] BETWEEN 100 AND 599),
            CONSTRAINT [CK_PO_NotificationAttempt_UtcDateTimes]
                CHECK (DATEPART(TZOFFSET, [StartedDateTime]) = 0
                    AND ([CompletedDateTime] IS NULL
                        OR DATEPART(TZOFFSET, [CompletedDateTime]) = 0)),
            CONSTRAINT [FK_PO_NotificationAttempt_Notification]
                FOREIGN KEY ([NotificationKey])
                REFERENCES [po].[PurchaseOrderNotification] ([NotificationKey])
                ON DELETE NO ACTION
                ON UPDATE NO ACTION
        );';
END;

IF EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE [object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'IX_PO_Notification_Status_CreatedDateTime'
)
    DROP INDEX [IX_PO_Notification_Status_CreatedDateTime]
        ON [po].[PurchaseOrderNotification];

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE [object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotification]', N'U')
      AND [name] = N'IX_PO_Notification_DueWork'
)
    CREATE NONCLUSTERED INDEX [IX_PO_Notification_DueWork]
        ON [po].[PurchaseOrderNotification]
            ([Status], [NextAttemptDateTime], [CreatedDateTime], [NotificationKey])
        INCLUDE ([LeaseExpiresDateTime], [EmailEnvelopeVersion], [PayloadSha256]);

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE [object_id] = OBJECT_ID(N'[po].[PurchaseOrderNotificationAttempt]', N'U')
      AND [name] = N'IX_PO_NotificationAttempt_StartedDateTime'
)
    CREATE NONCLUSTERED INDEX [IX_PO_NotificationAttempt_StartedDateTime]
        ON [po].[PurchaseOrderNotificationAttempt] ([StartedDateTime]);
GO
