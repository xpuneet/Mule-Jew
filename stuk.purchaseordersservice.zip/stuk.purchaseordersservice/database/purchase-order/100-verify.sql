SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @expectedTables nvarchar(max) = N'[
  "ApplicationSetting",
  "PurchaseOrderBatch",
  "PurchaseOrderCandidate",
  "PurchaseOrderSubmissionAttempt",
  "PurchaseOrderAudit",
  "PurchaseOrderNotification",
  "PurchaseOrderNotificationAttempt",
  "RelexNotificationEvent"
]';

DECLARE @expectedProcedures nvarchar(max) = N'[
  "sp_get_application_settings",
  "sp_create_purchase_order_candidate",
  "sp_search_purchase_order_candidates",
  "sp_register_purchase_order_batch",
  "sp_add_purchase_order_candidate_to_batch",
  "sp_complete_purchase_order_batch",
  "sp_fail_purchase_order_batch",
  "sp_get_purchase_order_batch",
  "sp_get_purchase_order_batch_by_source_hash",
  "sp_claim_purchase_order_candidates",
  "sp_renew_purchase_order_claim",
  "sp_release_purchase_order_claim",
  "sp_expire_purchase_order_claims",
  "sp_get_purchase_order_candidate",
  "sp_begin_purchase_order_submission_attempt",
  "sp_fail_purchase_order_candidate_pre_dispatch",
  "sp_complete_purchase_order_submission",
  "sp_fail_purchase_order_submission",
  "sp_request_purchase_order_retry",
  "sp_cancel_purchase_order_candidate",
  "sp_get_purchase_order_audit",
  "sp_get_purchase_order_batch_outcomes",
  "sp_register_purchase_order_notification",
  "sp_complete_purchase_order_notification",
  "sp_enqueue_purchase_order_email_notification",
  "sp_claim_purchase_order_email_notifications",
  "sp_defer_purchase_order_email_notification",
  "sp_reschedule_purchase_order_email_notification",
  "sp_complete_purchase_order_email_notification",
  "sp_get_purchase_order_email_notification_queue_summary",
  "sp_prepare_and_claim_relex_notification_events",
  "sp_save_relex_notification_envelope",
  "sp_complete_relex_notification_event",
  "sp_get_purchase_order_candidate_summary",
  "sp_get_purchase_order_batch_summary",
  "sp_search_purchase_order_batches",
  "sp_get_purchase_order_batch_candidate_summary",
  "sp_search_purchase_order_batch_candidates"
]';

DECLARE @expectedIndexes nvarchar(max) = N'[
  {"table":"ApplicationSetting","index":"PK_PO_ApplicationSetting","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"Context","descending":false},{"column":"Key","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderBatch","index":"PK_PO_Batch","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"BatchKey","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderBatch","index":"UQ_PO_Batch_BatchId","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":true,"keys":[{"column":"BatchId","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderCandidate","index":"PK_PO_Candidate","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"CandidateKey","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderCandidate","index":"UQ_PO_Candidate_CandidateId","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":true,"keys":[{"column":"CandidateId","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderSubmissionAttempt","index":"PK_PO_Attempt","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"AttemptKey","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderSubmissionAttempt","index":"UQ_PO_Attempt_AttemptId","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":true,"keys":[{"column":"AttemptId","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderAudit","index":"PK_PO_Audit","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"AuditKey","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderNotification","index":"PK_PO_Notification","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"NotificationKey","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderNotification","index":"UQ_PO_Notification_NotificationId","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":true,"keys":[{"column":"NotificationId","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderNotificationAttempt","index":"PK_PO_NotificationAttempt","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"NotificationAttemptKey","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderBatch","index":"UX_PO_Batch_Source_FileSha256","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Source","descending":false},{"column":"FileSha256","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderBatch","index":"IX_PO_Batch_Status_DiscoveredDateTime","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Status","descending":false},{"column":"DiscoveredDateTime","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderCandidate","index":"IX_PO_Candidate_Source_Status_AcceptedDateTime","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Source","descending":false},{"column":"Status","descending":false},{"column":"AcceptedDateTime","descending":true}],"includes":["Account","Branch","Reference","IconPurchaseOrderNumber"],"filter":null},
  {"table":"PurchaseOrderCandidate","index":"IX_PO_Candidate_Source_Account_Branch_Reference","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Source","descending":false},{"column":"Account","descending":false},{"column":"Branch","descending":false},{"column":"Reference","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderCandidate","index":"IX_PO_Candidate_IconPurchaseOrderNumber","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"IconPurchaseOrderNumber","descending":false}],"includes":[],"filter":"IconPurchaseOrderNumber IS NOT NULL"},
  {"table":"PurchaseOrderCandidate","index":"IX_PO_Candidate_Status_LeaseExpires_AcceptedDateTime","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Status","descending":false},{"column":"LeaseExpiresDateTime","descending":false},{"column":"AcceptedDateTime","descending":false}],"includes":["CandidateId","Branch"],"filter":null},
  {"table":"PurchaseOrderCandidate","index":"IX_PO_Candidate_BatchKey_CandidateKey","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"BatchKey","descending":false},{"column":"CandidateKey","descending":false}],"includes":["Status","LeaseToken"],"filter":null},
  {"table":"PurchaseOrderSubmissionAttempt","index":"UX_PO_Attempt_CandidateKey_AttemptNumber","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"CandidateKey","descending":false},{"column":"AttemptNumber","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderSubmissionAttempt","index":"IX_PO_Attempt_Status_DispatchedDateTime","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Status","descending":false},{"column":"DispatchedDateTime","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderAudit","index":"IX_PO_Audit_CandidateKey_ChangedDateTime","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"CandidateKey","descending":false},{"column":"ChangedDateTime","descending":true}],"includes":[],"filter":null},
  {"table":"PurchaseOrderNotification","index":"IX_PO_Notification_DueWork","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Status","descending":false},{"column":"NextAttemptDateTime","descending":false},{"column":"CreatedDateTime","descending":false},{"column":"NotificationKey","descending":false}],"includes":["LeaseExpiresDateTime","EmailEnvelopeVersion","PayloadSha256"],"filter":null},
  {"table":"PurchaseOrderNotification","index":"IX_PO_Notification_BatchKey_CreatedDateTime","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"BatchKey","descending":false},{"column":"CreatedDateTime","descending":true}],"includes":[],"filter":null},
  {"table":"PurchaseOrderNotificationAttempt","index":"UQ_PO_NotificationAttempt_AttemptId","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":true,"keys":[{"column":"AttemptId","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderNotificationAttempt","index":"UQ_PO_NotificationAttempt_NotificationKey_AttemptNumber","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":true,"keys":[{"column":"NotificationKey","descending":false},{"column":"AttemptNumber","descending":false}],"includes":[],"filter":null},
  {"table":"PurchaseOrderNotificationAttempt","index":"IX_PO_NotificationAttempt_StartedDateTime","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"StartedDateTime","descending":false}],"includes":[],"filter":null},
  {"table":"RelexNotificationEvent","index":"PK_PO_RelexEvent","type":"CLUSTERED","unique":true,"primaryKey":true,"uniqueConstraint":false,"keys":[{"column":"EventKey","descending":false}],"includes":[],"filter":null},
  {"table":"RelexNotificationEvent","index":"UQ_PO_RelexEvent_NotificationId","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":true,"keys":[{"column":"NotificationId","descending":false}],"includes":[],"filter":null},
  {"table":"RelexNotificationEvent","index":"IX_PO_RelexEvent_DueWork","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"Status","descending":false},{"column":"NextAttemptDateTime","descending":false},{"column":"CreatedDateTime","descending":false}],"includes":["LeaseExpiresDateTime"],"filter":null},
  {"table":"RelexNotificationEvent","index":"UX_PO_RelexEvent_Batch","type":"NONCLUSTERED","unique":true,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"BatchKey","descending":false}],"includes":[],"filter":"BatchKey IS NOT NULL"},
  {"table":"RelexNotificationEvent","index":"IX_PO_RelexEvent_ProcessedFile","type":"NONCLUSTERED","unique":false,"primaryKey":false,"uniqueConstraint":false,"keys":[{"column":"ProcessedFileDateTime","descending":false},{"column":"ProcessingCompletedDateTime","descending":false}],"includes":[],"filter":null}
]';

DECLARE @expectedRoles nvarchar(max) = N'[
  "po_service_executor"
]';

DECLARE @expectedStatusConstraints nvarchar(max) = N'[
  {"table":"PurchaseOrderBatch","constraint":"CK_PO_Batch_Status","column":"Status","definition":"[Status]=''FAILED'' OR [Status]=''COMPLETED'' OR [Status]=''PROCESSING'' OR [Status]=''READY_FOR_SUBMISSION'' OR [Status]=''INGESTING''"},
  {"table":"PurchaseOrderCandidate","constraint":"CK_PO_Candidate_Status","column":"Status","definition":"[Status]=''CANCELLED'' OR [Status]=''COMPLETED'' OR [Status]=''RETRY_REQUESTED'' OR [Status]=''NON_RECOVERABLE_ERROR'' OR [Status]=''RECOVERABLE_ERROR'' OR [Status]=''SUBMISSION_IN_PROGRESS'' OR [Status]=''READY_FOR_SUBMISSION'' OR [Status]=''DRAFT''"},
  {"table":"PurchaseOrderSubmissionAttempt","constraint":"CK_PO_Attempt_Status","column":"Status","definition":"[Status]=''UNKNOWN_OUTCOME'' OR [Status]=''FAILED'' OR [Status]=''SUCCEEDED'' OR [Status]=''DISPATCHED''"},
  {"table":"PurchaseOrderAudit","constraint":"CK_PO_Audit_PreviousStatus","column":"PreviousStatus","definition":"[PreviousStatus] IS NULL OR ([PreviousStatus]=''CANCELLED'' OR [PreviousStatus]=''COMPLETED'' OR [PreviousStatus]=''RETRY_REQUESTED'' OR [PreviousStatus]=''NON_RECOVERABLE_ERROR'' OR [PreviousStatus]=''RECOVERABLE_ERROR'' OR [PreviousStatus]=''SUBMISSION_IN_PROGRESS'' OR [PreviousStatus]=''READY_FOR_SUBMISSION'' OR [PreviousStatus]=''DRAFT'')"},
  {"table":"PurchaseOrderAudit","constraint":"CK_PO_Audit_CurrentStatus","column":"CurrentStatus","definition":"[CurrentStatus] IS NULL OR ([CurrentStatus]=''CANCELLED'' OR [CurrentStatus]=''COMPLETED'' OR [CurrentStatus]=''RETRY_REQUESTED'' OR [CurrentStatus]=''NON_RECOVERABLE_ERROR'' OR [CurrentStatus]=''RECOVERABLE_ERROR'' OR [CurrentStatus]=''SUBMISSION_IN_PROGRESS'' OR [CurrentStatus]=''READY_FOR_SUBMISSION'' OR [CurrentStatus]=''DRAFT'')"},
  {"table":"PurchaseOrderNotification","constraint":"CK_PO_Notification_Status","column":"Status","definition":"[Status]=''FAILED'' OR [Status]=''SENT'' OR [Status]=''SENDING'' OR [Status]=''PENDING''"},
  {"table":"PurchaseOrderNotificationAttempt","constraint":"CK_PO_NotificationAttempt_Outcome","column":"Outcome","definition":"[Outcome]=''LEASE_EXPIRED'' OR [Outcome]=''DEFERRED'' OR [Outcome]=''PERMANENT_FAILURE'' OR [Outcome]=''THROTTLED'' OR [Outcome]=''TRANSIENT_FAILURE'' OR [Outcome]=''SUCCEEDED'' OR [Outcome]=''STARTED''"},
  {"table":"RelexNotificationEvent","constraint":"CK_PO_RelexEvent_Status","column":"Status","definition":"[Status]=''FAILED'' OR [Status]=''ENQUEUED'' OR [Status]=''PROCESSING'' OR [Status]=''PENDING''"}
]';

DECLARE @expectedNotificationColumns nvarchar(max) = N'[
  {"table":"PurchaseOrderNotification","column":"NotificationKey","type":"bigint","nullable":false,"identity":true},
  {"table":"PurchaseOrderNotification","column":"NotificationId","type":"uniqueidentifier","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"BatchKey","type":"bigint","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"Channel","type":"varchar(50)","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"TemplateKey","type":"nvarchar(100)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"RecipientGroupKey","type":"nvarchar(100)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"AttachmentBlobName","type":"nvarchar(512)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"EventType","type":"varchar(100)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"BusinessCorrelationId","type":"nvarchar(256)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"EmailEnvelopeVersion","type":"smallint","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"EmailEnvelopeJson","type":"nvarchar(max)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"PayloadSha256","type":"binary(32)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"Status","type":"varchar(50)","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"AttemptCount","type":"int","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"FailureCount","type":"int","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"ThrottleCount","type":"int","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"NextAttemptDateTime","type":"datetimeoffset(3)","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"LastAttemptDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"LeaseId","type":"uniqueidentifier","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"LeaseExpiresDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"ProviderMessageId","type":"nvarchar(256)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"FailureCode","type":"varchar(100)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"FailureDescription","type":"nvarchar(1000)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"CreatedDateTime","type":"datetimeoffset(3)","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotification","column":"SentDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"CompletedDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotification","column":"RowVersion","type":"timestamp","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"NotificationAttemptKey","type":"bigint","nullable":false,"identity":true},
  {"table":"PurchaseOrderNotificationAttempt","column":"AttemptId","type":"uniqueidentifier","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"NotificationKey","type":"bigint","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"AttemptNumber","type":"int","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"StartedDateTime","type":"datetimeoffset(3)","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"CompletedDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"Outcome","type":"varchar(50)","nullable":false,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"ProviderMessageId","type":"nvarchar(256)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"FailureCategory","type":"varchar(50)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"FailureCode","type":"varchar(100)","nullable":true,"identity":false},
  {"table":"PurchaseOrderNotificationAttempt","column":"HttpStatusCode","type":"smallint","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"EventKey","type":"nvarchar(100)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"NotificationId","type":"uniqueidentifier","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"BatchKey","type":"bigint","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"EventType","type":"varchar(100)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"BusinessCorrelationId","type":"nvarchar(256)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"OriginalFileName","type":"nvarchar(260)","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"ProcessedFileDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"ProcessingCompletedDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"CreatedDateTime","type":"datetimeoffset(3)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"CompositionSettingsJson","type":"nvarchar(max)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"OutcomeRowsJson","type":"nvarchar(max)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"EmailEnvelopeJson","type":"nvarchar(max)","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"Status","type":"varchar(50)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"FailureCount","type":"int","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"NextAttemptDateTime","type":"datetimeoffset(3)","nullable":false,"identity":false},
  {"table":"RelexNotificationEvent","column":"LeaseId","type":"uniqueidentifier","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"LeaseExpiresDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"CompletedDateTime","type":"datetimeoffset(3)","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"FailureCode","type":"varchar(100)","nullable":true,"identity":false},
  {"table":"RelexNotificationEvent","column":"RowVersion","type":"timestamp","nullable":false,"identity":false}
]';

DECLARE @expectedRoleProcedureGrants nvarchar(max) = N'[
  {"role":"po_service_executor","procedure":"sp_get_application_settings"},
  {"role":"po_service_executor","procedure":"sp_create_purchase_order_candidate"},
  {"role":"po_service_executor","procedure":"sp_search_purchase_order_candidates"},
  {"role":"po_service_executor","procedure":"sp_register_purchase_order_batch"},
  {"role":"po_service_executor","procedure":"sp_add_purchase_order_candidate_to_batch"},
  {"role":"po_service_executor","procedure":"sp_complete_purchase_order_batch"},
  {"role":"po_service_executor","procedure":"sp_fail_purchase_order_batch"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_batch"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_batch_by_source_hash"},
  {"role":"po_service_executor","procedure":"sp_claim_purchase_order_candidates"},
  {"role":"po_service_executor","procedure":"sp_renew_purchase_order_claim"},
  {"role":"po_service_executor","procedure":"sp_release_purchase_order_claim"},
  {"role":"po_service_executor","procedure":"sp_expire_purchase_order_claims"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_candidate"},
  {"role":"po_service_executor","procedure":"sp_begin_purchase_order_submission_attempt"},
  {"role":"po_service_executor","procedure":"sp_fail_purchase_order_candidate_pre_dispatch"},
  {"role":"po_service_executor","procedure":"sp_complete_purchase_order_submission"},
  {"role":"po_service_executor","procedure":"sp_fail_purchase_order_submission"},
  {"role":"po_service_executor","procedure":"sp_request_purchase_order_retry"},
  {"role":"po_service_executor","procedure":"sp_cancel_purchase_order_candidate"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_audit"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_batch_outcomes"},
  {"role":"po_service_executor","procedure":"sp_register_purchase_order_notification"},
  {"role":"po_service_executor","procedure":"sp_complete_purchase_order_notification"},
  {"role":"po_service_executor","procedure":"sp_enqueue_purchase_order_email_notification"},
  {"role":"po_service_executor","procedure":"sp_claim_purchase_order_email_notifications"},
  {"role":"po_service_executor","procedure":"sp_defer_purchase_order_email_notification"},
  {"role":"po_service_executor","procedure":"sp_reschedule_purchase_order_email_notification"},
  {"role":"po_service_executor","procedure":"sp_complete_purchase_order_email_notification"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_email_notification_queue_summary"},
  {"role":"po_service_executor","procedure":"sp_prepare_and_claim_relex_notification_events"},
  {"role":"po_service_executor","procedure":"sp_save_relex_notification_envelope"},
  {"role":"po_service_executor","procedure":"sp_complete_relex_notification_event"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_candidate_summary"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_batch_summary"},
  {"role":"po_service_executor","procedure":"sp_search_purchase_order_batches"},
  {"role":"po_service_executor","procedure":"sp_get_purchase_order_batch_candidate_summary"},
  {"role":"po_service_executor","procedure":"sp_search_purchase_order_batch_candidates"}
]';

IF SCHEMA_ID(N'po') IS NULL
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: schema po is missing.', 1;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.schemas
    WHERE [name] = N'po'
      AND [principal_id] = DATABASE_PRINCIPAL_ID(N'dbo')
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: schema po must be owned by dbo.', 1;
END;

IF OBJECT_ID(N'[po].[PurchaseOrderCandidateStatus]', N'U') IS NOT NULL
   OR OBJECT_ID(N'[po].[PurchaseOrderBatchStatus]', N'U') IS NOT NULL
   OR OBJECT_ID(N'[po].[PurchaseOrderAttemptStatus]', N'U') IS NOT NULL
   OR OBJECT_ID(N'[po].[PurchaseOrderNotificationStatus]', N'U') IS NOT NULL
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: legacy status lookup tables must not exist.', 1;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.objects AS wrapperObject
    INNER JOIN sys.schemas AS wrapperSchema
        ON wrapperSchema.[schema_id] = wrapperObject.[schema_id]
    WHERE wrapperObject.[object_id] = OBJECT_ID(N'[po].[sp_get_application_settings]', N'P')
      AND COALESCE(
          wrapperObject.[principal_id],
          wrapperSchema.[principal_id]) = DATABASE_PRINCIPAL_ID(N'dbo')
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: po.sp_get_application_settings must be effectively owned by dbo.', 1;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.sql_modules
    WHERE [object_id] = OBJECT_ID(N'[po].[sp_get_application_settings]', N'P')
      AND [execute_as_principal_id] IS NULL
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: po.sp_get_application_settings must use the caller context and same-owner chaining.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM OPENJSON(@expectedTables) AS expected
    WHERE OBJECT_ID(
        QUOTENAME(N'po') + N'.' + QUOTENAME(CONVERT(sysname, expected.[value])),
        N'U') IS NULL
)
OR
(
    SELECT COUNT_BIG(*)
    FROM sys.tables
    WHERE [schema_id] = SCHEMA_ID(N'po')
) <> (SELECT COUNT_BIG(*) FROM OPENJSON(@expectedTables))
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: table inventory is not exact.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM OPENJSON(@expectedNotificationColumns)
    WITH
    (
        [TableName] sysname '$.table',
        [ColumnName] sysname '$.column',
        [TypeDeclaration] nvarchar(128) '$.type',
        [IsNullable] bit '$.nullable',
        [IsIdentity] bit '$.identity'
    ) AS expected
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM sys.columns AS actualColumn
        INNER JOIN sys.tables AS actualTable
            ON actualTable.[object_id] = actualColumn.[object_id]
        INNER JOIN sys.types AS actualType
            ON actualType.[user_type_id] = actualColumn.[user_type_id]
        WHERE actualTable.[schema_id] = SCHEMA_ID(N'po')
          AND actualTable.[name] = expected.[TableName]
          AND actualColumn.[name] = expected.[ColumnName]
          AND actualType.[is_user_defined] = 0
          AND
          (
              CASE
                  WHEN actualType.[name] IN (N'varchar', N'char', N'binary', N'varbinary')
                      THEN actualType.[name] + N'(' +
                          CASE WHEN actualColumn.[max_length] = -1
                              THEN N'max'
                              ELSE CONVERT(nvarchar(10), actualColumn.[max_length])
                          END + N')'
                  WHEN actualType.[name] IN (N'nvarchar', N'nchar')
                      THEN actualType.[name] + N'(' +
                          CASE WHEN actualColumn.[max_length] = -1
                              THEN N'max'
                              ELSE CONVERT(nvarchar(10), actualColumn.[max_length] / 2)
                          END + N')'
                  WHEN actualType.[name] IN (N'datetimeoffset', N'datetime2', N'time')
                      THEN actualType.[name] + N'(' +
                          CONVERT(nvarchar(10), actualColumn.[scale]) + N')'
                  ELSE actualType.[name]
              END
          ) COLLATE Latin1_General_100_BIN2 =
              expected.[TypeDeclaration] COLLATE Latin1_General_100_BIN2
          AND actualColumn.[is_nullable] = expected.[IsNullable]
          AND actualColumn.[is_identity] = expected.[IsIdentity]
    )
)
OR
(
    SELECT COUNT_BIG(*)
    FROM sys.columns AS actualColumn
    INNER JOIN sys.tables AS actualTable
        ON actualTable.[object_id] = actualColumn.[object_id]
    WHERE actualTable.[schema_id] = SCHEMA_ID(N'po')
      AND actualTable.[name] IN
      (
          SELECT expectedTable.[TableName]
          FROM OPENJSON(@expectedNotificationColumns)
          WITH ([TableName] sysname '$.table') AS expectedTable
      )
) <> (SELECT COUNT_BIG(*) FROM OPENJSON(@expectedNotificationColumns))
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: notification column contract is not exact.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM (VALUES (N'CK_PO_RelexEvent_Status'), (N'CK_PO_RelexEvent_Identity'),
        (N'CK_PO_RelexEvent_Json'), (N'CK_PO_RelexEvent_State'),
        (N'CK_PO_RelexEvent_UtcDateTimes')) AS expected([Name])
    WHERE NOT EXISTS (SELECT 1 FROM sys.check_constraints AS actual
        WHERE actual.[parent_object_id] = OBJECT_ID(N'[po].[RelexNotificationEvent]')
            AND actual.[name] = expected.[Name] AND actual.[is_disabled] = 0 AND actual.[is_not_trusted] = 0)
)
OR NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE [parent_object_id] = OBJECT_ID(N'[po].[RelexNotificationEvent]')
        AND [referenced_object_id] = OBJECT_ID(N'[po].[PurchaseOrderBatch]')
        AND [name] = N'FK_PO_RelexEvent_Batch' AND [is_disabled] = 0 AND [is_not_trusted] = 0
)
OR NOT EXISTS
(
    SELECT 1 FROM sys.columns WHERE [object_id] = OBJECT_ID(N'[po].[RelexNotificationEvent]')
        AND [name] = N'EventKey' AND [collation_name] = N'Latin1_General_100_BIN2'
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: Relex event integrity constraints are missing or disabled.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM OPENJSON(@expectedProcedures) AS expected
    WHERE OBJECT_ID(
        QUOTENAME(N'po') + N'.' + QUOTENAME(CONVERT(sysname, expected.[value])),
        N'P') IS NULL
)
OR
(
    SELECT COUNT_BIG(*)
    FROM sys.procedures
    WHERE [schema_id] = SCHEMA_ID(N'po')
) <> (SELECT COUNT_BIG(*) FROM OPENJSON(@expectedProcedures))
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: procedure inventory is not exact.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM OPENJSON(@expectedIndexes)
    WITH
    (
        [TableName] sysname '$.table',
        [IndexName] sysname '$.index',
        [IndexType] nvarchar(60) '$.type',
        [IsUnique] bit '$.unique',
        [IsPrimaryKey] bit '$.primaryKey',
        [IsUniqueConstraint] bit '$.uniqueConstraint',
        [KeysJson] nvarchar(max) '$.keys' AS JSON,
        [IncludesJson] nvarchar(max) '$.includes' AS JSON,
        [FilterDefinition] nvarchar(4000) '$.filter'
    ) AS expected
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes AS [index]
        INNER JOIN sys.tables AS [table]
            ON [table].[object_id] = [index].[object_id]
        WHERE [table].[schema_id] = SCHEMA_ID(N'po')
          AND [table].[name] = expected.[TableName]
          AND [index].[name] = expected.[IndexName]
          AND [index].[is_disabled] = 0
          AND [index].[is_hypothetical] = 0
          AND [index].[type_desc] = expected.[IndexType]
          AND [index].[is_unique] = expected.[IsUnique]
          AND [index].[is_primary_key] = expected.[IsPrimaryKey]
          AND [index].[is_unique_constraint] = expected.[IsUniqueConstraint]
          AND COALESCE(
              UPPER(
                  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                      [index].[filter_definition],
                      N' ', N''),
                      NCHAR(9), N''),
                      NCHAR(10), N''),
                      NCHAR(13), N''),
                      N'[', N''),
                      N']', N''),
                      N'(', N''),
                      N')', N'')),
              N'') = COALESCE(
                  UPPER(
                      REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                          expected.[FilterDefinition],
                          N' ', N''),
                          NCHAR(9), N''),
                          NCHAR(10), N''),
                          NCHAR(13), N''),
                          N'[', N''),
                          N']', N''),
                          N'(', N''),
                          N')', N'')),
                  N'')
          AND
          (
              SELECT COUNT_BIG(*)
              FROM sys.index_columns AS keyColumnCount
              WHERE keyColumnCount.[object_id] = [index].[object_id]
                AND keyColumnCount.[index_id] = [index].[index_id]
                AND keyColumnCount.[key_ordinal] > 0
          ) = (SELECT COUNT_BIG(*) FROM OPENJSON(expected.[KeysJson]))
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS keyColumn
              INNER JOIN sys.columns AS keyColumnMetadata
                  ON keyColumnMetadata.[object_id] = keyColumn.[object_id]
                 AND keyColumnMetadata.[column_id] = keyColumn.[column_id]
              WHERE keyColumn.[object_id] = [index].[object_id]
                AND keyColumn.[index_id] = [index].[index_id]
                AND keyColumn.[key_ordinal] > 0
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM OPENJSON(expected.[KeysJson]) AS expectedKeyItem
                    CROSS APPLY OPENJSON(expectedKeyItem.[value])
                    WITH
                    (
                        [ColumnName] sysname '$.column',
                        [Descending] bit '$.descending'
                    ) AS expectedKey
                    WHERE keyColumnMetadata.[name] = expectedKey.[ColumnName]
                      AND keyColumn.[key_ordinal] = CONVERT(int, expectedKeyItem.[key]) + 1
                      AND keyColumn.[is_descending_key] = expectedKey.[Descending]
                )
          )
          AND
          (
              SELECT COUNT_BIG(*)
              FROM sys.index_columns AS includeColumnCount
              WHERE includeColumnCount.[object_id] = [index].[object_id]
                AND includeColumnCount.[index_id] = [index].[index_id]
                AND includeColumnCount.[is_included_column] = 1
          ) = (SELECT COUNT_BIG(*) FROM OPENJSON(expected.[IncludesJson]))
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS includeColumn
              INNER JOIN sys.columns AS includeColumnMetadata
                  ON includeColumnMetadata.[object_id] = includeColumn.[object_id]
                 AND includeColumnMetadata.[column_id] = includeColumn.[column_id]
              WHERE includeColumn.[object_id] = [index].[object_id]
                AND includeColumn.[index_id] = [index].[index_id]
                AND includeColumn.[is_included_column] = 1
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM OPENJSON(expected.[IncludesJson]) AS expectedInclude
                    WHERE includeColumnMetadata.[name] = CONVERT(sysname, expectedInclude.[value])
                )
          )
    )
)
OR
(
    SELECT COUNT_BIG(*)
    FROM sys.indexes AS [index]
    INNER JOIN sys.tables AS [table]
        ON [table].[object_id] = [index].[object_id]
    WHERE [table].[schema_id] = SCHEMA_ID(N'po')
      AND [index].[index_id] > 0
      AND [index].[name] IS NOT NULL
) <> (SELECT COUNT_BIG(*) FROM OPENJSON(@expectedIndexes))
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: named index inventory is not exact.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM OPENJSON(@expectedRoles) AS expected
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM sys.database_principals AS principal
        WHERE principal.[name] = CONVERT(sysname, expected.[value])
          AND principal.[type] = N'R'
          AND principal.[owning_principal_id] = DATABASE_PRINCIPAL_ID(N'dbo')
    )
)
OR
(
    SELECT COUNT_BIG(*)
    FROM sys.database_principals
    WHERE [type] = N'R'
      AND [name] LIKE N'po[_]%'
) <> (SELECT COUNT_BIG(*) FROM OPENJSON(@expectedRoles))
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: database role inventory is not exact.', 1;
END;

DECLARE @hasParentRoleMembership bit = 0;

;WITH [ParentRoleMembership] AS
(
    SELECT
        workloadRole.[principal_id] AS [WorkloadRolePrincipalId],
        roleMembership.[role_principal_id] AS [ParentRolePrincipalId]
    FROM OPENJSON(@expectedRoles) AS expectedRole
    INNER JOIN sys.database_principals AS workloadRole
        ON workloadRole.[name] = CONVERT(sysname, expectedRole.[value])
    INNER JOIN sys.database_role_members AS roleMembership
        ON roleMembership.[member_principal_id] = workloadRole.[principal_id]

    UNION ALL

    SELECT
        parentMembership.[WorkloadRolePrincipalId],
        roleMembership.[role_principal_id]
    FROM [ParentRoleMembership] AS parentMembership
    INNER JOIN sys.database_role_members AS roleMembership
        ON roleMembership.[member_principal_id] = parentMembership.[ParentRolePrincipalId]
)
SELECT TOP (1)
    @hasParentRoleMembership = 1
FROM [ParentRoleMembership]
OPTION (MAXRECURSION 32767);

IF @hasParentRoleMembership = 1
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: workload-role nesting is forbidden.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM OPENJSON(@expectedStatusConstraints)
    WITH
    (
        [TableName] sysname '$.table',
        [ConstraintName] sysname '$.constraint',
        [ColumnName] sysname '$.column',
        [Definition] nvarchar(4000) '$.definition'
    ) AS expected
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM sys.check_constraints AS statusConstraint
        INNER JOIN sys.tables AS statusTable
            ON statusTable.[object_id] = statusConstraint.[parent_object_id]
        WHERE statusTable.[schema_id] = SCHEMA_ID(N'po')
          AND statusTable.[name] = expected.[TableName]
          AND statusConstraint.[name] = expected.[ConstraintName]
          AND statusConstraint.[is_disabled] = 0
          AND statusConstraint.[is_not_trusted] = 0
          AND REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                  statusConstraint.[definition],
                  N' ', N''),
                  NCHAR(9), N''),
                  NCHAR(10), N''),
                  NCHAR(13), N''),
                  N'[', N''),
                  N']', N''),
                  N'(', N''),
                  N')', N'') COLLATE Latin1_General_100_BIN2
              = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                  expected.[Definition],
                  N' ', N''),
                  NCHAR(9), N''),
                  NCHAR(10), N''),
                  NCHAR(13), N''),
                  N'[', N''),
                  N']', N''),
                  N'(', N''),
                  N')', N'') COLLATE Latin1_General_100_BIN2
    )
)
OR
(
    SELECT COUNT_BIG(*)
    FROM sys.check_constraints AS statusConstraint
    INNER JOIN sys.tables AS statusTable
        ON statusTable.[object_id] = statusConstraint.[parent_object_id]
    WHERE statusTable.[schema_id] = SCHEMA_ID(N'po')
      AND EXISTS
      (
          SELECT 1
          FROM OPENJSON(@expectedStatusConstraints)
          WITH
          (
              [TableName] sysname '$.table',
              [ConstraintName] sysname '$.constraint',
              [ColumnName] sysname '$.column'
          ) AS expectedStatusColumn
          WHERE expectedStatusColumn.[TableName] = statusTable.[name]
            AND expectedStatusColumn.[ConstraintName] = statusConstraint.[name]
            AND CHARINDEX(
                N'[' + expectedStatusColumn.[ColumnName] + N']',
                statusConstraint.[definition]) > 0
      )
) <> (SELECT COUNT_BIG(*) FROM OPENJSON(@expectedStatusConstraints))
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: status CHECK constraint inventory is not exact, enabled, and trusted.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM OPENJSON(@expectedRoleProcedureGrants)
    WITH
    (
        [RoleName] sysname '$.role',
        [ProcedureName] sysname '$.procedure'
    ) AS expected
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM sys.database_permissions AS permission
        INNER JOIN sys.database_principals AS principal
            ON principal.[principal_id] = permission.[grantee_principal_id]
        INNER JOIN sys.objects AS procedureObject
            ON procedureObject.[object_id] = permission.[major_id]
        INNER JOIN sys.schemas AS procedureSchema
            ON procedureSchema.[schema_id] = procedureObject.[schema_id]
        WHERE permission.[class] = 1
          AND permission.[minor_id] = 0
          AND permission.[permission_name] = N'EXECUTE'
          AND permission.[state] = N'G'
          AND principal.[name] = expected.[RoleName]
          AND procedureSchema.[name] = N'po'
          AND procedureObject.[type] IN (N'P', N'PC')
          AND procedureObject.[name] = expected.[ProcedureName]
    )
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: an expected procedure grant is missing.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.database_permissions AS directPermission
    INNER JOIN sys.database_principals AS workloadRole
        ON workloadRole.[principal_id] = directPermission.[grantee_principal_id]
    WHERE EXISTS
    (
        SELECT 1
        FROM OPENJSON(@expectedRoles) AS expectedRole
        WHERE CONVERT(sysname, expectedRole.[value]) = workloadRole.[name]
    )
      AND NOT
      (
          directPermission.[class] = 1
          AND directPermission.[minor_id] = 0
          AND directPermission.[permission_name] = N'EXECUTE'
          AND directPermission.[state] = N'G'
          AND EXISTS
          (
              SELECT 1
              FROM sys.objects AS procedureObject
              INNER JOIN sys.schemas AS procedureSchema
                  ON procedureSchema.[schema_id] = procedureObject.[schema_id]
              WHERE procedureObject.[object_id] = directPermission.[major_id]
                AND procedureObject.[type] IN (N'P', N'PC')
                AND procedureSchema.[name] = N'po'
                AND EXISTS
                (
                    SELECT 1
                    FROM OPENJSON(@expectedRoleProcedureGrants)
                    WITH
                    (
                        [RoleName] sysname '$.role',
                        [ProcedureName] sysname '$.procedure'
                    ) AS expectedGrant
                    WHERE expectedGrant.[RoleName] = workloadRole.[name]
                      AND expectedGrant.[ProcedureName] = procedureObject.[name]
                )
          )
      )
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: a workload role has a permission outside the exact allowlist.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.database_permissions AS permission
    INNER JOIN sys.database_principals AS principal
        ON principal.[principal_id] = permission.[grantee_principal_id]
    INNER JOIN sys.objects AS procedureObject
        ON procedureObject.[object_id] = permission.[major_id]
    INNER JOIN sys.schemas AS procedureSchema
        ON procedureSchema.[schema_id] = procedureObject.[schema_id]
    WHERE permission.[class] = 1
      AND permission.[minor_id] = 0
      AND permission.[permission_name] = N'EXECUTE'
      AND permission.[state] IN (N'G', N'W')
      AND procedureSchema.[name] = N'po'
      AND procedureObject.[type] IN (N'P', N'PC')
      AND EXISTS
      (
          SELECT 1
          FROM OPENJSON(@expectedRoles) AS expectedRole
          WHERE CONVERT(sysname, expectedRole.[value]) = principal.[name]
      )
      AND NOT EXISTS
      (
          SELECT 1
          FROM OPENJSON(@expectedRoleProcedureGrants)
          WITH
          (
              [RoleName] sysname '$.role',
              [ProcedureName] sysname '$.procedure'
          ) AS expectedGrant
          WHERE expectedGrant.[RoleName] = principal.[name]
            AND expectedGrant.[ProcedureName] = procedureObject.[name]
      )
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: an extra procedure grant exists.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.database_permissions AS permission
    INNER JOIN sys.database_principals AS principal
        ON principal.[principal_id] = permission.[grantee_principal_id]
    WHERE permission.[permission_name] = N'EXECUTE'
      AND permission.[state] IN (N'G', N'W')
      AND permission.[class] IN (0, 3)
      AND EXISTS
      (
          SELECT 1
          FROM OPENJSON(@expectedRoles) AS expectedRole
          WHERE CONVERT(sysname, expectedRole.[value]) = principal.[name]
      )
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: database or schema EXECUTE is forbidden.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.database_permissions AS permission
    INNER JOIN sys.database_principals AS principal
        ON principal.[principal_id] = permission.[grantee_principal_id]
    WHERE permission.[permission_name] IN (N'SELECT', N'INSERT', N'UPDATE', N'DELETE')
      AND permission.[state] IN (N'G', N'W')
      AND EXISTS
      (
          SELECT 1
          FROM OPENJSON(@expectedRoles) AS expectedRole
          WHERE CONVERT(sysname, expectedRole.[value]) = principal.[name]
      )
      AND
      (
          permission.[class] IN (0, 3)
          OR
          (
              permission.[class] = 1
              AND EXISTS
              (
                  SELECT 1
                  FROM sys.objects AS tableObject
                  WHERE tableObject.[object_id] = permission.[major_id]
                    AND tableObject.[schema_id] = SCHEMA_ID(N'po')
                    AND tableObject.[type] = N'U'
              )
          )
      )
)
BEGIN
    ;THROW 51000, 'Purchase Order verification failed: direct workload-role table DML is forbidden.', 1;
END;
