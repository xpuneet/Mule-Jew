CREATE OR ALTER PROCEDURE [po].[sp_register_purchase_order_batch]
    @batchId uniqueidentifier,
    @originalFileName nvarchar(260),
    @sourceFilePath nvarchar(512),
    @fileContentLength bigint,
    @fileSha256 binary(32),
    @expectedRowCount int = NULL,
    @discoveredDateTime datetimeoffset(3),
    @actor nvarchar(256)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    IF @originalFileName IS NULL
       OR NULLIF(LTRIM(RTRIM(@originalFileName)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The original file name is required.', 1;
    END;

    IF @sourceFilePath IS NULL
       OR NULLIF(LTRIM(RTRIM(@sourceFilePath)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The source file path is required.', 1;
    END;

    IF @fileContentLength IS NULL OR @fileContentLength < 0
    BEGIN
        ;THROW 51004, 'The file content length cannot be negative.', 1;
    END;

    IF @fileSha256 IS NULL
    BEGIN
        ;THROW 51004, 'The file SHA-256 hash is required.', 1;
    END;

    IF @expectedRowCount IS NOT NULL AND @expectedRowCount < 0
    BEGIN
        ;THROW 51004, 'The expected row count cannot be negative.', 1;
    END;

    IF @discoveredDateTime IS NULL
       OR DATEPART(TZOFFSET, @discoveredDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The discovered timestamp must use the UTC offset.', 1;
    END;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    DECLARE @registeredBatch TABLE
    (
        [BatchId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        IF EXISTS
        (
            SELECT 1
            FROM [po].[PurchaseOrderBatch] WITH (UPDLOCK, HOLDLOCK)
            WHERE [Source] = N'Relex'
              AND [FileSha256] = @fileSha256
        )
        BEGIN
            ;THROW 51005, 'The source file has already been registered.', 1;
        END;

        INSERT INTO [po].[PurchaseOrderBatch]
        (
            [BatchId],
            [Source],
            [OriginalFileName],
            [SourceFilePath],
            [FileContentLength],
            [FileSha256],
            [Status],
            [ExpectedRowCount],
            [ParsedRowCount],
            [CandidateCount],
            [FailureCode],
            [FailureDescription],
            [DiscoveredDateTime],
            [IngestionStartedDateTime],
            [CompletedDateTime],
            [CreatedBy],
            [UpdatedDateTime]
        )
        OUTPUT
            inserted.[BatchId],
            inserted.[Status],
            inserted.[RowVersion]
        INTO @registeredBatch
        VALUES
        (
            @batchId,
            N'Relex',
            @originalFileName,
            @sourceFilePath,
            @fileContentLength,
            @fileSha256,
            'INGESTING',
            @expectedRowCount,
            0,
            0,
            NULL,
            NULL,
            @discoveredDateTime,
            @discoveredDateTime,
            NULL,
            @actor,
            @discoveredDateTime
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        DECLARE @errorNumber int = ERROR_NUMBER();
        DECLARE @isDuplicateSourceFile bit = 0;

        IF @errorNumber IN (2601, 2627)
           AND XACT_STATE() <> 0
        BEGIN
            IF EXISTS
            (
                SELECT 1
                FROM [po].[PurchaseOrderBatch]
                WHERE [Source] = N'Relex'
                  AND [FileSha256] = @fileSha256
            )
            BEGIN
                SET @isDuplicateSourceFile = 1;
            END;
        END;

        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        IF @isDuplicateSourceFile = 1
        BEGIN
            ;THROW 51005, 'The source file has already been registered.', 1;
        END;

        THROW;
    END CATCH;

    SELECT
        [BatchId],
        [Status],
        [RowVersion]
    FROM @registeredBatch;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_add_purchase_order_candidate_to_batch]
    @batchId uniqueidentifier,
    @candidateId uniqueidentifier,
    @account nvarchar(50),
    @branch nvarchar(20),
    @reference nvarchar(100) = NULL,
    @sourceRowCount int,
    @acceptedDateTime datetimeoffset(3),
    @payloadJson nvarchar(max),
    @actor nvarchar(256)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    IF @candidateId IS NULL
    BEGIN
        ;THROW 51004, 'The candidate identifier is required.', 1;
    END;

    IF @account IS NULL
       OR NULLIF(LTRIM(RTRIM(@account)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The account is required.', 1;
    END;

    IF @branch IS NULL
       OR NULLIF(LTRIM(RTRIM(@branch)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The branch is required.', 1;
    END;

    IF @sourceRowCount IS NULL OR @sourceRowCount <= 0
    BEGIN
        ;THROW 51004, 'The source row count must be positive.', 1;
    END;

    IF @acceptedDateTime IS NULL
       OR DATEPART(TZOFFSET, @acceptedDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The accepted timestamp must use the UTC offset.', 1;
    END;

    IF @payloadJson IS NULL
       OR ISJSON(@payloadJson, OBJECT) <> 1
    BEGIN
        ;THROW 51004, 'The payload must be a JSON object.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM OPENJSON(@payloadJson) AS jsonProperty
        WHERE jsonProperty.[key] COLLATE Latin1_General_100_BIN2 = N'candidateStatus'
    )
    BEGIN
        ;THROW 51004, 'The payload must not contain candidateStatus.', 1;
    END;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    DECLARE @batchKey bigint;
    DECLARE @batchSource nvarchar(50);
    DECLARE @batchStatus varchar(50);
    DECLARE @candidateKey bigint;
    DECLARE @existingBatchKey bigint;
    DECLARE @existingReference nvarchar(100);
    DECLARE @existingPayloadJson nvarchar(max);
    DECLARE @existingSourceRowCount int;

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT
            @batchKey = [BatchKey],
            @batchSource = [Source],
            @batchStatus = [Status]
        FROM [po].[PurchaseOrderBatch] WITH (UPDLOCK, HOLDLOCK)
        WHERE [BatchId] = @batchId;

        IF @batchKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order batch was not found.', 1;
        END;

        IF @batchStatus <> 'INGESTING'
        BEGIN
            ;THROW 51004, 'Candidates can only be added to an ingesting batch.', 1;
        END;

        IF @batchSource <> N'Relex'
        BEGIN
            ;THROW 51006, 'The batch source is not Relex.', 1;
        END;

        SELECT
            @existingBatchKey = [BatchKey],
            @existingReference = [Reference],
            @existingPayloadJson = [PayloadJson],
            @existingSourceRowCount = [SourceRowCount]
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [CandidateId] = @candidateId;

        IF @existingBatchKey IS NOT NULL
        BEGIN
            IF @existingBatchKey = @batchKey
               AND ISNULL(@existingReference, N'') = ISNULL(@reference, N'')
               AND @existingPayloadJson = @payloadJson
               AND @existingSourceRowCount = @sourceRowCount
            BEGIN
                COMMIT TRANSACTION;
                RETURN;
            END;

            ;THROW 51006, 'The candidate replay does not match the stored candidate.', 1;
        END;

        INSERT INTO [po].[PurchaseOrderCandidate]
        (
            [CandidateId],
            [BatchKey],
            [Source],
            [Kind],
            [SourceRowCount],
            [Account],
            [Branch],
            [Reference],
            [IconPurchaseOrderNumber],
            [Status],
            [StatusDateTime],
            [StatusReason],
            [ProcessBatchNo],
            [PayloadMD5],
            [MessageCode],
            [MessageDescription],
            [PreviousMessageCode],
            [PreviousMessageDescription],
            [PayloadJson],
            [AcceptedDateTime],
            [CreatedDateTime],
            [UpdatedDateTime],
            [RefreshDateTime],
            [PendingRetriesCount],
            [ProcessingRetriesCount],
            [LeaseToken],
            [LeaseOwner],
            [LeaseAcquiredDateTime],
            [LeaseExpiresDateTime]
        )
        VALUES
        (
            @candidateId,
            @batchKey,
            N'Relex',
            'RELEX',
            @sourceRowCount,
            @account,
            @branch,
            @reference,
            NULL,
            'DRAFT',
            @acceptedDateTime,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            @payloadJson,
            @acceptedDateTime,
            @acceptedDateTime,
            @acceptedDateTime,
            @acceptedDateTime,
            0,
            0,
            NULL,
            NULL,
            NULL,
            NULL
        );

        SET @candidateKey = CONVERT(bigint, SCOPE_IDENTITY());

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        VALUES
        (
            @candidateKey,
            'CREATE',
            'INGESTION',
            @actor,
            NULL,
            NULL,
            'DRAFT',
            NULL,
            @payloadJson,
            NULL,
            @batchId,
            @acceptedDateTime
        );

        UPDATE [po].[PurchaseOrderBatch]
        SET
            [CandidateCount] = [CandidateCount] + 1,
            [ParsedRowCount] = [ParsedRowCount] + @sourceRowCount,
            [UpdatedDateTime] = @acceptedDateTime
        WHERE [BatchKey] = @batchKey;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_complete_purchase_order_batch]
    @batchId uniqueidentifier,
    @expectedCandidateCount int,
    @parsedRowCount int,
    @completedDateTime datetimeoffset(3),
    @actor nvarchar(256),
    @expectedBatchRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    IF @completedDateTime IS NULL
       OR DATEPART(TZOFFSET, @completedDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The completed timestamp must use the UTC offset.', 1;
    END;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    IF @expectedBatchRowVersion IS NULL
    BEGIN
        ;THROW 51006, 'The expected batch rowversion is required.', 1;
    END;

    IF @expectedCandidateCount IS NULL
       OR @parsedRowCount IS NULL
       OR @expectedCandidateCount < 0
       OR @parsedRowCount < 0
    BEGIN
        ;THROW 51006, 'The completion counts cannot be negative or null.', 1;
    END;

    DECLARE @batchKey bigint;
    DECLARE @batchStatus varchar(50);
    DECLARE @batchRowVersion binary(8);
    DECLARE @actualCandidateCount bigint;
    DECLARE @draftCandidateCount bigint;
    DECLARE @actualSourceRowCount bigint;
    DECLARE @promotedCandidateCount int;
    DECLARE @promotedCandidates TABLE
    (
        [CandidateKey] bigint NOT NULL PRIMARY KEY
    );
    DECLARE @completedBatch TABLE
    (
        [BatchId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [PromotedCandidateCount] int NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT
            @batchKey = [BatchKey],
            @batchStatus = [Status],
            @batchRowVersion = [RowVersion]
        FROM [po].[PurchaseOrderBatch] WITH (UPDLOCK, HOLDLOCK)
        WHERE [BatchId] = @batchId;

        IF @batchKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order batch was not found.', 1;
        END;

        IF @batchStatus <> 'INGESTING'
        BEGIN
            ;THROW 51004, 'Only an ingesting batch can be completed.', 1;
        END;

        IF @batchRowVersion <> @expectedBatchRowVersion
        BEGIN
            ;THROW 51006, 'The batch rowversion does not match.', 1;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM [po].[PurchaseOrderBatch]
            WHERE [BatchKey] = @batchKey
              AND
              (
                  [CandidateCount] <> @expectedCandidateCount
                  OR [ParsedRowCount] <> @parsedRowCount
                  OR ([ExpectedRowCount] IS NOT NULL
                      AND [ExpectedRowCount] <> @parsedRowCount)
              )
        )
        BEGIN
            ;THROW 51006, 'The batch counts do not match.', 1;
        END;

        SELECT
            @actualCandidateCount = COUNT_BIG(*),
            @draftCandidateCount = COALESCE(
                SUM(CASE WHEN [Status] = 'DRAFT' THEN CONVERT(bigint, 1) ELSE 0 END),
                0),
            @actualSourceRowCount = COALESCE(
                SUM(CONVERT(bigint, [SourceRowCount])),
                0)
        FROM [po].[PurchaseOrderCandidate] WITH (UPDLOCK, HOLDLOCK)
        WHERE [BatchKey] = @batchKey;

        IF @actualCandidateCount <> @expectedCandidateCount
           OR @draftCandidateCount <> @expectedCandidateCount
           OR @actualSourceRowCount <> @parsedRowCount
        BEGIN
            ;THROW 51006, 'The batch candidates are incomplete or not all in draft status.', 1;
        END;

        UPDATE candidate
        SET
            [Status] = 'READY_FOR_SUBMISSION',
            [StatusDateTime] = @completedDateTime,
            [StatusReason] = NULL,
            [UpdatedDateTime] = @completedDateTime,
            [RefreshDateTime] = @completedDateTime
        OUTPUT inserted.[CandidateKey]
        INTO @promotedCandidates
        FROM [po].[PurchaseOrderCandidate] AS candidate
        WHERE [BatchKey] = @batchKey
          AND [Status] = 'DRAFT';

        SET @promotedCandidateCount = @@ROWCOUNT;

        IF @promotedCandidateCount <> @expectedCandidateCount
        BEGIN
            ;THROW 51006, 'The promoted candidate count does not match.', 1;
        END;

        INSERT INTO [po].[PurchaseOrderAudit]
        (
            [CandidateKey],
            [Action],
            [Method],
            [Actor],
            [Reason],
            [PreviousStatus],
            [CurrentStatus],
            [PreviousPayloadJson],
            [CurrentPayloadJson],
            [BusinessPayloadHash],
            [CorrelationId],
            [ChangedDateTime]
        )
        SELECT
            promoted.[CandidateKey],
            'BATCH_PROMOTION',
            'INGESTION',
            @actor,
            NULL,
            'DRAFT',
            'READY_FOR_SUBMISSION',
            NULL,
            NULL,
            NULL,
            @batchId,
            @completedDateTime
        FROM @promotedCandidates AS promoted;

        UPDATE [po].[PurchaseOrderBatch]
        SET
            [Status] = 'COMPLETED',
            [FailureCode] = NULL,
            [FailureDescription] = NULL,
            [CompletedDateTime] = @completedDateTime,
            [UpdatedDateTime] = @completedDateTime
        OUTPUT
            inserted.[BatchId],
            inserted.[Status],
            @promotedCandidateCount,
            inserted.[RowVersion]
        INTO @completedBatch
        WHERE [BatchKey] = @batchKey;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [BatchId],
        [Status],
        [PromotedCandidateCount],
        [RowVersion]
    FROM @completedBatch;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_fail_purchase_order_batch]
    @batchId uniqueidentifier,
    @failureCode varchar(100),
    @failureDescription nvarchar(1000),
    @failedDateTime datetimeoffset(3),
    @actor nvarchar(256),
    @expectedBatchRowVersion binary(8)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    IF @failureCode IS NULL
       OR NULLIF(LTRIM(RTRIM(@failureCode)), '') IS NULL
    BEGIN
        ;THROW 51004, 'The failure code is required.', 1;
    END;

    IF @failureDescription IS NULL
       OR NULLIF(LTRIM(RTRIM(@failureDescription)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The failure description is required.', 1;
    END;

    IF @failedDateTime IS NULL
       OR DATEPART(TZOFFSET, @failedDateTime) <> 0
    BEGIN
        ;THROW 51004, 'The failed timestamp must use the UTC offset.', 1;
    END;

    IF @actor IS NULL
       OR NULLIF(LTRIM(RTRIM(@actor)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The actor is required.', 1;
    END;

    IF @expectedBatchRowVersion IS NULL
    BEGIN
        ;THROW 51004, 'The expected batch rowversion is required.', 1;
    END;

    DECLARE @batchKey bigint;
    DECLARE @batchStatus varchar(50);
    DECLARE @batchRowVersion binary(8);
    DECLARE @failedBatch TABLE
    (
        [BatchId] uniqueidentifier NOT NULL,
        [Status] varchar(50) NOT NULL,
        [RowVersion] binary(8) NOT NULL
    );

    BEGIN TRY
        BEGIN TRANSACTION;

        SELECT
            @batchKey = [BatchKey],
            @batchStatus = [Status],
            @batchRowVersion = [RowVersion]
        FROM [po].[PurchaseOrderBatch] WITH (UPDLOCK, HOLDLOCK)
        WHERE [BatchId] = @batchId;

        IF @batchKey IS NULL
        BEGIN
            ;THROW 51001, 'The purchase order batch was not found.', 1;
        END;

        IF @batchStatus <> 'INGESTING'
        BEGIN
            ;THROW 51004, 'Only an ingesting batch can be failed.', 1;
        END;

        IF @batchRowVersion <> @expectedBatchRowVersion
        BEGIN
            ;THROW 51002, 'The batch rowversion does not match.', 1;
        END;

        UPDATE [po].[PurchaseOrderBatch]
        SET
            [Status] = 'FAILED',
            [FailureCode] = @failureCode,
            [FailureDescription] = @failureDescription,
            [CompletedDateTime] = @failedDateTime,
            [UpdatedDateTime] = @failedDateTime
        OUTPUT
            inserted.[BatchId],
            inserted.[Status],
            inserted.[RowVersion]
        INTO @failedBatch
        WHERE [BatchKey] = @batchKey;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        THROW;
    END CATCH;

    SELECT
        [BatchId],
        [Status],
        [RowVersion]
    FROM @failedBatch;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_batch]
    @batchId uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;

    IF @batchId IS NULL
    BEGIN
        ;THROW 51004, 'The batch identifier is required.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderBatch]
        WHERE [BatchId] = @batchId
    )
    BEGIN
        ;THROW 51001, 'The purchase order batch was not found.', 1;
    END;

    SELECT
        [BatchId],
        [Source],
        [OriginalFileName],
        [SourceFilePath],
        [FileContentLength],
        [FileSha256],
        [Status],
        [ExpectedRowCount],
        [ParsedRowCount],
        [CandidateCount],
        [FailureCode],
        [FailureDescription],
        [DiscoveredDateTime],
        [IngestionStartedDateTime],
        [CompletedDateTime],
        [CreatedBy],
        [UpdatedDateTime],
        [RowVersion]
    FROM [po].[PurchaseOrderBatch]
    WHERE [BatchId] = @batchId;
END;
GO

CREATE OR ALTER PROCEDURE [po].[sp_get_purchase_order_batch_by_source_hash]
    @source nvarchar(50),
    @fileSha256 binary(32)
AS
BEGIN
    SET NOCOUNT ON;

    IF @source IS NULL
       OR NULLIF(LTRIM(RTRIM(@source)), N'') IS NULL
    BEGIN
        ;THROW 51004, 'The source is required.', 1;
    END;

    IF @fileSha256 IS NULL
    BEGIN
        ;THROW 51004, 'The file SHA-256 hash is required.', 1;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [po].[PurchaseOrderBatch]
        WHERE [Source] = @source
          AND [FileSha256] = @fileSha256
    )
    BEGIN
        ;THROW 51001, 'The purchase order batch was not found.', 1;
    END;

    SELECT
        [BatchId],
        [Source],
        [OriginalFileName],
        [SourceFilePath],
        [FileContentLength],
        [FileSha256],
        [Status],
        [ExpectedRowCount],
        [ParsedRowCount],
        [CandidateCount],
        [FailureCode],
        [FailureDescription],
        [DiscoveredDateTime],
        [IngestionStartedDateTime],
        [CompletedDateTime],
        [CreatedBy],
        [UpdatedDateTime],
        [RowVersion]
    FROM [po].[PurchaseOrderBatch]
    WHERE [Source] = @source
      AND [FileSha256] = @fileSha256;
END;
GO
