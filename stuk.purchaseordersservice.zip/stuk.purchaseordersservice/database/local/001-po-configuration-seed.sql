SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @settings TABLE
(
    [Context] nvarchar(100) NOT NULL,
    [Key] nvarchar(256) NOT NULL,
    [Value] nvarchar(max) NOT NULL,
    PRIMARY KEY ([Context], [Key])
);

INSERT INTO @settings ([Context], [Key], [Value])
VALUES
    (N'Common', N'CommonSettings:ServiceName', N'PurchaseOrderService'),
    (N'WebApi', N'WebApiSettings:AllowedSources', N'["API","Relex"]'),
    (N'WebApi', N'WebApiSettings:ApiCreateUser', N'APIMIN_User'),
    (N'WebApi', N'WebApiSettings:PurchaseOrdersMaxPageSize', N'50');

UPDATE target
SET target.[Value] = source.[Value]
FROM [po].[ApplicationSetting] AS target
INNER JOIN @settings AS source
    ON source.[Context] = target.[Context]
   AND source.[Key] = target.[Key]
WHERE target.[Value] <> source.[Value];

INSERT INTO [po].[ApplicationSetting] ([Context], [Key], [Value])
SELECT source.[Context], source.[Key], source.[Value]
FROM @settings AS source
WHERE NOT EXISTS
(
    SELECT 1
    FROM [po].[ApplicationSetting] AS target
    WHERE target.[Context] = source.[Context]
      AND target.[Key] = source.[Key]
);
GO
