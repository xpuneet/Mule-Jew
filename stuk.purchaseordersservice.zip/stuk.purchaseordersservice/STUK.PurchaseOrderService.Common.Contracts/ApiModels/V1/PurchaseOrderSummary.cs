namespace STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;

/// <summary>
/// Search projection for one persisted purchase order candidate.
/// </summary>
public sealed class PurchaseOrderSummary
{
    /// <summary>
    /// Service-generated identifier used to track the candidate.
    /// </summary>
    /// <example>00000000-0000-0000-0000-000000000001</example>
    public Guid CandidateId { get; init; }

    /// <summary>
    /// Ingestion source recorded by the service.
    /// </summary>
    /// <example>API</example>
    public string Source { get; init; } = string.Empty;

    /// <summary>
    /// Supplier account identifier.
    /// </summary>
    /// <example>BRIT186</example>
    public string Account { get; init; } = string.Empty;

    /// <summary>
    /// Branch or location identifier.
    /// </summary>
    /// <example>385</example>
    public string Branch { get; init; } = string.Empty;

    /// <summary>
    /// External purchase order reference, when supplied.
    /// </summary>
    /// <example>20211108</example>
    public string? Reference { get; init; }

    /// <summary>
    /// Purchase order number returned by ICON, when processing has produced one.
    /// </summary>
    /// <example>PO123456</example>
    public string? IconPurchaseOrderNumber { get; init; }

    /// <summary>
    /// Current canonical candidate status.
    /// </summary>
    /// <example>READY_FOR_SUBMISSION</example>
    public string Status { get; init; } = string.Empty;

    /// <summary>
    /// UTC timestamp at which the service persisted the candidate.
    /// </summary>
    /// <example>2026-09-15T10:30:00Z</example>
    public DateTimeOffset AcceptedDateTime { get; init; }
}
