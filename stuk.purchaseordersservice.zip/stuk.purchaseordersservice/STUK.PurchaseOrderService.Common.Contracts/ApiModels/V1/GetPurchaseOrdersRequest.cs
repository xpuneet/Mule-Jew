namespace STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;

/// <summary>
/// Filters and pagination for persisted purchase order candidates.
/// </summary>
public sealed class GetPurchaseOrdersRequest
{
    /// <summary>
    /// Required ingestion source. The value must be present in the environment's configured allowed-source list.
    /// </summary>
    /// <example>API</example>
    public string? Source { get; init; }

    /// <summary>
    /// Supplier account identifier.
    /// </summary>
    /// <example>BRIT186</example>
    public string? Account { get; init; }

    /// <summary>
    /// Branch or location identifier stored with the candidate.
    /// </summary>
    /// <example>385</example>
    public string? Branch { get; init; }

    /// <summary>
    /// External purchase order reference supplied in the canonical header.
    /// </summary>
    /// <example>20211108</example>
    public string? Reference { get; init; }

    /// <summary>
    /// Purchase order number returned by ICON after successful processing.
    /// </summary>
    /// <example>PO123456</example>
    public string? IconPurchaseOrderNumber { get; init; }

    /// <summary>
    /// Canonical candidate status: DRAFT, READY_FOR_SUBMISSION, SUBMISSION_IN_PROGRESS,
    /// RECOVERABLE_ERROR, NON_RECOVERABLE_ERROR, RETRY_REQUESTED, COMPLETED, or CANCELLED.
    /// </summary>
    /// <example>READY_FOR_SUBMISSION</example>
    public string? Status { get; init; }

    /// <summary>
    /// One-based page number. Values below 1 are rejected.
    /// </summary>
    /// <example>1</example>
    public int PageNumber { get; init; } = 1;

    /// <summary>
    /// Requested records per page. The value must be at least 1 and no greater than the configured maximum,
    /// which is capped at 50.
    /// </summary>
    /// <example>25</example>
    public int PageSize { get; init; } = 50;
}
