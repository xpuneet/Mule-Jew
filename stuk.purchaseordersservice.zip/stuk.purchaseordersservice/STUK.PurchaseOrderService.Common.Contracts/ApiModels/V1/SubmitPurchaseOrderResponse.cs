using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;

/// <summary>
/// Acceptance details for a persisted purchase order candidate.
/// </summary>
public sealed class SubmitPurchaseOrderResponse
{
    /// <summary>
    /// Service-generated identifier used to track the candidate.
    /// </summary>
    /// <example>00000000-0000-0000-0000-000000000001</example>
    public Guid CandidateId { get; init; }

    /// <summary>
    /// Initial processing status. Acceptance normally returns READY_FOR_SUBMISSION and does not mean ICON has
    /// created the purchase order.
    /// </summary>
    /// <example>READY_FOR_SUBMISSION</example>
    public PurchaseOrderCandidateStatus Status { get; init; }

    /// <summary>
    /// UTC timestamp at which the service persisted the candidate.
    /// </summary>
    /// <example>2026-09-15T10:30:00Z</example>
    public DateTimeOffset AcceptedDateTime { get; init; }

    /// <summary>
    /// Human-readable acceptance message.
    /// </summary>
    /// <example>Purchase order accepted for asynchronous processing.</example>
    public string Message { get; init; } = string.Empty;
}
