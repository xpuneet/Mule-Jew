namespace STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;

/// <summary>
/// One bounded page of persisted purchase order candidates.
/// </summary>
public sealed class PurchaseOrderSearchResponse
{
    /// <summary>
    /// Candidates matching every supplied filter.
    /// </summary>
    public IReadOnlyCollection<PurchaseOrderSummary> Orders { get; init; } = [];

    /// <summary>
    /// One-based page number returned by the search.
    /// </summary>
    /// <example>1</example>
    public int PageNumber { get; init; }

    /// <summary>
    /// Number of records requested for this page.
    /// </summary>
    /// <example>25</example>
    public int PageSize { get; init; }
}
