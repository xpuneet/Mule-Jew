using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public sealed class WebApiSettings
{
    public List<string> AllowedSources { get; init; } =
        [PurchaseOrderSources.Api, PurchaseOrderSources.Relex];

    public string ApiCreateUser { get; init; } = string.Empty;

    public int PurchaseOrdersMaxPageSize { get; init; } = 50;
}
