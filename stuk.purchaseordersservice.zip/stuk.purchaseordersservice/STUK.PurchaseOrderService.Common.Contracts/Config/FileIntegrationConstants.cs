namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public static class FileIntegrationConstants
{
    public const string ServiceName = "PurchaseOrderService";
    public const string IconToRelexTimerTriggerName = "IconToRelexTimerTrigger";
    public const string IconToRelexSchedulerName = "icon-to-relex-scheduler";
    public const string SourceSystemIcon = "ICON";
    public const string SourceSystemStaging = "Azure Storage";

}
