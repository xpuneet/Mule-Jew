namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public sealed class RelexNotificationSettings
{
    public const string SectionName = "RelexNotifications";

    public bool ResultsEnabled { get; set; }
    public bool MissingProposalEnabled { get; set; }
    public string EnvironmentName { get; set; } = string.Empty;
    public string Recipients { get; set; } = string.Empty;
    public DateTimeOffset? ResultsNotBeforeUtc { get; set; }
    public string TimeZoneId { get; set; } = "Europe/London";
    public string MissingProposalCutoffLocalTime { get; set; } = "10:30";
    public string MissingProposalDays { get; set; } = "Monday,Tuesday,Wednesday,Thursday,Friday,Saturday";
    public int MissingProposalLookbackHours { get; set; } = 6;
    public int MissingProposalCatchUpMinutes { get; set; } = 60;
    public int MaxEventsPerRun { get; set; } = 10;
    public int LeaseDurationSeconds { get; set; } = 120;
    public int MaxRunDurationSeconds { get; set; } = 50;
    public int OutcomePersistenceTimeoutSeconds { get; set; } = 10;
    public int RetryDelaySeconds { get; set; } = 60;
    public int MaxFailureCount { get; set; } = 8;
    public string CronExpression { get; set; } = "0 * * * * *";

    public string[] GetRecipients() => (Recipients ?? string.Empty)
        .Split([',', ';'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .ToArray();
}
