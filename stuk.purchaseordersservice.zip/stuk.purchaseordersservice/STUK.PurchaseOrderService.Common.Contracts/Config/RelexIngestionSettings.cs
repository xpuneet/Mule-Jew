namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public enum RelexFileStoreProvider
{
    Local,
    Sftp
}

public sealed record RelexIngestionSettings
{
    public const string SectionName = nameof(RelexIngestionSettings);

    public RelexFileStoreProvider Provider { get; init; } = RelexFileStoreProvider.Sftp;

    public string InputPath { get; init; } = "/data/input";

    public string ArchivePath { get; init; } = "/data/output/archive";

    public string ErrorPath { get; init; } = "/data/output/error";

    public string FilePattern { get; init; } = "SG_OrderProposal*.csv";

    public int MinimumFileAgeSeconds { get; init; } = 120;

    public string Actor { get; init; } = "RelexIngestionFunction";

    public string? LocalRootPath { get; init; }

    public string? SftpHost { get; init; }

    public int SftpPort { get; init; } = 22;

    public string? SftpUsername { get; init; }

    public string? SftpPassword { get; init; }

    public int OperationTimeoutSeconds { get; init; } = 60;
}
