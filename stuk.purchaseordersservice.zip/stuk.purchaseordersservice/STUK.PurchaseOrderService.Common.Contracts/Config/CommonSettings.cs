namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public sealed class CommonSettings
{
    public string ServiceName { get; init; } = "PurchaseOrderService";
}
