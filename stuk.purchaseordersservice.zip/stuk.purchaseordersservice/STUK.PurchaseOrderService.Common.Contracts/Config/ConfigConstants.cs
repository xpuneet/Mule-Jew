namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public static class ConfigConstants
{
    public const string AzureKeyVaultUriSettingKey = "AzureKeyVaultUri";
    public const string PurchaseOrdersDbConnectionStringName = "PurchaseOrdersServiceDB";
    public const string DatabaseConfigurationRefreshInterval = "DatabaseConfigurationRefreshInterval";
    public const string EmailNotificationSenderCronExpressionSettingKey =
        "EmailNotificationSenderCronExpression";
    public const string RelexNotificationProducerCronExpressionSettingKey =
        "RelexNotificationProducerCronExpression";

    public const string DatabaseAppSettingCommonContext = "Common";
    public const string DatabaseAppSettingWebApiContext = "WebApi";
    public const string DatabaseAppSettingBatchProcessorContext = "BatchProcessor";
    public const string DatabaseAppSettingWebAppContext = "WebApp";
}
