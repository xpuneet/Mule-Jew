namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public sealed class BatchProcessorSettings
{
    public string ReadyCandidatesProcessorCronExpression { get; init; } = "0 */5 * * * *";

    public int MaxConcurrentSubmissions { get; init; } = 4;

    public bool SubmissionEnabled { get; init; }

    public int LeaseDurationSeconds { get; init; } = 120;

    public int OutcomePersistenceTimeoutSeconds { get; init; } = 15;
}
