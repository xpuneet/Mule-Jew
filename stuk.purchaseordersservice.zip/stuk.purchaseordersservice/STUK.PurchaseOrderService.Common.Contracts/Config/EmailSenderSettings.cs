namespace STUK.PurchaseOrderService.Common.Contracts.Config;

public sealed record EmailSenderSettings
{
    public const string SectionName = "EmailSender";

    public bool SendingEnabled { get; init; }
    public EmailSmtpSettings Smtp { get; init; } = new();
    public string DefaultSenderAddress { get; init; } = string.Empty;
    public int ClaimBatchSize { get; init; } = 10;
    public int MaxConcurrency { get; init; } = 4;
    public int LeaseDurationSeconds { get; init; } = 120;
    public int MaxRunDurationSeconds { get; init; } = 50;
    public int ProviderOperationTimeoutSeconds { get; init; } = 30;
    public int CompletionSafetyMarginSeconds { get; init; } = 10;
    public int OutcomePersistenceTimeoutSeconds { get; init; } = 10;
    public int MaxFailureCount { get; init; } = 8;
    public int InitialRetryDelaySeconds { get; init; } = 60;
    public int MaxRetryDelaySeconds { get; init; } = 3600;
    public int RetryJitterSeconds { get; init; } = 10;
    public int ThrottleFallbackDelaySeconds { get; init; } = 60;
    public EmailRateLimitSettings RateLimit { get; init; } = new();
}

public sealed record EmailSmtpSettings
{
    public string Host { get; init; } = string.Empty;
    public int Port { get; init; }
    public bool UseStartTls { get; init; }
    public string Username { get; init; } = string.Empty;
    public string Password { get; init; } = string.Empty;
}

public sealed record EmailRateLimitSettings
{
    public int MaxAttemptsPerMinute { get; init; }
    public int MaxAttemptsPerHour { get; init; }
}

public sealed class EmailNotificationScheduleSettings
{
    public string CronExpression { get; set; } = string.Empty;
}
