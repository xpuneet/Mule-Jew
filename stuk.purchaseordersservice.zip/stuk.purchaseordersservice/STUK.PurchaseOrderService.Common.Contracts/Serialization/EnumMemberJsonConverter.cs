using System.Reflection;
using System.Runtime.Serialization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace STUK.PurchaseOrderService.Common.Contracts.Serialization;

public sealed class EnumMemberJsonConverter<TEnum> : JsonConverter<TEnum>
    where TEnum : struct, Enum
{
    private static readonly IReadOnlyDictionary<TEnum, string> ValuesByMember =
        Enum.GetValues<TEnum>().ToDictionary(value => value, EnumMemberValue.GetSerializedValue);

    private static readonly IReadOnlyDictionary<string, TEnum> MembersByValue =
        ValuesByMember.ToDictionary(pair => pair.Value, pair => pair.Key, StringComparer.Ordinal);

    public override TEnum Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType != JsonTokenType.String)
        {
            throw new JsonException($"Expected a string value for {typeof(TEnum).Name}.");
        }

        var value = reader.GetString();
        if (value is null || !MembersByValue.TryGetValue(value, out var member))
        {
            throw new JsonException($"Value '{value}' is not valid for {typeof(TEnum).Name}.");
        }

        return member;
    }

    public override void Write(Utf8JsonWriter writer, TEnum value, JsonSerializerOptions options)
    {
        if (!ValuesByMember.TryGetValue(value, out var serializedValue))
        {
            throw new JsonException($"Value '{value}' is not valid for {typeof(TEnum).Name}.");
        }

        writer.WriteStringValue(serializedValue);
    }
}

public static class EnumMemberValue
{
    public static string GetSerializedValue<TEnum>(TEnum value)
        where TEnum : struct, Enum
    {
        var member = typeof(TEnum).GetMember(value.ToString()).Single();
        return member.GetCustomAttribute<EnumMemberAttribute>()?.Value ?? value.ToString();
    }

    public static bool TryParse<TEnum>(string? value, out TEnum result)
        where TEnum : struct, Enum
    {
        if (value is not null)
        {
            foreach (var member in Enum.GetValues<TEnum>())
            {
                if (string.Equals(GetSerializedValue(member), value, StringComparison.Ordinal))
                {
                    result = member;
                    return true;
                }
            }
        }

        result = default;
        return false;
    }
}
