namespace STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

public sealed class PurchaseOrderSearchCriteria
{
    public string Source { get; init; } = string.Empty;

    public string? Account { get; init; }

    public string? Branch { get; init; }

    public string? Reference { get; init; }

    public string? IconPurchaseOrderNumber { get; init; }

    public PurchaseOrderCandidateStatus? Status { get; init; }

    public DateTimeOffset? AcceptedAfterDateTimeUtc { get; init; }

    public DateTimeOffset? AcceptedUntilDateTimeUtc { get; init; }

    public int PageNumber { get; init; } = 1;

    public int PageSize { get; init; } = 50;
}
