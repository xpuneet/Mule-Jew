using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using STUK.PurchaseOrderService.Common.Contracts.Serialization;

namespace STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

/// <summary>
/// Canonical purchase order accepted by the public API.
/// </summary>
public sealed class PurchaseOrder
{
    /// <summary>
    /// Required order-level supplier, location, delivery, and reference data.
    /// </summary>
    public PurchaseOrderHeader? PurchaseOrderHeader { get; set; }

    /// <summary>
    /// Required product lines. At least one line must be supplied; bulk top-level arrays are not supported.
    /// </summary>
    public List<PurchaseOrderLine>? PurchaseOrderLines { get; set; }
}

/// <summary>
/// Order-level canonical purchase order values.
/// </summary>
public sealed class PurchaseOrderHeader
{
    /// <summary>
    /// Required supplier account identifier.
    /// </summary>
    /// <example>BRIT186</example>
    public string? Account { get; set; }

    /// <summary>
    /// Required branch or location number.
    /// </summary>
    /// <example>385</example>
    [JsonRequired]
    public int Branch { get; set; }

    /// <summary>
    /// Required stock-class number used for the order header.
    /// </summary>
    /// <example>1</example>
    public int? StockClass { get; set; }

    /// <summary>
    /// Service-controlled creation user. Any caller-supplied value is replaced by configured server data.
    /// </summary>
    /// <example>APIMIN_User</example>
    public string? CreateUser { get; set; }

    /// <summary>
    /// External purchase order reference used for tracking and search.
    /// </summary>
    /// <example>20211108</example>
    public string? Reference { get; set; }

    /// <summary>
    /// Expected delivery date in ISO 8601 calendar-date format.
    /// </summary>
    /// <example>2026-09-22</example>
    public DateOnly? DateExpected { get; set; }

    /// <summary>
    /// Supplier or invoice contacts associated with the order.
    /// </summary>
    public List<PurchaseOrderContact> Contacts { get; set; } = [];

    /// <summary>
    /// Supplier or invoice postal addresses associated with the order.
    /// </summary>
    public List<PurchaseOrderAddress> Addresses { get; set; } = [];

    /// <summary>
    /// Delivery or handling instructions intended for order processing.
    /// </summary>
    /// <example>Deliver during goods-in opening hours.</example>
    public string? Instructions { get; set; }

    /// <summary>
    /// Internal free-text narrative for the purchase order.
    /// </summary>
    /// <example>Example stock replenishment order.</example>
    public string? Narrative { get; set; }

    /// <summary>
    /// Canonical order type serialized as stock, ibt, ict, emergency, direct, return, or link.
    /// </summary>
    /// <example>stock</example>
    public PurchaseOrderType? OrderType { get; set; }

    /// <summary>
    /// Delivery method serialized as C for collection or D for delivery.
    /// </summary>
    /// <example>D</example>
    public PurchaseOrderDeliveryMethod? DeliveryMethod { get; set; }

    /// <summary>
    /// Required indicator controlling whether the resulting order starts suspended.
    /// </summary>
    /// <example>false</example>
    public bool? SuspendOrder { get; set; }

    /// <summary>
    /// Additional external order reference.
    /// </summary>
    /// <example>REF01</example>
    public string? ExtOrderRef { get; set; }

    /// <summary>
    /// Return reason code when applicable to the selected order type.
    /// </summary>
    /// <example>AB</example>
    public string? ReasonReturn { get; set; }

    /// <summary>
    /// Purchase reason code when applicable.
    /// </summary>
    /// <example>STOCK</example>
    public string? ReasonPurchase { get; set; }

    /// <summary>
    /// Named extension values. A packIgnore entry with a value of true or false is currently required.
    /// </summary>
    public List<PurchaseOrderExtensionAttribute> ExtensionAttributes { get; set; } = [];
}

/// <summary>
/// Contact associated with one purchase order party role.
/// </summary>
public sealed class PurchaseOrderContact
{
    /// <summary>
    /// Party role serialized as supplier or invoice.
    /// </summary>
    /// <example>supplier</example>
    public PurchaseOrderPartyType? Type { get; set; }

    /// <summary>
    /// Contact person's display name.
    /// </summary>
    /// <example>John Smith</example>
    public string? Name { get; set; }

    /// <summary>
    /// Source-system contact identifier or code.
    /// </summary>
    /// <example>1</example>
    public string? Contact { get; set; }

    /// <summary>
    /// Contact telephone number.
    /// </summary>
    /// <example>+44 1488 662000</example>
    public string? Phone { get; set; }

    /// <summary>
    /// Contact email address.
    /// </summary>
    /// <example>supplier@example.com</example>
    public string? Email { get; set; }
}

/// <summary>
/// Postal address associated with one purchase order party role.
/// </summary>
public sealed class PurchaseOrderAddress
{
    /// <summary>
    /// Party role serialized as supplier or invoice.
    /// </summary>
    /// <example>supplier</example>
    public PurchaseOrderPartyType? Type { get; set; }

    /// <summary>
    /// Ordered postal-address lines.
    /// </summary>
    /// <example>["Example Supplier", "10 High Street"]</example>
    public List<string> Lines { get; set; } = [];

    /// <summary>
    /// Postal code.
    /// </summary>
    /// <example>RG17 0YU</example>
    public string? PostCode { get; set; }

    /// <summary>
    /// ISO 3166-1 alpha-2 country code.
    /// </summary>
    /// <example>GB</example>
    public string? Country { get; set; }
}

/// <summary>
/// Named extension value carried by the canonical order.
/// </summary>
public sealed class PurchaseOrderExtensionAttribute
{
    /// <summary>
    /// Extension name. The current API requires packIgnore.
    /// </summary>
    /// <example>packIgnore</example>
    public string? Name { get; set; }

    /// <summary>
    /// Extension value. packIgnore must be the string true or false.
    /// </summary>
    /// <example>true</example>
    public string? Value { get; set; }
}

/// <summary>
/// One product line in the canonical purchase order.
/// </summary>
public sealed class PurchaseOrderLine
{
    /// <summary>
    /// Required product identifier.
    /// </summary>
    /// <example>A0000201</example>
    public string? ProductId { get; set; }

    /// <summary>
    /// Product manufacturer name or identifier.
    /// </summary>
    /// <example>Example Manufacturer</example>
    public string? Manufacturer { get; set; }

    /// <summary>
    /// Required stock-class number for this line.
    /// </summary>
    /// <example>1</example>
    public int? StockClass { get; set; }

    /// <summary>
    /// Human-readable product description.
    /// </summary>
    /// <example>Red Brick</example>
    public string? ProductDescription { get; set; }

    /// <summary>
    /// Required ordered quantity. The value must be greater than zero.
    /// </summary>
    /// <example>5</example>
    [JsonRequired]
    public int Quantity { get; set; }

    /// <summary>
    /// Unit-of-measure code.
    /// </summary>
    /// <example>EA</example>
    public string? Unit { get; set; }

    /// <summary>
    /// Expected delivery date for this line in ISO 8601 calendar-date format.
    /// </summary>
    /// <example>2026-09-22</example>
    public DateOnly? DateExpected { get; set; }

    /// <summary>
    /// External handling instructions for the line.
    /// </summary>
    /// <example>Keep dry.</example>
    public string? SpecialInstructions { get; set; }

    /// <summary>
    /// Internal handling instructions for the line.
    /// </summary>
    /// <example>Check packaging on receipt.</example>
    public string? InternalInstructions { get; set; }

    /// <summary>
    /// Optional unit pricing information.
    /// </summary>
    public PurchaseOrderPricing? Pricing { get; set; }

    /// <summary>
    /// Optional tally dimensions associated with the ordered quantity.
    /// </summary>
    public List<PurchaseOrderTallyItem> Tally { get; set; } = [];
}

/// <summary>
/// Unit pricing information for a purchase order line.
/// </summary>
public sealed class PurchaseOrderPricing
{
    /// <summary>
    /// Pricing unit-of-measure code.
    /// </summary>
    /// <example>EA</example>
    public string? Unit { get; set; }

    /// <summary>
    /// Price per pricing unit.
    /// </summary>
    /// <example>8.45</example>
    public float Price { get; set; }
}

/// <summary>
/// Quantity and dimensions for one tally item.
/// </summary>
public sealed class PurchaseOrderTallyItem
{
    /// <summary>
    /// Quantity represented by this tally item.
    /// </summary>
    /// <example>5</example>
    public int Quantity { get; set; }

    /// <summary>
    /// Source-system length value for the tally item.
    /// </summary>
    /// <example>215</example>
    public int Length { get; set; }

    /// <summary>
    /// Source-system width value for the tally item.
    /// </summary>
    /// <example>102</example>
    public int Width { get; set; }
}

/// <summary>
/// Canonical purchase order types and their JSON values.
/// </summary>
[JsonConverter(typeof(EnumMemberJsonConverter<PurchaseOrderType>))]
public enum PurchaseOrderType
{
    [EnumMember(Value = "stock")]
    Stock,

    [EnumMember(Value = "ibt")]
    Ibt,

    [EnumMember(Value = "ict")]
    Ict,

    [EnumMember(Value = "emergency")]
    Emergency,

    [EnumMember(Value = "direct")]
    Direct,

    [EnumMember(Value = "return")]
    Return,

    [EnumMember(Value = "link")]
    Link
}

/// <summary>
/// Canonical collection or delivery method.
/// </summary>
[JsonConverter(typeof(EnumMemberJsonConverter<PurchaseOrderDeliveryMethod>))]
public enum PurchaseOrderDeliveryMethod
{
    [EnumMember(Value = "C")]
    Collection,

    [EnumMember(Value = "D")]
    Delivery
}

/// <summary>
/// Canonical purchase order party role.
/// </summary>
[JsonConverter(typeof(EnumMemberJsonConverter<PurchaseOrderPartyType>))]
public enum PurchaseOrderPartyType
{
    [EnumMember(Value = "supplier")]
    Supplier,

    [EnumMember(Value = "invoice")]
    Invoice
}
