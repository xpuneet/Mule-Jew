namespace STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

public static class PurchaseOrderSources
{
    public const string Api = "API";

    public const string Relex = "Relex";
}
