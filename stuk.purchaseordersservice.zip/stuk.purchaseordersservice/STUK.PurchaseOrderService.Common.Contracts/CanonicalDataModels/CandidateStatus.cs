namespace STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

public sealed class CandidateStatus
{
    public PurchaseOrderCandidateStatus Status { get; set; }

    public DateTimeOffset? StatusDateTime { get; set; }

    public string? StatusReason { get; set; }

    public int? ProcessBatchNo { get; set; }

    public string? PayloadMD5 { get; set; }

    public string? MessageCode { get; set; }

    public string? MessageDesc { get; set; }

    public string? PreviousMessageCode { get; set; }

    public string? PreviousMessageDesc { get; set; }

    public DateTimeOffset? CreatedDateTime { get; set; }

    public DateTimeOffset? UpdatedDateTime { get; set; }

    public DateTimeOffset? RefreshDateTime { get; set; }

    public int PendingRetriesCount { get; set; }

    public int ProcessingRetriesCount { get; set; }
}
