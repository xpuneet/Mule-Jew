using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using STUK.PurchaseOrderService.Common.Contracts.Serialization;

namespace STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

/// <summary>
/// Durable lifecycle status for a purchase order candidate.
/// </summary>
[JsonConverter(typeof(EnumMemberJsonConverter<PurchaseOrderCandidateStatus>))]
public enum PurchaseOrderCandidateStatus
{
    [EnumMember(Value = "DRAFT")]
    Draft = 0,

    [EnumMember(Value = "READY_FOR_SUBMISSION")]
    ReadyForSubmission = 10,

    [EnumMember(Value = "SUBMISSION_IN_PROGRESS")]
    SubmissionInProgress = 20,

    [EnumMember(Value = "RECOVERABLE_ERROR")]
    RecoverableError = 30,

    [EnumMember(Value = "NON_RECOVERABLE_ERROR")]
    NonRecoverableError = 40,

    [EnumMember(Value = "RETRY_REQUESTED")]
    RetryRequested = 50,

    [EnumMember(Value = "COMPLETED")]
    Completed = 60,

    [EnumMember(Value = "CANCELLED")]
    Cancelled = 70
}
