namespace STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

public sealed class PurchaseOrderCandidate
{
    public Guid CandidateId { get; init; }

    public string Source { get; init; } = string.Empty;

    public PurchaseOrder Payload { get; init; } = new();

    public CandidateStatus CandidateStatus { get; init; } = new();

    public DateTimeOffset AcceptedDateTime { get; init; }
}
