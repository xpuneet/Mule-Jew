using System.Text;
using Renci.SshNet;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Relex.Files;
using Testcontainers.Sftp;

namespace STUK.PurchaseOrderService.EndToEndTests;

public sealed class SftpRelexFileStoreTests
{
    private const string Username = "relex";
    private const string Password = "test-password";
    private const string InputPath = "/upload/data/input";
    private const string ArchivePath = "/upload/data/output/archive";
    private const string ErrorPath = "/upload/data/output/error";

    [Fact]
    public async Task ProductionAdapter_UsesEphemeralSftpWithPasswordAuthentication()
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromMinutes(2));
        var cancellationToken = timeout.Token;
        await using var container = new SftpBuilder("atmoz/sftp:alpine")
            .WithUsername(Username)
            .WithPassword(Password)
            .WithUploadDirectory("upload")
            .Build();
        await container.StartAsync(cancellationToken);

        var host = container.Hostname;
        var port = container.GetMappedPublicPort(22);
        var payload = Encoding.UTF8.GetBytes("synthetic Relex SFTP payload");
        const string fileName = "SG_OrderProposal_sftp.csv";
        var sourcePath = $"{InputPath}/{fileName}";
        var archivedPath = $"{ArchivePath}/{fileName}";
        var lastModifiedUtc = new DateTime(2026, 8, 17, 9, 0, 0, DateTimeKind.Utc);
        await SeedServerAsync(
            host,
            port,
            sourcePath,
            payload,
            lastModifiedUtc,
            cancellationToken);
        var store = new SftpRelexFileStore(CreateSettings(host, port));

        var listed = await store.ListFilesAsync(InputPath, cancellationToken);

        var file = Assert.Single(listed);
        Assert.Equal(sourcePath, file.Path);
        Assert.Equal(fileName, file.Name);
        Assert.Equal(payload.Length, file.Length);
        Assert.Equal(TimeSpan.Zero, file.LastModifiedUtc.Offset);
        Assert.Equal(lastModifiedUtc, file.LastModifiedUtc.UtcDateTime);

        await using var destination = new MemoryStream();
        await store.DownloadAsync(sourcePath, destination, cancellationToken);
        Assert.Equal(payload, destination.ToArray());
        Assert.True(await store.ExistsAsync(sourcePath, cancellationToken));
        Assert.False(await store.ExistsAsync(
            $"{InputPath}/missing.csv",
            cancellationToken));

        await store.MoveAsync(sourcePath, archivedPath, cancellationToken);

        Assert.False(await store.ExistsAsync(sourcePath, cancellationToken));
        Assert.True(await store.ExistsAsync(archivedPath, cancellationToken));
    }

    private static async Task SeedServerAsync(
        string host,
        ushort port,
        string sourcePath,
        byte[] payload,
        DateTime lastModifiedUtc,
        CancellationToken cancellationToken)
    {
        using var client = new SftpClient(host, port, Username, Password);
        await client.ConnectAsync(cancellationToken);
        await EnsureDirectoryAsync(client, "/upload/data", cancellationToken);
        await EnsureDirectoryAsync(client, InputPath, cancellationToken);
        await EnsureDirectoryAsync(client, "/upload/data/output", cancellationToken);
        await EnsureDirectoryAsync(client, ArchivePath, cancellationToken);
        await EnsureDirectoryAsync(client, ErrorPath, cancellationToken);
        await using var source = new MemoryStream(payload, writable: false);
        await client.UploadFileAsync(source, sourcePath, cancellationToken);
        client.SetLastWriteTimeUtc(sourcePath, lastModifiedUtc);
        client.Disconnect();
    }

    private static async Task EnsureDirectoryAsync(
        SftpClient client,
        string path,
        CancellationToken cancellationToken)
    {
        if (!client.Exists(path))
        {
            await client.CreateDirectoryAsync(path, cancellationToken);
        }
    }

    private static RelexIngestionSettings CreateSettings(
        string host,
        ushort port) =>
        new()
        {
            Provider = RelexFileStoreProvider.Sftp,
            InputPath = InputPath,
            ArchivePath = ArchivePath,
            ErrorPath = ErrorPath,
            SftpHost = host,
            SftpPort = port,
            SftpUsername = Username,
            SftpPassword = Password,
            OperationTimeoutSeconds = 30
        };
}
