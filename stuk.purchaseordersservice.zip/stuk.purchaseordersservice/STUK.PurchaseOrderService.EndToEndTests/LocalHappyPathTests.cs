using System.Diagnostics;
using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Aspire.Hosting;
using Aspire.Hosting.ApplicationModel;
using Aspire.Hosting.Testing;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;

namespace STUK.PurchaseOrderService.EndToEndTests;

public sealed class LocalHappyPathTests
{
    private static readonly TimeSpan StartupTimeout = TimeSpan.FromMinutes(10);
    private static readonly TimeSpan ProcessingTimeout = TimeSpan.FromMinutes(1);

    [Fact]
    public async Task CanonicalOrder_ReachesCompletedIconOutcome()
    {
        var functionsCoreToolsVersion = await GetFunctionsCoreToolsVersionAsync();
        Assert.True(
            functionsCoreToolsVersion?.StartsWith("4.", StringComparison.Ordinal) == true,
            "Azure Functions Core Tools 4 ('func') must be installed and available on PATH.");

        using var startupCancellation = new CancellationTokenSource(StartupTimeout);
        var builder = await DistributedApplicationTestingBuilder
            .CreateAsync<Projects.STUK_PurchaseOrderService_AppHost>(
                startupCancellation.Token);

        ConfigureIsolatedSqlStorage(builder);

        await using var app = await builder.BuildAsync(startupCancellation.Token);
        await app.StartAsync(startupCancellation.Token);

        await app.ResourceNotifications.WaitForResourceHealthyAsync(
            "icon-mock",
            startupCancellation.Token);
        await app.ResourceNotifications.WaitForResourceHealthyAsync(
            "web-api",
            startupCancellation.Token);
        var processorState = await app.ResourceNotifications.WaitForResourceAsync(
            "processor-functions",
            [
                KnownResourceStates.Running,
                KnownResourceStates.FailedToStart,
                KnownResourceStates.Exited
            ],
            startupCancellation.Token);
        Assert.True(
            string.Equals(
                processorState,
                KnownResourceStates.Running,
                StringComparison.Ordinal),
            $"processor-functions entered '{processorState}'. Azure Functions Core Tools 4 ('func') must be installed and available on PATH.");

        using var iconMock = app.CreateHttpClient("icon-mock", "http");
        using var resetResponse = await iconMock.DeleteAsync(
            "/_test/requests",
            startupCancellation.Token);
        resetResponse.EnsureSuccessStatusCode();

        var reference = $"E2E-{Guid.NewGuid():N}"[..20];
        var canonicalJson = await LoadCanonicalOrderAsync(
            reference,
            startupCancellation.Token);

        using var webApi = app.CreateHttpClient("web-api", "http");
        using var submitRequest = new HttpRequestMessage(
            HttpMethod.Post,
            "/PurchaseOrderService/PurchaseOrders/v1")
        {
            Content = new StringContent(
                canonicalJson,
                Encoding.UTF8,
                "application/json")
        };
        using var submitResponse = await webApi.SendAsync(
            submitRequest,
            startupCancellation.Token);
        var submitBody = await submitResponse.Content.ReadAsStringAsync(
            startupCancellation.Token);
        Assert.True(
            submitResponse.IsSuccessStatusCode,
            $"Purchase Order POST failed with {(int)submitResponse.StatusCode}: {submitBody}");

        using var submitDocument = JsonDocument.Parse(submitBody);
        var candidateId = submitDocument.RootElement
            .GetProperty("candidateId")
            .GetGuid();
        Assert.Equal(
            "READY_FOR_SUBMISSION",
            submitDocument.RootElement.GetProperty("status").GetString());

        var connectionString = await app.GetConnectionStringAsync(
            "PurchaseOrdersServiceDB",
            startupCancellation.Token);
        Assert.False(string.IsNullOrWhiteSpace(connectionString));

        JsonElement completedOrder;
        using (var processingCancellation = new CancellationTokenSource(ProcessingTimeout))
        {
            try
            {
                completedOrder = await WaitForCompletedOrderAsync(
                    webApi,
                    reference,
                    ProcessingTimeout,
                    processingCancellation.Token);
            }
            catch (Exception exception)
            {
                using var diagnosticCancellation = new CancellationTokenSource(
                    TimeSpan.FromSeconds(15));
                var databaseDiagnostic = await GetProcessingDiagnosticAsync(
                    connectionString,
                    candidateId,
                    diagnosticCancellation.Token);
                var processorLogs = await GetResourceLogsAsync(
                    app,
                    "processor-functions",
                    diagnosticCancellation.Token);
                throw new InvalidOperationException(
                    $"Purchase order processing failed. Database: {databaseDiagnostic}{Environment.NewLine}Processor logs:{Environment.NewLine}{processorLogs}",
                    exception);
            }
        }

        Assert.Equal(candidateId, completedOrder.GetProperty("candidateId").GetGuid());
        Assert.Equal("900001", completedOrder.GetProperty("iconPurchaseOrderNumber").GetString());

        using var assertionCancellation = new CancellationTokenSource(TimeSpan.FromSeconds(30));

        var activationRequests = await iconMock.GetFromJsonAsync<string[]>(
            "/_test/requests/activation",
            assertionCancellation.Token);
        var activationJson = Assert.Single(
            Assert.IsType<string[]>(activationRequests));
        using var activationDocument = JsonDocument.Parse(activationJson);
        Assert.Equal(
            "BRIT186",
            activationDocument.RootElement.GetProperty("account").GetString());

        var purchaseOrderRequests = await iconMock.GetFromJsonAsync<string[]>(
            "/_test/requests/purchase-orders",
            assertionCancellation.Token);
        var purchaseOrderJson = Assert.Single(
            Assert.IsType<string[]>(purchaseOrderRequests));
        using var purchaseOrderDocument = JsonDocument.Parse(purchaseOrderJson);
        var iconHeader = purchaseOrderDocument.RootElement.GetProperty("header");
        Assert.Equal(reference, iconHeader.GetProperty("reference").GetString());
        Assert.Equal(
            1u,
            iconHeader.GetProperty("contactID").GetUInt32());

        await AssertSuccessfulAttemptAsync(
            connectionString,
            candidateId,
            reference,
            assertionCancellation.Token);
    }

    private static void ConfigureIsolatedSqlStorage(
        IDistributedApplicationTestingBuilder builder)
    {
        var sql = builder.Resources
            .OfType<SqlServerServerResource>()
            .Single(resource => resource.Name == "sql");
        var persistentDataMount = sql.Annotations
            .OfType<ContainerMountAnnotation>()
            .Single(annotation =>
                annotation.Type == ContainerMountType.Volume
                && annotation.Target == "/var/opt/mssql");

        Assert.True(sql.Annotations.Remove(persistentDataMount));
        sql.Annotations.Add(new ContainerMountAnnotation(
            source: null,
            persistentDataMount.Target,
            ContainerMountType.Volume,
            isReadOnly: false));
    }

    private static async Task<string?> GetFunctionsCoreToolsVersionAsync()
    {
        try
        {
            using var process = Process.Start(new ProcessStartInfo
            {
                FileName = "func",
                Arguments = "--version",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            });
            if (process is null)
            {
                return null;
            }

            using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            var standardOutput = process.StandardOutput.ReadToEndAsync(cancellation.Token);
            await process.WaitForExitAsync(cancellation.Token);
            return process.ExitCode == 0
                ? (await standardOutput).Trim()
                : null;
        }
        catch (Exception exception) when (
            exception is System.ComponentModel.Win32Exception
                or OperationCanceledException)
        {
            return null;
        }
    }

    private static async Task<string> LoadCanonicalOrderAsync(
        string reference,
        CancellationToken cancellationToken)
    {
        var path = Path.Combine(
            AppContext.BaseDirectory,
            "TestData",
            "canonical-purchase-order.example.json");
        var json = await File.ReadAllTextAsync(path, cancellationToken);
        var root = JsonNode.Parse(json)?.AsObject()
            ?? throw new InvalidOperationException("The canonical fixture was empty.");
        root["purchaseOrderHeader"]!["reference"] = reference;
        return root.ToJsonString();
    }

    private static async Task<JsonElement> WaitForCompletedOrderAsync(
        HttpClient client,
        string reference,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        string? lastResponse = null;

        try
        {
            while (stopwatch.Elapsed < timeout)
            {
                using var response = await client.GetAsync(
                    $"/PurchaseOrderService/PurchaseOrders/v1?source=API&reference={Uri.EscapeDataString(reference)}&pageNumber=1&pageSize=50",
                    cancellationToken);
                lastResponse = await response.Content.ReadAsStringAsync(cancellationToken);

                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    await Task.Delay(TimeSpan.FromSeconds(1), cancellationToken);
                    continue;
                }

                Assert.True(
                    response.IsSuccessStatusCode,
                    $"Purchase Order GET failed with {(int)response.StatusCode}: {lastResponse}");

                using var document = JsonDocument.Parse(lastResponse);
                var orders = document.RootElement.GetProperty("orders");
                var order = Assert.Single(orders.EnumerateArray().ToArray());
                var status = order.GetProperty("status").GetString();
                if (string.Equals(status, "COMPLETED", StringComparison.Ordinal))
                {
                    return order.Clone();
                }

                Assert.DoesNotContain(
                    status,
                    new[]
                    {
                        "RECOVERABLE_ERROR",
                        "NON_RECOVERABLE_ERROR",
                        "CANCELLED"
                    });
                await Task.Delay(TimeSpan.FromSeconds(1), cancellationToken);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // The timeout below includes the last observed API response.
        }

        throw new TimeoutException(
            $"Purchase Order {reference} did not reach COMPLETED within {timeout}. Last response: {lastResponse}");
    }

    private static async Task<string> GetProcessingDiagnosticAsync(
        string connectionString,
        Guid candidateId,
        CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText =
            """
            SELECT
                candidate.[CandidateId],
                candidate.[Status] AS [CandidateStatus],
                candidate.[StatusReason],
                candidate.[MessageCode] AS [CandidateMessageCode],
                candidate.[MessageDescription] AS [CandidateMessageDescription],
                attempt.[AttemptId],
                attempt.[Status] AS [AttemptStatus],
                attempt.[FailureCategory],
                attempt.[MessageCode] AS [AttemptMessageCode],
                attempt.[MessageDescription] AS [AttemptMessageDescription],
                attempt.[ResponsePayloadJson]
            FROM [po].[PurchaseOrderCandidate] AS candidate
            LEFT JOIN [po].[PurchaseOrderSubmissionAttempt] AS attempt
                ON attempt.[CandidateKey] = candidate.[CandidateKey]
            WHERE candidate.[CandidateId] = @candidateId
            ORDER BY attempt.[AttemptNumber]
            FOR JSON PATH, INCLUDE_NULL_VALUES;
            """;
        command.Parameters.AddWithValue("@candidateId", candidateId);
        return (string?)await command.ExecuteScalarAsync(cancellationToken) ?? "[]";
    }

    private static async Task<string> GetResourceLogsAsync(
        DistributedApplication app,
        string resourceName,
        CancellationToken cancellationToken)
    {
        var loggerService = app.Services.GetRequiredService<ResourceLoggerService>();
        var lines = new Queue<string>();

        await foreach (var batch in loggerService
                           .GetAllAsync(resourceName)
                           .WithCancellation(cancellationToken))
        {
            foreach (var line in batch)
            {
                if (lines.Count == 100)
                {
                    lines.Dequeue();
                }

                lines.Enqueue(line.Content);
            }
        }

        return lines.Count == 0
            ? "<no resource logs captured>"
            : string.Join(Environment.NewLine, lines);
    }

    private static async Task AssertSuccessfulAttemptAsync(
        string connectionString,
        Guid candidateId,
        string reference,
        CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText =
            """
            SELECT
                candidate.[CandidateId],
                candidate.[Reference],
                candidate.[Status] AS [CandidateStatus],
                attempt.[Status] AS [AttemptStatus],
                attempt.[IconPurchaseOrderNumber]
            FROM [po].[PurchaseOrderCandidate] AS candidate
            INNER JOIN [po].[PurchaseOrderSubmissionAttempt] AS attempt
                ON attempt.[CandidateKey] = candidate.[CandidateKey]
            WHERE candidate.[CandidateId] = @candidateId
            ORDER BY attempt.[AttemptNumber] DESC;
            """;
        command.Parameters.AddWithValue("@candidateId", candidateId);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        Assert.True(
            await reader.ReadAsync(cancellationToken),
            $"No submission attempt was persisted for candidate {candidateId}.");
        Assert.Equal(candidateId, reader.GetGuid(reader.GetOrdinal("CandidateId")));
        Assert.Equal(reference, reader.GetString(reader.GetOrdinal("Reference")));
        Assert.Equal("COMPLETED", reader.GetString(reader.GetOrdinal("CandidateStatus")));
        Assert.Equal("SUCCEEDED", reader.GetString(reader.GetOrdinal("AttemptStatus")));
        Assert.Equal(
            "900001",
            reader.GetString(reader.GetOrdinal("IconPurchaseOrderNumber")));
        Assert.False(await reader.ReadAsync(cancellationToken));
    }
}
