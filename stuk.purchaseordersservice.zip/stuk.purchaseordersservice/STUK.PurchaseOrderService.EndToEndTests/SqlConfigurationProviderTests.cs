using System.Data;
using Aspire.Hosting.ApplicationModel;
using Aspire.Hosting.Testing;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using STUK.ConfigurationProviders;

namespace STUK.PurchaseOrderService.EndToEndTests;

public sealed class SqlConfigurationProviderTests
{
    private static readonly TimeSpan StartupTimeout = TimeSpan.FromMinutes(10);
    private static readonly TimeSpan ReloadTimeout = TimeSpan.FromSeconds(15);

    [Fact]
    public async Task Provider_LoadsOrderedContextsAndReloadsCommittedValues()
    {
        using var startupCancellation = new CancellationTokenSource(StartupTimeout);
        var builder = await DistributedApplicationTestingBuilder
            .CreateAsync<Projects.STUK_PurchaseOrderService_AppHost>(
                startupCancellation.Token);

        ConfigureIsolatedSqlStorage(builder);

        await using var app = await builder.BuildAsync(startupCancellation.Token);
        await app.StartAsync(startupCancellation.Token);
        await app.ResourceNotifications.WaitForResourceHealthyAsync(
            "web-api",
            startupCancellation.Token);

        var connectionString = await app.GetConnectionStringAsync(
            "PurchaseOrdersServiceDB",
            startupCancellation.Token);
        Assert.False(string.IsNullOrWhiteSpace(connectionString));

        var uniqueSuffix = Guid.NewGuid().ToString("N");
        var commonOnlyKey = $"E2E:SqlConfigurationProvider:{uniqueSuffix}:CommonOnly";
        var overrideKey = $"E2E:SqlConfigurationProvider:{uniqueSuffix}:Override";
        IConfigurationRoot? configuration = null;

        try
        {
            await InsertSettingsAsync(
                connectionString,
                commonOnlyKey,
                overrideKey,
                startupCancellation.Token);

            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["ConnectionStrings:PurchaseOrdersServiceDB"] = connectionString,
                    ["DatabaseConfigurationRefreshInterval"] = "1"
                })
                .AddSqlServerConfiguration(
                    "PurchaseOrdersServiceDB",
                    "po.sp_get_application_settings",
                    "DatabaseConfigurationRefreshInterval",
                    ["Common", "WebApi"])
                .Build();

            Assert.Equal("common-value", configuration[commonOnlyKey]);
            Assert.Equal("webapi-initial", configuration[overrideKey]);

            await UpdateWebApiSettingAsync(
                connectionString,
                overrideKey,
                startupCancellation.Token);

            var reloaded = await WaitForValueAsync(
                configuration,
                overrideKey,
                "webapi-updated",
                ReloadTimeout,
                startupCancellation.Token);

            Assert.True(
                reloaded,
                "The existing configuration root did not observe the committed SQL update within the reload timeout.");
        }
        finally
        {
            (configuration as IDisposable)?.Dispose();
            using var cleanupCancellation = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            await DeleteSettingsAsync(
                connectionString,
                commonOnlyKey,
                overrideKey,
                cleanupCancellation.Token);
        }
    }

    private static void ConfigureIsolatedSqlStorage(
        IDistributedApplicationTestingBuilder builder)
    {
        var sql = builder.Resources
            .OfType<SqlServerServerResource>()
            .Single(resource => resource.Name == "sql");
        var persistentDataMount = sql.Annotations
            .OfType<ContainerMountAnnotation>()
            .Single(annotation =>
                annotation.Type == ContainerMountType.Volume
                && annotation.Target == "/var/opt/mssql");

        Assert.True(sql.Annotations.Remove(persistentDataMount));
        sql.Annotations.Add(new ContainerMountAnnotation(
            source: null,
            persistentDataMount.Target,
            ContainerMountType.Volume,
            isReadOnly: false));
    }

    private static async Task InsertSettingsAsync(
        string connectionString,
        string commonOnlyKey,
        string overrideKey,
        CancellationToken cancellationToken)
    {
        const string commandText = """
            INSERT INTO [po].[ApplicationSetting] ([Context], [Key], [Value])
            VALUES
                (N'Common', @commonOnlyKey, N'common-value'),
                (N'Common', @overrideKey, N'common-value'),
                (N'WebApi', @overrideKey, N'webapi-initial');
            """;

        await ExecuteAsync(
            connectionString,
            commandText,
            command =>
            {
                AddKeyParameter(command, "@commonOnlyKey", commonOnlyKey);
                AddKeyParameter(command, "@overrideKey", overrideKey);
            },
            cancellationToken);
    }

    private static async Task UpdateWebApiSettingAsync(
        string connectionString,
        string overrideKey,
        CancellationToken cancellationToken)
    {
        const string commandText = """
            UPDATE [po].[ApplicationSetting]
            SET [Value] = N'webapi-updated'
            WHERE [Context] = N'WebApi'
              AND [Key] = @overrideKey;
            """;

        await ExecuteAsync(
            connectionString,
            commandText,
            command => AddKeyParameter(command, "@overrideKey", overrideKey),
            cancellationToken);
    }

    private static async Task DeleteSettingsAsync(
        string connectionString,
        string commonOnlyKey,
        string overrideKey,
        CancellationToken cancellationToken)
    {
        const string commandText = """
            DELETE FROM [po].[ApplicationSetting]
            WHERE [Key] IN (@commonOnlyKey, @overrideKey);
            """;

        await ExecuteAsync(
            connectionString,
            commandText,
            command =>
            {
                AddKeyParameter(command, "@commonOnlyKey", commonOnlyKey);
                AddKeyParameter(command, "@overrideKey", overrideKey);
            },
            cancellationToken);
    }

    private static async Task ExecuteAsync(
        string connectionString,
        string commandText,
        Action<SqlCommand> addParameters,
        CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(commandText, connection);
        addParameters(command);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static void AddKeyParameter(
        SqlCommand command,
        string parameterName,
        string value)
    {
        command.Parameters.Add(parameterName, SqlDbType.NVarChar, 256).Value = value;
    }

    private static async Task<bool> WaitForValueAsync(
        IConfiguration configuration,
        string key,
        string expectedValue,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        var deadline = DateTimeOffset.UtcNow + timeout;

        while (DateTimeOffset.UtcNow < deadline)
        {
            if (string.Equals(
                    configuration[key],
                    expectedValue,
                    StringComparison.Ordinal))
            {
                return true;
            }

            await Task.Delay(TimeSpan.FromMilliseconds(200), cancellationToken);
        }

        return false;
    }
}
