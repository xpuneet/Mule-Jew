using System.Diagnostics;
using System.Net.Http.Json;
using Aspire.Hosting;
using Aspire.Hosting.ApplicationModel;
using Aspire.Hosting.Testing;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;

namespace STUK.PurchaseOrderService.EndToEndTests;

public sealed class RelexIngestionTests
{
    private static readonly TimeSpan StartupTimeout = TimeSpan.FromMinutes(10);
    private static readonly TimeSpan IngestionTimeout = TimeSpan.FromMinutes(1);

    [Fact]
    public async Task SyntheticFile_IsPersistedAndArchivedWithoutIconSubmission()
    {
        var functionsCoreToolsVersion = await GetFunctionsCoreToolsVersionAsync();
        Assert.True(
            functionsCoreToolsVersion?.StartsWith("4.", StringComparison.Ordinal) == true,
            "Azure Functions Core Tools 4 ('func') must be installed and available on PATH.");

        var uniqueRoot = Path.Combine(
            Path.GetTempPath(),
            $"stuk-relex-e2e-{Guid.NewGuid():N}");
        var previousRelexRoot = Environment.GetEnvironmentVariable(
            "STUK_RELEX_LOCAL_ROOT");
        var previousSubmissionEnabled = Environment.GetEnvironmentVariable(
            "STUK_PROCESSOR_SUBMISSION_ENABLED");

        try
        {
            Environment.SetEnvironmentVariable("STUK_RELEX_LOCAL_ROOT", uniqueRoot);
            Environment.SetEnvironmentVariable(
                "STUK_PROCESSOR_SUBMISSION_ENABLED",
                "false");
            await RunScenarioAsync(uniqueRoot);
        }
        finally
        {
            Environment.SetEnvironmentVariable(
                "STUK_RELEX_LOCAL_ROOT",
                previousRelexRoot);
            Environment.SetEnvironmentVariable(
                "STUK_PROCESSOR_SUBMISSION_ENABLED",
                previousSubmissionEnabled);
            if (Directory.Exists(uniqueRoot))
            {
                Directory.Delete(uniqueRoot, recursive: true);
            }
        }
    }

    private static async Task RunScenarioAsync(string uniqueRoot)
    {
        var inputDirectory = Path.Combine(uniqueRoot, "data", "input");
        var archiveDirectory = Path.Combine(
            uniqueRoot,
            "data",
            "output",
            "archive");
        var errorDirectory = Path.Combine(uniqueRoot, "data", "output", "error");
        Directory.CreateDirectory(inputDirectory);
        Directory.CreateDirectory(archiveDirectory);
        Directory.CreateDirectory(errorDirectory);

        const string fileName = "SG_OrderProposal_synthetic.csv";
        var fixturePath = Path.Combine(
            AppContext.BaseDirectory,
            "TestData",
            "Relex",
            fileName);
        var inputPath = Path.Combine(inputDirectory, fileName);
        var archivePath = Path.Combine(archiveDirectory, fileName);
        File.Copy(fixturePath, inputPath);
        File.SetLastWriteTimeUtc(inputPath, DateTime.UtcNow.AddMinutes(-3));

        using var startupCancellation = new CancellationTokenSource(StartupTimeout);
        var builder = await DistributedApplicationTestingBuilder
            .CreateAsync<Projects.STUK_PurchaseOrderService_AppHost>(
                startupCancellation.Token);
        ConfigureIsolatedSqlStorage(builder);

        await using var app = await builder.BuildAsync(startupCancellation.Token);
        await app.StartAsync(startupCancellation.Token);
        await app.ResourceNotifications.WaitForResourceHealthyAsync(
            "icon-mock",
            startupCancellation.Token);
        var processorState = await app.ResourceNotifications.WaitForResourceAsync(
            "processor-functions",
            [
                KnownResourceStates.Running,
                KnownResourceStates.FailedToStart,
                KnownResourceStates.Exited
            ],
            startupCancellation.Token);
        Assert.True(
            string.Equals(
                processorState,
                KnownResourceStates.Running,
                StringComparison.Ordinal),
            $"processor-functions entered '{processorState}'.");

        using var iconMock = app.CreateHttpClient("icon-mock", "http");
        using var resetResponse = await iconMock.DeleteAsync(
            "/_test/requests",
            startupCancellation.Token);
        resetResponse.EnsureSuccessStatusCode();

        try
        {
            await WaitForFileAsync(
                archivePath,
                IngestionTimeout,
                startupCancellation.Token);
        }
        catch (Exception exception)
        {
            using var diagnosticCancellation = new CancellationTokenSource(
                TimeSpan.FromSeconds(15));
            var processorLogs = await GetResourceLogsAsync(
                app,
                "processor-functions",
                diagnosticCancellation.Token);
            throw new InvalidOperationException(
                $"Relex file was not archived. Processor logs:{Environment.NewLine}{processorLogs}",
                exception);
        }

        var connectionString = await app.GetConnectionStringAsync(
            "PurchaseOrdersServiceDB",
            startupCancellation.Token);
        Assert.False(string.IsNullOrWhiteSpace(connectionString));
        await AssertDatabaseStateAsync(
            connectionString,
            startupCancellation.Token);

        Assert.Empty(Directory.EnumerateFiles(inputDirectory));
        Assert.Equal(fileName, Assert.Single(Directory.EnumerateFiles(archiveDirectory))
            .Split(Path.DirectorySeparatorChar)[^1]);
        Assert.Empty(Directory.EnumerateFiles(errorDirectory));

        var purchaseOrderRequests = await iconMock.GetFromJsonAsync<string[]>(
            "/_test/requests/purchase-orders",
            startupCancellation.Token);
        Assert.Empty(Assert.IsType<string[]>(purchaseOrderRequests));
    }

    private static async Task AssertDatabaseStateAsync(
        string connectionString,
        CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText =
            """
            SELECT
                COUNT(*) AS [BatchCount],
                MAX([Status]) AS [BatchStatus],
                MAX([ParsedRowCount]) AS [ParsedRowCount],
                MAX([CandidateCount]) AS [CandidateCount]
            FROM [po].[PurchaseOrderBatch]
            WHERE [Source] = N'Relex';

            SELECT
                COUNT(*) AS [CandidateCount],
                COALESCE(SUM([SourceRowCount]), 0) AS [SourceRowCount]
            FROM [po].[PurchaseOrderCandidate]
            WHERE [Source] = N'Relex'
              AND [Kind] = 'RELEX'
              AND [Status] = 'READY_FOR_SUBMISSION';

            SELECT COUNT(*) AS [LineCount]
            FROM [po].[PurchaseOrderCandidate] AS candidate
            CROSS APPLY OPENJSON(candidate.[PayloadJson], '$.purchaseOrderLines') AS line
            WHERE candidate.[Source] = N'Relex'
              AND candidate.[Reference] = N'1001';
            """;

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        Assert.True(await reader.ReadAsync(cancellationToken));
        Assert.Equal(1, reader.GetInt32(reader.GetOrdinal("BatchCount")));
        Assert.Equal(
            "COMPLETED",
            reader.GetString(reader.GetOrdinal("BatchStatus")));
        Assert.Equal(6, reader.GetInt32(reader.GetOrdinal("ParsedRowCount")));
        Assert.Equal(5, reader.GetInt32(reader.GetOrdinal("CandidateCount")));

        Assert.True(await reader.NextResultAsync(cancellationToken));
        Assert.True(await reader.ReadAsync(cancellationToken));
        Assert.Equal(5, reader.GetInt32(reader.GetOrdinal("CandidateCount")));
        Assert.Equal(6, reader.GetInt32(reader.GetOrdinal("SourceRowCount")));

        Assert.True(await reader.NextResultAsync(cancellationToken));
        Assert.True(await reader.ReadAsync(cancellationToken));
        Assert.Equal(2, reader.GetInt32(reader.GetOrdinal("LineCount")));
    }

    private static async Task WaitForFileAsync(
        string path,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        while (stopwatch.Elapsed < timeout)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (File.Exists(path))
            {
                return;
            }

            await Task.Delay(TimeSpan.FromSeconds(1), cancellationToken);
        }

        throw new TimeoutException(
            $"File was not created within {timeout}: {path}");
    }

    private static void ConfigureIsolatedSqlStorage(
        IDistributedApplicationTestingBuilder builder)
    {
        var sql = builder.Resources
            .OfType<SqlServerServerResource>()
            .Single(resource => resource.Name == "sql");
        var persistentDataMount = sql.Annotations
            .OfType<ContainerMountAnnotation>()
            .Single(annotation =>
                annotation.Type == ContainerMountType.Volume
                && annotation.Target == "/var/opt/mssql");

        Assert.True(sql.Annotations.Remove(persistentDataMount));
        sql.Annotations.Add(new ContainerMountAnnotation(
            source: null,
            persistentDataMount.Target,
            ContainerMountType.Volume,
            isReadOnly: false));
    }

    private static async Task<string?> GetFunctionsCoreToolsVersionAsync()
    {
        try
        {
            using var process = Process.Start(new ProcessStartInfo
            {
                FileName = "func",
                Arguments = "--version",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            });
            if (process is null)
            {
                return null;
            }

            using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            var standardOutput = process.StandardOutput.ReadToEndAsync(cancellation.Token);
            await process.WaitForExitAsync(cancellation.Token);
            return process.ExitCode == 0
                ? (await standardOutput).Trim()
                : null;
        }
        catch (Exception exception) when (
            exception is System.ComponentModel.Win32Exception
                or OperationCanceledException)
        {
            return null;
        }
    }

    private static async Task<string> GetResourceLogsAsync(
        DistributedApplication app,
        string resourceName,
        CancellationToken cancellationToken)
    {
        var loggerService = app.Services.GetRequiredService<ResourceLoggerService>();
        var lines = new Queue<string>();

        await foreach (var batch in loggerService
                           .GetAllAsync(resourceName)
                           .WithCancellation(cancellationToken))
        {
            foreach (var line in batch)
            {
                if (lines.Count == 100)
                {
                    lines.Dequeue();
                }

                lines.Enqueue(line.Content);
            }
        }

        return lines.Count == 0
            ? "<no resource logs captured>"
            : string.Join(Environment.NewLine, lines);
    }
}
