using System.Text.Json;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.WebApi.Config;
using STUK.PurchaseOrderService.WebApi.Controllers.V1;
using STUK.PurchaseOrderService.WebApi.Domain.Services.V1;

namespace STUK.PurchaseOrderService.WebApiIntegrationTests.Contracts;

public sealed class PurchaseOrderApiContractTests
{
    [Fact]
    public void SubmitPurchaseOrderResponse_SerializesCanonicalReadyForSubmissionStatus()
    {
        var response = new SubmitPurchaseOrderResponse
        {
            CandidateId = Guid.Parse("1c656100-c74d-4739-9df2-35a95165c0b3"),
            Status = PurchaseOrderCandidateStatus.ReadyForSubmission,
            AcceptedDateTime = new DateTimeOffset(2026, 7, 25, 10, 30, 0, TimeSpan.Zero)
        };

        using var document = JsonDocument.Parse(
            JsonSerializer.Serialize(response, new JsonSerializerOptions(JsonSerializerDefaults.Web)));

        Assert.Equal("READY_FOR_SUBMISSION", document.RootElement.GetProperty("status").GetString());
    }

    [Fact]
    public void ApiAssemblies_DoNotReferenceIconIntegration()
    {
        var referencedAssemblies = typeof(PurchaseOrdersController).Assembly
            .GetReferencedAssemblies()
            .Concat(typeof(PurchaseOrdersService).Assembly.GetReferencedAssemblies());

        Assert.DoesNotContain(
            referencedAssemblies,
            assembly => assembly.Name?.StartsWith("STUK.IconIntegration", StringComparison.Ordinal) == true);
    }

    [Fact]
    public void WebApiSettingsValidator_WhenApiCreateUserIsBlank_Fails()
    {
        var settings = new WebApiSettings
        {
            AllowedSources = ["API", "Relex"],
            ApiCreateUser = "",
            PurchaseOrdersMaxPageSize = 50
        };

        var result = new WebApiSettingsValidator().Validate(null, settings);

        Assert.True(result.Failed);
    }

    [Fact]
    public void WebApiSettingsValidator_WhenConfigurationIsComplete_Succeeds()
    {
        var settings = new WebApiSettings
        {
            AllowedSources = ["API", "Relex"],
            ApiCreateUser = "APIMIN_User",
            PurchaseOrdersMaxPageSize = 50
        };

        var result = new WebApiSettingsValidator().Validate(null, settings);

        Assert.True(result.Succeeded);
    }
}
