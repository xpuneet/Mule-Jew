using System.Text.Json;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.WebApiIntegrationTests.Contracts;

public sealed class CanonicalPurchaseOrderSerializationTests
{
    private static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.Web);

    [Fact]
    public void CanonicalModel_UsesApprovedScalarTypes()
    {
        Assert.Equal(
            typeof(int),
            typeof(PurchaseOrderHeader).GetProperty(nameof(PurchaseOrderHeader.Branch))!.PropertyType);
        Assert.Equal(
            typeof(int?),
            typeof(PurchaseOrderHeader).GetProperty(nameof(PurchaseOrderHeader.StockClass))!.PropertyType);
        Assert.Equal(
            typeof(bool?),
            typeof(PurchaseOrderHeader).GetProperty(nameof(PurchaseOrderHeader.SuspendOrder))!.PropertyType);
        Assert.Equal(
            typeof(int),
            typeof(PurchaseOrderLine).GetProperty(nameof(PurchaseOrderLine.Quantity))!.PropertyType);
        Assert.Equal(
            typeof(float),
            typeof(PurchaseOrderPricing).GetProperty(nameof(PurchaseOrderPricing.Price))!.PropertyType);
        Assert.Equal(
            typeof(int),
            typeof(PurchaseOrderTallyItem).GetProperty(nameof(PurchaseOrderTallyItem.Quantity))!.PropertyType);
        Assert.Equal(
            typeof(int),
            typeof(PurchaseOrderTallyItem).GetProperty(nameof(PurchaseOrderTallyItem.Length))!.PropertyType);
        Assert.Equal(
            typeof(int),
            typeof(PurchaseOrderTallyItem).GetProperty(nameof(PurchaseOrderTallyItem.Width))!.PropertyType);
    }

    [Fact]
    public async Task CanonicalExample_UsesApprovedJsonScalarKinds()
    {
        using var document = JsonDocument.Parse(await File.ReadAllTextAsync(GetExamplePath()));
        var header = document.RootElement.GetProperty("purchaseOrderHeader");
        var line = document.RootElement.GetProperty("purchaseOrderLines")[0];
        var pricing = line.GetProperty("pricing");
        var tallyItem = line.GetProperty("tally")[0];

        Assert.Equal(JsonValueKind.Number, header.GetProperty("branch").ValueKind);
        Assert.Equal(JsonValueKind.Number, header.GetProperty("stockClass").ValueKind);
        Assert.True(
            header.GetProperty("suspendOrder").ValueKind is JsonValueKind.True or JsonValueKind.False);
        Assert.Equal(JsonValueKind.Number, line.GetProperty("quantity").ValueKind);
        Assert.Equal(JsonValueKind.Number, pricing.GetProperty("price").ValueKind);
        Assert.Equal(JsonValueKind.Number, tallyItem.GetProperty("quantity").ValueKind);
        Assert.Equal(JsonValueKind.Number, tallyItem.GetProperty("length").ValueKind);
        Assert.Equal(JsonValueKind.Number, tallyItem.GetProperty("width").ValueKind);
    }

    [Fact]
    public async Task CanonicalExample_DeserializesApprovedScalarTypes()
    {
        var json = await File.ReadAllTextAsync(GetExamplePath());

        var order = JsonSerializer.Deserialize<PurchaseOrder>(json, SerializerOptions);

        Assert.NotNull(order);
        Assert.Equal(385, order.PurchaseOrderHeader!.Branch);
        Assert.Equal(1, order.PurchaseOrderHeader.StockClass);
        Assert.True(order.PurchaseOrderHeader.SuspendOrder);
        Assert.Equal(1, order.PurchaseOrderLines![0].StockClass);
        Assert.Equal(5, order.PurchaseOrderLines[0].Quantity);
        Assert.Equal(8.45f, order.PurchaseOrderLines[0].Pricing!.Price);
        Assert.Equal(0, order.PurchaseOrderLines[0].Tally[0].Quantity);
        Assert.Equal(0, order.PurchaseOrderLines[0].Tally[0].Length);
        Assert.Equal(0, order.PurchaseOrderLines[0].Tally[0].Width);
    }

    [Fact]
    public async Task CanonicalExample_RoundTripsBusinessPayloadWithoutCandidateStatus()
    {
        var json = await File.ReadAllTextAsync(GetExamplePath());
        var order = JsonSerializer.Deserialize<PurchaseOrder>(json, SerializerOptions)!;

        using var document = JsonDocument.Parse(JsonSerializer.Serialize(order, SerializerOptions));

        Assert.True(document.RootElement.TryGetProperty("purchaseOrderHeader", out var header));
        Assert.True(document.RootElement.TryGetProperty("purchaseOrderLines", out _));
        Assert.False(document.RootElement.TryGetProperty("candidateStatus", out _));
        Assert.Equal("stock", header.GetProperty("orderType").GetString());
        Assert.Equal("D", header.GetProperty("deliveryMethod").GetString());
        Assert.Equal("supplier", header.GetProperty("contacts")[0].GetProperty("type").GetString());
    }

    [Fact]
    public void PurchaseOrderCandidate_SerializesStatusOutsideBusinessPayload()
    {
        var candidate = new PurchaseOrderCandidate
        {
            CandidateId = Guid.Parse("7b44588e-ff0f-48ac-a48f-36bd28279703"),
            Source = "Relex",
            Payload = new PurchaseOrder(),
            AcceptedDateTime = new DateTimeOffset(2026, 7, 17, 10, 20, 0, TimeSpan.Zero)
        };

        using var document = JsonDocument.Parse(JsonSerializer.Serialize(candidate, SerializerOptions));

        Assert.True(document.RootElement.TryGetProperty("payload", out var payload));
        Assert.False(payload.TryGetProperty("candidateStatus", out _));
        Assert.Equal(
            "DRAFT",
            document.RootElement.GetProperty("candidateStatus").GetProperty("status").GetString());
    }

    private static string GetExamplePath() =>
        Path.Combine(AppContext.BaseDirectory, "TestData", "canonical-purchase-order.example.json");
}
