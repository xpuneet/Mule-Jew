using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Reports;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.IconMock;
using IconMockProgram = STUK.PurchaseOrderService.IconMock.Program;

namespace STUK.PurchaseOrderService.UnitTests.IconMock;

public sealed class IconMockContractTests
{
    private const string ActivationToken = "synthetic-activation-token";
    private const string PurchaseOrderToken = "synthetic-purchase-order-token";

    [Fact]
    public async Task ActivationRoute_UsesDedicatedTokenAndReturnsPackageCompatibleResponse()
    {
        await using var factory = new IconMockFactory("Development");
        using var client = factory.CreateClient();

        using var wrongTokenRequest = JsonRequest(
            "/CF_ICXI0002",
            "{\"account\":\"SUP-001\"}",
            PurchaseOrderToken);
        using var wrongTokenResponse = await client.SendAsync(wrongTokenRequest);

        Assert.Equal(HttpStatusCode.Unauthorized, wrongTokenResponse.StatusCode);

        var reports = new IconReports(client);
        var response = await reports.POST_PurchaseOrderActivationOptionsAsync(
            new PurchaseOrderActivationOptionsRequest { Account = "SUP-001" },
            ActivationToken,
            "CF_ICXI0002");

        var result = Assert.Single(response.Response.Results);
        Assert.Equal("SUP-001", result.Account);
        Assert.Equal(PurchaseOrderActivateAction.Activate, result.ActivateAction);
        Assert.False(result.Bypass);

        var recorded = await client.GetFromJsonAsync<string[]>(
            "/_test/requests/activation");
        var rawRequest = Assert.Single(Assert.IsType<string[]>(recorded));
        using var document = JsonDocument.Parse(rawRequest);
        Assert.Equal("SUP-001", FindString(document.RootElement, "account"));
    }

    [Fact]
    public async Task CreatePurchaseOrderRoute_UsesDedicatedTokenAndReturnsPackageCompatibleResponse()
    {
        await using var factory = new IconMockFactory("Development");
        using var client = factory.CreateClient();

        using var wrongTokenRequest = JsonRequest(
            "/CreatePurchaseOrder",
            "{\"header\":{\"deliveryMethod\":\"delivered\",\"contactID\":1}}",
            ActivationToken);
        using var wrongTokenResponse = await client.SendAsync(wrongTokenRequest);

        Assert.Equal(HttpStatusCode.Unauthorized, wrongTokenResponse.StatusCode);

        var packageClient = new PurchaseOrderClient(client)
        {
            BaseUrl = client.BaseAddress!.ToString().TrimEnd('/')
        };
        var response = await packageClient.POST_CreatePurchaseOrderAsync(
            CreatePackageRequest(),
            PurchaseOrderToken,
            CancellationToken.None);

        var body = Assert.IsType<IconCreatePurchaseOrderResponse_Body>(response.Body);
        var deliveryMethod = Assert.IsType<PurchaseOrderDeliveryMethodResponse>(
            body.DeliveryMethod);
        var contactId = Assert.IsType<PurchaseOrderContactIdResponse>(body.ContactId);
        Assert.Equal(900001u, body.OrderNo);
        Assert.Equal(PurchaseOrderCreatedStatus.Activated, body.CreatedStatus);
        Assert.False(body.Suspended);
        Assert.Equal(
            PurchaseOrderDeliveryMethod.Delivered,
            deliveryMethod.DeliveryMethodCode);
        Assert.Null(deliveryMethod.DeliveryMethodError);
        Assert.Equal(1u, contactId.ContactIdCode);
        Assert.Null(contactId.ContactIdError);

        var recorded = await client.GetFromJsonAsync<string[]>(
            "/_test/requests/purchase-orders");
        var rawRequest = Assert.Single(Assert.IsType<string[]>(recorded));
        using var document = JsonDocument.Parse(rawRequest);
        Assert.Equal(
            1u,
            document.RootElement
                .GetProperty("header")
                .GetProperty("contactID")
                .GetUInt32());
    }

    [Fact]
    public async Task ResetEndpoint_ClearsBothCapturedRequestLists()
    {
        await using var factory = new IconMockFactory("Development");
        using var client = factory.CreateClient();

        using var activationRequest = JsonRequest(
            "/CF_ICXI0002",
            "{\"account\":\"SUP-001\"}",
            ActivationToken);
        using var createRequest = JsonRequest(
            "/CreatePurchaseOrder",
            "{\"header\":{\"deliveryMethod\":\"delivered\",\"contactID\":1}}",
            PurchaseOrderToken);
        using var activationResponse = await client.SendAsync(activationRequest);
        using var createResponse = await client.SendAsync(createRequest);
        activationResponse.EnsureSuccessStatusCode();
        createResponse.EnsureSuccessStatusCode();

        using var resetResponse = await client.DeleteAsync("/_test/requests");

        resetResponse.EnsureSuccessStatusCode();
        Assert.Empty((await client.GetFromJsonAsync<string[]>(
            "/_test/requests/activation"))!);
        Assert.Empty((await client.GetFromJsonAsync<string[]>(
            "/_test/requests/purchase-orders"))!);
    }

    [Fact]
    public async Task TestControlEndpoints_OutsideDevelopment_ReturnNotFound()
    {
        await using var factory = new IconMockFactory("Staging");
        using var client = factory.CreateClient();

        using var activationRequests = await client.GetAsync(
            "/_test/requests/activation");
        using var createRequests = await client.GetAsync(
            "/_test/requests/purchase-orders");
        using var reset = await client.DeleteAsync("/_test/requests");

        Assert.Equal(HttpStatusCode.NotFound, activationRequests.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, createRequests.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, reset.StatusCode);
    }

    private static HttpRequestMessage JsonRequest(
        string path,
        string json,
        string token)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, path)
        {
            Content = new StringContent(json, Encoding.UTF8, "application/json")
        };
        request.Headers.Add("K8-XI-AuthToken", token);
        return request;
    }

    private static IconCreatePurchaseOrderRequest CreatePackageRequest() => new()
    {
        Header = new PurchaseOrderHeader
        {
            Account = "SUP-001",
            Branch = 1,
            CreateUser = "LOCAL_TEST",
            Reference = "LOCAL-001",
            DateExpected = "2026-08-05",
            DeliveryMethod = PurchaseOrderDeliveryMethod.Delivered,
            ContactID = 1
        },
        Lines = new PurchaseOrderLines
        {
            Line =
            [
                new PurchaseOrderLine
                {
                    Product = "PRODUCT-001",
                    Quantity = 1m,
                    Price = 10m
                }
            ]
        }
    };

    private static string? FindString(JsonElement element, string propertyName)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in element.EnumerateObject())
            {
                if (string.Equals(
                        property.Name,
                        propertyName,
                        StringComparison.OrdinalIgnoreCase)
                    && property.Value.ValueKind == JsonValueKind.String)
                {
                    return property.Value.GetString();
                }

                var nested = FindString(property.Value, propertyName);
                if (nested is not null)
                {
                    return nested;
                }
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
            {
                var nested = FindString(item, propertyName);
                if (nested is not null)
                {
                    return nested;
                }
            }
        }

        return null;
    }

    private sealed class IconMockFactory(string environment)
        : WebApplicationFactory<IconMockProgram>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment(environment);
            builder.UseSetting(
                $"{IconMockOptions.SectionName}:{nameof(IconMockOptions.ActivationAuthToken)}",
                ActivationToken);
            builder.UseSetting(
                $"{IconMockOptions.SectionName}:{nameof(IconMockOptions.PurchaseOrderAuthToken)}",
                PurchaseOrderToken);
        }
    }
}
