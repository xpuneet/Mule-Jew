using System.Text.RegularExpressions;
using System.Text.Json;

namespace STUK.PurchaseOrderService.UnitTests.Database;

public sealed class SqlDeploymentContractTests
{
    private static readonly string[] CandidateStatusValues =
    [
        "DRAFT",
        "READY_FOR_SUBMISSION",
        "SUBMISSION_IN_PROGRESS",
        "RECOVERABLE_ERROR",
        "NON_RECOVERABLE_ERROR",
        "RETRY_REQUESTED",
        "COMPLETED",
        "CANCELLED"
    ];

    private static readonly string[] BatchStatusValues =
    [
        "INGESTING",
        "READY_FOR_SUBMISSION",
        "PROCESSING",
        "COMPLETED",
        "FAILED"
    ];

    private static readonly string[] AttemptStatusValues =
    [
        "DISPATCHED",
        "SUCCEEDED",
        "FAILED",
        "UNKNOWN_OUTCOME"
    ];

    private static readonly string[] NotificationStatusValues =
    [
        "PENDING",
        "SENDING",
        "SENT",
        "FAILED"
    ];

    private static readonly string[] NotificationAttemptOutcomeValues =
    [
        "STARTED",
        "SUCCEEDED",
        "TRANSIENT_FAILURE",
        "THROTTLED",
        "PERMANENT_FAILURE",
        "DEFERRED",
        "LEASE_EXPIRED"
    ];

    private static readonly string[] LegacyStatusTableNames =
    [
        "PurchaseOrderCandidateStatus",
        "PurchaseOrderBatchStatus",
        "PurchaseOrderAttemptStatus",
        "PurchaseOrderNotificationStatus"
    ];

    private static readonly string[] ExpectedStatusConstraints =
    [
        CreateStatusConstraintManifestEntry(
            "PurchaseOrderBatch",
            "CK_PO_Batch_Status",
            "Status",
            BatchStatusValues),
        CreateStatusConstraintManifestEntry(
            "PurchaseOrderCandidate",
            "CK_PO_Candidate_Status",
            "Status",
            CandidateStatusValues),
        CreateStatusConstraintManifestEntry(
            "PurchaseOrderSubmissionAttempt",
            "CK_PO_Attempt_Status",
            "Status",
            AttemptStatusValues),
        CreateStatusConstraintManifestEntry(
            "PurchaseOrderAudit",
            "CK_PO_Audit_PreviousStatus",
            "PreviousStatus",
            CandidateStatusValues,
            isNullable: true),
        CreateStatusConstraintManifestEntry(
            "PurchaseOrderAudit",
            "CK_PO_Audit_CurrentStatus",
            "CurrentStatus",
            CandidateStatusValues,
            isNullable: true),
        CreateStatusConstraintManifestEntry(
            "PurchaseOrderNotification",
            "CK_PO_Notification_Status",
            "Status",
            NotificationStatusValues),
        CreateStatusConstraintManifestEntry(
            "PurchaseOrderNotificationAttempt",
            "CK_PO_NotificationAttempt_Outcome",
            "Outcome",
            NotificationAttemptOutcomeValues),
        CreateStatusConstraintManifestEntry(
            "RelexNotificationEvent",
            "CK_PO_RelexEvent_Status",
            "Status",
            ["PENDING", "PROCESSING", "ENQUEUED", "FAILED"])
    ];

    private static readonly string[] ProcedureNames =
    [
        "sp_get_application_settings",
        "sp_create_purchase_order_candidate",
        "sp_search_purchase_order_candidates",
        "sp_register_purchase_order_batch",
        "sp_add_purchase_order_candidate_to_batch",
        "sp_complete_purchase_order_batch",
        "sp_fail_purchase_order_batch",
        "sp_get_purchase_order_batch",
        "sp_get_purchase_order_batch_by_source_hash",
        "sp_claim_purchase_order_candidates",
        "sp_renew_purchase_order_claim",
        "sp_release_purchase_order_claim",
        "sp_expire_purchase_order_claims",
        "sp_get_purchase_order_candidate",
        "sp_begin_purchase_order_submission_attempt",
        "sp_fail_purchase_order_candidate_pre_dispatch",
        "sp_complete_purchase_order_submission",
        "sp_fail_purchase_order_submission",
        "sp_request_purchase_order_retry",
        "sp_cancel_purchase_order_candidate",
        "sp_get_purchase_order_audit",
        "sp_get_purchase_order_batch_outcomes",
        "sp_register_purchase_order_notification",
        "sp_complete_purchase_order_notification",
        "sp_enqueue_purchase_order_email_notification",
        "sp_claim_purchase_order_email_notifications",
        "sp_defer_purchase_order_email_notification",
        "sp_reschedule_purchase_order_email_notification",
        "sp_complete_purchase_order_email_notification",
        "sp_get_purchase_order_email_notification_queue_summary",
        "sp_prepare_and_claim_relex_notification_events",
        "sp_save_relex_notification_envelope",
        "sp_complete_relex_notification_event",
        "sp_get_purchase_order_candidate_summary",
        "sp_get_purchase_order_batch_summary",
        "sp_search_purchase_order_batches",
        "sp_get_purchase_order_batch_candidate_summary",
        "sp_search_purchase_order_batch_candidates"
    ];

    private static readonly string[] TableNames =
    [
        "ApplicationSetting",
        "PurchaseOrderBatch",
        "PurchaseOrderCandidate",
        "PurchaseOrderSubmissionAttempt",
        "PurchaseOrderAudit",
        "PurchaseOrderNotification",
        "PurchaseOrderNotificationAttempt",
        "RelexNotificationEvent"
    ];

    private static readonly string[] ExpectedNotificationColumnContracts =
    [
        "PurchaseOrderNotification:NotificationKey:bigint:False:True",
        "PurchaseOrderNotification:NotificationId:uniqueidentifier:False:False",
        "PurchaseOrderNotification:BatchKey:bigint:True:False",
        "PurchaseOrderNotification:Channel:varchar(50):False:False",
        "PurchaseOrderNotification:TemplateKey:nvarchar(100):True:False",
        "PurchaseOrderNotification:RecipientGroupKey:nvarchar(100):True:False",
        "PurchaseOrderNotification:AttachmentBlobName:nvarchar(512):True:False",
        "PurchaseOrderNotification:EventType:varchar(100):True:False",
        "PurchaseOrderNotification:BusinessCorrelationId:nvarchar(256):True:False",
        "PurchaseOrderNotification:EmailEnvelopeVersion:smallint:True:False",
        "PurchaseOrderNotification:EmailEnvelopeJson:nvarchar(max):True:False",
        "PurchaseOrderNotification:PayloadSha256:binary(32):True:False",
        "PurchaseOrderNotification:Status:varchar(50):False:False",
        "PurchaseOrderNotification:AttemptCount:int:False:False",
        "PurchaseOrderNotification:FailureCount:int:False:False",
        "PurchaseOrderNotification:ThrottleCount:int:False:False",
        "PurchaseOrderNotification:NextAttemptDateTime:datetimeoffset(3):False:False",
        "PurchaseOrderNotification:LastAttemptDateTime:datetimeoffset(3):True:False",
        "PurchaseOrderNotification:LeaseId:uniqueidentifier:True:False",
        "PurchaseOrderNotification:LeaseExpiresDateTime:datetimeoffset(3):True:False",
        "PurchaseOrderNotification:ProviderMessageId:nvarchar(256):True:False",
        "PurchaseOrderNotification:FailureCode:varchar(100):True:False",
        "PurchaseOrderNotification:FailureDescription:nvarchar(1000):True:False",
        "PurchaseOrderNotification:CreatedDateTime:datetimeoffset(3):False:False",
        "PurchaseOrderNotification:SentDateTime:datetimeoffset(3):True:False",
        "PurchaseOrderNotification:CompletedDateTime:datetimeoffset(3):True:False",
        "PurchaseOrderNotification:RowVersion:timestamp:False:False",
        "PurchaseOrderNotificationAttempt:NotificationAttemptKey:bigint:False:True",
        "PurchaseOrderNotificationAttempt:AttemptId:uniqueidentifier:False:False",
        "PurchaseOrderNotificationAttempt:NotificationKey:bigint:False:False",
        "PurchaseOrderNotificationAttempt:AttemptNumber:int:False:False",
        "PurchaseOrderNotificationAttempt:StartedDateTime:datetimeoffset(3):False:False",
        "PurchaseOrderNotificationAttempt:CompletedDateTime:datetimeoffset(3):True:False",
        "PurchaseOrderNotificationAttempt:Outcome:varchar(50):False:False",
        "PurchaseOrderNotificationAttempt:ProviderMessageId:nvarchar(256):True:False",
        "PurchaseOrderNotificationAttempt:FailureCategory:varchar(50):True:False",
        "PurchaseOrderNotificationAttempt:FailureCode:varchar(100):True:False",
        "PurchaseOrderNotificationAttempt:HttpStatusCode:smallint:True:False",
        "RelexNotificationEvent:EventKey:nvarchar(100):False:False",
        "RelexNotificationEvent:NotificationId:uniqueidentifier:False:False",
        "RelexNotificationEvent:BatchKey:bigint:True:False",
        "RelexNotificationEvent:EventType:varchar(100):False:False",
        "RelexNotificationEvent:BusinessCorrelationId:nvarchar(256):False:False",
        "RelexNotificationEvent:OriginalFileName:nvarchar(260):True:False",
        "RelexNotificationEvent:ProcessedFileDateTime:datetimeoffset(3):True:False",
        "RelexNotificationEvent:ProcessingCompletedDateTime:datetimeoffset(3):True:False",
        "RelexNotificationEvent:CreatedDateTime:datetimeoffset(3):False:False",
        "RelexNotificationEvent:CompositionSettingsJson:nvarchar(max):False:False",
        "RelexNotificationEvent:OutcomeRowsJson:nvarchar(max):False:False",
        "RelexNotificationEvent:EmailEnvelopeJson:nvarchar(max):True:False",
        "RelexNotificationEvent:Status:varchar(50):False:False",
        "RelexNotificationEvent:FailureCount:int:False:False",
        "RelexNotificationEvent:NextAttemptDateTime:datetimeoffset(3):False:False",
        "RelexNotificationEvent:LeaseId:uniqueidentifier:True:False",
        "RelexNotificationEvent:LeaseExpiresDateTime:datetimeoffset(3):True:False",
        "RelexNotificationEvent:CompletedDateTime:datetimeoffset(3):True:False",
        "RelexNotificationEvent:FailureCode:varchar(100):True:False",
        "RelexNotificationEvent:RowVersion:timestamp:False:False"
    ];

    private static readonly string[] DeploymentScripts =
    [
        "010-preflight.sql",
        "020-schema.sql",
        "030-operational-tables.sql",
        "035-email-notification-outbox-migration.sql",
        "036-relex-notification-events.sql",
        "040-api-configuration-procedures.sql",
        "050-batch-ingestion-procedures.sql",
        "060-claim-recovery-procedures.sql",
        "070-submission-outcome-procedures.sql",
        "080-support-notification-procedures.sql",
        "081-relex-notification-procedures.sql",
        "085-webapp-procedures.sql",
        "090-security.sql",
        "100-verify.sql"
    ];

    private static readonly string[] AcceptanceFiles =
    [
        "010-api-and-json.sql",
        "020-batch-atomicity.sql",
        "030-claim-recovery.sql",
        "031-claim-concurrency-session-a.sql",
        "032-claim-concurrency-session-b.sql",
        "040-attempt-outcomes.sql",
        "050-support-notification.sql",
        "055-webapp.sql",
        "056-email-notification-outbox.sql",
        "057-email-notification-concurrency-session-a.sql",
        "058-email-notification-concurrency-session-b.sql",
        "059-relex-notification-events.sql",
        "060-permissions.sql"
    ];

    private static readonly string[] DatabaseRoleNames =
    [
        "po_service_executor"
    ];

    private const string EnvironmentSeedTemplateFileName =
        "110-application-settings-seed.template.sql";

    private static readonly string[] ExpectedRoleProcedureGrants = ProcedureNames
        .Select(procedureName => $"po_service_executor:{procedureName}")
        .ToArray();

    private static readonly IReadOnlyDictionary<string, string[]> AcceptanceScenarioContracts =
        new Dictionary<string, string[]>(StringComparer.Ordinal)
        {
            ["010-api-and-json.sql"] =
            [
                "SCENARIO:INVALID_JSON_ROLLBACK",
                "SCENARIO:INVALID_STATUS_ROLLBACK",
                "SCENARIO:CANDIDATE_STATUS_REJECTED",
                "SCENARIO:REPEATED_API_PAYLOAD_DISTINCT_IDS",
                "SCENARIO:DETERMINISTIC_SEARCH_PAGING",
                "[po].[sp_create_purchase_order_candidate]",
                "[po].[sp_search_purchase_order_candidates]",
                "IX_PO_Candidate_Source_Status_AcceptedDateTime"
            ],
            ["020-batch-atomicity.sql"] =
            [
                "SCENARIO:DUPLICATE_RELEX_FILE",
                "FIRST_REGISTRATION_CONFIRMED",
                "SECOND_REGISTRATION_DUPLICATE_REJECTED",
                "PASS:BATCH_DIFFERENT_ROW_AND_CANDIDATE_COUNTS",
                "PASS:BATCH_EXACT_CANDIDATE_REPLAY",
                "PASS:BATCH_CONFLICTING_CANDIDATE_REPLAY_REJECTED",
                "PASS:BATCH_SOURCE_HASH_LOOKUP",
                "PASS:BATCH_ZERO_BYTE_FAILURE",
                "[po].[sp_register_purchase_order_batch]",
                "[po].[sp_add_purchase_order_candidate_to_batch]",
                "[po].[sp_complete_purchase_order_batch]",
                "[po].[sp_get_purchase_order_batch_by_source_hash]",
                "[po].[sp_fail_purchase_order_batch]",
                "@sourceRowCount = 2",
                "ERROR_NUMBER() = 51005",
                "ERROR_NUMBER() = 51006"
            ],
            ["030-claim-recovery.sql"] =
            [
                "PREFLIGHT:NO_EXISTING_LEASES",
                "SCENARIO:LEASE_OWNERSHIP",
                "SCENARIO:LEASE_RENEWAL_AND_RELEASE",
                "SCENARIO:EXPIRED_PREDISPATCH_RECOVERY",
                "[po].[sp_claim_purchase_order_candidates]",
                "[po].[sp_renew_purchase_order_claim]",
                "[po].[sp_release_purchase_order_claim]",
                "[po].[sp_expire_purchase_order_claims]",
                "ERROR_NUMBER() = 51003"
            ],
            ["031-claim-concurrency-session-a.sql"] =
            [
                "CONCURRENCY_PROTOCOL:SESSION_A",
                "PREFLIGHT:NO_EXISTING_LEASES",
                "SESSION_A_READY",
                "WITH NOWAIT",
                "WAITFOR DELAY",
                "[po].[sp_claim_purchase_order_candidates]",
                "CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY",
                "CLEANUP_COMPLETE"
            ],
            ["032-claim-concurrency-session-b.sql"] =
            [
                "CONCURRENCY_PROTOCOL:SESSION_B",
                "SESSION_B_EXCLUSIVE_CLAIM",
                "POST_CLAIM_SESSION_A_LEASE_PROOF",
                "WITH (READUNCOMMITTED)",
                "SET LOCK_TIMEOUT 5000",
                "SET LOCK_TIMEOUT -1",
                "[po].[sp_claim_purchase_order_candidates]"
            ],
            ["040-attempt-outcomes.sql"] =
            [
                "SCENARIO:ATTEMPT_BEGIN_DISPATCH",
                "SCENARIO:UNKNOWN_OUTCOME_NOT_ELIGIBLE",
                "[po].[sp_begin_purchase_order_submission_attempt]",
                "[po].[sp_fail_purchase_order_candidate_pre_dispatch]",
                "[po].[sp_fail_purchase_order_submission]",
                "SCENARIO:PREDISPATCH_FAILURE_TERMINAL",
                "SCENARIO:PREDISPATCH_FAILURE_NONRECOVERABLE",
                "SCENARIO:PREDISPATCH_FAILURE_REJECTS_WRONG_LEASE",
                "SCENARIO:PREDISPATCH_FAILURE_REJECTS_INELIGIBLE_STATUS",
                "SCENARIO:PREDISPATCH_FAILURE_REJECTS_DISPATCHED_ATTEMPT",
                "CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY",
                "UNKNOWN_OUTCOME",
                "NON_RECOVERABLE_ERROR"
            ],
            ["050-support-notification.sql"] =
            [
                "SCENARIO:RETRY_OPTIMISTIC_CONCURRENCY",
                "SCENARIO:CANCEL_OPTIMISTIC_CONCURRENCY",
                "SCENARIO:NOTIFICATION_OPTIMISTIC_CONCURRENCY",
                "SCENARIO:LEGACY_COMPLETION_REJECTS_EMAIL_ENVELOPE",
                "[po].[sp_request_purchase_order_retry]",
                "[po].[sp_cancel_purchase_order_candidate]",
                "[po].[sp_register_purchase_order_notification]",
                "[po].[sp_complete_purchase_order_notification]",
                "ERROR_NUMBER() = 51002"
            ],
            ["055-webapp.sql"] =
            [
                "SCENARIO:WEBAPP_SUMMARY_HALF_OPEN_RANGE",
                "SCENARIO:WEBAPP_SUMMARY_SOURCE_ISOLATION",
                "SCENARIO:WEBAPP_SEARCH_ACCEPTED_RANGE",
                "SCENARIO:WEBAPP_BATCH_SUMMARY_HALF_OPEN_RANGE",
                "SCENARIO:WEBAPP_BATCH_SEARCH_BOUNDED",
                "SCENARIO:WEBAPP_BATCH_CANDIDATE_SUMMARY",
                "SCENARIO:WEBAPP_BATCH_CANDIDATE_SEARCH_BOUNDED",
                "[po].[sp_get_purchase_order_candidate_summary]",
                "[po].[sp_search_purchase_order_candidates]",
                "[po].[sp_get_purchase_order_batch_summary]",
                "[po].[sp_search_purchase_order_batches]",
                "[po].[sp_get_purchase_order_batch_candidate_summary]",
                "[po].[sp_search_purchase_order_batch_candidates]",
                "CLEANUP_SCOPE:FIXED_CANDIDATE_IDS_ONLY"
            ],
            ["056-email-notification-outbox.sql"] =
            [
                "SCENARIO:EMAIL_ENQUEUE_REPLAY_AND_CONFLICT",
                "SCENARIO:EMAIL_ENVELOPE_IDENTITY_REQUIRED",
                "SCENARIO:EMAIL_OPTIONAL_BATCH",
                "SCENARIO:EMAIL_ORDERING_AND_QUOTA",
                "SCENARIO:EMAIL_OUT_OF_ORDER_QUOTA",
                "SCENARIO:EMAIL_ACTIVE_AND_EXPIRED_LEASES",
                "SCENARIO:EMAIL_DEFER_AND_RETRY_COUNTERS",
                "SCENARIO:EMAIL_TERMINAL_OUTCOMES",
                "SCENARIO:EMAIL_HTTP_429_CLASSIFICATION",
                "SCENARIO:EMAIL_EXHAUSTED_TRANSIENT_FAILURE",
                "SCENARIO:EMAIL_STALE_LEASE_AND_ROWVERSION",
                "SCENARIO:EMAIL_QUEUE_SUMMARY_AND_LEGACY_ISOLATION",
                "SCENARIO:EMAIL_UTC_JSON_STATE_AND_SIZE",
                "SCENARIO:EMAIL_OVERSIZED_VALID_ENVELOPE",
                "SCENARIO:EMAIL_MIGRATION_RERUN_ROWVERSION_STABILITY",
                "SCENARIO:EMAIL_ATTEMPT_ID_UNIQUENESS"
            ],
            ["057-email-notification-concurrency-session-a.sql"] =
            [
                "SESSION_A_READY", "SESSION_A_COMMITTED", "WITH NOWAIT",
                "WAITFOR DELAY '00:00:05'", "CLEANUP_SCOPE:FIXED_NOTIFICATION_IDS_ONLY"
            ],
            ["058-email-notification-concurrency-session-b.sql"] =
            [
                "SESSION_B_QUOTA_LOCK_CONTENTION_CONFIRMED",
                "SESSION_B_QUOTA_NOT_DOUBLE_SPENT", "CLEANUP_COMPLETE",
                "CLEANUP_SCOPE:FIXED_NOTIFICATION_IDS_ONLY"
            ],
            ["060-permissions.sql"] =
            [
                "SCENARIO:ROLE_EXECUTE_ALLOWLIST",
                "SCENARIO:NO_DIRECT_TABLE_DML",
                "SCENARIO:API_CONFIGURATION_ISOLATED_TABLE_EXECUTE_AS_ROLE",
                "po_service_executor",
                "sys.database_permissions"
            ],
            ["059-relex-notification-events.sql"] =
            [
                "SCENARIO:RELEX_MIXED_OUTCOMES_AND_FROZEN_SNAPSHOT",
                "SCENARIO:RELEX_INITIAL_READINESS_AND_EMPTY",
                "SCENARIO:RELEX_CUTOFF_EQUALITY_AND_RETRY_HISTORY",
                "SCENARIO:RELEX_ENVELOPE_REPLAY_AND_COMPLETION",
                "SCENARIO:RELEX_STALE_LEASE_REJECTED",
                "SCENARIO:RELEX_LARGE_SNAPSHOT_ISOLATION",
                "[po].[sp_prepare_and_claim_relex_notification_events]",
                "[po].[sp_save_relex_notification_envelope]",
                "[po].[sp_complete_relex_notification_event]"
            ]
        };

    [Fact]
    public void DeploymentScripts_ContainApprovedInventoryInExecutionOrder()
    {
        var scripts = LoadSqlScripts();
        var deploymentScripts = scripts
            .Where(script => string.Equals(
                Path.GetFileName(script.Path),
                "000-deploy.sql",
                StringComparison.OrdinalIgnoreCase))
            .ToArray();

        Assert.True(
            deploymentScripts.Length == 1,
            $"Expected exactly one copied 000-deploy.sql file, but found {deploymentScripts.Length}.");

        AssertDeploymentOrder(deploymentScripts[0].Content);

        var combinedSql = string.Join(
            Environment.NewLine,
            scripts.Select(script => script.Content));
        var sanitizedSql = SanitizeSql(combinedSql);

        AssertProcedureInventory(sanitizedSql);
        AssertTableInventory(sanitizedSql);
    }

    [Fact]
    public void ProcessorPersistence_UsesOneSqlTimedDispatchTransitionWithoutDuplicatedOutcomeState()
    {
        var scripts = LoadSqlScripts();
        var operationalSql = LoadSingleScript(scripts, "030-operational-tables.sql");
        var claimSql = LoadSingleScript(scripts, "060-claim-recovery-procedures.sql");
        var submissionSql = LoadSingleScript(scripts, "070-submission-outcome-procedures.sql");

        Assert.Contains(
            "CREATE OR ALTER PROCEDURE [po].[sp_begin_purchase_order_submission_attempt]",
            submissionSql,
            StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain(
            "sp_create_purchase_order_submission_attempt",
            submissionSql,
            StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain(
            "sp_mark_purchase_order_attempt_dispatched",
            submissionSql,
            StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("'PREPARED'", operationalSql, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("[UnknownOutcome]", operationalSql, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("[RowVersion] rowversion", ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderSubmissionAttempt"), StringComparison.OrdinalIgnoreCase);

        var processorSql = claimSql + Environment.NewLine + submissionSql;
        Assert.DoesNotMatch(
            @"@(claimed|renewed|released|asOf|prepared|dispatched|failed|completed)DateTime\s+datetimeoffset",
            processorSql);
        Assert.DoesNotContain("@expectedAttemptRowVersion", processorSql, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("[UnknownOutcome]", processorSql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("SYSUTCDATETIME()", claimSql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("SYSUTCDATETIME()", submissionSql, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void ConfigurationProcedure_UsesPoOwnedTableWithoutCrossSchemaImpersonation()
    {
        var scripts = LoadSqlScripts();
        var preflight = NormalizeSql(LoadSingleScript(scripts, "010-preflight.sql"));
        var apiConfigurationSql = LoadSingleScript(
            scripts,
            "040-api-configuration-procedures.sql");
        var apiConfiguration = NormalizeSql(apiConfigurationSql);
        var verification = NormalizeSql(LoadSingleScript(scripts, "100-verify.sql"));

        Assert.Matches(
            @"IF EXISTS\s*\(\s*SELECT 1 FROM sys\.schemas.*?\[name\] = N?'po'.*?\[principal_id\] <> DATABASE_PRINCIPAL_ID\s*\(\s*N?'dbo'\s*\).*?\) BEGIN ;?THROW 51000\b",
            preflight);
        Assert.Matches(
            @"OBJECT_ID\s*\(\s*N?'\[po\]\.\[ApplicationSetting\]'\s*,\s*N?'U'\s*\) IS NOT NULL.*?FROM sys\.indexes AS applicationSettingPrimaryKey.*?applicationSettingPrimaryKey\.\[name\] = N?'PK_PO_ApplicationSetting'.*?applicationSettingPrimaryKey\.\[is_primary_key\] = 1.*?contextIndexColumn\.\[key_ordinal\] = 1.*?contextColumn\.\[name\] = N?'Context'.*?keyIndexColumn\.\[key_ordinal\] = 2.*?keyColumn\.\[name\] = N?'Key'.*?THROW 51000\b",
            preflight);
        Assert.Matches(
            @"CREATE OR ALTER PROCEDURE \[po\]\.\[sp_get_application_settings\] @contextList nvarchar\(max\) AS\b",
            apiConfiguration);
        Assert.DoesNotContain("WITH EXECUTE AS OWNER", apiConfiguration, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("[orders]", preflight + " " + apiConfiguration + " " + verification, StringComparison.OrdinalIgnoreCase);
        Assert.Matches(
            @"FROM \[po\]\.\[ApplicationSetting\] AS setting",
            apiConfiguration);
        Assert.Matches(
            @"ROW_NUMBER\s*\(\s*\)\s+OVER\s*\(\s*PARTITION BY setting\.\[Key\]\s+ORDER BY requested\.\[ContextOrdinal\] DESC",
            apiConfiguration);
        Assert.Matches(
            @"CREATE OR ALTER PROCEDURE \[po\]\.\[sp_get_application_settings\].*?END; GO ALTER AUTHORIZATION ON OBJECT::\[po\]\.\[sp_get_application_settings\] TO SCHEMA OWNER; GO CREATE OR ALTER PROCEDURE \[po\]\.\[sp_create_purchase_order_candidate\]",
            apiConfiguration);
        Assert.Matches(
            @"FROM sys\.schemas.*?\[name\] = N?'po'.*?\[principal_id\] = DATABASE_PRINCIPAL_ID\s*\(\s*N?'dbo'\s*\).*?THROW 51000\b",
            verification);
        Assert.Matches(
            @"sys\.sql_modules.*?OBJECT_ID\s*\(\s*N?'\[po\]\.\[sp_get_application_settings\]'\s*,\s*N?'P'\s*\).*?\[execute_as_principal_id\] IS NULL.*?THROW 51000\b",
            verification);
        Assert.Matches(
            @"FROM sys\.objects AS wrapperObject INNER JOIN sys\.schemas AS wrapperSchema ON wrapperSchema\.\[schema_id\] = wrapperObject\.\[schema_id\].*?wrapperObject\.\[object_id\] = OBJECT_ID\s*\(\s*N?'\[po\]\.\[sp_get_application_settings\]'\s*,\s*N?'P'\s*\).*?COALESCE\s*\(\s*wrapperObject\.\[principal_id\]\s*,\s*wrapperSchema\.\[principal_id\]\s*\) = DATABASE_PRINCIPAL_ID\s*\(\s*N?'dbo'\s*\).*?THROW 51000\b",
            verification);
        Assert.DoesNotMatch(
            @"sys\.schemas.*?\[name\] = N?'orders'.*?\[principal_id\]",
            preflight + " " + verification);
    }

    [Fact]
    public void PermissionsAcceptance_ExecutesIsolatedConfigurationProcedureAsSyntheticServiceRole()
    {
        var permissionsSql = File.ReadAllText(Path.Combine(
            GetAcceptanceDirectory(),
            "060-permissions.sql"));
        var normalizedSql = NormalizeSql(permissionsSql);

        Assert.Contains(
            "SCENARIO:API_CONFIGURATION_ISOLATED_TABLE_EXECUTE_AS_ROLE",
            permissionsSql,
            StringComparison.Ordinal);
        Assert.Matches(
            @"CREATE USER \[po_acceptance_service_executor\] WITHOUT LOGIN",
            normalizedSql);
        Assert.Matches(
            @"ALTER ROLE \[po_service_executor\] ADD MEMBER \[po_acceptance_service_executor\]",
            normalizedSql);
        Assert.Matches(
            @"IF EXISTS\s*\(.*?FROM \[po\]\.\[ApplicationSetting\].*?\[Key\] IN\s*\(\s*N?'Acceptance:SharedKey'\s*,\s*N?'Acceptance:CommonOnly'\s*\).*?THROW 520\d{2}",
            normalizedSql);
        Assert.Matches(
            @"OR EXISTS\s*\(.*?FROM sys\.database_role_members.*?WHERE workloadRole\.\[name\] <> N?'po_service_executor'.*?memberPrincipal\.\[name\] = N?'po_acceptance_service_executor'.*?\)",
            normalizedSql);
        Assert.Matches(
            @"CREATE TABLE #applicationSettings\s*\(\s*\[key\] nvarchar\(256\).*?\[value\] nvarchar\(max\).*?\)",
            normalizedSql);
        Assert.Matches(
            @"BEGIN TRANSACTION.*?INSERT INTO \[po\]\.\[ApplicationSetting\].*?EXECUTE AS USER = N?'po_acceptance_service_executor'.*?CREATE TABLE #applicationSettings.*?INSERT INTO #applicationSettings.*?EXEC \[po\]\.\[sp_get_application_settings\] @contextList = N?'Common,WebApi'",
            normalizedSql);
        Assert.Matches(
            @"IF NOT EXISTS\s*\(.*?FROM #applicationSettings.*?\[key\] = N?'Acceptance:SharedKey'.*?\[value\] = N?'web-api-value'.*?\).*?THROW 520\d{2}",
            normalizedSql);
        Assert.True(
            Regex.Matches(normalizedSql, @"\bREVERT\b").Count >= 2,
            "The impersonated acceptance session must REVERT on success and failure.");
        Assert.Matches(
            @"BEGIN CATCH.*?IF @isImpersonating = 1 BEGIN REVERT;.*?END; IF XACT_STATE\s*\(\s*\) <> 0 BEGIN ROLLBACK TRANSACTION; END; THROW; END CATCH",
            normalizedSql);
        Assert.DoesNotMatch(
            @"\bSELECT\s+(?:\*|\[key\]|\[value\]).*?\bFROM #applicationSettings\b|\bPRINT\b.*?applicationSettings",
            normalizedSql);
        Assert.Contains(
            "PRINT 'PASS:SCENARIO:API_CONFIGURATION_ISOLATED_TABLE_EXECUTE_AS_ROLE'",
            permissionsSql,
            StringComparison.Ordinal);
    }

    [Fact]
    public void ApplicationSettingSeedTemplate_IsSeparateFromDeploymentAndFailsOnPlaceholders()
    {
        var scripts = LoadSqlScripts();
        var deploySql = LoadSingleScript(scripts, "000-deploy.sql");
        var seedTemplate = LoadSingleScript(scripts, EnvironmentSeedTemplateFileName);

        Assert.DoesNotContain(EnvironmentSeedTemplateFileName, deploySql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("[po].[ApplicationSetting]", seedTemplate, StringComparison.Ordinal);
        Assert.Contains("__REPLACE_", seedTemplate, StringComparison.Ordinal);
        Assert.Contains("WHERE [Value] LIKE N'__REPLACE[_]%'", seedTemplate, StringComparison.Ordinal);
        Assert.Matches(@"THROW 51004", NormalizeSql(seedTemplate));
        Assert.DoesNotContain("Password", seedTemplate, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("ConnectionString", seedTemplate, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void AcceptancePack_ContainsExactGuardedFilesAndCleanupContracts()
    {
        var acceptanceDirectory = GetAcceptanceDirectory();
        var actualFiles = Directory
            .GetFiles(acceptanceDirectory, "*.sql", SearchOption.TopDirectoryOnly)
            .Select(Path.GetFileName)
            .OrderBy(fileName => fileName, StringComparer.Ordinal)
            .ToArray();

        Assert.Equal(
            AcceptanceFiles.OrderBy(fileName => fileName, StringComparer.Ordinal),
            actualFiles);

        foreach (var fileName in AcceptanceFiles.Where(fileName => fileName.EndsWith(".sql", StringComparison.Ordinal)))
        {
            var sql = File.ReadAllText(Path.Combine(acceptanceDirectory, fileName));
            Assert.Matches(
                @"^SET NOCOUNT ON; SET QUOTED_IDENTIFIER ON;",
                NormalizeSql(sql));
            AssertAcceptanceGuard(fileName, sql);
            Assert.Contains("PRINT 'PASS:", sql, StringComparison.Ordinal);
            Assert.DoesNotContain("@blobName", sql, StringComparison.OrdinalIgnoreCase);
            Assert.True(
                Regex.Matches(SanitizeSql(sql), @"\bTHROW\s+52\d{3}\b").Count >= 2,
                $"{fileName} must fail closed at its guard and on an unexpected scenario result.");
        }

        foreach (var fileName in AcceptanceScenarioContracts.Keys.Except(
                     [
                         "031-claim-concurrency-session-a.sql",
                         "032-claim-concurrency-session-b.sql",
                         "057-email-notification-concurrency-session-a.sql",
                         "058-email-notification-concurrency-session-b.sql",
                         "040-attempt-outcomes.sql"
                     ],
                     StringComparer.Ordinal))
        {
            var sql = File.ReadAllText(Path.Combine(acceptanceDirectory, fileName));
            var normalizedSql = NormalizeSql(sql);

            Assert.Matches(@"\bBEGIN TRANSACTION\b", normalizedSql);
            Assert.Matches(@"IF XACT_STATE\s*\(\s*\) <> 0 BEGIN ROLLBACK TRANSACTION; END", normalizedSql);
            Assert.DoesNotMatch(@"\bCOMMIT TRANSACTION\b", normalizedSql);
        }

        var sessionA = File.ReadAllText(Path.Combine(
            acceptanceDirectory,
            "031-claim-concurrency-session-a.sql"));
        var sessionB = File.ReadAllText(Path.Combine(
            acceptanceDirectory,
            "032-claim-concurrency-session-b.sql"));
        Assert.Matches(@"\bBEGIN TRANSACTION\b.*?SESSION_A_READY.*?WAITFOR DELAY.*?\bROLLBACK TRANSACTION\b", NormalizeSql(sessionA));
        Assert.Contains("DELETE FROM [po].[PurchaseOrderAudit]", sessionA, StringComparison.Ordinal);
        Assert.Contains("DELETE FROM [po].[PurchaseOrderCandidate]", sessionA, StringComparison.Ordinal);
        Assert.DoesNotContain("DELETE FROM", sessionB, StringComparison.OrdinalIgnoreCase);

        var attemptOutcomes = File.ReadAllText(Path.Combine(
            acceptanceDirectory,
            "040-attempt-outcomes.sql"));
        var normalizedAttemptOutcomes = NormalizeSql(attemptOutcomes);
        var attemptCleanupDeletes = normalizedAttemptOutcomes
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(statement => Regex.IsMatch(statement, @"\bDELETE\b"))
            .ToArray();

        Assert.Matches(@"\bBEGIN TRANSACTION\b", normalizedAttemptOutcomes);
        Assert.Matches(
            @"IF XACT_STATE\s*\(\s*\) <> 0 BEGIN ROLLBACK TRANSACTION; END",
            normalizedAttemptOutcomes);
        Assert.Equal(3, Regex.Matches(normalizedAttemptOutcomes, @"\bCOMMIT TRANSACTION\b").Count);
        Assert.Equal(
            3,
            Regex.Matches(
                attemptOutcomes,
                "CLEANUP_SCOPE:FIXED_CANDIDATE_ID_ONLY",
                RegexOptions.CultureInvariant).Count);
        Assert.Equal(9, attemptCleanupDeletes.Length);
        Assert.All(
            attemptCleanupDeletes,
            statement => Assert.Contains(
                "@preDispatchGuardCandidateId",
                statement,
                StringComparison.Ordinal));
    }

    [Fact]
    public void AcceptanceConcurrency_IsRaceSafeAndRecoverable()
    {
        var acceptanceDirectory = GetAcceptanceDirectory();
        var duplicateSql = NormalizeSql(File.ReadAllText(Path.Combine(
            acceptanceDirectory,
            "020-batch-atomicity.sql")));
        var claimRecovery = NormalizeSql(File.ReadAllText(Path.Combine(
            acceptanceDirectory,
            "030-claim-recovery.sql")));
        var sessionA = File.ReadAllText(Path.Combine(
            acceptanceDirectory,
            "031-claim-concurrency-session-a.sql"));
        var normalizedSessionA = NormalizeSql(sessionA);
        var sessionB = File.ReadAllText(Path.Combine(
            acceptanceDirectory,
            "032-claim-concurrency-session-b.sql"));
        var normalizedSessionB = NormalizeSql(sessionB);

        Assert.Matches(
            @"INSERT INTO @firstRegistrationResult EXEC \[po\]\.\[sp_register_purchase_order_batch\].*?@batchId = @duplicateBatchOne.*?SET @firstRegistrationConfirmed = 1;.*?SET @secondRegistrationAttempted = 1;.*?EXEC \[po\]\.\[sp_register_purchase_order_batch\].*?@batchId = @duplicateBatchTwo",
            duplicateSql);
        Assert.Matches(
            @"IF ERROR_NUMBER\s*\(\s*\) = 51005 AND @firstRegistrationConfirmed = 1 AND @secondRegistrationAttempted = 1 BEGIN SET @duplicateRejected = 1; END",
            duplicateSql);

        Assert.Matches(
            @"IF EXISTS\s*\(\s*SELECT 1 FROM \[po\]\.\[PurchaseOrderCandidate\] WHERE \[LeaseToken\] IS NOT NULL\s*\) BEGIN ;THROW 52\d{3}\b",
            claimRecovery);
        Assert.Matches(
            @"IF EXISTS\s*\(\s*SELECT 1 FROM \[po\]\.\[PurchaseOrderCandidate\] WHERE \[LeaseToken\] IS NOT NULL\s*\) BEGIN ;THROW 52\d{3}\b",
            normalizedSessionA);
        var sessionACleanupDeletes = normalizedSessionA
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(statement => Regex.IsMatch(statement, @"\bDELETE\b"))
            .ToArray();
        Assert.Equal(9, sessionACleanupDeletes.Length);
        Assert.All(
            sessionACleanupDeletes,
            statement => Assert.Contains("@concurrencyCandidateId", statement, StringComparison.Ordinal));

        Assert.Matches(
            @"IF @@LOCK_TIMEOUT <> -1 BEGIN ;THROW 52\d{3}\b.*?END; SET LOCK_TIMEOUT 5000; BEGIN TRY BEGIN TRANSACTION; INSERT INTO @sessionBClaims EXEC \[po\]\.\[sp_claim_purchase_order_candidates\].*?IF XACT_STATE\s*\(\s*\) <> 0 BEGIN ROLLBACK TRANSACTION; END; SET LOCK_TIMEOUT -1; END TRY BEGIN CATCH IF XACT_STATE\s*\(\s*\) <> 0 BEGIN ROLLBACK TRANSACTION; END; SET LOCK_TIMEOUT -1; THROW; END CATCH",
            normalizedSessionB);
        Assert.Equal(2, Regex.Matches(normalizedSessionB, @"\bSET LOCK_TIMEOUT -1\b").Count);
        Assert.True(
            Regex.Matches(normalizedSessionB, @"WITH \(READUNCOMMITTED\)").Count >= 2,
            "Session B requires nonblocking readiness and post-claim probes.");
        Assert.Matches(
            @"WITH \(READUNCOMMITTED\).*?\[CandidateId\] = @concurrencyCandidateId.*?\[LeaseOwner\] = N'acceptance-concurrency-session-a'.*?\[LeaseToken\] IS NOT NULL",
            normalizedSessionB);
        Assert.Contains("POST_CLAIM_SESSION_A_LEASE_PROOF", sessionB, StringComparison.Ordinal);
        Assert.True(
            sessionB.IndexOf("POST_CLAIM_SESSION_A_LEASE_PROOF", StringComparison.Ordinal) >
            sessionB.IndexOf("EXEC [po].[sp_claim_purchase_order_candidates]", StringComparison.Ordinal),
            "Session B must prove Session A still owns the fixed lease after the claim call returns empty.");
    }

    [Fact]
    public void AcceptancePack_CoversApprovedSqlScenarios()
    {
        var acceptanceDirectory = GetAcceptanceDirectory();

        foreach (var (fileName, requiredContracts) in AcceptanceScenarioContracts)
        {
            var content = File.ReadAllText(Path.Combine(acceptanceDirectory, fileName));
            foreach (var requiredContract in requiredContracts)
            {
                Assert.Contains(requiredContract, content, StringComparison.Ordinal);
            }
        }
    }

    [Fact]
    public void DeclarationDiscovery_IgnoresCommentsStringsAndInlineStatements()
    {
        const string sql = """
            -- CREATE OR ALTER PROCEDURE [po].[line_comment_fake]
            /* outer comment
            CREATE OR ALTER PROCEDURE [po].[block_comment_fake]
            /* nested comment
            CREATE TABLE [po].[nested_block_fake]
            */
            CREATE OR ALTER PROCEDURE [po].[outer_after_nested_fake]
            */
            DECLARE @unicodeStatement nvarchar(max) = N'
            ''escaped quote''
            CREATE OR ALTER PROCEDURE [po].[unicode_string_fake]
            ';
            DECLARE @regularStatement varchar(max) = '
            ''escaped quote''
            CREATE TABLE [po].[regular_string_fake]
            ';
            SELECT 1; CREATE OR ALTER PROCEDURE [po].[inline_procedure_fake]
            SELECT 1; CREATE TABLE [po].[inline_table_fake]
                CREATE OR ALTER PROCEDURE [po].[real_procedure]
                CREATE TABLE [po].[RealTable]
            """;

        var sanitizedSql = SanitizeSql(sql);

        Assert.Equal(
            sql.Count(character => character == '\n'),
            sanitizedSql.Count(character => character == '\n'));

        foreach (var hiddenIdentifier in new[]
                 {
                     "line_comment_fake",
                     "block_comment_fake",
                     "nested_block_fake",
                     "outer_after_nested_fake",
                     "unicode_string_fake",
                     "regular_string_fake"
                 })
        {
            Assert.DoesNotContain(hiddenIdentifier, sanitizedSql);
        }

        Assert.Equal(
            new[] { "real_procedure" },
            DiscoverProcedureNames(sanitizedSql));
        Assert.Equal(
            new[] { "RealTable" },
            DiscoverTableNames(sanitizedSql));
    }

    [Fact]
    public void SchemaScripts_ContainApprovedSchemaStatusConstraintsAndIndexes()
    {
        var scripts = LoadSqlScripts();
        var schemaSql = LoadSingleScript(scripts, "020-schema.sql");
        var operationalSql = LoadSingleScript(scripts, "030-operational-tables.sql");

        AssertSchemaContract(schemaSql);
        AssertOperationalKeyContract(operationalSql);
        AssertOperationalCheckContract(operationalSql);
        AssertOperationalForeignKeyContract(operationalSql);
        AssertOperationalIndexContract(operationalSql);
        Assert.Matches(
            @"UPDATE \[po\]\.\[PurchaseOrderBatch\] SET \[Status\] = 'COMPLETED' WHERE \[Status\] IN \(\s*'READY_FOR_SUBMISSION'\s*,\s*'PROCESSING'\s*\)",
            NormalizeSql(operationalSql));
    }

    [Fact]
    public void Preflight_RejectsLegacyStatusLookupTables()
    {
        var preflightSql = NormalizeSql(LoadSingleScript(
            LoadSqlScripts(),
            "010-preflight.sql"));

        foreach (var tableName in LegacyStatusTableNames)
        {
            Assert.Matches(
                $@"OBJECT_ID\s*\(\s*N?'\[po\]\.\[{Regex.Escape(tableName)}\]'\s*,\s*N?'U'\s*\)\s+IS\s+NOT\s+NULL",
                preflightSql);
        }

        Assert.Contains(
            "legacy status lookup tables",
            preflightSql,
            StringComparison.OrdinalIgnoreCase);
        Assert.Contains(
            "fresh database is required",
            preflightSql,
            StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void NotificationOutboxMigration_AcceptsOnlyKnownShapesAndPreservesLegacyPayloadHistory()
    {
        var scripts = LoadSqlScripts();
        var preflightSql = NormalizeSql(LoadSingleScript(scripts, "010-preflight.sql"));
        var operationalSql = NormalizeSql(LoadSingleScript(
            scripts,
            "030-operational-tables.sql"));
        var migrationSql = NormalizeSql(LoadSingleScript(
            scripts,
            "035-email-notification-outbox-migration.sql"));

        Assert.Matches(
            @"VALUES\s*\(\s*N?'NotificationKey'\s*,\s*N?'bigint'\s*,\s*CAST\s*\(\s*0\s+AS\s+bit\s*\)\s*,\s*CAST\s*\(\s*1\s+AS\s+bit\s*\)\s*\)\s*,\s*\(\s*N?'NotificationId'\s*,\s*N?'uniqueidentifier'\s*,\s*CAST\s*\(\s*0\s+AS\s+bit\s*\)\s*,\s*CAST\s*\(\s*0\s+AS\s+bit\s*\)\s*\)\s*,\s*\(\s*N?'BatchKey'\s*,\s*N?'bigint'\s*,\s*CAST\s*\(\s*0\s+AS\s+bit\s*\)\s*,\s*CAST\s*\(\s*0\s+AS\s+bit\s*\)\s*\)",
            preflightSql);
        Assert.Matches(
            @"actualColumn\.is_nullable\s*<>\s*expected\.IsNullable\s+AND\s+NOT\s*\(\s*expected\.ColumnName\s*=\s*N?'BatchKey'\s+AND\s+actualColumn\.is_nullable\s+IN\s*\(\s*0\s*,\s*1\s*\)\s*\)",
            preflightSql);
        Assert.Contains("THROW 51000", preflightSql, StringComparison.OrdinalIgnoreCase);

        Assert.Matches(
            @"IF COL_LENGTH\s*\(\s*N?'\[po\]\.\[PurchaseOrderNotification\]'\s*,\s*N?'NextAttemptDateTime'\s*\)\s+IS\s+NOT\s+NULL\s+AND\s+NOT\s+EXISTS\s*\(.*?IX_PO_Notification_DueWork.*?CREATE\s+NONCLUSTERED\s+INDEX\s+\[IX_PO_Notification_DueWork\]",
            operationalSql);

        Assert.Contains("COL_LENGTH", migrationSql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("sys.columns", migrationSql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("sys.check_constraints", migrationSql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("sys.indexes", migrationSql, StringComparison.OrdinalIgnoreCase);
        Assert.Matches(
            @"UPDATE \[po\]\.\[PurchaseOrderNotification\] SET \[AttemptCount\] = COALESCE\s*\(\s*\[AttemptCount\]\s*,\s*0\s*\)\s*,\s*\[FailureCount\] = COALESCE\s*\(\s*\[FailureCount\]\s*,\s*0\s*\)\s*,\s*\[ThrottleCount\] = COALESCE\s*\(\s*\[ThrottleCount\]\s*,\s*0\s*\)\s*,\s*\[NextAttemptDateTime\] = COALESCE\s*\(\s*\[NextAttemptDateTime\]\s*,\s*\[CreatedDateTime\]\s*\)\s*,\s*\[CompletedDateTime\] = CASE WHEN \[Status\] = 'SENT' THEN COALESCE\s*\(\s*\[CompletedDateTime\]\s*,\s*\[SentDateTime\]\s*\) ELSE \[CompletedDateTime\] END",
            migrationSql);
        Assert.DoesNotMatch(
            @"UPDATE\s+\[po\]\.\[PurchaseOrderNotification\]\s+SET.*?\[(?:EventType|BusinessCorrelationId|EmailEnvelopeVersion|EmailEnvelopeJson|PayloadSha256)\]\s*=",
            migrationSql);
    }

    [Fact]
    public void NotificationOutboxMigration_SeparatesColumnCreationFromDependentStatements()
    {
        var migrationSql = LoadSingleScript(
            LoadSqlScripts(),
            "035-email-notification-outbox-migration.sql");
        var batches = Regex
            .Split(
                migrationSql,
                @"^\s*GO\s*$",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Where(batch => !string.IsNullOrWhiteSpace(batch))
            .ToArray();

        var columnCreationBatchIndex = Array.FindIndex(
            batches,
            batch => batch.Contains(
                "ADD [CompletedDateTime] datetimeoffset(3) NULL",
                StringComparison.OrdinalIgnoreCase));
        var firstDependentBatchIndex = Array.FindIndex(
            batches,
            batch => batch.Contains(
                "UPDATE [po].[PurchaseOrderNotification]",
                StringComparison.OrdinalIgnoreCase));

        Assert.True(columnCreationBatchIndex >= 0, "Expected the final guarded column addition.");
        Assert.True(firstDependentBatchIndex >= 0, "Expected the legacy-row backfill.");
        Assert.True(
            columnCreationBatchIndex < firstDependentBatchIndex,
            "SQL Server must compile statements that reference new columns in a later batch than the ALTER TABLE additions.");
    }

    [Fact]
    public void NotificationOutboxMigration_BackfillsOnlyRowsWithMissingValues()
    {
        var migrationSql = NormalizeSql(LoadSingleScript(
            LoadSqlScripts(),
            "035-email-notification-outbox-migration.sql"));
        var backfill = Regex.Match(
            migrationSql,
            @"UPDATE \[po\]\.\[PurchaseOrderNotification\] SET .*?;",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Value;

        Assert.NotEmpty(backfill);
        // Break: a repeat deployment updates an already-migrated SENDING row and invalidates
        // the rowversion held by the worker that owns its active lease.
        Assert.Matches(
            @"WHERE \[AttemptCount\] IS NULL OR \[FailureCount\] IS NULL OR \[ThrottleCount\] IS NULL OR \[NextAttemptDateTime\] IS NULL OR \(\[Status\] = 'SENT' AND \[CompletedDateTime\] IS NULL AND \[SentDateTime\] IS NOT NULL\);$",
            backfill);
    }

    [Fact]
    public void EmailOutboxAcceptance_RerunsMigrationWithoutChangingAlreadyMigratedRowVersions()
    {
        var acceptanceSql = File.ReadAllText(Path.Combine(
            GetAcceptanceDirectory(),
            "056-email-notification-outbox.sql"));
        var normalizedSql = NormalizeSql(acceptanceSql);
        var scenarioStart = acceptanceSql.IndexOf(
            "SCENARIO:EMAIL_MIGRATION_RERUN_ROWVERSION_STABILITY",
            StringComparison.Ordinal);
        var migrationInclude = acceptanceSql.IndexOf(
            @":r ..\035-email-notification-outbox-migration.sql",
            scenarioStart,
            StringComparison.Ordinal);

        // Break: static migration checks pass while the guarded acceptance pack never executes
        // the real migration against active and terminal target-shape rows.
        Assert.Contains(
            "SCENARIO:EMAIL_MIGRATION_RERUN_ROWVERSION_STABILITY",
            acceptanceSql,
            StringComparison.Ordinal);
        Assert.Contains(
            @":r ..\035-email-notification-outbox-migration.sql",
            acceptanceSql,
            StringComparison.Ordinal);
        Assert.True(scenarioStart >= 0, "Expected the migration-rerun acceptance scenario.");
        Assert.True(migrationInclude > scenarioStart, "Expected the migration include after fixture setup.");
        var scenarioSetup = NormalizeSql(acceptanceSql[scenarioStart..migrationInclude]);
        Assert.Matches(
            @"CREATE TABLE #migrationRowVersions.*?\[NotificationId\] uniqueidentifier.*?\[RowVersion\] binary\(8\).*?INSERT INTO #migrationRowVersions.*?FROM \[po\]\.\[PurchaseOrderNotification\].*?WHERE \[NotificationId\] IN",
            scenarioSetup);
        Assert.Matches(
            @"VALUES .*?'PENDING'.*?'SENDING'.*?'SENT'",
            scenarioSetup);
        Assert.Matches(
            @"JOIN #migrationRowVersions AS original.*?notification\.\[RowVersion\] <> original\.\[RowVersion\].*?THROW 52\d{3}",
            normalizedSql);
    }

    [Fact]
    public void EmailOutboxAcceptance_OversizedEnvelopeIsOtherwiseValidAndProvesItsSize()
    {
        var acceptanceSql = File.ReadAllText(Path.Combine(
            GetAcceptanceDirectory(),
            "056-email-notification-outbox.sql"));
        var normalizedSql = NormalizeSql(acceptanceSql);

        // Break: the oversized fixture is rejected for absent identity metadata or malformed
        // JSON, so the acceptance marker does not prove enforcement of the 20 MiB boundary.
        Assert.Contains(
            "SCENARIO:EMAIL_OVERSIZED_VALID_ENVELOPE",
            acceptanceSql,
            StringComparison.Ordinal);
        Assert.Contains(
            "WHEN 11 THEN N'{\"notificationId\":\"A5600000-0000-4000-8000-000000000001\",\"businessCorrelationId\":\"SYNTHETIC-EMAIL\",\"schemaVersion\":1,\"padding\":\"'",
            normalizedSql,
            StringComparison.Ordinal);
        Assert.Matches(
            @"IF @invalidCase = 11 AND \(ISJSON\(@invalidEnvelope\) <> 1 OR DATALENGTH\(@invalidEnvelope\) <= 20 \* 1024 \* 1024\) BEGIN ;THROW 52\d{3}",
            normalizedSql);
    }

    [Fact]
    public void Verification_DescribesOnlyTargetNotificationColumnShape()
    {
        var verificationSql = LoadSingleScript(LoadSqlScripts(), "100-verify.sql");
        var expectedColumns = JsonDocument.Parse(ReadJsonManifest(
                verificationSql,
                "expectedNotificationColumns"))
            .RootElement
            .EnumerateArray()
            .Select(column => string.Join(
                ':',
                column.GetProperty("table").GetString(),
                column.GetProperty("column").GetString(),
                column.GetProperty("type").GetString(),
                column.GetProperty("nullable").GetBoolean(),
                column.GetProperty("identity").GetBoolean()))
            .ToArray();

        Assert.Equal(ExpectedNotificationColumnContracts, expectedColumns);
        var verificationCode = NormalizeSql(verificationSql);
        Assert.Contains("OPENJSON(@expectedNotificationColumns)", verificationCode, StringComparison.OrdinalIgnoreCase);
        Assert.Matches(
            @"FROM sys\.columns AS actualColumn.*?sys\.types AS actualType.*?actualColumn\.\[is_nullable\] = expected\.\[IsNullable\].*?actualColumn\.\[is_identity\] = expected\.\[IsIdentity\].*?THROW 51000",
            verificationCode);
        Assert.DoesNotContain("IX_PO_Notification_Status_CreatedDateTime", verificationSql, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Verification_ComparesStatusConstraintDefinitionsCaseSensitively()
    {
        var verificationSql = NormalizeSql(LoadSingleScript(
            LoadSqlScripts(),
            "100-verify.sql"));
        var comparisonStart = verificationSql.IndexOf(
            "FROM OPENJSON(@expectedStatusConstraints)",
            StringComparison.OrdinalIgnoreCase);
        var comparisonEnd = verificationSql.IndexOf(
            "OR ( SELECT COUNT_BIG(*)",
            comparisonStart,
            StringComparison.OrdinalIgnoreCase);

        Assert.True(comparisonStart >= 0, "Expected the status-constraint manifest comparison.");
        Assert.True(comparisonEnd > comparisonStart, "Expected the status-constraint count check.");

        var comparisonSql = verificationSql[comparisonStart..comparisonEnd];
        Assert.DoesNotContain("UPPER(", comparisonSql, StringComparison.OrdinalIgnoreCase);
        Assert.Equal(
            2,
            Regex.Matches(
                comparisonSql,
                @"COLLATE\s+Latin1_General_100_BIN2",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Count);
    }

    [Fact]
    public void WebAppProcedures_ExposeBoundedAcceptedTimeSummaryAndSearch()
    {
        var scripts = LoadSqlScripts();
        var summary = NormalizeSql(LoadSingleScript(scripts, "085-webapp-procedures.sql"));
        var search = NormalizeSql(LoadSingleScript(
            scripts,
            "040-api-configuration-procedures.sql"));

        Assert.Matches(
            @"sp_get_purchase_order_candidate_summary\] @source nvarchar\(50\), @afterDateTimeUtc datetimeoffset\(3\), @untilDateTimeUtc datetimeoffset\(3\) AS\b",
            summary);
        Assert.Matches(
            @"DATEPART\s*\(\s*TZOFFSET\s*,\s*@afterDateTimeUtc\s*\) <> 0",
            summary);
        Assert.Matches(
            @"@afterDateTimeUtc >= @untilDateTimeUtc.*?THROW 51004",
            summary);
        Assert.Matches(
            @"\[Source\] = @source.*?\[AcceptedDateTime\] >= @afterDateTimeUtc.*?\[AcceptedDateTime\] < @untilDateTimeUtc",
            summary);
        Assert.Matches(@"GROUP BY \[Status\]", summary);
        Assert.Matches(
            @"@acceptedAfterDateTimeUtc datetimeoffset\(3\) = NULL",
            search);
        Assert.Matches(
            @"@acceptedUntilDateTimeUtc datetimeoffset\(3\) = NULL",
            search);
        Assert.Matches(
            @"@acceptedAfterDateTimeUtc IS NULL OR \[candidate\]\.\[AcceptedDateTime\] >= @acceptedAfterDateTimeUtc",
            search);
        Assert.Matches(
            @"@acceptedUntilDateTimeUtc IS NULL OR \[candidate\]\.\[AcceptedDateTime\] < @acceptedUntilDateTimeUtc",
            search);
    }

    [Fact]
    public void WebAppBatchProcedures_ExposeBoundedFileAndBatchScopedCandidateReads()
    {
        var sql = NormalizeSql(LoadSingleScript(
            LoadSqlScripts(),
            "085-webapp-procedures.sql"));

        Assert.Matches(
            @"sp_get_purchase_order_batch_summary\] @source nvarchar\(50\), @afterDateTimeUtc datetimeoffset\(3\), @untilDateTimeUtc datetimeoffset\(3\) AS\b.*?CASE WHEN \[Status\] IN\s*\(\s*'INGESTING'\s*,\s*'READY_FOR_SUBMISSION'\s*,\s*'PROCESSING'\s*\) THEN 'PROCESSING' ELSE \[Status\] END AS \[Status\].*?\[Source\] = @source.*?\[DiscoveredDateTime\] >= @afterDateTimeUtc.*?\[DiscoveredDateTime\] < @untilDateTimeUtc.*?GROUP BY CASE WHEN \[Status\] IN\s*\(\s*'INGESTING'\s*,\s*'READY_FOR_SUBMISSION'\s*,\s*'PROCESSING'\s*\) THEN 'PROCESSING' ELSE \[Status\] END",
            sql);
        Assert.Matches(
            @"sp_search_purchase_order_batches\] @source nvarchar\(50\), @originalFileName nvarchar\(260\) = NULL, @status varchar\(50\) = NULL, @discoveredAfterDateTimeUtc datetimeoffset\(3\), @discoveredUntilDateTimeUtc datetimeoffset\(3\), @pageNumber int, @pageSize int AS\b",
            sql);
        Assert.Matches(
            @"sp_search_purchase_order_batches.*?@status NOT IN\s*\(\s*'PROCESSING'\s*,\s*'COMPLETED'\s*,\s*'FAILED'\s*\).*?@pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50.*?batch\.\[Source\] = @source.*?CHARINDEX\s*\(\s*@originalFileName\s*,\s*batch\.\[OriginalFileName\]\s*\) > 0.*?batch\.\[DiscoveredDateTime\] >= @discoveredAfterDateTimeUtc.*?batch\.\[DiscoveredDateTime\] < @discoveredUntilDateTimeUtc.*?ORDER BY batch\.\[DiscoveredDateTime\] DESC, batch\.\[BatchId\] DESC.*?FETCH NEXT @pageSize ROWS ONLY",
            sql);
        Assert.Matches(
            @"sp_get_purchase_order_batch_candidate_summary\] @batchId uniqueidentifier AS\b.*?\[BatchId\] = @batchId.*?THROW 51001.*?GROUP BY candidate\.\[Status\]",
            sql);
        Assert.Matches(
            @"sp_search_purchase_order_batch_candidates\] @batchId uniqueidentifier, @status varchar\(50\) = NULL, @pageNumber int, @pageSize int AS\b.*?@pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50.*?\[BatchId\] = @batchId.*?THROW 51001.*?ORDER BY candidate\.\[AcceptedDateTime\] DESC, candidate\.\[CandidateId\] DESC.*?FETCH NEXT @pageSize ROWS ONLY",
            sql);
    }

    [Fact]
    public void ApiConfigurationProcedures_MatchApprovedContract()
    {
        var sql = LoadSingleScript(LoadSqlScripts(), "040-api-configuration-procedures.sql");
        var codeSql = Regex.Replace(SanitizeSql(sql), @"\s+", " ").Trim();
        var literalSql = NormalizeSql(sql);

        Assert.Equal(
            new[]
            {
                "sp_get_application_settings",
                "sp_create_purchase_order_candidate",
                "sp_search_purchase_order_candidates"
            },
            DiscoverProcedureNames(SanitizeSql(sql)));

        var batches = Regex
            .Split(
                SanitizeSql(sql),
                @"^[ \t]*GO[ \t]*(?:\r?$)",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Where(batch => !string.IsNullOrWhiteSpace(batch))
            .ToArray();
        Assert.True(batches.Length == 4, $"Expected three procedure batches plus one authorization batch, but found {batches.Length}.");
        Assert.All(
            new[] { batches[0], batches[2], batches[3] },
            batch => Assert.Matches(
                @"^\s*CREATE\s+OR\s+ALTER\s+PROCEDURE\s+\[po\]\.\[",
                batch));
        Assert.Matches(
            @"^\s*ALTER AUTHORIZATION ON OBJECT::\[po\]\.\[sp_get_application_settings\] TO SCHEMA OWNER\s*;?\s*$",
            batches[1]);

        Assert.Matches(
            @"CREATE OR ALTER PROCEDURE \[po\]\.\[sp_get_application_settings\] @contextList nvarchar\(max\) AS\b",
            codeSql);
        Assert.Matches(
            @"CREATE OR ALTER PROCEDURE \[po\]\.\[sp_create_purchase_order_candidate\] @candidateId uniqueidentifier, @account nvarchar\(50\), @branch nvarchar\(20\), @reference nvarchar\(100\) = NULL, @status varchar\(50\), @acceptedDateTime datetimeoffset\(3\), @payloadJson nvarchar\(max\), @actor nvarchar\(256\) AS\b",
            codeSql);
        Assert.Matches(
            @"CREATE OR ALTER PROCEDURE \[po\]\.\[sp_search_purchase_order_candidates\] @source nvarchar\(50\), @account nvarchar\(50\) = NULL, @branch nvarchar\(20\) = NULL, @reference nvarchar\(100\) = NULL, @iconPurchaseOrderNumber nvarchar\(100\) = NULL, @status varchar\(50\) = NULL, @acceptedAfterDateTimeUtc datetimeoffset\(3\) = NULL, @acceptedUntilDateTimeUtc datetimeoffset\(3\) = NULL, @pageNumber int, @pageSize int AS\b",
            codeSql);
        Assert.Equal(3, Regex.Matches(codeSql, @"\bSET NOCOUNT ON\b").Count);
        Assert.Single(Regex.Matches(codeSql, @"\bSET XACT_ABORT ON\b").Cast<Match>());

        Assert.Matches(
            @"@contextList IS NULL OR NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@contextList\s*\)\s*\)\s*,\s*N?''\s*\) IS NULL",
            literalSql);
        Assert.Matches(@"THROW 51004\b", codeSql);
        Assert.DoesNotContain("[orders]", codeSql, StringComparison.OrdinalIgnoreCase);
        Assert.Matches(@"FROM \[po\]\.\[ApplicationSetting\] AS setting", codeSql);
        Assert.Matches(@"ORDER BY requested\.\[ContextOrdinal\] DESC", codeSql);

        Assert.Matches(@"@candidateId IS NULL", codeSql);
        foreach (var parameterName in new[] { "account", "branch", "status", "actor" })
        {
            Assert.Matches(
                $@"NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@{parameterName}\s*\)\s*\)\s*,\s*(?:N)?''\s*\) IS NULL",
                literalSql);
        }

        Assert.Matches(@"@acceptedDateTime IS NULL", codeSql);
        Assert.Matches(@"DATEPART\s*\(\s*TZOFFSET\s*,\s*@acceptedDateTime\s*\) <> 0", codeSql);
        Assert.Matches(@"ISJSON\s*\(\s*@payloadJson\s*,\s*OBJECT\s*\) <> 1", codeSql);
        Assert.Matches(@"OPENJSON\s*\(\s*@payloadJson\s*\)", codeSql);
        Assert.Matches(@"\[key\] COLLATE Latin1_General_100_BIN2 = N'candidateStatus'", literalSql);
        var invalidStatusPattern = CreateStatusInListPattern(
            "@status",
            CandidateStatusValues,
            isNegated: true);
        Assert.Equal(2, Regex.Matches(literalSql, invalidStatusPattern).Count);
        Assert.DoesNotContain(
            "PurchaseOrderCandidateStatus",
            codeSql,
            StringComparison.OrdinalIgnoreCase);

        Assert.Single(Regex.Matches(codeSql, @"\bBEGIN TRY\b").Cast<Match>());
        Assert.Single(Regex.Matches(codeSql, @"\bBEGIN TRANSACTION\b").Cast<Match>());
        Assert.Single(Regex.Matches(codeSql, @"\bCOMMIT TRANSACTION\b").Cast<Match>());
        Assert.Single(Regex.Matches(codeSql, @"\bBEGIN CATCH\b").Cast<Match>());
        Assert.Single(Regex.Matches(codeSql, @"\bROLLBACK TRANSACTION\b").Cast<Match>());
        Assert.Equal(2, Regex.Matches(codeSql, @"\[po\]\.\[PurchaseOrderCandidate\]").Count);
        Assert.Single(Regex.Matches(codeSql, @"\[po\]\.\[PurchaseOrderAudit\]").Cast<Match>());
        Assert.Matches(@"SET @candidateKey = CONVERT\s*\(\s*bigint\s*,\s*SCOPE_IDENTITY\s*\(\s*\)\s*\)", codeSql);
        Assert.Matches(@"VALUES \( @candidateId, NULL, N'API', 'API', NULL, @account, @branch, @reference, NULL, @status, @acceptedDateTime, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @payloadJson, @acceptedDateTime, @acceptedDateTime, @acceptedDateTime, @acceptedDateTime, 0, 0, NULL, NULL, NULL, NULL \)", literalSql);
        Assert.Matches(@"VALUES \( @candidateKey, 'CREATE', 'API', @actor, NULL, NULL, @status, NULL, @payloadJson, NULL, @candidateId, @acceptedDateTime \)", literalSql);
        Assert.DoesNotMatch(@"\bOUTPUT\b", codeSql);
        Assert.DoesNotMatch(@"\bJSON_MODIFY\b", codeSql);
        Assert.DoesNotMatch(@"\bSET @(?:source|account|branch|reference|status|payloadJson)\b", codeSql);
        var apiBusinessProcedureCode = Regex.Replace(
            batches[2] + Environment.NewLine + batches[3],
            @"\s+",
            " ");
        Assert.Equal(2, Regex.Matches(apiBusinessProcedureCode, @"\bSELECT\b").Count);

        Assert.Matches(@"@source IS NULL OR NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@source\s*\)\s*\)\s*,\s*N?''\s*\) IS NULL", literalSql);
        Assert.Matches(@"@pageNumber IS NULL OR @pageNumber < 1", codeSql);
        Assert.Matches(@"@pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50", codeSql);
        Assert.Matches($@"@status IS NOT NULL AND {invalidStatusPattern}", literalSql);
        foreach (var (parameterName, columnName) in new[]
                 {
                     ("account", "Account"),
                     ("branch", "Branch"),
                     ("reference", "Reference"),
                     ("iconPurchaseOrderNumber", "IconPurchaseOrderNumber"),
                     ("status", "Status")
                 })
        {
            Assert.Matches(
                $@"\(\s*@{parameterName} IS NULL OR \[?candidate\]?\.\[{columnName}\] = @{parameterName}\s*\)",
                codeSql);
        }

        Assert.Matches(
            @"SELECT \[CandidateId\], \[Source\], \[Account\], \[Branch\], \[Reference\], \[IconPurchaseOrderNumber\], \[Status\], \[AcceptedDateTime\] FROM \[po\]\.\[PurchaseOrderCandidate\] AS \[?candidate\]?",
            codeSql);
        Assert.Matches(@"\[?candidate\]?\.\[Source\] = @source", codeSql);
        Assert.Matches(@"DECLARE @offset bigint = \(CONVERT\s*\(\s*bigint\s*,\s*@pageNumber\s*\) - 1\) \* CONVERT\s*\(\s*bigint\s*,\s*@pageSize\s*\)", codeSql);
        Assert.Matches(@"ORDER BY \[AcceptedDateTime\] DESC, \[CandidateId\] OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY", codeSql);
        Assert.DoesNotMatch(@"\bNOLOCK\b", codeSql);

        var numberedThrows = Regex
            .Matches(codeSql, @"\bTHROW (?<number>\d+)\b")
            .Cast<Match>()
            .Select(match => match.Groups["number"].Value)
            .Distinct(StringComparer.Ordinal)
            .ToArray();
        Assert.Equal(new[] { "51004" }, numberedThrows);
    }

    [Fact]
    public void BatchIngestionProcedures_MatchApprovedContract()
    {
        var sql = LoadSingleScript(LoadSqlScripts(), "050-batch-ingestion-procedures.sql");
        var sanitizedSql = SanitizeSql(sql);
        var codeSql = Regex.Replace(sanitizedSql, @"\s+", " ").Trim();
        var literalSql = NormalizeSql(sql);
        var batches = Regex
            .Split(
                sanitizedSql,
                @"^[ \t]*GO[ \t]*(?:\r?$)",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Where(batch => !string.IsNullOrWhiteSpace(batch))
            .ToArray();
        Assert.Equal(
            new[]
            {
                "sp_register_purchase_order_batch",
                "sp_add_purchase_order_candidate_to_batch",
                "sp_complete_purchase_order_batch",
                "sp_fail_purchase_order_batch",
                "sp_get_purchase_order_batch",
                "sp_get_purchase_order_batch_by_source_hash"
            },
            DiscoverProcedureNames(sanitizedSql));
        Assert.Equal(6, batches.Length);
        Assert.All(batches, batch => Assert.Matches(
            @"^\s*CREATE\s+OR\s+ALTER\s+PROCEDURE\s+\[po\]\.\[",
            batch));

        foreach (var signature in new[]
                 {
                     @"sp_register_purchase_order_batch\] @batchId uniqueidentifier, @originalFileName nvarchar\(260\), @sourceFilePath nvarchar\(512\), @fileContentLength bigint, @fileSha256 binary\(32\), @expectedRowCount int = NULL, @discoveredDateTime datetimeoffset\(3\), @actor nvarchar\(256\) AS\b",
                     @"sp_add_purchase_order_candidate_to_batch\] @batchId uniqueidentifier, @candidateId uniqueidentifier, @account nvarchar\(50\), @branch nvarchar\(20\), @reference nvarchar\(100\) = NULL, @sourceRowCount int, @acceptedDateTime datetimeoffset\(3\), @payloadJson nvarchar\(max\), @actor nvarchar\(256\) AS\b",
                     @"sp_complete_purchase_order_batch\] @batchId uniqueidentifier, @expectedCandidateCount int, @parsedRowCount int, @completedDateTime datetimeoffset\(3\), @actor nvarchar\(256\), @expectedBatchRowVersion binary\(8\) AS\b",
                     @"sp_fail_purchase_order_batch\] @batchId uniqueidentifier, @failureCode varchar\(100\), @failureDescription nvarchar\(1000\), @failedDateTime datetimeoffset\(3\), @actor nvarchar\(256\), @expectedBatchRowVersion binary\(8\) AS\b",
                     @"sp_get_purchase_order_batch\] @batchId uniqueidentifier AS\b",
                     @"sp_get_purchase_order_batch_by_source_hash\] @source nvarchar\(50\), @fileSha256 binary\(32\) AS\b"
                 })
        {
            Assert.Matches(signature, codeSql);
        }

        Assert.Equal(6, Regex.Matches(codeSql, @"\bSET NOCOUNT ON\b").Count);
        foreach (var keyword in new[]
                 {
                     @"\bSET XACT_ABORT ON\b", @"\bBEGIN TRY\b", @"\bBEGIN TRANSACTION\b",
                     @"\bBEGIN CATCH\b", @"\bROLLBACK TRANSACTION\b"
                 })
        {
            Assert.Equal(4, Regex.Matches(codeSql, keyword).Count);
        }
        Assert.Equal(5, Regex.Matches(codeSql, @"\bCOMMIT TRANSACTION\b").Count);

        Assert.DoesNotMatch(@"\bNOLOCK\b", codeSql);
        Assert.True(Regex.Matches(codeSql, @"WITH \(UPDLOCK, HOLDLOCK\)").Count >= 5);
        foreach (var errorNumber in new[] { "51001", "51002", "51004", "51005", "51006" })
        {
            Assert.Matches($@"\bTHROW {errorNumber}\b", codeSql);
        }

        Assert.Matches(@"@batchId IS NULL", codeSql);
        Assert.Matches(@"@fileSha256 IS NULL", codeSql);
        Assert.Matches(@"@fileContentLength IS NULL OR @fileContentLength < 0", codeSql);
        Assert.Matches(@"@sourceRowCount IS NULL OR @sourceRowCount <= 0", codeSql);
        Assert.Matches(@"@expectedRowCount IS NOT NULL AND @expectedRowCount < 0", codeSql);
        foreach (var parameterName in new[]
                 {
                     "originalFileName", "sourceFilePath", "account", "branch", "actor",
                     "failureCode", "failureDescription"
                 })
        {
            Assert.Matches($@"NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@{parameterName}\s*\)\s*\)\s*,\s*N?''\s*\) IS NULL", literalSql);
        }

        Assert.Equal(4, Regex.Matches(codeSql, @"DATEPART\s*\(\s*TZOFFSET\s*,\s*@(discovered|accepted|completed|failed)DateTime\s*\)\s*<>\s*0").Count);
        Assert.Matches(@"ISJSON\s*\(\s*@payloadJson\s*,\s*OBJECT\s*\)\s*<>\s*1", codeSql);
        Assert.Matches(@"OPENJSON\s*\(\s*@payloadJson\s*\)", codeSql);
        Assert.Matches(@"\[key\] COLLATE Latin1_General_100_BIN2 = N'candidateStatus'", literalSql);

        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderBatch\].*?WITH \(UPDLOCK, HOLDLOCK\).*?\[Source\] = N'Relex'.*?\[FileSha256\] = @fileSha256", literalSql);
        Assert.Matches(@"DECLARE @errorNumber int = ERROR_NUMBER\s*\(\s*\);.*?DECLARE @isDuplicateSourceFile bit = 0;.*?@errorNumber IN \(2601, 2627\).*?\[Source\] = N'Relex'.*?\[FileSha256\] = @fileSha256.*?SET @isDuplicateSourceFile = 1;.*?ROLLBACK TRANSACTION.*?IF @isDuplicateSourceFile = 1.*?THROW 51005.*?THROW;", literalSql);
        Assert.Matches(@"VALUES \( @batchId, N'Relex', @originalFileName, @sourceFilePath, @fileContentLength, @fileSha256, 'INGESTING', @expectedRowCount, 0, 0, NULL, NULL, @discoveredDateTime, @discoveredDateTime, NULL, @actor, @discoveredDateTime \)", literalSql);

        Assert.Matches(@"VALUES \( @candidateId, @batchKey, N'Relex', 'RELEX', @sourceRowCount, @account, @branch, @reference, NULL, 'DRAFT', @acceptedDateTime, NULL, NULL, NULL, NULL, NULL, NULL, NULL, @payloadJson, @acceptedDateTime, @acceptedDateTime, @acceptedDateTime, @acceptedDateTime, 0, 0, NULL, NULL, NULL, NULL \)", literalSql);
        Assert.Matches(@"VALUES \( @candidateKey, 'CREATE', 'INGESTION', @actor, NULL, NULL, 'DRAFT', NULL, @payloadJson, NULL, @batchId, @acceptedDateTime \)", literalSql);
        Assert.Matches(@"\[CandidateCount\] = \[CandidateCount\] \+ 1, \[ParsedRowCount\] = \[ParsedRowCount\] \+ @sourceRowCount, \[UpdatedDateTime\] = @acceptedDateTime", codeSql);
        Assert.Matches(@"@batchSource <> N'Relex'.*?THROW 51006", literalSql);
        Assert.Matches(@"SELECT @existingBatchKey = \[BatchKey\], @existingReference = \[Reference\], @existingPayloadJson = \[PayloadJson\], @existingSourceRowCount = \[SourceRowCount\] FROM \[po\]\.\[PurchaseOrderCandidate\] WITH \(UPDLOCK, HOLDLOCK\) WHERE \[CandidateId\] = @candidateId", codeSql);
        Assert.Matches(@"IF @existingBatchKey IS NOT NULL BEGIN IF @existingBatchKey = @batchKey AND ISNULL\s*\(\s*@existingReference\s*,\s*N''\s*\) = ISNULL\s*\(\s*@reference\s*,\s*N''\s*\) AND @existingPayloadJson = @payloadJson AND @existingSourceRowCount = @sourceRowCount BEGIN COMMIT TRANSACTION; RETURN; END; ;?THROW 51006", literalSql);

        Assert.Matches(@"@expectedCandidateCount < 0 OR @parsedRowCount < 0.*?THROW 51006", codeSql);
        Assert.Matches(@"@batchRowVersion <> @expectedBatchRowVersion.*?THROW 51006", codeSql);
        Assert.Matches(@"\[CandidateCount\] <> @expectedCandidateCount.*?\[ParsedRowCount\] <> @parsedRowCount.*?\[ExpectedRowCount\] IS NOT NULL.*?\[ExpectedRowCount\] <> @parsedRowCount", codeSql);
        Assert.DoesNotMatch(@"@expectedCandidateCount <> @parsedRowCount", codeSql);
        Assert.Matches(@"@actualCandidateCount = COUNT_BIG\s*\(\s*\*\s*\), @draftCandidateCount = COALESCE\s*\(\s*SUM\s*\(\s*CASE WHEN \[Status\] = 'DRAFT' THEN CONVERT\s*\(\s*bigint\s*,\s*1\s*\) ELSE 0 END\s*\)\s*,\s*0\s*\), @actualSourceRowCount = COALESCE\s*\(\s*SUM\s*\(\s*CONVERT\s*\(\s*bigint\s*,\s*\[SourceRowCount\]\s*\)\s*\)\s*,\s*0\s*\)", literalSql);
        Assert.Matches(@"@actualCandidateCount <> @expectedCandidateCount.*?@draftCandidateCount <> @expectedCandidateCount.*?@actualSourceRowCount <> @parsedRowCount", codeSql);
        Assert.Matches(@"UPDATE.*?\[PurchaseOrderCandidate\].*?\[Status\] = 'READY_FOR_SUBMISSION'.*?\[StatusDateTime\] = @completedDateTime.*?\[StatusReason\] = NULL.*?\[UpdatedDateTime\] = @completedDateTime.*?\[RefreshDateTime\] = @completedDateTime", literalSql);
        Assert.Matches(@"'BATCH_PROMOTION', 'INGESTION', @actor, NULL, 'DRAFT', 'READY_FOR_SUBMISSION', NULL, NULL, NULL, @batchId, @completedDateTime", literalSql);
        Assert.Matches(@"UPDATE \[po\]\.\[PurchaseOrderBatch\] SET \[Status\] = 'COMPLETED'.*?\[CompletedDateTime\] = @completedDateTime", literalSql);
        Assert.DoesNotMatch(@"\bJSON_MODIFY\b", codeSql);

        Assert.Matches(@"@batchRowVersion <> @expectedBatchRowVersion.*?THROW 51002", codeSql);
        Assert.Matches(@"\[Status\] = 'FAILED'.*?\[FailureCode\] = @failureCode.*?\[FailureDescription\] = @failureDescription.*?\[CompletedDateTime\] = @failedDateTime", literalSql);
        Assert.DoesNotMatch(@"PurchaseOrderCandidate", batches[3]);

        Assert.Matches(@"SELECT \[BatchId\], \[Status\], \[RowVersion\] FROM @registeredBatch", codeSql);
        Assert.Matches(@"SELECT \[BatchId\], \[Status\], \[PromotedCandidateCount\], \[RowVersion\] FROM @completedBatch", codeSql);
        Assert.Matches(@"SELECT \[BatchId\], \[Status\], \[RowVersion\] FROM @failedBatch", codeSql);
        const string batchDetailsSelectPattern = @"SELECT \[BatchId\], \[Source\], \[OriginalFileName\], \[SourceFilePath\], \[FileContentLength\], \[FileSha256\], \[Status\], \[ExpectedRowCount\], \[ParsedRowCount\], \[CandidateCount\], \[FailureCode\], \[FailureDescription\], \[DiscoveredDateTime\], \[IngestionStartedDateTime\], \[CompletedDateTime\], \[CreatedBy\], \[UpdatedDateTime\], \[RowVersion\] FROM \[po\]\.\[PurchaseOrderBatch\]";
        Assert.Equal(2, Regex.Matches(codeSql, batchDetailsSelectPattern).Count);
        Assert.Matches(@"@source IS NULL OR NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@source\s*\)\s*\)\s*,\s*N''\s*\) IS NULL", literalSql);
        Assert.Matches(@"WHERE \[Source\] = @source AND \[FileSha256\] = @fileSha256", codeSql);
        Assert.DoesNotContain("[BlobName]", batches[0], StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void ClaimRecoveryProcedures_MatchApprovedContract()
    {
        var sql = LoadSingleScript(LoadSqlScripts(), "060-claim-recovery-procedures.sql");
        var sanitizedSql = SanitizeSql(sql);
        var codeSql = Regex.Replace(sanitizedSql, @"\s+", " ").Trim();
        var literalSql = NormalizeSql(sql);
        var batches = Regex
            .Split(
                sanitizedSql,
                @"^[ \t]*GO[ \t]*(?:\r?$)",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Where(batch => !string.IsNullOrWhiteSpace(batch))
            .ToArray();
        var literalBatches = Regex
            .Split(
                SanitizeSql(sql, sanitizeStringLiterals: false),
                @"^[ \t]*GO[ \t]*(?:\r?$)",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Where(batch => !string.IsNullOrWhiteSpace(batch))
            .ToArray();

        Assert.Equal(
            new[]
            {
                "sp_claim_purchase_order_candidates",
                "sp_renew_purchase_order_claim",
                "sp_release_purchase_order_claim",
                "sp_expire_purchase_order_claims",
                "sp_get_purchase_order_candidate"
            },
            DiscoverProcedureNames(sanitizedSql));
        Assert.Equal(5, batches.Length);
        Assert.All(batches, batch => Assert.Matches(
            @"^\s*CREATE\s+OR\s+ALTER\s+PROCEDURE\s+\[po\]\.\[",
            batch));

        foreach (var signature in new[]
                 {
                     @"sp_claim_purchase_order_candidates\] @workerId nvarchar\(256\), @maxCandidates smallint, @leaseDurationSeconds int AS\b",
                     @"sp_renew_purchase_order_claim\] @candidateId uniqueidentifier, @leaseToken uniqueidentifier, @workerId nvarchar\(256\), @leaseDurationSeconds int AS\b",
                     @"sp_release_purchase_order_claim\] @candidateId uniqueidentifier, @leaseToken uniqueidentifier, @workerId nvarchar\(256\) AS\b",
                     @"sp_expire_purchase_order_claims\] @actor nvarchar\(256\) AS\b",
                     @"sp_get_purchase_order_candidate\] @candidateId uniqueidentifier AS\b"
                 })
        {
            Assert.Matches(signature, codeSql);
        }

        Assert.Equal(5, Regex.Matches(codeSql, @"\bSET NOCOUNT ON\b").Count);
        foreach (var keyword in new[]
                 {
                     @"\bSET XACT_ABORT ON\b", @"\bBEGIN TRY\b", @"\bBEGIN TRANSACTION\b",
                     @"\bCOMMIT TRANSACTION\b", @"\bBEGIN CATCH\b", @"\bROLLBACK TRANSACTION\b"
                 })
        {
            Assert.Equal(4, Regex.Matches(codeSql, keyword).Count);
        }

        Assert.DoesNotMatch(@"\bNOLOCK\b", codeSql);
        Assert.DoesNotMatch(@"SET\s+\[PayloadJson\]", codeSql);
        foreach (var errorNumber in new[] { "51001", "51003", "51004" })
        {
            Assert.Matches($@"\bTHROW {errorNumber}\b", codeSql);
        }

        var claimSql = Regex.Replace(batches[0], @"\s+", " ").Trim();
        Assert.Matches(@"@maxCandidates IS NULL OR @maxCandidates < 1 OR @maxCandidates > 20", claimSql);
        Assert.Matches(@"@leaseDurationSeconds IS NULL OR @leaseDurationSeconds <= 0", claimSql);
        Assert.DoesNotContain("RECOVERABLE_ERROR", batches[0], StringComparison.OrdinalIgnoreCase);
        Assert.Matches(@"\[LeaseToken\] = NEWID\s*\(\s*\).*?\[LeaseOwner\] = @workerId.*?\[LeaseAcquiredDateTime\] = @now.*?\[LeaseExpiresDateTime\] = DATEADD\s*\(\s*second\s*,\s*@leaseDurationSeconds\s*,\s*@now\s*\).*?\[RefreshDateTime\] = @now", claimSql);
        Assert.DoesNotContain("PreviousRefreshDateTime", claimSql, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("PurchaseOrderBatch", batches[0], StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("[BatchKey]", batches[0], StringComparison.OrdinalIgnoreCase);
        Assert.Matches(@"SELECT \[CandidateId\], \[Source\], \[Account\], \[Branch\], \[Reference\], \[Status\], \[PayloadJson\], \[LeaseToken\], \[LeaseExpiresDateTime\], \[RowVersion\] FROM @claimedCandidates", codeSql);

        Assert.Matches(@"WITH \(UPDLOCK, HOLDLOCK\).*?@candidateId.*?THROW 51001", codeSql);
        Assert.Equal(
            2,
            Regex.Matches(
                codeSql,
                @"@currentLeaseToken IS NULL.*?@currentLeaseToken <> @leaseToken.*?@currentLeaseOwner IS NULL.*?@currentLeaseOwner <> @workerId.*?@currentLeaseExpiresDateTime IS NULL.*?@currentLeaseExpiresDateTime <= @now.*?THROW 51003").Count);
        var renewSql = Regex.Replace(batches[1], @"\s+", " ").Trim();
        Assert.Matches(@"@requiredLeaseExpiresDateTime = DATEADD\s*\(\s*second\s*,\s*@leaseDurationSeconds\s*,\s*@now\s*\)", renewSql);
        Assert.Matches(@"WHEN @currentLeaseExpiresDateTime >= @requiredLeaseExpiresDateTime THEN DATEADD\s*\(\s*second\s*,\s*1\s*,\s*@currentLeaseExpiresDateTime\s*\)", renewSql);
        Assert.Matches(@"\[LeaseExpiresDateTime\] = @newLeaseExpiresDateTime.*?\[RefreshDateTime\] = @now", codeSql);
        Assert.Matches(@"SELECT \[CandidateId\], \[LeaseExpiresDateTime\], \[RowVersion\] FROM @renewedClaim", codeSql);

        var releaseSql = Regex.Replace(batches[2], @"\s+", " ").Trim();
        Assert.Matches(@"@currentLeaseExpiresDateTime <= @now.*?THROW 51003.*?UPDATE \[po\]\.\[PurchaseOrderCandidate\]", releaseSql);
        Assert.Matches(@"@candidateStatus NOT IN\s*\(\s*'READY_FOR_SUBMISSION'\s*,\s*'RETRY_REQUESTED'\s*\).*?THROW 51004", literalSql);
        Assert.Matches(@"\[LeaseToken\] = NULL.*?\[LeaseOwner\] = NULL.*?\[LeaseAcquiredDateTime\] = NULL.*?\[LeaseExpiresDateTime\] = NULL.*?\[RefreshDateTime\] = @now", codeSql);
        Assert.DoesNotContain("PurchaseOrderSubmissionAttempt", batches[2], StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("PurchaseOrderAudit", batches[2], StringComparison.OrdinalIgnoreCase);
        Assert.Matches(@"SELECT \[CandidateId\], \[Status\], \[RowVersion\] FROM @releasedClaim", codeSql);

        var expirySql = Regex.Replace(batches[3], @"\s+", " ").Trim();
        const string claimLockPattern = @"TOP \(@maxCandidates\).*?FROM \[po\]\.\[PurchaseOrderCandidate\].*?WITH \(UPDLOCK, READPAST, READCOMMITTEDLOCK\).*?\[Status\] IN \(.*?\).*?\[LeaseToken\] IS NULL.*?ORDER BY.*?\[AcceptedDateTime\].*?\[CandidateKey\]";
        const string expiryLockPattern = @"FROM \[po\]\.\[PurchaseOrderCandidate\] WITH \(UPDLOCK, READPAST, READCOMMITTEDLOCK\).*?\[LeaseToken\] IS NOT NULL.*?\[LeaseExpiresDateTime\] <= @now";
        var missingConcurrencyContracts = new List<string>();

        if (!Regex.IsMatch(claimSql, claimLockPattern))
        {
            missingConcurrencyContracts.Add("claim READCOMMITTEDLOCK hint set");
        }

        if (!Regex.IsMatch(expirySql, expiryLockPattern))
        {
            missingConcurrencyContracts.Add("expiry READCOMMITTEDLOCK hint set");
        }

        if (Regex.Matches(codeSql, @"WITH \(UPDLOCK, READPAST, READCOMMITTEDLOCK\)").Count != 2)
        {
            missingConcurrencyContracts.Add("exactly two RCSI-compatible READPAST hint sets");
        }

        if (Regex.IsMatch(codeSql, @"\bROWLOCK\b"))
        {
            missingConcurrencyContracts.Add("no ROWLOCK hint");
        }

        Assert.True(
            missingConcurrencyContracts.Count == 0,
            $"Missing claim/recovery concurrency contracts: {string.Join(", ", missingConcurrencyContracts)}.");
        Assert.Matches(claimLockPattern, claimSql);
        Assert.Matches(expiryLockPattern, expirySql);
        Assert.Equal(2, Regex.Matches(codeSql, @"WITH \(UPDLOCK, READPAST, READCOMMITTEDLOCK\)").Count);
        Assert.DoesNotMatch(@"\bROWLOCK\b", codeSql);
        Assert.Matches(@"\[Status\] = 'UNKNOWN_OUTCOME'.*?\[FailureCategory\] = 'LEASE_EXPIRED_AFTER_DISPATCH'.*?\[MessageCode\] = 'UNKNOWN_OUTCOME'", literalSql);
        Assert.Matches(@"\[Status\] = 'NON_RECOVERABLE_ERROR'.*?\[PreviousMessageCode\] =.*?\[MessageCode\].*?\[MessageCode\] = 'UNKNOWN_OUTCOME'", literalSql);
        Assert.Matches(@"'CLAIM_EXPIRED_UNKNOWN_OUTCOME', 'SYSTEM', @actor.*?'NON_RECOVERABLE_ERROR'.*?@now", literalSql);
        Assert.DoesNotContain("LEASE_EXPIRED_BEFORE_DISPATCH", literalSql, StringComparison.OrdinalIgnoreCase);
        Assert.Matches(@"SELECT @releasedBeforeDispatchCount AS \[ReleasedBeforeDispatchCount\], @unknownOutcomeCount AS \[UnknownOutcomeCount\]", codeSql);

        var getCandidateSql = Regex.Replace(batches[4], @"\s+", " ").Trim();
        Assert.Matches(@"SELECT candidate\.\[CandidateId\], batch\.\[BatchId\], candidate\.\[Source\], candidate\.\[Kind\], candidate\.\[Account\], candidate\.\[Branch\], candidate\.\[Reference\], candidate\.\[IconPurchaseOrderNumber\], candidate\.\[Status\], candidate\.\[StatusDateTime\], candidate\.\[StatusReason\], candidate\.\[ProcessBatchNo\], candidate\.\[PayloadMD5\], candidate\.\[MessageCode\], candidate\.\[MessageDescription\], candidate\.\[PreviousMessageCode\], candidate\.\[PreviousMessageDescription\], candidate\.\[PayloadJson\], candidate\.\[AcceptedDateTime\], candidate\.\[CreatedDateTime\], candidate\.\[UpdatedDateTime\], candidate\.\[RefreshDateTime\], candidate\.\[PendingRetriesCount\], candidate\.\[ProcessingRetriesCount\], candidate\.\[LeaseToken\], candidate\.\[LeaseOwner\], candidate\.\[LeaseAcquiredDateTime\], candidate\.\[LeaseExpiresDateTime\], candidate\.\[RowVersion\]", getCandidateSql);
        Assert.Matches(@"LEFT JOIN \[po\]\.\[PurchaseOrderBatch\] AS batch ON batch\.\[BatchKey\] = candidate\.\[BatchKey\]", getCandidateSql);
        Assert.DoesNotMatch(@"SELECT\s+(?:candidate\.)?\[BatchKey\]|,\s*(?:candidate\.)?\[BatchKey\]\s*(?:,|FROM)", getCandidateSql);
    }

    [Fact]
    public void SubmissionOutcomeProcedures_MatchApprovedContract()
    {
        var sql = LoadSingleScript(LoadSqlScripts(), "070-submission-outcome-procedures.sql");
        var sanitizedSql = SanitizeSql(sql);
        var codeSql = Regex.Replace(sanitizedSql, @"\s+", " ").Trim();
        var literalSql = NormalizeSql(sql);
        var batches = Regex
            .Split(
                sql,
                @"^[ \t]*GO[ \t]*(?:\r?$)",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Where(batch => !string.IsNullOrWhiteSpace(batch))
            .Select(NormalizeSql)
            .ToArray();

        Assert.Equal(
            new[]
            {
                "sp_begin_purchase_order_submission_attempt",
                "sp_fail_purchase_order_candidate_pre_dispatch",
                "sp_complete_purchase_order_submission",
                "sp_fail_purchase_order_submission"
            },
            DiscoverProcedureNames(sanitizedSql));
        Assert.Equal(4, batches.Length);

        foreach (var signature in new[]
                 {
                     @"sp_begin_purchase_order_submission_attempt\] @attemptId uniqueidentifier, @candidateId uniqueidentifier, @leaseToken uniqueidentifier, @workerId nvarchar\(256\), @requestPayloadJson nvarchar\(max\) AS\b",
                     @"sp_fail_purchase_order_candidate_pre_dispatch\] @candidateId uniqueidentifier, @leaseToken uniqueidentifier, @workerId nvarchar\(256\), @candidateStatus varchar\(50\), @failureCategory varchar\(100\), @messageCode nvarchar\(100\) = NULL, @messageDescription nvarchar\(1000\) = NULL AS\b",
                     @"sp_complete_purchase_order_submission\] @attemptId uniqueidentifier, @candidateId uniqueidentifier, @leaseToken uniqueidentifier, @workerId nvarchar\(256\), @iconPurchaseOrderNumber nvarchar\(100\), @iconCreatedStatus varchar\(50\), @iconSuspended bit, @iconSuspendMessage nvarchar\(1000\) = NULL, @responsePayloadJson nvarchar\(max\) = NULL AS\b",
                     @"sp_fail_purchase_order_submission\] @attemptId uniqueidentifier, @candidateId uniqueidentifier, @leaseToken uniqueidentifier, @workerId nvarchar\(256\), @candidateStatus varchar\(50\), @failureCategory varchar\(100\), @messageCode nvarchar\(100\) = NULL, @messageDescription nvarchar\(1000\) = NULL, @httpStatusCode smallint = NULL, @responsePayloadJson nvarchar\(max\) = NULL, @attemptStatus varchar\(50\) AS\b"
                 })
        {
            Assert.Matches(signature, codeSql);
        }

        foreach (var keyword in new[]
                 {
                     @"\bSET NOCOUNT ON\b", @"\bSET XACT_ABORT ON\b", @"\bBEGIN TRY\b",
                     @"\bBEGIN TRANSACTION\b", @"\bCOMMIT TRANSACTION\b", @"\bBEGIN CATCH\b",
                     @"\bROLLBACK TRANSACTION\b"
                 })
        {
            Assert.Equal(4, Regex.Matches(codeSql, keyword).Count);
        }

        Assert.DoesNotMatch(@"\bNOLOCK\b", codeSql);
        Assert.DoesNotMatch(@"SET\s+(?:candidate\.)?\[PayloadJson\]", codeSql);
        Assert.DoesNotMatch(@"\bJSON_MODIFY\b", codeSql);
        foreach (var errorNumber in new[] { "51001", "51003", "51004" })
        {
            Assert.Matches($@"\bTHROW {errorNumber}\b", codeSql);
        }

        Assert.Equal(3, Regex.Matches(codeSql, @"@attemptId IS NULL").Count);
        Assert.Equal(4, Regex.Matches(codeSql, @"@candidateId IS NULL").Count);
        Assert.Equal(4, Regex.Matches(codeSql, @"@leaseToken IS NULL").Count);
        Assert.Equal(4, Regex.Matches(literalSql, @"NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@workerId\s*\)\s*\)\s*,\s*N''\s*\) IS NULL").Count);
        Assert.Equal(4, Regex.Matches(codeSql, @"SYSUTCDATETIME\s*\(\s*\)").Count);

        var dispatchSql = batches[0];
        Assert.Matches(@"ISJSON\s*\(\s*@requestPayloadJson\s*,\s*OBJECT\s*\)\s*<>\s*1", dispatchSql);
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderCandidate\] WITH \(UPDLOCK, HOLDLOCK\).*?WHERE \[CandidateId\] = @candidateId.*?FROM \[po\]\.\[PurchaseOrderSubmissionAttempt\] WITH \(UPDLOCK, HOLDLOCK\)", dispatchSql);
        Assert.Matches(@"@currentLeaseToken IS NULL.*?@currentLeaseToken <> @leaseToken.*?@currentLeaseOwner IS NULL.*?@currentLeaseOwner <> @workerId.*?@currentLeaseExpiresDateTime IS NULL.*?@currentLeaseExpiresDateTime <= @now.*?THROW 51003", dispatchSql);
        Assert.Matches(@"@candidateStatus NOT IN\s*\(\s*'READY_FOR_SUBMISSION'\s*,\s*'RETRY_REQUESTED'\s*\).*?THROW 51004", dispatchSql);
        Assert.Matches(@"ISNULL\s*\(\s*MAX\s*\(\s*\[AttemptNumber\]\s*\)\s*,\s*0\s*\)\s*\+\s*1.*?WITH \(UPDLOCK, HOLDLOCK\).*?\[CandidateKey\] = @candidateKey", dispatchSql);
        Assert.Matches(@"VALUES \( @attemptId, @candidateKey, @attemptNumber, @leaseToken, 'DISPATCHED'.*?@now, @now, NULL, @workerId \)", dispatchSql);
        Assert.Matches(@"UPDATE \[po\]\.\[PurchaseOrderCandidate\] SET \[Status\] = 'SUBMISSION_IN_PROGRESS'.*?\[StatusDateTime\] = @now.*?\[UpdatedDateTime\] = @now.*?\[RefreshDateTime\] = @now", dispatchSql);
        Assert.Matches(@"VALUES \( @candidateKey, 'ATTEMPT_DISPATCHED', 'PROCESSOR'.*?@attemptId, @now \)", dispatchSql);
        Assert.Matches(@"SELECT \[AttemptId\], \[AttemptNumber\], \[Status\] FROM @dispatchedAttempt", dispatchSql);

        var preDispatchFailureSql = batches[1];
        Assert.Matches(@"@candidateStatus NOT IN\s*\(\s*'RECOVERABLE_ERROR'\s*,\s*'NON_RECOVERABLE_ERROR'\s*\)", preDispatchFailureSql);
        Assert.Matches(@"@currentLeaseToken IS NULL.*?@currentLeaseToken <> @leaseToken.*?@currentLeaseOwner IS NULL.*?@currentLeaseOwner <> @workerId.*?@currentLeaseExpiresDateTime IS NULL.*?@currentLeaseExpiresDateTime <= @now.*?THROW 51003", preDispatchFailureSql);
        Assert.Matches(@"@currentCandidateStatus NOT IN\s*\(\s*'READY_FOR_SUBMISSION'\s*,\s*'RETRY_REQUESTED'\s*\).*?THROW 51004", preDispatchFailureSql);
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderSubmissionAttempt\] WITH \(UPDLOCK, HOLDLOCK\).*?\[CandidateKey\] = @candidateKey.*?\[Status\] = 'DISPATCHED'.*?\[CompletedDateTime\] IS NULL.*?THROW 51004", preDispatchFailureSql);
        Assert.Matches(@"\[Status\] = @candidateStatus.*?\[StatusDateTime\] = @now.*?\[UpdatedDateTime\] = @now.*?\[RefreshDateTime\] = @now.*?\[LeaseToken\] = NULL", preDispatchFailureSql);
        Assert.Matches(@"VALUES \( @candidateKey, 'SUBMISSION_FAILED_BEFORE_DISPATCH'.*?@leaseToken, @now \)", preDispatchFailureSql);
        Assert.Matches(@"SELECT \[CandidateId\], \[Status\], \[RowVersion\] FROM @failedCandidate", preDispatchFailureSql);

        var successSql = batches[2];
        Assert.Matches(@"@iconCreatedStatus NOT IN\s*\(\s*'activated'\s*,\s*'notactivated'\s*,\s*'received'\s*,\s*'undefined'\s*\)", successSql);
        Assert.Matches(@"@iconSuspended IS NULL", successSql);
        Assert.Matches(@"@responsePayloadJson IS NOT NULL.*?ISJSON\s*\(\s*@responsePayloadJson\s*\)\s*<>\s*1", successSql);
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderCandidate\] WITH \(UPDLOCK, HOLDLOCK\).*?FROM \[po\]\.\[PurchaseOrderSubmissionAttempt\] WITH \(UPDLOCK, HOLDLOCK\)", successSql);
        Assert.Matches(@"@candidateStatus <> 'SUBMISSION_IN_PROGRESS'.*?THROW 51004", successSql);
        Assert.Matches(@"\[Status\] = 'SUCCEEDED'.*?\[ResponsePayloadJson\] = @responsePayloadJson.*?\[CompletedDateTime\] = @now", successSql);
        Assert.Matches(@"\[Status\] = 'COMPLETED'.*?\[IconPurchaseOrderNumber\] = @iconPurchaseOrderNumber.*?\[StatusDateTime\] = @now.*?\[UpdatedDateTime\] = @now.*?\[RefreshDateTime\] = @now.*?\[LeaseToken\] = NULL", successSql);
        Assert.Matches(@"VALUES \( @candidateKey, 'SUBMISSION_SUCCEEDED'.*?@attemptId, @now \)", successSql);
        Assert.Matches(@"SELECT \[CandidateId\], \[Status\], \[IconPurchaseOrderNumber\], @attemptId AS \[AttemptId\], 'SUCCEEDED' AS \[AttemptStatus\], \[CandidateRowVersion\] FROM @completedCandidate", successSql);

        var failureSql = batches[3];
        Assert.Matches(@"@candidateStatus NOT IN\s*\(\s*'RECOVERABLE_ERROR'\s*,\s*'NON_RECOVERABLE_ERROR'\s*\)", failureSql);
        Assert.Matches(@"@attemptStatus IS NULL.*?@attemptStatus NOT IN\s*\(\s*'FAILED'\s*,\s*'UNKNOWN_OUTCOME'\s*\)", failureSql);
        Assert.Matches(@"@httpStatusCode IS NOT NULL.*?@httpStatusCode NOT BETWEEN 100 AND 599", failureSql);
        Assert.Matches(@"@responsePayloadJson IS NOT NULL.*?ISJSON\s*\(\s*@responsePayloadJson\s*\)\s*<>\s*1", failureSql);
        Assert.Matches(@"@attemptStatus = 'UNKNOWN_OUTCOME'.*?@candidateStatus <> 'NON_RECOVERABLE_ERROR'.*?THROW 51004", failureSql);
        Assert.Matches(@"@auditAction varchar\(100\) = CASE WHEN @attemptStatus = 'UNKNOWN_OUTCOME' THEN 'SUBMISSION_UNKNOWN_OUTCOME' ELSE 'SUBMISSION_FAILED' END", failureSql);
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderCandidate\] WITH \(UPDLOCK, HOLDLOCK\).*?FROM \[po\]\.\[PurchaseOrderSubmissionAttempt\] WITH \(UPDLOCK, HOLDLOCK\)", failureSql);
        Assert.Matches(@"@candidateCurrentStatus <> 'SUBMISSION_IN_PROGRESS'.*?THROW 51004", failureSql);
        Assert.Matches(@"\[Status\] = @attemptStatus.*?\[ResponsePayloadJson\] = @responsePayloadJson.*?\[HttpStatusCode\] = @httpStatusCode.*?\[FailureCategory\] = @failureCategory.*?\[MessageCode\] = @messageCode.*?\[MessageDescription\] = @messageDescription.*?\[CompletedDateTime\] = @now", failureSql);
        Assert.Matches(@"@statusReason nvarchar\(1000\) = COALESCE\s*\(\s*NULLIF\s*\(\s*@messageDescription\s*,\s*N''\s*\)\s*,\s*@failureCategory\s*\)", failureSql);
        Assert.Matches(@"\[Status\] = @candidateStatus.*?\[StatusDateTime\] = @now.*?\[StatusReason\] = @statusReason.*?\[UpdatedDateTime\] = @now.*?\[RefreshDateTime\] = @now.*?\[LeaseToken\] = NULL", failureSql);
        Assert.Matches(@"VALUES \( @candidateKey, @auditAction.*?'SUBMISSION_IN_PROGRESS', @candidateStatus.*?@attemptId, @now \)", failureSql);
        Assert.Matches(@"SELECT \[CandidateId\], \[Status\], \[IconPurchaseOrderNumber\], @attemptId AS \[AttemptId\], @attemptStatus AS \[AttemptStatus\], \[CandidateRowVersion\] FROM @failedCandidate", failureSql);
    }

    [Fact]
    public void SupportSecurityAndVerificationScripts_MatchApprovedContract()
    {
        var scripts = LoadSqlScripts();
        var supportSql = LoadSingleScript(scripts, "080-support-notification-procedures.sql");
        var securitySql = LoadSingleScript(scripts, "090-security.sql");
        var verifySql = LoadSingleScript(scripts, "100-verify.sql");
        var supportCode = Regex.Replace(SanitizeSql(supportSql), @"\s+", " ").Trim();
        var supportLiteral = NormalizeSql(supportSql);
        var supportBatches = Regex
            .Split(
                supportSql,
                @"^[ \t]*GO[ \t]*(?:\r?$)",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Where(batch => !string.IsNullOrWhiteSpace(batch))
            .Select(NormalizeSql)
            .ToArray();

        Assert.Equal(
            new[]
            {
                "sp_request_purchase_order_retry",
                "sp_cancel_purchase_order_candidate",
                "sp_get_purchase_order_audit",
                "sp_get_purchase_order_batch_outcomes",
                "sp_register_purchase_order_notification",
                "sp_complete_purchase_order_notification",
                "sp_enqueue_purchase_order_email_notification",
                "sp_claim_purchase_order_email_notifications",
                "sp_defer_purchase_order_email_notification",
                "sp_reschedule_purchase_order_email_notification",
                "sp_complete_purchase_order_email_notification",
                "sp_get_purchase_order_email_notification_queue_summary"
            },
            DiscoverProcedureNames(SanitizeSql(supportSql)));
        Assert.Equal(13, supportBatches.Length);
        Assert.All(supportBatches.Take(6), batch => Assert.Matches(
            @"^CREATE OR ALTER PROCEDURE \[po\]\.\[",
            batch));
        Assert.Matches(
            @"^DROP PROCEDURE IF EXISTS \[po\]\.\[sp_complete_purchase_order_batch_processing\]",
            supportBatches[6]);
        foreach (var signature in new[]
                 {
                     @"sp_request_purchase_order_retry\] @candidateId uniqueidentifier, @actor nvarchar\(256\), @reason nvarchar\(1000\), @requestedDateTime datetimeoffset\(3\), @expectedCandidateRowVersion binary\(8\) AS\b",
                     @"sp_cancel_purchase_order_candidate\] @candidateId uniqueidentifier, @actor nvarchar\(256\), @reason nvarchar\(1000\), @cancelledDateTime datetimeoffset\(3\), @expectedCandidateRowVersion binary\(8\) AS\b",
                     @"sp_get_purchase_order_audit\] @candidateId uniqueidentifier, @pageNumber int, @pageSize int AS\b",
                     @"sp_get_purchase_order_batch_outcomes\] @batchId uniqueidentifier AS\b",
                     @"sp_register_purchase_order_notification\] @notificationId uniqueidentifier, @batchId uniqueidentifier, @channel varchar\(50\), @templateKey nvarchar\(100\), @recipientGroupKey nvarchar\(100\), @attachmentBlobName nvarchar\(512\) = NULL, @createdDateTime datetimeoffset\(3\) AS\b",
                     @"sp_complete_purchase_order_notification\] @notificationId uniqueidentifier, @status varchar\(50\), @providerMessageId nvarchar\(256\) = NULL, @failureCode varchar\(100\) = NULL, @failureDescription nvarchar\(1000\) = NULL, @completedDateTime datetimeoffset\(3\), @expectedNotificationRowVersion binary\(8\) AS\b"
                 })
        {
            Assert.Matches(signature, supportCode);
        }

        Assert.Equal(12, Regex.Matches(supportCode, @"\bSET NOCOUNT ON\b").Count);
        foreach (var keyword in new[]
                 {
                     @"\bSET XACT_ABORT ON\b", @"\bBEGIN TRY\b", @"\bBEGIN TRANSACTION\b",
                     @"\bCOMMIT TRANSACTION\b", @"\bBEGIN CATCH\b", @"\bROLLBACK TRANSACTION\b"
                 })
        {
            Assert.Equal(9, Regex.Matches(supportCode, keyword).Count);
        }
        Assert.DoesNotMatch(@"\bNOLOCK\b|\bJSON_MODIFY\b|SET\s+(?:candidate\.)?\[PayloadJson\]", supportCode);

        var retrySql = supportBatches[0];
        Assert.Matches(@"@actor IS NULL.*?NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@actor\s*\).*?@reason IS NULL.*?NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@reason\s*\).*?DATEPART\s*\(\s*TZOFFSET\s*,\s*@requestedDateTime\s*\) <> 0.*?@expectedCandidateRowVersion IS NULL", retrySql);
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderCandidate\] WITH \(UPDLOCK, HOLDLOCK\).*?WHERE \[CandidateId\] = @candidateId.*?@candidateKey IS NULL.*?THROW 51001.*?@candidateRowVersion <> @expectedCandidateRowVersion.*?THROW 51002", retrySql);
        Assert.Matches(@"@candidateStatus NOT IN\s*\(\s*'RECOVERABLE_ERROR'\s*,\s*'NON_RECOVERABLE_ERROR'\s*\).*?@leaseToken IS NOT NULL.*?FROM \[po\]\.\[PurchaseOrderSubmissionAttempt\] WITH \(UPDLOCK, HOLDLOCK\).*?\[Status\] = 'DISPATCHED'.*?\[CompletedDateTime\] IS NULL.*?THROW 51004", retrySql);
        Assert.Matches(@"@requestedDateTime < @statusDateTime.*?@requestedDateTime < @refreshDateTime.*?THROW 51004", retrySql);
        Assert.Matches(@"UPDATE \[po\]\.\[PurchaseOrderCandidate\] SET \[Status\] = 'RETRY_REQUESTED', \[StatusDateTime\] = @requestedDateTime, \[StatusReason\] = @reason, \[UpdatedDateTime\] = @requestedDateTime, \[RefreshDateTime\] = @requestedDateTime", retrySql);
        Assert.Matches(@"VALUES \( @candidateKey, 'MANUAL_RETRY_REQUESTED', 'SUPPORT', @actor, @reason, @candidateStatus, 'RETRY_REQUESTED', NULL, NULL, NULL, @candidateId, @requestedDateTime \)", retrySql);
        Assert.Matches(@"SELECT \[CandidateId\], \[Status\], \[RowVersion\] FROM @retriedCandidate", retrySql);

        var cancelSql = supportBatches[1];
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderCandidate\] WITH \(UPDLOCK, HOLDLOCK\).*?@candidateKey IS NULL.*?THROW 51001.*?@candidateRowVersion <> @expectedCandidateRowVersion.*?THROW 51002", cancelSql);
        Assert.Matches(@"@candidateStatus IN\s*\(\s*'COMPLETED'\s*,\s*'CANCELLED'\s*\).*?@leaseToken IS NOT NULL.*?FROM \[po\]\.\[PurchaseOrderSubmissionAttempt\] WITH \(UPDLOCK, HOLDLOCK\).*?\[Status\] = 'DISPATCHED'.*?\[CompletedDateTime\] IS NULL.*?THROW 51004", cancelSql);
        Assert.Matches(@"@cancelledDateTime < @statusDateTime.*?@cancelledDateTime < @refreshDateTime.*?THROW 51004", cancelSql);
        Assert.Matches(@"UPDATE \[po\]\.\[PurchaseOrderCandidate\] SET \[Status\] = 'CANCELLED', \[StatusDateTime\] = @cancelledDateTime, \[StatusReason\] = @reason, \[UpdatedDateTime\] = @cancelledDateTime, \[RefreshDateTime\] = @cancelledDateTime", cancelSql);
        Assert.Matches(@"VALUES \( @candidateKey, 'CANCELLED', 'SUPPORT', @actor, @reason, @candidateStatus, 'CANCELLED', NULL, NULL, NULL, @candidateId, @cancelledDateTime \)", cancelSql);
        Assert.Matches(@"SELECT \[CandidateId\], \[Status\], \[RowVersion\] FROM @cancelledCandidate", cancelSql);
        Assert.All(new[] { retrySql, cancelSql }, sql => Assert.DoesNotMatch(
            @"\[(?:PayloadJson|MessageCode|MessageDescription|PreviousMessageCode|PreviousMessageDescription|PendingRetriesCount|ProcessingRetriesCount)\]",
            sql));

        var auditSql = supportBatches[2];
        Assert.Matches(@"@pageNumber IS NULL OR @pageNumber < 1", auditSql);
        Assert.Matches(@"@pageSize IS NULL OR @pageSize < 1 OR @pageSize > 50", auditSql);
        Assert.Matches(@"IF NOT EXISTS.*?\[CandidateId\] = @candidateId.*?THROW 51001", auditSql);
        Assert.Matches(@"DECLARE @offset bigint = \(CONVERT\s*\(\s*bigint\s*,\s*@pageNumber\s*\) - 1\) \* CONVERT\s*\(\s*bigint\s*,\s*@pageSize\s*\)", auditSql);
        Assert.Matches(@"SELECT audit\.\[Action\], audit\.\[Method\], audit\.\[Actor\], audit\.\[Reason\], audit\.\[PreviousStatus\], audit\.\[CurrentStatus\], audit\.\[PreviousPayloadJson\], audit\.\[CurrentPayloadJson\], audit\.\[BusinessPayloadHash\], audit\.\[CorrelationId\], audit\.\[ChangedDateTime\].*?ORDER BY audit\.\[ChangedDateTime\] DESC, audit\.\[AuditKey\] DESC OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY", auditSql);

        var outcomesSql = supportBatches[3];
        Assert.Matches(@"SELECT @batchKey = \[BatchKey\].*?\[BatchId\] = @batchId.*?@batchKey IS NULL.*?THROW 51001", outcomesSql);
        Assert.Matches(@"SELECT candidate\.\[CandidateId\], candidate\.\[Account\], candidate\.\[Branch\], candidate\.\[Reference\], candidate\.\[Status\], candidate\.\[IconPurchaseOrderNumber\], candidate\.\[StatusReason\], candidate\.\[AcceptedDateTime\], candidate\.\[UpdatedDateTime\].*?ORDER BY candidate\.\[AcceptedDateTime\], candidate\.\[CandidateId\]", outcomesSql);

        var registerNotificationSql = supportBatches[4];
        Assert.Matches(@"@notificationId IS NULL.*?@batchId IS NULL.*?NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@channel\s*\).*?NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@templateKey\s*\).*?NULLIF\s*\(\s*LTRIM\s*\(\s*RTRIM\s*\(\s*@recipientGroupKey\s*\).*?DATEPART\s*\(\s*TZOFFSET\s*,\s*@createdDateTime\s*\) <> 0", registerNotificationSql);
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderBatch\] WITH \(UPDLOCK, HOLDLOCK\).*?@batchKey IS NULL.*?THROW 51001.*?@batchStatus <> 'COMPLETED'.*?@createdDateTime < @batchUpdatedDateTime.*?THROW 51004", registerNotificationSql);
        Assert.Matches(@"VALUES \( @notificationId, @batchKey, @channel, @templateKey, @recipientGroupKey, @attachmentBlobName, 'PENDING', NULL, NULL, NULL, @createdDateTime, NULL, NULL, NULL, NULL, NULL, NULL, @createdDateTime \)", registerNotificationSql);
        Assert.Matches(@"SELECT \[NotificationId\], \[Status\], \[RowVersion\] FROM @registeredNotification", registerNotificationSql);

        var completeNotificationSql = supportBatches[5];
        // Break: legacy completion bypasses leasing and closes a sendable email without an attempt.
        Assert.Matches(@"@emailEnvelopeJson = \[EmailEnvelopeJson\].*?WITH \(UPDLOCK, HOLDLOCK\).*?IF @emailEnvelopeJson IS NOT NULL BEGIN ;THROW 51004.*?UPDATE \[po\]\.\[PurchaseOrderNotification\]", completeNotificationSql);
        Assert.Matches(@"\[CompletedDateTime\] = @completedDateTime", completeNotificationSql);
        Assert.Matches(@"@status NOT IN\s*\(\s*'SENT'\s*,\s*'FAILED'\s*\).*?@completedDateTime IS NULL.*?DATEPART\s*\(\s*TZOFFSET\s*,\s*@completedDateTime\s*\) <> 0.*?@expectedNotificationRowVersion IS NULL", completeNotificationSql);
        Assert.Matches(@"FROM \[po\]\.\[PurchaseOrderNotification\] WITH \(UPDLOCK, HOLDLOCK\).*?@notificationKey IS NULL.*?THROW 51001.*?@notificationRowVersion <> @expectedNotificationRowVersion.*?THROW 51002.*?@currentStatus <> 'PENDING'.*?@completedDateTime < @createdDateTime.*?THROW 51004", completeNotificationSql);
        Assert.Matches(@"\[Status\] = @status, \[ProviderMessageId\] = @providerMessageId, \[FailureCode\] = @failureCode, \[FailureDescription\] = @failureDescription, \[SentDateTime\] = CASE WHEN @status = 'SENT' THEN @completedDateTime ELSE NULL END", completeNotificationSql);
        Assert.Matches(@"SELECT \[NotificationId\], \[Status\], \[SentDateTime\], \[RowVersion\] FROM @completedNotification", completeNotificationSql);

        var roles = DatabaseRoleNames;
        var expectedGrants = ExpectedRoleProcedureGrants;
        var securityLiteral = NormalizeSql(securitySql);
        foreach (var obsoleteRole in new[]
                 {
                     "po_api_executor",
                     "po_ingestion_executor",
                     "po_processor_executor",
                     "po_support_reader",
                     "po_support_operator"
                 })
        {
            Assert.DoesNotContain(obsoleteRole, securitySql, StringComparison.Ordinal);
            Assert.DoesNotContain(obsoleteRole, verifySql, StringComparison.Ordinal);
        }

        Assert.Equal(
            roles,
            Regex.Matches(securityLiteral, @"CREATE ROLE \[(?<role>po_[^\]]+)\] AUTHORIZATION \[dbo\]")
                .Cast<Match>()
                .Select(match => match.Groups["role"].Value)
                .ToArray());
        foreach (var role in roles)
        {
            Assert.Matches(
                $@"IF DATABASE_PRINCIPAL_ID\s*\(\s*N'{role}'\s*\) IS NULL.*?CREATE ROLE \[{role}\] AUTHORIZATION \[dbo\]",
                securityLiteral);
        }
        Assert.Equal(
            expectedGrants.OrderBy(value => value, StringComparer.Ordinal),
            Regex.Matches(
                    securityLiteral,
                    @"GRANT EXECUTE ON OBJECT::\[po\]\.\[(?<procedure>[^\]]+)\] TO \[(?<role>po_[^\]]+)\]")
                .Cast<Match>()
                .Select(match => $"{match.Groups["role"].Value}:{match.Groups["procedure"].Value}")
                .OrderBy(value => value, StringComparer.Ordinal));
        Assert.DoesNotMatch(@"GRANT\s+(?:SELECT|INSERT|UPDATE|DELETE)\b|GRANT\s+EXECUTE\s+ON\s+SCHEMA::|\bREVOKE\b", securityLiteral);

        var expectedIndexes = new[]
        {
            "ApplicationSetting:PK_PO_ApplicationSetting:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=Context:ASC,Key:ASC:includes=:filter=<null>",
            "PurchaseOrderBatch:PK_PO_Batch:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=BatchKey:ASC:includes=:filter=<null>",
            "PurchaseOrderBatch:UQ_PO_Batch_BatchId:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=True:keys=BatchId:ASC:includes=:filter=<null>",
            "PurchaseOrderCandidate:PK_PO_Candidate:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=CandidateKey:ASC:includes=:filter=<null>",
            "PurchaseOrderCandidate:UQ_PO_Candidate_CandidateId:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=True:keys=CandidateId:ASC:includes=:filter=<null>",
            "PurchaseOrderSubmissionAttempt:PK_PO_Attempt:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=AttemptKey:ASC:includes=:filter=<null>",
            "PurchaseOrderSubmissionAttempt:UQ_PO_Attempt_AttemptId:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=True:keys=AttemptId:ASC:includes=:filter=<null>",
            "PurchaseOrderAudit:PK_PO_Audit:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=AuditKey:ASC:includes=:filter=<null>",
            "PurchaseOrderNotification:PK_PO_Notification:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=NotificationKey:ASC:includes=:filter=<null>",
            "PurchaseOrderNotification:UQ_PO_Notification_NotificationId:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=True:keys=NotificationId:ASC:includes=:filter=<null>",
            "PurchaseOrderNotificationAttempt:PK_PO_NotificationAttempt:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=NotificationAttemptKey:ASC:includes=:filter=<null>",
            "PurchaseOrderBatch:UX_PO_Batch_Source_FileSha256:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=False:keys=Source:ASC,FileSha256:ASC:includes=:filter=<null>",
            "PurchaseOrderBatch:IX_PO_Batch_Status_DiscoveredDateTime:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=Status:ASC,DiscoveredDateTime:ASC:includes=:filter=<null>",
            "PurchaseOrderCandidate:IX_PO_Candidate_Source_Status_AcceptedDateTime:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=Source:ASC,Status:ASC,AcceptedDateTime:DESC:includes=Account,Branch,Reference,IconPurchaseOrderNumber:filter=<null>",
            "PurchaseOrderCandidate:IX_PO_Candidate_Source_Account_Branch_Reference:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=Source:ASC,Account:ASC,Branch:ASC,Reference:ASC:includes=:filter=<null>",
            "PurchaseOrderCandidate:IX_PO_Candidate_IconPurchaseOrderNumber:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=IconPurchaseOrderNumber:ASC:includes=:filter=IconPurchaseOrderNumber IS NOT NULL",
            "PurchaseOrderCandidate:IX_PO_Candidate_Status_LeaseExpires_AcceptedDateTime:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=Status:ASC,LeaseExpiresDateTime:ASC,AcceptedDateTime:ASC:includes=CandidateId,Branch:filter=<null>",
            "PurchaseOrderCandidate:IX_PO_Candidate_BatchKey_CandidateKey:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=BatchKey:ASC,CandidateKey:ASC:includes=Status,LeaseToken:filter=<null>",
            "PurchaseOrderSubmissionAttempt:UX_PO_Attempt_CandidateKey_AttemptNumber:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=False:keys=CandidateKey:ASC,AttemptNumber:ASC:includes=:filter=<null>",
            "PurchaseOrderSubmissionAttempt:IX_PO_Attempt_Status_DispatchedDateTime:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=Status:ASC,DispatchedDateTime:ASC:includes=:filter=<null>",
            "PurchaseOrderAudit:IX_PO_Audit_CandidateKey_ChangedDateTime:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=CandidateKey:ASC,ChangedDateTime:DESC:includes=:filter=<null>",
            "PurchaseOrderNotification:IX_PO_Notification_DueWork:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=Status:ASC,NextAttemptDateTime:ASC,CreatedDateTime:ASC,NotificationKey:ASC:includes=LeaseExpiresDateTime,EmailEnvelopeVersion,PayloadSha256:filter=<null>",
            "PurchaseOrderNotification:IX_PO_Notification_BatchKey_CreatedDateTime:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=BatchKey:ASC,CreatedDateTime:DESC:includes=:filter=<null>",
            "PurchaseOrderNotificationAttempt:UQ_PO_NotificationAttempt_AttemptId:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=True:keys=AttemptId:ASC:includes=:filter=<null>",
            "PurchaseOrderNotificationAttempt:UQ_PO_NotificationAttempt_NotificationKey_AttemptNumber:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=True:keys=NotificationKey:ASC,AttemptNumber:ASC:includes=:filter=<null>",
            "PurchaseOrderNotificationAttempt:IX_PO_NotificationAttempt_StartedDateTime:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=StartedDateTime:ASC:includes=:filter=<null>",
            "RelexNotificationEvent:PK_PO_RelexEvent:CLUSTERED:unique=True:primaryKey=True:uniqueConstraint=False:keys=EventKey:ASC:includes=:filter=<null>",
            "RelexNotificationEvent:UQ_PO_RelexEvent_NotificationId:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=True:keys=NotificationId:ASC:includes=:filter=<null>",
            "RelexNotificationEvent:IX_PO_RelexEvent_DueWork:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=Status:ASC,NextAttemptDateTime:ASC,CreatedDateTime:ASC:includes=LeaseExpiresDateTime:filter=<null>",
            "RelexNotificationEvent:UX_PO_RelexEvent_Batch:NONCLUSTERED:unique=True:primaryKey=False:uniqueConstraint=False:keys=BatchKey:ASC:includes=:filter=BatchKey IS NOT NULL",
            "RelexNotificationEvent:IX_PO_RelexEvent_ProcessedFile:NONCLUSTERED:unique=False:primaryKey=False:uniqueConstraint=False:keys=ProcessedFileDateTime:ASC,ProcessingCompletedDateTime:ASC:includes=:filter=<null>"
        };
        Assert.Equal(TableNames, ReadStringManifest(verifySql, "expectedTables"));
        Assert.Equal(ProcedureNames, ReadStringManifest(verifySql, "expectedProcedures"));
        Assert.Equal(roles, ReadStringManifest(verifySql, "expectedRoles"));
        Assert.Equal(expectedIndexes, ReadIndexManifest(verifySql));
        Assert.Equal(
            ExpectedStatusConstraints,
            ReadStatusConstraintManifest(verifySql));
        Assert.Equal(expectedGrants, ReadPairManifest(verifySql, "expectedRoleProcedureGrants", "role", "procedure"));

        var verifyCode = Regex.Replace(SanitizeSql(verifySql), @"\s+", " ").Trim();
        var verifyLiteral = NormalizeSql(verifySql);
        Assert.Single(Regex.Matches(verifyCode, @"\bSET NOCOUNT ON\b").Cast<Match>());
        Assert.Single(Regex.Matches(verifyCode, @"\bSET XACT_ABORT ON\b").Cast<Match>());
        Assert.DoesNotMatch(@"\b(?:CREATE|ALTER|DROP|TRUNCATE|MERGE|INSERT|UPDATE|DELETE)\b", verifyCode);
        Assert.True(Regex.Matches(verifyCode, @"\bTHROW 51000\b").Count >= 9);
        foreach (var manifestName in new[]
                 {
                     "expectedTables", "expectedProcedures", "expectedIndexes", "expectedRoles",
                     "expectedStatusConstraints", "expectedNotificationColumns",
                     "expectedRoleProcedureGrants"
                 })
        {
            Assert.Contains($"OPENJSON(@{manifestName})", verifyCode, StringComparison.OrdinalIgnoreCase);
        }
        Assert.Matches(@"OBJECT_ID\s*\(.*?N'U'\s*\).*?THROW 51000", verifyLiteral);
        Assert.Matches(@"OBJECT_ID\s*\(.*?N'P'\s*\).*?THROW 51000", verifyLiteral);
        Assert.Matches(@"sys\.indexes.*?@expectedIndexes.*?THROW 51000", verifyCode);
        Assert.Matches(@"\[is_disabled\] = 0.*?\[is_hypothetical\] = 0.*?\[type_desc\] = expected\.\[IndexType\].*?\[is_unique\] = expected\.\[IsUnique\].*?\[is_primary_key\] = expected\.\[IsPrimaryKey\].*?\[is_unique_constraint\] = expected\.\[IsUniqueConstraint\]", verifyCode);
        Assert.Matches(@"sys\.index_columns AS keyColumn.*?sys\.columns AS keyColumnMetadata.*?OPENJSON\s*\(\s*expected\.\[KeysJson\]\s*\).*?keyColumn\.\[key_ordinal\].*?keyColumn\.\[is_descending_key\]", verifyCode);
        Assert.Matches(@"sys\.index_columns AS includeColumn.*?sys\.columns AS includeColumnMetadata.*?includeColumn\.\[is_included_column\] = 1.*?OPENJSON\s*\(\s*expected\.\[IncludesJson\]\s*\)", verifyCode);
        Assert.Matches(@"\[filter_definition\].*?UPPER.*?REPLACE.*?expected\.\[FilterDefinition\]", verifyCode);
        var exactIndexCountCheck = Regex.Match(
            verifyCode,
            @"SELECT COUNT_BIG\(\*\) FROM sys\.indexes AS \[index\] INNER JOIN sys\.tables AS \[table\].*?\[index\]\.\[index_id\] > 0.*?\[index\]\.\[name\] IS NOT NULL.*?<> \(SELECT COUNT_BIG\(\*\) FROM OPENJSON\(@expectedIndexes\)\)");
        Assert.True(exactIndexCountCheck.Success, "Expected an exact count of every named po index.");
        Assert.DoesNotContain("[is_hypothetical]", exactIndexCountCheck.Value, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("[is_disabled]", exactIndexCountCheck.Value, StringComparison.OrdinalIgnoreCase);
        Assert.Matches(@"sys\.database_principals.*?@expectedRoles.*?THROW 51000", verifyCode);
        Assert.Matches(@"principal\.\[type\] = N'R'.*?principal\.\[owning_principal_id\] = DATABASE_PRINCIPAL_ID\s*\(\s*N'dbo'\s*\)", verifyLiteral);
        Assert.Matches(@";WITH \[ParentRoleMembership\] AS\s*\(.*?OPENJSON\s*\(\s*@expectedRoles\s*\).*?sys\.database_role_members.*?UNION ALL.*?\[ParentRoleMembership\].*?sys\.database_role_members.*?\).*?OPTION\s*\(\s*MAXRECURSION\s+32767\s*\).*?THROW 51000", verifyLiteral);
        Assert.Matches(@"@expectedStatusConstraints.*?sys\.check_constraints.*?\[is_disabled\] = 0.*?\[is_not_trusted\] = 0.*?THROW 51000", verifyCode);
        Assert.Matches(@"sys\.check_constraints.*?<> \(SELECT COUNT_BIG\(\*\) FROM OPENJSON\(@expectedStatusConstraints\)\).*?THROW 51000", verifyCode);
        Assert.Matches(
            @"CHARINDEX\s*\(\s*N?'\['\s*\+\s*expectedStatusColumn\.\[ColumnName\]\s*\+\s*N?'\]'\s*,\s*statusConstraint\.\[definition\]\s*\)\s*>\s*0",
            verifyLiteral);
        Assert.DoesNotMatch(@"statusConstraint\.\[definition\]\s+LIKE", verifyCode);
        foreach (var tableName in LegacyStatusTableNames)
        {
            Assert.Matches(
                $@"OBJECT_ID\s*\(\s*N?'\[po\]\.\[{Regex.Escape(tableName)}\]'\s*,\s*N?'U'\s*\)\s+IS\s+NOT\s+NULL.*?THROW 51000",
                verifyLiteral);
        }
        Assert.Matches(@"@expectedRoleProcedureGrants.*?sys\.database_permissions.*?permission_name\] = N'EXECUTE'.*?THROW 51000", verifyLiteral);
        Assert.Matches(@"FROM sys\.database_permissions AS directPermission.*?OPENJSON\s*\(\s*@expectedRoles\s*\).*?NOT\s*\(.*?directPermission\.\[class\] = 1.*?directPermission\.\[minor_id\] = 0.*?directPermission\.\[permission_name\] = N'EXECUTE'.*?directPermission\.\[state\] = N'G'.*?procedureObject\.\[type\] IN\s*\(\s*N'P'\s*,\s*N'PC'\s*\).*?procedureSchema\.\[name\] = N'po'.*?OPENJSON\s*\(\s*@expectedRoleProcedureGrants\s*\).*?\).*?THROW 51000", verifyLiteral);
        Assert.Matches(@"sys\.database_permissions.*?permission_name\] = N'EXECUTE'.*?NOT EXISTS.*?OPENJSON\s*\(\s*@expectedRoleProcedureGrants\s*\).*?THROW 51000", verifyLiteral);
        Assert.Matches(@"permission_name\] = N'EXECUTE'.*?\[class\] IN\s*\(\s*0\s*,\s*3\s*\).*?THROW 51000", verifyLiteral);
        Assert.Matches(@"permission_name\] IN\s*\(\s*N'SELECT'\s*,\s*N'INSERT'\s*,\s*N'UPDATE'\s*,\s*N'DELETE'\s*\).*?\[class\] IN\s*\(\s*0\s*,\s*3\s*\).*?\[class\] = 1.*?\[type\] = N'U'.*?THROW 51000", verifyLiteral);
    }

    private static IReadOnlyList<SqlScript> LoadSqlScripts()
    {
        var databaseDirectory = Path.Combine(
            AppContext.BaseDirectory,
            "TestData",
            "Database");

        Assert.True(
            Directory.Exists(databaseDirectory),
            $"Copied SQL deployment directory was not found: {databaseDirectory}");

        var sqlFiles = Directory
            .GetFiles(databaseDirectory, "*.sql", SearchOption.AllDirectories)
            .OrderBy(path => path, StringComparer.Ordinal)
            .ToArray();

        Assert.NotEmpty(sqlFiles);

        return sqlFiles
            .Select(path => new SqlScript(
                Path.GetRelativePath(databaseDirectory, path),
                File.ReadAllText(path)))
            .ToArray();
    }

    private static string GetRepositoryRoot()
    {
        foreach (var startPath in new[] { Directory.GetCurrentDirectory(), AppContext.BaseDirectory })
        {
            var directory = new DirectoryInfo(startPath);
            while (directory is not null)
            {
                if (File.Exists(Path.Combine(directory.FullName, "STUK.PurchaseOrderService.sln")))
                {
                    return directory.FullName;
                }

                directory = directory.Parent;
            }
        }

        Assert.Fail("Could not locate the Purchase Order Service repository root.");
        return string.Empty;
    }

    [Fact]
    public void EmailProcedures_PreserveSenderParameterAndResultContracts()
    {
        var sql = LoadSingleScript(LoadSqlScripts(), "080-support-notification-procedures.sql");
        // Break: a renamed/reordered parameter or result column prevents the sender repository binding.
        var signatures = new Dictionary<string, string>
        {
            ["sp_enqueue_purchase_order_email_notification"] = "@notificationId uniqueidentifier, @batchId uniqueidentifier = NULL, @eventType varchar(100), @businessCorrelationId nvarchar(256), @emailEnvelopeVersion smallint, @emailEnvelopeJson nvarchar(max), @templateKey nvarchar(100) = NULL, @recipientGroupKey nvarchar(100) = NULL, @attachmentBlobName nvarchar(512) = NULL, @createdDateTime datetimeoffset(3)",
            ["sp_claim_purchase_order_email_notifications"] = "@asOfDateTime datetimeoffset(3), @leaseDurationSeconds int, @maxNotifications int, @maxAttemptsPerMinute int, @maxAttemptsPerHour int",
            ["sp_defer_purchase_order_email_notification"] = "@notificationId uniqueidentifier, @leaseId uniqueidentifier, @nextAttemptDateTime datetimeoffset(3), @completedDateTime datetimeoffset(3), @expectedNotificationRowVersion binary(8)",
            ["sp_reschedule_purchase_order_email_notification"] = "@notificationId uniqueidentifier, @leaseId uniqueidentifier, @outcome varchar(50), @failureCategory varchar(50), @failureCode varchar(100) = NULL, @failureDescription nvarchar(1000) = NULL, @httpStatusCode smallint = NULL, @nextAttemptDateTime datetimeoffset(3), @completedDateTime datetimeoffset(3), @expectedNotificationRowVersion binary(8)",
            ["sp_complete_purchase_order_email_notification"] = "@notificationId uniqueidentifier, @leaseId uniqueidentifier, @status varchar(50), @attemptOutcome varchar(50), @incrementFailureCount bit, @providerMessageId nvarchar(256) = NULL, @failureCategory varchar(50) = NULL, @failureCode varchar(100) = NULL, @failureDescription nvarchar(1000) = NULL, @httpStatusCode smallint = NULL, @completedDateTime datetimeoffset(3), @expectedNotificationRowVersion binary(8)",
            ["sp_get_purchase_order_email_notification_queue_summary"] = "@asOfDateTime datetimeoffset(3), @terminalFailureSinceDateTime datetimeoffset(3)"
        };
        foreach (var (name, signature) in signatures)
        {
            Assert.Matches(Regex.Escape($"CREATE OR ALTER PROCEDURE [po].[{name}] {signature} AS"),
                EmailProcedure(sql, name));
        }

        var resultColumns = new Dictionary<string, string>
        {
            ["sp_enqueue_purchase_order_email_notification"] = "[NotificationId], [Status], [NextAttemptDateTime], [AttemptCount], [FailureCount], [ThrottleCount], [PayloadSha256], [RowVersion]",
            ["sp_claim_purchase_order_email_notifications"] = "[NotificationId], [EventType], [BusinessCorrelationId], [EmailEnvelopeVersion], [EmailEnvelopeJson], [PayloadSha256], [AttemptCount], [FailureCount], [ThrottleCount], [LeaseId], [LeaseExpiresDateTime], [RowVersion]",
            ["sp_defer_purchase_order_email_notification"] = "[NotificationId], [Status], [NextAttemptDateTime], [FailureCount], [ThrottleCount], [RowVersion]",
            ["sp_reschedule_purchase_order_email_notification"] = "[NotificationId], [Status], [NextAttemptDateTime], [FailureCount], [ThrottleCount], [RowVersion]",
            ["sp_complete_purchase_order_email_notification"] = "[NotificationId], [Status], [SentDateTime], [CompletedDateTime], [FailureCount], [ThrottleCount], [RowVersion]"
        };
        foreach (var (name, columns) in resultColumns)
        {
            Assert.Matches(Regex.Escape($"SELECT {columns} FROM @") + @"\w+", EmailProcedure(sql, name));
        }
        var summary = EmailProcedure(sql, "sp_get_purchase_order_email_notification_queue_summary");
        Assert.Equal(new[] { "ClaimablePendingCount", "OldestClaimablePendingDateTime", "DelayedPendingCount",
                "ActiveLeasedCount", "ExpiredLeasedCount", "UnsendableLegacyPendingCount", "TerminalFailureCount" },
            Regex.Matches(summary, @"AS \[(?<name>\w+)\]").Select(match => match.Groups["name"].Value));
    }

    [Fact]
    public void EmailEnqueue_RejectsMissingOrMismatchedIdentityBeforePersistingAndLocksReplay()
    {
        var sql = EmailProcedure(LoadSingleScript(LoadSqlScripts(), "080-support-notification-procedures.sql"),
            "sp_enqueue_purchase_order_email_notification");
        // Break: SQL UNKNOWN accepts absent/null identity, or an idempotency replay silently changes content.
        Assert.Matches(@"@envelopeNotificationId IS NULL OR @envelopeNotificationId <> @notificationId.*?@envelopeBusinessCorrelationId IS NULL.*?COLLATE Latin1_General_100_BIN2.*?<> @businessCorrelationId COLLATE Latin1_General_100_BIN2.*?@envelopeSchemaVersion IS NULL OR @envelopeSchemaVersion <> @emailEnvelopeVersion.*?THROW 51004.*?HASHBYTES\s*\(\s*'SHA2_256'\s*,\s*CONVERT\s*\(\s*varbinary\(max\)\s*,\s*@emailEnvelopeJson\s*\)\s*\)", sql);
        Assert.Matches(@"ISJSON\s*\(\s*@emailEnvelopeJson\s*\) <> 1.*?DATALENGTH\s*\(\s*@emailEnvelopeJson\s*\) > 20 \* 1024 \* 1024.*?THROW 51004", sql);
        Assert.Matches(@"BEGIN TRANSACTION.*?FROM \[po\]\.\[PurchaseOrderNotification\] WITH \(UPDLOCK, HOLDLOCK\).*?WHERE \[NotificationId\] = @notificationId.*?EXCEPT.*?\[PayloadSha256\].*?\[EmailEnvelopeVersion\].*?\[EventType\].*?\[BusinessCorrelationId\].*?\[BatchKey\].*?\[TemplateKey\].*?\[RecipientGroupKey\].*?\[AttachmentBlobName\].*?\[CreatedDateTime\].*?THROW 51004.*?INSERT INTO \[po\]\.\[PurchaseOrderNotification\]", sql);
    }

    [Fact]
    public void EmailClaim_SerializesQuotaThroughAtomicReclaimAndAttemptInsertion()
    {
        var sql = EmailProcedure(LoadSingleScript(LoadSqlScripts(), "080-support-notification-procedures.sql"),
            "sp_claim_purchase_order_email_notifications");
        // Break: concurrent Function invocations spend the same minute/hour capacity before inserting attempts.
        Assert.Matches(@"BEGIN TRANSACTION; DECLARE @applicationLockResult int; EXEC @applicationLockResult = sys\.sp_getapplock @Resource = N'po.email-notification-claim-quota', @LockMode = 'Exclusive', @LockOwner = 'Transaction', @LockTimeout = 10000; IF @applicationLockResult < 0 BEGIN ;THROW 51002.*?SELECT @minuteAttempts = COUNT_BIG\(\*\).*?\[StartedDateTime\] > DATEADD\(MINUTE, -1, @asOfDateTime\).*?SELECT @hourAttempts = COUNT_BIG\(\*\).*?\[StartedDateTime\] > DATEADD\(HOUR, -1, @asOfDateTime\).*?WITH claimable AS.*?UPDATE notification.*?INSERT INTO \[po\]\.\[PurchaseOrderNotificationAttempt\].*?COMMIT TRANSACTION", sql);
        Assert.DoesNotMatch(@"THROW 51005|sp_releaseapplock", sql);
        Assert.Matches(@"SELECT TOP \(@claimCount\).*?WITH \(UPDLOCK, READPAST, READCOMMITTEDLOCK\).*?\[Channel\] = 'EMAIL'.*?\[EmailEnvelopeVersion\] = 1.*?\[EmailEnvelopeJson\] IS NOT NULL.*?\[Status\] = 'PENDING'.*?\[NextAttemptDateTime\] <= @asOfDateTime.*?\[Status\] = 'SENDING'.*?\[LeaseExpiresDateTime\] <= @asOfDateTime.*?ORDER BY notification\.\[NextAttemptDateTime\], notification\.\[CreatedDateTime\], notification\.\[NotificationKey\]", sql);
        // Break: reclaim leaves two open attempts, or uses an AttemptId different from the returned lease.
        Assert.Matches(@"\[Outcome\] = 'LEASE_EXPIRED'.*?attempt\.\[AttemptId\] = claimed\.\[PreviousLeaseId\].*?attempt\.\[Outcome\] = 'STARTED'.*?INSERT INTO \[po\]\.\[PurchaseOrderNotificationAttempt\].*?SELECT \[LeaseId\], \[NotificationKey\], \[AttemptCount\], @asOfDateTime, 'STARTED'", sql);
        Assert.Matches(@"\[LeaseId\] = NEWID\(\).*?\[AttemptCount\] = notification\.\[AttemptCount\] \+ 1", sql);
    }

    [Fact]
    public void EmailTransitions_RejectStaleOwnersAndKeepRetryOutcomeAndCountersDistinct()
    {
        var source = LoadSingleScript(LoadSqlScripts(), "080-support-notification-procedures.sql");
        foreach (var name in new[] { "sp_defer_purchase_order_email_notification",
                     "sp_reschedule_purchase_order_email_notification", "sp_complete_purchase_order_email_notification" })
        {
            var sql = EmailProcedure(source, name);
            // Break: stale workers update a newer lease or notification state without closing its own attempt.
            Assert.Matches(@"BEGIN TRANSACTION.*?WITH \(UPDLOCK, HOLDLOCK\).*?@notificationKey IS NULL.*?THROW 51001.*?@notificationRowVersion <> @expectedNotificationRowVersion.*?THROW 51002.*?@currentStatus <> 'SENDING'.*?@currentLeaseId <> @leaseId.*?THROW 51003.*?UPDATE \[po\]\.\[PurchaseOrderNotification\].*?\[LeaseId\] = NULL, \[LeaseExpiresDateTime\] = NULL.*?UPDATE \[po\]\.\[PurchaseOrderNotificationAttempt\].*?\[AttemptId\] = @leaseId.*?\[NotificationKey\] = @notificationKey.*?\[Outcome\] = 'STARTED'.*?IF @@ROWCOUNT <> 1.*?THROW 51003.*?COMMIT TRANSACTION", sql);
        }
        var defer = EmailProcedure(source, "sp_defer_purchase_order_email_notification");
        Assert.DoesNotMatch(@"\[(FailureCount|ThrottleCount)\] =", defer);
        Assert.Matches(@"\[Outcome\] = 'DEFERRED'", defer);
        var reschedule = EmailProcedure(source, "sp_reschedule_purchase_order_email_notification");
        Assert.Matches(@"\[FailureCount\] = \[FailureCount\] \+ CASE WHEN @outcome = 'TRANSIENT_FAILURE' THEN 1 ELSE 0 END, \[ThrottleCount\] = \[ThrottleCount\] \+ CASE WHEN @outcome = 'THROTTLED' THEN 1 ELSE 0 END", reschedule);
        var complete = EmailProcedure(source, "sp_complete_purchase_order_email_notification");
        // Break: retry exhaustion is incorrectly recorded as permanent failure or loses the eighth failure.
        Assert.Matches(@"@status = 'SENT' AND @attemptOutcome = 'SUCCEEDED' AND @incrementFailureCount = 0.*?@status = 'FAILED' AND @attemptOutcome = 'PERMANENT_FAILURE' AND @incrementFailureCount = 0.*?@status = 'FAILED' AND @attemptOutcome = 'TRANSIENT_FAILURE' AND @incrementFailureCount = 1.*?THROW 51004", complete);
        Assert.Matches(@"\[FailureCount\] = \[FailureCount\] \+ CONVERT\(int, @incrementFailureCount\).*?\[Outcome\] = @attemptOutcome", complete);
    }

    [Fact]
    public void EmailClaim_CountsLaterRecordedAttemptsWhenCallerTimeMovesBackward()
    {
        var sql = EmailProcedure(LoadSingleScript(LoadSqlScripts(), "080-support-notification-procedures.sql"),
            "sp_claim_purchase_order_email_notifications");
        // Break: an older caller excludes a later committed attempt and spends its minute/hour slot again.
        foreach (var (counter, unit) in new[] { ("minuteAttempts", "MINUTE"), ("hourAttempts", "HOUR") })
        {
            Assert.Matches($@"SELECT @{counter} = COUNT_BIG\(\*\) FROM \[po\]\.\[PurchaseOrderNotificationAttempt\] WHERE \[StartedDateTime\] > DATEADD\({unit}, -1, @asOfDateTime\);", sql);
        }
    }

    [Theory]
    [InlineData("sp_reschedule_purchase_order_email_notification")]
    [InlineData("sp_complete_purchase_order_email_notification")]
    public void EmailWriters_RejectHttp429OutsideThrottleReschedule(string name)
    {
        var sql = EmailProcedure(LoadSingleScript(LoadSqlScripts(), "080-support-notification-procedures.sql"), name);
        // Break: HTTP 429 increments ordinary failures or becomes terminal; a non-429 response is mislabeled throttled.
        if (name == "sp_reschedule_purchase_order_email_notification")
        {
            Assert.Matches(@"OR \(@httpStatusCode = 429 AND @outcome <> 'THROTTLED'\) OR \(@outcome = 'THROTTLED' AND \(@httpStatusCode IS NULL OR @httpStatusCode <> 429\)\).*?THROW 51004.*?BEGIN TRANSACTION", sql);
        }
        else
        {
            Assert.Matches(@"OR @httpStatusCode = 429.*?THROW 51004.*?BEGIN TRANSACTION", sql);
        }
    }

    [Fact]
    public void EmailConcurrencyAcceptance_RequiresAnUnavailableExclusiveQuotaLockBeforeClaim()
    {
        var b = NormalizeSql(File.ReadAllText(Path.Combine(GetAcceptanceDirectory(), "058-email-notification-concurrency-session-b.sql")));
        // Break: starting B after A commits produces an empty result without any proof of lock contention.
        Assert.Matches(@"BEGIN TRANSACTION; DECLARE @quotaLockAvailable int = APPLOCK_TEST\('public', N'po.email-notification-claim-quota', 'Exclusive', 'Transaction'\); IF @quotaLockAvailable IS NULL OR @quotaLockAvailable <> 0 BEGIN ;THROW 52\d{3}.*?END; RAISERROR \('PASS:SESSION_B_QUOTA_LOCK_CONTENTION_CONFIRMED', 10, 1\) WITH NOWAIT; INSERT INTO @claimed EXEC \[po\]\.\[sp_claim_purchase_order_email_notifications\]", b);
        Assert.Matches(@"IF EXISTS \(SELECT 1 FROM @claimed\).*?COMMIT TRANSACTION; PRINT 'PASS:SESSION_B_QUOTA_NOT_DOUBLE_SPENT'; BEGIN TRANSACTION;.*?DELETE attempt", b);
    }

    [Fact]
    public void EmailConcurrencyAcceptance_HoldsQuotaUntilCommitAndCleansOnlyOwnedFixtures()
    {
        var a = NormalizeSql(File.ReadAllText(Path.Combine(GetAcceptanceDirectory(), "057-email-notification-concurrency-session-a.sql")));
        var b = NormalizeSql(File.ReadAllText(Path.Combine(GetAcceptanceDirectory(), "058-email-notification-concurrency-session-b.sql")));
        // Break: the proof releases its quota lock before B runs, or B deletes A's fixtures before observing quota.
        // Break: uncommitted seed rows can make READPAST return zero without quota serialization.
        Assert.Matches(@"BEGIN TRANSACTION; EXEC \[po\]\.\[sp_enqueue_purchase_order_email_notification\].*?EXEC \[po\]\.\[sp_enqueue_purchase_order_email_notification\].*?COMMIT TRANSACTION; BEGIN TRANSACTION; INSERT INTO @claimed EXEC \[po\]\.\[sp_claim_purchase_order_email_notifications\]", a);
        Assert.Matches(@"BEGIN TRANSACTION.*?sp_claim_purchase_order_email_notifications.*?@maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 1.*?SESSION_A_READY.*?WAITFOR DELAY '00:00:05'.*?COMMIT TRANSACTION.*?SESSION_A_COMMITTED", a);
        Assert.Matches(@"sp_claim_purchase_order_email_notifications.*?@maxAttemptsPerMinute = 1, @maxAttemptsPerHour = 1.*?IF EXISTS \(SELECT 1 FROM @claimed\).*?THROW 52\d{3}.*?DELETE attempt.*?DELETE FROM \[po\]\.\[PurchaseOrderNotification\]", b);
        Assert.DoesNotMatch(@"DELETE.*?sp_claim_purchase_order_email_notifications", b);
        foreach (var sql in new[] { a, b })
        {
            Assert.Matches(@"SET XACT_ABORT ON", sql);
            Assert.Matches(@"BEGIN CATCH IF XACT_STATE\(\) <> 0 BEGIN ROLLBACK TRANSACTION; END;.*?DELETE attempt.*?DELETE FROM \[po\]\.\[PurchaseOrderNotification\].*?THROW;", sql);
        }
    }

    [Fact]
    public void RelexProducerClaims_BoundAggregatePayloadWhileAllowingOneLargeEventToProgress()
    {
        var sql = EmailProcedure(LoadSingleScript(LoadSqlScripts(), "081-relex-notification-procedures.sql"),
            "sp_prepare_and_claim_relex_notification_events");

        // Break: a 100-row claim materializes up to 100 individually valid 36 MiB snapshots.
        Assert.Matches(@"TOP \(@maxEvents\).*?DATALENGTH\(\[CompositionSettingsJson\]\).*?DATALENGTH\(\[OutcomeRowsJson\]\).*?DATALENGTH\(\[EmailEnvelopeJson\]\)", sql);
        Assert.Matches(@"SUM\(\[PayloadBytes\]\) OVER \(ORDER BY \[NextAttemptDateTime\], \[CreatedDateTime\], \[EventKey\] ROWS UNBOUNDED PRECEDING\)", sql);
        Assert.Contains("WHERE sized.[Ordinal] = 1 OR sized.[RunningPayloadBytes] <= 32 * 1024 * 1024", sql, StringComparison.Ordinal);
        Assert.Contains("WITH (UPDLOCK, READPAST, READCOMMITTEDLOCK)", sql, StringComparison.Ordinal);
        Assert.Matches(@"IF @expectedCount > 100000.*?SET @tooLarge = 1; END ELSE BEGIN.*?INSERT INTO @rows", sql);
    }

    private static string EmailProcedure(string sql, string name) => NormalizeSql(
        Regex.Split(sql, @"^[ \t]*GO[ \t]*\r?$", RegexOptions.Multiline | RegexOptions.IgnoreCase)
            .SingleOrDefault(batch => batch.Contains($"CREATE OR ALTER PROCEDURE [po].[{name}]", StringComparison.Ordinal))
        ?? string.Empty);

    private static string GetAcceptanceDirectory()
    {
        var acceptanceDirectory = Path.Combine(
            AppContext.BaseDirectory,
            "TestData",
            "Database",
            "tests");

        Assert.True(
            Directory.Exists(acceptanceDirectory),
            $"Copied SQL acceptance directory was not found: {acceptanceDirectory}");

        return acceptanceDirectory;
    }

    private static void AssertAcceptanceGuard(string fileName, string sql)
    {
        var normalizedSql = NormalizeSql(sql);
        Assert.True(
            Regex.IsMatch(
                normalizedSql,
                @"^SET NOCOUNT ON; SET QUOTED_IDENTIFIER ON; IF N'\$\(AllowDestructiveAcceptanceTests\)' <> N'1' BEGIN ;?THROW 52000\b"),
            $"{fileName} must begin with the fail-closed SQLCMD guard.");
        Assert.DoesNotContain(
            ":setvar AllowDestructiveAcceptanceTests",
            sql,
            StringComparison.OrdinalIgnoreCase);
        Assert.Contains(
            "approved disposable/non-production database",
            sql,
            StringComparison.Ordinal);
    }

    private static string LoadSingleScript(
        IReadOnlyList<SqlScript> scripts,
        string fileName)
    {
        var matchingScripts = scripts
            .Where(script => string.Equals(
                Path.GetFileName(script.Path),
                fileName,
                StringComparison.OrdinalIgnoreCase))
            .ToArray();

        Assert.True(
            matchingScripts.Length == 1,
            $"Expected exactly one copied {fileName} file, but found {matchingScripts.Length}.");

        return matchingScripts[0].Content;
    }

    private static void AssertSchemaContract(string schemaSql)
    {
        var normalizedSql = NormalizeSql(schemaSql);

        Assert.Matches(
            @"\bIF\s+SCHEMA_ID\s*\(\s*N?'po'\s*\)\s+IS\s+NULL\b",
            normalizedSql);
        Assert.Matches(
            @"CREATE SCHEMA \[po\] AUTHORIZATION \[dbo\]",
            normalizedSql);
        Assert.Empty(DiscoverTableNames(SanitizeSql(schemaSql)));
        Assert.DoesNotMatch(
            @"\b(?:CREATE\s+TABLE|MERGE|INSERT|UPDATE|DELETE)\b",
            normalizedSql);

        foreach (var tableName in LegacyStatusTableNames)
        {
            Assert.DoesNotContain(tableName, normalizedSql, StringComparison.OrdinalIgnoreCase);
        }
    }

    private static void AssertOperationalKeyContract(string operationalSql)
    {
        var keyContracts = new[]
        {
            new OperationalKeyContract("PurchaseOrderBatch", "BatchKey", "BatchId"),
            new OperationalKeyContract("PurchaseOrderCandidate", "CandidateKey", "CandidateId"),
            new OperationalKeyContract("PurchaseOrderSubmissionAttempt", "AttemptKey", "AttemptId"),
            new OperationalKeyContract("PurchaseOrderAudit", "AuditKey", null),
            new OperationalKeyContract("PurchaseOrderNotification", "NotificationKey", "NotificationId"),
            new OperationalKeyContract("PurchaseOrderNotificationAttempt", "NotificationAttemptKey", "AttemptId")
        };

        foreach (var contract in keyContracts)
        {
            var tableDefinition = ExtractCreateTableDefinition(
                operationalSql,
                contract.TableName);

            Assert.Matches(
                $@"\[{Regex.Escape(contract.KeyColumn)}\]\s+bigint\s+IDENTITY\s*\(\s*1\s*,\s*1\s*\)\s+NOT\s+NULL",
                tableDefinition);
            Assert.Matches(
                $@"\bPRIMARY\s+KEY\s+CLUSTERED\s*\(\s*\[{Regex.Escape(contract.KeyColumn)}\]\s*\)",
                tableDefinition);

            if (contract.PublicIdColumn is not null)
            {
                Assert.Matches(
                    $@"\bUNIQUE(?:\s+NONCLUSTERED)?\s*\(\s*\[{Regex.Escape(contract.PublicIdColumn)}\]\s*\)",
                    tableDefinition);
            }
        }

        var applicationSettingDefinition = ExtractCreateTableDefinition(
            operationalSql,
            "ApplicationSetting");
        Assert.Matches(@"\[Context\]\s+nvarchar\(100\)\s+NOT\s+NULL", applicationSettingDefinition);
        Assert.Matches(@"\[Key\]\s+nvarchar\(256\)\s+NOT\s+NULL", applicationSettingDefinition);
        Assert.Matches(@"\[Value\]\s+nvarchar\(max\)\s+NOT\s+NULL", applicationSettingDefinition);
        Assert.Matches(
            @"PRIMARY\s+KEY\s+CLUSTERED\s*\(\s*\[Context\]\s*,\s*\[Key\]\s*\)",
            applicationSettingDefinition);

        var normalizedSql = NormalizeSql(operationalSql);
        Assert.Equal(
            keyContracts.Length + 1,
            Regex.Matches(
                normalizedSql,
                @"\bPRIMARY\s+KEY\s+CLUSTERED\b",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Count);
        Assert.Equal(
            keyContracts.Count(contract => contract.PublicIdColumn is not null),
            Regex.Matches(
                normalizedSql,
                @"\bCONSTRAINT\s+\[[^\]]+\]\s+UNIQUE(?:\s+NONCLUSTERED)?\s*\(\s*\[(?:BatchId|CandidateId|AttemptId|NotificationId)\]\s*\)",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Count);
    }

    private static void AssertOperationalCheckContract(string operationalSql)
    {
        var batchDefinition = ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderBatch");
        AssertStatusCheckConstraint(
            batchDefinition,
            "CK_PO_Batch_Status",
            "Status",
            BatchStatusValues);
        Assert.Matches(@"\[SourceFilePath\]\s+nvarchar\(512\)\s+NOT\s+NULL", batchDefinition);
        Assert.DoesNotContain("[BlobName]", batchDefinition, StringComparison.OrdinalIgnoreCase);
        Assert.Matches(@"CHECK\s*\(\s*\[FileContentLength\]\s*>=\s*0\s*\)", batchDefinition);
        Assert.Matches(@"CHECK\s*\(\s*\[ExpectedRowCount\]\s+IS\s+NULL\s+OR\s+\[ExpectedRowCount\]\s*>=\s*0\s*\)", batchDefinition);
        Assert.Matches(@"CHECK\s*\(\s*\[ParsedRowCount\]\s*>=\s*0\s+AND\s+\[CandidateCount\]\s*>=\s*0\s*\)", batchDefinition);

        var candidateDefinition = ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderCandidate");
        AssertStatusCheckConstraint(
            candidateDefinition,
            "CK_PO_Candidate_Status",
            "Status",
            CandidateStatusValues);
        Assert.Matches(@"\[SourceRowCount\]\s+int\s+NULL", candidateDefinition);
        Assert.Matches(@"CHECK\s*\(\s*\[Kind\]\s+IN\s*\(\s*'API'\s*,\s*'RELEX'\s*\)\s*\)", candidateDefinition);
        Assert.Matches(@"CONSTRAINT\s+\[CK_PO_Candidate_SourceRowCount\]\s+CHECK\s*\(\s*\(\s*\[Kind\]\s*=\s*'RELEX'\s+AND\s+\[SourceRowCount\]\s*>\s*0\s*\)\s+OR\s+\(\s*\[Kind\]\s*=\s*'API'\s+AND\s+\[SourceRowCount\]\s+IS\s+NULL\s*\)\s*\)", candidateDefinition);
        Assert.Matches(@"CHECK\s*\(\s*ISJSON\s*\(\s*\[PayloadJson\]\s*\)\s*=\s*1\s*\)", candidateDefinition);
        Assert.Matches(@"CHECK\s*\(\s*\[PendingRetriesCount\]\s*>=\s*0\s+AND\s+\[ProcessingRetriesCount\]\s*>=\s*0\s*\)", candidateDefinition);
        AssertLeaseContract(candidateDefinition);

        var attemptDefinition = ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderSubmissionAttempt");
        AssertStatusCheckConstraint(
            attemptDefinition,
            "CK_PO_Attempt_Status",
            "Status",
            AttemptStatusValues);
        Assert.Matches(@"CHECK\s*\(\s*\[AttemptNumber\]\s*>=\s*1\s*\)", attemptDefinition);
        Assert.Matches(@"CHECK\s*\(\s*ISJSON\s*\(\s*\[RequestPayloadJson\]\s*\)\s*=\s*1\s*\)", attemptDefinition);
        Assert.Matches(@"CHECK\s*\(\s*\[ResponsePayloadJson\]\s+IS\s+NULL\s+OR\s+ISJSON\s*\(\s*\[ResponsePayloadJson\]\s*\)\s*=\s*1\s*\)", attemptDefinition);
        Assert.Matches(@"CHECK\s*\(\s*\[HttpStatusCode\]\s+IS\s+NULL\s+OR\s+\[HttpStatusCode\]\s+BETWEEN\s+100\s+AND\s+599\s*\)", attemptDefinition);
        Assert.Matches(@"CHECK\s*\(\s*\[IconCreatedStatus\]\s+IS\s+NULL\s+OR\s+\[IconCreatedStatus\]\s+IN\s*\(\s*'activated'\s*,\s*'notactivated'\s*,\s*'received'\s*,\s*'undefined'\s*\)\s*\)", attemptDefinition);

        var auditDefinition = ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderAudit");
        AssertStatusCheckConstraint(
            auditDefinition,
            "CK_PO_Audit_PreviousStatus",
            "PreviousStatus",
            CandidateStatusValues,
            isNullable: true);
        AssertStatusCheckConstraint(
            auditDefinition,
            "CK_PO_Audit_CurrentStatus",
            "CurrentStatus",
            CandidateStatusValues,
            isNullable: true);
        Assert.Matches(@"CHECK\s*\(\s*\[Method\]\s+IN\s*\(\s*'API'\s*,\s*'INGESTION'\s*,\s*'PROCESSOR'\s*,\s*'SUPPORT'\s*,\s*'SYSTEM'\s*\)\s*\)", auditDefinition);
        AssertNullableJsonCheck(auditDefinition, "PreviousPayloadJson");
        AssertNullableJsonCheck(auditDefinition, "CurrentPayloadJson");

        AssertUtcTimestampContract(batchDefinition, [
            "DiscoveredDateTime", "IngestionStartedDateTime", "CompletedDateTime", "UpdatedDateTime"
        ]);
        AssertUtcTimestampContract(candidateDefinition, [
            "StatusDateTime", "AcceptedDateTime", "CreatedDateTime", "UpdatedDateTime",
            "RefreshDateTime", "LeaseAcquiredDateTime", "LeaseExpiresDateTime"
        ]);
        AssertUtcTimestampContract(attemptDefinition, [
            "PreparedDateTime", "DispatchedDateTime", "CompletedDateTime"
        ]);
        AssertUtcTimestampContract(auditDefinition, ["ChangedDateTime"]);
        var notificationDefinition = ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderNotification");
        AssertStatusCheckConstraint(
            notificationDefinition,
            "CK_PO_Notification_Status",
            "Status",
            NotificationStatusValues);
        AssertUtcTimestampContract(
            notificationDefinition,
            [
                "NextAttemptDateTime", "LastAttemptDateTime", "LeaseExpiresDateTime",
                "CreatedDateTime", "SentDateTime", "CompletedDateTime"
            ]);

        var notificationAttemptDefinition = ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderNotificationAttempt");
        AssertStatusCheckConstraint(
            notificationAttemptDefinition,
            "CK_PO_NotificationAttempt_Outcome",
            "Outcome",
            NotificationAttemptOutcomeValues);
        Assert.Matches(
            @"CHECK\s*\(\s*\[AttemptNumber\]\s*>=\s*1\s*\)",
            notificationAttemptDefinition);
        Assert.Matches(
            @"CHECK\s*\(\s*\[HttpStatusCode\]\s+IS\s+NULL\s+OR\s+\[HttpStatusCode\]\s+BETWEEN\s+100\s+AND\s+599\s*\)",
            notificationAttemptDefinition);
        AssertUtcTimestampContract(
            notificationAttemptDefinition,
            ["StartedDateTime", "CompletedDateTime"]);

        Assert.Matches(
            @"CHECK\s*\(\s*\[AttemptCount\]\s*>=\s*0\s+AND\s+\[FailureCount\]\s*>=\s*0\s+AND\s+\[ThrottleCount\]\s*>=\s*0\s*\)",
            notificationDefinition);
        Assert.Matches(
            @"CHECK\s*\(\s*\(\s*\[EmailEnvelopeVersion\]\s+IS\s+NULL\s+AND\s+\[EmailEnvelopeJson\]\s+IS\s+NULL\s+AND\s+\[PayloadSha256\]\s+IS\s+NULL\s+AND\s+\[EventType\]\s+IS\s+NULL\s+AND\s+\[BusinessCorrelationId\]\s+IS\s+NULL\s*\)\s+OR\s+\(\s*\[EmailEnvelopeVersion\]\s+IS\s+NOT\s+NULL\s+AND\s+\[EmailEnvelopeJson\]\s+IS\s+NOT\s+NULL\s+AND\s+\[PayloadSha256\]\s+IS\s+NOT\s+NULL\s+AND\s+\[EventType\]\s+IS\s+NOT\s+NULL\s+AND\s+\[BusinessCorrelationId\]\s+IS\s+NOT\s+NULL\s*\)\s*\)",
            notificationDefinition);
        Assert.Matches(
            @"CHECK\s*\(\s*\[EmailEnvelopeJson\]\s+IS\s+NULL\s+OR\s+\(\s*ISJSON\s*\(\s*\[EmailEnvelopeJson\]\s*\)\s*=\s*1\s+AND\s+DATALENGTH\s*\(\s*\[EmailEnvelopeJson\]\s*\)\s*<=\s*20\s*\*\s*1024\s*\*\s*1024\s*\)\s*\)",
            notificationDefinition);
        Assert.Matches(
            @"CHECK\s*\(.*?\[EmailEnvelopeJson\]\s+IS\s+NULL.*?\[Status\]\s*<>\s*'SENDING'.*?\[LeaseId\]\s+IS\s+NULL.*?\[LeaseExpiresDateTime\]\s+IS\s+NULL.*?OR.*?\[Status\]\s*=\s*'PENDING'.*?\[LeaseId\]\s+IS\s+NULL.*?\[LeaseExpiresDateTime\]\s+IS\s+NULL.*?\[SentDateTime\]\s+IS\s+NULL.*?\[CompletedDateTime\]\s+IS\s+NULL.*?OR.*?\[Status\]\s*=\s*'SENDING'.*?\[LeaseId\]\s+IS\s+NOT\s+NULL.*?\[LeaseExpiresDateTime\]\s+IS\s+NOT\s+NULL.*?\[SentDateTime\]\s+IS\s+NULL.*?\[CompletedDateTime\]\s+IS\s+NULL.*?OR.*?\[Status\]\s*=\s*'SENT'.*?\[LeaseId\]\s+IS\s+NULL.*?\[LeaseExpiresDateTime\]\s+IS\s+NULL.*?\[SentDateTime\]\s+IS\s+NOT\s+NULL.*?\[CompletedDateTime\]\s+IS\s+NOT\s+NULL.*?OR.*?\[Status\]\s*=\s*'FAILED'.*?\[LeaseId\]\s+IS\s+NULL.*?\[LeaseExpiresDateTime\]\s+IS\s+NULL.*?\[SentDateTime\]\s+IS\s+NULL.*?\[CompletedDateTime\]\s+IS\s+NOT\s+NULL.*?\)",
            NormalizeSql(notificationDefinition));
    }

    private static void AssertLeaseContract(string candidateDefinition)
    {
        const string allNull = @"\[LeaseToken\]\s+IS\s+NULL\s+AND\s+\[LeaseOwner\]\s+IS\s+NULL\s+AND\s+\[LeaseAcquiredDateTime\]\s+IS\s+NULL\s+AND\s+\[LeaseExpiresDateTime\]\s+IS\s+NULL";
        const string allPopulated = @"\[LeaseToken\]\s+IS\s+NOT\s+NULL\s+AND\s+\[LeaseOwner\]\s+IS\s+NOT\s+NULL\s+AND\s+\[LeaseAcquiredDateTime\]\s+IS\s+NOT\s+NULL\s+AND\s+\[LeaseExpiresDateTime\]\s+IS\s+NOT\s+NULL";

        Assert.Matches(
            $@"CHECK\s*\(\s*\(\s*{allNull}\s*\)\s+OR\s+\(\s*{allPopulated}\s*\)\s*\)",
            candidateDefinition);
        Assert.Matches(
            @"CHECK\s*\(\s*\[LeaseExpiresDateTime\]\s+IS\s+NULL\s+OR\s+\[LeaseExpiresDateTime\]\s*>\s*\[LeaseAcquiredDateTime\]\s*\)",
            candidateDefinition);
    }

    private static void AssertNullableJsonCheck(
        string tableDefinition,
        string columnName)
    {
        Assert.Matches(
            $@"CHECK\s*\(\s*\[{Regex.Escape(columnName)}\]\s+IS\s+NULL\s+OR\s+ISJSON\s*\(\s*\[{Regex.Escape(columnName)}\]\s*\)\s*=\s*1\s*\)",
            tableDefinition);
    }

    private static void AssertUtcTimestampContract(
        string tableDefinition,
        IReadOnlyList<string> columnNames)
    {
        foreach (var columnName in columnNames)
        {
            Assert.Matches(
                $@"DATEPART\s*\(\s*TZOFFSET\s*,\s*\[{Regex.Escape(columnName)}\]\s*\)\s*=\s*0",
                tableDefinition);
        }
    }

    private static void AssertOperationalForeignKeyContract(string operationalSql)
    {
        var foreignKeys = new[]
        {
            new ForeignKeyContract("PurchaseOrderCandidate", "BatchKey", "PurchaseOrderBatch", "BatchKey"),
            new ForeignKeyContract("PurchaseOrderSubmissionAttempt", "CandidateKey", "PurchaseOrderCandidate", "CandidateKey"),
            new ForeignKeyContract("PurchaseOrderAudit", "CandidateKey", "PurchaseOrderCandidate", "CandidateKey"),
            new ForeignKeyContract("PurchaseOrderNotification", "BatchKey", "PurchaseOrderBatch", "BatchKey"),
            new ForeignKeyContract("PurchaseOrderNotificationAttempt", "NotificationKey", "PurchaseOrderNotification", "NotificationKey")
        };

        foreach (var foreignKey in foreignKeys)
        {
            var tableDefinition = ExtractCreateTableDefinition(
                operationalSql,
                foreignKey.FromTable);
            Assert.Matches(
                $@"FOREIGN\s+KEY\s*\(\s*\[{Regex.Escape(foreignKey.FromColumn)}\]\s*\)\s+REFERENCES\s+\[po\]\.\[{Regex.Escape(foreignKey.ToTable)}\]\s*\(\s*\[{Regex.Escape(foreignKey.ToColumn)}\]\s*\)\s+ON\s+DELETE\s+NO\s+ACTION\s+ON\s+UPDATE\s+NO\s+ACTION",
                tableDefinition);
        }

        Assert.Equal(
            foreignKeys.Length,
            Regex.Matches(
                NormalizeSql(operationalSql),
                @"FOREIGN\s+KEY\s*\([^\)]*\)\s+REFERENCES\s+\[po\]\.\[[^\]]+\]\s*\([^\)]*\)\s+ON\s+DELETE\s+NO\s+ACTION\s+ON\s+UPDATE\s+NO\s+ACTION",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Count);
    }

    private static void AssertOperationalIndexContract(string operationalSql)
    {
        Assert.Matches(
            @"^SET NOCOUNT ON; SET XACT_ABORT ON; SET QUOTED_IDENTIFIER ON;",
            NormalizeSql(operationalSql));
        Assert.Matches(@"\bEND;\s*GO\s*$", operationalSql);

        var expectedIndexes = new[]
        {
            new IndexContract("PurchaseOrderBatch", true, "[Source], [FileSha256]", null, null),
            new IndexContract("PurchaseOrderBatch", false, "[Status], [DiscoveredDateTime]", null, null),
            new IndexContract("PurchaseOrderCandidate", false, "[Source], [Status], [AcceptedDateTime] DESC", "[Account], [Branch], [Reference], [IconPurchaseOrderNumber]", null),
            new IndexContract("PurchaseOrderCandidate", false, "[Source], [Account], [Branch], [Reference]", null, null),
            new IndexContract("PurchaseOrderCandidate", false, "[IconPurchaseOrderNumber]", null, "[IconPurchaseOrderNumber] IS NOT NULL"),
            new IndexContract("PurchaseOrderCandidate", false, "[Status], [LeaseExpiresDateTime], [AcceptedDateTime]", "[CandidateId], [Branch]", null),
            new IndexContract("PurchaseOrderCandidate", false, "[BatchKey], [CandidateKey]", "[Status], [LeaseToken]", null),
            new IndexContract("PurchaseOrderSubmissionAttempt", true, "[CandidateKey], [AttemptNumber]", null, null),
            new IndexContract("PurchaseOrderSubmissionAttempt", false, "[Status], [DispatchedDateTime]", null, null),
            new IndexContract("PurchaseOrderAudit", false, "[CandidateKey], [ChangedDateTime] DESC", null, null),
            new IndexContract("PurchaseOrderNotification", false, "[Status], [NextAttemptDateTime], [CreatedDateTime], [NotificationKey]", "[LeaseExpiresDateTime], [EmailEnvelopeVersion], [PayloadSha256]", null),
            new IndexContract("PurchaseOrderNotification", false, "[BatchKey], [CreatedDateTime] DESC", null, null),
            new IndexContract("PurchaseOrderNotificationAttempt", true, "[AttemptId]", null, null),
            new IndexContract("PurchaseOrderNotificationAttempt", true, "[NotificationKey], [AttemptNumber]", null, null),
            new IndexContract("PurchaseOrderNotificationAttempt", false, "[StartedDateTime]", null, null)
        };

        var normalizedSql = NormalizeSql(operationalSql);
        var declaredIndexes = Regex
            .Matches(
                normalizedSql,
                @"CREATE\s+(?<unique>UNIQUE\s+)?NONCLUSTERED\s+INDEX\s+\[(?<name>[^\]]+)\]\s+ON\s+\[po\]\.\[(?<table>[^\]]+)\]\s*\((?<keys>[^\)]*)\)(?:\s+INCLUDE\s*\((?<include>[^\)]*)\))?(?:\s+WHERE\s+(?<filter>.*?))?\s*;",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)
            .Cast<Match>()
            .Select(match => new IndexContract(
                match.Groups["table"].Value,
                match.Groups["unique"].Success,
                NormalizeIndexPart(match.Groups["keys"].Value),
                match.Groups["include"].Success
                    ? NormalizeIndexPart(match.Groups["include"].Value)
                    : null,
                match.Groups["filter"].Success
                    ? NormalizeIndexPart(match.Groups["filter"].Value)
                    : null))
            .ToArray();

        var notificationAttemptDefinition = NormalizeSql(ExtractCreateTableDefinition(
            operationalSql,
            "PurchaseOrderNotificationAttempt"));
        var declaredUniqueConstraints = Regex
            .Matches(
                notificationAttemptDefinition,
                @"CONSTRAINT\s+\[UQ_[^\]]+\]\s+UNIQUE(?:\s+NONCLUSTERED)?\s*\((?<keys>[^\)]*)\)",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)
            .Cast<Match>()
            .Select(match => new IndexContract(
                "PurchaseOrderNotificationAttempt",
                true,
                NormalizeIndexPart(match.Groups["keys"].Value),
                null,
                null))
            .ToArray();

        var actualIndexes = declaredIndexes
            .Concat(declaredUniqueConstraints)
            .OrderBy(index => index.ToString(), StringComparer.Ordinal)
            .ToArray();

        Assert.Equal(
            expectedIndexes.OrderBy(index => index.ToString(), StringComparer.Ordinal),
            actualIndexes);

        foreach (var indexName in Regex
                     .Matches(
                         normalizedSql,
                         @"CREATE\s+(?:UNIQUE\s+)?NONCLUSTERED\s+INDEX\s+\[(?<name>[^\]]+)\]",
                         RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)
                     .Cast<Match>()
                     .Select(match => match.Groups["name"].Value))
        {
            Assert.Matches(
                $@"IF\s+NOT\s+EXISTS\s*\(.*?sys\.indexes.*?\[name\]\s*=\s*N?'{Regex.Escape(indexName)}'.*?\)\s+BEGIN\s+CREATE\s+(?:UNIQUE\s+)?NONCLUSTERED\s+INDEX\s+\[{Regex.Escape(indexName)}\]",
                normalizedSql);
        }
    }

    private static string NormalizeIndexPart(string value)
    {
        return Regex.Replace(value.Trim(), @"\s+", " ")
            .Replace(" ASC", string.Empty, StringComparison.OrdinalIgnoreCase);
    }

    private static string ExtractCreateTableDefinition(
        string sql,
        string tableName)
    {
        var commentFreeSql = SanitizeSql(sql, sanitizeStringLiterals: false);
        var declaration = Regex.Match(
            commentFreeSql,
            $@"\bCREATE\s+TABLE\s+\[po\]\.\[{Regex.Escape(tableName)}\]\s*\(",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        Assert.True(
            declaration.Success,
            $"Expected CREATE TABLE [po].[{tableName}] declaration.");

        var openingParenthesis = commentFreeSql.IndexOf('(', declaration.Index);
        var depth = 0;
        var insideString = false;

        for (var index = openingParenthesis; index < commentFreeSql.Length; index++)
        {
            var currentCharacter = commentFreeSql[index];
            var nextCharacter = index + 1 < commentFreeSql.Length
                ? commentFreeSql[index + 1]
                : '\0';

            if (insideString)
            {
                if (currentCharacter == '\'' && nextCharacter == '\'')
                {
                    index++;
                }
                else if (currentCharacter == '\'')
                {
                    insideString = false;
                }

                continue;
            }

            if (currentCharacter == '\'')
            {
                insideString = true;
            }
            else if (currentCharacter == '(')
            {
                depth++;
            }
            else if (currentCharacter == ')')
            {
                depth--;
                if (depth == 0)
                {
                    return NormalizeSql(commentFreeSql[declaration.Index..(index + 1)]);
                }
            }
        }

        Assert.Fail($"CREATE TABLE [po].[{tableName}] has no closing parenthesis.");
        return string.Empty;
    }

    private static string NormalizeSql(string sql)
    {
        return Regex.Replace(
            SanitizeSql(sql, sanitizeStringLiterals: false),
            @"\s+",
            " ").Trim();
    }

    private static string[] ReadStringManifest(string sql, string variableName)
    {
        using var document = JsonDocument.Parse(ReadJsonManifest(sql, variableName));
        return document.RootElement
            .EnumerateArray()
            .Select(element => element.GetString() ?? string.Empty)
            .ToArray();
    }

    private static string[] ReadIndexManifest(string sql)
    {
        using var document = JsonDocument.Parse(ReadJsonManifest(sql, "expectedIndexes"));
        return document.RootElement
            .EnumerateArray()
            .Select((element, index) =>
            {
                Assert.True(element.TryGetProperty("table", out var table), $"Index manifest entry {index} requires table.");
                Assert.True(element.TryGetProperty("index", out var indexName), $"Index manifest entry {index} requires index.");
                Assert.True(element.TryGetProperty("type", out var indexType), $"Index manifest entry {index} requires type.");
                Assert.True(element.TryGetProperty("unique", out var isUnique), $"Index manifest entry {index} requires unique.");
                Assert.True(element.TryGetProperty("primaryKey", out var isPrimaryKey), $"Index manifest entry {index} requires primaryKey.");
                Assert.True(element.TryGetProperty("uniqueConstraint", out var isUniqueConstraint), $"Index manifest entry {index} requires uniqueConstraint.");
                Assert.True(element.TryGetProperty("keys", out var keys), $"Index manifest entry {index} requires keys.");
                Assert.True(element.TryGetProperty("includes", out var includes), $"Index manifest entry {index} requires includes.");
                Assert.True(element.TryGetProperty("filter", out var filter), $"Index manifest entry {index} requires filter.");
                Assert.Equal(JsonValueKind.Array, keys.ValueKind);
                Assert.Equal(JsonValueKind.Array, includes.ValueKind);
                Assert.True(filter.ValueKind is JsonValueKind.Null or JsonValueKind.String);

                var keyContract = string.Join(",", keys.EnumerateArray().Select((key, keyIndex) =>
                {
                    Assert.True(key.TryGetProperty("column", out var column), $"Index manifest entry {index} key {keyIndex} requires column.");
                    Assert.True(key.TryGetProperty("descending", out var descending), $"Index manifest entry {index} key {keyIndex} requires descending.");
                    return $"{column.GetString()}:{(descending.GetBoolean() ? "DESC" : "ASC")}";
                }));
                var includeContract = string.Join(",", includes.EnumerateArray().Select(include => include.GetString()));
                var filterContract = filter.ValueKind == JsonValueKind.Null
                    ? "<null>"
                    : filter.GetString();

                return $"{table.GetString()}:{indexName.GetString()}:{indexType.GetString()}:" +
                    $"unique={isUnique.GetBoolean()}:primaryKey={isPrimaryKey.GetBoolean()}:" +
                    $"uniqueConstraint={isUniqueConstraint.GetBoolean()}:keys={keyContract}:" +
                    $"includes={includeContract}:filter={filterContract}";
            })
            .ToArray();
    }

    private static string[] ReadPairManifest(
        string sql,
        string variableName,
        string firstProperty,
        string secondProperty)
    {
        using var document = JsonDocument.Parse(ReadJsonManifest(sql, variableName));
        return document.RootElement
            .EnumerateArray()
            .Select(element =>
                $"{element.GetProperty(firstProperty).GetString()}:{element.GetProperty(secondProperty).GetString()}")
            .ToArray();
    }

    private static string[] ReadStatusConstraintManifest(string sql)
    {
        using var document = JsonDocument.Parse(ReadJsonManifest(
            sql,
            "expectedStatusConstraints"));
        return document.RootElement
            .EnumerateArray()
            .Select(element =>
                $"{element.GetProperty("table").GetString()}:" +
                $"{element.GetProperty("constraint").GetString()}:" +
                $"{element.GetProperty("column").GetString()}:" +
                NormalizeStatusConstraintDefinition(
                    element.GetProperty("definition").GetString() ?? string.Empty))
            .ToArray();
    }

    private static void AssertStatusCheckConstraint(
        string tableDefinition,
        string constraintName,
        string columnName,
        IReadOnlyList<string> values,
        bool isNullable = false)
    {
        var columnPattern = $@"\[{Regex.Escape(columnName)}\]";
        var inListPattern = CreateStatusInListPattern(columnPattern, values);
        var checkBodyPattern = isNullable
            ? $@"{columnPattern}\s+IS\s+NULL\s+OR\s+{inListPattern}"
            : inListPattern;

        Assert.Matches(
            $@"CONSTRAINT\s+\[{Regex.Escape(constraintName)}\]\s+CHECK\s*\(\s*{checkBodyPattern}\s*\)",
            tableDefinition);
    }

    private static string CreateStatusInListPattern(
        string expressionPattern,
        IReadOnlyList<string> values,
        bool isNegated = false)
    {
        var valuesPattern = string.Join(
            @"\s*,\s*",
            values.Select(value => $"'{Regex.Escape(value)}'"));
        return $@"{expressionPattern}\s+{(isNegated ? @"NOT\s+" : string.Empty)}IN\s*\(\s*{valuesPattern}\s*\)";
    }

    private static string CreateStatusConstraintManifestEntry(
        string tableName,
        string constraintName,
        string columnName,
        IReadOnlyList<string> values,
        bool isNullable = false)
    {
        var column = $"[{columnName}]";
        var comparisons = string.Join(
            " OR ",
            values.Reverse().Select(value => $"{column}='{value}'"));
        var definition = isNullable
            ? $"{column} IS NULL OR ({comparisons})"
            : comparisons;
        return $"{tableName}:{constraintName}:{columnName}:" +
            NormalizeStatusConstraintDefinition(definition);
    }

    private static string NormalizeStatusConstraintDefinition(string definition)
    {
        return Regex
            .Replace(definition, @"[\s\[\]\(\)]", string.Empty)
            .ToUpperInvariant();
    }

    private static string ReadJsonManifest(string sql, string variableName)
    {
        var match = Regex.Match(
            sql,
            $@"\bDECLARE\s+@{Regex.Escape(variableName)}\s+nvarchar\(max\)\s*=\s*N'(?<json>(?:[^']|'')*)'\s*;",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        Assert.True(match.Success, $"Expected @{variableName} JSON verification manifest.");
        return match.Groups["json"].Value.Replace("''", "'", StringComparison.Ordinal);
    }

    private static void AssertDeploymentOrder(string deploymentSql)
    {
        var referencedScripts = Regex
            .Matches(
                deploymentSql,
                @"^\s*:r\s+\.\\(?<script>[^\r\n]+\.sql)\s*$",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Cast<Match>()
            .Select(match => match.Groups["script"].Value)
            .ToArray();

        Assert.Equal(DeploymentScripts, referencedScripts);
    }

    private static void AssertProcedureInventory(string sanitizedSql)
    {
        var declaredProcedureNames = DiscoverProcedureNames(sanitizedSql);

        foreach (var procedureName in ProcedureNames)
        {
            var declarationCount = declaredProcedureNames.Count(
                declaredProcedureName => string.Equals(
                    declaredProcedureName,
                    procedureName,
                    StringComparison.Ordinal));

            Assert.True(
                declarationCount == 1,
                $"Expected exactly one CREATE OR ALTER PROCEDURE [po].[{procedureName}] declaration, " +
                $"but found {declarationCount}.");
        }

        Assert.True(
            declaredProcedureNames.Length == ProcedureNames.Length,
            $"Expected exactly {ProcedureNames.Length} CREATE OR ALTER PROCEDURE [po] declarations, " +
            $"but found {declaredProcedureNames.Length}.");

        var expectedProcedureNames = ProcedureNames
            .OrderBy(procedureName => procedureName, StringComparer.Ordinal)
            .ToArray();
        var distinctDeclaredProcedureNames = declaredProcedureNames
            .Distinct(StringComparer.Ordinal)
            .OrderBy(procedureName => procedureName, StringComparer.Ordinal)
            .ToArray();

        Assert.Equal(expectedProcedureNames, distinctDeclaredProcedureNames);
    }

    private static void AssertTableInventory(string sanitizedSql)
    {
        var declaredTableNames = DiscoverTableNames(sanitizedSql);

        foreach (var tableName in TableNames)
        {
            var declarationCount = declaredTableNames.Count(
                declaredTableName => string.Equals(
                    declaredTableName,
                    tableName,
                    StringComparison.Ordinal));

            Assert.True(
                declarationCount == 1,
                $"Expected exactly one CREATE TABLE [po].[{tableName}] declaration, " +
                $"but found {declarationCount}.");
        }

        Assert.True(
            declaredTableNames.Length == TableNames.Length,
            $"Expected exactly {TableNames.Length} CREATE TABLE [po] declarations, " +
            $"but found {declaredTableNames.Length}.");

        var expectedTableNames = TableNames
            .OrderBy(tableName => tableName, StringComparer.Ordinal)
            .ToArray();
        var distinctDeclaredTableNames = declaredTableNames
            .Distinct(StringComparer.Ordinal)
            .OrderBy(tableName => tableName, StringComparer.Ordinal)
            .ToArray();

        Assert.Equal(expectedTableNames, distinctDeclaredTableNames);
    }

    private static string[] DiscoverProcedureNames(string sanitizedSql)
    {
        return Regex
            .Matches(
                sanitizedSql,
                @"^[ \t]*CREATE[ \t]+OR[ \t]+ALTER[ \t]+PROCEDURE[ \t]+\[po\]\.\[(?<name>[^\]\r\n]+)\]",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Cast<Match>()
            .Select(match => match.Groups["name"].Value)
            .ToArray();
    }

    private static string[] DiscoverTableNames(string sanitizedSql)
    {
        return Regex
            .Matches(
                sanitizedSql,
                @"^[ \t]*CREATE[ \t]+TABLE[ \t]+\[po\]\.\[(?<name>[^\]\r\n]+)\]",
                RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant)
            .Cast<Match>()
            .Select(match => match.Groups["name"].Value)
            .ToArray();
    }

    private static string SanitizeSql(
        string sql,
        bool sanitizeStringLiterals = true)
    {
        var sanitizedCharacters = sql.ToCharArray();
        var state = SqlSanitizerState.Code;
        var blockCommentDepth = 0;

        for (var index = 0; index < sql.Length; index++)
        {
            var currentCharacter = sql[index];
            var nextCharacter = index + 1 < sql.Length
                ? sql[index + 1]
                : '\0';

            switch (state)
            {
                case SqlSanitizerState.Code:
                    if (currentCharacter == '-' && nextCharacter == '-')
                    {
                        BlankCharacter(sanitizedCharacters, index);
                        BlankCharacter(sanitizedCharacters, index + 1);
                        index++;
                        state = SqlSanitizerState.LineComment;
                    }
                    else if (currentCharacter == '/' && nextCharacter == '*')
                    {
                        BlankCharacter(sanitizedCharacters, index);
                        BlankCharacter(sanitizedCharacters, index + 1);
                        index++;
                        blockCommentDepth = 1;
                        state = SqlSanitizerState.BlockComment;
                    }
                    else if ((currentCharacter == 'N' || currentCharacter == 'n')
                             && nextCharacter == '\'')
                    {
                        if (sanitizeStringLiterals)
                        {
                            BlankCharacter(sanitizedCharacters, index);
                            BlankCharacter(sanitizedCharacters, index + 1);
                        }

                        index++;
                        state = SqlSanitizerState.StringLiteral;
                    }
                    else if (currentCharacter == '\'')
                    {
                        if (sanitizeStringLiterals)
                        {
                            BlankCharacter(sanitizedCharacters, index);
                        }

                        state = SqlSanitizerState.StringLiteral;
                    }

                    break;

                case SqlSanitizerState.LineComment:
                    BlankCharacter(sanitizedCharacters, index);
                    if (currentCharacter == '\r' || currentCharacter == '\n')
                    {
                        state = SqlSanitizerState.Code;
                    }

                    break;

                case SqlSanitizerState.BlockComment:
                    if (currentCharacter == '/' && nextCharacter == '*')
                    {
                        BlankCharacter(sanitizedCharacters, index);
                        BlankCharacter(sanitizedCharacters, index + 1);
                        index++;
                        blockCommentDepth++;
                    }
                    else if (currentCharacter == '*' && nextCharacter == '/')
                    {
                        BlankCharacter(sanitizedCharacters, index);
                        BlankCharacter(sanitizedCharacters, index + 1);
                        index++;
                        blockCommentDepth--;
                        if (blockCommentDepth == 0)
                        {
                            state = SqlSanitizerState.Code;
                        }
                    }
                    else
                    {
                        BlankCharacter(sanitizedCharacters, index);
                    }

                    break;

                case SqlSanitizerState.StringLiteral:
                    if (sanitizeStringLiterals)
                    {
                        BlankCharacter(sanitizedCharacters, index);
                    }

                    if (currentCharacter == '\'')
                    {
                        if (nextCharacter == '\'')
                        {
                            if (sanitizeStringLiterals)
                            {
                                BlankCharacter(sanitizedCharacters, index + 1);
                            }

                            index++;
                        }
                        else
                        {
                            state = SqlSanitizerState.Code;
                        }
                    }

                    break;
            }
        }

        return new string(sanitizedCharacters);
    }

    private static void BlankCharacter(char[] characters, int index)
    {
        if (characters[index] != '\r' && characters[index] != '\n')
        {
            characters[index] = ' ';
        }
    }

    private enum SqlSanitizerState
    {
        Code,
        LineComment,
        BlockComment,
        StringLiteral
    }

    private sealed record OperationalKeyContract(
        string TableName,
        string KeyColumn,
        string? PublicIdColumn);

    private sealed record ForeignKeyContract(
        string FromTable,
        string FromColumn,
        string ToTable,
        string ToColumn);

    private sealed record IndexContract(
        string TableName,
        bool IsUnique,
        string KeyColumns,
        string? IncludedColumns,
        string? Filter);

    private sealed record SqlScript(string Path, string Content);
}
