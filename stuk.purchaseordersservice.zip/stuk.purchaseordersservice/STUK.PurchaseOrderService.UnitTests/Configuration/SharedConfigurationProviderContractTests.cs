namespace STUK.PurchaseOrderService.UnitTests.Configuration;

public sealed class SharedConfigurationProviderContractTests
{
    private const string AdminProjectName =
        "STUK.PurchaseOrderService.PurchaseOrderAdmin";
    private const string PackageReference =
        "<PackageReference Include=\"STUK.ConfigurationProviders\" Version=\"1.0.1\" />";

    [Fact]
    public void ExecutableHosts_UseSharedSqlConfigurationProviderBeforeBindingServices()
    {
        var webApiProject = Read("STUK.PurchaseOrderService.WebApi/STUK.PurchaseOrderService.WebApi.csproj");
        var adminProject = Read($"{AdminProjectName}/{AdminProjectName}.csproj");

        Assert.Contains(PackageReference, webApiProject, StringComparison.Ordinal);
        Assert.Contains(PackageReference, adminProject, StringComparison.Ordinal);

        var webApiProgram = Read("STUK.PurchaseOrderService.WebApi/Program.cs");
        AssertProviderRegistration(
            webApiProgram,
            "ConfigConstants.DatabaseAppSettingWebApiContext",
            "builder.Services.AddPurchaseOrderPersistence");

        var adminProgram = Read($"{AdminProjectName}/Program.cs");
        AssertProviderRegistration(
            adminProgram,
            "ConfigConstants.DatabaseAppSettingWebAppContext",
            "builder.Services.AddCoreUI(builder.Configuration)");
    }

    [Fact]
    public void CommonData_DoesNotRetainTheLocalSqlConfigurationProvider()
    {
        var providerDirectory = Path.Combine(
            FindRepositoryRoot(),
            "STUK.PurchaseOrderService.Common.Data",
            "ConfigurationProviders");

        Assert.False(
            Directory.Exists(providerDirectory),
            "The local SQL configuration provider must be replaced by STUK.ConfigurationProviders.");
    }

    [Fact]
    public void NuGetConfig_IncludesTheInternalAppsFeedThatPublishesTheSharedProvider()
    {
        var nugetConfig = Read("nuget.config");

        Assert.Contains(
            "key=\"InternalAppsNuget\"",
            nugetConfig,
            StringComparison.Ordinal);
        Assert.Contains(
            "_packaging/145fbfae-df8d-4524-a686-289c3835c4f1/nuget/v3/index.json",
            nugetConfig,
            StringComparison.Ordinal);
    }

    private static void AssertProviderRegistration(
        string program,
        string hostContext,
        string dependentRegistration)
    {
        Assert.Contains("using STUK.ConfigurationProviders;", program, StringComparison.Ordinal);
        Assert.Contains("builder.Configuration.AddSqlServerConfiguration(", program, StringComparison.Ordinal);
        Assert.Contains(
            "ConfigConstants.PurchaseOrdersDbConnectionStringName",
            program,
            StringComparison.Ordinal);
        Assert.Contains("\"po.sp_get_application_settings\"", program, StringComparison.Ordinal);
        Assert.Contains(
            "ConfigConstants.DatabaseConfigurationRefreshInterval",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            "ConfigConstants.DatabaseAppSettingCommonContext",
            program,
            StringComparison.Ordinal);
        Assert.Contains(hostContext, program, StringComparison.Ordinal);

        var keyVaultIndex = program.IndexOf(
            "builder.Configuration.AddAzureKeyVault",
            StringComparison.Ordinal);
        var providerIndex = program.IndexOf(
            "builder.Configuration.AddSqlServerConfiguration",
            StringComparison.Ordinal);
        var dependentIndex = program.IndexOf(dependentRegistration, StringComparison.Ordinal);

        Assert.True(keyVaultIndex >= 0, "Key Vault registration is required.");
        Assert.True(providerIndex > keyVaultIndex, "SQL configuration must load after Key Vault.");
        Assert.True(
            dependentIndex > providerIndex,
            "SQL configuration must load before services bind configuration.");
    }

    private static string Read(string relativePath)
    {
        var path = Path.Combine(
            FindRepositoryRoot(),
            relativePath.Replace('/', Path.DirectorySeparatorChar));
        Assert.True(File.Exists(path), $"Required repository file was not found: {relativePath}");
        return File.ReadAllText(path);
    }

    private static string FindRepositoryRoot()
    {
        foreach (var startPath in new[] { Directory.GetCurrentDirectory(), AppContext.BaseDirectory })
        {
            for (var directory = new DirectoryInfo(startPath);
                 directory is not null;
                 directory = directory.Parent)
            {
                if (File.Exists(Path.Combine(
                        directory.FullName,
                        "STUK.PurchaseOrderService.sln")))
                {
                    return directory.FullName;
                }
            }
        }

        throw new InvalidOperationException("The repository root could not be located.");
    }
}
