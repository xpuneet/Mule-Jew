using System.Configuration;
using Microsoft.Extensions.Configuration;
using STUK.ConfigurationProviders;

namespace STUK.PurchaseOrderService.UnitTests.Configuration;

public sealed class SharedConfigurationProviderBehaviorTests
{
    private const string ConnectionStringName = "PurchaseOrdersServiceDB";
    private const string ReloadIntervalKey = "DatabaseConfigurationRefreshInterval";
    private const string StoredProcedure = "po.sp_get_application_settings";
    private const string NonSecretConnectionString =
        "Server=not-used.invalid;Database=not-used;Integrated Security=true";

    private static readonly List<string> Contexts = ["Common", "WebApi"];

    [Fact]
    public void AddSqlServerConfiguration_WhenConnectionStringIsMissing_FailsClosed()
    {
        var builder = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                [ReloadIntervalKey] = "1"
            });

        var exception = Assert.Throws<ConfigurationErrorsException>(() =>
        {
            builder.AddSqlServerConfiguration(
                ConnectionStringName,
                StoredProcedure,
                ReloadIntervalKey,
                Contexts);
        });

        Assert.Contains(
            $"ConnectionString not found: '{ConnectionStringName}'",
            exception.Message,
            StringComparison.Ordinal);
        Assert.DoesNotContain("not-used.invalid", exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void AddSqlServerConfiguration_WhenReloadIntervalIsMissing_FailsClosedBeforeDatabaseAccess()
    {
        var builder = CreateBuilderWithConnectionString();

        var exception = Assert.Throws<ConfigurationErrorsException>(() =>
        {
            builder.AddSqlServerConfiguration(
                ConnectionStringName,
                StoredProcedure,
                ReloadIntervalKey,
                Contexts);
        });

        Assert.Contains(
            $"ReloadIntervalKey not found: '{ReloadIntervalKey}'",
            exception.Message,
            StringComparison.Ordinal);
        Assert.DoesNotContain("not-used.invalid", exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void AddSqlServerConfiguration_WhenReloadIntervalIsNotAnInteger_FailsClosedBeforeDatabaseAccess()
    {
        var builder = CreateBuilderWithConnectionString()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                [ReloadIntervalKey] = "not-an-integer"
            });

        var exception = Assert.Throws<ConfigurationErrorsException>(() =>
        {
            builder.AddSqlServerConfiguration(
                ConnectionStringName,
                StoredProcedure,
                ReloadIntervalKey,
                Contexts);
        });

        Assert.Contains(
            "ReloadInterval value is invalid: 'not-an-integer'",
            exception.Message,
            StringComparison.Ordinal);
        Assert.DoesNotContain("not-used.invalid", exception.Message, StringComparison.Ordinal);
    }

    private static IConfigurationBuilder CreateBuilderWithConnectionString()
    {
        return new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                [$"ConnectionStrings:{ConnectionStringName}"] = NonSecretConnectionString
            });
    }
}
