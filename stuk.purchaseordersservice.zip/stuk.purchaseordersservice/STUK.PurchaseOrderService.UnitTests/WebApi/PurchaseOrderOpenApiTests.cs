using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi;
using STUK.PurchaseOrderService.WebApi.Controllers.V1;
using STUK.PurchaseOrderService.WebApi.Swagger;
using Swashbuckle.AspNetCore.Swagger;

namespace STUK.PurchaseOrderService.UnitTests.WebApi;

public sealed class PurchaseOrderOpenApiTests
{
    [Fact]
    public async Task GeneratedDocument_DescribesPurchaseOrderOperationsWithRealisticExamples()
    {
        var webApiAssembly = typeof(PurchaseOrdersController).Assembly;
        var builder = WebApplication.CreateBuilder();
        builder.Services
            .AddControllers()
            .AddApplicationPart(webApiAssembly);
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddPurchaseOrderSwagger();

        await using var app = builder.Build();
        var swaggerProvider = app.Services.GetRequiredService<ISwaggerProvider>();
        var document = swaggerProvider.GetSwagger("v1");

        await using var stream = new MemoryStream();
        await document.SerializeAsJsonAsync(
            stream,
            OpenApiSpecVersion.OpenApi3_0,
            CancellationToken.None);
        var json = Encoding.UTF8.GetString(stream.ToArray());
        using var openApi = JsonDocument.Parse(json);

        var operation = openApi.RootElement
            .GetProperty("paths")
            .GetProperty("/PurchaseOrderService/PurchaseOrders/v1");

        var submit = operation.GetProperty("post");
        Assert.Contains("asynchronous", submit.GetProperty("description").GetString());
        Assert.Equal(
            "BRIT186",
            submit
                .GetProperty("requestBody")
                .GetProperty("content")
                .GetProperty("application/json")
                .GetProperty("example")
                .GetProperty("purchaseOrderHeader")
                .GetProperty("account")
                .GetString());
        Assert.Equal(
            "READY_FOR_SUBMISSION",
            submit
                .GetProperty("responses")
                .GetProperty("200")
                .GetProperty("content")
                .GetProperty("application/json")
                .GetProperty("example")
                .GetProperty("status")
                .GetString());
        var submitResponses = submit.GetProperty("responses");
        AssertProblemResponse(submitResponses, StatusCodes.Status400BadRequest);
        AssertProblemResponse(submitResponses, StatusCodes.Status411LengthRequired);
        AssertProblemResponse(submitResponses, StatusCodes.Status413PayloadTooLarge);
        AssertProblemResponse(submitResponses, StatusCodes.Status418ImATeapot);
        AssertProblemResponse(submitResponses, StatusCodes.Status503ServiceUnavailable);

        var search = operation.GetProperty("get");
        var source = Assert.Single(
            search.GetProperty("parameters").EnumerateArray(),
            parameter => parameter.GetProperty("name").GetString() == "Source");
        Assert.Equal("API", source.GetProperty("example").GetString());
        Assert.Contains(
            "configured maximum",
            search.GetProperty("description").GetString(),
            StringComparison.OrdinalIgnoreCase);
        Assert.Equal(
            "BRIT186",
            search
                .GetProperty("responses")
                .GetProperty("200")
                .GetProperty("content")
                .GetProperty("application/json")
                .GetProperty("example")
                .GetProperty("orders")[0]
                .GetProperty("account")
                .GetString());
        var searchResponses = search.GetProperty("responses");
        AssertProblemResponse(searchResponses, StatusCodes.Status400BadRequest);
        AssertProblemResponse(searchResponses, StatusCodes.Status404NotFound);
        AssertProblemResponse(searchResponses, StatusCodes.Status503ServiceUnavailable);

        var schemas = openApi.RootElement.GetProperty("components").GetProperty("schemas");
        var purchaseOrderHeader = schemas.GetProperty("PurchaseOrderHeader");
        Assert.Equal(
            "BRIT186",
            purchaseOrderHeader
                .GetProperty("properties")
                .GetProperty("account")
                .GetProperty("example")
                .GetString());
        Assert.Contains(
            "supplier account",
            purchaseOrderHeader
                .GetProperty("properties")
                .GetProperty("account")
                .GetProperty("description")
                .GetString(),
            StringComparison.OrdinalIgnoreCase);
    }

    private static void AssertProblemResponse(JsonElement responses, int statusCode)
    {
        var response = responses
            .GetProperty(statusCode.ToString())
            .GetProperty("content")
            .GetProperty("application/problem+json")
            .GetProperty("example");

        Assert.Equal(statusCode, response.GetProperty("status").GetInt32());
    }
}
