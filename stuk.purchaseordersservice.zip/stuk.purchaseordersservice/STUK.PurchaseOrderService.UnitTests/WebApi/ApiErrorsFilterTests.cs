using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Logging.Abstractions;
using STUK.PurchaseOrderService.WebApi.Filters;

namespace STUK.PurchaseOrderService.UnitTests.WebApi;

public sealed class ApiErrorsFilterTests
{
    [Fact]
    public void OnException_ReturnsSanitizedServiceUnavailableProblem()
    {
        const string sensitiveExceptionMessage = "database password and payload must not escape";
        var httpContext = new DefaultHttpContext();
        httpContext.Request.Path = "/PurchaseOrderService/PurchaseOrders/v1";
        var actionContext = new ActionContext(
            httpContext,
            new RouteData(),
            new ActionDescriptor());
        var exceptionContext = new ExceptionContext(actionContext, [])
        {
            Exception = new InvalidOperationException(sensitiveExceptionMessage)
        };
        var filter = new ApiErrorsFilter(NullLogger<ApiErrorsFilter>.Instance);

        filter.OnException(exceptionContext);

        var result = Assert.IsType<ObjectResult>(exceptionContext.Result);
        var problem = Assert.IsType<ProblemDetails>(result.Value);
        Assert.Equal(StatusCodes.Status503ServiceUnavailable, result.StatusCode);
        Assert.Equal(StatusCodes.Status503ServiceUnavailable, problem.Status);
        Assert.DoesNotContain(sensitiveExceptionMessage, problem.Detail, StringComparison.Ordinal);
        Assert.True(exceptionContext.ExceptionHandled);
    }
}
