using Microsoft.Extensions.Configuration;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.WebApi.Config;
using System.Reflection;

namespace STUK.PurchaseOrderService.UnitTests.WebApi;

public sealed class PurchaseOrderDatabaseConfigurationTests
{
    private const string ExpectedMissingConnectionMessage =
        "The Purchase Orders database connection is not configured.";

    [Fact]
    public void RequireConnectionString_WhenConfigured_ReturnsConfiguredValue()
    {
        const string connectionString =
            "Data Source=localhost;Initial Catalog=Orders;Integrated Security=True;";
        var configuration = BuildConfiguration(connectionString);

        var result = InvokeRequireConnectionString(configuration);

        Assert.Equal(connectionString, result);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void RequireConnectionString_WhenMissingOrBlank_ThrowsFixedSanitizedError(
        string? connectionString)
    {
        const string sensitiveMarker = "Password=do-not-echo-this";
        var configuration = BuildConfiguration(connectionString, sensitiveMarker);

        var wrapper = Assert.Throws<TargetInvocationException>(() =>
            InvokeRequireConnectionString(configuration));

        var exception = Assert.IsType<InvalidOperationException>(wrapper.InnerException);
        Assert.Equal(ExpectedMissingConnectionMessage, exception.Message);
        Assert.Null(exception.InnerException);
        Assert.DoesNotContain(sensitiveMarker, exception.Message, StringComparison.Ordinal);
        if (!string.IsNullOrEmpty(connectionString))
        {
            Assert.DoesNotContain(connectionString, exception.Message, StringComparison.Ordinal);
        }
    }

    private static IConfiguration BuildConfiguration(
        string? connectionString,
        string? sensitiveMarker = null)
    {
        var values = new Dictionary<string, string?>
        {
            ["UnrelatedSensitiveSetting"] = sensitiveMarker
        };
        if (connectionString is not null)
        {
            values[$"ConnectionStrings:{ConfigConstants.PurchaseOrdersDbConnectionStringName}"] =
                connectionString;
        }

        return new ConfigurationBuilder()
            .AddInMemoryCollection(values)
            .Build();
    }

    private static string InvokeRequireConnectionString(IConfiguration configuration)
    {
        var configurationType = typeof(WebApiSettingsValidator).Assembly.GetType(
            "STUK.PurchaseOrderService.WebApi.Config.PurchaseOrderDatabaseConfiguration");
        Assert.NotNull(configurationType);
        var method = configurationType.GetMethod(
            "RequireConnectionString",
            BindingFlags.Public | BindingFlags.Static);
        Assert.NotNull(method);
        Assert.Equal(typeof(string), method.ReturnType);
        Assert.Collection(
            method.GetParameters(),
            parameter => Assert.Equal(typeof(IConfiguration), parameter.ParameterType));
        return Assert.IsType<string>(method.Invoke(null, [configuration]));
    }
}
