using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.TestUtils.Builders;
using STUK.PurchaseOrderService.WebApi.Controllers.V1;
using STUK.PurchaseOrderService.WebApi.Domain.Config;
using STUK.PurchaseOrderService.WebApi.Domain.Services;
using STUK.PurchaseOrderService.WebApi.Domain.Services.V1;
using STUK.PurchaseOrderService.WebApi.Domain.Validation;
using System.Reflection;
using System.Text.Json;

namespace STUK.PurchaseOrderService.UnitTests.WebApi;

public sealed class PurchaseOrdersControllerTests
{
    [Fact]
    public async Task SubmitPurchaseOrder_PassesCanonicalBodyAndCancellationToken()
    {
        var service = new Mock<IPurchaseOrdersService>();
        var purchaseOrder = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        var cancellationToken = new CancellationTokenSource().Token;
        var expected = new SubmitPurchaseOrderResponse
        {
            CandidateId = Guid.NewGuid(),
            Status = PurchaseOrderCandidateStatus.ReadyForSubmission,
            AcceptedDateTime = DateTimeOffset.UtcNow
        };
        service
            .Setup(instance => instance.SubmitPurchaseOrder(purchaseOrder, cancellationToken))
            .ReturnsAsync(ServiceResponse<SubmitPurchaseOrderResponse>.Ok(expected));
        var controller = CreateController(service.Object);

        var result = await controller.SubmitPurchaseOrder(purchaseOrder, cancellationToken);

        var ok = Assert.IsType<OkObjectResult>(result.Result);
        Assert.Same(expected, ok.Value);
        service.Verify(
            instance => instance.SubmitPurchaseOrder(purchaseOrder, cancellationToken),
            Times.Once);
    }

    [Fact]
    public void SubmitPurchaseOrder_DoesNotDeclareSourceHeader()
    {
        var method = typeof(PurchaseOrdersController).GetMethod(
            nameof(PurchaseOrdersController.SubmitPurchaseOrder));

        Assert.NotNull(method);
        Assert.DoesNotContain(
            method.GetParameters(),
            parameter => parameter.GetCustomAttribute<FromHeaderAttribute>() is not null);
    }

    [Fact]
    public async Task SubmitPurchaseOrder_WhenValidationFails_ReturnsBadRequest()
    {
        var service = new Mock<IPurchaseOrdersService>();
        var validation = new ValidationResult();
        validation.AddError("purchaseOrderHeader.account", "Account is required.");
        service
            .Setup(instance => instance.SubmitPurchaseOrder(
                It.IsAny<PurchaseOrder>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(ServiceResponse<SubmitPurchaseOrderResponse>.Error(validation));
        var controller = CreateController(service.Object);

        var result = await controller.SubmitPurchaseOrder(
            PurchaseOrderRequestBuilder.ValidPurchaseOrder(),
            default);

        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetPurchaseOrders_WhenResultsExist_ReturnsOk()
    {
        var service = new Mock<IPurchaseOrdersService>();
        var request = new GetPurchaseOrdersRequest { Source = "Relex" };
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var expected = new PurchaseOrderSearchResponse
        {
            Orders =
            [
                new PurchaseOrderSummary
                {
                    CandidateId = Guid.NewGuid(),
                    Source = "Relex",
                    Account = "BRIT186",
                    Branch = "385",
                    Status = "READY_FOR_SUBMISSION",
                    AcceptedDateTime = DateTimeOffset.UtcNow
                }
            ],
            PageNumber = 1,
            PageSize = 50
        };
        service
            .Setup(instance => instance.GetPurchaseOrders(request, cancellationToken))
            .ReturnsAsync(ServiceResponse<PurchaseOrderSearchResponse>.Ok(expected));
        var controller = CreateController(service.Object);

        var result = await controller.GetPurchaseOrders(request, cancellationToken);

        var ok = Assert.IsType<OkObjectResult>(result.Result);
        Assert.Same(expected, ok.Value);
        service.Verify(
            instance => instance.GetPurchaseOrders(request, cancellationToken),
            Times.Once);
    }

    [Fact]
    public async Task GetPurchaseOrders_WhenSuccessfulResultsAreEmpty_ReturnsSanitizedNotFoundProblem()
    {
        const string sensitiveCriterion = "sensitive-reference-do-not-echo";
        var service = new Mock<IPurchaseOrdersService>();
        var request = new GetPurchaseOrdersRequest
        {
            Source = "Relex",
            Reference = sensitiveCriterion
        };
        service
            .Setup(instance => instance.GetPurchaseOrders(request, It.IsAny<CancellationToken>()))
            .ReturnsAsync(ServiceResponse<PurchaseOrderSearchResponse>.Ok(new PurchaseOrderSearchResponse
            {
                Orders = [],
                PageNumber = 1,
                PageSize = 50
            }));
        var controller = CreateController(service.Object);

        var result = await controller.GetPurchaseOrders(request, default);

        var notFound = Assert.IsType<NotFoundObjectResult>(result.Result);
        var problem = Assert.IsType<ProblemDetails>(notFound.Value);
        Assert.Equal(StatusCodes.Status404NotFound, problem.Status);
        Assert.Equal("Purchase orders were not found.", problem.Title);
        Assert.Equal(
            "No purchase orders matched the supplied search criteria.",
            problem.Detail);
        Assert.Equal(
            "https://tools.ietf.org/html/rfc9110#section-15.5.5",
            problem.Type);
        Assert.DoesNotContain(
            sensitiveCriterion,
            JsonSerializer.Serialize(problem),
            StringComparison.Ordinal);
    }

    [Fact]
    public async Task GetPurchaseOrders_WhenValidationFails_StillReturnsValidationProblemBadRequest()
    {
        var service = new Mock<IPurchaseOrdersService>();
        var validation = new ValidationResult();
        validation.AddError("source", "Source is required.");
        service
            .Setup(instance => instance.GetPurchaseOrders(
                It.IsAny<GetPurchaseOrdersRequest>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(ServiceResponse<PurchaseOrderSearchResponse>.Error(validation));
        var controller = CreateController(service.Object);

        var result = await controller.GetPurchaseOrders(new GetPurchaseOrdersRequest(), default);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result.Result);
        var problem = Assert.IsType<ValidationProblemDetails>(badRequest.Value);
        Assert.Equal(StatusCodes.Status400BadRequest, problem.Status);
        Assert.Contains("source", problem.Errors.Keys);
    }

    [Fact]
    public void GetPurchaseOrders_DeclaresNotFoundProblemResponse()
    {
        var method = typeof(PurchaseOrdersController).GetMethod(
            nameof(PurchaseOrdersController.GetPurchaseOrders));
        Assert.NotNull(method);

        var response = Assert.Single(
            method.GetCustomAttributes<ProducesResponseTypeAttribute>(),
            attribute => attribute.StatusCode == StatusCodes.Status404NotFound);
        Assert.Equal(typeof(ProblemDetails), response.Type);
    }

    [Fact]
    public void Controller_RequiresUserAuthorizationPolicy()
    {
        var authorize = Assert.Single(
            typeof(PurchaseOrdersController).GetCustomAttributes(typeof(AuthorizeAttribute), inherit: true)
                .Cast<AuthorizeAttribute>());

        Assert.Equal(ApiSecuritySettings.AuthenticationSchemes.User, authorize.Policy);
    }

    private static PurchaseOrdersController CreateController(IPurchaseOrdersService service)
    {
        return new PurchaseOrdersController(
            service,
            NullLogger<PurchaseOrdersController>.Instance)
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            }
        };
    }
}
