using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.WebApi.Config;

namespace STUK.PurchaseOrderService.UnitTests.WebApi;

public sealed class WebApiSettingsValidatorTests
{
    private readonly WebApiSettingsValidator _validator = new();

    [Fact]
    public void Validate_WhenMaximumPageSizeIs50_Succeeds()
    {
        var result = _validator.Validate(null, ValidSettings(50));

        Assert.True(result.Succeeded);
    }

    [Fact]
    public void Validate_WhenApiCreateUserIsBlank_FailsWithFixedMessage()
    {
        var settings = new WebApiSettings
        {
            PurchaseOrdersMaxPageSize = 50,
            AllowedSources = ["API", "Relex"],
            ApiCreateUser = " "
        };

        var result = _validator.Validate(null, settings);

        Assert.False(result.Succeeded);
        Assert.Contains(
            "WebApiSettings:ApiCreateUser must not be blank.",
            Assert.IsAssignableFrom<IEnumerable<string>>(result.Failures));
    }

    [Fact]
    public void Validate_WhenMaximumPageSizeIs51_FailsWithFixedMessage()
    {
        var result = _validator.Validate(null, ValidSettings(51));

        Assert.False(result.Succeeded);
        var failures = Assert.IsAssignableFrom<IEnumerable<string>>(result.Failures);
        Assert.Contains(
            "WebApiSettings:PurchaseOrdersMaxPageSize must not exceed 50.",
            failures);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void Validate_WhenMaximumPageSizeIsNotPositive_StillFails(int maximumPageSize)
    {
        var result = _validator.Validate(null, ValidSettings(maximumPageSize));

        Assert.False(result.Succeeded);
        var failures = Assert.IsAssignableFrom<IEnumerable<string>>(result.Failures);
        Assert.Contains(
            "WebApiSettings:PurchaseOrdersMaxPageSize must be greater than zero.",
            failures);
    }

    [Fact]
    public void Validate_WhenAllowedSourceIsBlank_PreservesExistingFailure()
    {
        var settings = new WebApiSettings
        {
            PurchaseOrdersMaxPageSize = 50,
            AllowedSources = ["", "Relex"],
            ApiCreateUser = "APIMIN_User"
        };

        var result = _validator.Validate(null, settings);

        Assert.False(result.Succeeded);
        var failures = Assert.IsAssignableFrom<IEnumerable<string>>(result.Failures);
        Assert.Contains(
            "WebApiSettings:AllowedSources must not contain blank values.",
            failures);
    }

    private static WebApiSettings ValidSettings(int maximumPageSize) => new()
    {
        PurchaseOrdersMaxPageSize = maximumPageSize,
        AllowedSources = ["API", "Relex"],
        ApiCreateUser = "APIMIN_User"
    };
}
