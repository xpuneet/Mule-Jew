using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.TestUtils.Builders;
using STUK.PurchaseOrderService.WebApi.Domain.Config;
using STUK.PurchaseOrderService.WebApi.Domain.Validation;

namespace STUK.PurchaseOrderService.UnitTests.WebApi.Domain;

public sealed class PurchaseOrderRequestValidatorTests
{
    [Fact]
    public void ValidatePurchaseOrder_WhenRequestIsValid_ReturnsValidResult()
    {
        var result = PurchaseOrderRequestValidator.ValidatePurchaseOrder(
            PurchaseOrderRequestBuilder.ValidPurchaseOrder());

        Assert.True(result.IsValid);
        Assert.Empty(result.Errors);
    }

    [Fact]
    public void ValidatePurchaseOrder_WhenRequiredFieldsAreMissing_ReturnsCanonicalPaths()
    {
        var purchaseOrder = new PurchaseOrder
        {
            PurchaseOrderHeader = new PurchaseOrderHeader
            {
                SuspendOrder = true,
                ExtensionAttributes =
                [
                    new PurchaseOrderExtensionAttribute { Name = "packIgnore", Value = "true" }
                ]
            },
            PurchaseOrderLines =
            [
                new PurchaseOrderLine()
            ]
        };

        var result = PurchaseOrderRequestValidator.ValidatePurchaseOrder(
            purchaseOrder);

        Assert.False(result.IsValid);
        Assert.True(result.MissingKeyData);
        Assert.Contains("purchaseOrderHeader.account", result.Errors.Keys);
        Assert.Contains("purchaseOrderHeader.stockClass", result.Errors.Keys);
        Assert.Contains("purchaseOrderLines[0].productId", result.Errors.Keys);
        Assert.Contains("purchaseOrderLines[0].stockClass", result.Errors.Keys);
        Assert.Contains("purchaseOrderLines[0].quantity", result.Errors.Keys);
    }

    [Fact]
    public void ValidatePurchaseOrder_WhenLinesAreMissing_ReturnsLinesError()
    {
        var purchaseOrder = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        purchaseOrder.PurchaseOrderLines = [];

        var result = PurchaseOrderRequestValidator.ValidatePurchaseOrder(
            purchaseOrder);

        Assert.Contains("purchaseOrderLines", result.Errors.Keys);
    }

    [Fact]
    public void ValidatePurchaseOrder_WhenExtensionAttributesAreNull_ReturnsPackIgnoreError()
    {
        var purchaseOrder = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        purchaseOrder.PurchaseOrderHeader!.ExtensionAttributes = null!;

        var result = PurchaseOrderRequestValidator.ValidatePurchaseOrder(
            purchaseOrder);

        Assert.Contains("purchaseOrderHeader.extensionAttributes[packIgnore].value", result.Errors.Keys);
    }

    [Fact]
    public void ValidatePurchaseOrder_WhenLineIsNull_ReturnsLineError()
    {
        var purchaseOrder = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        purchaseOrder.PurchaseOrderLines = [null!];

        var result = PurchaseOrderRequestValidator.ValidatePurchaseOrder(
            purchaseOrder);

        Assert.Contains("purchaseOrderLines[0]", result.Errors.Keys);
    }

    [Fact]
    public void ValidatePurchaseOrder_WhenRequiredTypedHeaderFieldsAreMissing_ReturnsCanonicalPaths()
    {
        var purchaseOrder = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        purchaseOrder.PurchaseOrderHeader!.StockClass = null;
        purchaseOrder.PurchaseOrderHeader.SuspendOrder = null;

        var result = PurchaseOrderRequestValidator.ValidatePurchaseOrder(
            purchaseOrder);

        Assert.Contains("purchaseOrderHeader.stockClass", result.Errors.Keys);
        Assert.Contains("purchaseOrderHeader.suspendOrder", result.Errors.Keys);
    }

    [Fact]
    public void ValidatePurchaseOrder_WhenPackIgnoreBooleanStringIsInvalid_ReturnsCanonicalPath()
    {
        var purchaseOrder = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        purchaseOrder.PurchaseOrderHeader!.ExtensionAttributes
            .Single(attribute => attribute.Name == "packIgnore")
            .Value = "not-a-boolean";

        var result = PurchaseOrderRequestValidator.ValidatePurchaseOrder(
            purchaseOrder);

        Assert.Contains("purchaseOrderHeader.extensionAttributes[packIgnore].value", result.Errors.Keys);
    }

    [Fact]
    public void ValidateGetPurchaseOrdersRequest_WhenSourceIsNotConfigured_ReturnsSourceError()
    {
        var result = PurchaseOrderRequestValidator.ValidateGetPurchaseOrdersRequest(
            new GetPurchaseOrdersRequest { Source = "Unknown" },
            CreateAppSettings());

        Assert.Contains("source", result.Errors.Keys);
    }

    [Fact]
    public void ValidateGetPurchaseOrdersRequest_WhenPageSizeExceedsConfiguredLimit_ReturnsPageSizeError()
    {
        var request = new GetPurchaseOrdersRequest
        {
            Source = "Relex",
            PageNumber = 1,
            PageSize = 51
        };

        var result = PurchaseOrderRequestValidator.ValidateGetPurchaseOrdersRequest(
            request,
            CreateAppSettings(maxPageSize: 50));

        Assert.False(result.IsValid);
        Assert.Contains(nameof(GetPurchaseOrdersRequest.PageSize), result.Errors.Keys);
    }

    private static AppSettings CreateAppSettings(int maxPageSize = 50)
    {
        return new AppSettings(
            new CommonSettings(),
            new WebApiSettings
            {
                AllowedSources = ["API", "Relex"],
                ApiCreateUser = "APIMIN_User",
                PurchaseOrdersMaxPageSize = maxPageSize
            });
    }
}
