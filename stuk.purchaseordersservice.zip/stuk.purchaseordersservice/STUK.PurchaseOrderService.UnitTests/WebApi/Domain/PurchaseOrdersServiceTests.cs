using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.TestUtils.Builders;
using STUK.PurchaseOrderService.WebApi.Domain.Config;
using STUK.PurchaseOrderService.WebApi.Domain.Services.V1;

namespace STUK.PurchaseOrderService.UnitTests.WebApi.Domain;

public sealed class PurchaseOrdersServiceTests
{
    private static readonly DateTimeOffset FixedNow = new(2026, 7, 25, 10, 30, 0, TimeSpan.Zero);

    [Fact]
    public async Task SubmitPurchaseOrder_ReplacesCallerOwnedFieldsAndPersistsCanonicalCandidate()
    {
        var repository = new Mock<IPurchaseOrdersRepository>();
        PurchaseOrderCandidate? persistedCandidate = null;
        var cancellationToken = new CancellationTokenSource().Token;
        repository
            .Setup(instance => instance.AddCandidate(It.IsAny<PurchaseOrderCandidate>(), cancellationToken))
            .Callback<PurchaseOrderCandidate, CancellationToken>((candidate, _) => persistedCandidate = candidate)
            .Returns(Task.CompletedTask);
        var service = CreateService(repository.Object);

        var response = await service.SubmitPurchaseOrder(
            PurchaseOrderRequestBuilder.ValidPurchaseOrder(),
            cancellationToken);

        Assert.True(response.Success);
        Assert.NotNull(persistedCandidate);
        Assert.Equal(PurchaseOrderSources.Api, persistedCandidate.Source);
        Assert.Equal("APIMIN_User", persistedCandidate.Payload.PurchaseOrderHeader!.CreateUser);
        Assert.Equal(PurchaseOrderCandidateStatus.ReadyForSubmission, persistedCandidate.CandidateStatus.Status);
        Assert.Equal(FixedNow, persistedCandidate.CandidateStatus.StatusDateTime);
        Assert.Equal(FixedNow, persistedCandidate.CandidateStatus.CreatedDateTime);
        Assert.Equal(FixedNow, persistedCandidate.CandidateStatus.UpdatedDateTime);
        Assert.Equal(FixedNow, persistedCandidate.CandidateStatus.RefreshDateTime);
        Assert.Equal(FixedNow, persistedCandidate.AcceptedDateTime);
        Assert.Null(persistedCandidate.CandidateStatus.StatusReason);
        Assert.Null(persistedCandidate.CandidateStatus.ProcessBatchNo);
        Assert.Null(persistedCandidate.CandidateStatus.PayloadMD5);
        Assert.Null(persistedCandidate.CandidateStatus.MessageCode);
        Assert.Equal(0, persistedCandidate.CandidateStatus.PendingRetriesCount);
        Assert.Equal(0, persistedCandidate.CandidateStatus.ProcessingRetriesCount);
        Assert.Equal(persistedCandidate.CandidateId, response.Result!.CandidateId);
        Assert.Equal(PurchaseOrderCandidateStatus.ReadyForSubmission, response.Result.Status);
        Assert.Equal(FixedNow, response.Result.AcceptedDateTime);
        repository.Verify(
            instance => instance.AddCandidate(It.IsAny<PurchaseOrderCandidate>(), cancellationToken),
            Times.Once);
    }

    [Fact]
    public async Task GetPurchaseOrders_MapsCanonicalQueryFieldsAndCancellationToken()
    {
        var repository = new Mock<IPurchaseOrdersRepository>();
        PurchaseOrderSearchCriteria? capturedCriteria = null;
        var cancellationToken = new CancellationTokenSource().Token;
        repository
            .Setup(instance => instance.SearchCandidates(It.IsAny<PurchaseOrderSearchCriteria>(), cancellationToken))
            .Callback<PurchaseOrderSearchCriteria, CancellationToken>((criteria, _) => capturedCriteria = criteria)
            .ReturnsAsync([]);
        var service = CreateService(repository.Object);
        var request = new GetPurchaseOrdersRequest
        {
            Source = "Relex",
            Account = "BRIT186",
            Branch = "385",
            Reference = "PO-100",
            IconPurchaseOrderNumber = "ICON-200",
            Status = "READY_FOR_SUBMISSION",
            PageNumber = 2,
            PageSize = 25
        };

        var response = await service.GetPurchaseOrders(request, cancellationToken);

        Assert.True(response.Success);
        Assert.NotNull(capturedCriteria);
        Assert.Equal(request.Source, capturedCriteria.Source);
        Assert.Equal(request.Account, capturedCriteria.Account);
        Assert.Equal(request.Branch, capturedCriteria.Branch);
        Assert.Equal(request.Reference, capturedCriteria.Reference);
        Assert.Equal(request.IconPurchaseOrderNumber, capturedCriteria.IconPurchaseOrderNumber);
        Assert.Equal(PurchaseOrderCandidateStatus.ReadyForSubmission, capturedCriteria.Status);
        Assert.Equal(request.PageNumber, capturedCriteria.PageNumber);
        Assert.Equal(request.PageSize, capturedCriteria.PageSize);
        Assert.NotNull(response.Result);
        Assert.Empty(response.Result.Orders);
        Assert.Equal(request.PageNumber, response.Result.PageNumber);
        Assert.Equal(request.PageSize, response.Result.PageSize);
    }

    private static PurchaseOrdersService CreateService(IPurchaseOrdersRepository repository)
    {
        var appSettings = new AppSettings(
            new CommonSettings(),
            new WebApiSettings
            {
                AllowedSources = ["API", "Relex"],
                ApiCreateUser = "APIMIN_User",
                PurchaseOrdersMaxPageSize = 50
            });

        return new PurchaseOrdersService(
            repository,
            appSettings,
            NullLogger<PurchaseOrdersService>.Instance,
            new FixedTimeProvider(FixedNow));
    }

    private sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => utcNow;
    }
}
