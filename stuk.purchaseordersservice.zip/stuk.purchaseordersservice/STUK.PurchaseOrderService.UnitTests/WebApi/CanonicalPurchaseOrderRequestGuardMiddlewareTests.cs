using System.Text;
using Microsoft.AspNetCore.Http;
using STUK.PurchaseOrderService.WebApi.Middleware;

namespace STUK.PurchaseOrderService.UnitTests.WebApi;

public sealed class CanonicalPurchaseOrderRequestGuardMiddlewareTests
{
    [Fact]
    public async Task InvokeAsync_WhenContentLengthIsMissing_ReturnsLengthRequired()
    {
        var context = CreateContext("{}");
        context.Request.ContentLength = null;

        await InvokeMiddleware(context);

        Assert.Equal(StatusCodes.Status411LengthRequired, context.Response.StatusCode);
    }

    [Fact]
    public async Task InvokeAsync_WhenContentLengthExceedsLimit_ReturnsPayloadTooLarge()
    {
        var context = CreateContext("{}");
        context.Request.ContentLength = 10_241;

        await InvokeMiddleware(context);

        Assert.Equal(StatusCodes.Status413PayloadTooLarge, context.Response.StatusCode);
    }

    [Fact]
    public async Task InvokeAsync_WhenContentTypeIsNotJson_ReturnsBadRequest()
    {
        var context = CreateContext("{}", "text/plain");

        await InvokeMiddleware(context);

        Assert.Equal(StatusCodes.Status400BadRequest, context.Response.StatusCode);
    }

    [Fact]
    public async Task InvokeAsync_WhenPayloadIsAnArray_ReturnsImATeapot()
    {
        var context = CreateContext("  [ {} ]");

        await InvokeMiddleware(context);

        Assert.Equal(StatusCodes.Status418ImATeapot, context.Response.StatusCode);
    }

    [Fact]
    public async Task InvokeAsync_WhenRouteHasTrailingSlashAndPayloadIsAnArray_ReturnsImATeapot()
    {
        var context = CreateContext("[{}]");
        context.Request.Path = "/PurchaseOrderService/PurchaseOrders/v1/";

        await InvokeMiddleware(context);

        Assert.Equal(StatusCodes.Status418ImATeapot, context.Response.StatusCode);
    }

    [Fact]
    public async Task InvokeAsync_WhenPayloadIsAnObject_RewindsBodyAndCallsNext()
    {
        var context = CreateContext("  { \"purchaseOrderHeader\": {} }");
        string? bodySeenByNext = null;
        var middleware = new CanonicalPurchaseOrderRequestGuardMiddleware(async nextContext =>
        {
            using var reader = new StreamReader(nextContext.Request.Body, Encoding.UTF8, leaveOpen: true);
            bodySeenByNext = await reader.ReadToEndAsync();
            nextContext.Response.StatusCode = StatusCodes.Status204NoContent;
        });

        await middleware.InvokeAsync(context);

        Assert.Equal(StatusCodes.Status204NoContent, context.Response.StatusCode);
        Assert.Equal("  { \"purchaseOrderHeader\": {} }", bodySeenByNext);
    }

    private static DefaultHttpContext CreateContext(string body, string contentType = "application/json")
    {
        var bytes = Encoding.UTF8.GetBytes(body);
        var context = new DefaultHttpContext();
        context.Request.Method = HttpMethods.Post;
        context.Request.Path = "/PurchaseOrderService/PurchaseOrders/v1";
        context.Request.ContentType = contentType;
        context.Request.ContentLength = bytes.Length;
        context.Request.Body = new MemoryStream(bytes);
        context.Response.Body = new MemoryStream();
        return context;
    }

    private static Task InvokeMiddleware(HttpContext context)
    {
        var middleware = new CanonicalPurchaseOrderRequestGuardMiddleware(_ => Task.CompletedTask);
        return middleware.InvokeAsync(context);
    }
}
