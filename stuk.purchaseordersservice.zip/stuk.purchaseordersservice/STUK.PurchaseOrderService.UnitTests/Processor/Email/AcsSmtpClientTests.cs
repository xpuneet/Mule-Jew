using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Email.Delivery;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class AcsSmtpClientTests
{
    [Fact]
    public async Task SendAsync_ConfiguresFreshClientFromSmtpSettingsForEachSend()
    {
        var clients = new List<SmtpClient>();
        var cancellationTokens = new List<CancellationToken>();
        var settings = Options.Create(new EmailSenderSettings
        {
            SendingEnabled = true,
            Smtp = new EmailSmtpSettings
            {
                Host = "smtp.azurecomm.net",
                Port = 587,
                UseStartTls = true,
                Username = "test-username",
                Password = "test-password"
            }
        });
        var client = new AcsSmtpClient(
            settings,
            static () => new SmtpClient(),
            (smtpClient, _, cancellationToken) =>
            {
                clients.Add(smtpClient);
                cancellationTokens.Add(cancellationToken);
                Assert.Equal("smtp.azurecomm.net", smtpClient.Host);
                Assert.Equal(587, smtpClient.Port);
                Assert.True(smtpClient.EnableSsl);
                Assert.False(smtpClient.UseDefaultCredentials);
                var credential = Assert.IsType<NetworkCredential>(smtpClient.Credentials);
                Assert.Equal("test-username", credential.UserName);
                Assert.Equal("test-password", credential.Password);
                return Task.CompletedTask;
            });
        using var firstMessage = CreateMessage();
        using var secondMessage = CreateMessage();
        using var cancellationSource = new CancellationTokenSource();

        await client.SendAsync(firstMessage, cancellationSource.Token);
        await client.SendAsync(secondMessage, cancellationSource.Token);

        Assert.Equal(2, clients.Count);
        Assert.NotSame(clients[0], clients[1]);
        Assert.All(cancellationTokens, token => Assert.Equal(cancellationSource.Token, token));
    }

    [Fact]
    public void Constructor_DoesNotCreateClientForBlankDisabledSettings()
    {
        var clientCreated = false;

        var exception = Record.Exception(() => new AcsSmtpClient(
            Options.Create(new EmailSenderSettings
            {
                SendingEnabled = false,
                Smtp = new EmailSmtpSettings()
            }),
            () =>
            {
                clientCreated = true;
                return new SmtpClient();
            },
            static (_, _, _) => Task.CompletedTask));

        Assert.Null(exception);
        Assert.False(clientCreated);
    }

    private static MailMessage CreateMessage() => new(
        "sender@example.com",
        "to@example.com",
        "Subject",
        "Body");
}
