using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using Moq;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Outbox;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class EmailNotificationOutboxTests
{
    [Fact]
    public async Task EnqueueSnapshotAsync_PreservesExactSavedJsonAndOriginalSender()
    {
        var validator = new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator());
        var serializer = new EmailEnvelopeSerializer(validator);
        var request = CreateRequest();
        var envelope = new EmailEnvelopeV1(1, request.NotificationId, request.BusinessCorrelationId,
            "frozen-sender@example.com", request.To, request.Cc, request.Bcc, request.ReplyTo,
            request.Subject, request.HtmlBody, request.PlainTextBody, request.Attachments);
        var snapshot = "\n" + serializer.Serialize(envelope) + "\n";
        EnqueuePurchaseOrderEmailNotificationCommand? saved = null;
        var repository = new Mock<IPurchaseOrderNotificationRepository>(MockBehavior.Strict);
        repository.Setup(x => x.EnqueueEmailNotificationAsync(
                It.IsAny<EnqueuePurchaseOrderEmailNotificationCommand>(), It.IsAny<CancellationToken>()))
            .Returns((EnqueuePurchaseOrderEmailNotificationCommand command, CancellationToken _) =>
            {
                saved = command;
                return Task.FromResult(CreateEnqueuedResult(command.NotificationId,
                    SHA256.HashData(Encoding.Unicode.GetBytes(command.EmailEnvelopeJson))));
            });

        await CreateOutbox(repository.Object).EnqueueSnapshotAsync(snapshot, CreateMetadata());

        Assert.NotNull(saved);
        Assert.Equal(snapshot, saved.EmailEnvelopeJson);
        Assert.Equal("frozen-sender@example.com", serializer.Deserialize(saved.EmailEnvelopeJson).SenderAddress);
    }

    [Fact]
    public async Task EnqueueSnapshotAsync_InvalidJsonNeverCallsDatabase()
    {
        var repository = new Mock<IPurchaseOrderNotificationRepository>(MockBehavior.Strict);
        await Assert.ThrowsAsync<System.Text.Json.JsonException>(() =>
            CreateOutbox(repository.Object).EnqueueSnapshotAsync("not-json", CreateMetadata()));
        repository.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task EnqueueAsync_PersistsOneValidatedSnapshotWithConfiguredSenderAndMetadata()
    {
        var request = CreateRequest();
        var metadata = new EmailNotificationMetadata(
            Guid.Parse("22222222-2222-2222-2222-222222222222"),
            "BATCH_COMPLETED",
            "batch-result-v1",
            "relex-support",
            "batch-results.csv",
            new DateTimeOffset(2026, 9, 18, 12, 30, 0, TimeSpan.FromHours(2)));
        var settings = new EmailSenderSettings
        {
            DefaultSenderAddress = "configured-sender@example.com"
        };
        EnqueuePurchaseOrderEmailNotificationCommand? persistedCommand = null;
        var repository = new Mock<IPurchaseOrderNotificationRepository>(MockBehavior.Strict);
        repository
            .Setup(candidate => candidate.EnqueueEmailNotificationAsync(
                It.IsAny<EnqueuePurchaseOrderEmailNotificationCommand>(),
                It.IsAny<CancellationToken>()))
            .Returns((EnqueuePurchaseOrderEmailNotificationCommand command, CancellationToken _) =>
            {
                persistedCommand = command;
                return Task.FromResult(CreateEnqueuedResult(
                    command.NotificationId,
                    SHA256.HashData(Encoding.Unicode.GetBytes(command.EmailEnvelopeJson))));
            });
        var realSerializer = new EmailEnvelopeSerializer(
            new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator()));
        var serializer = new CountingEmailEnvelopeSerializer(realSerializer);
        var optionsMonitor = new MutableOptionsMonitor<EmailSenderSettings>(settings);
        var outbox = new EmailNotificationOutbox(
            repository.Object,
            new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator()),
            serializer,
            optionsMonitor);

        var result = await outbox.EnqueueAsync(request, metadata, CancellationToken.None);

        Assert.NotNull(persistedCommand);
        var persistedEnvelope = realSerializer.Deserialize(persistedCommand.EmailEnvelopeJson);
        Assert.Equal(settings.DefaultSenderAddress, persistedEnvelope.SenderAddress);
        Assert.Equal(request.NotificationId, persistedEnvelope.NotificationId);
        Assert.Equal(request.BusinessCorrelationId, persistedEnvelope.BusinessCorrelationId);
        Assert.Equal("Named Recipient", persistedEnvelope.To[0].DisplayName);
        Assert.Equal("Named Reply", persistedEnvelope.ReplyTo[0].DisplayName);
        Assert.Equal("aGVsbG8=", persistedEnvelope.Attachments[0].Base64Content);
        Assert.Equal((short)1, persistedCommand.EmailEnvelopeVersion);
        Assert.Equal(metadata.BatchId, persistedCommand.BatchId);
        Assert.Equal(metadata.EventType, persistedCommand.EventType);
        Assert.Equal(metadata.TemplateKey, persistedCommand.TemplateKey);
        Assert.Equal(metadata.RecipientGroupKey, persistedCommand.RecipientGroupKey);
        Assert.Equal(metadata.AttachmentBlobName, persistedCommand.AttachmentBlobName);
        Assert.Equal(new DateTimeOffset(2026, 9, 18, 10, 30, 0, TimeSpan.Zero), persistedCommand.CreatedDateTime);
        Assert.Equal(1, serializer.SerializeCallCount);
        Assert.Equal(request.NotificationId, result.NotificationId);
    }

    [Fact]
    public async Task EnqueueAsync_UsesCurrentSenderWhenCreatingNewSnapshot()
    {
        EnqueuePurchaseOrderEmailNotificationCommand? persistedCommand = null;
        var repository = new Mock<IPurchaseOrderNotificationRepository>(MockBehavior.Strict);
        repository
            .Setup(candidate => candidate.EnqueueEmailNotificationAsync(
                It.IsAny<EnqueuePurchaseOrderEmailNotificationCommand>(),
                It.IsAny<CancellationToken>()))
            .Returns((EnqueuePurchaseOrderEmailNotificationCommand command, CancellationToken _) =>
            {
                persistedCommand = command;
                return Task.FromResult(CreateEnqueuedResult(
                    command.NotificationId,
                    SHA256.HashData(Encoding.Unicode.GetBytes(command.EmailEnvelopeJson))));
            });
        var validator = new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator());
        var serializer = new EmailEnvelopeSerializer(validator);
        var optionsMonitor = new MutableOptionsMonitor<EmailSenderSettings>(new EmailSenderSettings
        {
            DefaultSenderAddress = "old-sender@example.com"
        });
        var outbox = new EmailNotificationOutbox(
            repository.Object,
            validator,
            serializer,
            optionsMonitor);
        optionsMonitor.CurrentValue = new EmailSenderSettings
        {
            DefaultSenderAddress = "current-sender@example.com"
        };

        await outbox.EnqueueAsync(CreateRequest(), CreateMetadata());

        Assert.NotNull(persistedCommand);
        var envelope = serializer.Deserialize(persistedCommand.EmailEnvelopeJson);
        Assert.Equal("current-sender@example.com", envelope.SenderAddress);
    }

    [Fact]
    public async Task EnqueueAsync_RejectsSqlHashThatDoesNotMatchExactUnicodeJson()
    {
        var repository = new Mock<IPurchaseOrderNotificationRepository>(MockBehavior.Strict);
        repository
            .Setup(candidate => candidate.EnqueueEmailNotificationAsync(
                It.IsAny<EnqueuePurchaseOrderEmailNotificationCommand>(),
                It.IsAny<CancellationToken>()))
            .Returns((EnqueuePurchaseOrderEmailNotificationCommand command, CancellationToken _) =>
                Task.FromResult(CreateEnqueuedResult(command.NotificationId, new byte[32])));
        var outbox = CreateOutbox(repository.Object);

        await Assert.ThrowsAsync<InvalidOperationException>(() => outbox.EnqueueAsync(
            CreateRequest(),
            CreateMetadata()));
    }

    [Fact]
    public async Task EnqueueAsync_DoesNotCallRepositoryWhenEnvelopeValidationFails()
    {
        var repository = new Mock<IPurchaseOrderNotificationRepository>(MockBehavior.Strict);
        var outbox = CreateOutbox(repository.Object);
        var invalidRequest = CreateRequest() with { Subject = " " };

        await Assert.ThrowsAsync<ArgumentException>(() => outbox.EnqueueAsync(
            invalidRequest,
            CreateMetadata()));
        repository.Verify(
            candidate => candidate.EnqueueEmailNotificationAsync(
                It.IsAny<EnqueuePurchaseOrderEmailNotificationCommand>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    private static EmailNotificationOutbox CreateOutbox(
        IPurchaseOrderNotificationRepository repository)
    {
        var sizeCalculator = new AcsSmtpMessageSizeCalculator();
        var validator = new EmailEnvelopeValidator(sizeCalculator);
        return new EmailNotificationOutbox(
            repository,
            validator,
            new EmailEnvelopeSerializer(validator),
            new MutableOptionsMonitor<EmailSenderSettings>(new EmailSenderSettings
            {
                DefaultSenderAddress = "configured-sender@example.com"
            }));
    }

    private static EmailNotificationRequest CreateRequest() => new(
        Guid.Parse("11111111-1111-1111-1111-111111111111"),
        "corr-123",
        [new EmailMailbox("recipient@example.com", "Named Recipient")],
        [],
        [],
        [new EmailMailbox("reply@example.com", "Named Reply")],
        "Subject",
        "<p>Hello</p>",
        "Hello",
        [
            new EmailAttachmentV1(
                "hello.txt",
                "text/plain",
                "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824",
                "aGVsbG8=")
        ]);

    private static EmailNotificationMetadata CreateMetadata() => new(
        null,
        "BATCH_COMPLETED",
        null,
        null,
        null,
        new DateTimeOffset(2026, 9, 18, 10, 30, 0, TimeSpan.Zero));

    private static EnqueuedPurchaseOrderEmailNotification CreateEnqueuedResult(
        Guid notificationId,
        byte[] payloadSha256) => new(
        notificationId,
        "PENDING",
        new DateTimeOffset(2026, 9, 18, 10, 30, 0, TimeSpan.Zero),
        0,
        0,
        0,
        payloadSha256,
        [1, 2, 3, 4, 5, 6, 7, 8]);

    private sealed class CountingEmailEnvelopeSerializer(IEmailEnvelopeSerializer inner)
        : IEmailEnvelopeSerializer
    {
        public int SerializeCallCount { get; private set; }

        public string Serialize(EmailEnvelopeV1 envelope)
        {
            SerializeCallCount++;
            return inner.Serialize(envelope);
        }

        public EmailEnvelopeV1 Deserialize(string envelopeJson) => inner.Deserialize(envelopeJson);
    }

    private sealed class MutableOptionsMonitor<TOptions>(TOptions currentValue)
        : IOptionsMonitor<TOptions>
    {
        public TOptions CurrentValue { get; set; } = currentValue;

        public TOptions Get(string? name) => CurrentValue;

        public IDisposable? OnChange(Action<TOptions, string?> listener) => null;
    }
}
