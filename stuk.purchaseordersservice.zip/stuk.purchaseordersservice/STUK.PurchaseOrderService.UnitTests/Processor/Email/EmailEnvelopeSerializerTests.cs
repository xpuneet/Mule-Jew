using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class EmailEnvelopeSerializerTests
{
    private const string HelloSha256 =
        "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824";

    [Fact]
    public void Serialize_ProducesDeterministicCamelCaseSnapshot()
    {
        var serializer = CreateSerializer();
        var envelope = CreateEnvelope();

        var first = serializer.Serialize(envelope);
        var second = serializer.Serialize(envelope);

        const string expected = "{\"schemaVersion\":1,\"notificationId\":\"11111111-1111-1111-1111-111111111111\",\"businessCorrelationId\":\"corr-123\",\"senderAddress\":\"sender@example.com\",\"to\":[{\"address\":\"to@example.com\",\"displayName\":\"To User\"}],\"cc\":[{\"address\":\"cc@example.com\",\"displayName\":null}],\"bcc\":[],\"replyTo\":[{\"address\":\"reply@example.com\",\"displayName\":\"Reply User\"}],\"subject\":\"Subject\",\"htmlBody\":\"<p>Hello</p>\",\"plainTextBody\":\"Hello\",\"attachments\":[{\"fileName\":\"hello.txt\",\"contentType\":\"text/plain\",\"sha256\":\"2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824\",\"base64Content\":\"aGVsbG8=\"}]}";
        Assert.Equal(expected, first);
        Assert.Equal(first, second);
    }

    [Fact]
    public void Deserialize_ReturnsValidatedImmutableSnapshotWithAllPrivateFields()
    {
        var serializer = CreateSerializer();
        var expectedJson = serializer.Serialize(CreateEnvelope());

        var envelope = serializer.Deserialize(expectedJson);

        Assert.Equal(expectedJson, serializer.Serialize(envelope));
        Assert.Equal("To User", envelope.To[0].DisplayName);
        Assert.Equal("Reply User", envelope.ReplyTo[0].DisplayName);
        Assert.Equal("aGVsbG8=", envelope.Attachments[0].Base64Content);
        Assert.Equal(HelloSha256, envelope.Attachments[0].Sha256);
    }

    [Fact]
    public void EmailEnvelopeV1_ConstructorCopiesEveryCallerOwnedCollection()
    {
        var to = new List<EmailMailbox> { new("to@example.com", "To User") };
        var cc = new List<EmailMailbox> { new("cc@example.com", "Cc User") };
        var bcc = new List<EmailMailbox> { new("bcc@example.com", "Bcc User") };
        var replyTo = new List<EmailMailbox> { new("reply@example.com", "Reply User") };
        var attachments = new List<EmailAttachmentV1>
        {
            new("hello.txt", "text/plain", HelloSha256, "aGVsbG8=")
        };
        var envelope = new EmailEnvelopeV1(
            1,
            Guid.Parse("11111111-1111-1111-1111-111111111111"),
            "corr-123",
            "sender@example.com",
            to,
            cc,
            bcc,
            replyTo,
            "Subject",
            "<p>Hello</p>",
            "Hello",
            attachments);

        to[0] = new EmailMailbox("changed-to@example.com", null);
        cc.Clear();
        bcc.Add(new EmailMailbox("changed-bcc@example.com", null));
        replyTo[0] = new EmailMailbox("changed-reply@example.com", null);
        attachments.Clear();

        Assert.Equal("to@example.com", envelope.To.Single().Address);
        Assert.Equal("cc@example.com", envelope.Cc.Single().Address);
        Assert.Equal("bcc@example.com", envelope.Bcc.Single().Address);
        Assert.Equal("reply@example.com", envelope.ReplyTo.Single().Address);
        Assert.Equal("hello.txt", envelope.Attachments.Single().FileName);
    }

    [Fact]
    public void Deserialize_ReturnsCollectionsWhoseElementsCannotBeReplaced()
    {
        var serializer = CreateSerializer();
        var envelope = serializer.Deserialize(serializer.Serialize(CreateEnvelope()));
        var to = Assert.IsAssignableFrom<IList<EmailMailbox>>(envelope.To);
        var cc = Assert.IsAssignableFrom<IList<EmailMailbox>>(envelope.Cc);
        var replyTo = Assert.IsAssignableFrom<IList<EmailMailbox>>(envelope.ReplyTo);
        var attachments = Assert.IsAssignableFrom<IList<EmailAttachmentV1>>(
            envelope.Attachments);

        Assert.Throws<NotSupportedException>(() =>
            to[0] = new EmailMailbox("changed-to@example.com", null));
        Assert.Throws<NotSupportedException>(() => cc.Clear());
        Assert.Throws<NotSupportedException>(() =>
            replyTo[0] = new EmailMailbox("changed-reply@example.com", null));
        Assert.Throws<NotSupportedException>(() => attachments.Clear());
    }

    [Fact]
    public void Deserialize_RejectsUnknownSchemaVersion()
    {
        var serializer = CreateSerializer();
        var json = serializer.Serialize(CreateEnvelope()).Replace(
            "\"schemaVersion\":1",
            "\"schemaVersion\":2",
            StringComparison.Ordinal);

        Assert.Throws<ArgumentException>(() => serializer.Deserialize(json));
    }

    [Fact]
    public void Deserialize_RejectsEnvelopeThatFailsValidation()
    {
        var serializer = CreateSerializer();
        var json = serializer.Serialize(CreateEnvelope()).Replace(
            "\"subject\":\"Subject\"",
            "\"subject\":\"\"",
            StringComparison.Ordinal);

        Assert.Throws<ArgumentException>(() => serializer.Deserialize(json));
    }

    [Fact]
    public void Deserialize_RejectsAttachmentWithMissingSha256AsValidationFailure()
    {
        var serializer = CreateSerializer();
        var json = serializer.Serialize(CreateEnvelope()).Replace(
            $"\"sha256\":\"{HelloSha256}\",",
            string.Empty,
            StringComparison.Ordinal);

        Assert.Throws<ArgumentException>(() => serializer.Deserialize(json));
    }

    private static EmailEnvelopeSerializer CreateSerializer()
    {
        var sizeCalculator = new AcsSmtpMessageSizeCalculator();
        return new EmailEnvelopeSerializer(new EmailEnvelopeValidator(sizeCalculator));
    }

    private static EmailEnvelopeV1 CreateEnvelope() => new(
        1,
        Guid.Parse("11111111-1111-1111-1111-111111111111"),
        "corr-123",
        "sender@example.com",
        [new EmailMailbox("to@example.com", "To User")],
        [new EmailMailbox("cc@example.com", null)],
        [],
        [new EmailMailbox("reply@example.com", "Reply User")],
        "Subject",
        "<p>Hello</p>",
        "Hello",
        [new EmailAttachmentV1("hello.txt", "text/plain", HelloSha256, "aGVsbG8=")]);
}
