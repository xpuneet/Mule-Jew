using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Relex;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class RelexEmailComposerTests
{
    private const string CsvHeader = "counter,branch,supplier,order number,create status,suspended status,suspended message,bypass flag status,delivery mode,api user\r\n";
    private readonly RelexEmailComposer _composer = new();

    [Fact]
    public void Compose_Results_PreservesSubjectFrozenAddressesAndLegacyAttachmentContract()
    {
        var notification = CreateNotification();

        var envelope = _composer.Compose(notification);

        Assert.Equal(1, envelope.SchemaVersion);
        Assert.Equal(notification.NotificationId, envelope.NotificationId);
        Assert.Equal(notification.BusinessCorrelationId, envelope.BusinessCorrelationId);
        Assert.Equal("frozen-sender@example.com", envelope.SenderAddress);
        Assert.Equal(["operations@example.com", "relex@example.com"], envelope.To.Select(x => x.Address));
        Assert.All(envelope.To, x => Assert.Null(x.DisplayName));
        Assert.Empty(envelope.Cc);
        Assert.Empty(envelope.Bcc);
        Assert.Empty(envelope.ReplyTo);
        Assert.Equal("Relex PO Results | Environment - test", envelope.Subject);
        Assert.Equal("<html>\n<body bgcolor=\"White\" text=\"Black\">\n<p>CSV attached\n<br><br> \n\n</p>\n</body>\n</html>", envelope.HtmlBody);
        Assert.Null(envelope.PlainTextBody);
        var attachment = Assert.Single(envelope.Attachments);
        Assert.Equal("SG_OrderProposals_20260924.csv", attachment.FileName);
        Assert.Equal("application/octet-stream", attachment.ContentType);
        var bytes = Convert.FromBase64String(attachment.Base64Content);
        Assert.False(bytes.AsSpan().StartsWith(Encoding.UTF8.GetPreamble()));
        Assert.Equal(CsvHeader + "1,12,SUPPLIER,345,Created,false,,true,D,APIRELEX_User\r\n", Encoding.UTF8.GetString(bytes));
        Assert.Equal(Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(), attachment.Sha256);
    }

    [Fact]
    public void Compose_MixedResults_ReportsFailuresInCsvWithoutInventingAnErrorFile()
    {
        var notification = CreateNotification(rows:
        [
            CreateRow(),
            CreateRow() with
            {
                Counter = 2,
                OrderNumber = null,
                CreateStatus = "Validation\r\nfailed",
                Suspended = null,
                SuspendedMessage = "unavailable",
                Bypass = null,
                CandidateStatus = "NON_RECOVERABLE_ERROR"
            }
        ]);

        var envelope = _composer.Compose(notification);

        Assert.Contains("Failed Purchase Orders are included in the attached CSV.", envelope.HtmlBody);
        Assert.DoesNotContain("SFTP", envelope.HtmlBody);
        Assert.DoesNotContain("error_", envelope.HtmlBody);
        Assert.EndsWith("2,12,SUPPLIER,0,Validationfailed,false,check ICON,,D,APIRELEX_User\r\n", Csv(envelope));
    }

    [Fact]
    public void Compose_Results_EscapesCsvAndPreservesUnicodeWithoutPuttingDataInHtml()
    {
        var notification = CreateNotification(rows:
        [
            CreateRow() with
            {
                Supplier = "Supplier, \"Łódź\"",
                Suspended = true,
                SuspendedMessage = "First line\r\n<script>alert(1)</script>",
                CreateStatus = "Created\r\nwith warning"
            }
        ]);

        var envelope = _composer.Compose(notification);

        Assert.Equal(CsvHeader + "1,12,\"Supplier, \"\"Łódź\"\"\",345,Createdwith warning,true,\"First line\r\n<script>alert(1)</script>\",true,D,APIRELEX_User\r\n", Csv(envelope));
        Assert.DoesNotContain("<script>", envelope.HtmlBody);
        Assert.DoesNotContain("Łódź", envelope.HtmlBody);
    }

    [Theory]
    [InlineData("=HYPERLINK(\"https://example.com\")", "\"'=HYPERLINK(\"\"https://example.com\"\")\"")]
    [InlineData("+SUM(A1:A2)", "'+SUM(A1:A2)")]
    [InlineData("-1+2", "'-1+2")]
    [InlineData("@SUM(A1:A2)", "'@SUM(A1:A2)")]
    [InlineData("  =1+2", "'  =1+2")]
    [InlineData("\t=1+2", "'\t=1+2")]
    [InlineData("\r=1+2", "\"'\r=1+2\"")]
    [InlineData("\uFEFF=1+2", "'\uFEFF=1+2")]
    public void Compose_Results_NeutralizesSpreadsheetFormulaCells(string input, string expectedCell)
    {
        var envelope = _composer.Compose(CreateNotification(rows:
        [CreateRow() with { Supplier = input }]));

        Assert.Contains($"\r\n1,12,{expectedCell},345,", Csv(envelope));
    }

    [Theory]
    [InlineData("00123")]
    [InlineData("-123")]
    [InlineData("+123")]
    [InlineData("-12.5")]
    [InlineData("+1e3")]
    public void Compose_Results_PreservesNormalNumericCells(string input)
    {
        var envelope = _composer.Compose(CreateNotification(rows:
        [CreateRow() with { Supplier = input }]));

        Assert.Contains($"\r\n1,12,{input},345,", Csv(envelope));
    }

    [Fact]
    public void Compose_Results_DefaultsUnavailableLegacyFieldsWithoutInventingActivationSuccess()
    {
        var envelope = _composer.Compose(CreateNotification(rows:
        [CreateRow() with
        {
            OrderNumber = null,
            CreateStatus = null,
            Suspended = null,
            SuspendedMessage = null,
            Bypass = null,
            DeliveryMode = null,
            ApiUser = null,
            CandidateStatus = "RECOVERABLE_ERROR"
        }]));

        Assert.Equal(CsvHeader + "1,12,SUPPLIER,0,Purchase Order timed out,false,check ICON,,,\r\n", Csv(envelope));
    }

    [Fact]
    public void Compose_Missing_UsesLegacyShapeWithAccurateProcessingWordingAndNoAttachment()
    {
        var notification = CreateNotification() with
        {
            EventType = "RELEX_MISSING",
            OriginalFileName = null,
            OutcomeRowsJson = "[]"
        };

        var envelope = _composer.Compose(notification);

        Assert.Equal("Relex - No order proposal notification | Environment - test", envelope.Subject);
        Assert.Equal("<html>\n<body bgcolor=\"White\" text=\"Black\">\n<p>No recent Purchase Order proposals have been processed by the agreed cut off time.<br><br> Please investigate with Relex, CSD and the Integration team. </p>\n</body>\n</html>", envelope.HtmlBody);
        Assert.DoesNotContain("no Purchase Orders have been created", envelope.HtmlBody);
        Assert.Empty(envelope.Attachments);
        Assert.Null(envelope.PlainTextBody);
    }

    [Fact]
    public void Compose_RepeatedFrozenEvent_IsByteDeterministic()
    {
        var notification = CreateNotification();

        var first = JsonSerializer.Serialize(_composer.Compose(notification), JsonSerializerOptions.Web);
        var second = JsonSerializer.Serialize(_composer.Compose(notification), JsonSerializerOptions.Web);

        Assert.Equal(first, second);
    }

    [Theory]
    [InlineData("../proposal.csv")]
    [InlineData("/proposal.csv")]
    [InlineData("folder/proposal.csv")]
    [InlineData("folder\\proposal.csv")]
    [InlineData("C:proposal.csv")]
    [InlineData("proposal.csv\r\nBcc:other@example.com")]
    [InlineData(".")]
    [InlineData("..")]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData(null)]
    public void Compose_Results_RejectsUnsafeOrMissingAttachmentName(string? fileName)
    {
        Assert.Throws<InvalidOperationException>(() =>
            _composer.Compose(CreateNotification() with { OriginalFileName = fileName }));
    }

    [Theory]
    [InlineData("[]")]
    [InlineData("null")]
    [InlineData("[null]")]
    [InlineData("invalid")]
    public void Compose_Results_RejectsMissingOrMalformedRows(string rowsJson)
    {
        Assert.Throws<InvalidOperationException>(() =>
            _composer.Compose(CreateNotification() with { OutcomeRowsJson = rowsJson }));
    }

    [Theory]
    [InlineData("READY_FOR_SUBMISSION")]
    [InlineData("SUBMITTING")]
    [InlineData("")]
    public void Compose_Results_RejectsNonTerminalOutcomes(string candidateStatus)
    {
        Assert.Throws<InvalidOperationException>(() =>
            _composer.Compose(CreateNotification(rows:
            [CreateRow() with { CandidateStatus = candidateStatus }])));
    }

    [Fact]
    public void Compose_Results_RejectsCsvAboveSafetyBudgetWithoutTruncation()
    {
        var notification = CreateNotification(rows:
        [CreateRow() with { CreateStatus = new string('x', 6 * 1024 * 1024) }]);

        Assert.Throws<InvalidOperationException>(() => _composer.Compose(notification));
    }

    [Theory]
    [InlineData("RELEX_UNKNOWN")]
    [InlineData("relex_results")]
    [InlineData("")]
    public void Compose_RejectsUnknownEventType(string eventType)
    {
        Assert.Throws<InvalidOperationException>(() =>
            _composer.Compose(CreateNotification() with { EventType = eventType }));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(2)]
    public void Compose_RejectsUnsupportedCompositionSchema(int schemaVersion)
    {
        Assert.Throws<InvalidOperationException>(() =>
            _composer.Compose(CreateNotification(snapshot: CreateSnapshot() with { SchemaVersion = schemaVersion })));
    }

    [Theory]
    [InlineData("null")]
    [InlineData("{}")]
    [InlineData("invalid")]
    public void Compose_RejectsMissingOrMalformedCompositionSnapshot(string snapshotJson)
    {
        Assert.Throws<InvalidOperationException>(() =>
            _composer.Compose(CreateNotification() with { CompositionSettingsJson = snapshotJson }));
    }

    [Theory]
    [InlineData("")]
    [InlineData("test\r\nBcc:other@example.com")]
    public void Compose_RejectsInvalidEnvironment(string environment)
    {
        Assert.Throws<InvalidOperationException>(() =>
            _composer.Compose(CreateNotification(snapshot: CreateSnapshot() with { EnvironmentName = environment })));
    }

    [Fact]
    public void Compose_RejectsMissingFrozenRecipientAndSender()
    {
        Assert.Throws<InvalidOperationException>(() => _composer.Compose(CreateNotification(
            snapshot: CreateSnapshot() with { Recipients = [] })));
        Assert.Throws<InvalidOperationException>(() => _composer.Compose(CreateNotification(
            snapshot: CreateSnapshot() with { SenderAddress = string.Empty })));
    }

    private static string Csv(EmailEnvelopeV1 envelope) =>
        Encoding.UTF8.GetString(Convert.FromBase64String(Assert.Single(envelope.Attachments).Base64Content));

    private static RelexEmailCompositionSnapshot CreateSnapshot() => new(
        1,
        "test",
        ["operations@example.com", "relex@example.com"],
        "frozen-sender@example.com");

    private static RelexNotificationOutcomeRow CreateRow() => new(
        1, "12", "SUPPLIER", "345", "Created", false, null, true, "D", "APIRELEX_User", "COMPLETED");

    private static RelexNotificationEvent CreateNotification(
        IReadOnlyList<RelexNotificationOutcomeRow>? rows = null,
        RelexEmailCompositionSnapshot? snapshot = null) => new(
        Guid.Parse("6a7870b1-510c-4e8b-ac17-2a4237c61c97"),
        Guid.Parse("8290b025-a8d6-4af1-8358-fcd03e9c4c76"),
        "RELEX_RESULTS",
        "batch-8290b025-a8d6-4af1-8358-fcd03e9c4c76",
        "SG_OrderProposals_20260924.csv",
        DateTimeOffset.Parse("2026-09-24T09:30:00+00:00"),
        JsonSerializer.Serialize(snapshot ?? CreateSnapshot(), JsonSerializerOptions.Web),
        JsonSerializer.Serialize(rows ?? [CreateRow()], JsonSerializerOptions.Web),
        null,
        Guid.Parse("fdf063a2-e046-4b59-92bc-08ad974d4083"),
        0);
}
