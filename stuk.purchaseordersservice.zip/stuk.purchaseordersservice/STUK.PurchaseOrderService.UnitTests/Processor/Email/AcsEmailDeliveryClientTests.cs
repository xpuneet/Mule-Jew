using System.Net.Mail;
using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Delivery;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class AcsEmailDeliveryClientTests
{
    private const string HelloSha256 =
        "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824";

    [Fact]
    public async Task SendAsync_WhenSmtpAcceptsMessage_ReturnsSuccessWithoutProviderMessageId()
    {
        MailMessage? sentMessage = null;
        using var cancellationSource = new CancellationTokenSource();
        var smtpClient = new StubSmtpClient((message, cancellationToken) =>
        {
            sentMessage = message;
            Assert.Equal(cancellationSource.Token, cancellationToken);
            return Task.CompletedTask;
        });

        var result = await CreateClient(smtpClient).SendAsync(
            CreateEnvelope(),
            cancellationSource.Token);

        Assert.Equal(EmailDeliveryOutcome.Succeeded, result.Outcome);
        Assert.Null(result.ProviderMessageId);
        Assert.Null(result.HttpStatusCode);
        Assert.Null(result.FailureCategory);
        Assert.Null(result.FailureCode);
        Assert.Null(result.FailureDescription);
        Assert.NotNull(sentMessage);
    }

    [Theory]
    [InlineData(421)]
    [InlineData(450)]
    [InlineData(451)]
    [InlineData(452)]
    [InlineData(454)]
    public async Task SendAsync_WhenSmtpReturns4xx_ClassifiesSanitizedTransientFailure(int status)
    {
        var result = await SendExceptionAsync(new SmtpException(
            (SmtpStatusCode)status,
            "RAW PROVIDER RESPONSE WITH PRIVATE DETAILS"));

        Assert.Equal(EmailDeliveryOutcome.TransientFailure, result.Outcome);
        Assert.Equal("TRANSPORT", result.FailureCategory);
        Assert.Equal($"ACS_SMTP_{status}", result.FailureCode);
        Assert.Null(result.HttpStatusCode);
        Assert.DoesNotContain("RAW", result.FailureDescription, StringComparison.Ordinal);
        Assert.DoesNotContain("PRIVATE", result.FailureDescription, StringComparison.Ordinal);
    }

    [Theory]
    [InlineData(500)]
    [InlineData(501)]
    [InlineData(502)]
    [InlineData(503)]
    [InlineData(504)]
    [InlineData(550)]
    [InlineData(551)]
    [InlineData(552)]
    [InlineData(553)]
    [InlineData(554)]
    public async Task SendAsync_WhenSmtpReturns5xx_ClassifiesSanitizedPermanentFailure(int status)
    {
        var result = await SendExceptionAsync(new SmtpException(
            (SmtpStatusCode)status,
            "RAW PROVIDER RESPONSE WITH PRIVATE DETAILS"));

        Assert.Equal(EmailDeliveryOutcome.PermanentFailure, result.Outcome);
        Assert.Equal("PROVIDER", result.FailureCategory);
        Assert.Equal($"ACS_SMTP_{status}", result.FailureCode);
        Assert.Null(result.HttpStatusCode);
        Assert.DoesNotContain("RAW", result.FailureDescription, StringComparison.Ordinal);
        Assert.DoesNotContain("PRIVATE", result.FailureDescription, StringComparison.Ordinal);
    }

    [Fact]
    public async Task SendAsync_WhenSmtpHasNoStatus_ClassifiesSanitizedTransientFailure()
    {
        var result = await SendExceptionAsync(new SmtpException(
            SmtpStatusCode.GeneralFailure,
            "RAW PROVIDER RESPONSE WITH PRIVATE DETAILS"));

        Assert.Equal(EmailDeliveryOutcome.TransientFailure, result.Outcome);
        Assert.Equal("TRANSPORT", result.FailureCategory);
        Assert.Equal("ACS_SMTP_ERROR", result.FailureCode);
        Assert.DoesNotContain("RAW", result.FailureDescription, StringComparison.Ordinal);
    }

    [Fact]
    public async Task SendAsync_WhenAllFailedRecipientsHave5xxStatuses_ClassifiesPermanentFailure()
    {
        var result = await SendExceptionAsync(new SmtpFailedRecipientsException(
            "RAW AGGREGATE RESPONSE WITH PRIVATE DETAILS",
            [
                new SmtpFailedRecipientException(
                    SmtpStatusCode.MailboxUnavailable,
                    "private-first@example.com",
                    "RAW FIRST RECIPIENT RESPONSE"),
                new SmtpFailedRecipientException(
                    SmtpStatusCode.UserNotLocalTryAlternatePath,
                    "private-second@example.com",
                    "RAW SECOND RECIPIENT RESPONSE")
            ]));

        Assert.Equal(EmailDeliveryOutcome.PermanentFailure, result.Outcome);
        Assert.Equal("PROVIDER", result.FailureCategory);
        Assert.Equal("ACS_SMTP_RECIPIENTS_REJECTED", result.FailureCode);
        Assert.DoesNotContain("RAW", result.FailureDescription, StringComparison.Ordinal);
        Assert.DoesNotContain("private", result.FailureDescription, StringComparison.Ordinal);
    }

    [Fact]
    public async Task SendAsync_WhenFailedRecipientStatusesAreMixed_ClassifiesTransientFailure()
    {
        var result = await SendExceptionAsync(new SmtpFailedRecipientsException(
            "RAW AGGREGATE RESPONSE WITH PRIVATE DETAILS",
            [
                new SmtpFailedRecipientException(
                    SmtpStatusCode.MailboxBusy,
                    "private-temporary@example.com",
                    "RAW TEMPORARY RECIPIENT RESPONSE"),
                new SmtpFailedRecipientException(
                    SmtpStatusCode.MailboxUnavailable,
                    "private-permanent@example.com",
                    "RAW PERMANENT RECIPIENT RESPONSE")
            ]));

        Assert.Equal(EmailDeliveryOutcome.TransientFailure, result.Outcome);
        Assert.Equal("TRANSPORT", result.FailureCategory);
        Assert.Equal("ACS_SMTP_RECIPIENTS_RETRYABLE", result.FailureCode);
        Assert.DoesNotContain("RAW", result.FailureDescription, StringComparison.Ordinal);
        Assert.DoesNotContain("private", result.FailureDescription, StringComparison.Ordinal);
    }

    [Fact]
    public async Task SendAsync_WhenAllFailedRecipientsHave4xxStatuses_ClassifiesTransientFailure()
    {
        var result = await SendExceptionAsync(new SmtpFailedRecipientsException(
            "RAW AGGREGATE RESPONSE WITH PRIVATE DETAILS",
            [
                new SmtpFailedRecipientException(
                    SmtpStatusCode.MailboxBusy,
                    "private-first@example.com",
                    "RAW FIRST RECIPIENT RESPONSE"),
                new SmtpFailedRecipientException(
                    SmtpStatusCode.LocalErrorInProcessing,
                    "private-second@example.com",
                    "RAW SECOND RECIPIENT RESPONSE")
            ]));

        Assert.Equal(EmailDeliveryOutcome.TransientFailure, result.Outcome);
        Assert.Equal("TRANSPORT", result.FailureCategory);
        Assert.Equal("ACS_SMTP_RECIPIENTS_RETRYABLE", result.FailureCode);
    }

    [Fact]
    public async Task SendAsync_WhenAttachmentContentTypeIsMalformed_ReturnsPermanentValidationFailure()
    {
        var smtpWasCalled = false;
        var smtpClient = new StubSmtpClient((_, _) =>
        {
            smtpWasCalled = true;
            return Task.CompletedTask;
        });
        var envelope = CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1(
                    "hello.txt",
                    "not a mime type",
                    HelloSha256,
                    "aGVsbG8=")
            ]
        };

        var result = await CreateClient(smtpClient).SendAsync(envelope);

        Assert.False(smtpWasCalled);
        Assert.Equal(EmailDeliveryOutcome.PermanentFailure, result.Outcome);
        Assert.Equal("VALIDATION", result.FailureCategory);
        Assert.Equal("EMAIL_ENVELOPE_INVALID", result.FailureCode);
    }

    [Fact]
    public async Task SendAsync_ClassifiesLocalValidationAndAttachmentIntegrityWithoutCallingSmtp()
    {
        var smtpClient = new StubSmtpClient((_, _) =>
            throw new InvalidOperationException("SMTP must not be called."));
        var invalidEnvelope = CreateEnvelope() with { SenderAddress = "private-invalid-address" };
        var validation = await CreateClient(smtpClient).SendAsync(invalidEnvelope);
        var malformedAttachment = CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1(
                    "private-file.txt",
                    "text/plain",
                    new string('0', 64),
                    "private-not-base64")
            ]
        };
        var integrity = await CreateClient(smtpClient).SendAsync(malformedAttachment);

        Assert.Equal(EmailDeliveryOutcome.PermanentFailure, validation.Outcome);
        Assert.Equal("VALIDATION", validation.FailureCategory);
        Assert.Equal(EmailDeliveryOutcome.PermanentFailure, integrity.Outcome);
        Assert.Equal("INTEGRITY", integrity.FailureCategory);
    }

    [Fact]
    public async Task SendAsync_DisposesMappedMessageAfterSmtpAttempt()
    {
        Stream? attachmentStream = null;
        var smtpClient = new StubSmtpClient((message, _) =>
        {
            attachmentStream = message.Attachments.Single().ContentStream;
            return Task.CompletedTask;
        });
        var envelope = CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1("hello.txt", "text/plain", HelloSha256, "aGVsbG8=")
            ]
        };

        await CreateClient(smtpClient).SendAsync(envelope);

        Assert.NotNull(attachmentStream);
        Assert.Throws<ObjectDisposedException>(() => attachmentStream.ReadByte());
    }

    [Fact]
    public async Task SendAsync_DoesNotLogEnvelopeValuesOrRawSmtpFailureDetails()
    {
        var logger = new CapturingLogger<AcsEmailDeliveryClient>();
        var envelope = CreateEnvelope();
        var smtpClient = new StubSmtpClient((_, _) => Task.FromException(
            new SmtpException(
                SmtpStatusCode.MailboxUnavailable,
                "RAW PROVIDER RESPONSE WITH PRIVATE DETAILS")));

        var result = await CreateClient(smtpClient, logger).SendAsync(envelope);

        var captured = string.Join(Environment.NewLine, logger.Entries);
        Assert.All(logger.ExceptionArguments, Assert.Null);
        foreach (var privateValue in new[]
                 {
                     envelope.BusinessCorrelationId,
                     envelope.SenderAddress,
                     envelope.To[0].Address,
                     envelope.Subject,
                     envelope.HtmlBody!,
                     envelope.PlainTextBody!,
                     "RAW PROVIDER RESPONSE WITH PRIVATE DETAILS"
                 })
        {
            Assert.DoesNotContain(privateValue, captured, StringComparison.Ordinal);
            Assert.DoesNotContain(privateValue, result.FailureDescription, StringComparison.Ordinal);
        }
    }

    [Fact]
    public async Task SendAsync_AllowsOperationCanceledExceptionToEscape()
    {
        var smtpClient = new StubSmtpClient((_, cancellationToken) =>
            Task.FromCanceled(cancellationToken));
        using var cancellationSource = new CancellationTokenSource();
        cancellationSource.Cancel();

        await Assert.ThrowsAsync<TaskCanceledException>(() => CreateClient(smtpClient).SendAsync(
            CreateEnvelope(),
            cancellationSource.Token));
    }

    private static async Task<EmailDeliveryResult> SendExceptionAsync(Exception exception)
    {
        var smtpClient = new StubSmtpClient((_, _) => Task.FromException(exception));
        return await CreateClient(smtpClient).SendAsync(CreateEnvelope());
    }

    private static AcsEmailDeliveryClient CreateClient(
        IAcsSmtpClient smtpClient,
        ILogger<AcsEmailDeliveryClient>? logger = null) => new(
        new AcsEmailMessageMapper(
            new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator())),
        smtpClient,
        logger ?? new CapturingLogger<AcsEmailDeliveryClient>());

    private static EmailEnvelopeV1 CreateEnvelope() => new(
        1,
        Guid.Parse("11111111-1111-1111-1111-111111111111"),
        "private-correlation",
        "private-sender@example.com",
        [new EmailMailbox("private-recipient@example.com", "Private Recipient")],
        [],
        [],
        [],
        "Private subject",
        "<p>Private HTML</p>",
        "Private plain text",
        []);

    private sealed class StubSmtpClient(
        Func<MailMessage, CancellationToken, Task> send)
        : IAcsSmtpClient
    {
        public Task SendAsync(
            MailMessage message,
            CancellationToken cancellationToken) => send(message, cancellationToken);
    }

    private sealed class CapturingLogger<T> : ILogger<T>
    {
        public List<string> Entries { get; } = [];
        public List<Exception?> ExceptionArguments { get; } = [];

        public IDisposable? BeginScope<TState>(TState state)
            where TState : notnull => null;

        public bool IsEnabled(LogLevel logLevel) => true;

        public void Log<TState>(
            LogLevel logLevel,
            EventId eventId,
            TState state,
            Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            Entries.Add(formatter(state, exception));
            ExceptionArguments.Add(exception);
        }
    }
}
