using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class EmailEnvelopeValidatorTests
{
    private const int MaximumSmtpMessageSize = 10_000_000;
    private const string HelloSha256 =
        "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824";

    private readonly AcsSmtpMessageSizeCalculator _sizeCalculator = new();

    [Fact]
    public void Validate_AcceptsCombinedRecipientCountOfFifty()
    {
        var envelope = CreateEnvelope() with
        {
            To = Enumerable.Range(1, 20)
                .Select(number => new EmailMailbox($"to{number}@example.com", null))
                .ToArray(),
            Cc = Enumerable.Range(1, 20)
                .Select(number => new EmailMailbox($"cc{number}@example.com", null))
                .ToArray(),
            Bcc = Enumerable.Range(1, 10)
                .Select(number => new EmailMailbox($"bcc{number}@example.com", null))
                .ToArray()
        };

        CreateValidator().Validate(envelope);
    }

    [Fact]
    public void Validate_RejectsCombinedRecipientCountOfFiftyOne()
    {
        var envelope = CreateEnvelope() with
        {
            To = Enumerable.Range(1, 21)
                .Select(number => new EmailMailbox($"to{number}@example.com", null))
                .ToArray(),
            Cc = Enumerable.Range(1, 20)
                .Select(number => new EmailMailbox($"cc{number}@example.com", null))
                .ToArray(),
            Bcc = Enumerable.Range(1, 10)
                .Select(number => new EmailMailbox($"bcc{number}@example.com", null))
                .ToArray()
        };

        Assert.Throws<ArgumentException>(() => CreateValidator().Validate(envelope));
    }

    [Fact]
    public void Validate_RejectsEmptyNotificationId() => AssertInvalid(
        CreateEnvelope() with { NotificationId = Guid.Empty });

    [Fact]
    public void Validate_RejectsBlankBusinessCorrelationId() => AssertInvalid(
        CreateEnvelope() with { BusinessCorrelationId = " " });

    [Fact]
    public void Validate_RejectsBlankSenderAddress() => AssertInvalid(
        CreateEnvelope() with { SenderAddress = " " });

    [Fact]
    public void Validate_RejectsBlankSubject() => AssertInvalid(
        CreateEnvelope() with { Subject = " " });

    [Fact]
    public void Validate_RejectsMissingHtmlAndPlainTextBodies() => AssertInvalid(
        CreateEnvelope() with { HtmlBody = null, PlainTextBody = " " });

    [Fact]
    public void Validate_RejectsMissingPrimaryRecipient() => AssertInvalid(
        CreateEnvelope() with { To = [], Cc = [], Bcc = [] });

    [Theory]
    [InlineData("sender")]
    [InlineData("Display Name <sender@example.com>")]
    [InlineData(" sender@example.com ")]
    public void Validate_RejectsInvalidOrNonCanonicalSenderAddress(string address) => AssertInvalid(
        CreateEnvelope() with { SenderAddress = address });

    [Fact]
    public void Validate_RejectsInvalidRecipientAddress() => AssertInvalid(
        CreateEnvelope() with { ReplyTo = [new EmailMailbox("not-an-address", "Reply")] });

    [Fact]
    public void Validate_RejectsInvalidBase64Attachment() => AssertInvalid(
        CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1("hello.txt", "text/plain", HelloSha256, "not-base64")
            ]
        });

    [Fact]
    public void Validate_RejectsMalformedAttachmentContentType() => AssertInvalid(
        CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1(
                    "hello.txt",
                    "not a mime type",
                    HelloSha256,
                    "aGVsbG8=")
            ]
        });

    [Fact]
    public void Validate_RejectsAttachmentSha256Mismatch() => AssertInvalid(
        CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1(
                    "hello.txt",
                    "text/plain",
                    new string('0', 64),
                    "aGVsbG8=")
            ]
        });

    [Fact]
    public void Validate_RejectsNonLowercaseAttachmentSha256() => AssertInvalid(
        CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1(
                    "hello.txt",
                    "text/plain",
                    HelloSha256.ToUpperInvariant(),
                    "aGVsbG8=")
            ]
        });

    [Fact]
    public void Validate_RejectsNullAttachmentSha256WithControlledValidationFailure() =>
        AssertInvalid(
            CreateEnvelope() with
            {
                Attachments =
                [
                    new EmailAttachmentV1(
                        "hello.txt",
                        "text/plain",
                        null!,
                        "aGVsbG8=")
                ]
            });

    [Fact]
    public void CalculateUpperBoundByteCount_DoesNotMaterialiseTheBase64EncodedBody()
    {
        var envelope = CreateEnvelope() with
        {
            HtmlBody = null,
            PlainTextBody = new string('a', 1024 * 1024),
            ReplyTo = [],
            Attachments = []
        };

        _sizeCalculator.CalculateUpperBoundByteCount(envelope);
        var allocatedBefore = GC.GetAllocatedBytesForCurrentThread();

        var estimatedSize = _sizeCalculator.CalculateUpperBoundByteCount(envelope);
        var allocatedBytes = GC.GetAllocatedBytesForCurrentThread() - allocatedBefore;

        Assert.True(estimatedSize > envelope.PlainTextBody.Length);
        Assert.InRange(allocatedBytes, 0, 64 * 1024);
    }

    [Fact]
    public void Validate_AcceptsSevenMillionByteAsciiBodyWithinEstimatedSmtpMimeLimit()
    {
        var envelope = CreateEnvelope() with
        {
            HtmlBody = null,
            PlainTextBody = new string('a', 7_000_000),
            ReplyTo = [],
            Attachments = []
        };

        CreateValidator().Validate(envelope);
        Assert.True(
            _sizeCalculator.CalculateUpperBoundByteCount(envelope)
            <= MaximumSmtpMessageSize);
    }

    [Fact]
    public void Validate_RejectsMessageAboveDocumentedTenMegabyteLimit()
    {
        var envelope = CreateEnvelope() with
        {
            HtmlBody = null,
            PlainTextBody = new string('a', 7_300_000),
            ReplyTo = [],
            Attachments = []
        };

        Assert.True(
            _sizeCalculator.CalculateUpperBoundByteCount(envelope)
            > MaximumSmtpMessageSize);
        Assert.Throws<ArgumentException>(() => CreateValidator().Validate(envelope));
    }

    [Fact]
    public void Validate_RejectsEightMebibyteAsciiBodyWhenSmtpMimeEncodingExceedsTenMebibytes()
    {
        var envelope = CreateEnvelope() with
        {
            HtmlBody = null,
            PlainTextBody = new string('a', 8 * 1024 * 1024),
            ReplyTo = [],
            Attachments = []
        };

        Assert.True(
            _sizeCalculator.CalculateUpperBoundByteCount(envelope)
            > MaximumSmtpMessageSize);
        Assert.Throws<ArgumentException>(() => CreateValidator().Validate(envelope));
    }

    private EmailEnvelopeValidator CreateValidator() => new(_sizeCalculator);

    private void AssertInvalid(EmailEnvelopeV1 envelope) =>
        Assert.Throws<ArgumentException>(() => CreateValidator().Validate(envelope));

    private static EmailEnvelopeV1 CreateEnvelope() => new(
        1,
        Guid.Parse("11111111-1111-1111-1111-111111111111"),
        "corr-123",
        "sender@example.com",
        [new EmailMailbox("to@example.com", "To User")],
        [],
        [],
        [new EmailMailbox("reply@example.com", "Reply User")],
        "Subject",
        "<p>Hello</p>",
        "Hello",
        [new EmailAttachmentV1("hello.txt", "text/plain", HelloSha256, "aGVsbG8=")]);
}
