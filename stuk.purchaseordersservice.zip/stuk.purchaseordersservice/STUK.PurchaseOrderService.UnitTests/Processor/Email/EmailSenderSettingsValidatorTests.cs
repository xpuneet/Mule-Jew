using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Email.Configuration;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class EmailSenderSettingsValidatorTests
{
    private readonly EmailSenderSettingsValidator _validator = new();

    [Fact]
    public void Validate_WhenSendingIsDisabled_AllowsBlankProviderSettingsAndZeroRates()
    {
        var settings = new EmailSenderSettings
        {
            SendingEnabled = false,
            Smtp = new EmailSmtpSettings(),
            DefaultSenderAddress = string.Empty,
            RateLimit = new EmailRateLimitSettings()
        };

        Assert.True(_validator.Validate(null, settings).Succeeded);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_AcceptsCoherentSettings()
    {
        Assert.True(_validator.Validate(null, CreateValidEnabledSettings()).Succeeded);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsNonAcsSmtpHost()
    {
        var settings = CreateValidEnabledSettings() with
        {
            Smtp = CreateValidEnabledSettings().Smtp with { Host = "smtp.example.com" }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsNonSubmissionPort()
    {
        var settings = CreateValidEnabledSettings() with
        {
            Smtp = CreateValidEnabledSettings().Smtp with { Port = 25 }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsBlankSmtpHost()
    {
        var settings = CreateValidEnabledSettings() with
        {
            Smtp = CreateValidEnabledSettings().Smtp with { Host = string.Empty }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(65536)]
    public void Validate_WhenSendingIsEnabled_RejectsSmtpPortOutsideTcpRange(int port)
    {
        var settings = CreateValidEnabledSettings() with
        {
            Smtp = CreateValidEnabledSettings().Smtp with { Port = port }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsDisabledStartTls()
    {
        var settings = CreateValidEnabledSettings() with
        {
            Smtp = CreateValidEnabledSettings().Smtp with { UseStartTls = false }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Theory]
    [InlineData("Username")]
    [InlineData("Password")]
    public void Validate_WhenSendingIsEnabled_RejectsBlankSmtpCredential(string settingName)
    {
        var smtp = CreateValidEnabledSettings().Smtp;
        var settings = CreateValidEnabledSettings() with
        {
            Smtp = settingName switch
            {
                "Username" => smtp with { Username = string.Empty },
                "Password" => smtp with { Password = string.Empty },
                _ => throw new ArgumentOutOfRangeException(nameof(settingName))
            }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsInvalidSenderAddress()
    {
        var settings = CreateValidEnabledSettings() with { DefaultSenderAddress = "sender" };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsNonPositiveMinuteRateLimit()
    {
        var settings = CreateValidEnabledSettings() with
        {
            RateLimit = new EmailRateLimitSettings
            {
                MaxAttemptsPerMinute = 0,
                MaxAttemptsPerHour = 120
            }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsNonPositiveHourRateLimit()
    {
        var settings = CreateValidEnabledSettings() with
        {
            RateLimit = new EmailRateLimitSettings
            {
                MaxAttemptsPerMinute = 10,
                MaxAttemptsPerHour = 0
            }
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Theory]
    [InlineData("ClaimBatchSize", 0)]
    [InlineData("ClaimBatchSize", 101)]
    [InlineData("MaxConcurrency", 0)]
    [InlineData("MaxConcurrency", 21)]
    [InlineData("MaxFailureCount", 0)]
    [InlineData("MaxFailureCount", 21)]
    public void Validate_WhenSendingIsEnabled_RejectsBoundedValuesOutsideRange(
        string settingName,
        int value)
    {
        var settings = settingName switch
        {
            "ClaimBatchSize" => CreateValidEnabledSettings() with { ClaimBatchSize = value },
            "MaxConcurrency" => CreateValidEnabledSettings() with { MaxConcurrency = value },
            "MaxFailureCount" => CreateValidEnabledSettings() with { MaxFailureCount = value },
            _ => throw new ArgumentOutOfRangeException(nameof(settingName))
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsLeaseWithoutProviderAndCompletionMargin()
    {
        var settings = CreateValidEnabledSettings() with { LeaseDurationSeconds = 40 };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsRunWithoutProviderAndCompletionMargin()
    {
        var settings = CreateValidEnabledSettings() with { MaxRunDurationSeconds = 40 };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsOutcomePersistenceTimeoutAboveCompletionMargin()
    {
        var settings = CreateValidEnabledSettings() with
        {
            OutcomePersistenceTimeoutSeconds = 11
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Theory]
    [InlineData("InitialRetryDelaySeconds")]
    [InlineData("MaxRetryDelaySeconds")]
    [InlineData("RetryJitterSeconds")]
    [InlineData("ThrottleFallbackDelaySeconds")]
    public void Validate_WhenSendingIsEnabled_RejectsDelayAboveOneHour(string settingName)
    {
        var settings = settingName switch
        {
            "InitialRetryDelaySeconds" => CreateValidEnabledSettings() with
            {
                InitialRetryDelaySeconds = 3601
            },
            "MaxRetryDelaySeconds" => CreateValidEnabledSettings() with
            {
                MaxRetryDelaySeconds = 3601
            },
            "RetryJitterSeconds" => CreateValidEnabledSettings() with
            {
                RetryJitterSeconds = 3601
            },
            "ThrottleFallbackDelaySeconds" => CreateValidEnabledSettings() with
            {
                ThrottleFallbackDelaySeconds = 3601
            },
            _ => throw new ArgumentOutOfRangeException(nameof(settingName))
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_WhenSendingIsEnabled_RejectsInitialRetryDelayAboveMaximum()
    {
        var settings = CreateValidEnabledSettings() with
        {
            InitialRetryDelaySeconds = 61,
            MaxRetryDelaySeconds = 60
        };

        Assert.True(_validator.Validate(null, settings).Failed);
    }

    [Theory]
    [InlineData("0 */1 * * * *", true)]
    [InlineData("0 60 * * * *", false)]
    [InlineData("0 nope * * * *", false)]
    [InlineData("*/1 * * * *", false)]
    public void EmailNotificationScheduleSettingsValidator_UsesSixFieldNcrontabParsing(
        string expression,
        bool expectedSuccess)
    {
        var validator = new EmailNotificationScheduleSettingsValidator();

        var result = validator.Validate(
            null,
            new EmailNotificationScheduleSettings { CronExpression = expression });

        Assert.Equal(expectedSuccess, result.Succeeded);
    }

    private static EmailSenderSettings CreateValidEnabledSettings() => new()
    {
        SendingEnabled = true,
        Smtp = new EmailSmtpSettings
        {
            Host = "smtp.azurecomm.net",
            Port = 587,
            UseStartTls = true,
            Username = "test-username",
            Password = "test-password"
        },
        DefaultSenderAddress = "sender@example.com",
        ClaimBatchSize = 10,
        MaxConcurrency = 4,
        LeaseDurationSeconds = 120,
        MaxRunDurationSeconds = 50,
        ProviderOperationTimeoutSeconds = 30,
        CompletionSafetyMarginSeconds = 10,
        OutcomePersistenceTimeoutSeconds = 10,
        MaxFailureCount = 8,
        InitialRetryDelaySeconds = 60,
        MaxRetryDelaySeconds = 3600,
        RetryJitterSeconds = 10,
        ThrottleFallbackDelaySeconds = 60,
        RateLimit = new EmailRateLimitSettings
        {
            MaxAttemptsPerMinute = 10,
            MaxAttemptsPerHour = 120
        }
    };
}
