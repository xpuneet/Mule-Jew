using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Email.Processing;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class EmailRetryDelayCalculatorTests
{
    [Fact]
    public void Calculate_AppliesExponentialDelayAndSymmetricInjectedJitter()
    {
        var jitter = new FixedJitterProvider(7);
        var calculator = CreateCalculator(
            new EmailSenderSettings
            {
                InitialRetryDelaySeconds = 60,
                MaxRetryDelaySeconds = 3600,
                RetryJitterSeconds = 10
            },
            jitter);

        var delay = calculator.Calculate(3);

        Assert.Equal(TimeSpan.FromSeconds(247), delay);
        Assert.Equal((-10, 10), jitter.LastRange);
    }

    [Theory]
    [InlineData(60, 3600, 10, 20, -10, 3600)]
    [InlineData(5, 3600, 10, 1, -10, 0)]
    [InlineData(1, 3600, 10, int.MaxValue, 10, 3600)]
    public void Calculate_ClampsAfterJitterWithoutOverflow(
        int initialSeconds,
        int maximumSeconds,
        int jitterSeconds,
        int nextFailureCount,
        int jitter,
        int expectedSeconds)
    {
        var calculator = CreateCalculator(
            new EmailSenderSettings
            {
                InitialRetryDelaySeconds = initialSeconds,
                MaxRetryDelaySeconds = maximumSeconds,
                RetryJitterSeconds = jitterSeconds
            },
            new FixedJitterProvider(jitter));

        var delay = calculator.Calculate(nextFailureCount);

        Assert.Equal(TimeSpan.FromSeconds(expectedSeconds), delay);
    }

    [Fact]
    public void Calculate_RejectsNonPositiveFailureCount()
    {
        var calculator = CreateCalculator(
            new EmailSenderSettings(),
            new FixedJitterProvider(0));

        Assert.Throws<ArgumentOutOfRangeException>(() => calculator.Calculate(0));
    }

    [Fact]
    public void Calculate_WithZeroInitialDelayHandlesMaximumFailureCountWithoutLoopingOrOverflow()
    {
        var calculator = CreateCalculator(
            new EmailSenderSettings
            {
                InitialRetryDelaySeconds = 0,
                MaxRetryDelaySeconds = 3600,
                RetryJitterSeconds = 0
            },
            new FixedJitterProvider(0));

        var delay = calculator.Calculate(int.MaxValue);

        Assert.Equal(TimeSpan.Zero, delay);
    }

    private static EmailRetryDelayCalculator CreateCalculator(
        EmailSenderSettings settings,
        IEmailJitterProvider jitterProvider) => new(
        new StaticOptionsMonitor<EmailSenderSettings>(settings),
        jitterProvider);

    private sealed class FixedJitterProvider(int value) : IEmailJitterProvider
    {
        public (int Minimum, int Maximum)? LastRange { get; private set; }

        public int NextInclusive(int minimum, int maximum)
        {
            LastRange = (minimum, maximum);
            Assert.InRange(value, minimum, maximum);
            return value;
        }
    }

    private sealed class StaticOptionsMonitor<TOptions>(TOptions value)
        : IOptionsMonitor<TOptions>
    {
        public TOptions CurrentValue => value;

        public TOptions Get(string? name) => value;

        public IDisposable? OnChange(
            Action<TOptions, string?> listener) => null;
    }
}
