using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Outbox;
using STUK.PurchaseOrderService.Processor.Email.Relex;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class RelexNotificationProducerTests
{
    private static readonly DateTimeOffset Now = DateTimeOffset.Parse("2026-09-24T09:35:00Z");

    [Fact]
    public async Task ProcessAsync_DisabledDoesNotTouchDatabase()
    {
        var fixture = new Fixture();
        fixture.Settings.CurrentValue.ResultsEnabled = false;
        fixture.Settings.CurrentValue.MissingProposalEnabled = false;
        var result = await fixture.Create().ProcessAsync();
        Assert.Equal(new RelexNotificationProducerResult(0, 0, 0), result);
        fixture.Events.VerifyNoOtherCalls();
        fixture.Deliveries.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task ProcessAsync_RejectsInvalidReloadedSenderBeforePreparingDurableEvents()
    {
        var fixture = new Fixture();
        fixture.Sender.CurrentValue = new EmailSenderSettings();
        await Assert.ThrowsAsync<OptionsValidationException>(() => fixture.Create().ProcessAsync());
        fixture.Events.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task ProcessAsync_DoesNotStartClaimedWorkAfterRunDeadline()
    {
        var fixture = new Fixture();
        fixture.Claim([Event()], _ => fixture.Clock.UtcNow = Now.AddSeconds(51));
        var result = await fixture.Create().ProcessAsync();
        Assert.Equal(new RelexNotificationProducerResult(1, 0, 0), result);
        fixture.Events.Verify(x => x.SaveEnvelopeAsync(It.IsAny<SaveRelexNotificationEnvelopeCommand>(),
            It.IsAny<CancellationToken>()), Times.Never);
        fixture.Events.Verify(x => x.CompleteAsync(It.IsAny<CompleteRelexNotificationEventCommand>(),
            It.IsAny<CancellationToken>()), Times.Never);
        fixture.Deliveries.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task ProcessAsync_FreezesConfigurationAndPassesStableCutoffInsteadOfPollTime()
    {
        var fixture = new Fixture();
        PrepareRelexNotificationEventsCommand? saved = null;
        fixture.Claim([], command => saved = command);
        await fixture.Create().ProcessAsync();
        Assert.NotNull(saved);
        Assert.Equal(Now, saved.AsOfDateTime);
        Assert.Equal(DateTimeOffset.Parse("2026-09-24T09:30:00Z"), saved.MissingCutoffDateTime);
        Assert.Equal(DateTimeOffset.Parse("2026-09-24T03:30:00Z"), saved.MissingFreshSinceDateTime);
        Assert.Equal("RELEX_MISSING:2026-09-24", saved.MissingEventKey);
        Assert.Equal(fixture.Settings.CurrentValue.ResultsNotBeforeUtc, saved.ResultsNotBeforeDateTime);
        var snapshot = JsonSerializer.Deserialize<RelexEmailCompositionSnapshot>(saved.CompositionSettingsJson,
            new JsonSerializerOptions(JsonSerializerDefaults.Web))!;
        Assert.Equal("dev", snapshot.EnvironmentName);
        Assert.Equal(["new-team@example.com"], snapshot.Recipients);
        Assert.Equal("new-sender@example.com", snapshot.SenderAddress);
    }

    [Fact]
    public async Task ProcessAsync_SavesEnvelopeBeforeOutboxAndCompletesOnlyAfterEnqueue()
    {
        var fixture = new Fixture();
        var notification = Event();
        fixture.Claim([notification]);
        fixture.SaveEnvelope();
        fixture.Enqueue();
        fixture.Complete();

        var result = await fixture.Create().ProcessAsync();

        Assert.Equal(new RelexNotificationProducerResult(1, 1, 0), result);
        Assert.Equal(["save", "enqueue", "complete"], fixture.Operations);
        var persisted = Assert.Single(fixture.Enqueued);
        var envelope = fixture.Serializer.Deserialize(persisted.EmailEnvelopeJson);
        Assert.Equal(notification.NotificationId, envelope.NotificationId);
        Assert.Equal("original-sender@example.com", envelope.SenderAddress);
        Assert.Equal("old-team@example.com", envelope.To.Single().Address);
        Assert.Equal(notification.CreatedDateTime, persisted.CreatedDateTime);
        Assert.Equal("relex-missing-v1", persisted.TemplateKey);
        Assert.True(Assert.Single(fixture.Completed).Enqueued);
    }

    [Fact]
    public async Task ProcessAsync_ReplayAfterCompletionFailureReusesExactEnvelopeAndIdentity()
    {
        var fixture = new Fixture();
        var notification = Event();
        string? saved = null;
        fixture.Claim([notification]);
        fixture.SaveEnvelope(command => saved = command.EmailEnvelopeJson);
        fixture.Enqueue();
        fixture.Events.Setup(x => x.CompleteAsync(It.IsAny<CompleteRelexNotificationEventCommand>(),
                It.IsAny<CancellationToken>())).ThrowsAsync(new IOException("Database unavailable"));
        var first = await fixture.Create().ProcessAsync();
        Assert.Equal(1, first.FailedCount);
        Assert.NotNull(saved);
        fixture.Claim([notification with { EmailEnvelopeJson = saved, CompositionSettingsJson = "invalid" }]);
        fixture.Complete();
        var second = await fixture.Create().ProcessAsync();
        Assert.Equal(1, second.EnqueuedCount);
        Assert.Equal(2, fixture.Enqueued.Count);
        Assert.Equal(fixture.Enqueued[0], fixture.Enqueued[1]);
        fixture.Events.Verify(x => x.SaveEnvelopeAsync(It.IsAny<SaveRelexNotificationEnvelopeCommand>(),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task ProcessAsync_UsesFirstPersistedEnvelopeReturnedBySave()
    {
        var fixture = new Fixture();
        var notification = Event();
        var frozen = "\n" + fixture.Serializer.Serialize(new RelexEmailComposer().Compose(notification)) + "\n";
        fixture.Claim([notification]);
        fixture.Events.Setup(x => x.SaveEnvelopeAsync(It.IsAny<SaveRelexNotificationEnvelopeCommand>(),
                It.IsAny<CancellationToken>())).ReturnsAsync(frozen);
        fixture.Enqueue();
        fixture.Complete();
        await fixture.Create().ProcessAsync();
        Assert.Equal(frozen, Assert.Single(fixture.Enqueued).EmailEnvelopeJson);
    }

    [Fact]
    public async Task ProcessAsync_PermanentBadSnapshotDoesNotBlockOtherNotifications()
    {
        var fixture = new Fixture();
        fixture.Claim([Event() with { CompositionSettingsJson = "bad-json" }, Event()]);
        fixture.SaveEnvelope();
        fixture.Enqueue();
        fixture.Complete();
        var result = await fixture.Create().ProcessAsync();
        Assert.Equal(new RelexNotificationProducerResult(2, 1, 1), result);
        Assert.True(fixture.Completed[0].PermanentFailure);
        Assert.Equal("INVALID_RELEX_SNAPSHOT", fixture.Completed[0].FailureCode);
        Assert.True(fixture.Completed[1].Enqueued);
    }

    [Fact]
    public async Task ProcessAsync_TransientOutboxFailureSchedulesRetryWithoutReplacingEnvelope()
    {
        var fixture = new Fixture();
        fixture.Claim([Event()]);
        fixture.SaveEnvelope();
        fixture.Deliveries.Setup(x => x.EnqueueEmailNotificationAsync(
                It.IsAny<EnqueuePurchaseOrderEmailNotificationCommand>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new IOException("Private database details must not be logged"));
        fixture.Complete();
        var result = await fixture.Create().ProcessAsync();
        var failure = Assert.Single(fixture.Completed);
        Assert.Equal(1, result.FailedCount);
        Assert.False(failure.PermanentFailure);
        Assert.Equal(Now.AddSeconds(60), failure.NextAttemptDateTime);
        Assert.Equal("RELEX_PRODUCER_PERSISTENCE_FAILED", failure.FailureCode);
    }

    [Fact]
    public async Task ProcessAsync_SnapshotWithDifferentIdentityIsNeverEnqueued()
    {
        var fixture = new Fixture();
        var wrong = fixture.Serializer.Serialize(new RelexEmailComposer().Compose(Event()));
        fixture.Claim([Event() with { EmailEnvelopeJson = wrong }]);
        fixture.Complete();
        await fixture.Create().ProcessAsync();
        Assert.True(Assert.Single(fixture.Completed).PermanentFailure);
        fixture.Deliveries.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task ProcessAsync_CancellationLeavesLeaseForRecoveryWithoutIncrementingFailures()
    {
        var fixture = new Fixture();
        using var cancellation = new CancellationTokenSource();
        fixture.Claim([Event()]);
        fixture.Events.Setup(x => x.SaveEnvelopeAsync(It.IsAny<SaveRelexNotificationEnvelopeCommand>(),
                It.IsAny<CancellationToken>())).Returns((SaveRelexNotificationEnvelopeCommand _, CancellationToken token) =>
            {
                cancellation.Cancel();
                token.ThrowIfCancellationRequested();
                return Task.FromResult("");
            });
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => fixture.Create().ProcessAsync(cancellation.Token));
        fixture.Events.Verify(x => x.CompleteAsync(It.IsAny<CompleteRelexNotificationEventCommand>(),
            It.IsAny<CancellationToken>()), Times.Never);
        fixture.Deliveries.VerifyNoOtherCalls();
    }

    private static RelexNotificationEvent Event() => new(Guid.NewGuid(), null, "RELEX_MISSING",
        "RELEX_MISSING:2026-09-24", null, Now.AddMinutes(-5),
        """{"schemaVersion":1,"environmentName":"prod","recipients":["old-team@example.com"],"senderAddress":"original-sender@example.com"}""",
        "[]", null, Guid.NewGuid(), 0);

    private sealed class Fixture
    {
        public Mock<IRelexNotificationRepository> Events { get; } = new(MockBehavior.Strict);
        public Mock<IPurchaseOrderNotificationRepository> Deliveries { get; } = new(MockBehavior.Strict);
        public Monitor<RelexNotificationSettings> Settings { get; } = new(new()
        {
            ResultsEnabled = true, MissingProposalEnabled = true, EnvironmentName = "dev",
            Recipients = "new-team@example.com", ResultsNotBeforeUtc = Now.AddDays(-1)
        });
        public List<string> Operations { get; } = [];
        public List<EnqueuePurchaseOrderEmailNotificationCommand> Enqueued { get; } = [];
        public List<CompleteRelexNotificationEventCommand> Completed { get; } = [];
        public EmailEnvelopeSerializer Serializer { get; } = new(new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator()));
        public Monitor<EmailSenderSettings> Sender { get; } = new(new() { DefaultSenderAddress = "new-sender@example.com" });
        public FixedClock Clock { get; } = new();

        public void Claim(IReadOnlyList<RelexNotificationEvent> events,
            Action<PrepareRelexNotificationEventsCommand>? callback = null) =>
            Events.Setup(x => x.PrepareAndClaimAsync(It.IsAny<PrepareRelexNotificationEventsCommand>(),
                    It.IsAny<CancellationToken>()))
                .Callback((PrepareRelexNotificationEventsCommand command, CancellationToken _) => callback?.Invoke(command))
                .ReturnsAsync(events);

        public void SaveEnvelope(Action<SaveRelexNotificationEnvelopeCommand>? callback = null) =>
            Events.Setup(x => x.SaveEnvelopeAsync(It.IsAny<SaveRelexNotificationEnvelopeCommand>(), It.IsAny<CancellationToken>()))
                .Returns((SaveRelexNotificationEnvelopeCommand command, CancellationToken _) =>
                {
                    Operations.Add("save");
                    callback?.Invoke(command);
                    return Task.FromResult(command.EmailEnvelopeJson);
                });

        public void Enqueue() => Deliveries.Setup(x => x.EnqueueEmailNotificationAsync(
                It.IsAny<EnqueuePurchaseOrderEmailNotificationCommand>(), It.IsAny<CancellationToken>()))
            .Returns((EnqueuePurchaseOrderEmailNotificationCommand command, CancellationToken _) =>
            {
                Operations.Add("enqueue");
                Enqueued.Add(command);
                return Task.FromResult(new EnqueuedPurchaseOrderEmailNotification(command.NotificationId,
                    "PENDING", Now, 0, 0, 0, SHA256.HashData(Encoding.Unicode.GetBytes(command.EmailEnvelopeJson)), []));
            });

        public void Complete() => Events.Setup(x => x.CompleteAsync(It.IsAny<CompleteRelexNotificationEventCommand>(),
                It.IsAny<CancellationToken>())).Callback((CompleteRelexNotificationEventCommand command, CancellationToken _) =>
            {
                Operations.Add("complete");
                Completed.Add(command);
            }).Returns(Task.CompletedTask);

        public RelexNotificationProducer Create()
        {
            var validator = new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator());
            return new(Events.Object, new RelexEmailComposer(), Serializer, validator,
                new EmailNotificationOutbox(Deliveries.Object, validator, Serializer, Sender), Settings,
                Sender, Clock, NullLogger<RelexNotificationProducer>.Instance);
        }
    }

    private sealed class FixedClock : TimeProvider
    {
        public DateTimeOffset UtcNow { get; set; } = Now;
        public override DateTimeOffset GetUtcNow() => UtcNow;
    }
    private sealed class Monitor<T>(T value) : IOptionsMonitor<T>
    {
        public T CurrentValue { get; set; } = value;
        public T Get(string? name) => CurrentValue;
        public IDisposable? OnChange(Action<T, string?> listener) => null;
    }
}
