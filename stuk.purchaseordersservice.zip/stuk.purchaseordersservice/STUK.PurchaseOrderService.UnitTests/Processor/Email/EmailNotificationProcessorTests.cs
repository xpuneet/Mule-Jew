using System.Collections.Concurrent;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Delivery;
using STUK.PurchaseOrderService.Processor.Email.Processing;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class EmailNotificationProcessorTests
{
    private static readonly DateTimeOffset FixedNow =
        new(2026, 9, 18, 10, 0, 0, TimeSpan.Zero);

    [Fact]
    public async Task ProcessAsync_WhenDisabledMakesNoRepositoryOrProviderCalls()
    {
        var repository = new RecordingRepository();
        var delivery = new RecordingDeliveryClient();
        var settings = CreateSettings() with { SendingEnabled = false };

        var result = await CreateProcessor(repository, delivery, settings).ProcessAsync();

        Assert.Equal(ZeroSummary, result.QueueSummary);
        Assert.Equal(0, result.ClaimedCount);
        Assert.Equal(0, repository.TotalCalls);
        Assert.Equal(0, delivery.CallCount);
    }

    [Fact]
    public async Task ProcessAsync_WhenClaimIsEmptyReturnsQueueSummaryAfterNormalStop()
    {
        var repository = new RecordingRepository { Summary = Summary };
        repository.ClaimResults.Enqueue([]);
        var logger = new CapturingLogger<EmailNotificationProcessor>();

        var result = await CreateProcessor(repository, logger: logger).ProcessAsync();

        Assert.Equal(Summary, result.QueueSummary);
        Assert.Single(repository.ClaimCommands);
        Assert.Equal(1, repository.SummaryCallCount);
        AssertQueueHealthLog(logger, Summary, expectedOldestPendingAgeSeconds: 300);
    }

    [Fact]
    public async Task ProcessAsync_DrainsSuccessiveBatchesUntilEmpty()
    {
        var repository = new RecordingRepository();
        repository.ClaimResults.Enqueue([CreateClaimed(1)]);
        repository.ClaimResults.Enqueue([CreateClaimed(2)]);
        repository.ClaimResults.Enqueue([CreateClaimed(3)]);
        repository.ClaimResults.Enqueue([]);
        var delivery = new RecordingDeliveryClient();
        var settings = CreateSettings() with
        {
            ClaimBatchSize = 1,
            MaxConcurrency = 1
        };

        var result = await CreateProcessor(repository, delivery, settings).ProcessAsync();

        Assert.Equal(3, result.ClaimedCount);
        Assert.Equal(3, result.SentCount);
        Assert.Equal(
            [NotificationId(1), NotificationId(2), NotificationId(3)],
            delivery.NotificationIds);
        Assert.Equal(4, repository.ClaimCommands.Count);
        Assert.Equal(1, repository.SummaryCallCount);
    }

    [Fact]
    public async Task ProcessAsync_ClaimsAtMostMinimumOfBatchSizeAndConcurrency()
    {
        var repository = new RecordingRepository();
        repository.ClaimResults.Enqueue([]);
        var settings = CreateSettings() with
        {
            ClaimBatchSize = 10,
            MaxConcurrency = 3
        };

        await CreateProcessor(repository, settings: settings).ProcessAsync();

        var command = Assert.Single(repository.ClaimCommands);
        Assert.Equal(3, command.MaxNotifications);
        Assert.Equal(settings.RateLimit.MaxAttemptsPerMinute, command.MaxAttemptsPerMinute);
        Assert.Equal(settings.RateLimit.MaxAttemptsPerHour, command.MaxAttemptsPerHour);
    }

    [Fact]
    public async Task ProcessAsync_BoundsParallelProviderCallsByConfiguredConcurrency()
    {
        var repository = new RecordingRepository();
        repository.ClaimResults.Enqueue(
            Enumerable.Range(1, 6).Select(number => CreateClaimed(number)).ToArray());
        repository.ClaimResults.Enqueue([]);
        var delivery = new RecordingDeliveryClient(async (_, cancellationToken) =>
        {
            await Task.Delay(50, cancellationToken);
            return Succeeded;
        });
        var settings = CreateSettings() with
        {
            ClaimBatchSize = 10,
            MaxConcurrency = 3
        };

        var result = await CreateProcessor(repository, delivery, settings).ProcessAsync();

        Assert.Equal(6, result.SentCount);
        Assert.InRange(delivery.MaximumActiveCalls, 2, 3);
    }

    [Fact]
    public async Task ProcessAsync_AtExactRunSafetyBoundaryDoesNotClaimAndReturnsSummary()
    {
        var repository = new RecordingRepository { Summary = Summary };
        var settings = CreateSettings();
        var logger = new CapturingLogger<EmailNotificationProcessor>();
        var timeProvider = new SequenceTimeProvider(
            FixedNow,
            FixedNow.AddSeconds(
                settings.MaxRunDurationSeconds
                - settings.ProviderOperationTimeoutSeconds
                - settings.CompletionSafetyMarginSeconds));

        var result = await CreateProcessor(
            repository,
            settings: settings,
            timeProvider: timeProvider,
            logger: logger).ProcessAsync();

        Assert.Empty(repository.ClaimCommands);
        Assert.Equal(1, repository.SummaryCallCount);
        Assert.Equal(Summary, result.QueueSummary);
        AssertQueueHealthLog(logger, Summary, expectedOldestPendingAgeSeconds: 310);
    }

    [Fact]
    public async Task ProcessAsync_AtExactLeaseSafetyBoundaryDefersWithoutProviderCallAndStopsClaiming()
    {
        var settings = CreateSettings();
        var safeTime = TimeSpan.FromSeconds(
            settings.ProviderOperationTimeoutSeconds
            + settings.CompletionSafetyMarginSeconds);
        var repository = new RecordingRepository();
        repository.ClaimResults.Enqueue([CreateClaimed(1, leaseExpiry: FixedNow + safeTime)]);
        repository.ClaimResults.Enqueue([CreateClaimed(2)]);
        var delivery = new RecordingDeliveryClient();

        var result = await CreateProcessor(repository, delivery, settings).ProcessAsync();

        var command = Assert.Single(repository.DeferCommands);
        Assert.Equal(FixedNow, command.NextAttemptDateTime);
        Assert.Equal(FixedNow, command.CompletedDateTime);
        Assert.Equal(1, result.DeferredCount);
        Assert.Equal(0, delivery.CallCount);
        Assert.Single(repository.ClaimCommands);
        Assert.Equal(1, repository.SummaryCallCount);
    }

    [Fact]
    public async Task ProcessAsync_WhenRunBecomesUnsafeAfterClaimDefersBeforeProviderCall()
    {
        var settings = CreateSettings();
        var repository = new RecordingRepository();
        repository.ClaimResults.Enqueue([CreateClaimed(1)]);
        var delivery = new RecordingDeliveryClient();
        var timeProvider = new SequenceTimeProvider(
            FixedNow,
            FixedNow,
            FixedNow.AddSeconds(
                settings.MaxRunDurationSeconds
                - settings.ProviderOperationTimeoutSeconds
                - settings.CompletionSafetyMarginSeconds));

        var result = await CreateProcessor(
            repository,
            delivery,
            settings,
            timeProvider).ProcessAsync();

        Assert.Single(repository.DeferCommands);
        Assert.Equal(0, delivery.CallCount);
        Assert.Equal(1, result.DeferredCount);
        Assert.Equal(1, repository.SummaryCallCount);
    }

    [Fact]
    public async Task ProcessAsync_OnSuccessCompletesSentWithProviderMessageId()
    {
        var repository = RepositoryWithOneClaim();
        var delivery = new RecordingDeliveryClient((_, _) => Task.FromResult(
            Succeeded with { ProviderMessageId = "provider-message-123" }));

        var result = await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.CompleteCommands);
        Assert.Equal("SENT", command.Status);
        Assert.Equal("SUCCEEDED", command.AttemptOutcome);
        Assert.False(command.IncrementFailureCount);
        Assert.Equal("provider-message-123", command.ProviderMessageId);
        Assert.Equal(1, result.SentCount);
    }

    [Fact]
    public async Task ProcessAsync_OnTransientFailureReschedulesWithIncrementedExponentialDelay()
    {
        var repository = RepositoryWithOneClaim(CreateClaimed(1, failureCount: 2));
        var delivery = DeliveryReturning(
            EmailDeliveryOutcome.TransientFailure,
            "TRANSPORT",
            "ACS_NETWORK_ERROR",
            "Safe transient failure.");
        var settings = CreateSettings() with
        {
            InitialRetryDelaySeconds = 60,
            RetryJitterSeconds = 0
        };

        var result = await CreateProcessor(repository, delivery, settings).ProcessAsync();

        var command = Assert.Single(repository.RescheduleCommands);
        Assert.Equal("TRANSIENT_FAILURE", command.Outcome);
        Assert.Equal(FixedNow.AddSeconds(240), command.NextAttemptDateTime);
        Assert.Equal(3, Assert.Single(repository.RescheduleResults).FailureCount);
        Assert.Equal(1, result.RescheduledCount);
        Assert.Equal(0, result.ThrottledCount);
    }

    [Fact]
    public async Task ProcessAsync_OnEighthTransientFailureCompletesTerminalFailureAndChecksReturnedCount()
    {
        var repository = RepositoryWithOneClaim(CreateClaimed(1, failureCount: 7));
        var delivery = DeliveryReturning(
            EmailDeliveryOutcome.TransientFailure,
            "TRANSPORT",
            "ACS_TIMEOUT",
            "Safe timeout.");

        var result = await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.CompleteCommands);
        Assert.Equal("FAILED", command.Status);
        Assert.Equal("TRANSIENT_FAILURE", command.AttemptOutcome);
        Assert.True(command.IncrementFailureCount);
        Assert.Equal(8, Assert.Single(repository.CompleteResults).FailureCount);
        Assert.Equal(1, result.FailedCount);
    }

    [Fact]
    public async Task ProcessAsync_RejectsTerminalTransientPersistenceWithWrongFailureCount()
    {
        var repository = RepositoryWithOneClaim(CreateClaimed(1, failureCount: 7));
        repository.CompleteResultFactory = command => Completed(command, failureCount: 7);
        var delivery = DeliveryReturning(
            EmailDeliveryOutcome.TransientFailure,
            "TRANSPORT",
            "ACS_TIMEOUT",
            "Safe timeout.");

        var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            CreateProcessor(repository, delivery).ProcessAsync());

        Assert.Contains("failure count", exception.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Theory]
    [InlineData(90, 90)]
    [InlineData(null, 60)]
    public async Task ProcessAsync_OnThrottleReschedulesWithoutFailureIncrement(
        int? retryAfterSeconds,
        int expectedDelaySeconds)
    {
        var claimed = CreateClaimed(1, failureCount: 3, throttleCount: 4);
        var repository = RepositoryWithOneClaim(claimed);
        var delivery = new RecordingDeliveryClient((_, _) => Task.FromResult(
            new EmailDeliveryResult(
                EmailDeliveryOutcome.Throttled,
                null,
                429,
                retryAfterSeconds is null
                    ? null
                    : TimeSpan.FromSeconds(retryAfterSeconds.Value),
                "CAPACITY",
                "ACS_THROTTLED",
                "Provider capacity was exceeded.")));

        var result = await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.RescheduleCommands);
        Assert.Equal("THROTTLED", command.Outcome);
        Assert.Equal(FixedNow.AddSeconds(expectedDelaySeconds), command.NextAttemptDateTime);
        var persisted = Assert.Single(repository.RescheduleResults);
        Assert.Equal(3, persisted.FailureCount);
        Assert.Equal(5, persisted.ThrottleCount);
        Assert.Equal(1, result.RescheduledCount);
        Assert.Equal(1, result.ThrottledCount);
    }

    [Fact]
    public async Task ProcessAsync_OnExtremeThrottleRetryAfterSaturatesAtSqlDateTime2Maximum()
    {
        var claimed = CreateClaimed(1, failureCount: 3, throttleCount: 4);
        var repository = RepositoryWithOneClaim(claimed);
        var delivery = new RecordingDeliveryClient((_, _) => Task.FromResult(
            new EmailDeliveryResult(
                EmailDeliveryOutcome.Throttled,
                null,
                429,
                TimeSpan.MaxValue,
                "CAPACITY",
                "ACS_THROTTLED",
                "Provider capacity was exceeded.")));

        var result = await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.RescheduleCommands);
        Assert.Equal("THROTTLED", command.Outcome);
        Assert.Equal(
            new DateTimeOffset(9999, 12, 31, 23, 59, 59, 999, TimeSpan.Zero),
            command.NextAttemptDateTime);
        var persisted = Assert.Single(repository.RescheduleResults);
        Assert.Equal(3, persisted.FailureCount);
        Assert.Equal(5, persisted.ThrottleCount);
        Assert.Equal(1, result.RescheduledCount);
        Assert.Equal(1, result.ThrottledCount);
    }

    [Fact]
    public async Task ProcessAsync_OnPermanentFailureCompletesWithoutFailureIncrementAndBoundsDescription()
    {
        var repository = RepositoryWithOneClaim(CreateClaimed(1, failureCount: 3));
        var delivery = DeliveryReturning(
            EmailDeliveryOutcome.PermanentFailure,
            "PROVIDER",
            "ACS_TERMINAL_FAILED",
            new string('x', 1200));

        var result = await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.CompleteCommands);
        Assert.Equal("FAILED", command.Status);
        Assert.Equal("PERMANENT_FAILURE", command.AttemptOutcome);
        Assert.False(command.IncrementFailureCount);
        Assert.Equal(1000, command.FailureDescription?.Length);
        Assert.Equal(3, Assert.Single(repository.CompleteResults).FailureCount);
        Assert.Equal(1, result.FailedCount);
    }

    [Fact]
    public async Task ProcessAsync_WhenProviderTimesOutReschedulesAsTransientFailure()
    {
        var repository = RepositoryWithOneClaim();
        var delivery = new RecordingDeliveryClient(async (_, cancellationToken) =>
        {
            await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
            return Succeeded;
        });
        var settings = CreateSettings() with
        {
            LeaseDurationSeconds = 10,
            MaxRunDurationSeconds = 10,
            ProviderOperationTimeoutSeconds = 1,
            CompletionSafetyMarginSeconds = 2,
            OutcomePersistenceTimeoutSeconds = 2,
            RetryJitterSeconds = 0
        };
        var stopwatch = Stopwatch.StartNew();

        var result = await CreateProcessor(repository, delivery, settings).ProcessAsync();

        stopwatch.Stop();
        var command = Assert.Single(repository.RescheduleCommands);
        Assert.Equal("TRANSIENT_FAILURE", command.Outcome);
        Assert.Equal("TRANSPORT", command.FailureCategory);
        Assert.Equal("PROVIDER_TIMEOUT", command.FailureCode);
        Assert.Equal(1, result.RescheduledCount);
        Assert.InRange(stopwatch.Elapsed, TimeSpan.FromMilliseconds(500), TimeSpan.FromSeconds(5));
    }

    [Fact]
    public async Task ProcessAsync_WhenHostCancelsUnobservedProviderCallPropagatesWithoutTransition()
    {
        var repository = RepositoryWithOneClaim();
        var providerStarted = new TaskCompletionSource(
            TaskCreationOptions.RunContinuationsAsynchronously);
        var delivery = new RecordingDeliveryClient(async (_, cancellationToken) =>
        {
            providerStarted.SetResult();
            await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
            return Succeeded;
        });
        using var cancellationSource = new CancellationTokenSource();
        var processTask = CreateProcessor(repository, delivery)
            .ProcessAsync(cancellationSource.Token);
        await providerStarted.Task;

        cancellationSource.Cancel();

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => processTask);
        Assert.Empty(repository.DeferCommands);
        Assert.Empty(repository.RescheduleCommands);
        Assert.Empty(repository.CompleteCommands);
        Assert.Equal(0, repository.SummaryCallCount);
    }

    [Fact]
    public async Task ProcessAsync_WhenHostCancelsAfterObservedOutcomePersistsWithIndependentToken()
    {
        var repository = RepositoryWithOneClaim();
        using var cancellationSource = new CancellationTokenSource();
        var delivery = new RecordingDeliveryClient((_, _) =>
        {
            cancellationSource.Cancel();
            return Task.FromResult(Succeeded);
        });

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            CreateProcessor(repository, delivery).ProcessAsync(cancellationSource.Token));

        Assert.Single(repository.CompleteCommands);
        var persistenceToken = Assert.Single(repository.CompleteTokens);
        Assert.True(persistenceToken.CanBeCanceled);
        Assert.NotEqual(cancellationSource.Token, persistenceToken);
        Assert.False(persistenceToken.IsCancellationRequested);
    }

    [Fact]
    public async Task ProcessAsync_WhenSqlPayloadHashMismatchesCompletesIntegrityFailureWithoutSend()
    {
        var repository = RepositoryWithOneClaim(
            CreateClaimed(1) with { PayloadSha256 = new byte[32] });
        var delivery = new RecordingDeliveryClient();

        var result = await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.CompleteCommands);
        Assert.Equal("FAILED", command.Status);
        Assert.Equal("PERMANENT_FAILURE", command.AttemptOutcome);
        Assert.False(command.IncrementFailureCount);
        Assert.Equal("INTEGRITY", command.FailureCategory);
        Assert.Equal("PAYLOAD_HASH_MISMATCH", command.FailureCode);
        Assert.Equal(0, delivery.CallCount);
        Assert.Equal(1, result.FailedCount);
    }

    [Fact]
    public async Task ProcessAsync_WhenEnvelopeCannotBeDeserializedCompletesValidationFailureWithoutSend()
    {
        const string invalidJson = "{not-json";
        var repository = RepositoryWithOneClaim(
            CreateClaimed(1) with
            {
                EmailEnvelopeJson = invalidJson,
                PayloadSha256 = SHA256.HashData(Encoding.Unicode.GetBytes(invalidJson))
            });
        var delivery = new RecordingDeliveryClient();

        await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.CompleteCommands);
        Assert.Equal("VALIDATION", command.FailureCategory);
        Assert.Equal("INVALID_EMAIL_ENVELOPE", command.FailureCode);
        Assert.Equal(0, delivery.CallCount);
    }

    [Fact]
    public async Task ProcessAsync_WhenClaimedAttachmentSha256IsMissingCompletesPermanentFailureOnceWithoutSend()
    {
        var validClaim = CreateClaimed(1);
        var invalidJson = validClaim.EmailEnvelopeJson.Replace(
            "\"attachments\":[]",
            "\"attachments\":[{\"fileName\":\"private-file.txt\",\"contentType\":\"text/plain\",\"base64Content\":\"aGVsbG8=\"}]",
            StringComparison.Ordinal);
        var claimed = validClaim with
        {
            EmailEnvelopeJson = invalidJson,
            PayloadSha256 = SHA256.HashData(Encoding.Unicode.GetBytes(invalidJson))
        };
        var repository = RepositoryWithOneClaim(claimed);
        var delivery = new RecordingDeliveryClient();

        var result = await CreateProcessor(repository, delivery).ProcessAsync();

        var command = Assert.Single(repository.CompleteCommands);
        Assert.Equal("FAILED", command.Status);
        Assert.Equal("PERMANENT_FAILURE", command.AttemptOutcome);
        Assert.False(command.IncrementFailureCount);
        Assert.Equal("VALIDATION", command.FailureCategory);
        Assert.Equal("INVALID_EMAIL_ENVELOPE", command.FailureCode);
        Assert.Equal(0, delivery.CallCount);
        Assert.Equal(1, result.FailedCount);
        Assert.Equal(1, repository.SummaryCallCount);
        Assert.Equal(repository.Summary, result.QueueSummary);
    }

    [Fact]
    public async Task ProcessAsync_AfterTypicalNormalExitLogsCompleteSafeQueueHealthTelemetry()
    {
        var claimed = CreateClaimed(1);
        var futureOldestPending = FixedNow.AddMinutes(5);
        var summary = Summary with
        {
            OldestClaimablePendingDateTime = futureOldestPending
        };
        var repository = RepositoryWithOneClaim(claimed);
        repository.Summary = summary;
        var logger = new CapturingLogger<EmailNotificationProcessor>();

        var result = await CreateProcessor(repository, logger: logger).ProcessAsync();

        AssertQueueHealthLog(logger, summary, expectedOldestPendingAgeSeconds: 0);
        var captured = string.Join(Environment.NewLine, logger.Entries);
        Assert.Contains($"Claimed={result.ClaimedCount}", captured, StringComparison.Ordinal);
        Assert.Contains($"Sent={result.SentCount}", captured, StringComparison.Ordinal);
        foreach (var privateValue in new[]
                 {
                     claimed.EmailEnvelopeJson,
                     "private-sender@example.com",
                     "private-recipient@example.com",
                     "Private subject",
                     "Private body"
                 })
        {
            Assert.DoesNotContain(privateValue, captured, StringComparison.Ordinal);
        }
    }

    private static void AssertQueueHealthLog(
        CapturingLogger<EmailNotificationProcessor> logger,
        PurchaseOrderEmailNotificationQueueSummary summary,
        long expectedOldestPendingAgeSeconds)
    {
        var state = Assert.Single(
            logger.States,
            entry => entry.ContainsKey("ClaimablePendingCount"));
        Assert.Equal(summary.ClaimablePendingCount, state["ClaimablePendingCount"]);
        Assert.Equal(summary.DelayedPendingCount, state["DelayedPendingCount"]);
        Assert.Equal(summary.ActiveLeasedCount, state["ActiveLeasedCount"]);
        Assert.Equal(summary.ExpiredLeasedCount, state["ExpiredLeasedCount"]);
        Assert.Equal(
            summary.UnsendableLegacyPendingCount,
            state["UnsendableLegacyPendingCount"]);
        Assert.Equal(summary.TerminalFailureCount, state["TerminalFailureCount"]);
        Assert.Equal(
            summary.OldestClaimablePendingDateTime,
            state["OldestClaimablePendingDateTime"]);
        Assert.Equal(
            expectedOldestPendingAgeSeconds,
            state["OldestClaimablePendingAgeSeconds"]);
        Assert.True(expectedOldestPendingAgeSeconds >= 0);
    }

    private static EmailNotificationProcessor CreateProcessor(
        RecordingRepository repository,
        RecordingDeliveryClient? delivery = null,
        EmailSenderSettings? settings = null,
        TimeProvider? timeProvider = null,
        ILogger<EmailNotificationProcessor>? logger = null)
    {
        var validator = new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator());
        var serializer = new EmailEnvelopeSerializer(validator);
        var actualSettings = settings ?? CreateSettings();
        return new EmailNotificationProcessor(
            repository,
            serializer,
            validator,
            delivery ?? new RecordingDeliveryClient(),
            new EmailRetryDelayCalculator(
                new StaticOptionsMonitor<EmailSenderSettings>(actualSettings),
                new FixedJitterProvider(0)),
            new StaticOptionsMonitor<EmailSenderSettings>(actualSettings),
            timeProvider ?? new FixedTimeProvider(FixedNow),
            logger ?? new CapturingLogger<EmailNotificationProcessor>());
    }

    private static EmailSenderSettings CreateSettings() => new()
    {
        SendingEnabled = true,
        Smtp = new EmailSmtpSettings
        {
            Host = "smtp.azurecomm.net",
            Port = 587,
            UseStartTls = true,
            Username = "test-username",
            Password = "test-password"
        },
        DefaultSenderAddress = "private-sender@example.com",
        ClaimBatchSize = 10,
        MaxConcurrency = 4,
        LeaseDurationSeconds = 120,
        MaxRunDurationSeconds = 50,
        ProviderOperationTimeoutSeconds = 30,
        CompletionSafetyMarginSeconds = 10,
        OutcomePersistenceTimeoutSeconds = 10,
        MaxFailureCount = 8,
        InitialRetryDelaySeconds = 60,
        MaxRetryDelaySeconds = 3600,
        RetryJitterSeconds = 0,
        ThrottleFallbackDelaySeconds = 60,
        RateLimit = new EmailRateLimitSettings
        {
            MaxAttemptsPerMinute = 100,
            MaxAttemptsPerHour = 1000
        }
    };

    private static RecordingRepository RepositoryWithOneClaim(
        ClaimedPurchaseOrderEmailNotification? claimed = null)
    {
        var repository = new RecordingRepository();
        repository.ClaimResults.Enqueue([claimed ?? CreateClaimed(1)]);
        repository.ClaimResults.Enqueue([]);
        return repository;
    }

    private static RecordingDeliveryClient DeliveryReturning(
        EmailDeliveryOutcome outcome,
        string category,
        string code,
        string description) => new((_, _) => Task.FromResult(
        new EmailDeliveryResult(
            outcome,
            null,
            null,
            null,
            category,
            code,
            description)));

    private static ClaimedPurchaseOrderEmailNotification CreateClaimed(
        int number,
        int failureCount = 0,
        int throttleCount = 0,
        DateTimeOffset? leaseExpiry = null)
    {
        var envelope = new EmailEnvelopeV1(
            1,
            NotificationId(number),
            $"private-correlation-{number}",
            "private-sender@example.com",
            [new EmailMailbox("private-recipient@example.com", "Private Recipient")],
            [],
            [],
            [],
            "Private subject",
            "<p>Private body</p>",
            "Private body",
            []);
        var validator = new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator());
        var json = new EmailEnvelopeSerializer(validator).Serialize(envelope);
        return new ClaimedPurchaseOrderEmailNotification(
            envelope.NotificationId,
            "BATCH_COMPLETED",
            envelope.BusinessCorrelationId,
            1,
            json,
            SHA256.HashData(Encoding.Unicode.GetBytes(json)),
            1,
            failureCount,
            throttleCount,
            Guid.Parse($"20000000-0000-0000-0000-{number:D12}"),
            leaseExpiry ?? FixedNow.AddMinutes(2),
            [(byte)number, 0, 0, 0, 0, 0, 0, 0]);
    }

    private static Guid NotificationId(int number) =>
        Guid.Parse($"10000000-0000-0000-0000-{number:D12}");

    private static readonly EmailDeliveryResult Succeeded = new(
        EmailDeliveryOutcome.Succeeded,
        "provider-id",
        null,
        null,
        null,
        null,
        null);

    private static readonly PurchaseOrderEmailNotificationQueueSummary ZeroSummary = new(
        0,
        null,
        0,
        0,
        0,
        0,
        0);

    private static readonly PurchaseOrderEmailNotificationQueueSummary Summary = new(
        2,
        FixedNow.AddMinutes(-5),
        3,
        4,
        5,
        6,
        7);

    private sealed class RecordingRepository : IPurchaseOrderNotificationRepository
    {
        private int _summaryCallCount;
        private int _totalCalls;

        public Queue<IReadOnlyList<ClaimedPurchaseOrderEmailNotification>> ClaimResults { get; } = [];
        public ConcurrentQueue<ClaimPurchaseOrderEmailNotificationsCommand> ClaimCommands { get; } = [];
        public ConcurrentQueue<DeferPurchaseOrderEmailNotificationCommand> DeferCommands { get; } = [];
        public ConcurrentQueue<ReschedulePurchaseOrderEmailNotificationCommand> RescheduleCommands { get; } = [];
        public ConcurrentQueue<CompletePurchaseOrderEmailNotificationCommand> CompleteCommands { get; } = [];
        public ConcurrentQueue<UpdatedPurchaseOrderEmailNotification> RescheduleResults { get; } = [];
        public ConcurrentQueue<CompletedPurchaseOrderEmailNotification> CompleteResults { get; } = [];
        public ConcurrentQueue<CancellationToken> CompleteTokens { get; } = [];
        public PurchaseOrderEmailNotificationQueueSummary Summary { get; set; } = ZeroSummary;
        public Func<CompletePurchaseOrderEmailNotificationCommand, CompletedPurchaseOrderEmailNotification>
            CompleteResultFactory { get; set; } = command => Completed(command);

        public int SummaryCallCount => Volatile.Read(ref _summaryCallCount);
        public int TotalCalls => Volatile.Read(ref _totalCalls);

        public Task<IReadOnlyList<ClaimedPurchaseOrderEmailNotification>> ClaimDueEmailNotificationsAsync(
            ClaimPurchaseOrderEmailNotificationsCommand command,
            CancellationToken cancellationToken = default)
        {
            Interlocked.Increment(ref _totalCalls);
            cancellationToken.ThrowIfCancellationRequested();
            ClaimCommands.Enqueue(command);
            return Task.FromResult(ClaimResults.Count == 0 ? [] : ClaimResults.Dequeue());
        }

        public Task<UpdatedPurchaseOrderEmailNotification> DeferEmailNotificationAsync(
            DeferPurchaseOrderEmailNotificationCommand command,
            CancellationToken cancellationToken = default)
        {
            Interlocked.Increment(ref _totalCalls);
            cancellationToken.ThrowIfCancellationRequested();
            DeferCommands.Enqueue(command);
            return Task.FromResult(new UpdatedPurchaseOrderEmailNotification(
                command.NotificationId,
                "PENDING",
                command.NextAttemptDateTime,
                0,
                0,
                [2, 0, 0, 0, 0, 0, 0, 0]));
        }

        public Task<UpdatedPurchaseOrderEmailNotification> RescheduleEmailNotificationAsync(
            ReschedulePurchaseOrderEmailNotificationCommand command,
            CancellationToken cancellationToken = default)
        {
            Interlocked.Increment(ref _totalCalls);
            cancellationToken.ThrowIfCancellationRequested();
            RescheduleCommands.Enqueue(command);
            var failureCount = command.Outcome == "TRANSIENT_FAILURE" ? 3 : 3;
            var throttleCount = command.Outcome == "THROTTLED" ? 5 : 0;
            var result = new UpdatedPurchaseOrderEmailNotification(
                command.NotificationId,
                "PENDING",
                command.NextAttemptDateTime,
                failureCount,
                throttleCount,
                [2, 0, 0, 0, 0, 0, 0, 0]);
            RescheduleResults.Enqueue(result);
            return Task.FromResult(result);
        }

        public Task<CompletedPurchaseOrderEmailNotification> CompleteEmailNotificationAsync(
            CompletePurchaseOrderEmailNotificationCommand command,
            CancellationToken cancellationToken = default)
        {
            Interlocked.Increment(ref _totalCalls);
            cancellationToken.ThrowIfCancellationRequested();
            CompleteCommands.Enqueue(command);
            CompleteTokens.Enqueue(cancellationToken);
            var result = CompleteResultFactory(command);
            CompleteResults.Enqueue(result);
            return Task.FromResult(result);
        }

        public Task<PurchaseOrderEmailNotificationQueueSummary> GetEmailNotificationQueueSummaryAsync(
            GetPurchaseOrderEmailNotificationQueueSummaryQuery query,
            CancellationToken cancellationToken = default)
        {
            Interlocked.Increment(ref _totalCalls);
            cancellationToken.ThrowIfCancellationRequested();
            Interlocked.Increment(ref _summaryCallCount);
            return Task.FromResult(Summary);
        }

        public Task<RegisteredPurchaseOrderNotification> RegisterNotificationAsync(
            RegisterPurchaseOrderNotificationCommand command,
            CancellationToken cancellationToken = default) => throw new NotSupportedException();

        public Task<CompletedPurchaseOrderNotification> CompleteNotificationAsync(
            CompletePurchaseOrderNotificationCommand command,
            CancellationToken cancellationToken = default) => throw new NotSupportedException();

        public Task<EnqueuedPurchaseOrderEmailNotification> EnqueueEmailNotificationAsync(
            EnqueuePurchaseOrderEmailNotificationCommand command,
            CancellationToken cancellationToken = default) => throw new NotSupportedException();
    }

    private static CompletedPurchaseOrderEmailNotification Completed(
        CompletePurchaseOrderEmailNotificationCommand command,
        int? failureCount = null) => new(
        command.NotificationId,
        command.Status,
        command.Status == "SENT" ? command.CompletedDateTime : null,
        command.CompletedDateTime,
        failureCount ?? (command.IncrementFailureCount ? 8 : 3),
        0,
        [2, 0, 0, 0, 0, 0, 0, 0]);

    private sealed class RecordingDeliveryClient : IEmailDeliveryClient
    {
        private readonly Func<EmailEnvelopeV1, CancellationToken, Task<EmailDeliveryResult>> _send;
        private int _activeCalls;
        private int _callCount;
        private int _maximumActiveCalls;

        public RecordingDeliveryClient(
            Func<EmailEnvelopeV1, CancellationToken, Task<EmailDeliveryResult>>? send = null)
        {
            _send = send ?? ((_, _) => Task.FromResult(Succeeded));
        }

        public ConcurrentQueue<Guid> NotificationIds { get; } = [];
        public int CallCount => Volatile.Read(ref _callCount);
        public int MaximumActiveCalls => Volatile.Read(ref _maximumActiveCalls);

        public async Task<EmailDeliveryResult> SendAsync(
            EmailEnvelopeV1 envelope,
            CancellationToken cancellationToken = default)
        {
            Interlocked.Increment(ref _callCount);
            NotificationIds.Enqueue(envelope.NotificationId);
            var active = Interlocked.Increment(ref _activeCalls);
            SetMaximum(active);
            try
            {
                return await _send(envelope, cancellationToken);
            }
            finally
            {
                Interlocked.Decrement(ref _activeCalls);
            }
        }

        private void SetMaximum(int candidate)
        {
            int current;
            do
            {
                current = Volatile.Read(ref _maximumActiveCalls);
                if (candidate <= current)
                {
                    return;
                }
            }
            while (Interlocked.CompareExchange(
                ref _maximumActiveCalls,
                candidate,
                current) != current);
        }
    }

    private sealed class FixedJitterProvider(int value) : IEmailJitterProvider
    {
        public int NextInclusive(int minimum, int maximum)
        {
            Assert.InRange(value, minimum, maximum);
            return value;
        }
    }

    private sealed class StaticOptionsMonitor<TOptions>(TOptions value)
        : IOptionsMonitor<TOptions>
    {
        public TOptions CurrentValue => value;
        public TOptions Get(string? name) => value;
        public IDisposable? OnChange(Action<TOptions, string?> listener) => null;
    }

    private sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => utcNow;
    }

    private sealed class SequenceTimeProvider(params DateTimeOffset[] values) : TimeProvider
    {
        private readonly Queue<DateTimeOffset> _values = new(values);
        private DateTimeOffset _last = values[^1];

        public override DateTimeOffset GetUtcNow()
        {
            if (_values.TryDequeue(out var value))
            {
                _last = value;
            }

            return _last;
        }
    }

    private sealed class CapturingLogger<T> : ILogger<T>
    {
        public ConcurrentQueue<string> Entries { get; } = [];
        public ConcurrentQueue<IReadOnlyDictionary<string, object?>> States { get; } = [];

        public IDisposable? BeginScope<TState>(TState state)
            where TState : notnull => null;

        public bool IsEnabled(LogLevel logLevel) => true;

        public void Log<TState>(
            LogLevel logLevel,
            EventId eventId,
            TState state,
            Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            Entries.Enqueue(formatter(state, exception));
            if (state is IEnumerable<KeyValuePair<string, object?>> values)
            {
                States.Enqueue(values.ToDictionary(
                    item => item.Key,
                    item => item.Value,
                    StringComparer.Ordinal));
            }
        }
    }
}
