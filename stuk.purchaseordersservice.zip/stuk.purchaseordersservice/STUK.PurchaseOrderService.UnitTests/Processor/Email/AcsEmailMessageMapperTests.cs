using System.Net.Mail;
using System.Text;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Delivery;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class AcsEmailMessageMapperTests
{
    private const string HelloSha256 =
        "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824";

    [Fact]
    public void Map_UsesTheCompletePersistedEnvelopeSnapshot()
    {
        var envelope = new EmailEnvelopeV1(
            1,
            Guid.Parse("11111111-1111-1111-1111-111111111111"),
            "private-correlation",
            "persisted-sender@example.com",
            [new EmailMailbox("to@example.com", "To User")],
            [new EmailMailbox("cc@example.com", "Cc User")],
            [new EmailMailbox("bcc@example.com", "Bcc User")],
            [new EmailMailbox("reply@example.com", "Reply User")],
            "Persisted subject",
            "<p>Private HTML</p>",
            "Private plain text",
            [new EmailAttachmentV1("hello.txt", "text/plain", HelloSha256, "aGVsbG8=")]);

        using var message = CreateMapper().Map(envelope);

        AssertMailbox(message.From!, "persisted-sender@example.com", string.Empty);
        AssertMailbox(message.To.Single(), "to@example.com", "To User");
        AssertMailbox(message.CC.Single(), "cc@example.com", "Cc User");
        AssertMailbox(message.Bcc.Single(), "bcc@example.com", "Bcc User");
        AssertMailbox(message.ReplyToList.Single(), "reply@example.com", "Reply User");
        Assert.Equal("Persisted subject", message.Subject);
        Assert.Equal(Encoding.UTF8, message.SubjectEncoding);
        Assert.Equal("Private plain text", message.Body);
        Assert.False(message.IsBodyHtml);
        Assert.Equal(Encoding.UTF8, message.BodyEncoding);
        var htmlView = Assert.Single(message.AlternateViews);
        Assert.Equal("text/html", htmlView.ContentType.MediaType);
        Assert.Equal("<p>Private HTML</p>", ReadText(htmlView.ContentStream));
        var attachment = Assert.Single(message.Attachments);
        Assert.Equal("hello.txt", attachment.Name);
        Assert.Equal("text/plain", attachment.ContentType.MediaType);
        Assert.Equal("hello", ReadText(attachment.ContentStream));
    }

    [Fact]
    public void Map_WithHtmlOnly_UsesHtmlAsTheMessageBody()
    {
        var envelope = CreateEnvelope() with
        {
            HtmlBody = "<p>Hello</p>",
            PlainTextBody = null
        };

        using var message = CreateMapper().Map(envelope);

        Assert.Equal("<p>Hello</p>", message.Body);
        Assert.True(message.IsBodyHtml);
        Assert.Empty(message.AlternateViews);
    }

    [Fact]
    public void Dispose_DisposesAttachmentContentStreams()
    {
        var envelope = CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1("hello.txt", "text/plain", HelloSha256, "aGVsbG8=")
            ]
        };
        var message = CreateMapper().Map(envelope);
        var contentStream = message.Attachments.Single().ContentStream;

        message.Dispose();

        Assert.Throws<ObjectDisposedException>(() => contentStream.ReadByte());
    }

    [Fact]
    public void Map_ValidatesBeforeMapping()
    {
        var validator = new RecordingValidator();
        var mapper = new AcsEmailMessageMapper(validator);
        var envelope = CreateEnvelope();

        using var message = mapper.Map(envelope);

        Assert.Same(envelope, validator.ValidatedEnvelope);
    }

    [Fact]
    public void Map_WithNullAttachment_ThrowsControlledValidationFailure()
    {
        var envelope = CreateEnvelope() with { Attachments = [null!] };

        var exception = Record.Exception(() => CreateMapper().Map(envelope));

        Assert.IsType<ArgumentException>(exception);
    }

    [Fact]
    public void Map_WithNullAttachmentHash_ThrowsControlledValidationFailure()
    {
        var envelope = CreateEnvelope() with
        {
            Attachments =
            [
                new EmailAttachmentV1("hello.txt", "text/plain", null!, "aGVsbG8=")
            ]
        };

        var exception = Record.Exception(() => CreateMapper().Map(envelope));

        Assert.IsType<ArgumentException>(exception);
    }

    private static AcsEmailMessageMapper CreateMapper() => new(
        new EmailEnvelopeValidator(new AcsSmtpMessageSizeCalculator()));

    private static void AssertMailbox(
        MailAddress actual,
        string expectedAddress,
        string expectedDisplayName)
    {
        Assert.Equal(expectedAddress, actual.Address);
        Assert.Equal(expectedDisplayName, actual.DisplayName);
    }

    private static string ReadText(Stream stream)
    {
        stream.Position = 0;
        using var reader = new StreamReader(
            stream,
            Encoding.UTF8,
            detectEncodingFromByteOrderMarks: true,
            leaveOpen: true);
        return reader.ReadToEnd();
    }

    private static EmailEnvelopeV1 CreateEnvelope() => new(
        1,
        Guid.Parse("11111111-1111-1111-1111-111111111111"),
        "correlation",
        "sender@example.com",
        [new EmailMailbox("to@example.com", null)],
        [],
        [],
        [],
        "Subject",
        "<p>Hello</p>",
        "Hello",
        []);

    private sealed class RecordingValidator : IEmailEnvelopeValidator
    {
        public EmailEnvelopeV1? ValidatedEnvelope { get; private set; }

        public void Validate(EmailEnvelopeV1 envelope) => ValidatedEnvelope = envelope;
    }
}
