using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Email.Relex;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Email;

public sealed class RelexNotificationSettingsTests
{
    [Fact]
    public void Validate_DisabledDefaultsNeedNoRecipientsOrSender() =>
        Assert.True(Validator().Validate(null, new RelexNotificationSettings()).Succeeded);

    [Fact]
    public void Validate_EnabledResultsRequireExplicitActivationBoundary()
    {
        var settings = ValidSettings();
        settings.ResultsNotBeforeUtc = null;
        Assert.True(Validator().Validate(null, settings).Failed);
    }

    [Theory]
    [InlineData("bad-address")]
    [InlineData("Name <test@example.com>")]
    [InlineData("")]
    public void Validate_EnabledRejectsInvalidRecipients(string recipients)
    {
        var settings = ValidSettings();
        settings.Recipients = recipients;
        Assert.True(Validator().Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_EnabledRequiresSenderEvenWhenDeliveryDisabled() =>
        Assert.True(new RelexNotificationSettingsValidator(Options.Create(new EmailSenderSettings()))
            .Validate(null, ValidSettings()).Failed);

    [Theory]
    [InlineData("MaxEventsPerRun", 0)]
    [InlineData("MaxEventsPerRun", 101)]
    [InlineData("LeaseDurationSeconds", 59)]
    [InlineData("MissingProposalCatchUpMinutes", 1440)]
    [InlineData("MissingProposalLookbackHours", 0)]
    [InlineData("MaxFailureCount", 0)]
    public void Validate_RejectsUnsafeBounds(string property, int value)
    {
        var settings = ValidSettings();
        typeof(RelexNotificationSettings).GetProperty(property)!.SetValue(settings, value);
        Assert.True(Validator().Validate(null, settings).Failed);
    }

    [Fact]
    public void Validate_RejectsBadTimezoneDaysTimeAndCron()
    {
        var settings = ValidSettings();
        settings.TimeZoneId = "not-a-zone";
        settings.MissingProposalDays = "Monday,Funday";
        settings.MissingProposalCutoffLocalTime = "25:00";
        settings.CronExpression = "bad";
        Assert.True(Validator().Validate(null, settings).Failures!.Count() >= 4);
    }

    [Theory]
    [InlineData("2026-09-24T09:29:59Z", null)]
    [InlineData("2026-09-24T09:30:00Z", "2026-09-24T09:30:00Z")]
    [InlineData("2026-09-24T10:29:59Z", "2026-09-24T09:30:00Z")]
    [InlineData("2026-09-24T10:30:00Z", null)]
    [InlineData("2026-12-24T10:30:00Z", "2026-12-24T10:30:00Z")]
    [InlineData("2026-09-27T09:30:00Z", null)]
    public void Cutoff_UsesLondonCalendarBoundedCatchUpAndConfiguredDays(string now, string? expected)
    {
        var result = RelexNotificationCutoff.GetDue(ValidSettings(), DateTimeOffset.Parse(now));
        if (expected is null)
        {
            Assert.Null(result);
            return;
        }

        Assert.NotNull(result);
        Assert.Equal(DateTimeOffset.Parse(expected), result.CutoffUtc);
        Assert.Equal(result.CutoffUtc.AddHours(-6), result.FreshSinceUtc);
        Assert.Equal($"RELEX_MISSING:{DateTimeOffset.Parse(now):yyyy-MM-dd}", result.EventKey);
    }

    [Fact]
    public void Cutoff_DisabledDoesNotCreateMissingEvent()
    {
        var settings = ValidSettings();
        settings.MissingProposalEnabled = false;
        Assert.Null(RelexNotificationCutoff.GetDue(settings, DateTimeOffset.Parse("2026-09-24T09:30:00Z")));
    }

    [Fact]
    public void Cutoff_CatchUpAcrossMidnightUsesPreviousAllowedDay()
    {
        var settings = ValidSettings();
        settings.MissingProposalCutoffLocalTime = "23:30";
        var cutoff = RelexNotificationCutoff.GetDue(settings, DateTimeOffset.Parse("2026-09-26T23:10:00Z"));
        Assert.NotNull(cutoff);
        Assert.Equal("RELEX_MISSING:2026-09-26", cutoff.EventKey);
        Assert.Equal(DateTimeOffset.Parse("2026-09-26T22:30:00Z"), cutoff.CutoffUtc);
    }

    [Theory]
    [InlineData("2026-03-29T01:30:00Z", null)]
    [InlineData("2026-10-25T00:30:00Z", "2026-10-25T00:30:00Z")]
    [InlineData("2026-10-25T01:30:00Z", null)]
    public void Cutoff_DstSkipsNonexistentTimeAndUsesFirstRepeatedInstant(string now, string? expected)
    {
        var settings = ValidSettings();
        settings.MissingProposalDays = "Sunday";
        settings.MissingProposalCutoffLocalTime = "01:30";
        var cutoff = RelexNotificationCutoff.GetDue(settings, DateTimeOffset.Parse(now));
        Assert.Equal(expected is null ? (DateTimeOffset?)null : DateTimeOffset.Parse(expected), cutoff?.CutoffUtc);
    }

    [Fact]
    public void Recipients_AreTrimmedAndDeduplicated()
    {
        var settings = ValidSettings();
        settings.Recipients = "one@example.com; TWO@example.com, one@example.com";
        Assert.Equal(new[] { "one@example.com", "TWO@example.com" }, settings.GetRecipients());
        Assert.True(Validator().Validate(null, settings).Succeeded);
    }

    private static RelexNotificationSettingsValidator Validator() => new(
        Options.Create(new EmailSenderSettings { DefaultSenderAddress = "sender@example.com" }));

    private static RelexNotificationSettings ValidSettings() => new()
    {
        ResultsEnabled = true,
        MissingProposalEnabled = true,
        EnvironmentName = "dev",
        Recipients = "team@example.com",
        ResultsNotBeforeUtc = DateTimeOffset.Parse("2026-09-24T00:00:00Z")
    };
}
