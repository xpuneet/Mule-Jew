using Icon = STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Processor.Mapping;
using STUK.PurchaseOrderService.TestUtils.Builders;

namespace STUK.PurchaseOrderService.UnitTests.Processor;

public sealed class PurchaseOrderIconMapperTests
{
    private readonly PurchaseOrderIconMapper _mapper = new();

    [Fact]
    public void Map_CompleteCanonicalOrder_MapsTheApprovedIconRequest()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        var header = order.PurchaseOrderHeader!;
        header.CreateUser = "APIMIN_User";
        header.Instructions = "BRIT186_2";
        header.Narrative = "Internal header text";
        header.ExtOrderRef = "REF01";
        header.ReasonReturn = "AB";
        header.ReasonPurchase = "XYZ";
        header.Contacts =
        [
            new PurchaseOrderContact
            {
                Type = PurchaseOrderPartyType.Invoice,
                Name = "Invoice Contact",
                Contact = "999",
                Phone = "+44 20 0000 0000",
                Email = "invoice@example.test"
            },
            new PurchaseOrderContact
            {
                Type = PurchaseOrderPartyType.Supplier,
                Name = "Supplier Contact",
                Contact = "1",
                Phone = "+44 1488 662000",
                Email = "supplier@example.test"
            }
        ];
        header.Addresses =
        [
            new PurchaseOrderAddress
            {
                Type = PurchaseOrderPartyType.Invoice,
                Lines = ["Invoice line 1", "Invoice line 2"],
                PostCode = "INV 1",
                Country = "GB"
            },
            new PurchaseOrderAddress
            {
                Type = PurchaseOrderPartyType.Supplier,
                Lines = ["Supplier line 1", "Supplier line 2"],
                PostCode = "SUP 1",
                Country = "GB"
            }
        ];
        order.PurchaseOrderLines!.Add(new PurchaseOrderLine
        {
            ProductId = "A0000202",
            Manufacturer = "MAN",
            StockClass = 2,
            ProductDescription = "Blue Brick",
            Quantity = 7,
            Unit = "PK",
            DateExpected = new DateOnly(2026, 7, 10),
            SpecialInstructions = "external",
            InternalInstructions = "internal",
            Tally = []
        });
        var activation = new PurchaseOrderActivationOptionsResult
        {
            Account = "BRIT186",
            ActivateAction = Icon.PurchaseOrderActivateAction.NoActivate,
            Bypass = false
        };

        var request = _mapper.Map(order, activation);

        var iconHeader = Assert.IsType<STUK.IconIntegration.IconClient.PurchaseOrderHeader>(request.Header);
        Assert.Equal("BRIT186", iconHeader.Account);
        Assert.Equal(385, iconHeader.Branch);
        Assert.Equal(1, iconHeader.Location);
        Assert.Equal("APIMIN_User", iconHeader.CreateUser);
        Assert.Equal("20211108", iconHeader.Reference);
        Assert.Equal("2026-07-09", iconHeader.DateExpected);
        Assert.False(iconHeader.Bypass);
        Assert.True(iconHeader.PackIgnore);
        Assert.Equal("Supplier Contact", iconHeader.Name);
        Assert.Equal(["Supplier line 1", "Supplier line 2"], iconHeader.Address!.Line);
        Assert.Equal("SUP 1", iconHeader.Address.PostCode);
        Assert.Equal("GB", iconHeader.CountryOfOrigin);
        Assert.Equal("Invoice Contact", iconHeader.InvoiceName);
        Assert.Equal(["Invoice line 1", "Invoice line 2"], iconHeader.InvoiceAddress!.Line);
        Assert.Equal("INV 1", iconHeader.InvoiceAddress.Postcode);
        Assert.Equal("BRIT186_2", iconHeader.Instructions);
        Assert.Equal("Internal header text", iconHeader.Narrative);
        Assert.True(iconHeader.SuspendOrder);
        Assert.Equal(Icon.PurchaseOrderHeaderOrderType.Stock, iconHeader.OrderType);
        Assert.Equal(Icon.PurchaseOrderActivateAction.NoActivate, iconHeader.ActivateAction);
        Assert.Equal(Icon.PurchaseOrderDeliveryMethod.Delivered, iconHeader.DeliveryMethod);
        Assert.Equal(1u, iconHeader.ContactID);
        Assert.Equal("REF01", iconHeader.ExtOrderRef);
        Assert.Equal("supplier@example.test", iconHeader.Email);
        Assert.Equal("AB", iconHeader.Reason);
        Assert.Equal("XYZ", iconHeader.ReasonPurc);

        Assert.Collection(
            request.Lines!.Line!,
            first =>
            {
                Assert.Equal("A0000201", first.Product);
                Assert.Equal(string.Empty, first.Manufact);
                Assert.Equal(1, first.Location);
                Assert.Equal("Red Brick", first.ExtendedDescription);
                Assert.Equal(5m, first.Quantity);
                Assert.Equal("EA", first.Unit);
                Assert.Equal("2026-07-09", first.DateExpected);
                Assert.Equal(8.45m, first.Price);
                Assert.Equal("EA", first.PriceUnit);
                var tally = Assert.Single(first.Tally!.TallyItem!);
                Assert.Equal(0m, tally.Quantity);
                Assert.Equal(0m, tally.Length);
                Assert.Equal(0m, tally.Width);
            },
            second =>
            {
                Assert.Equal("A0000202", second.Product);
                Assert.Equal("MAN", second.Manufact);
                Assert.Equal(2, second.Location);
                Assert.Equal("Blue Brick", second.ExtendedDescription);
                Assert.Equal(7m, second.Quantity);
                Assert.Equal("PK", second.Unit);
                Assert.Equal("2026-07-10", second.DateExpected);
                Assert.Equal("external", second.SpecialInstructions);
                Assert.Equal("internal", second.InternalInstructions);
                Assert.Null(second.Price);
                Assert.Null(second.PriceUnit);
                Assert.Null(second.Tally);
            });
    }

    [Fact]
    public void Map_ValidCanonicalOrder_ProducesPackageValidIconRequest()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.CreateUser = "APIMIN_User";
        order.PurchaseOrderHeader.Contacts[0].Contact = "1";

        var request = _mapper.Map(order, ActivationFor(order));
        var errors = Icon.PurchaseOrderRequestValidator.Validate(request);

        Assert.True(
            errors.Count == 0,
            string.Join(
                Environment.NewLine,
                errors.Select(error => $"{error.Path}: {error.Message}")));
    }

    [Theory]
    [InlineData(null, null)]
    [InlineData("", null)]
    [InlineData("   ", null)]
    [InlineData("0", 0u)]
    [InlineData("1", 1u)]
    [InlineData("4294967295", uint.MaxValue)]
    public void Map_ContactText_MapsToUnsignedContactId(string? contact, uint? expected)
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.Contacts[0].Contact = contact;

        var request = _mapper.Map(order, ActivationFor(order));

        Assert.Equal(expected, request.Header!.ContactID);
    }

    [Theory]
    [InlineData("-1")]
    [InlineData("+1")]
    [InlineData("1.0")]
    [InlineData("1,000")]
    [InlineData("4294967296")]
    [InlineData("not-a-number")]
    public void Map_InvalidContactText_ThrowsPathSpecificMappingError(string contact)
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.Contacts[0].Contact = contact;

        var exception = Assert.Throws<PurchaseOrderIconMappingException>(
            () => _mapper.Map(order, ActivationFor(order)));

        Assert.Equal("purchaseOrderHeader.contacts[supplier].contact", exception.Path);
        Assert.Contains(exception.Path, exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void Map_ActivationOptions_OverrideCanonicalPlaceholderExtensions()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.Contacts[0].Contact = "1";
        var activation = new PurchaseOrderActivationOptionsResult
        {
            Account = order.PurchaseOrderHeader.Account!,
            ActivateAction = Icon.PurchaseOrderActivateAction.Activate,
            Bypass = false
        };

        var request = _mapper.Map(order, activation);

        Assert.Equal(Icon.PurchaseOrderActivateAction.Activate, request.Header!.ActivateAction);
        Assert.False(request.Header.Bypass);
    }

    [Fact]
    public void Map_DifferentSupplierAndInvoiceCountries_ThrowsPathSpecificMappingError()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.Contacts[0].Contact = "1";
        order.PurchaseOrderHeader.Addresses.Add(new PurchaseOrderAddress
        {
            Type = PurchaseOrderPartyType.Invoice,
            Country = "FR"
        });

        var exception = Assert.Throws<PurchaseOrderIconMappingException>(
            () => _mapper.Map(order, ActivationFor(order)));

        Assert.Equal("purchaseOrderHeader.addresses", exception.Path);
    }

    [Fact]
    public void Map_InvoiceCountryOnly_UsesItAsCountryOfOrigin()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.Contacts[0].Contact = "1";
        order.PurchaseOrderHeader.Addresses[0].Country = null;
        order.PurchaseOrderHeader.Addresses.Add(new PurchaseOrderAddress
        {
            Type = PurchaseOrderPartyType.Invoice,
            Country = "FR"
        });

        var request = _mapper.Map(order, ActivationFor(order));

        Assert.Equal("FR", request.Header!.CountryOfOrigin);
    }

    [Fact]
    public void Map_DuplicateSupplierContact_ThrowsPathSpecificMappingError()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.Contacts[0].Contact = "1";
        order.PurchaseOrderHeader.Contacts.Add(new PurchaseOrderContact
        {
            Type = PurchaseOrderPartyType.Supplier,
            Contact = "2"
        });

        var exception = Assert.Throws<PurchaseOrderIconMappingException>(
            () => _mapper.Map(order, ActivationFor(order)));

        Assert.Equal("purchaseOrderHeader.contacts[supplier]", exception.Path);
    }

    [Fact]
    public void Map_InvalidPackIgnore_ThrowsPathSpecificMappingError()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.Contacts[0].Contact = "1";
        order.PurchaseOrderHeader.ExtensionAttributes.Single(attribute =>
            attribute.Name == "packIgnore").Value = "yes";

        var exception = Assert.Throws<PurchaseOrderIconMappingException>(
            () => _mapper.Map(order, ActivationFor(order)));

        Assert.Equal("purchaseOrderHeader.extensionAttributes[packIgnore].value", exception.Path);
    }

    [Fact]
    public void Map_MissingHeader_ThrowsPathSpecificMappingError()
    {
        var exception = Assert.Throws<PurchaseOrderIconMappingException>(() =>
            _mapper.Map(
                new PurchaseOrder { PurchaseOrderLines = [] },
                new PurchaseOrderActivationOptionsResult()));

        Assert.Equal("purchaseOrderHeader", exception.Path);
    }

    private static PurchaseOrderActivationOptionsResult ActivationFor(PurchaseOrder order) => new()
    {
        Account = order.PurchaseOrderHeader!.Account!,
        ActivateAction = Icon.PurchaseOrderActivateAction.Activate,
        Bypass = true
    };
}
