using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using STUK.IconIntegration.Configuration;
using STUK.IconIntegration.Reports;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.Processor;
using STUK.PurchaseOrderService.Processor.Email.Configuration;
using STUK.PurchaseOrderService.Processor.Email.Delivery;
using STUK.PurchaseOrderService.Processor.Email.Outbox;
using STUK.PurchaseOrderService.Processor.Email.Processing;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;
using STUK.PurchaseOrderService.Processor.Mapping;
using STUK.PurchaseOrderService.Processor.Processing;
using STUK.PurchaseOrderService.Processor.Relex.Files;
using STUK.PurchaseOrderService.Processor.Relex.Parsing;
using STUK.PurchaseOrderService.Processor.Relex.Processing;
using STUK.PurchaseOrderService.Processor.Services;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Processor;

public sealed class ServiceRegistrationExtensionsTests
{
    private const string ConnectionString =
        "Data Source=localhost;Initial Catalog=PurchaseOrders;Integrated Security=True;";
    private const string MissingConnectionStringMessage =
        "Connection string 'PurchaseOrdersServiceDB' is required.";

    [Fact]
    public void AddPurchaseOrderProcessor_WhenConfigured_PreservesProcessorAndIconRegistrations()
    {
        var configuration = BuildConfiguration(ConnectionString, maxConcurrentSubmissions: 37);
        var services = new ServiceCollection();
        services.AddLogging();

        services.AddPurchaseOrderProcessor(configuration);

        using var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        });
        using var scope = provider.CreateScope();

        Assert.Equal(
            "PurchaseOrderService",
            scope.ServiceProvider.GetRequiredService<IOptions<CommonSettings>>().Value.ServiceName);
        var processorSettings = scope.ServiceProvider
            .GetRequiredService<IOptions<BatchProcessorSettings>>()
            .Value;
        Assert.Equal("0 */5 * * * *", processorSettings.ReadyCandidatesProcessorCronExpression);
        Assert.Equal(37, processorSettings.MaxConcurrentSubmissions);
        Assert.IsType<PurchaseOrderProcessor>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrderProcessor>());
        Assert.IsType<IconPurchaseOrderService>(
            scope.ServiceProvider.GetRequiredService<IIconPurchaseOrderService>());
        Assert.IsType<PurchaseOrderIconMapper>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrderIconMapper>());
    }

    [Fact]
    public void AddPurchaseOrderProcessor_WhenConfigured_RegistersValidatedEmailSenderGraph()
    {
        var configuration = BuildConfiguration(ConnectionString, maxConcurrentSubmissions: 37);
        var services = new ServiceCollection();
        services.AddLogging();

        services.AddPurchaseOrderProcessor(configuration);

        AssertRegistration<IEmailEnvelopeSerializer, EmailEnvelopeSerializer>(
            services,
            ServiceLifetime.Singleton);
        AssertRegistration<IEmailRequestSizeCalculator, AcsSmtpMessageSizeCalculator>(
            services,
            ServiceLifetime.Singleton);
        AssertRegistration<IEmailEnvelopeValidator, EmailEnvelopeValidator>(
            services,
            ServiceLifetime.Singleton);
        AssertRegistration<IEmailJitterProvider, SystemEmailJitterProvider>(
            services,
            ServiceLifetime.Singleton);
        AssertRegistration<IEmailRetryDelayCalculator, EmailRetryDelayCalculator>(
            services,
            ServiceLifetime.Singleton);
        AssertRegistration<IAcsSmtpClient, AcsSmtpClient>(
            services,
            ServiceLifetime.Singleton);
        AssertRegistration<IEmailDeliveryClient, AcsEmailDeliveryClient>(
            services,
            ServiceLifetime.Singleton);
        AssertRegistration<IEmailNotificationOutbox, EmailNotificationOutbox>(
            services,
            ServiceLifetime.Scoped);
        AssertRegistration<IEmailNotificationProcessor, EmailNotificationProcessor>(
            services,
            ServiceLifetime.Scoped);

        using var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        });
        provider.GetRequiredService<IStartupValidator>().Validate();
        using var scope = provider.CreateScope();

        var settings = scope.ServiceProvider
            .GetRequiredService<IOptions<EmailSenderSettings>>()
            .Value;
        Assert.False(settings.SendingEnabled);
        Assert.Equal(string.Empty, settings.Smtp.Host);
        Assert.Equal(0, settings.Smtp.Port);
        Assert.False(settings.Smtp.UseStartTls);
        Assert.Equal(string.Empty, settings.Smtp.Username);
        Assert.Equal(string.Empty, settings.Smtp.Password);
        Assert.Equal(string.Empty, settings.DefaultSenderAddress);
        Assert.Equal(
            "0 */1 * * * *",
            scope.ServiceProvider
                .GetRequiredService<IOptions<EmailNotificationScheduleSettings>>()
                .Value
                .CronExpression);
        Assert.IsType<AcsEmailDeliveryClient>(
            scope.ServiceProvider.GetRequiredService<IEmailDeliveryClient>());
        Assert.IsType<EmailNotificationOutbox>(
            scope.ServiceProvider.GetRequiredService<IEmailNotificationOutbox>());
        Assert.IsType<EmailNotificationProcessor>(
            scope.ServiceProvider.GetRequiredService<IEmailNotificationProcessor>());
        Assert.Same(
            TimeProvider.System,
            scope.ServiceProvider.GetRequiredService<TimeProvider>());
    }

    [Fact]
    public void AddPurchaseOrderProcessor_WhenEnabledEmailSettingsAreInvalid_FailsStartupValidation()
    {
        var configuration = BuildConfiguration(
            ConnectionString,
            maxConcurrentSubmissions: 37,
            emailSendingEnabled: true);
        var services = new ServiceCollection();
        services.AddLogging();
        services.AddPurchaseOrderProcessor(configuration);

        using var provider = services.BuildServiceProvider();

        var exception = Assert.Throws<OptionsValidationException>(() =>
            provider.GetRequiredService<IStartupValidator>().Validate());
        Assert.Contains(
            exception.Failures,
            failure => failure.Contains("EmailSender:Smtp:Host", StringComparison.Ordinal));
    }

    [Fact]
    public void AddPurchaseOrderProcessor_WhenEmailScheduleIsInvalid_FailsStartupValidation()
    {
        var configuration = BuildConfiguration(
            ConnectionString,
            maxConcurrentSubmissions: 37,
            emailCronExpression: "not-a-six-field-cron");
        var services = new ServiceCollection();
        services.AddLogging();
        services.AddPurchaseOrderProcessor(configuration);

        using var provider = services.BuildServiceProvider();

        var exception = Assert.Throws<OptionsValidationException>(() =>
            provider.GetRequiredService<IStartupValidator>().Validate());
        Assert.Contains(
            exception.Failures,
            failure => failure.Contains(
                "EmailNotificationSenderCronExpression",
                StringComparison.Ordinal));
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_WhenResolved_DoesNotClaimOrSubmitCandidates()
    {
        var configuration = BuildConfiguration(ConnectionString, maxConcurrentSubmissions: 37);
        var executor = new RecordingStoredProcedureExecutor();
        var iconService = new RecordingIconPurchaseOrderService();
        var services = new ServiceCollection();
        services.AddLogging();
        services.AddPurchaseOrderProcessor(configuration);
        services.AddScoped<IStoredProcedureExecutor>(_ => executor);
        services.AddScoped<IIconPurchaseOrderService>(_ => iconService);

        using var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        });
        using var scope = provider.CreateScope();
        var processor = scope.ServiceProvider.GetRequiredService<IPurchaseOrderProcessor>();

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(0, 0, 0), result);
        Assert.Empty(executor.ProcedureNames);
        Assert.Equal(0, iconService.CallCount);
    }

    [Fact]
    public void AddPurchaseOrderProcessor_WithLocalRelexSettings_ResolvesValidatedIngestionServices()
    {
        var configuration = BuildConfiguration(ConnectionString, maxConcurrentSubmissions: 37);
        var services = new ServiceCollection();
        services.AddLogging();

        services.AddPurchaseOrderProcessor(configuration);

        using var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        });
        using var scope = provider.CreateScope();
        var settings = scope.ServiceProvider
            .GetRequiredService<IOptions<RelexIngestionSettings>>()
            .Value;

        Assert.Equal(RelexFileStoreProvider.Local, settings.Provider);
        Assert.Equal("/data/input", settings.InputPath);
        Assert.Equal("/data/output/archive", settings.ArchivePath);
        Assert.Equal("/data/output/error", settings.ErrorPath);
        Assert.Equal("SG_OrderProposal*.csv", settings.FilePattern);
        Assert.Equal(120, settings.MinimumFileAgeSeconds);
        Assert.Equal(60, settings.OperationTimeoutSeconds);
        Assert.IsType<LocalRelexFileStore>(
            scope.ServiceProvider.GetRequiredService<IRelexFileStore>());
        Assert.IsType<RelexPurchaseOrderFileProcessor>(
            scope.ServiceProvider.GetRequiredService<IRelexPurchaseOrderFileProcessor>());
        Assert.IsType<RelexPurchaseOrderSerializer>(
            scope.ServiceProvider.GetRequiredService<IRelexPurchaseOrderSerializer>());
        Assert.IsType<RelexIngestionService>(
            scope.ServiceProvider.GetRequiredService<IRelexIngestionService>());
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void AddPurchaseOrderProcessor_WhenDatabaseConnectionIsMissingOrBlank_ThrowsSanitizedError(
        string? connectionString)
    {
        const string sensitiveMarker = "Password=do-not-echo-this";
        var configuration = BuildConfiguration(
            connectionString,
            maxConcurrentSubmissions: 37,
            sensitiveMarker);
        var services = new ServiceCollection();

        var exception = Assert.Throws<InvalidOperationException>(() =>
            services.AddPurchaseOrderProcessor(configuration));

        Assert.Equal(MissingConnectionStringMessage, exception.Message);
        Assert.Null(exception.InnerException);
        Assert.DoesNotContain(sensitiveMarker, exception.Message, StringComparison.Ordinal);
        if (!string.IsNullOrEmpty(connectionString))
        {
            Assert.DoesNotContain(connectionString, exception.Message, StringComparison.Ordinal);
        }
    }

    private static IConfiguration BuildConfiguration(
        string? connectionString,
        int maxConcurrentSubmissions,
        string? sensitiveMarker = null,
        bool emailSendingEnabled = false,
        string emailCronExpression = "0 */1 * * * *")
    {
        var values = new Dictionary<string, string?>
        {
            [$"{nameof(CommonSettings)}:{nameof(CommonSettings.ServiceName)}"] =
                "PurchaseOrderService",
            [$"{nameof(BatchProcessorSettings)}:{nameof(BatchProcessorSettings.ReadyCandidatesProcessorCronExpression)}"] =
                "0 */5 * * * *",
            [$"{nameof(BatchProcessorSettings)}:{nameof(BatchProcessorSettings.MaxConcurrentSubmissions)}"] =
                maxConcurrentSubmissions.ToString(System.Globalization.CultureInfo.InvariantCulture),
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.Provider)}"] =
                nameof(RelexFileStoreProvider.Local),
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.InputPath)}"] =
                "/data/input",
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.ArchivePath)}"] =
                "/data/output/archive",
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.ErrorPath)}"] =
                "/data/output/error",
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.FilePattern)}"] =
                "SG_OrderProposal*.csv",
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.MinimumFileAgeSeconds)}"] =
                "120",
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.Actor)}"] =
                "RelexIngestionFunction",
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.LocalRootPath)}"] =
                Path.GetTempPath(),
            [$"{RelexIngestionSettings.SectionName}:{nameof(RelexIngestionSettings.OperationTimeoutSeconds)}"] =
                "60",
            [$"{nameof(IconSettings)}:{nameof(IconSettings.HttpRequestTimeoutSeconds)}"] = "30",
            [$"{nameof(IconSettings)}:{nameof(IconSettings.BaseUrl)}"] =
                "https://icon-native.example/",
            [$"{nameof(IconSettings)}:{nameof(IconSettings.ReportsBaseUrl)}"] =
                "https://icon-reports.example/",
            [$"{nameof(IconSettings)}:{nameof(IconSettings.ReportsAuthToken)}"] =
                "reports-token",
            [$"{nameof(IconSettings)}:{nameof(IconSettings.PurchaseOrderActivationOptionsReportName)}"] =
                "CF_ICXI0002",
            [$"{nameof(IconSettings)}:{nameof(IconSettings.PurchaseOrderBaseUrl)}"] =
                "https://icon.example/",
            [$"{nameof(IconSettings)}:{nameof(IconSettings.PurchaseOrderAuthToken)}"] =
                "test-token",
            [ConfigConstants.EmailNotificationSenderCronExpressionSettingKey] =
                emailCronExpression,
            [$"{EmailSenderSettings.SectionName}:{nameof(EmailSenderSettings.SendingEnabled)}"] =
                emailSendingEnabled.ToString(System.Globalization.CultureInfo.InvariantCulture),
            [$"{EmailSenderSettings.SectionName}:{nameof(EmailSenderSettings.Smtp)}:{nameof(EmailSmtpSettings.Host)}"] =
                string.Empty,
            [$"{EmailSenderSettings.SectionName}:{nameof(EmailSenderSettings.Smtp)}:{nameof(EmailSmtpSettings.Port)}"] =
                "0",
            [$"{EmailSenderSettings.SectionName}:{nameof(EmailSenderSettings.Smtp)}:{nameof(EmailSmtpSettings.UseStartTls)}"] =
                "false",
            [$"{EmailSenderSettings.SectionName}:{nameof(EmailSenderSettings.Smtp)}:{nameof(EmailSmtpSettings.Username)}"] =
                string.Empty,
            [$"{EmailSenderSettings.SectionName}:{nameof(EmailSenderSettings.Smtp)}:{nameof(EmailSmtpSettings.Password)}"] =
                string.Empty,
            [$"{EmailSenderSettings.SectionName}:{nameof(EmailSenderSettings.DefaultSenderAddress)}"] =
                string.Empty,
            ["UnrelatedSensitiveSetting"] = sensitiveMarker
        };
        if (connectionString is not null)
        {
            values[$"ConnectionStrings:{ConfigConstants.PurchaseOrdersDbConnectionStringName}"] =
                connectionString;
        }

        return new ConfigurationBuilder()
            .AddInMemoryCollection(values)
            .Build();
    }

    private static void AssertRegistration<TService, TImplementation>(
        IServiceCollection services,
        ServiceLifetime expectedLifetime)
        where TService : class
        where TImplementation : class, TService
    {
        var registration = Assert.Single(
            services,
            descriptor => descriptor.ServiceType == typeof(TService));
        Assert.Equal(typeof(TImplementation), registration.ImplementationType);
        Assert.Equal(expectedLifetime, registration.Lifetime);
    }

    private sealed class RecordingStoredProcedureExecutor : IStoredProcedureExecutor
    {
        public List<string> ProcedureNames { get; } = [];

        public Task<int> ExecuteNonQueryAsync(
            StoredProcedureCall call,
            CancellationToken cancellationToken)
        {
            ProcedureNames.Add(call.ProcedureName);
            return Task.FromResult(0);
        }

        public Task<IReadOnlyList<T>> QueryAsync<T>(
            StoredProcedureCall call,
            Func<DbDataReader, T> map,
            CancellationToken cancellationToken)
        {
            ProcedureNames.Add(call.ProcedureName);
            return Task.FromResult<IReadOnlyList<T>>([]);
        }

        public Task<T> QuerySingleAsync<T>(
            StoredProcedureCall call,
            Func<DbDataReader, T> map,
            CancellationToken cancellationToken)
        {
            ProcedureNames.Add(call.ProcedureName);
            throw new InvalidOperationException("No stored procedure call is expected in this test.");
        }
    }

    private sealed class RecordingIconPurchaseOrderService : IIconPurchaseOrderService
    {
        public int CallCount { get; private set; }

        public Task<STUK.IconIntegration.IconClient.IconCreatePurchaseOrderResponse>
            CreatePurchaseOrderAsync(
                STUK.IconIntegration.IconClient.IconCreatePurchaseOrderRequest request,
                CancellationToken cancellationToken = default)
        {
            CallCount++;
            throw new InvalidOperationException("No ICON call is expected in this test.");
        }

        public Task<IconReportResponse<PurchaseOrderActivationOptionsResult>>
            GetPurchaseOrderActivationOptions(
                string account,
                CancellationToken cancellationToken = default)
        {
            CallCount++;
            throw new InvalidOperationException("No ICON call is expected in this test.");
        }
    }
}
