using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Moq;
using STUK.IconIntegration.Configuration;
using STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Reports;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.Processor;
using STUK.PurchaseOrderService.Processor.Services;

namespace STUK.PurchaseOrderService.UnitTests.Processor;

public sealed class IconPurchaseOrderServiceTests
{
    [Fact]
    public void AddPurchaseOrderProcessor_WhenCalled_RegistersIconPurchaseOrderService()
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:PurchaseOrdersServiceDB"] =
                    "Data Source=localhost;Initial Catalog=PurchaseOrders;Integrated Security=True;",
                [$"{nameof(IconSettings)}:{nameof(IconSettings.HttpRequestTimeoutSeconds)}"] = "30",
                [$"{nameof(IconSettings)}:{nameof(IconSettings.BaseUrl)}"] = "https://icon-native.example/",
                [$"{nameof(IconSettings)}:{nameof(IconSettings.ReportsBaseUrl)}"] = "https://icon-reports.example/",
                [$"{nameof(IconSettings)}:{nameof(IconSettings.ReportsAuthToken)}"] = "reports-token",
                [$"{nameof(IconSettings)}:{nameof(IconSettings.PurchaseOrderActivationOptionsReportName)}"] =
                    "CF_ICXI0002",
                [$"{nameof(IconSettings)}:{nameof(IconSettings.PurchaseOrderBaseUrl)}"] = "https://icon.example/",
                [$"{nameof(IconSettings)}:{nameof(IconSettings.PurchaseOrderAuthToken)}"] = "purchase-order-token"
            })
            .Build();
        var services = new ServiceCollection();
        services.AddLogging();

        services.AddPurchaseOrderProcessor(configuration);

        using var serviceProvider = services.BuildServiceProvider();
        var service = serviceProvider.GetRequiredService<IIconPurchaseOrderService>();

        Assert.IsType<IconPurchaseOrderService>(service);
    }

    [Fact]
    public async Task CreatePurchaseOrderAsync_WhenCalled_ForwardsPackageRequestTokenAndCancellation()
    {
        using var cancellationTokenSource = new CancellationTokenSource();
        var request = new IconCreatePurchaseOrderRequest();
        var response = new IconCreatePurchaseOrderResponse
        {
            Body = new IconCreatePurchaseOrderResponse_Body
            {
                OrderNo = 123,
                CreatedStatus = PurchaseOrderCreatedStatus.NotActivated,
                Suspended = false
            }
        };
        var iconHttpClient = new Mock<IIconHttpClient>();
        iconHttpClient
            .Setup(client => client.POST_CreatePurchaseOrderAsync(
                request,
                "purchase-order-token",
                cancellationTokenSource.Token))
            .ReturnsAsync(response);
        var service = new IconPurchaseOrderService(
            Options.Create(new IconSettings
            {
                PurchaseOrderAuthToken = "purchase-order-token"
            }),
            iconHttpClient.Object);

        var result = await service.CreatePurchaseOrderAsync(
            request,
            cancellationTokenSource.Token);

        Assert.Same(response, result);
        iconHttpClient.Verify(client => client.POST_CreatePurchaseOrderAsync(
            request,
            "purchase-order-token",
            cancellationTokenSource.Token), Times.Once);
    }

    [Fact]
    public async Task GetPurchaseOrderActivationOptions_WhenCalled_ForwardsAccountAndConfiguredReportSettings()
    {
        using var cancellationTokenSource = new CancellationTokenSource();
        var response = new IconReportResponse<PurchaseOrderActivationOptionsResult>();
        var reports = new Mock<IIconReports>();
        reports
            .Setup(client => client.POST_PurchaseOrderActivationOptionsAsync(
                It.Is<PurchaseOrderActivationOptionsRequest>(request =>
                    request.Account == "TOOL001"
                    && request.Level == "3"
                    && request.LevelCode == "01"),
                "reports-token",
                "CF_ICXI0002"))
            .ReturnsAsync(response);
        var iconHttpClient = new Mock<IIconHttpClient>();
        iconHttpClient.SetupGet(client => client.Reports).Returns(reports.Object);
        iconHttpClient.SetupGet(client => client.IconSettings).Returns(new IconSettings
        {
            ReportsAuthToken = "reports-token",
            PurchaseOrderActivationOptionsReportName = "CF_ICXI0002"
        });
        var service = new IconPurchaseOrderService(
            Options.Create(new IconSettings
            {
                PurchaseOrderAuthToken = "purchase-order-token"
            }),
            iconHttpClient.Object);

        var result = await service.GetPurchaseOrderActivationOptions(
            "TOOL001",
            cancellationTokenSource.Token);

        Assert.Same(response, result);
        reports.Verify(client => client.POST_PurchaseOrderActivationOptionsAsync(
            It.Is<PurchaseOrderActivationOptionsRequest>(request =>
                request.Account == "TOOL001"
                && request.Level == "3"
                && request.LevelCode == "01"),
            "reports-token",
            "CF_ICXI0002"), Times.Once);
    }

    [Fact]
    public async Task GetPurchaseOrderActivationOptions_WhenCancelled_StopsAwaitingPackageCall()
    {
        var pendingResponse = new TaskCompletionSource<
            IconReportResponse<PurchaseOrderActivationOptionsResult>>(
            TaskCreationOptions.RunContinuationsAsynchronously);
        var reports = new Mock<IIconReports>();
        reports
            .Setup(client => client.POST_PurchaseOrderActivationOptionsAsync(
                It.IsAny<PurchaseOrderActivationOptionsRequest>(),
                "reports-token",
                "CF_ICXI0002"))
            .Returns(pendingResponse.Task);
        var iconHttpClient = new Mock<IIconHttpClient>();
        iconHttpClient.SetupGet(client => client.Reports).Returns(reports.Object);
        iconHttpClient.SetupGet(client => client.IconSettings).Returns(new IconSettings
        {
            ReportsAuthToken = "reports-token",
            PurchaseOrderActivationOptionsReportName = "CF_ICXI0002"
        });
        var service = new IconPurchaseOrderService(
            Options.Create(new IconSettings()),
            iconHttpClient.Object);
        using var cancellationTokenSource = new CancellationTokenSource();
        cancellationTokenSource.Cancel();

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            service.GetPurchaseOrderActivationOptions(
                "TOOL001",
                cancellationTokenSource.Token));
    }
}
