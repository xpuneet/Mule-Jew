using STUK.PurchaseOrderService.Processor.Relex.Processing;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class RelexTemporaryFileFactoryTests
{
    [Fact]
    public async Task CreateAsync_CreatesUniqueEmptyFilesWithRestrictivePermissions()
    {
        await using var root = TemporaryDirectory.Create();
        var factory = new RelexTemporaryFileFactory(root.Path);

        await using var first = await factory.CreateAsync(CancellationToken.None);
        await using var second = await factory.CreateAsync(CancellationToken.None);

        Assert.NotEqual(first.Path, second.Path);
        Assert.StartsWith(root.Path, first.Path, StringComparison.Ordinal);
        Assert.True(File.Exists(first.Path));
        Assert.Equal(0, new FileInfo(first.Path).Length);
        if (!OperatingSystem.IsWindows())
        {
            Assert.Equal(
                UnixFileMode.UserRead | UnixFileMode.UserWrite,
                File.GetUnixFileMode(first.Path));
        }
    }

    [Fact]
    public async Task DisposeAsync_AfterSuccessfulScope_DeletesOnlyOwnedFile()
    {
        await using var root = TemporaryDirectory.Create();
        var unrelatedPath = root.Combine("unrelated.txt");
        await File.WriteAllTextAsync(unrelatedPath, "keep");
        var factory = new RelexTemporaryFileFactory(root.Path);
        string scratchPath;

        await using (var scratch = await factory.CreateAsync(CancellationToken.None))
        {
            scratchPath = scratch.Path;
            await File.WriteAllTextAsync(scratch.Path, "temporary");
        }

        Assert.False(File.Exists(scratchPath));
        Assert.True(File.Exists(unrelatedPath));
    }

    [Fact]
    public async Task DisposeAsync_WhenScopeThrows_StillDeletesFile()
    {
        await using var root = TemporaryDirectory.Create();
        var factory = new RelexTemporaryFileFactory(root.Path);
        string? scratchPath = null;

        await Assert.ThrowsAsync<InvalidOperationException>(async () =>
        {
            await using var scratch = await factory.CreateAsync(CancellationToken.None);
            scratchPath = scratch.Path;
            throw new InvalidOperationException("test failure");
        });

        Assert.NotNull(scratchPath);
        Assert.False(File.Exists(scratchPath));
    }

    [Fact]
    public async Task DisposeAsync_WhenFileIsAlreadyMissing_IsHarmless()
    {
        await using var root = TemporaryDirectory.Create();
        var factory = new RelexTemporaryFileFactory(root.Path);
        var scratch = await factory.CreateAsync(CancellationToken.None);
        File.Delete(scratch.Path);

        await scratch.DisposeAsync();
    }

    private sealed class TemporaryDirectory : IAsyncDisposable
    {
        private TemporaryDirectory(string path)
        {
            Path = path;
        }

        public string Path { get; }

        public static TemporaryDirectory Create()
        {
            var path = System.IO.Path.Combine(
                System.IO.Path.GetTempPath(),
                $"stuk-relex-scratch-test-{Guid.NewGuid():N}");
            Directory.CreateDirectory(path);
            return new TemporaryDirectory(path);
        }

        public string Combine(params string[] parts) =>
            System.IO.Path.Combine([Path, .. parts]);

        public ValueTask DisposeAsync()
        {
            if (Directory.Exists(Path))
            {
                Directory.Delete(Path, recursive: true);
            }

            return ValueTask.CompletedTask;
        }
    }
}
