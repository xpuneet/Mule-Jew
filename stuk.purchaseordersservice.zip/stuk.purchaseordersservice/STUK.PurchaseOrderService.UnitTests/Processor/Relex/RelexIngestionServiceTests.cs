using Microsoft.Extensions.Logging.Abstractions;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Relex.Files;
using STUK.PurchaseOrderService.Processor.Relex.Processing;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class RelexIngestionServiceTests
{
    private static readonly DateTimeOffset FixedNow =
        new(2026, 8, 17, 12, 0, 0, TimeSpan.Zero);

    [Fact]
    public async Task RunAsync_SelectsBoundaryAndSortsEligibleSnapshot()
    {
        var listed = new List<RelexFileMetadata>
        {
            File("/data/input/SG_OrderProposal_z.csv", "SG_OrderProposal_z.csv", -180),
            File("/data/input/not-relex.csv", "not-relex.csv", -500),
            File("/data/input/SG_OrderProposal_b.csv", "SG_OrderProposal_b.csv", -180),
            File("/data/input/SG_OrderProposal_exact.csv", "SG_OrderProposal_exact.csv", -120),
            File(
                "/data/input/SG_OrderProposal_deferred.csv",
                "SG_OrderProposal_deferred.csv",
                -119.999),
            File("/data/input/sg_orderproposal_upper.CSV", "sg_orderproposal_upper.CSV", -121)
        };
        var store = new SnapshotFileStore(listed);
        var processed = new List<string>();
        var service = CreateService(
            store,
            (file, _, _) =>
            {
                processed.Add(file.Name);
                return Task.FromResult(RelexFileProcessingOutcome.Archived);
            });

        var result = await service.RunAsync();

        Assert.Equal(
            [
                "SG_OrderProposal_b.csv",
                "SG_OrderProposal_z.csv",
                "sg_orderproposal_upper.CSV",
                "SG_OrderProposal_exact.csv"
            ],
            processed);
        Assert.Equal(6, result.Discovered);
        Assert.Equal(1, result.Deferred);
        Assert.Equal(1, result.Ignored);
        Assert.Equal(4, result.Archived);
        Assert.Equal(0, result.FailedFiles);
        Assert.Equal(0, result.TransientFailures);
        Assert.Equal(1, store.ListCallCount);
    }

    [Fact]
    public async Task RunAsync_FileAddedWhileProcessing_WaitsForNextSnapshot()
    {
        var listed = new List<RelexFileMetadata>
        {
            File("/data/input/SG_OrderProposal_one.csv", "SG_OrderProposal_one.csv", -180),
            File("/data/input/SG_OrderProposal_two.csv", "SG_OrderProposal_two.csv", -170)
        };
        var store = new SnapshotFileStore(listed);
        var processed = new List<string>();
        var newcomer = File(
            "/data/input/SG_OrderProposal_new.csv",
            "SG_OrderProposal_new.csv",
            -160);
        var service = CreateService(
            store,
            (file, _, _) =>
            {
                processed.Add(file.Name);
                if (processed.Count == 1)
                {
                    listed.Add(newcomer);
                }

                return Task.FromResult(RelexFileProcessingOutcome.Archived);
            });

        await service.RunAsync();

        Assert.DoesNotContain(newcomer.Name, processed);
        Assert.Equal(1, store.ListCallCount);

        processed.Clear();
        await service.RunAsync();

        Assert.Contains(newcomer.Name, processed);
        Assert.Equal(2, store.ListCallCount);
    }

    [Fact]
    public async Task RunAsync_ProcessesAtMostOneFileAtATime()
    {
        var listed = Enumerable.Range(1, 4)
            .Select(index => File(
                $"/data/input/SG_OrderProposal_{index}.csv",
                $"SG_OrderProposal_{index}.csv",
                -200 + index))
            .ToList();
        var store = new SnapshotFileStore(listed);
        var active = 0;
        var maximumActive = 0;
        var service = CreateService(
            store,
            async (_, _, cancellationToken) =>
            {
                var current = Interlocked.Increment(ref active);
                maximumActive = Math.Max(maximumActive, current);
                await Task.Delay(5, cancellationToken);
                Interlocked.Decrement(ref active);
                return RelexFileProcessingOutcome.Archived;
            });

        var result = await service.RunAsync();

        Assert.Equal(1, maximumActive);
        Assert.Equal(4, result.Archived);
    }

    [Fact]
    public async Task RunAsync_WhenOneFileHasTechnicalFailure_ContinuesSnapshot()
    {
        var listed = new List<RelexFileMetadata>
        {
            File("/data/input/SG_OrderProposal_one.csv", "SG_OrderProposal_one.csv", -180),
            File("/data/input/SG_OrderProposal_two.csv", "SG_OrderProposal_two.csv", -170)
        };
        var store = new SnapshotFileStore(listed);
        var processed = new List<string>();
        var service = CreateService(
            store,
            (file, _, _) =>
            {
                processed.Add(file.Name);
                return file.Name.EndsWith("one.csv", StringComparison.Ordinal)
                    ? Task.FromException<RelexFileProcessingOutcome>(
                        new IOException("synthetic technical failure"))
                    : Task.FromResult(RelexFileProcessingOutcome.FailedFile);
            });

        var result = await service.RunAsync();

        Assert.Equal(2, processed.Count);
        Assert.Equal(0, result.Archived);
        Assert.Equal(1, result.FailedFiles);
        Assert.Equal(1, result.TransientFailures);
    }

    [Fact]
    public async Task RunAsync_WhenListingFails_PropagatesFailure()
    {
        var store = new SnapshotFileStore([], new IOException("listing failed"));
        var service = CreateService(
            store,
            (_, _, _) => Task.FromResult(RelexFileProcessingOutcome.Archived));

        await Assert.ThrowsAsync<IOException>(() => service.RunAsync());
    }

    [Fact]
    public async Task RunAsync_WhenFileProcessingIsCancelled_PropagatesCancellation()
    {
        var store = new SnapshotFileStore(
            [File("/data/input/SG_OrderProposal_one.csv", "SG_OrderProposal_one.csv", -180)]);
        var service = CreateService(
            store,
            (_, _, cancellationToken) =>
                Task.FromCanceled<RelexFileProcessingOutcome>(cancellationToken));
        using var cancellationSource = new CancellationTokenSource();
        cancellationSource.Cancel();

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            service.RunAsync(cancellationSource.Token));
    }

    private static RelexIngestionService CreateService(
        IRelexFileStore store,
        RelexFileProcessor processFile) =>
        new(
            store,
            new RelexIngestionSettings
            {
                Provider = RelexFileStoreProvider.Local,
                InputPath = "/data/input",
                ArchivePath = "/data/output/archive",
                ErrorPath = "/data/output/error",
                FilePattern = "SG_OrderProposal*.csv",
                MinimumFileAgeSeconds = 120,
                LocalRootPath = Path.GetTempPath()
            },
            new FixedTimeProvider(FixedNow),
            NullLogger<RelexIngestionService>.Instance,
            processFile);

    private static RelexFileMetadata File(
        string path,
        string name,
        double ageSeconds) =>
        new(path, name, 100, FixedNow.AddSeconds(ageSeconds));

    private sealed class SnapshotFileStore(
        List<RelexFileMetadata> files,
        Exception? listingException = null) : IRelexFileStore
    {
        public int ListCallCount { get; private set; }

        public Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
            string directoryPath,
            CancellationToken cancellationToken)
        {
            ListCallCount++;
            if (listingException is not null)
            {
                return Task.FromException<IReadOnlyList<RelexFileMetadata>>(
                    listingException);
            }

            return Task.FromResult<IReadOnlyList<RelexFileMetadata>>(files);
        }

        public Task DownloadAsync(
            string sourcePath,
            Stream destination,
            CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public Task<bool> ExistsAsync(string path, CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public Task MoveAsync(
            string sourcePath,
            string destinationPath,
            CancellationToken cancellationToken) =>
            throw new NotSupportedException();
    }

    private sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => utcNow;
    }
}
