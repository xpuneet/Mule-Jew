using System.Text;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Processor.Relex.Parsing;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class RelexPurchaseOrderFileProcessorTests
{
    private readonly RelexPurchaseOrderFileProcessor _processor = new();

    [Fact]
    public void Process_WhenSyntheticFileIsValid_MapsSixRowsToFiveOrders()
    {
        using var stream = File.OpenRead(
            Path.Combine(
                AppContext.BaseDirectory,
                "TestData",
                "Relex",
                "SG_OrderProposal_synthetic.csv"));

        var result = _processor.Process(stream);

        Assert.Equal(6, result.ParsedRowCount);
        Assert.Equal(5, result.PurchaseOrders.Count);

        var first = Assert.Single(
            result.PurchaseOrders,
            order => order.PurchaseOrder.PurchaseOrderHeader!.Reference == "1001");
        Assert.Equal(2, first.SourceRowCount);
        var firstHeader = Assert.IsType<PurchaseOrderHeader>(
            first.PurchaseOrder.PurchaseOrderHeader);
        Assert.Equal("SUP-1", firstHeader.Account);
        Assert.Equal(10, firstHeader.Branch);
        Assert.Equal(1, firstHeader.StockClass);
        Assert.Equal("APIRELEX_User", firstHeader.CreateUser);
        Assert.Equal("1001", firstHeader.Reference);
        Assert.Equal(new DateOnly(2026, 8, 20), firstHeader.DateExpected);
        Assert.Equal("Coordinate A", firstHeader.Instructions);
        Assert.Equal("Comment A", firstHeader.Narrative);
        Assert.Equal(PurchaseOrderType.Stock, firstHeader.OrderType);
        Assert.Equal(PurchaseOrderDeliveryMethod.Delivery, firstHeader.DeliveryMethod);
        Assert.True(firstHeader.SuspendOrder);
        Assert.Equal("RUN-1", firstHeader.ExtOrderRef);
        Assert.Empty(firstHeader.Contacts);
        Assert.Empty(firstHeader.Addresses);
        var extension = Assert.Single(firstHeader.ExtensionAttributes);
        Assert.Equal("packIgnore", extension.Name);
        Assert.Equal("true", extension.Value);

        var firstLines = Assert.IsAssignableFrom<IReadOnlyList<PurchaseOrderLine>>(
            first.PurchaseOrder.PurchaseOrderLines);
        Assert.Equal(2, firstLines.Count);
        var pricedLine = firstLines[0];
        Assert.Equal("PROD-A", pricedLine.ProductId);
        Assert.Equal(1, pricedLine.StockClass);
        Assert.Equal(2, pricedLine.Quantity);
        Assert.Equal("EA", pricedLine.Unit);
        Assert.Equal(new DateOnly(2026, 8, 20), pricedLine.DateExpected);
        Assert.Equal("Coordinate A", pricedLine.SpecialInstructions);
        Assert.Equal(12.5f, Assert.IsType<PurchaseOrderPricing>(pricedLine.Pricing).Price);
        Assert.Null(pricedLine.Pricing!.Unit);
        var tally = Assert.Single(pricedLine.Tally);
        Assert.Equal(3, tally.Quantity);
        Assert.Equal(2400, tally.Length);
        Assert.Equal(0, tally.Width);

        var unpricedLine = firstLines[1];
        Assert.Equal("PROD-B", unpricedLine.ProductId);
        Assert.Equal(4, unpricedLine.Quantity);
        Assert.Null(unpricedLine.Pricing);
        Assert.Empty(unpricedLine.Tally);

        var slashDateOrder = FindOrder(result, "1002");
        Assert.Equal(
            new DateOnly(2026, 8, 21),
            slashDateOrder.PurchaseOrder.PurchaseOrderHeader!.DateExpected);
        Assert.Null(slashDateOrder.PurchaseOrder.PurchaseOrderHeader.Instructions);
        Assert.Null(slashDateOrder.PurchaseOrder.PurchaseOrderHeader.Narrative);

        Assert.Equal(
            "Coordinate, quoted",
            FindOrder(result, "1003").PurchaseOrder.PurchaseOrderHeader!.Instructions);
        Assert.Equal(
            "Say \"ready\"",
            FindOrder(result, "1004").PurchaseOrder.PurchaseOrderHeader!.Instructions);
    }

    [Fact]
    public void Process_WhenUnknownColumnIsPresent_IgnoresIt()
    {
        using var stream = Csv(
            " ORDER_NUMBER , Supplier ,LOCATION, Product ,EFFECTIVE_QUANTITY,order_type,unknown_column\n" +
            " 1001 , SUP-1 , 10 , PROD-A , 2 ,normal,ignored\n");

        var result = _processor.Process(stream);

        Assert.Equal(1, result.ParsedRowCount);
        var order = Assert.Single(result.PurchaseOrders);
        Assert.Equal("1001", order.PurchaseOrder.PurchaseOrderHeader!.Reference);
        Assert.Equal(PurchaseOrderType.Stock, order.PurchaseOrder.PurchaseOrderHeader.OrderType);
    }

    [Fact]
    public void Process_LeavesInputStreamOpen()
    {
        using var stream = Csv(ValidMinimalCsv());

        _processor.Process(stream);

        Assert.True(stream.CanRead);
        stream.Position = 0;
        Assert.NotEqual(-1, stream.ReadByte());
    }

    [Fact]
    public void Process_WhenFileIsEmpty_ThrowsSafeError()
    {
        using var stream = Csv(string.Empty);

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_EMPTY_FILE",
            "Relex CSV file is empty.",
            recordNumber: null,
            fieldName: null);
    }

    [Fact]
    public void Process_WhenFileHasOnlyHeader_ThrowsSafeError()
    {
        using var stream = Csv(
            "order_number,supplier,location,product,effective_quantity\n");

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_NO_DATA_ROWS",
            "Relex CSV file has no data rows.",
            recordNumber: null,
            fieldName: null);
    }

    [Theory]
    [InlineData("supplier,location,product,effective_quantity", "order_number")]
    [InlineData("order_number,location,product,effective_quantity", "supplier")]
    [InlineData("order_number,supplier,product,effective_quantity", "location")]
    [InlineData("order_number,supplier,location,effective_quantity", "product")]
    [InlineData("order_number,supplier,location,product", "effective_quantity")]
    public void Process_WhenRequiredHeaderIsMissing_ThrowsSafeError(
        string headers,
        string missingHeader)
    {
        using var stream = Csv($"{headers}\nvalues\n");

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_MISSING_HEADER",
            "A required Relex CSV header is missing.",
            1,
            missingHeader);
    }

    [Fact]
    public void Process_WhenKnownHeaderIsDuplicated_ThrowsSafeError()
    {
        using var stream = Csv(
            "order_number,supplier,location,product,effective_quantity, PRODUCT \n" +
            "1001,SUP-1,10,PROD-A,2,PROD-B\n");

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_DUPLICATE_HEADER",
            "A Relex CSV header is duplicated.",
            1,
            "product");
    }

    [Fact]
    public void Process_WhenCsvRecordIsMalformed_ThrowsSafeErrorWithoutRawRow()
    {
        const string secretMarker = "DO-NOT-EXPOSE";
        using var stream = Csv(
            "order_number,supplier,location,product,effective_quantity\n" +
            $"1001,SUP-1,10,\"{secretMarker},2\n");

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_MALFORMED_CSV",
            "Relex CSV record is malformed.",
            2,
            null);
        Assert.DoesNotContain(secretMarker, exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void Process_WhenRequiredValueIsMissing_ThrowsSafeError()
    {
        using var stream = Csv(
            "order_number,supplier,location,product,effective_quantity\n" +
            ",SUP-1,10,PROD-A,2\n");

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_MISSING_VALUE",
            "A required Relex CSV value is missing.",
            2,
            "order_number");
    }

    [Theory]
    [InlineData("location", "not-an-int")]
    [InlineData("effective_quantity", "1.5")]
    [InlineData("effective_quantity", "0")]
    [InlineData("delivery_date", "08/21/2026")]
    [InlineData("purchase_price", "12,5")]
    [InlineData("order_type", "DIRECT")]
    [InlineData("tally_q_1", "0")]
    [InlineData("tally_l_1", "invalid")]
    public void Process_WhenValueIsInvalid_ThrowsSafeError(
        string fieldName,
        string invalidValue)
    {
        var values = ValidValues();
        values[fieldName] = invalidValue;
        using var stream = Csv(CreateCsv(values));

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_INVALID_VALUE",
            "A Relex CSV value is invalid.",
            2,
            fieldName);
    }

    [Theory]
    [InlineData("tally_q_1", "")]
    [InlineData("tally_l_1", "")]
    public void Process_WhenTallyPairIsPartial_ThrowsMissingValue(
        string missingField,
        string missingValue)
    {
        var values = ValidValues();
        values[missingField] = missingValue;
        using var stream = Csv(CreateCsv(values));

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_MISSING_VALUE",
            "A required Relex CSV value is missing.",
            2,
            missingField);
    }

    [Theory]
    [InlineData("supplier", "SUP-CHANGED")]
    [InlineData("location", "11")]
    [InlineData("send_run_id", "RUN-CHANGED")]
    [InlineData("delivery_date", "2026-08-21")]
    [InlineData("coordination_group_description", "Changed")]
    [InlineData("comment_1", "Changed")]
    [InlineData("order_type", "")]
    public void Process_WhenOrderHeaderValueChanges_ThrowsInconsistentOrder(
        string changedField,
        string changedValue)
    {
        var first = ValidValues();
        var second = ValidValues();
        second["product"] = "PROD-B";
        second[changedField] = changedValue;
        using var stream = Csv(CreateCsv(first, second));

        var exception = Assert.Throws<RelexPurchaseOrderFileException>(
            () => _processor.Process(stream));

        AssertError(
            exception,
            "RELEX_INCONSISTENT_ORDER",
            "Rows for one Relex order have inconsistent header values.",
            3,
            changedField);
    }

    [Fact]
    public void Process_WhenCancellationIsRequested_StopsBeforeReadingData()
    {
        using var stream = Csv(ValidMinimalCsv());
        using var cancellationSource = new CancellationTokenSource();
        cancellationSource.Cancel();

        Assert.Throws<OperationCanceledException>(() =>
            _processor.Process(stream, cancellationSource.Token));
    }

    private static ParsedRelexPurchaseOrder FindOrder(
        RelexFileProcessingResult result,
        string reference) =>
        Assert.Single(
            result.PurchaseOrders,
            order => order.PurchaseOrder.PurchaseOrderHeader!.Reference == reference);

    private static MemoryStream Csv(string value) =>
        new(Encoding.UTF8.GetBytes(value));

    private static string ValidMinimalCsv() =>
        "order_number,supplier,location,product,effective_quantity\n" +
        "1001,SUP-1,10,PROD-A,2\n";

    private static Dictionary<string, string> ValidValues() => new()
    {
        ["order_number"] = "1001",
        ["supplier"] = "SUP-1",
        ["location"] = "10",
        ["product"] = "PROD-A",
        ["effective_quantity"] = "2",
        ["send_run_id"] = "RUN-1",
        ["delivery_date"] = "2026-08-20",
        ["coordination_group_description"] = "Coordinate A",
        ["comment_1"] = "Comment A",
        ["uom"] = "EA",
        ["purchase_price"] = "12.5",
        ["order_type"] = "NORMAL",
        ["tally_q_1"] = "3",
        ["tally_l_1"] = "2400"
    };

    private static string CreateCsv(params Dictionary<string, string>[] rows)
    {
        var headers = rows[0].Keys.ToArray();
        var lines = new List<string> { string.Join(',', headers) };
        lines.AddRange(rows.Select(row =>
            string.Join(',', headers.Select(header => EscapeCsv(row[header])))));
        return string.Join('\n', lines) + "\n";
    }

    private static string EscapeCsv(string value) =>
        value.IndexOfAny([',', '"', '\r', '\n']) >= 0
            ? $"\"{value.Replace("\"", "\"\"")}\""
            : value;

    private static void AssertError(
        RelexPurchaseOrderFileException exception,
        string code,
        string message,
        int? recordNumber,
        string? fieldName)
    {
        Assert.Equal(code, exception.Code);
        Assert.Equal(message, exception.Message);
        Assert.Equal(recordNumber, exception.RecordNumber);
        Assert.Equal(fieldName, exception.FieldName);
    }
}
