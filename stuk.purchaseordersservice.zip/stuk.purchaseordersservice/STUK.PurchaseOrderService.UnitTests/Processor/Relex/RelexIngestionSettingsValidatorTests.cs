using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Processor.Relex.Configuration;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class RelexIngestionSettingsValidatorTests
{
    private readonly RelexIngestionSettingsValidator _validator = new();

    [Fact]
    public void Validate_WhenLocalSettingsAreValid_Succeeds()
    {
        var result = _validator.Validate(
            RelexIngestionSettings.SectionName,
            ValidLocalSettings());

        Assert.True(result.Succeeded);
    }

    [Fact]
    public void Validate_WhenSftpPasswordSettingsAreValid_Succeeds()
    {
        var result = _validator.Validate(
            RelexIngestionSettings.SectionName,
            ValidSftpSettings());

        Assert.True(result.Succeeded);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    public void Validate_WhenSftpPasswordIsMissing_Fails(string? password)
    {
        var settings = ValidSftpSettings() with
        {
            SftpPassword = password
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        AssertFailure(
            result,
            "RelexIngestionSettings:SftpPassword is required for the Sftp provider.");
    }

    [Theory]
    [InlineData("input")]
    [InlineData("/data/../input")]
    [InlineData("/data/./input")]
    public void Validate_WhenLogicalInputPathIsUnsafe_Fails(string inputPath)
    {
        var settings = ValidLocalSettings() with
        {
            InputPath = inputPath
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        AssertFailure(
            result,
            "RelexIngestionSettings:InputPath must be an absolute logical path without dot segments.");
    }

    [Fact]
    public void Validate_WhenLogicalPathsOverlap_Fails()
    {
        var settings = ValidLocalSettings() with
        {
            ArchivePath = "/data/input/archive"
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        AssertFailure(
            result,
            "RelexIngestionSettings logical paths must not overlap.");
    }

    [Theory]
    [InlineData("")]
    [InlineData("data/*.csv")]
    [InlineData("data\\*.csv")]
    public void Validate_WhenFilePatternIsBlankOrContainsPathSeparator_Fails(
        string filePattern)
    {
        var settings = ValidLocalSettings() with
        {
            FilePattern = filePattern
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        AssertFailure(
            result,
            "RelexIngestionSettings:FilePattern must be a file-name pattern without path separators.");
    }

    [Fact]
    public void Validate_WhenMinimumFileAgeIsNegative_Fails()
    {
        var settings = ValidLocalSettings() with
        {
            MinimumFileAgeSeconds = -1
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        AssertFailure(
            result,
            "RelexIngestionSettings:MinimumFileAgeSeconds cannot be negative.");
    }

    [Theory]
    [InlineData(0)]
    [InlineData(301)]
    public void Validate_WhenOperationTimeoutIsOutsideSupportedRange_Fails(
        int timeoutSeconds)
    {
        var settings = ValidLocalSettings() with
        {
            OperationTimeoutSeconds = timeoutSeconds
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        AssertFailure(
            result,
            "RelexIngestionSettings:OperationTimeoutSeconds must be between 1 and 300.");
    }

    [Fact]
    public void Validate_WhenLocalRootIsRelative_Fails()
    {
        var settings = ValidLocalSettings() with
        {
            LocalRootPath = "relative-root"
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        AssertFailure(
            result,
            "RelexIngestionSettings:LocalRootPath must be fully qualified for the Local provider.");
    }

    [Theory]
    [InlineData(null, "relex-user")]
    [InlineData("sftp.example.test", null)]
    public void Validate_WhenSftpHostOrUsernameIsMissing_Fails(
        string? host,
        string? username)
    {
        var settings = ValidSftpSettings() with
        {
            SftpHost = host,
            SftpUsername = username
        };

        var result = _validator.Validate(RelexIngestionSettings.SectionName, settings);

        Assert.False(result.Succeeded);
    }

    private static RelexIngestionSettings ValidLocalSettings() => new()
    {
        Provider = RelexFileStoreProvider.Local,
        InputPath = "/data/input",
        ArchivePath = "/data/output/archive",
        ErrorPath = "/data/output/error",
        FilePattern = "SG_OrderProposal*.csv",
        MinimumFileAgeSeconds = 120,
        Actor = "RelexIngestionFunction",
        LocalRootPath = Path.GetFullPath(Path.GetTempPath()),
        OperationTimeoutSeconds = 60
    };

    private static RelexIngestionSettings ValidSftpSettings() => new()
    {
        Provider = RelexFileStoreProvider.Sftp,
        InputPath = "/data/input",
        ArchivePath = "/data/output/archive",
        ErrorPath = "/data/output/error",
        FilePattern = "SG_OrderProposal*.csv",
        MinimumFileAgeSeconds = 120,
        Actor = "RelexIngestionFunction",
        SftpHost = "sftp.example.test",
        SftpPort = 22,
        SftpUsername = "relex-user",
        SftpPassword = "test-password",
        OperationTimeoutSeconds = 60
    };

    private static void AssertFailure(
        Microsoft.Extensions.Options.ValidateOptionsResult result,
        string expectedFailure)
    {
        Assert.False(result.Succeeded);
        Assert.Contains(
            expectedFailure,
            Assert.IsAssignableFrom<IEnumerable<string>>(result.Failures));
    }
}
