using STUK.PurchaseOrderService.Processor.Relex.Processing;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class RelexCandidateIdTests
{
    [Fact]
    public void Create_WhenInputsAreTheSame_ReturnsStableNonEmptyId()
    {
        var batchId = Guid.Parse("28fe92bb-f301-47aa-bc0a-b3d1f745cfef");

        var first = RelexCandidateId.Create(batchId, " 1001 ");
        var second = RelexCandidateId.Create(batchId, "1001");

        Assert.NotEqual(Guid.Empty, first);
        Assert.Equal(first, second);
    }

    [Fact]
    public void Create_WhenBatchOrOrderChanges_ReturnsDifferentIds()
    {
        var batchId = Guid.Parse("28fe92bb-f301-47aa-bc0a-b3d1f745cfef");
        var otherBatchId = Guid.Parse("dc0344a2-af65-4fb4-a9c7-788f1ae3b6ec");

        var original = RelexCandidateId.Create(batchId, "1001");

        Assert.NotEqual(original, RelexCandidateId.Create(otherBatchId, "1001"));
        Assert.NotEqual(original, RelexCandidateId.Create(batchId, "1002"));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void Create_WhenOrderNumberIsBlank_Throws(string? orderNumber)
    {
        Assert.ThrowsAny<ArgumentException>(() =>
            RelexCandidateId.Create(Guid.NewGuid(), orderNumber!));
    }
}
