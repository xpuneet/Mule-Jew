using System.Security.Cryptography;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.Processor.Relex.Files;
using STUK.PurchaseOrderService.Processor.Relex.Parsing;
using STUK.PurchaseOrderService.Processor.Relex.Processing;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class RelexLocalIngestionIntegrationTests
{
    private static readonly DateTimeOffset FixedNow =
        new(2026, 8, 17, 12, 0, 0, TimeSpan.Zero);

    [Fact]
    public async Task RunAsync_ValidFixture_PersistsFiveCandidatesAndArchivesFile()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository
        {
            BeforeComplete = () => Assert.True(File.Exists(workspace.ArchiveFilePath))
        };
        var service = CreateService(workspace.Store, repository, workspace.RootPath);

        var result = await service.RunAsync();

        Assert.Equal(1, result.Archived);
        Assert.False(File.Exists(inputPath));
        Assert.True(File.Exists(workspace.ArchiveFilePath));
        Assert.Equal(5, repository.AddCommands.Count);
        Assert.Equal(5, repository.CandidateCount);
        Assert.Equal(6, repository.AddCommands.Sum(command => command.SourceRowCount));
        var completion = Assert.Single(repository.CompleteCommands);
        Assert.Equal(5, completion.ExpectedCandidateCount);
        Assert.Equal(6, completion.ParsedRowCount);
        Assert.Equal(PurchaseOrderBatchStatuses.Completed, repository.SingleBatch.Status);
        var registration = Assert.Single(repository.RegisterCommands);
        Assert.Equal("/data/input/SG_OrderProposal_synthetic.csv", registration.SourceFilePath);
        Assert.Equal(new FileInfo(workspace.ArchiveFilePath).Length, registration.FileContentLength);
        Assert.Equal(FixedNow, registration.DiscoveredDateTime);
        Assert.Equal(32, registration.FileSha256.Length);
        Assert.Empty(Directory.EnumerateFiles(workspace.RootPath, "stuk-relex-*.tmp"));
    }

    [Fact]
    public async Task RunAsync_InvalidFixture_FailsBatchAndMovesFileToError()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.WriteInput(string.Empty);
        var repository = new InMemoryBatchRepository
        {
            BeforeFail = () => Assert.True(File.Exists(workspace.ErrorFilePath))
        };
        var service = CreateService(workspace.Store, repository, workspace.RootPath);

        var result = await service.RunAsync();

        Assert.Equal(1, result.FailedFiles);
        Assert.False(File.Exists(inputPath));
        Assert.True(File.Exists(workspace.ErrorFilePath));
        var failure = Assert.Single(repository.FailCommands);
        Assert.Equal("RELEX_EMPTY_FILE", failure.FailureCode);
        Assert.Equal("Relex CSV file is empty.", failure.FailureDescription);
        Assert.Empty(repository.AddCommands);
        Assert.Empty(Directory.EnumerateFiles(workspace.RootPath, "stuk-relex-*.tmp"));
    }

    [Fact]
    public async Task RunAsync_PersistenceFailure_LeavesInputAndDeletesScratchFile()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository
        {
            AddException = new TimeoutException("synthetic SQL timeout")
        };
        var service = CreateService(workspace.Store, repository, workspace.RootPath);

        var result = await service.RunAsync();

        Assert.Equal(1, result.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.False(File.Exists(workspace.ArchiveFilePath));
        Assert.False(File.Exists(workspace.ErrorFilePath));
        Assert.Empty(Directory.EnumerateFiles(workspace.RootPath, "stuk-relex-*.tmp"));
    }

    [Fact]
    public async Task RunAsync_ArchiveMoveFails_LeavesBatchIngestingAndSecondRunReplaysIdempotently()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository();
        var firstService = CreateService(
            new ArchiveMoveFailingFileStore(workspace.Store),
            repository,
            workspace.RootPath);

        var firstResult = await firstService.RunAsync();

        Assert.Equal(1, firstResult.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.Equal(5, repository.AddCommands.Count);
        Assert.Equal(PurchaseOrderBatchStatuses.Ingesting, repository.SingleBatch.Status);
        Assert.Empty(repository.CompleteCommands);

        var secondService = CreateService(workspace.Store, repository, workspace.RootPath);
        var secondResult = await secondService.RunAsync();

        Assert.Equal(1, secondResult.Archived);
        Assert.False(File.Exists(inputPath));
        Assert.True(File.Exists(workspace.ArchiveFilePath));
        Assert.Equal(10, repository.AddCommands.Count);
        Assert.Equal(5, repository.CandidateCount);
        Assert.Single(repository.CompleteCommands);
        Assert.Equal(2, repository.RegisterCommands.Count);
        Assert.Equal(1, repository.GetByHashCallCount);
    }

    [Fact]
    public async Task RunAsync_PartiallyPersistedIngestingBatch_ReplaysCandidatesIdempotently()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository
        {
            AddException = new TimeoutException("synthetic SQL timeout"),
            AddFailureAfterSuccessfulCandidates = 2
        };
        var firstService = CreateService(workspace.Store, repository, workspace.RootPath);

        var firstResult = await firstService.RunAsync();

        Assert.Equal(1, firstResult.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.Equal(2, repository.CandidateCount);

        repository.AddException = null;
        var secondService = CreateService(workspace.Store, repository, workspace.RootPath);
        var secondResult = await secondService.RunAsync();

        Assert.Equal(1, secondResult.Archived);
        Assert.Equal(5, repository.CandidateCount);
        Assert.Equal(7, repository.AddCommands.Count);
        var completion = Assert.Single(repository.CompleteCommands);
        Assert.Equal(5, completion.ExpectedCandidateCount);
        Assert.Equal(6, completion.ParsedRowCount);
    }

    [Fact]
    public async Task RunAsync_ExistingCompletedBatch_MovesWithoutParsingAgain()
    {
        using var workspace = new LocalWorkspace();
        workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository();
        await CreateService(workspace.Store, repository, workspace.RootPath).RunAsync();
        repository.SetStatus(PurchaseOrderBatchStatuses.Completed);
        workspace.CopyFixtureToInput();
        var addCount = repository.AddCommands.Count;

        var result = await CreateService(
            workspace.Store,
            repository,
            workspace.RootPath).RunAsync();

        Assert.Equal(1, result.Archived);
        Assert.Equal(addCount, repository.AddCommands.Count);
        Assert.True(File.Exists(workspace.HashQualifiedArchiveFilePath));
    }

    [Fact]
    public async Task RunAsync_ExistingFailedBatch_MovesToErrorWithoutFailingAgain()
    {
        using var workspace = new LocalWorkspace();
        workspace.WriteInput(string.Empty);
        var repository = new InMemoryBatchRepository();
        await CreateService(workspace.Store, repository, workspace.RootPath).RunAsync();
        workspace.WriteInput(string.Empty);

        var result = await CreateService(
            workspace.Store,
            repository,
            workspace.RootPath).RunAsync();

        Assert.Equal(1, result.FailedFiles);
        Assert.Single(repository.FailCommands);
        Assert.True(File.Exists(workspace.HashQualifiedErrorFilePath));
    }

    [Fact]
    public async Task RunAsync_BothArchiveDestinationsExist_LeavesInput()
    {
        using var workspace = new LocalWorkspace();
        workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository();
        await CreateService(workspace.Store, repository, workspace.RootPath).RunAsync();
        var inputPath = workspace.CopyFixtureToInput();
        File.WriteAllText(workspace.HashQualifiedArchiveFilePath, "occupied");

        var result = await CreateService(
            workspace.Store,
            repository,
            workspace.RootPath).RunAsync();

        Assert.Equal(1, result.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.Equal(5, repository.AddCommands.Count);
    }

    [Fact]
    public async Task RunAsync_DownloadFails_LeavesInputAndDeletesScratchFile()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository();
        var service = CreateService(
            new DownloadFailingFileStore(workspace.Store),
            repository,
            workspace.RootPath);

        var result = await service.RunAsync();

        Assert.Equal(1, result.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.Empty(repository.RegisterCommands);
        Assert.Empty(Directory.EnumerateFiles(workspace.RootPath, "stuk-relex-*.tmp"));
    }

    [Fact]
    public async Task RunAsync_ScratchCreationFails_LeavesInputUnregistered()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository();
        var service = CreateService(
            workspace.Store,
            repository,
            workspace.RootPath,
            temporaryFileFactory: new FailingTemporaryFileFactory());

        var result = await service.RunAsync();

        Assert.Equal(1, result.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.Empty(repository.RegisterCommands);
    }

    [Fact]
    public async Task RunAsync_ErrorMoveFails_LeavesBatchIngestingAndRetryFailsIt()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.WriteInput(string.Empty);
        var repository = new InMemoryBatchRepository();
        var firstService = CreateService(
            new ErrorMoveFailingFileStore(workspace.Store),
            repository,
            workspace.RootPath);

        var firstResult = await firstService.RunAsync();

        Assert.Equal(1, firstResult.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.Equal(PurchaseOrderBatchStatuses.Ingesting, repository.SingleBatch.Status);
        Assert.Empty(repository.FailCommands);
        Assert.Empty(Directory.EnumerateFiles(workspace.RootPath, "stuk-relex-*.tmp"));

        var secondResult = await CreateService(
            workspace.Store,
            repository,
            workspace.RootPath).RunAsync();

        Assert.Equal(1, secondResult.FailedFiles);
        Assert.False(File.Exists(inputPath));
        Assert.True(File.Exists(workspace.ErrorFilePath));
        Assert.Single(repository.FailCommands);
    }

    [Fact]
    public async Task RunAsync_CompletionPersistenceFailsAfterArchive_RestoresInputForRetry()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var recordingStore = new RecordingFileStore(workspace.Store);
        var repository = new InMemoryBatchRepository
        {
            CompleteException = new TimeoutException("synthetic completion timeout")
        };
        var service = CreateService(recordingStore, repository, workspace.RootPath);

        var result = await service.RunAsync();

        Assert.Equal(1, result.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.False(File.Exists(workspace.ArchiveFilePath));
        Assert.Equal(PurchaseOrderBatchStatuses.Ingesting, repository.SingleBatch.Status);
        Assert.Single(repository.CompleteCommands);
        Assert.Collection(
            recordingStore.Moves,
            move =>
            {
                Assert.Equal("/data/input/SG_OrderProposal_synthetic.csv", move.Source);
                Assert.Equal("/data/output/archive/SG_OrderProposal_synthetic.csv", move.Destination);
            },
            move =>
            {
                Assert.Equal("/data/output/archive/SG_OrderProposal_synthetic.csv", move.Source);
                Assert.Equal("/data/input/SG_OrderProposal_synthetic.csv", move.Destination);
            });
    }

    [Fact]
    public async Task RunAsync_FailurePersistenceFailsAfterErrorMove_RestoresInputForRetry()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.WriteInput(string.Empty);
        var recordingStore = new RecordingFileStore(workspace.Store);
        var repository = new InMemoryBatchRepository
        {
            FailException = new TimeoutException("synthetic failure timeout")
        };
        var service = CreateService(recordingStore, repository, workspace.RootPath);

        var result = await service.RunAsync();

        Assert.Equal(1, result.TransientFailures);
        Assert.True(File.Exists(inputPath));
        Assert.False(File.Exists(workspace.ErrorFilePath));
        Assert.Equal(PurchaseOrderBatchStatuses.Ingesting, repository.SingleBatch.Status);
        Assert.Single(repository.FailCommands);
        Assert.Collection(
            recordingStore.Moves,
            move =>
            {
                Assert.Equal("/data/input/SG_OrderProposal_synthetic.csv", move.Source);
                Assert.Equal("/data/output/error/SG_OrderProposal_synthetic.csv", move.Destination);
            },
            move =>
            {
                Assert.Equal("/data/output/error/SG_OrderProposal_synthetic.csv", move.Source);
                Assert.Equal("/data/input/SG_OrderProposal_synthetic.csv", move.Destination);
            });
    }

    [Fact]
    public async Task RunAsync_CancellationDuringPersistence_PropagatesAndDeletesScratchFile()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository
        {
            AddException = new OperationCanceledException("synthetic cancellation")
        };
        var service = CreateService(workspace.Store, repository, workspace.RootPath);

        await Assert.ThrowsAsync<OperationCanceledException>(() => service.RunAsync());

        Assert.True(File.Exists(inputPath));
        Assert.Empty(Directory.EnumerateFiles(workspace.RootPath, "stuk-relex-*.tmp"));
    }

    [Fact]
    public async Task RunAsync_Success_LogsOnlyStructuredOperationalMetadata()
    {
        using var workspace = new LocalWorkspace();
        workspace.CopyFixtureToInput();
        var repository = new InMemoryBatchRepository();
        var logger = new CapturingLogger<RelexIngestionService>();
        var service = CreateService(
            workspace.Store,
            repository,
            workspace.RootPath,
            logger);

        await service.RunAsync();

        Assert.Contains(logger.Entries, entry => entry.HasFields(
            "FileName",
            "FilePath",
            "HashPrefix",
            "FileLength",
            "ResultCode"));
        Assert.Contains(logger.Entries, entry => entry.HasFields(
            "BatchId",
            "ParsedRowCount",
            "CandidateCount"));
        Assert.Contains(logger.Entries, entry => entry.HasFields(
            "Destination",
            "ElapsedMilliseconds"));
        var renderedLogs = string.Join(Environment.NewLine, logger.Entries.Select(
            entry => entry.Rendered));
        Assert.DoesNotContain("SUP-1", renderedLogs, StringComparison.Ordinal);
        Assert.DoesNotContain("PROD-A", renderedLogs, StringComparison.Ordinal);
        Assert.DoesNotContain("Coordinate A", renderedLogs, StringComparison.Ordinal);
        Assert.DoesNotContain("SftpPassword", renderedLogs, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("PrivateKey", renderedLogs, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task RunAsync_ParserFailure_DoesNotLogRawInnerException()
    {
        using var workspace = new LocalWorkspace();
        workspace.WriteInput("synthetic");
        var repository = new InMemoryBatchRepository();
        var logger = new CapturingLogger<RelexIngestionService>();
        var service = CreateService(
            workspace.Store,
            repository,
            workspace.RootPath,
            logger,
            new ThrowingFileProcessor());

        var result = await service.RunAsync();

        Assert.Equal(1, result.FailedFiles);
        Assert.Equal("RELEX_MALFORMED_CSV", Assert.Single(repository.FailCommands).FailureCode);
        Assert.DoesNotContain(
            logger.Entries,
            entry => entry.Rendered.Contains("RAW-INNER-SECRET", StringComparison.Ordinal));
    }

    [Fact]
    public async Task RunAsync_FileYoungerThanMinimumAge_RemainsForNextRun()
    {
        using var workspace = new LocalWorkspace();
        var inputPath = workspace.CopyFixtureToInput(ageSeconds: 119);
        var repository = new InMemoryBatchRepository();
        var service = CreateService(workspace.Store, repository, workspace.RootPath);

        var result = await service.RunAsync();

        Assert.Equal(1, result.Deferred);
        Assert.True(File.Exists(inputPath));
        Assert.Empty(repository.RegisterCommands);
    }

    private static RelexIngestionService CreateService(
        IRelexFileStore fileStore,
        IPurchaseOrderBatchRepository repository,
        string scratchRoot,
        ILogger<RelexIngestionService>? logger = null,
        IRelexPurchaseOrderFileProcessor? fileProcessor = null,
        IRelexTemporaryFileFactory? temporaryFileFactory = null) =>
        new(
            fileStore,
            new RelexIngestionSettings
            {
                Provider = RelexFileStoreProvider.Local,
                InputPath = "/data/input",
                ArchivePath = "/data/output/archive",
                ErrorPath = "/data/output/error",
                FilePattern = "SG_OrderProposal*.csv",
                MinimumFileAgeSeconds = 120,
                Actor = "RelexIntegrationTest",
                LocalRootPath = scratchRoot
            },
            new FixedTimeProvider(FixedNow),
            logger ?? NullLogger<RelexIngestionService>.Instance,
            fileProcessor ?? new RelexPurchaseOrderFileProcessor(),
            repository,
            new RelexPurchaseOrderSerializer(),
            temporaryFileFactory ?? new RelexTemporaryFileFactory(scratchRoot));

    private sealed class ThrowingFileProcessor : IRelexPurchaseOrderFileProcessor
    {
        public RelexFileProcessingResult Process(
            Stream csvStream,
            CancellationToken cancellationToken = default) =>
            throw new RelexPurchaseOrderFileException(
                "RELEX_MALFORMED_CSV",
                "Relex CSV record is malformed.",
                innerException: new FormatException("RAW-INNER-SECRET"));
    }

    private sealed class CapturingLogger<T> : ILogger<T>
    {
        public List<CapturedLogEntry> Entries { get; } = [];

        public IDisposable? BeginScope<TState>(TState state)
            where TState : notnull =>
            NoOpScope.Instance;

        public bool IsEnabled(LogLevel logLevel) => true;

        public void Log<TState>(
            LogLevel logLevel,
            EventId eventId,
            TState state,
            Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            var properties = state is IEnumerable<KeyValuePair<string, object?>> values
                ? values.ToDictionary(pair => pair.Key, pair => pair.Value)
                : new Dictionary<string, object?>();
            var rendered = formatter(state, exception);
            if (exception is not null)
            {
                rendered = $"{rendered} {exception.GetType().Name}: {exception.Message}";
            }

            Entries.Add(new CapturedLogEntry(rendered, properties));
        }

        private sealed class NoOpScope : IDisposable
        {
            public static readonly NoOpScope Instance = new();

            public void Dispose()
            {
            }
        }
    }

    private sealed record CapturedLogEntry(
        string Rendered,
        IReadOnlyDictionary<string, object?> Properties)
    {
        public bool HasFields(params string[] names) =>
            names.All(Properties.ContainsKey);
    }

    private sealed class LocalWorkspace : IDisposable
    {
        public LocalWorkspace()
        {
            RootPath = Path.Combine(
                Path.GetTempPath(),
                $"stuk-relex-integration-{Guid.NewGuid():N}");
            Directory.CreateDirectory(InputDirectory);
            Directory.CreateDirectory(ArchiveDirectory);
            Directory.CreateDirectory(ErrorDirectory);
            Store = new LocalRelexFileStore(RootPath);
        }

        public string RootPath { get; }

        public LocalRelexFileStore Store { get; }

        private string InputDirectory => Path.Combine(RootPath, "data", "input");

        private string ArchiveDirectory =>
            Path.Combine(RootPath, "data", "output", "archive");

        private string ErrorDirectory =>
            Path.Combine(RootPath, "data", "output", "error");

        public string ArchiveFilePath =>
            Path.Combine(ArchiveDirectory, "SG_OrderProposal_synthetic.csv");

        public string ErrorFilePath =>
            Path.Combine(ErrorDirectory, "SG_OrderProposal_synthetic.csv");

        public string HashQualifiedArchiveFilePath =>
            Path.Combine(ArchiveDirectory, HashQualifiedFileName());

        public string HashQualifiedErrorFilePath =>
            Path.Combine(
                ErrorDirectory,
                $"SG_OrderProposal_synthetic-{Convert.ToHexString(SHA256.HashData(Array.Empty<byte>()).AsSpan(0, 4)).ToLowerInvariant()}.csv");

        public string CopyFixtureToInput(double ageSeconds = 300)
        {
            var fixturePath = Path.Combine(
                AppContext.BaseDirectory,
                "TestData",
                "Relex",
                "SG_OrderProposal_synthetic.csv");
            var inputPath = Path.Combine(InputDirectory, "SG_OrderProposal_synthetic.csv");
            File.Copy(fixturePath, inputPath, overwrite: true);
            File.SetLastWriteTimeUtc(inputPath, FixedNow.AddSeconds(-ageSeconds).UtcDateTime);
            return inputPath;
        }

        private static string HashQualifiedFileName()
        {
            var fixturePath = Path.Combine(
                AppContext.BaseDirectory,
                "TestData",
                "Relex",
                "SG_OrderProposal_synthetic.csv");
            var hash = SHA256.HashData(File.ReadAllBytes(fixturePath));
            return $"SG_OrderProposal_synthetic-{Convert.ToHexString(hash.AsSpan(0, 4)).ToLowerInvariant()}.csv";
        }

        public string WriteInput(string content, double ageSeconds = 300)
        {
            var inputPath = Path.Combine(InputDirectory, "SG_OrderProposal_synthetic.csv");
            File.WriteAllText(inputPath, content);
            File.SetLastWriteTimeUtc(inputPath, FixedNow.AddSeconds(-ageSeconds).UtcDateTime);
            return inputPath;
        }

        public void Dispose()
        {
            if (Directory.Exists(RootPath))
            {
                Directory.Delete(RootPath, recursive: true);
            }
        }
    }

    private sealed class ArchiveMoveFailingFileStore(IRelexFileStore inner) : IRelexFileStore
    {
        public Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
            string directoryPath,
            CancellationToken cancellationToken) =>
            inner.ListFilesAsync(directoryPath, cancellationToken);

        public Task DownloadAsync(
            string sourcePath,
            Stream destination,
            CancellationToken cancellationToken) =>
            inner.DownloadAsync(sourcePath, destination, cancellationToken);

        public Task<bool> ExistsAsync(string path, CancellationToken cancellationToken) =>
            inner.ExistsAsync(path, cancellationToken);

        public Task MoveAsync(
            string sourcePath,
            string destinationPath,
            CancellationToken cancellationToken) =>
            destinationPath.StartsWith("/data/output/archive/", StringComparison.Ordinal)
                ? Task.FromException(new IOException("synthetic archive failure"))
                : inner.MoveAsync(sourcePath, destinationPath, cancellationToken);
    }

    private sealed class DownloadFailingFileStore(IRelexFileStore inner) : IRelexFileStore
    {
        public Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
            string directoryPath,
            CancellationToken cancellationToken) =>
            inner.ListFilesAsync(directoryPath, cancellationToken);

        public Task DownloadAsync(
            string sourcePath,
            Stream destination,
            CancellationToken cancellationToken) =>
            Task.FromException(new IOException("synthetic download failure"));

        public Task<bool> ExistsAsync(string path, CancellationToken cancellationToken) =>
            inner.ExistsAsync(path, cancellationToken);

        public Task MoveAsync(
            string sourcePath,
            string destinationPath,
            CancellationToken cancellationToken) =>
            inner.MoveAsync(sourcePath, destinationPath, cancellationToken);
    }

    private sealed class ErrorMoveFailingFileStore(IRelexFileStore inner) : IRelexFileStore
    {
        public Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
            string directoryPath,
            CancellationToken cancellationToken) =>
            inner.ListFilesAsync(directoryPath, cancellationToken);

        public Task DownloadAsync(
            string sourcePath,
            Stream destination,
            CancellationToken cancellationToken) =>
            inner.DownloadAsync(sourcePath, destination, cancellationToken);

        public Task<bool> ExistsAsync(string path, CancellationToken cancellationToken) =>
            inner.ExistsAsync(path, cancellationToken);

        public Task MoveAsync(
            string sourcePath,
            string destinationPath,
            CancellationToken cancellationToken) =>
            destinationPath.StartsWith("/data/output/error/", StringComparison.Ordinal)
                ? Task.FromException(new IOException("synthetic error move failure"))
                : inner.MoveAsync(sourcePath, destinationPath, cancellationToken);
    }

    private sealed class RecordingFileStore(IRelexFileStore inner) : IRelexFileStore
    {
        public List<(string Source, string Destination)> Moves { get; } = [];

        public Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
            string directoryPath,
            CancellationToken cancellationToken) =>
            inner.ListFilesAsync(directoryPath, cancellationToken);

        public Task DownloadAsync(
            string sourcePath,
            Stream destination,
            CancellationToken cancellationToken) =>
            inner.DownloadAsync(sourcePath, destination, cancellationToken);

        public Task<bool> ExistsAsync(string path, CancellationToken cancellationToken) =>
            inner.ExistsAsync(path, cancellationToken);

        public Task MoveAsync(
            string sourcePath,
            string destinationPath,
            CancellationToken cancellationToken)
        {
            Moves.Add((sourcePath, destinationPath));
            return inner.MoveAsync(sourcePath, destinationPath, cancellationToken);
        }
    }

    private sealed class FailingTemporaryFileFactory : IRelexTemporaryFileFactory
    {
        public ValueTask<RelexTemporaryFile> CreateAsync(
            CancellationToken cancellationToken) =>
            ValueTask.FromException<RelexTemporaryFile>(
                new IOException("synthetic scratch exhaustion"));
    }

    private sealed class InMemoryBatchRepository : IPurchaseOrderBatchRepository
    {
        private PurchaseOrderBatchDetails? _batch;
        private readonly HashSet<Guid> _candidateIds = [];
        private int _rowVersion;

        public Exception? AddException { get; set; }

        public Exception? CompleteException { get; init; }

        public Exception? FailException { get; init; }

        public Action? BeforeComplete { get; init; }

        public Action? BeforeFail { get; init; }

        public int? AddFailureAfterSuccessfulCandidates { get; init; }

        public List<RegisterPurchaseOrderBatchCommand> RegisterCommands { get; } = [];

        public List<AddPurchaseOrderCandidateToBatchCommand> AddCommands { get; } = [];

        public List<CompletePurchaseOrderBatchCommand> CompleteCommands { get; } = [];

        public List<FailPurchaseOrderBatchCommand> FailCommands { get; } = [];

        public int GetByHashCallCount { get; private set; }

        public int CandidateCount => _candidateIds.Count;

        public PurchaseOrderBatchDetails SingleBatch =>
            _batch ?? throw new InvalidOperationException("No batch was registered.");

        public Task<PurchaseOrderBatchState> RegisterBatchAsync(
            RegisterPurchaseOrderBatchCommand command,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            RegisterCommands.Add(command);
            if (_batch is not null)
            {
                throw SqlPersistenceExceptionMapper.Map(51005);
            }

            _batch = new PurchaseOrderBatchDetails(
                command.BatchId,
                PurchaseOrderSources.Relex,
                command.OriginalFileName,
                command.SourceFilePath,
                command.FileContentLength,
                command.FileSha256,
                PurchaseOrderBatchStatuses.Ingesting,
                command.ExpectedRowCount,
                0,
                0,
                null,
                null,
                command.DiscoveredDateTime,
                command.DiscoveredDateTime,
                null,
                command.Actor,
                command.DiscoveredDateTime,
                NextRowVersion());
            return Task.FromResult(
                new PurchaseOrderBatchState(_batch.BatchId, _batch.Status, _batch.RowVersion));
        }

        public Task AddCandidateAsync(
            AddPurchaseOrderCandidateToBatchCommand command,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (AddException is not null
                && (AddFailureAfterSuccessfulCandidates is null
                    || _candidateIds.Count >= AddFailureAfterSuccessfulCandidates))
            {
                throw AddException;
            }

            AddCommands.Add(command);
            if (_candidateIds.Add(command.CandidateId))
            {
                _batch = SingleBatch with
                {
                    CandidateCount = SingleBatch.CandidateCount + 1,
                    ParsedRowCount = SingleBatch.ParsedRowCount + command.SourceRowCount,
                    UpdatedDateTime = command.AcceptedDateTime,
                    RowVersion = NextRowVersion()
                };
            }

            return Task.CompletedTask;
        }

        public Task<PurchaseOrderBatchPromotionResult> CompleteBatchAsync(
            CompletePurchaseOrderBatchCommand command,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            CompleteCommands.Add(command);
            BeforeComplete?.Invoke();
            if (CompleteException is not null)
            {
                throw CompleteException;
            }

            Assert.Equal(SingleBatch.CandidateCount, command.ExpectedCandidateCount);
            Assert.Equal(SingleBatch.ParsedRowCount, command.ParsedRowCount);
            _batch = SingleBatch with
            {
                Status = PurchaseOrderBatchStatuses.Completed,
                CompletedDateTime = command.CompletedDateTime,
                UpdatedDateTime = command.CompletedDateTime,
                RowVersion = NextRowVersion()
            };
            return Task.FromResult(new PurchaseOrderBatchPromotionResult(
                SingleBatch.BatchId,
                SingleBatch.Status,
                SingleBatch.CandidateCount,
                SingleBatch.RowVersion));
        }

        public Task<PurchaseOrderBatchState> FailBatchAsync(
            FailPurchaseOrderBatchCommand command,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            FailCommands.Add(command);
            BeforeFail?.Invoke();
            if (FailException is not null)
            {
                throw FailException;
            }

            _batch = SingleBatch with
            {
                Status = PurchaseOrderBatchStatuses.Failed,
                FailureCode = command.FailureCode,
                FailureDescription = command.FailureDescription,
                CompletedDateTime = command.FailedDateTime,
                UpdatedDateTime = command.FailedDateTime,
                RowVersion = NextRowVersion()
            };
            return Task.FromResult(new PurchaseOrderBatchState(
                SingleBatch.BatchId,
                SingleBatch.Status,
                SingleBatch.RowVersion));
        }

        public Task<PurchaseOrderBatchDetails> GetBatchAsync(
            Guid batchId,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Assert.Equal(SingleBatch.BatchId, batchId);
            return Task.FromResult(SingleBatch);
        }

        public Task<PurchaseOrderBatchDetails> GetBatchBySourceHashAsync(
            string source,
            byte[] fileSha256,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            GetByHashCallCount++;
            Assert.Equal(PurchaseOrderSources.Relex, source);
            Assert.True(SingleBatch.FileSha256.SequenceEqual(fileSha256));
            return Task.FromResult(SingleBatch);
        }

        public Task<IReadOnlyList<PurchaseOrderBatchOutcome>> GetBatchOutcomesAsync(
            Guid batchId,
            CancellationToken cancellationToken = default) =>
            throw new NotSupportedException();

        public void SetStatus(string status)
        {
            _batch = SingleBatch with
            {
                Status = status,
                RowVersion = NextRowVersion()
            };
        }

        private byte[] NextRowVersion() =>
            BitConverter.GetBytes(Interlocked.Increment(ref _rowVersion));
    }

    private sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => utcNow;
    }
}
