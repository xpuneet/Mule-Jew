using System.Text.Json;
using System.Text.Json.Serialization;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Processor.Relex.Processing;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class RelexPurchaseOrderSerializerTests
{
    [Fact]
    public void Serialize_UsesDeterministicWebJsonAndOmitsNulls()
    {
        var order = new PurchaseOrder
        {
            PurchaseOrderHeader = new PurchaseOrderHeader
            {
                Account = "SUP-1",
                Branch = 10,
                Reference = null,
                OrderType = PurchaseOrderType.Stock
            },
            PurchaseOrderLines =
            [
                new PurchaseOrderLine
                {
                    ProductId = "PROD-A",
                    Quantity = 2,
                    Unit = null
                }
            ]
        };
        var expected = JsonSerializer.Serialize(
            order,
            new JsonSerializerOptions(JsonSerializerDefaults.Web)
            {
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
            });
        var serializer = new RelexPurchaseOrderSerializer();

        var first = serializer.Serialize(order);
        var second = serializer.Serialize(order);

        Assert.Equal(expected, first);
        Assert.Equal(first, second);
        Assert.Contains("\"purchaseOrderHeader\"", first, StringComparison.Ordinal);
        Assert.Contains("\"orderType\":\"stock\"", first, StringComparison.Ordinal);
        Assert.DoesNotContain("\"reference\"", first, StringComparison.Ordinal);
        Assert.DoesNotContain(":null", first, StringComparison.Ordinal);
    }
}
