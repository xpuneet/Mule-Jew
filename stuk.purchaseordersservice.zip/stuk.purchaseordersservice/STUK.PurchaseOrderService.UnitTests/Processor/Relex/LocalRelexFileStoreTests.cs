using System.Text;
using STUK.PurchaseOrderService.Processor.Relex.Files;

namespace STUK.PurchaseOrderService.UnitTests.Processor.Relex;

public sealed class LocalRelexFileStoreTests
{
    [Fact]
    public async Task ListFilesAsync_ListsOnlyTopDirectoryFilesWithUtcMetadata()
    {
        await using var root = TemporaryDirectory.Create();
        var inputPath = root.Combine("data", "input");
        Directory.CreateDirectory(inputPath);
        Directory.CreateDirectory(root.Combine("data", "input", "nested"));

        var expectedLastModifiedUtc = new DateTime(
            2026,
            8,
            17,
            10,
            30,
            0,
            DateTimeKind.Utc);
        var visibleFile = root.Combine("data", "input", "one.csv");
        await File.WriteAllTextAsync(visibleFile, "content");
        File.SetLastWriteTimeUtc(visibleFile, expectedLastModifiedUtc);
        await File.WriteAllTextAsync(
            root.Combine("data", "input", "nested", "hidden.csv"),
            "nested");

        var store = new LocalRelexFileStore(root.Path);

        var files = await store.ListFilesAsync("/data/input", CancellationToken.None);

        var file = Assert.Single(files);
        Assert.Equal("/data/input/one.csv", file.Path);
        Assert.Equal("one.csv", file.Name);
        Assert.Equal(7, file.Length);
        Assert.Equal(expectedLastModifiedUtc, file.LastModifiedUtc.UtcDateTime);
        Assert.Equal(TimeSpan.Zero, file.LastModifiedUtc.Offset);
    }

    [Fact]
    public async Task DownloadAsync_CopiesFileIntoProvidedStream()
    {
        await using var root = TemporaryDirectory.Create();
        Directory.CreateDirectory(root.Combine("data", "input"));
        await File.WriteAllTextAsync(
            root.Combine("data", "input", "one.csv"),
            "streamed-content");
        var store = new LocalRelexFileStore(root.Path);
        await using var destination = new MemoryStream();

        await store.DownloadAsync(
            "/data/input/one.csv",
            destination,
            CancellationToken.None);

        Assert.Equal("streamed-content", Encoding.UTF8.GetString(destination.ToArray()));
    }

    [Fact]
    public async Task ExistsAsync_ReturnsWhetherLogicalPathExists()
    {
        await using var root = TemporaryDirectory.Create();
        Directory.CreateDirectory(root.Combine("data", "input"));
        await File.WriteAllTextAsync(root.Combine("data", "input", "one.csv"), "content");
        var store = new LocalRelexFileStore(root.Path);

        Assert.True(await store.ExistsAsync("/data/input/one.csv", CancellationToken.None));
        Assert.False(await store.ExistsAsync("/data/input/missing.csv", CancellationToken.None));
    }

    [Fact]
    public async Task MoveAsync_MovesBetweenLogicalFoldersWithoutOverwriting()
    {
        await using var root = TemporaryDirectory.Create();
        Directory.CreateDirectory(root.Combine("data", "input"));
        Directory.CreateDirectory(root.Combine("data", "output", "archive"));
        await File.WriteAllTextAsync(root.Combine("data", "input", "one.csv"), "content");

        var store = new LocalRelexFileStore(root.Path);
        await store.MoveAsync(
            "/data/input/one.csv",
            "/data/output/archive/one.csv",
            CancellationToken.None);

        Assert.False(File.Exists(root.Combine("data", "input", "one.csv")));
        Assert.True(File.Exists(root.Combine("data", "output", "archive", "one.csv")));

        await File.WriteAllTextAsync(root.Combine("data", "input", "two.csv"), "new");
        await File.WriteAllTextAsync(root.Combine("data", "output", "archive", "two.csv"), "old");

        await Assert.ThrowsAsync<IOException>(() => store.MoveAsync(
            "/data/input/two.csv",
            "/data/output/archive/two.csv",
            CancellationToken.None));
        Assert.Equal(
            "old",
            await File.ReadAllTextAsync(root.Combine("data", "output", "archive", "two.csv")));
    }

    [Fact]
    public async Task MoveAsync_WhenDestinationDirectoryIsMissing_FailsWithoutCreatingIt()
    {
        await using var root = TemporaryDirectory.Create();
        Directory.CreateDirectory(root.Combine("data", "input"));
        await File.WriteAllTextAsync(root.Combine("data", "input", "one.csv"), "content");
        var store = new LocalRelexFileStore(root.Path);

        await Assert.ThrowsAsync<DirectoryNotFoundException>(() => store.MoveAsync(
            "/data/input/one.csv",
            "/data/output/archive/one.csv",
            CancellationToken.None));

        Assert.False(Directory.Exists(root.Combine("data", "output", "archive")));
        Assert.True(File.Exists(root.Combine("data", "input", "one.csv")));
    }

    [Fact]
    public async Task ExistsAsync_WhenLogicalPathContainsTraversal_RejectsPath()
    {
        await using var root = TemporaryDirectory.Create();
        var store = new LocalRelexFileStore(root.Path);

        await Assert.ThrowsAsync<ArgumentException>(() =>
            store.ExistsAsync("../escape.csv", CancellationToken.None));
    }

    private sealed class TemporaryDirectory : IAsyncDisposable
    {
        private TemporaryDirectory(string path)
        {
            Path = path;
        }

        public string Path { get; }

        public static TemporaryDirectory Create()
        {
            var path = System.IO.Path.Combine(
                System.IO.Path.GetTempPath(),
                $"stuk-relex-test-{Guid.NewGuid():N}");
            Directory.CreateDirectory(path);
            return new TemporaryDirectory(path);
        }

        public string Combine(params string[] parts) =>
            System.IO.Path.Combine([Path, .. parts]);

        public ValueTask DisposeAsync()
        {
            if (Directory.Exists(Path))
            {
                Directory.Delete(Path, recursive: true);
            }

            return ValueTask.CompletedTask;
        }
    }
}
