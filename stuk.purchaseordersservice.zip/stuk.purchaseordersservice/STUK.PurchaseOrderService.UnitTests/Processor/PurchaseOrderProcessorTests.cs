using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Icon = STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Configuration;
using STUK.IconIntegration.Reports;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Mapping;
using STUK.PurchaseOrderService.Processor.Processing;
using STUK.PurchaseOrderService.Processor.Services;
using STUK.PurchaseOrderService.TestUtils.Builders;
using System.Text.Json;

namespace STUK.PurchaseOrderService.UnitTests.Processor;

public sealed class PurchaseOrderProcessorTests
{
    private static readonly DateTimeOffset FixedUtcNow =
        new(2026, 8, 4, 10, 11, 12, TimeSpan.Zero);

    [Fact]
    public async Task ProcessReadyCandidatesAsync_ValidCandidate_CompletesInDurableDispatchOrder()
    {
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account),
            CreateResponse = SuccessfulCreateResponse()
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 1, 0), result);
        Assert.Equal(
            ["expire", "claim", "activation", "map", "renew", "begin-dispatch", "icon", "complete"],
            events);
        var claim = Assert.Single(repository.ClaimCommands);
        Assert.Equal(1, claim.MaxCandidates);
        Assert.Equal(120, claim.LeaseDurationSeconds);
        Assert.False(string.IsNullOrWhiteSpace(claim.WorkerId));

        var renewal = Assert.IsType<RenewPurchaseOrderClaimCommand>(repository.RenewCommand);
        Assert.Equal(candidate.CandidateId, renewal.CandidateId);
        Assert.Equal(candidate.LeaseToken, renewal.LeaseToken);
        Assert.Equal(claim.WorkerId, renewal.WorkerId);
        Assert.Equal(46, renewal.LeaseDurationSeconds);

        var dispatch = Assert.IsType<BeginPurchaseOrderSubmissionAttemptCommand>(repository.BeginCommand);
        Assert.Equal(candidate.CandidateId, dispatch.CandidateId);
        Assert.Equal(candidate.LeaseToken, dispatch.LeaseToken);
        Assert.Equal(claim.WorkerId, dispatch.WorkerId);
        Assert.Contains("\"contactID\":1", dispatch.RequestPayloadJson, StringComparison.Ordinal);
        Assert.Contains("\"activateAction\":\"activate\"", dispatch.RequestPayloadJson, StringComparison.Ordinal);

        var completed = Assert.IsType<CompletePurchaseOrderSubmissionCommand>(repository.CompleteCommand);
        Assert.Equal(dispatch.AttemptId, completed.AttemptId);
        Assert.Equal("900001", completed.IconPurchaseOrderNumber);
        Assert.Equal("activated", completed.IconCreatedStatus);
        Assert.False(completed.IconSuspended);
        Assert.Contains("\"orderNo\":900001", completed.ResponsePayloadJson, StringComparison.Ordinal);
        Assert.Single(iconService.CreateRequests);
        Assert.Single(repository.ClaimCommands);
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_SubmissionDisabled_DoesNothing()
    {
        var events = new List<string>();
        var repository = new RecordingProcessingRepository(events, CandidateWithPayload(SerializeCanonicalOrder()));
        var iconService = new RecordingIconPurchaseOrderService(events);
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: false);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(0, 0, 0), result);
        Assert.Empty(events);
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_InvalidCanonicalJson_FailsBeforeDispatch()
    {
        var events = new List<string>();
        var repository = new RecordingProcessingRepository(events, CandidateWithPayload("{invalid-json"));
        var iconService = new RecordingIconPurchaseOrderService(events);
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 0, 1), result);
        Assert.Equal(["expire", "claim", "fail-pre-dispatch"], events);
        AssertPreDispatchFailure(
            repository,
            "NON_RECOVERABLE_ERROR",
            "CANONICAL_DESERIALIZATION",
            "CANONICAL_DESERIALIZATION_FAILED");
    }

    [Theory]
    [InlineData(0)]
    [InlineData(2)]
    public async Task ProcessReadyCandidatesAsync_ActivationCardinalityIsNotOne_FailsBeforeDispatch(
        int resultCount)
    {
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account, resultCount)
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 0, 1), result);
        Assert.Equal(["expire", "claim", "activation", "fail-pre-dispatch"], events);
        AssertPreDispatchFailure(
            repository,
            "NON_RECOVERABLE_ERROR",
            "ACTIVATION_OPTIONS",
            "ACTIVATION_OPTIONS_INVALID");
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_ActivationTransportFailure_IsRecoverableBeforeDispatch()
    {
        var events = new List<string>();
        var repository = new RecordingProcessingRepository(events, CandidateWithPayload(SerializeCanonicalOrder()));
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationException = new HttpRequestException("synthetic activation outage")
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 0, 1), result);
        Assert.Equal(["expire", "claim", "activation", "fail-pre-dispatch"], events);
        AssertPreDispatchFailure(
            repository,
            "RECOVERABLE_ERROR",
            "ACTIVATION_TRANSPORT",
            "ACTIVATION_REQUEST_FAILED");
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_MappingFailure_FailsBeforeDispatch()
    {
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account)
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper())
        {
            Exception = new PurchaseOrderIconMappingException("purchaseOrderHeader.contacts", "invalid")
        };
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 0, 1), result);
        Assert.Equal(["expire", "claim", "activation", "map", "fail-pre-dispatch"], events);
        AssertPreDispatchFailure(
            repository,
            "NON_RECOVERABLE_ERROR",
            "ICON_MAPPING",
            "ICON_MAPPING_FAILED");
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ProcessReadyCandidatesAsync_PostDispatchTransportOrCancellation_IsUnknownOutcome(
        bool cancellation)
    {
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account),
            CreateException = cancellation
                ? new OperationCanceledException("synthetic dispatch cancellation")
                : new HttpRequestException("synthetic dispatch outage")
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 0, 1), result);
        Assert.Equal(
            ["expire", "claim", "activation", "map", "renew", "begin-dispatch", "icon", "fail-submission"],
            events);
        AssertUnknownOutcome(repository, cancellation ? "ICON_DISPATCH_CANCELLED" : "ICON_TRANSPORT_FAILED");
        Assert.Single(repository.ClaimCommands);
        Assert.Single(iconService.CreateRequests);
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_InvalidSuccessfulBody_IsUnknownOutcome()
    {
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account),
            CreateResponse = new Icon.IconCreatePurchaseOrderResponse()
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 0, 1), result);
        AssertUnknownOutcome(repository, "ICON_RESPONSE_INVALID");
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_UnambiguousHttp4xx_IsTerminalFailedNotUnknown()
    {
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account),
            CreateException = new Icon.ApiException(
                "Synthetic bad request",
                400,
                "{\"detail\":\"synthetic validation failure\"}",
                new Dictionary<string, IEnumerable<string>>(),
                null)
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        var result = await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        Assert.Equal(new ProcessingResult(1, 0, 1), result);
        var failure = Assert.IsType<FailPurchaseOrderSubmissionCommand>(repository.FailSubmissionCommand);
        Assert.Equal("NON_RECOVERABLE_ERROR", failure.CandidateStatus);
        Assert.Equal("ICON_HTTP_ERROR", failure.FailureCategory);
        Assert.Equal("ICON_HTTP_400", failure.MessageCode);
        Assert.Equal((short)400, failure.HttpStatusCode);
        Assert.Equal("FAILED", failure.AttemptStatus);
        Assert.Equal(
            "{\"detail\":\"synthetic validation failure\"}",
            failure.ResponsePayloadJson);
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_NonJsonHttpError_PersistsValidJsonEnvelope()
    {
        const string rawResponse = "synthetic plain-text validation failure";
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account),
            CreateException = CreateApiException(rawResponse)
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        var failure = Assert.IsType<FailPurchaseOrderSubmissionCommand>(repository.FailSubmissionCommand);
        using var document = JsonDocument.Parse(Assert.IsType<string>(failure.ResponsePayloadJson));
        Assert.Equal(rawResponse, document.RootElement.GetProperty("rawResponse").GetString());
        Assert.False(document.RootElement.GetProperty("truncated").GetBoolean());
    }

    [Fact]
    public async Task ProcessReadyCandidatesAsync_OversizedHttpError_PersistsValidTruncatedJsonEnvelope()
    {
        var rawResponse = $"{{\"detail\":\"{new string('x', 20 * 1024)}\"}}";
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account),
            CreateException = CreateApiException(rawResponse)
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        var failure = Assert.IsType<FailPurchaseOrderSubmissionCommand>(repository.FailSubmissionCommand);
        var storedPayload = Assert.IsType<string>(failure.ResponsePayloadJson);
        Assert.True(storedPayload.Length <= 16 * 1024);
        using var document = JsonDocument.Parse(storedPayload);
        Assert.True(document.RootElement.GetProperty("truncated").GetBoolean());
        Assert.StartsWith(
            "{\"detail\":\"",
            document.RootElement.GetProperty("rawResponse").GetString(),
            StringComparison.Ordinal);
    }

    [Theory]
    [InlineData(0, null)]
    [InlineData(99, null)]
    [InlineData(500, 500)]
    [InlineData(599, 599)]
    [InlineData(600, null)]
    public async Task ProcessReadyCandidatesAsync_ApiExceptionStatus_PersistsOnlySqlHttpRange(
        int statusCode,
        int? expectedStatusCode)
    {
        var events = new List<string>();
        var candidate = CandidateWithPayload(SerializeCanonicalOrder());
        var repository = new RecordingProcessingRepository(events, candidate);
        var iconService = new RecordingIconPurchaseOrderService(events)
        {
            ActivationResponse = ActivationResponse(candidate.Account),
            CreateException = new Icon.ApiException(
                "Synthetic unusual status",
                statusCode,
                "{\"detail\":\"synthetic status\"}",
                new Dictionary<string, IEnumerable<string>>(),
                null)
        };
        var mapper = new RecordingPurchaseOrderIconMapper(events, new PurchaseOrderIconMapper());
        var processor = CreateProcessor(repository, iconService, mapper, submissionEnabled: true);

        await processor.ProcessReadyCandidatesAsync(CancellationToken.None);

        var failure = Assert.IsType<FailPurchaseOrderSubmissionCommand>(repository.FailSubmissionCommand);
        Assert.Equal(expectedStatusCode, failure.HttpStatusCode is null
            ? null
            : (int?)failure.HttpStatusCode.Value);
    }

    private static PurchaseOrderProcessor CreateProcessor(
        RecordingProcessingRepository repository,
        RecordingIconPurchaseOrderService iconService,
        RecordingPurchaseOrderIconMapper mapper,
        bool submissionEnabled)
    {
        return new PurchaseOrderProcessor(
            Options.Create(new BatchProcessorSettings
            {
                SubmissionEnabled = submissionEnabled,
                LeaseDurationSeconds = 120,
                OutcomePersistenceTimeoutSeconds = 15
            }),
            Options.Create(new IconSettings { HttpRequestTimeoutSeconds = 30 }),
            repository,
            iconService,
            mapper,
            NullLogger<PurchaseOrderProcessor>.Instance);
    }

    private static void AssertPreDispatchFailure(
        RecordingProcessingRepository repository,
        string status,
        string category,
        string code)
    {
        var failure = Assert.IsType<FailPurchaseOrderCandidatePreDispatchCommand>(
            repository.FailPreDispatchCommand);
        Assert.Equal(status, failure.CandidateStatus);
        Assert.Equal(category, failure.FailureCategory);
        Assert.Equal(code, failure.MessageCode);
        Assert.Null(repository.BeginCommand);
    }

    private static void AssertUnknownOutcome(
        RecordingProcessingRepository repository,
        string code)
    {
        var failure = Assert.IsType<FailPurchaseOrderSubmissionCommand>(repository.FailSubmissionCommand);
        Assert.Equal("NON_RECOVERABLE_ERROR", failure.CandidateStatus);
        Assert.Equal("ICON_UNKNOWN_OUTCOME", failure.FailureCategory);
        Assert.Equal(code, failure.MessageCode);
        Assert.Equal("UNKNOWN_OUTCOME", failure.AttemptStatus);
    }

    private static string SerializeCanonicalOrder()
    {
        var order = PurchaseOrderRequestBuilder.ValidPurchaseOrder();
        order.PurchaseOrderHeader!.CreateUser = "APIMIN_User";
        return System.Text.Json.JsonSerializer.Serialize(
            order,
            new JsonSerializerOptions(JsonSerializerDefaults.Web));
    }

    private static ClaimedPurchaseOrderCandidate CandidateWithPayload(string payload) => new(
        Guid.Parse("11111111-1111-4111-8111-111111111111"),
        "Relex",
        "BRIT186",
        "385",
        "20211108",
        "READY_FOR_SUBMISSION",
        payload,
        Guid.Parse("22222222-2222-4222-8222-222222222222"),
        FixedUtcNow.AddSeconds(120),
        [1, 0, 0, 0, 0, 0, 0, 0]);

    private static IconReportResponse<PurchaseOrderActivationOptionsResult> ActivationResponse(
        string account,
        int count = 1)
    {
        var results = Enumerable.Range(0, count)
            .Select(_ => new PurchaseOrderActivationOptionsResult
            {
                Account = account,
                ActivateAction = Icon.PurchaseOrderActivateAction.Activate,
                Bypass = false
            })
            .ToList();
        return new IconReportResponse<PurchaseOrderActivationOptionsResult>(results, "{}");
    }

    private static Icon.IconCreatePurchaseOrderResponse SuccessfulCreateResponse() => new()
    {
        Body = new Icon.IconCreatePurchaseOrderResponse_Body
        {
            OrderNo = 900001,
            CreatedStatus = Icon.PurchaseOrderCreatedStatus.Activated,
            Suspended = false,
            DeliveryMethod = new Icon.PurchaseOrderDeliveryMethodResponse
            {
                DeliveryMethodCode = Icon.PurchaseOrderDeliveryMethod.Delivered
            },
            ContactId = new Icon.PurchaseOrderContactIdResponse { ContactIdCode = 1 }
        }
    };

    private static Icon.ApiException CreateApiException(string response) => new(
        "Synthetic bad request",
        400,
        response,
        new Dictionary<string, IEnumerable<string>>(),
        null);

    private sealed class RecordingPurchaseOrderIconMapper(
        List<string> events,
        IPurchaseOrderIconMapper inner) : IPurchaseOrderIconMapper
    {
        public Exception? Exception { get; init; }

        public Icon.IconCreatePurchaseOrderRequest Map(
            PurchaseOrder purchaseOrder,
            PurchaseOrderActivationOptionsResult activationOptions)
        {
            events.Add("map");
            if (Exception is not null)
            {
                throw Exception;
            }

            return inner.Map(purchaseOrder, activationOptions);
        }
    }

    private sealed class RecordingIconPurchaseOrderService(List<string> events)
        : IIconPurchaseOrderService
    {
        public IconReportResponse<PurchaseOrderActivationOptionsResult>? ActivationResponse { get; init; }

        public Exception? ActivationException { get; init; }

        public Icon.IconCreatePurchaseOrderResponse? CreateResponse { get; init; }

        public Exception? CreateException { get; init; }

        public List<Icon.IconCreatePurchaseOrderRequest> CreateRequests { get; } = [];

        public Task<IconReportResponse<PurchaseOrderActivationOptionsResult>>
            GetPurchaseOrderActivationOptions(
                string account,
                CancellationToken cancellationToken = default)
        {
            events.Add("activation");
            if (ActivationException is not null)
            {
                return Task.FromException<IconReportResponse<PurchaseOrderActivationOptionsResult>>(
                    ActivationException);
            }

            return Task.FromResult(ActivationResponse ?? ActivationResponseForNoResults());
        }

        public Task<Icon.IconCreatePurchaseOrderResponse> CreatePurchaseOrderAsync(
            Icon.IconCreatePurchaseOrderRequest request,
            CancellationToken cancellationToken = default)
        {
            events.Add("icon");
            CreateRequests.Add(request);
            if (CreateException is not null)
            {
                return Task.FromException<Icon.IconCreatePurchaseOrderResponse>(CreateException);
            }

            return Task.FromResult(CreateResponse ?? SuccessfulCreateResponse());
        }

        private static IconReportResponse<PurchaseOrderActivationOptionsResult>
            ActivationResponseForNoResults() => new([], "{}");
    }

    private sealed class RecordingProcessingRepository(
        List<string> events,
        params ClaimedPurchaseOrderCandidate[] candidates) : IPurchaseOrderProcessingRepository
    {
        public List<ClaimPurchaseOrderCandidatesCommand> ClaimCommands { get; } = [];

        public RenewPurchaseOrderClaimCommand? RenewCommand { get; private set; }

        public BeginPurchaseOrderSubmissionAttemptCommand? BeginCommand { get; private set; }

        public FailPurchaseOrderCandidatePreDispatchCommand? FailPreDispatchCommand { get; private set; }

        public CompletePurchaseOrderSubmissionCommand? CompleteCommand { get; private set; }

        public FailPurchaseOrderSubmissionCommand? FailSubmissionCommand { get; private set; }

        public Task<ExpiredPurchaseOrderClaims> ExpireClaimsAsync(
            ExpirePurchaseOrderClaimsCommand command,
            CancellationToken cancellationToken = default)
        {
            events.Add("expire");
            return Task.FromResult(new ExpiredPurchaseOrderClaims(0, 0));
        }

        public Task<IReadOnlyList<ClaimedPurchaseOrderCandidate>> ClaimCandidatesAsync(
            ClaimPurchaseOrderCandidatesCommand command,
            CancellationToken cancellationToken = default)
        {
            events.Add("claim");
            ClaimCommands.Add(command);
            return Task.FromResult<IReadOnlyList<ClaimedPurchaseOrderCandidate>>(candidates);
        }

        public Task<RenewedPurchaseOrderClaim> RenewClaimAsync(
            RenewPurchaseOrderClaimCommand command,
            CancellationToken cancellationToken = default)
        {
            events.Add("renew");
            RenewCommand = command;
            return Task.FromResult(new RenewedPurchaseOrderClaim(
                command.CandidateId,
                FixedUtcNow.AddSeconds(command.LeaseDurationSeconds),
                [4, 0, 0, 0, 0, 0, 0, 0]));
        }

        public Task<DispatchedPurchaseOrderSubmissionAttempt> BeginSubmissionAttemptAsync(
            BeginPurchaseOrderSubmissionAttemptCommand command,
            CancellationToken cancellationToken = default)
        {
            events.Add("begin-dispatch");
            BeginCommand = command;
            return Task.FromResult(new DispatchedPurchaseOrderSubmissionAttempt(
                command.AttemptId,
                1,
                "DISPATCHED"));
        }

        public Task<FailedPurchaseOrderCandidatePreDispatch> FailCandidatePreDispatchAsync(
            FailPurchaseOrderCandidatePreDispatchCommand command,
            CancellationToken cancellationToken = default)
        {
            events.Add("fail-pre-dispatch");
            FailPreDispatchCommand = command;
            return Task.FromResult(new FailedPurchaseOrderCandidatePreDispatch(
                command.CandidateId,
                command.CandidateStatus,
                [5, 0, 0, 0, 0, 0, 0, 0]));
        }

        public Task<CompletedPurchaseOrderSubmission> CompleteSubmissionAsync(
            CompletePurchaseOrderSubmissionCommand command,
            CancellationToken cancellationToken = default)
        {
            events.Add("complete");
            CompleteCommand = command;
            return Task.FromResult(new CompletedPurchaseOrderSubmission(
                command.CandidateId,
                "COMPLETED",
                command.IconPurchaseOrderNumber,
                command.AttemptId,
                "SUCCEEDED",
                [6, 0, 0, 0, 0, 0, 0, 0]));
        }

        public Task<FailedPurchaseOrderSubmission> FailSubmissionAsync(
            FailPurchaseOrderSubmissionCommand command,
            CancellationToken cancellationToken = default)
        {
            events.Add("fail-submission");
            FailSubmissionCommand = command;
            return Task.FromResult(new FailedPurchaseOrderSubmission(
                command.CandidateId,
                command.CandidateStatus,
                null,
                command.AttemptId,
                command.AttemptStatus,
                [7, 0, 0, 0, 0, 0, 0, 0]));
        }

        public Task<ReleasedPurchaseOrderClaim> ReleaseClaimAsync(
            ReleasePurchaseOrderClaimCommand command,
            CancellationToken cancellationToken = default) =>
            throw new InvalidOperationException("Release is not expected in processor orchestration.");

        public Task<PurchaseOrderCandidateDetails> GetCandidateAsync(
            Guid candidateId,
            CancellationToken cancellationToken = default) =>
            throw new InvalidOperationException("Get is not expected in processor orchestration.");
    }
}
