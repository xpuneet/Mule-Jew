using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;

namespace STUK.PurchaseOrderService.UnitTests.Processor;

public sealed class RelexNotificationDeploymentTests
{
    private const string FunctionsDirectory = "STUK.PurchaseOrderService.Processor.Functions";

    [Fact]
    public void LocalHosts_ResolveProducerTimerAndKeepNotificationsDisabled()
    {
        using var document = JsonDocument.Parse(File.ReadAllText(Path.Combine(
            GetRepositoryRoot(), FunctionsDirectory, "local.settings.json")));
        var values = document.RootElement.GetProperty("Values");
        Assert.True(values.TryGetProperty("RelexNotificationProducerCronExpression", out var timer));
        Assert.Equal("0 * * * * *", timer.GetString());
        Assert.Equal("false", values.GetProperty("RelexNotifications__ResultsEnabled").GetString());
        Assert.Equal("false", values.GetProperty("RelexNotifications__MissingProposalEnabled").GetString());
        var appHost = File.ReadAllText(Path.Combine(GetRepositoryRoot(), "STUK.PurchaseOrderService.AppHost", "Program.cs"));
        Assert.Contains(".WithEnvironment(\"RelexNotificationProducerCronExpression\", \"0 * * * * *\")", appHost);
        Assert.Contains(".WithEnvironment(\"RelexNotifications__ResultsEnabled\", \"false\")", appHost);
        Assert.Contains(".WithEnvironment(\"RelexNotifications__MissingProposalEnabled\", \"false\")", appHost);
    }

    [Fact]
    public void FunctionDefaults_KeepBothProducersDisabledUntilEnvironmentConfigurationIsProvided()
    {
        var configuration = new ConfigurationBuilder()
            .AddJsonFile(Path.Combine(GetRepositoryRoot(), FunctionsDirectory, "appsettings.json"))
            .Build();
        var notifications = configuration.GetSection("RelexNotifications");

        Assert.True(notifications.Exists(), "The Functions host must publish Relex notification defaults.");
        Assert.False(notifications.GetValue<bool>("ResultsEnabled"));
        Assert.False(notifications.GetValue<bool>("MissingProposalEnabled"));
        Assert.Null(notifications.GetValue<DateTimeOffset?>("ResultsNotBeforeUtc"));
        Assert.True(string.IsNullOrEmpty(notifications["Recipients"]));
        Assert.True(string.IsNullOrEmpty(notifications["EnvironmentName"]));
        Assert.Equal("0 * * * * *", configuration["RelexNotificationProducerCronExpression"]);
    }

    [Theory]
    [InlineData("DEV")]
    [InlineData("QA")]
    [InlineData("PROD")]
    public void DeploymentStage_EmitsEveryProducerSettingAsAnEnvironmentOverride(string stageName)
    {
        var pipeline = File.ReadAllText(Path.Combine(
            GetRepositoryRoot(), FunctionsDirectory, "Deploy", "azureDeploy-CD.yml"));
        var stage = Regex.Match(
            pipeline,
            $@"(?ms)^  - stage: {stageName}\s*$.*?(?=^  - stage:|\z)");
        Assert.True(stage.Success, $"Deployment stage {stageName} was not found.");
        var payload = Regex.Match(stage.Value, @"(?s)appSettings:\s*\|\s*(\[.*?\])");
        Assert.True(payload.Success, $"Stage {stageName} must apply Function application settings.");
        using var document = JsonDocument.Parse(payload.Groups[1].Value);
        var settings = document.RootElement.EnumerateArray().ToDictionary(
            setting => setting.GetProperty("name").GetString()!,
            setting => setting.GetProperty("value").GetString(),
            StringComparer.Ordinal);

        var requiredSettings = new[]
        {
            "RelexNotificationProducerCronExpression",
            "RelexNotifications__ResultsEnabled",
            "RelexNotifications__MissingProposalEnabled",
            "RelexNotifications__EnvironmentName",
            "RelexNotifications__Recipients",
            "RelexNotifications__ResultsNotBeforeUtc",
            "RelexNotifications__TimeZoneId",
            "RelexNotifications__MissingProposalCutoffLocalTime",
            "RelexNotifications__MissingProposalDays",
            "RelexNotifications__MissingProposalLookbackHours",
            "RelexNotifications__MissingProposalCatchUpMinutes",
            "RelexNotifications__MaxEventsPerRun",
            "RelexNotifications__LeaseDurationSeconds",
            "RelexNotifications__MaxRunDurationSeconds",
            "RelexNotifications__OutcomePersistenceTimeoutSeconds",
            "RelexNotifications__RetryDelaySeconds",
            "RelexNotifications__MaxFailureCount"
        };
        foreach (var key in requiredSettings)
        {
            Assert.True(settings.TryGetValue(key, out var value), $"Stage {stageName} does not emit {key}.");
            Assert.Equal($"$({key})", value);
        }

        Assert.Equal(
            requiredSettings.Length - 1,
            settings.Keys.Count(key => key.StartsWith("RelexNotifications", StringComparison.Ordinal)));
    }

    private static string GetRepositoryRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null && !File.Exists(Path.Combine(directory.FullName, "STUK.PurchaseOrderService.sln")))
        {
            directory = directory.Parent;
        }

        return directory?.FullName ?? throw new DirectoryNotFoundException("Purchase Order repository root was not found.");
    }
}
