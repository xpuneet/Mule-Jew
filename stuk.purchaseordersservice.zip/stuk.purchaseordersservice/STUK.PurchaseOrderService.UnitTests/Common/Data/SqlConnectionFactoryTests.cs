using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using STUK.PurchaseOrderService.Common.Data.Repositories.DbContexts;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class SqlConnectionFactoryTests
{
    [Fact]
    public async Task Create_ReturnsFreshClosedSqlConnectionsWithConfiguredConnectionString()
    {
        const string connectionString =
            "Data Source=localhost;Initial Catalog=Orders;Integrated Security=True;";
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:PurchaseOrdersServiceDB"] = connectionString
            })
            .Build();
        var factory = new SqlConnectionFactory(new PurchaseOrdersDbContext(configuration));

        await using DbConnection first = factory.Create();
        await using DbConnection second = factory.Create();

        var firstSqlConnection = Assert.IsType<SqlConnection>(first);
        var secondSqlConnection = Assert.IsType<SqlConnection>(second);
        Assert.NotSame(firstSqlConnection, secondSqlConnection);
        Assert.Equal(ConnectionState.Closed, firstSqlConnection.State);
        Assert.Equal(ConnectionState.Closed, secondSqlConnection.State);
        Assert.Equal(connectionString, firstSqlConnection.ConnectionString);
        Assert.Equal(connectionString, secondSqlConnection.ConnectionString);
        Assert.Equal(
            typeof(DbConnection),
            typeof(ISqlConnectionFactory).GetMethod(nameof(ISqlConnectionFactory.Create))!.ReturnType);
    }
}
