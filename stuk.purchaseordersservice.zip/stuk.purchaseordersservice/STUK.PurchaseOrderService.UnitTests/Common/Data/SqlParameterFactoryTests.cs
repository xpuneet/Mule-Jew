using Microsoft.Data.SqlClient;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class SqlParameterFactoryTests
{
    [Fact]
    public void NVarChar_WhenValueIsPresent_SetsExactMetadataAndValue()
    {
        var parameter = SqlParameterFactory.NVarChar("@source", 50, "RELEX");

        AssertParameter(parameter, "@source", SqlDbType.NVarChar, "RELEX", size: 50);
    }

    [Fact]
    public void NVarChar_WhenMaxValueIsNull_SetsMaxSizeAndDbNull()
    {
        var parameter = SqlParameterFactory.NVarChar("@payloadJson", -1, null);

        AssertParameter(parameter, "@payloadJson", SqlDbType.NVarChar, DBNull.Value, size: -1);
    }

    [Fact]
    public void NVarChar_WhenBoundedValueIsNull_SetsDbNull()
    {
        var parameter = SqlParameterFactory.NVarChar("@reference", 100, null);

        AssertParameter(parameter, "@reference", SqlDbType.NVarChar, DBNull.Value, size: 100);
    }

    [Fact]
    public void NVarChar_WhenValueLengthEqualsSize_Succeeds()
    {
        var parameter = SqlParameterFactory.NVarChar("@source", 5, "RELEX");

        AssertParameter(parameter, "@source", SqlDbType.NVarChar, "RELEX", size: 5);
    }

    [Fact]
    public void NVarChar_WhenValueIsOversized_ThrowsWithoutEchoingValue()
    {
        const string sensitiveValue = "sensitive-source-value";

        var exception = Assert.Throws<ArgumentException>(() =>
            SqlParameterFactory.NVarChar("@source", 5, sensitiveValue));

        Assert.Equal("value", exception.ParamName);
        Assert.DoesNotContain(sensitiveValue, exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void NVarChar_WhenSizeIsMax_AllowsLongValues()
    {
        var value = new string('x', 4096);

        var parameter = SqlParameterFactory.NVarChar("@payloadJson", -1, value);

        AssertParameter(parameter, "@payloadJson", SqlDbType.NVarChar, value, size: -1);
    }

    [Fact]
    public void VarChar_SetsExactMetadataAndValue()
    {
        var parameter = SqlParameterFactory.VarChar("@status", 50, "DRAFT");

        AssertParameter(parameter, "@status", SqlDbType.VarChar, "DRAFT", size: 50);
    }

    [Fact]
    public void VarChar_WhenBoundedValueIsNull_SetsDbNull()
    {
        var parameter = SqlParameterFactory.VarChar("@failureCode", 100, null);

        AssertParameter(parameter, "@failureCode", SqlDbType.VarChar, DBNull.Value, size: 100);
    }

    [Fact]
    public void VarChar_WhenValueLengthEqualsSize_Succeeds()
    {
        var parameter = SqlParameterFactory.VarChar("@status", 5, "DRAFT");

        AssertParameter(parameter, "@status", SqlDbType.VarChar, "DRAFT", size: 5);
    }

    [Fact]
    public void VarChar_WhenValueIsOversized_ThrowsWithoutEchoingValue()
    {
        const string sensitiveValue = "sensitive-status-value";

        var exception = Assert.Throws<ArgumentException>(() =>
            SqlParameterFactory.VarChar("@status", 5, sensitiveValue));

        Assert.Equal("value", exception.ParamName);
        Assert.DoesNotContain(sensitiveValue, exception.Message, StringComparison.Ordinal);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-2)]
    public void BoundedStringFactories_WhenSizeIsInvalid_ThrowClearly(int size)
    {
        var nVarCharException = Assert.Throws<ArgumentOutOfRangeException>(() =>
            SqlParameterFactory.NVarChar("@value", size, null));
        var varCharException = Assert.Throws<ArgumentOutOfRangeException>(() =>
            SqlParameterFactory.VarChar("@value", size, null));

        Assert.Equal("size", nVarCharException.ParamName);
        Assert.Equal("size", varCharException.ParamName);
    }

    [Fact]
    public void DateTimeOffset3_SetsScaleAndValue()
    {
        var value = new DateTimeOffset(2026, 7, 29, 12, 34, 56, TimeSpan.Zero);

        var parameter = SqlParameterFactory.DateTimeOffset3("@acceptedDateTime", value);

        AssertParameter(parameter, "@acceptedDateTime", SqlDbType.DateTimeOffset, value, scale: 3);
    }

    [Theory]
    [InlineData(8)]
    [InlineData(32)]
    public void Binary_WhenValueIsPresent_SetsExactMetadataAndValue(int size)
    {
        var value = Enumerable.Range(0, size).Select(index => (byte)index).ToArray();

        var parameter = SqlParameterFactory.Binary("@binaryValue", size, value);

        AssertParameter(parameter, "@binaryValue", SqlDbType.Binary, value, size: size);
    }

    [Fact]
    public void Binary_WhenValueIsNull_SetsDbNull()
    {
        var parameter = SqlParameterFactory.Binary("@expectedRowVersion", 8, null);

        AssertParameter(parameter, "@expectedRowVersion", SqlDbType.Binary, DBNull.Value, size: 8);
    }

    [Theory]
    [InlineData(7)]
    [InlineData(9)]
    public void Binary_WhenValueLengthDoesNotMatchFixedSize_Throws(int valueLength)
    {
        var value = new byte[valueLength];

        var exception = Assert.Throws<ArgumentException>(() =>
            SqlParameterFactory.Binary("@expectedRowVersion", 8, value));

        Assert.Equal("value", exception.ParamName);
    }

    [Fact]
    public void Binary_WhenSizeIsNotPositive_ThrowsClearly()
    {
        var exception = Assert.Throws<ArgumentOutOfRangeException>(() =>
            SqlParameterFactory.Binary("@expectedRowVersion", 0, null));

        Assert.Equal("size", exception.ParamName);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(null)]
    public void Bit_SetsValueOrDbNull(bool? value)
    {
        var parameter = SqlParameterFactory.Bit("@flag", value);

        AssertParameter(parameter, "@flag", SqlDbType.Bit, value ?? (object)DBNull.Value);
    }

    [Theory]
    [InlineData(42)]
    [InlineData(null)]
    public void Int_SetsValueOrDbNull(int? value)
    {
        var parameter = SqlParameterFactory.Int("@pageSize", value);

        AssertParameter(parameter, "@pageSize", SqlDbType.Int, value ?? (object)DBNull.Value);
    }

    [Theory]
    [InlineData((short)20)]
    [InlineData(null)]
    public void SmallInt_SetsValueOrDbNull(short? value)
    {
        var parameter = SqlParameterFactory.SmallInt("@maxCandidates", value);

        AssertParameter(parameter, "@maxCandidates", SqlDbType.SmallInt, value ?? (object)DBNull.Value);
    }

    [Theory]
    [InlineData(1024L)]
    [InlineData(null)]
    public void BigInt_SetsValueOrDbNull(long? value)
    {
        var parameter = SqlParameterFactory.BigInt("@fileContentLength", value);

        AssertParameter(parameter, "@fileContentLength", SqlDbType.BigInt, value ?? (object)DBNull.Value);
    }

    [Fact]
    public void UniqueIdentifier_WhenValueIsPresent_SetsExactValue()
    {
        var value = Guid.Parse("10f97062-8ee4-4ad7-89f0-954b42c33fd7");

        var parameter = SqlParameterFactory.UniqueIdentifier("@candidateId", value);

        AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, value);
    }

    [Fact]
    public void UniqueIdentifier_WhenValueIsNull_SetsDbNull()
    {
        var parameter = SqlParameterFactory.UniqueIdentifier("@candidateId", null);

        AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, DBNull.Value);
    }

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        if (ReferenceEquals(value, DBNull.Value))
        {
            Assert.Same(DBNull.Value, parameter.Value);
        }
        else
        {
            Assert.Equal(value, parameter.Value);
        }
    }
}
