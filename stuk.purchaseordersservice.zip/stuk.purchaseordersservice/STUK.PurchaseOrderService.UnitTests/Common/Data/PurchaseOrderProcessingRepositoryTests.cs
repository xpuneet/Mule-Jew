using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class PurchaseOrderProcessingRepositoryTests
{
    [Fact]
    public void Constructor_WhenExecutorIsNull_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => new PurchaseOrderProcessingRepository(null!));
    }

    [Fact]
    public async Task ClaimCandidatesAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var candidateId = Guid.Parse("ace1dc45-d9e8-4a72-aa2e-3211ad1d1aad");
        var leaseToken = Guid.Parse("f54e6136-bde6-476c-a0e0-d1969d134bb1");
        var leaseExpires = new DateTimeOffset(2026, 7, 29, 10, 45, 30, TimeSpan.Zero);
        var rowVersion = Bytes(8, 11);
        var command = new ClaimPurchaseOrderCandidatesCommand(
            "purchase-order-processor-01",
            1,
            300);
        SetupQueryResult<ClaimedPurchaseOrderCandidate>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("Source", typeof(string)),
                ("Account", typeof(string)),
                ("Branch", typeof(string)),
                ("Reference", typeof(string)),
                ("Status", typeof(string)),
                ("PayloadJson", typeof(string)),
                ("LeaseToken", typeof(Guid)),
                ("LeaseExpiresDateTime", typeof(DateTimeOffset)),
                ("RowVersion", typeof(byte[]))
            ],
            candidateId,
            "RELEX",
            "BRIT186",
            "385",
            DBNull.Value,
            "READY_FOR_SUBMISSION",
            "{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}",
            leaseToken,
            leaseExpires,
            rowVersion);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var results = await repository.ClaimCandidatesAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_claim_purchase_order_candidates",
            cancellationToken,
            parameter => AssertParameter(parameter, "@workerId", SqlDbType.NVarChar, command.WorkerId, size: 256),
            parameter => AssertParameter(parameter, "@maxCandidates", SqlDbType.SmallInt, command.MaxCandidates),
            parameter => AssertParameter(parameter, "@leaseDurationSeconds", SqlDbType.Int, command.LeaseDurationSeconds));
        var result = Assert.Single(results);
        Assert.Equal(candidateId, result.CandidateId);
        Assert.Equal("RELEX", result.Source);
        Assert.Equal("BRIT186", result.Account);
        Assert.Equal("385", result.Branch);
        Assert.Null(result.Reference);
        Assert.Equal("READY_FOR_SUBMISSION", result.Status);
        Assert.Equal("{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}", result.PayloadJson);
        Assert.Equal(leaseToken, result.LeaseToken);
        Assert.Equal(leaseExpires, result.LeaseExpiresDateTime);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task RenewClaimAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var candidateId = Guid.Parse("45831e3f-3284-44fb-af3c-d46ecb58da1f");
        var leaseToken = Guid.Parse("daac657d-6b2f-41c0-a544-05f8e2d2d92e");
        var renewed = new DateTimeOffset(2026, 7, 29, 11, 0, 0, TimeSpan.Zero);
        var newExpiry = renewed.AddMinutes(5);
        var rowVersion = Bytes(8, 21);
        var command = new RenewPurchaseOrderClaimCommand(
            candidateId,
            leaseToken,
            "purchase-order-processor-01",
            300);
        SetupSingleResult<RenewedPurchaseOrderClaim>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("LeaseExpiresDateTime", typeof(DateTimeOffset)),
                ("RowVersion", typeof(byte[]))
            ],
            candidateId,
            newExpiry,
            rowVersion);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.RenewClaimAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_renew_purchase_order_claim",
            cancellationToken,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@leaseToken", SqlDbType.UniqueIdentifier, command.LeaseToken),
            parameter => AssertParameter(parameter, "@workerId", SqlDbType.NVarChar, command.WorkerId, size: 256),
            parameter => AssertParameter(parameter, "@leaseDurationSeconds", SqlDbType.Int, command.LeaseDurationSeconds));
        Assert.Equal(candidateId, result.CandidateId);
        Assert.Equal(newExpiry, result.LeaseExpiresDateTime);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task ReleaseClaimAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new ReleasePurchaseOrderClaimCommand(
            Guid.Parse("9e06e253-994c-43fc-a80e-d92886b7e38f"),
            Guid.Parse("c0f6fba2-8665-414e-aa0e-8acb3cadc957"),
            "purchase-order-processor-01");
        var rowVersion = Bytes(8, 31);
        SetupSingleResult<ReleasedPurchaseOrderClaim>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("Status", typeof(string)),
                ("RowVersion", typeof(byte[]))
            ],
            command.CandidateId,
            "READY_FOR_SUBMISSION",
            rowVersion);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.ReleaseClaimAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_release_purchase_order_claim",
            cancellationToken,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@leaseToken", SqlDbType.UniqueIdentifier, command.LeaseToken),
            parameter => AssertParameter(parameter, "@workerId", SqlDbType.NVarChar, command.WorkerId, size: 256));
        Assert.Equal(command.CandidateId, result.CandidateId);
        Assert.Equal("READY_FOR_SUBMISSION", result.Status);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task ExpireClaimsAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new ExpirePurchaseOrderClaimsCommand("purchase-order-claim-recovery");
        SetupSingleResult<ExpiredPurchaseOrderClaims>(
            executor,
            capture,
            [
                ("ReleasedBeforeDispatchCount", typeof(int)),
                ("UnknownOutcomeCount", typeof(int))
            ],
            3,
            1);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.ExpireClaimsAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_expire_purchase_order_claims",
            cancellationToken,
            parameter => AssertParameter(parameter, "@actor", SqlDbType.NVarChar, command.Actor, size: 256));
        Assert.Equal(3, result.ReleasedBeforeDispatchCount);
        Assert.Equal(1, result.UnknownOutcomeCount);
        executor.VerifyAll();
    }

    [Fact]
    public async Task GetCandidateAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var candidateId = Guid.Parse("e015cacf-2127-41de-b374-1b57fa5d590d");
        var batchId = Guid.Parse("e5b750d0-58ea-4729-9d89-2ac5d686590f");
        var leaseToken = Guid.Parse("edbd5db7-061a-455b-bf01-3d3d1263527f");
        var statusDateTime = new DateTimeOffset(2026, 7, 29, 11, 30, 0, TimeSpan.Zero);
        var acceptedDateTime = statusDateTime.AddMinutes(-10);
        var createdDateTime = acceptedDateTime;
        var updatedDateTime = statusDateTime;
        var refreshDateTime = statusDateTime;
        var leaseAcquiredDateTime = statusDateTime.AddMinutes(-1);
        var leaseExpiresDateTime = statusDateTime.AddMinutes(4);
        var rowVersion = Bytes(8, 41);
        SetupSingleResult<PurchaseOrderCandidateDetails>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("BatchId", typeof(Guid)),
                ("Source", typeof(string)),
                ("Kind", typeof(string)),
                ("Account", typeof(string)),
                ("Branch", typeof(string)),
                ("Reference", typeof(string)),
                ("IconPurchaseOrderNumber", typeof(string)),
                ("Status", typeof(string)),
                ("StatusDateTime", typeof(DateTimeOffset)),
                ("StatusReason", typeof(string)),
                ("ProcessBatchNo", typeof(int)),
                ("PayloadMD5", typeof(string)),
                ("MessageCode", typeof(string)),
                ("MessageDescription", typeof(string)),
                ("PreviousMessageCode", typeof(string)),
                ("PreviousMessageDescription", typeof(string)),
                ("PayloadJson", typeof(string)),
                ("AcceptedDateTime", typeof(DateTimeOffset)),
                ("CreatedDateTime", typeof(DateTimeOffset)),
                ("UpdatedDateTime", typeof(DateTimeOffset)),
                ("RefreshDateTime", typeof(DateTimeOffset)),
                ("PendingRetriesCount", typeof(int)),
                ("ProcessingRetriesCount", typeof(int)),
                ("LeaseToken", typeof(Guid)),
                ("LeaseOwner", typeof(string)),
                ("LeaseAcquiredDateTime", typeof(DateTimeOffset)),
                ("LeaseExpiresDateTime", typeof(DateTimeOffset)),
                ("RowVersion", typeof(byte[]))
            ],
            candidateId,
            batchId,
            "RELEX",
            "RELEX",
            "BRIT186",
            "385",
            DBNull.Value,
            DBNull.Value,
            "READY_FOR_SUBMISSION",
            statusDateTime,
            "Ready for ICON submission.",
            DBNull.Value,
            "17D8E1A2F9281D1BFA4C",
            DBNull.Value,
            "Candidate accepted.",
            "VALIDATED",
            DBNull.Value,
            "{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}",
            acceptedDateTime,
            createdDateTime,
            updatedDateTime,
            refreshDateTime,
            2,
            1,
            leaseToken,
            "purchase-order-processor-01",
            leaseAcquiredDateTime,
            leaseExpiresDateTime,
            rowVersion);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.GetCandidateAsync(candidateId, cancellationToken);

        AssertCall(
            capture,
            "po.sp_get_purchase_order_candidate",
            cancellationToken,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, candidateId));
        Assert.Equal(candidateId, result.CandidateId);
        Assert.Equal(batchId, result.BatchId);
        Assert.Equal("RELEX", result.Source);
        Assert.Equal("RELEX", result.Kind);
        Assert.Equal("BRIT186", result.Account);
        Assert.Equal("385", result.Branch);
        Assert.Null(result.Reference);
        Assert.Null(result.IconPurchaseOrderNumber);
        Assert.Equal("READY_FOR_SUBMISSION", result.Status);
        Assert.Equal(statusDateTime, result.StatusDateTime);
        Assert.Equal("Ready for ICON submission.", result.StatusReason);
        Assert.Null(result.ProcessBatchNo);
        Assert.Equal("17D8E1A2F9281D1BFA4C", result.PayloadMd5);
        Assert.Null(result.MessageCode);
        Assert.Equal("Candidate accepted.", result.MessageDescription);
        Assert.Equal("VALIDATED", result.PreviousMessageCode);
        Assert.Null(result.PreviousMessageDescription);
        Assert.Equal("{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}", result.PayloadJson);
        Assert.Equal(acceptedDateTime, result.AcceptedDateTime);
        Assert.Equal(createdDateTime, result.CreatedDateTime);
        Assert.Equal(updatedDateTime, result.UpdatedDateTime);
        Assert.Equal(refreshDateTime, result.RefreshDateTime);
        Assert.Equal(2, result.PendingRetriesCount);
        Assert.Equal(1, result.ProcessingRetriesCount);
        Assert.Equal(leaseToken, result.LeaseToken);
        Assert.Equal("purchase-order-processor-01", result.LeaseOwner);
        Assert.Equal(leaseAcquiredDateTime, result.LeaseAcquiredDateTime);
        Assert.Equal(leaseExpiresDateTime, result.LeaseExpiresDateTime);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task BeginSubmissionAttemptAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new BeginPurchaseOrderSubmissionAttemptCommand(
            Guid.Parse("0f413e6c-467a-40fc-89aa-bbe50bc46af6"),
            Guid.Parse("8ca4c228-84a5-40a8-8285-0ba4d80be44e"),
            Guid.Parse("bc62c1e7-21a7-44df-9736-cf9f9ebf2d07"),
            "purchase-order-processor-01",
            "{\"purchaseOrder\":{}}");
        SetupSingleResult<DispatchedPurchaseOrderSubmissionAttempt>(
            executor,
            capture,
            [
                ("AttemptId", typeof(Guid)),
                ("AttemptNumber", typeof(int)),
                ("Status", typeof(string))
            ],
            command.AttemptId,
            2,
            "DISPATCHED");
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.BeginSubmissionAttemptAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_begin_purchase_order_submission_attempt",
            cancellationToken,
            parameter => AssertParameter(parameter, "@attemptId", SqlDbType.UniqueIdentifier, command.AttemptId),
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@leaseToken", SqlDbType.UniqueIdentifier, command.LeaseToken),
            parameter => AssertParameter(parameter, "@workerId", SqlDbType.NVarChar, command.WorkerId, size: 256),
            parameter => AssertParameter(parameter, "@requestPayloadJson", SqlDbType.NVarChar, command.RequestPayloadJson, size: -1));
        Assert.Equal(command.AttemptId, result.AttemptId);
        Assert.Equal(2, result.AttemptNumber);
        Assert.Equal("DISPATCHED", result.Status);
        executor.VerifyAll();
    }

    [Fact]
    public async Task CompleteSubmissionAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new CompletePurchaseOrderSubmissionCommand(
            Guid.Parse("a19afad7-e7b6-425e-adc4-5268c85dfd9a"),
            Guid.Parse("107ddc12-9959-419f-80ff-759a79f933ba"),
            Guid.Parse("21fce2a4-3e32-41c4-b36f-f7d253ebf82e"),
            "purchase-order-processor-01",
            "PO-902183",
            "activated",
            false,
            null,
            null);
        var returnedRowVersion = Bytes(8, 91);
        SetupSingleResult<CompletedPurchaseOrderSubmission>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("Status", typeof(string)),
                ("IconPurchaseOrderNumber", typeof(string)),
                ("AttemptId", typeof(Guid)),
                ("AttemptStatus", typeof(string)),
                ("CandidateRowVersion", typeof(byte[]))
            ],
            command.CandidateId,
            "COMPLETED",
            "PO-902183",
            command.AttemptId,
            "SUCCEEDED",
            returnedRowVersion);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.CompleteSubmissionAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_complete_purchase_order_submission",
            cancellationToken,
            parameter => AssertParameter(parameter, "@attemptId", SqlDbType.UniqueIdentifier, command.AttemptId),
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@leaseToken", SqlDbType.UniqueIdentifier, command.LeaseToken),
            parameter => AssertParameter(parameter, "@workerId", SqlDbType.NVarChar, command.WorkerId, size: 256),
            parameter => AssertParameter(parameter, "@iconPurchaseOrderNumber", SqlDbType.NVarChar, command.IconPurchaseOrderNumber, size: 100),
            parameter => AssertParameter(parameter, "@iconCreatedStatus", SqlDbType.VarChar, command.IconCreatedStatus, size: 50),
            parameter => AssertParameter(parameter, "@iconSuspended", SqlDbType.Bit, command.IconSuspended),
            parameter => AssertParameter(parameter, "@iconSuspendMessage", SqlDbType.NVarChar, DBNull.Value, size: 1000),
            parameter => AssertParameter(parameter, "@responsePayloadJson", SqlDbType.NVarChar, DBNull.Value, size: -1));
        Assert.Equal(command.CandidateId, result.CandidateId);
        Assert.Equal("COMPLETED", result.Status);
        Assert.Equal("PO-902183", result.IconPurchaseOrderNumber);
        Assert.Equal(command.AttemptId, result.AttemptId);
        Assert.Equal("SUCCEEDED", result.AttemptStatus);
        Assert.Equal(returnedRowVersion, result.CandidateRowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task FailCandidatePreDispatchAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new FailPurchaseOrderCandidatePreDispatchCommand(
            Guid.Parse("a7717557-328b-4f60-91ce-521b44e87144"),
            Guid.Parse("cc182ebc-d2b8-4135-8e3e-fda7a1bf6ef0"),
            "purchase-order-processor-01",
            "NON_RECOVERABLE_ERROR",
            "CDM_TO_ICON_MAPPING",
            "PO_MAPPING_INVALID",
            "Canonical Purchase Order could not be mapped to ICON.");
        var returnedRowVersion = Bytes(8, 106);
        SetupSingleResult<FailedPurchaseOrderCandidatePreDispatch>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("Status", typeof(string)),
                ("RowVersion", typeof(byte[]))
            ],
            command.CandidateId,
            "NON_RECOVERABLE_ERROR",
            returnedRowVersion);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.FailCandidatePreDispatchAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_fail_purchase_order_candidate_pre_dispatch",
            cancellationToken,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@leaseToken", SqlDbType.UniqueIdentifier, command.LeaseToken),
            parameter => AssertParameter(parameter, "@workerId", SqlDbType.NVarChar, command.WorkerId, size: 256),
            parameter => AssertParameter(parameter, "@candidateStatus", SqlDbType.VarChar, command.CandidateStatus, size: 50),
            parameter => AssertParameter(parameter, "@failureCategory", SqlDbType.VarChar, command.FailureCategory, size: 100),
            parameter => AssertParameter(parameter, "@messageCode", SqlDbType.NVarChar, command.MessageCode!, size: 100),
            parameter => AssertParameter(parameter, "@messageDescription", SqlDbType.NVarChar, command.MessageDescription!, size: 1000));
        Assert.Equal(command.CandidateId, result.CandidateId);
        Assert.Equal("NON_RECOVERABLE_ERROR", result.Status);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task FailSubmissionAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new FailPurchaseOrderSubmissionCommand(
            Guid.Parse("e70a372a-fc5d-4d92-953d-a4bf7373809e"),
            Guid.Parse("a1d18a87-3299-469a-a109-d1f39b57b71f"),
            Guid.Parse("d04dfba6-42c7-46bf-a83b-1a3e3905be15"),
            "purchase-order-processor-01",
            "NON_RECOVERABLE_ERROR",
            "ICON_UNKNOWN_OUTCOME",
            null,
            null,
            null,
            null,
            "UNKNOWN_OUTCOME");
        var returnedRowVersion = Bytes(8, 111);
        SetupSingleResult<FailedPurchaseOrderSubmission>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("Status", typeof(string)),
                ("IconPurchaseOrderNumber", typeof(string)),
                ("AttemptId", typeof(Guid)),
                ("AttemptStatus", typeof(string)),
                ("CandidateRowVersion", typeof(byte[]))
            ],
            command.CandidateId,
            "NON_RECOVERABLE_ERROR",
            DBNull.Value,
            command.AttemptId,
            "UNKNOWN_OUTCOME",
            returnedRowVersion);
        var repository = new PurchaseOrderProcessingRepository(executor.Object);

        var result = await repository.FailSubmissionAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_fail_purchase_order_submission",
            cancellationToken,
            parameter => AssertParameter(parameter, "@attemptId", SqlDbType.UniqueIdentifier, command.AttemptId),
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@leaseToken", SqlDbType.UniqueIdentifier, command.LeaseToken),
            parameter => AssertParameter(parameter, "@workerId", SqlDbType.NVarChar, command.WorkerId, size: 256),
            parameter => AssertParameter(parameter, "@candidateStatus", SqlDbType.VarChar, command.CandidateStatus, size: 50),
            parameter => AssertParameter(parameter, "@failureCategory", SqlDbType.VarChar, command.FailureCategory, size: 100),
            parameter => AssertParameter(parameter, "@messageCode", SqlDbType.NVarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@messageDescription", SqlDbType.NVarChar, DBNull.Value, size: 1000),
            parameter => AssertParameter(parameter, "@httpStatusCode", SqlDbType.SmallInt, DBNull.Value),
            parameter => AssertParameter(parameter, "@responsePayloadJson", SqlDbType.NVarChar, DBNull.Value, size: -1),
            parameter => AssertParameter(parameter, "@attemptStatus", SqlDbType.VarChar, command.AttemptStatus, size: 50));
        Assert.Equal(command.CandidateId, result.CandidateId);
        Assert.Equal("NON_RECOVERABLE_ERROR", result.Status);
        Assert.Null(result.IconPurchaseOrderNumber);
        Assert.Equal(command.AttemptId, result.AttemptId);
        Assert.Equal("UNKNOWN_OUTCOME", result.AttemptStatus);
        Assert.Equal(returnedRowVersion, result.CandidateRowVersion);
        executor.VerifyAll();
    }

    private static void SetupSingleResult<T>(
        Mock<IStoredProcedureExecutor> executor,
        CallCapture capture,
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, T>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, T> map,
                CancellationToken cancellationToken) =>
            {
                capture.Call = call;
                capture.CancellationToken = cancellationToken;
                using var reader = CreateReader(columns, values);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
    }

    private static void SetupQueryResult<T>(
        Mock<IStoredProcedureExecutor> executor,
        CallCapture capture,
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, T>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, T> map,
                CancellationToken cancellationToken) =>
            {
                capture.Call = call;
                capture.CancellationToken = cancellationToken;
                using var reader = CreateReader(columns, values);
                Assert.True(reader.Read());
                IReadOnlyList<T> results = [map(reader)];
                return Task.FromResult(results);
            });
    }

    private static DbDataReader CreateReader(
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        var table = new DataTable();
        foreach (var (name, type) in columns)
        {
            table.Columns.Add(name, type);
        }

        table.Rows.Add(values);
        return table.CreateDataReader();
    }

    private static void AssertCall(
        CallCapture capture,
        string procedureName,
        CancellationToken cancellationToken,
        params Action<SqlParameter>[] parameterAssertions)
    {
        Assert.NotNull(capture.Call);
        Assert.Equal(procedureName, capture.Call.ProcedureName);
        Assert.Collection(capture.Call.Parameters, parameterAssertions);
        Assert.Equal(cancellationToken, capture.CancellationToken);
    }

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        if (ReferenceEquals(value, DBNull.Value))
        {
            Assert.Same(DBNull.Value, parameter.Value);
            return;
        }

        Assert.Equal(value, parameter.Value);
    }

    private static byte[] Bytes(int length, byte seed) =>
        Enumerable.Range(0, length).Select(offset => unchecked((byte)(seed + offset))).ToArray();

    private sealed class CallCapture
    {
        public StoredProcedureCall? Call { get; set; }

        public CancellationToken CancellationToken { get; set; }
    }
}
