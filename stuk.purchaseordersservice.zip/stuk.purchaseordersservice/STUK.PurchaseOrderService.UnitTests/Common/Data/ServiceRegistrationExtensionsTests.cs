using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.DbContexts;
using STUK.PurchaseOrderService.Common.Data.Sql;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class ServiceRegistrationExtensionsTests
{
    private const string ConnectionString =
        "Data Source=localhost;Initial Catalog=PurchaseOrders;Integrated Security=True;";
    private const string MissingConnectionStringMessage =
        "Connection string 'PurchaseOrdersServiceDB' is required.";

    [Fact]
    public void AddPurchaseOrderPersistence_WhenConfigured_RegistersScopedPersistenceServices()
    {
        var configuration = BuildConfiguration(ConnectionString);
        var services = new ServiceCollection();

        services.AddPurchaseOrderPersistence(configuration);

        AssertScoped<PurchaseOrdersDbContext>(services);
        AssertScoped<ISqlConnectionFactory, SqlConnectionFactory>(services);
        AssertScoped<IStoredProcedureExecutor, StoredProcedureExecutor>(services);
        AssertScoped<IPurchaseOrdersRepository, PurchaseOrdersRepository>(services);
        AssertScoped<IPurchaseOrderAdminRepository, PurchaseOrderAdminRepository>(services);
        AssertScoped<IPurchaseOrderBatchRepository, PurchaseOrderBatchRepository>(services);
        AssertScoped<IPurchaseOrderProcessingRepository, PurchaseOrderProcessingRepository>(services);
        AssertScoped<IPurchaseOrderSupportRepository, PurchaseOrderSupportRepository>(services);
        AssertScoped<IPurchaseOrderNotificationRepository, PurchaseOrderNotificationRepository>(services);

        using var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        });
        using var scope = provider.CreateScope();

        Assert.IsType<PurchaseOrdersDbContext>(
            scope.ServiceProvider.GetRequiredService<PurchaseOrdersDbContext>());
        Assert.IsType<SqlConnectionFactory>(
            scope.ServiceProvider.GetRequiredService<ISqlConnectionFactory>());
        Assert.IsType<StoredProcedureExecutor>(
            scope.ServiceProvider.GetRequiredService<IStoredProcedureExecutor>());
        Assert.IsType<PurchaseOrdersRepository>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrdersRepository>());
        Assert.IsType<PurchaseOrderAdminRepository>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrderAdminRepository>());
        Assert.IsType<PurchaseOrderBatchRepository>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrderBatchRepository>());
        Assert.IsType<PurchaseOrderProcessingRepository>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrderProcessingRepository>());
        Assert.IsType<PurchaseOrderSupportRepository>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrderSupportRepository>());
        Assert.IsType<PurchaseOrderNotificationRepository>(
            scope.ServiceProvider.GetRequiredService<IPurchaseOrderNotificationRepository>());
    }

    [Fact]
    public void AddPurchaseOrderPersistence_WhenConfigurationChangesAfterRegistration_UsesOriginalConnectionString()
    {
        const string replacementConnectionString =
            "Data Source=replacement;Initial Catalog=OtherDatabase;Integrated Security=True;";
        var configuration = BuildConfiguration(ConnectionString);
        var services = new ServiceCollection();
        services.AddPurchaseOrderPersistence(configuration);

        configuration[$"ConnectionStrings:{ConfigConstants.PurchaseOrdersDbConnectionStringName}"] =
            replacementConnectionString;

        using var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        });
        using var scope = provider.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<PurchaseOrdersDbContext>();
        var connectionFactory = scope.ServiceProvider.GetRequiredService<ISqlConnectionFactory>();
        using var connection = connectionFactory.Create();

        Assert.Equal(ConnectionString, dbContext.ConnectionString);
        Assert.Equal(ConnectionString, connection.ConnectionString);
    }

    [Fact]
    public void AddPurchaseOrderPersistence_WhenConnectionStringIsProvided_UsesProvidedValue()
    {
        var services = new ServiceCollection();

        services.AddPurchaseOrderPersistence(ConnectionString);

        using var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            ValidateOnBuild = true,
            ValidateScopes = true
        });
        using var scope = provider.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<PurchaseOrdersDbContext>();
        var connectionFactory = scope.ServiceProvider.GetRequiredService<ISqlConnectionFactory>();
        using var connection = connectionFactory.Create();

        Assert.Equal(ConnectionString, dbContext.ConnectionString);
        Assert.Equal(ConnectionString, connection.ConnectionString);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void AddPurchaseOrderPersistence_WhenConnectionStringIsMissingOrBlank_ThrowsSanitizedError(
        string? connectionString)
    {
        const string sensitiveMarker = "Password=do-not-echo-this";
        var configuration = BuildConfiguration(connectionString, sensitiveMarker);
        var services = new ServiceCollection();

        var exception = Assert.Throws<InvalidOperationException>(() =>
            services.AddPurchaseOrderPersistence(configuration));

        Assert.Equal(MissingConnectionStringMessage, exception.Message);
        Assert.Null(exception.InnerException);
        Assert.DoesNotContain(sensitiveMarker, exception.Message, StringComparison.Ordinal);
        if (!string.IsNullOrEmpty(connectionString))
        {
            Assert.DoesNotContain(connectionString, exception.Message, StringComparison.Ordinal);
        }
    }

    private static IConfiguration BuildConfiguration(
        string? connectionString,
        string? sensitiveMarker = null)
    {
        var values = new Dictionary<string, string?>
        {
            ["UnrelatedSensitiveSetting"] = sensitiveMarker
        };
        if (connectionString is not null)
        {
            values[$"ConnectionStrings:{ConfigConstants.PurchaseOrdersDbConnectionStringName}"] =
                connectionString;
        }

        return new ConfigurationBuilder()
            .AddInMemoryCollection(values)
            .Build();
    }

    private static void AssertScoped<TService, TImplementation>(IServiceCollection services)
        where TService : class
        where TImplementation : class, TService
    {
        var descriptor = Assert.Single(
            services,
            candidate => candidate.ServiceType == typeof(TService));
        Assert.Equal(ServiceLifetime.Scoped, descriptor.Lifetime);
        Assert.Equal(typeof(TImplementation), descriptor.ImplementationType);
    }

    private static void AssertScoped<TService>(IServiceCollection services)
        where TService : class
    {
        var descriptor = Assert.Single(
            services,
            candidate => candidate.ServiceType == typeof(TService));
        Assert.Equal(ServiceLifetime.Scoped, descriptor.Lifetime);
        Assert.NotNull(descriptor.ImplementationFactory);
    }
}
