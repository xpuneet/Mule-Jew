using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class PurchaseOrderSupportRepositoryTests
{
    [Fact]
    public void Constructor_WhenExecutorIsNull_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => new PurchaseOrderSupportRepository(null!));
    }

    [Fact]
    public async Task RequestRetryAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new RequestPurchaseOrderRetryCommand(
            Guid.Parse("5f4a86af-d5d8-4a1b-90fc-dfa31c9bdc87"),
            "purchase-order-support-user",
            "Corrected source data is available.",
            new DateTimeOffset(2026, 7, 29, 15, 16, 17, TimeSpan.Zero),
            Bytes(8, 11));
        var returnedRowVersion = Bytes(8, 21);
        SetupSingleResult<PurchaseOrderSupportActionResult>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("Status", typeof(string)),
                ("RowVersion", typeof(byte[]))
            ],
            command.CandidateId,
            "RETRY_REQUESTED",
            returnedRowVersion);
        var repository = new PurchaseOrderSupportRepository(executor.Object);

        var result = await repository.RequestRetryAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_request_purchase_order_retry",
            cancellationToken,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@actor", SqlDbType.NVarChar, command.Actor, size: 256),
            parameter => AssertParameter(parameter, "@reason", SqlDbType.NVarChar, command.Reason, size: 1000),
            parameter => AssertParameter(parameter, "@requestedDateTime", SqlDbType.DateTimeOffset, command.RequestedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@expectedCandidateRowVersion", SqlDbType.Binary, command.ExpectedCandidateRowVersion, size: 8));
        Assert.Equal(command.CandidateId, result.CandidateId);
        Assert.Equal("RETRY_REQUESTED", result.Status);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task CancelCandidateAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new CancelPurchaseOrderCandidateCommand(
            Guid.Parse("77e1eb95-ffae-41b2-ac8e-b6650ef03b40"),
            "purchase-order-support-user",
            "Order was withdrawn by the business.",
            new DateTimeOffset(2026, 7, 29, 16, 17, 18, TimeSpan.Zero),
            Bytes(8, 31));
        var returnedRowVersion = Bytes(8, 41);
        SetupSingleResult<PurchaseOrderSupportActionResult>(
            executor,
            capture,
            [
                ("CandidateId", typeof(Guid)),
                ("Status", typeof(string)),
                ("RowVersion", typeof(byte[]))
            ],
            command.CandidateId,
            "CANCELLED",
            returnedRowVersion);
        var repository = new PurchaseOrderSupportRepository(executor.Object);

        var result = await repository.CancelCandidateAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_cancel_purchase_order_candidate",
            cancellationToken,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@actor", SqlDbType.NVarChar, command.Actor, size: 256),
            parameter => AssertParameter(parameter, "@reason", SqlDbType.NVarChar, command.Reason, size: 1000),
            parameter => AssertParameter(parameter, "@cancelledDateTime", SqlDbType.DateTimeOffset, command.CancelledDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@expectedCandidateRowVersion", SqlDbType.Binary, command.ExpectedCandidateRowVersion, size: 8));
        Assert.Equal(command.CandidateId, result.CandidateId);
        Assert.Equal("CANCELLED", result.Status);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task GetAuditAsync_CreatesExactBoundedPageCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var query = new GetPurchaseOrderAuditQuery(
            Guid.Parse("e488f591-9a19-4673-859b-cbdd2774113c"),
            1,
            50);
        var businessPayloadHash = Bytes(32, 51);
        var changedDateTime = new DateTimeOffset(2026, 7, 29, 17, 18, 19, TimeSpan.Zero);
        SetupQueryResult<PurchaseOrderAuditEntry>(
            executor,
            capture,
            [
                ("Action", typeof(string)),
                ("Method", typeof(string)),
                ("Actor", typeof(string)),
                ("Reason", typeof(string)),
                ("PreviousStatus", typeof(string)),
                ("CurrentStatus", typeof(string)),
                ("PreviousPayloadJson", typeof(string)),
                ("CurrentPayloadJson", typeof(string)),
                ("BusinessPayloadHash", typeof(byte[])),
                ("CorrelationId", typeof(Guid)),
                ("ChangedDateTime", typeof(DateTimeOffset))
            ],
            "MANUAL_RETRY_REQUESTED",
            "SUPPORT",
            "purchase-order-support-user",
            DBNull.Value,
            "RECOVERABLE_ERROR",
            "RETRY_REQUESTED",
            DBNull.Value,
            "{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}",
            businessPayloadHash,
            DBNull.Value,
            changedDateTime);
        var repository = new PurchaseOrderSupportRepository(executor.Object);

        var results = await repository.GetAuditAsync(query, cancellationToken);

        AssertCall(
            capture,
            "po.sp_get_purchase_order_audit",
            cancellationToken,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, query.CandidateId),
            parameter => AssertParameter(parameter, "@pageNumber", SqlDbType.Int, query.PageNumber),
            parameter => AssertParameter(parameter, "@pageSize", SqlDbType.Int, query.PageSize));
        var result = Assert.Single(results);
        Assert.Equal("MANUAL_RETRY_REQUESTED", result.Action);
        Assert.Equal("SUPPORT", result.Method);
        Assert.Equal("purchase-order-support-user", result.Actor);
        Assert.Null(result.Reason);
        Assert.Equal("RECOVERABLE_ERROR", result.PreviousStatus);
        Assert.Equal("RETRY_REQUESTED", result.CurrentStatus);
        Assert.Null(result.PreviousPayloadJson);
        Assert.Equal("{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}", result.CurrentPayloadJson);
        Assert.Equal(businessPayloadHash, result.BusinessPayloadHash);
        Assert.Null(result.CorrelationId);
        Assert.Equal(changedDateTime, result.ChangedDateTime);
        executor.VerifyAll();
    }

    private static void SetupSingleResult<T>(
        Mock<IStoredProcedureExecutor> executor,
        CallCapture capture,
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, T>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, T> map,
                CancellationToken cancellationToken) =>
            {
                capture.Call = call;
                capture.CancellationToken = cancellationToken;
                using var reader = CreateReader(columns, values);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
    }

    private static void SetupQueryResult<T>(
        Mock<IStoredProcedureExecutor> executor,
        CallCapture capture,
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, T>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, T> map,
                CancellationToken cancellationToken) =>
            {
                capture.Call = call;
                capture.CancellationToken = cancellationToken;
                using var reader = CreateReader(columns, values);
                Assert.True(reader.Read());
                IReadOnlyList<T> results = [map(reader)];
                return Task.FromResult(results);
            });
    }

    private static DbDataReader CreateReader(
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        var table = new DataTable();
        foreach (var (name, type) in columns)
        {
            table.Columns.Add(name, type);
        }

        table.Rows.Add(values);
        return table.CreateDataReader();
    }

    private static void AssertCall(
        CallCapture capture,
        string procedureName,
        CancellationToken cancellationToken,
        params Action<SqlParameter>[] parameterAssertions)
    {
        Assert.NotNull(capture.Call);
        Assert.Equal(procedureName, capture.Call.ProcedureName);
        Assert.Collection(capture.Call.Parameters, parameterAssertions);
        Assert.Equal(cancellationToken, capture.CancellationToken);
    }

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        if (ReferenceEquals(value, DBNull.Value))
        {
            Assert.Same(DBNull.Value, parameter.Value);
            return;
        }

        Assert.Equal(value, parameter.Value);
    }

    private static byte[] Bytes(int length, byte seed) =>
        Enumerable.Range(0, length).Select(offset => unchecked((byte)(seed + offset))).ToArray();

    private sealed class CallCapture
    {
        public StoredProcedureCall? Call { get; set; }

        public CancellationToken CancellationToken { get; set; }
    }
}
