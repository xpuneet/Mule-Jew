using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class PurchaseOrderNotificationRepositoryTests
{
    [Fact]
    public void Constructor_WhenExecutorIsNull_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => new PurchaseOrderNotificationRepository(null!));
    }

    [Fact]
    public async Task RegisterNotificationAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new RegisterPurchaseOrderNotificationCommand(
            Guid.Parse("a62cb968-f43e-4d49-b9b5-5349cc7551b6"),
            Guid.Parse("10b82541-859c-4503-a8e0-d3a9071e1e0e"),
            "EMAIL",
            "purchase-order-batch-completed",
            "relex-purchase-order-operations",
            null,
            new DateTimeOffset(2026, 7, 29, 18, 19, 20, TimeSpan.Zero));
        var rowVersion = Bytes(8, 11);
        SetupSingleResult<RegisteredPurchaseOrderNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("Status", typeof(string)),
                ("RowVersion", typeof(byte[]))
            ],
            command.NotificationId,
            "PENDING",
            rowVersion);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.RegisterNotificationAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_register_purchase_order_notification",
            cancellationToken,
            parameter => AssertParameter(parameter, "@notificationId", SqlDbType.UniqueIdentifier, command.NotificationId),
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, command.BatchId),
            parameter => AssertParameter(parameter, "@channel", SqlDbType.VarChar, command.Channel, size: 50),
            parameter => AssertParameter(parameter, "@templateKey", SqlDbType.NVarChar, command.TemplateKey, size: 100),
            parameter => AssertParameter(parameter, "@recipientGroupKey", SqlDbType.NVarChar, command.RecipientGroupKey, size: 100),
            parameter => AssertParameter(parameter, "@attachmentBlobName", SqlDbType.NVarChar, DBNull.Value, size: 512),
            parameter => AssertParameter(parameter, "@createdDateTime", SqlDbType.DateTimeOffset, command.CreatedDateTime, scale: 3));
        Assert.Equal(command.NotificationId, result.NotificationId);
        Assert.Equal("PENDING", result.Status);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task CompleteNotificationAsync_WhenFailed_CreatesExactNullableTypedCallMapsNullSentDateAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new CompletePurchaseOrderNotificationCommand(
            Guid.Parse("eb8cc034-4134-460f-b569-1c517f79e6bf"),
            "FAILED",
            null,
            "PROVIDER_UNAVAILABLE",
            "The notification provider was unavailable.",
            new DateTimeOffset(2026, 7, 29, 19, 20, 21, TimeSpan.Zero),
            Bytes(8, 21));
        var returnedRowVersion = Bytes(8, 31);
        SetupSingleResult<CompletedPurchaseOrderNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("Status", typeof(string)),
                ("SentDateTime", typeof(DateTimeOffset)),
                ("RowVersion", typeof(byte[]))
            ],
            command.NotificationId,
            "FAILED",
            DBNull.Value,
            returnedRowVersion);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.CompleteNotificationAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_complete_purchase_order_notification",
            cancellationToken,
            parameter => AssertParameter(parameter, "@notificationId", SqlDbType.UniqueIdentifier, command.NotificationId),
            parameter => AssertParameter(parameter, "@status", SqlDbType.VarChar, command.Status, size: 50),
            parameter => AssertParameter(parameter, "@providerMessageId", SqlDbType.NVarChar, DBNull.Value, size: 256),
            parameter => AssertParameter(parameter, "@failureCode", SqlDbType.VarChar, command.FailureCode!, size: 100),
            parameter => AssertParameter(parameter, "@failureDescription", SqlDbType.NVarChar, command.FailureDescription!, size: 1000),
            parameter => AssertParameter(parameter, "@completedDateTime", SqlDbType.DateTimeOffset, command.CompletedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@expectedNotificationRowVersion", SqlDbType.Binary, command.ExpectedNotificationRowVersion, size: 8));
        Assert.Equal(command.NotificationId, result.NotificationId);
        Assert.Equal("FAILED", result.Status);
        Assert.Null(result.SentDateTime);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task CompleteNotificationAsync_WhenSent_MapsSentDateAndForwardsNullableProviderFields()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        var completedDateTime = new DateTimeOffset(2026, 7, 29, 20, 21, 22, TimeSpan.Zero);
        var command = new CompletePurchaseOrderNotificationCommand(
            Guid.Parse("4d4fbc8f-a3e5-4d94-adc1-081d3a0d33d3"),
            "SENT",
            "retarus-message-81291",
            null,
            null,
            completedDateTime,
            Bytes(8, 41));
        var returnedRowVersion = Bytes(8, 51);
        SetupSingleResult<CompletedPurchaseOrderNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("Status", typeof(string)),
                ("SentDateTime", typeof(DateTimeOffset)),
                ("RowVersion", typeof(byte[]))
            ],
            command.NotificationId,
            "SENT",
            completedDateTime,
            returnedRowVersion);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.CompleteNotificationAsync(command, CancellationToken.None);

        AssertCall(
            capture,
            "po.sp_complete_purchase_order_notification",
            CancellationToken.None,
            parameter => AssertParameter(parameter, "@notificationId", SqlDbType.UniqueIdentifier, command.NotificationId),
            parameter => AssertParameter(parameter, "@status", SqlDbType.VarChar, command.Status, size: 50),
            parameter => AssertParameter(parameter, "@providerMessageId", SqlDbType.NVarChar, command.ProviderMessageId!, size: 256),
            parameter => AssertParameter(parameter, "@failureCode", SqlDbType.VarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@failureDescription", SqlDbType.NVarChar, DBNull.Value, size: 1000),
            parameter => AssertParameter(parameter, "@completedDateTime", SqlDbType.DateTimeOffset, command.CompletedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@expectedNotificationRowVersion", SqlDbType.Binary, command.ExpectedNotificationRowVersion, size: 8));
        Assert.Equal(command.NotificationId, result.NotificationId);
        Assert.Equal("SENT", result.Status);
        Assert.Equal(completedDateTime, result.SentDateTime);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    private static void SetupSingleResult<T>(
        Mock<IStoredProcedureExecutor> executor,
        CallCapture capture,
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, T>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, T> map,
                CancellationToken cancellationToken) =>
            {
                capture.Call = call;
                capture.CancellationToken = cancellationToken;
                using var reader = CreateReader(columns, values);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
    }

    private static DbDataReader CreateReader(
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        var table = new DataTable();
        foreach (var (name, type) in columns)
        {
            table.Columns.Add(name, type);
        }

        table.Rows.Add(values);
        return table.CreateDataReader();
    }

    private static void AssertCall(
        CallCapture capture,
        string procedureName,
        CancellationToken cancellationToken,
        params Action<SqlParameter>[] parameterAssertions)
    {
        Assert.NotNull(capture.Call);
        Assert.Equal(procedureName, capture.Call.ProcedureName);
        Assert.Collection(capture.Call.Parameters, parameterAssertions);
        Assert.Equal(cancellationToken, capture.CancellationToken);
    }

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        if (ReferenceEquals(value, DBNull.Value))
        {
            Assert.Same(DBNull.Value, parameter.Value);
            return;
        }

        Assert.Equal(value, parameter.Value);
    }

    private static byte[] Bytes(int length, byte seed) =>
        Enumerable.Range(0, length).Select(offset => unchecked((byte)(seed + offset))).ToArray();

    private sealed class CallCapture
    {
        public StoredProcedureCall? Call { get; set; }

        public CancellationToken CancellationToken { get; set; }
    }
}
