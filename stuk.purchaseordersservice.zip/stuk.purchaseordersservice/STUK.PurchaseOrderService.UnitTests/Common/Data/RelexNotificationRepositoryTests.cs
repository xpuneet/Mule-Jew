using System.Data;
using System.Data.Common;
using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class RelexNotificationRepositoryTests
{
    [Fact]
    public async Task PrepareAndClaimAsync_PreservesOptionalCutoffsAndMapsFrozenSnapshot()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var id = Guid.Parse("83ad2ee5-02a8-44b8-b5eb-39e97bf49213");
        var lease = Guid.Parse("9578c7e3-dca8-4d6e-bf54-f41fc2755f0c");
        var now = new DateTimeOffset(2026, 9, 24, 9, 30, 0, TimeSpan.Zero);
        using var cancellation = new CancellationTokenSource();
        StoredProcedureCall? captured = null;
        executor.Setup(x => x.QueryAsync(It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, RelexNotificationEvent>>(), cancellation.Token))
            .Returns((StoredProcedureCall call, Func<DbDataReader, RelexNotificationEvent> map,
                CancellationToken _) =>
            {
                captured = call;
                using var table = new DataTable();
                foreach (var column in new (string, Type)[]
                {
                    ("NotificationId", typeof(Guid)), ("BatchId", typeof(Guid)),
                    ("EventType", typeof(string)), ("BusinessCorrelationId", typeof(string)),
                    ("OriginalFileName", typeof(string)), ("CreatedDateTime", typeof(DateTimeOffset)),
                    ("CompositionSettingsJson", typeof(string)), ("OutcomeRowsJson", typeof(string)),
                    ("EmailEnvelopeJson", typeof(string)), ("LeaseId", typeof(Guid)),
                    ("FailureCount", typeof(int))
                }) table.Columns.Add(column.Item1, column.Item2);
                table.Rows.Add(id, DBNull.Value, "RELEX_MISSING", "RELEX_MISSING:2026-09-24",
                    DBNull.Value, now, "{\"schemaVersion\":1}", "[]", "{\"frozen\":true}", lease, 3);
                using var reader = table.CreateDataReader();
                reader.Read();
                return Task.FromResult<IReadOnlyList<RelexNotificationEvent>>([map(reader)]);
            });
        var repository = new RelexNotificationRepository(executor.Object);

        var result = Assert.Single(await repository.PrepareAndClaimAsync(new(
            now, 12, 180, false, "{\"schemaVersion\":1}", null,
            now, now.AddHours(-6), "RELEX_MISSING:2026-09-24"), cancellation.Token));

        Assert.NotNull(captured);
        Assert.Equal("po.sp_prepare_and_claim_relex_notification_events", captured.ProcedureName);
        Assert.Collection(captured.Parameters,
            p => Parameter(p, "@asOfDateTime", SqlDbType.DateTimeOffset, now, scale: 3),
            p => Parameter(p, "@maxEvents", SqlDbType.Int, 12),
            p => Parameter(p, "@leaseDurationSeconds", SqlDbType.Int, 180),
            p => Parameter(p, "@resultsEnabled", SqlDbType.Bit, false),
            p => Parameter(p, "@compositionSettingsJson", SqlDbType.NVarChar, "{\"schemaVersion\":1}", -1),
            p => Parameter(p, "@resultsNotBeforeDateTime", SqlDbType.DateTimeOffset, DBNull.Value, scale: 3),
            p => Parameter(p, "@missingCutoffDateTime", SqlDbType.DateTimeOffset, now, scale: 3),
            p => Parameter(p, "@missingFreshSinceDateTime", SqlDbType.DateTimeOffset, now.AddHours(-6), scale: 3),
            p => Parameter(p, "@missingEventKey", SqlDbType.NVarChar, "RELEX_MISSING:2026-09-24", 100));
        Assert.Equal(new RelexNotificationEvent(id, null, "RELEX_MISSING", "RELEX_MISSING:2026-09-24",
            null, now, "{\"schemaVersion\":1}", "[]", "{\"frozen\":true}", lease, 3), result);
    }

    [Fact]
    public async Task SaveEnvelopeAsync_ReturnsPreviouslyPersistedContentInsteadOfSubmittedReplacement()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var id = Guid.NewGuid();
        var lease = Guid.NewGuid();
        executor.Setup(x => x.QuerySingleAsync(It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, string>>(), It.IsAny<CancellationToken>()))
            .Returns((StoredProcedureCall call, Func<DbDataReader, string> map, CancellationToken _) =>
            {
                Assert.Equal("po.sp_save_relex_notification_envelope", call.ProcedureName);
                Assert.Collection(call.Parameters,
                    p => Parameter(p, "@notificationId", SqlDbType.UniqueIdentifier, id),
                    p => Parameter(p, "@leaseId", SqlDbType.UniqueIdentifier, lease),
                    p => Parameter(p, "@emailEnvelopeJson", SqlDbType.NVarChar, "new", -1));
                using var table = new DataTable();
                table.Columns.Add("EmailEnvelopeJson", typeof(string));
                table.Rows.Add("original");
                using var reader = table.CreateDataReader();
                reader.Read();
                return Task.FromResult(map(reader));
            });

        var result = await new RelexNotificationRepository(executor.Object)
            .SaveEnvelopeAsync(new(id, lease, "new"));

        Assert.Equal("original", result);
    }

    [Fact]
    public async Task CompleteAsync_PreservesFailureClassificationAndRetryDeadline()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var id = Guid.NewGuid();
        var lease = Guid.NewGuid();
        var now = new DateTimeOffset(2026, 9, 24, 9, 32, 0, TimeSpan.Zero);
        StoredProcedureCall? captured = null;
        executor.Setup(x => x.ExecuteNonQueryAsync(It.IsAny<StoredProcedureCall>(), It.IsAny<CancellationToken>()))
            .Returns((StoredProcedureCall call, CancellationToken _) =>
            {
                captured = call;
                return Task.FromResult(1);
            });

        await new RelexNotificationRepository(executor.Object).CompleteAsync(new(
            id, lease, false, false, now, now.AddMinutes(5), "OUTBOX_UNAVAILABLE", 8));

        Assert.NotNull(captured);
        Assert.Equal("po.sp_complete_relex_notification_event", captured.ProcedureName);
        Assert.Collection(captured.Parameters,
            p => Parameter(p, "@notificationId", SqlDbType.UniqueIdentifier, id),
            p => Parameter(p, "@leaseId", SqlDbType.UniqueIdentifier, lease),
            p => Parameter(p, "@enqueued", SqlDbType.Bit, false),
            p => Parameter(p, "@permanentFailure", SqlDbType.Bit, false),
            p => Parameter(p, "@completedDateTime", SqlDbType.DateTimeOffset, now, scale: 3),
            p => Parameter(p, "@nextAttemptDateTime", SqlDbType.DateTimeOffset, now.AddMinutes(5), scale: 3),
            p => Parameter(p, "@failureCode", SqlDbType.VarChar, "OUTBOX_UNAVAILABLE", 100),
            p => Parameter(p, "@maxFailureCount", SqlDbType.Int, 8));
    }

    private static void Parameter(SqlParameter actual, string name, SqlDbType type, object value,
        int? size = null, byte? scale = null)
    {
        Assert.Equal(name, actual.ParameterName);
        Assert.Equal(type, actual.SqlDbType);
        Assert.Equal(value, actual.Value);
        if (size.HasValue) Assert.Equal(size.Value, actual.Size);
        if (scale.HasValue) Assert.Equal(scale.Value, actual.Scale);
    }
}
