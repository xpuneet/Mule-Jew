using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.TestUtils.Builders;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Text.Json;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class PurchaseOrdersRepositoryTests
{
    [Fact]
    public async Task AddCandidate_CreatesExactTypedCallSerializesBusinessPayloadAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var candidate = CreateCandidate();
        candidate.Payload.PurchaseOrderHeader!.Branch = -385;
        candidate.Payload.PurchaseOrderHeader.Reference = null;
        executor
            .Setup(instance => instance.ExecuteNonQueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<CancellationToken>()))
            .Callback<StoredProcedureCall, CancellationToken>((call, token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
            })
            .ReturnsAsync(1);
        var repository = CreateRepository(executor.Object);
        var previousCulture = CultureInfo.CurrentCulture;
        var distinguishingCulture = (CultureInfo)CultureInfo.InvariantCulture.Clone();
        distinguishingCulture.NumberFormat.NegativeSign = "~";

        try
        {
            CultureInfo.CurrentCulture = distinguishingCulture;
            await repository.AddCandidate(candidate, cancellationToken);
        }
        finally
        {
            CultureInfo.CurrentCulture = previousCulture;
        }

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_create_purchase_order_candidate", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, candidate.CandidateId),
            parameter => AssertParameter(parameter, "@account", SqlDbType.NVarChar, "BRIT186", size: 50),
            parameter => AssertParameter(parameter, "@branch", SqlDbType.NVarChar, "-385", size: 20),
            parameter => AssertParameter(parameter, "@reference", SqlDbType.NVarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@status", SqlDbType.VarChar, "READY_FOR_SUBMISSION", size: 50),
            parameter => AssertParameter(parameter, "@acceptedDateTime", SqlDbType.DateTimeOffset, candidate.AcceptedDateTime, scale: 3),
            parameter =>
            {
                AssertParameter(parameter, "@payloadJson", SqlDbType.NVarChar, parameter.Value, size: -1);
                var payloadJson = Assert.IsType<string>(parameter.Value);
                using var payload = JsonDocument.Parse(payloadJson);
                Assert.True(payload.RootElement.TryGetProperty("purchaseOrderHeader", out _));
                Assert.True(payload.RootElement.TryGetProperty("purchaseOrderLines", out _));
                Assert.False(payload.RootElement.TryGetProperty("candidateId", out _));
                Assert.False(payload.RootElement.TryGetProperty("source", out _));
                Assert.False(payload.RootElement.TryGetProperty("candidateStatus", out _));
                Assert.False(payload.RootElement.TryGetProperty("payload", out _));
            },
            parameter => AssertParameter(
                parameter,
                "@actor",
                SqlDbType.NVarChar,
                candidate.Payload.PurchaseOrderHeader!.CreateUser!,
                size: 256));
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public async Task SearchCandidates_CreatesExactTypedCallMapsNullableResultsAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var candidateId = Guid.Parse("035c2f5e-eb38-4c71-b455-145be69b85f1");
        var acceptedDateTime = new DateTimeOffset(2026, 7, 29, 15, 30, 0, TimeSpan.Zero);
        var acceptedAfterDateTimeUtc = acceptedDateTime.AddDays(-1);
        var acceptedUntilDateTimeUtc = acceptedDateTime.AddDays(1);
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderSummary>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderSummary> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                using var reader = CreateSearchResultReader(candidateId, acceptedDateTime);
                Assert.True(reader.Read());
                IReadOnlyList<PurchaseOrderSummary> rows = [map(reader)];
                return Task.FromResult(rows);
            });
        var repository = CreateRepository(executor.Object);
        var criteria = new PurchaseOrderSearchCriteria
        {
            Source = "Relex",
            Account = null,
            Branch = null,
            Reference = null,
            IconPurchaseOrderNumber = null,
            Status = null,
            AcceptedAfterDateTimeUtc = acceptedAfterDateTimeUtc,
            AcceptedUntilDateTimeUtc = acceptedUntilDateTimeUtc,
            PageNumber = 2,
            PageSize = 25
        };

        var results = await repository.SearchCandidates(criteria, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_search_purchase_order_candidates", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@source", SqlDbType.NVarChar, "Relex", size: 50),
            parameter => AssertParameter(parameter, "@account", SqlDbType.NVarChar, DBNull.Value, size: 50),
            parameter => AssertParameter(parameter, "@branch", SqlDbType.NVarChar, DBNull.Value, size: 20),
            parameter => AssertParameter(parameter, "@reference", SqlDbType.NVarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@iconPurchaseOrderNumber", SqlDbType.NVarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@status", SqlDbType.VarChar, DBNull.Value, size: 50),
            parameter => AssertParameter(parameter, "@acceptedAfterDateTimeUtc", SqlDbType.DateTimeOffset, acceptedAfterDateTimeUtc, scale: 3),
            parameter => AssertParameter(parameter, "@acceptedUntilDateTimeUtc", SqlDbType.DateTimeOffset, acceptedUntilDateTimeUtc, scale: 3),
            parameter => AssertParameter(parameter, "@pageNumber", SqlDbType.Int, 2),
            parameter => AssertParameter(parameter, "@pageSize", SqlDbType.Int, 25));
        var result = Assert.Single(results);
        Assert.Equal(candidateId, result.CandidateId);
        Assert.Equal("Relex", result.Source);
        Assert.Equal("BRIT186", result.Account);
        Assert.Equal("385", result.Branch);
        Assert.Null(result.Reference);
        Assert.Null(result.IconPurchaseOrderNumber);
        Assert.Equal("READY_FOR_SUBMISSION", result.Status);
        Assert.Equal(acceptedDateTime, result.AcceptedDateTime);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    private static PurchaseOrderCandidate CreateCandidate() => new()
    {
        CandidateId = Guid.Parse("2acfec13-0e8c-465a-8827-3dd89c35fb3d"),
        Source = PurchaseOrderSources.Api,
        Payload = PurchaseOrderRequestBuilder.ValidPurchaseOrder(),
        CandidateStatus = new CandidateStatus
        {
            Status = PurchaseOrderCandidateStatus.ReadyForSubmission
        },
        AcceptedDateTime = new DateTimeOffset(2026, 7, 29, 14, 15, 16, TimeSpan.Zero)
    };

    private static PurchaseOrdersRepository CreateRepository(IStoredProcedureExecutor executor)
    {
        var constructor = typeof(PurchaseOrdersRepository).GetConstructor([typeof(IStoredProcedureExecutor)]);
        Assert.True(
            constructor is not null,
            "PurchaseOrdersRepository must expose the Task 9 IStoredProcedureExecutor constructor.");
        return Assert.IsType<PurchaseOrdersRepository>(constructor.Invoke([executor]));
    }

    private static DbDataReader CreateSearchResultReader(Guid candidateId, DateTimeOffset acceptedDateTime)
    {
        var table = new DataTable();
        table.Columns.Add("CandidateId", typeof(Guid));
        table.Columns.Add("Source", typeof(string));
        table.Columns.Add("Account", typeof(string));
        table.Columns.Add("Branch", typeof(string));
        table.Columns.Add("Reference", typeof(string));
        table.Columns.Add("IconPurchaseOrderNumber", typeof(string));
        table.Columns.Add("Status", typeof(string));
        table.Columns.Add("AcceptedDateTime", typeof(DateTimeOffset));
        table.Rows.Add(
            candidateId,
            "Relex",
            "BRIT186",
            "385",
            DBNull.Value,
            DBNull.Value,
            "READY_FOR_SUBMISSION",
            acceptedDateTime);
        return table.CreateDataReader();
    }

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        if (ReferenceEquals(value, DBNull.Value))
        {
            Assert.Same(DBNull.Value, parameter.Value);
            return;
        }

        Assert.Equal(value, parameter.Value);
    }
}
