using Microsoft.Data.SqlClient;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Collections;
using System.Data;
using System.Data.Common;
using System.Diagnostics.CodeAnalysis;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class StoredProcedureExecutorTests
{
    private const string SingleRowInvariantMessage =
        "The stored procedure result must contain exactly one row.";

    [Fact]
    public async Task ExecuteNonQueryAsync_ConfiguresCommandForwardsCancellationAndDisposesResources()
    {
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var firstParameter = SqlParameterFactory.UniqueIdentifier("@candidateId", Guid.NewGuid());
        var secondParameter = SqlParameterFactory.NVarChar("@source", 50, "RELEX");
        var fixture = CreateNonQueryFixture(3);
        var call = new StoredProcedureCall(
            "po.sp_create_purchase_order_candidate",
            [firstParameter, secondParameter]);

        var result = await fixture.Executor.ExecuteNonQueryAsync(call, cancellationToken);

        Assert.Equal(3, result);
        Assert.Equal(call.ProcedureName, fixture.Connection.Command.CommandText);
        Assert.Equal(CommandType.StoredProcedure, fixture.Connection.Command.CommandType);
        Assert.Equal(2, fixture.Connection.Command.Parameters.Count);
        Assert.Same(firstParameter, fixture.Connection.Command.Parameters[0]);
        Assert.Same(secondParameter, fixture.Connection.Command.Parameters[1]);
        Assert.Equal(cancellationToken, fixture.Connection.OpenCancellationToken);
        Assert.Equal(cancellationToken, fixture.Connection.Command.ExecuteNonQueryCancellationToken);
        Assert.Equal(1, fixture.Factory.CreateCount);
        Assert.True(fixture.Connection.Command.AsyncDisposed);
        Assert.True(fixture.Connection.AsyncDisposed);
    }

    [Fact]
    public async Task QueryAsync_MapsRowsForwardsCancellationAndDisposesResources()
    {
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var fixture = CreateQueryFixture(7, 9);

        var results = await fixture.Executor.QueryAsync(
            new StoredProcedureCall("po.sp_search_purchase_order_candidates", []),
            reader => reader.GetInt32(reader.GetOrdinal("Value")),
            cancellationToken);

        Assert.Equal(new[] { 7, 9 }, results);
        Assert.Equal(cancellationToken, fixture.Connection.OpenCancellationToken);
        Assert.Equal(cancellationToken, fixture.Connection.Command.ExecuteReaderCancellationToken);
        Assert.Equal(3, fixture.Connection.Command.Reader.ReadCancellationTokens.Count);
        Assert.All(
            fixture.Connection.Command.Reader.ReadCancellationTokens,
            token => Assert.Equal(cancellationToken, token));
        Assert.True(fixture.Connection.Command.Reader.AsyncDisposed);
        Assert.True(fixture.Connection.Command.AsyncDisposed);
        Assert.True(fixture.Connection.AsyncDisposed);
    }

    [Fact]
    public async Task QuerySingleAsync_WhenExactlyOneRow_ReturnsMappedValue()
    {
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var fixture = CreateQueryFixture(42);

        var result = await fixture.Executor.QuerySingleAsync(
            new StoredProcedureCall("po.sp_get_purchase_order_candidate", []),
            reader => reader.GetInt32(reader.GetOrdinal("Value")),
            cancellationToken);

        Assert.Equal(42, result);
        Assert.Equal(cancellationToken, fixture.Connection.OpenCancellationToken);
        Assert.Equal(cancellationToken, fixture.Connection.Command.ExecuteReaderCancellationToken);
        Assert.Equal(2, fixture.Connection.Command.Reader.ReadCancellationTokens.Count);
        Assert.All(
            fixture.Connection.Command.Reader.ReadCancellationTokens,
            token => Assert.Equal(cancellationToken, token));
        Assert.True(fixture.Connection.Command.Reader.AsyncDisposed);
        Assert.True(fixture.Connection.Command.AsyncDisposed);
        Assert.True(fixture.Connection.AsyncDisposed);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(2)]
    public async Task QuerySingleAsync_WhenCardinalityIsWrong_ThrowsSanitizedInvariantAndDisposesResources(
        int rowCount)
    {
        var values = Enumerable.Range(1, rowCount).ToArray();
        var fixture = CreateQueryFixture(values);

        var exception = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            fixture.Executor.QuerySingleAsync(
                new StoredProcedureCall("po.sp_get_purchase_order_candidate", []),
                reader => reader.GetInt32(reader.GetOrdinal("Value")),
                CancellationToken.None));

        Assert.Equal(SingleRowInvariantMessage, exception.Message);
        Assert.Null(exception.InnerException);
        Assert.True(fixture.Connection.Command.Reader.AsyncDisposed);
        Assert.True(fixture.Connection.Command.AsyncDisposed);
        Assert.True(fixture.Connection.AsyncDisposed);
    }

    private static ExecutorFixture CreateQueryFixture(params int[] values) =>
        CreateFixture(1, values);

    private static ExecutorFixture CreateNonQueryFixture(int nonQueryResult) =>
        CreateFixture(nonQueryResult, []);

    private static ExecutorFixture CreateFixture(int nonQueryResult, params int[] values)
    {
        var reader = new FakeDbDataReader(
            ["Value"],
            values.Select(value => new object?[] { value }).ToArray());
        var connection = new FakeDbConnection(reader, nonQueryResult);
        var factory = new FakeConnectionFactory(connection);
        return new ExecutorFixture(new StoredProcedureExecutor(factory), factory, connection);
    }

    private sealed record ExecutorFixture(
        StoredProcedureExecutor Executor,
        FakeConnectionFactory Factory,
        FakeDbConnection Connection);

    private sealed class FakeConnectionFactory(FakeDbConnection connection) : ISqlConnectionFactory
    {
        public int CreateCount { get; private set; }

        public DbConnection Create()
        {
            CreateCount++;
            return connection;
        }
    }

    private sealed class FakeDbConnection : DbConnection
    {
        private ConnectionState _state = ConnectionState.Closed;

        public FakeDbConnection(FakeDbDataReader reader, int nonQueryResult)
        {
            Command = new FakeDbCommand(reader, nonQueryResult);
        }

        public FakeDbCommand Command { get; }

        public CancellationToken OpenCancellationToken { get; private set; }

        public bool AsyncDisposed { get; private set; }

        [AllowNull]
        public override string ConnectionString { get; set; } = "fake";

        public override string Database => "FakeDatabase";

        public override string DataSource => "FakeDataSource";

        public override string ServerVersion => "1.0";

        public override ConnectionState State => _state;

        public override void ChangeDatabase(string databaseName)
        {
        }

        public override void Close() => _state = ConnectionState.Closed;

        public override void Open() => _state = ConnectionState.Open;

        public override Task OpenAsync(CancellationToken cancellationToken)
        {
            OpenCancellationToken = cancellationToken;
            _state = ConnectionState.Open;
            return Task.CompletedTask;
        }

        public override ValueTask DisposeAsync()
        {
            AsyncDisposed = true;
            _state = ConnectionState.Closed;
            return ValueTask.CompletedTask;
        }

        protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel) =>
            throw new NotSupportedException();

        protected override DbCommand CreateDbCommand()
        {
            Command.SetConnection(this);
            return Command;
        }
    }

    private sealed class FakeDbCommand(
        FakeDbDataReader reader,
        int nonQueryResult) : DbCommand
    {
        private readonly FakeDbParameterCollection _parameters = new();
        private DbConnection? _connection;

        public FakeDbDataReader Reader { get; } = reader;

        public CancellationToken ExecuteNonQueryCancellationToken { get; private set; }

        public CancellationToken ExecuteReaderCancellationToken { get; private set; }

        public bool AsyncDisposed { get; private set; }

        [AllowNull]
        public override string CommandText { get; set; } = string.Empty;

        public override int CommandTimeout { get; set; }

        public override CommandType CommandType { get; set; }

        public override bool DesignTimeVisible { get; set; }

        public override UpdateRowSource UpdatedRowSource { get; set; }

        protected override DbConnection? DbConnection
        {
            get => _connection;
            set => _connection = value;
        }

        protected override DbParameterCollection DbParameterCollection => _parameters;

        protected override DbTransaction? DbTransaction { get; set; }

        public void SetConnection(DbConnection connection) => _connection = connection;

        public override void Cancel()
        {
        }

        public override int ExecuteNonQuery() => nonQueryResult;

        public override object? ExecuteScalar() => null;

        public override void Prepare()
        {
        }

        public override Task<int> ExecuteNonQueryAsync(CancellationToken cancellationToken)
        {
            ExecuteNonQueryCancellationToken = cancellationToken;
            return Task.FromResult(nonQueryResult);
        }

        public override ValueTask DisposeAsync()
        {
            AsyncDisposed = true;
            return ValueTask.CompletedTask;
        }

        protected override DbParameter CreateDbParameter() => new SqlParameter();

        protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior) => Reader;

        protected override Task<DbDataReader> ExecuteDbDataReaderAsync(
            CommandBehavior behavior,
            CancellationToken cancellationToken)
        {
            ExecuteReaderCancellationToken = cancellationToken;
            return Task.FromResult<DbDataReader>(Reader);
        }
    }

    private sealed class FakeDbParameterCollection : DbParameterCollection
    {
        private readonly List<DbParameter> _parameters = [];

        public override int Count => _parameters.Count;

        public override object SyncRoot => ((ICollection)_parameters).SyncRoot;

        public override int Add(object value)
        {
            _parameters.Add((DbParameter)value);
            return _parameters.Count - 1;
        }

        public override void AddRange(Array values)
        {
            foreach (var value in values)
            {
                Add(value!);
            }
        }

        public override void Clear() => _parameters.Clear();

        public override bool Contains(object value) => _parameters.Contains((DbParameter)value);

        public override bool Contains(string value) => IndexOf(value) >= 0;

        public override void CopyTo(Array array, int index) =>
            ((ICollection)_parameters).CopyTo(array, index);

        public override IEnumerator GetEnumerator() => _parameters.GetEnumerator();

        public override int IndexOf(object value) => _parameters.IndexOf((DbParameter)value);

        public override int IndexOf(string parameterName) =>
            _parameters.FindIndex(parameter =>
                string.Equals(parameter.ParameterName, parameterName, StringComparison.Ordinal));

        public override void Insert(int index, object value) =>
            _parameters.Insert(index, (DbParameter)value);

        public override void Remove(object value) => _parameters.Remove((DbParameter)value);

        public override void RemoveAt(int index) => _parameters.RemoveAt(index);

        public override void RemoveAt(string parameterName)
        {
            var index = IndexOf(parameterName);
            if (index >= 0)
            {
                RemoveAt(index);
            }
        }

        protected override DbParameter GetParameter(int index) => _parameters[index];

        protected override DbParameter GetParameter(string parameterName) =>
            _parameters[IndexOf(parameterName)];

        protected override void SetParameter(int index, DbParameter value) =>
            _parameters[index] = value;

        protected override void SetParameter(string parameterName, DbParameter value)
        {
            var index = IndexOf(parameterName);
            if (index < 0)
            {
                _parameters.Add(value);
                return;
            }

            _parameters[index] = value;
        }
    }

    private sealed class FakeDbDataReader(
        IReadOnlyList<string> columns,
        IReadOnlyList<object?[]> rows) : DbDataReader
    {
        private bool _isClosed;
        private int _rowIndex = -1;

        public List<CancellationToken> ReadCancellationTokens { get; } = [];

        public bool AsyncDisposed { get; private set; }

        public override int Depth => 0;

        public override int FieldCount => columns.Count;

        public override bool HasRows => rows.Count > 0;

        public override bool IsClosed => _isClosed;

        public override int RecordsAffected => -1;

        public override object this[int ordinal] => GetValue(ordinal);

        public override object this[string name] => GetValue(GetOrdinal(name));

        public override bool GetBoolean(int ordinal) => (bool)GetValue(ordinal);

        public override byte GetByte(int ordinal) => (byte)GetValue(ordinal);

        public override long GetBytes(
            int ordinal,
            long dataOffset,
            byte[]? buffer,
            int bufferOffset,
            int length)
        {
            var value = (byte[])GetValue(ordinal);
            var available = Math.Min(length, value.Length - (int)dataOffset);
            if (buffer is not null)
            {
                Array.Copy(value, dataOffset, buffer, bufferOffset, available);
            }

            return available;
        }

        public override char GetChar(int ordinal) => (char)GetValue(ordinal);

        public override long GetChars(
            int ordinal,
            long dataOffset,
            char[]? buffer,
            int bufferOffset,
            int length)
        {
            var value = GetString(ordinal).ToCharArray();
            var available = Math.Min(length, value.Length - (int)dataOffset);
            if (buffer is not null)
            {
                Array.Copy(value, dataOffset, buffer, bufferOffset, available);
            }

            return available;
        }

        public override string GetDataTypeName(int ordinal) => GetFieldType(ordinal).Name;

        public override DateTime GetDateTime(int ordinal) => (DateTime)GetValue(ordinal);

        public override decimal GetDecimal(int ordinal) => (decimal)GetValue(ordinal);

        public override double GetDouble(int ordinal) => (double)GetValue(ordinal);

        public override IEnumerator GetEnumerator() => rows.GetEnumerator();

        public override Type GetFieldType(int ordinal)
        {
            var value = rows.Select(row => row[ordinal]).FirstOrDefault(item => item is not null);
            return value?.GetType() ?? typeof(object);
        }

        public override float GetFloat(int ordinal) => (float)GetValue(ordinal);

        public override Guid GetGuid(int ordinal) => (Guid)GetValue(ordinal);

        public override short GetInt16(int ordinal) => (short)GetValue(ordinal);

        public override int GetInt32(int ordinal) => (int)GetValue(ordinal);

        public override long GetInt64(int ordinal) => (long)GetValue(ordinal);

        public override string GetName(int ordinal) => columns[ordinal];

        public override int GetOrdinal(string name)
        {
            for (var ordinal = 0; ordinal < columns.Count; ordinal++)
            {
                if (string.Equals(columns[ordinal], name, StringComparison.Ordinal))
                {
                    return ordinal;
                }
            }

            throw new IndexOutOfRangeException("The requested fake reader column does not exist.");
        }

        public override string GetString(int ordinal) => (string)GetValue(ordinal);

        public override object GetValue(int ordinal) =>
            rows[_rowIndex][ordinal] ?? DBNull.Value;

        public override int GetValues(object[] values)
        {
            var count = Math.Min(values.Length, FieldCount);
            for (var ordinal = 0; ordinal < count; ordinal++)
            {
                values[ordinal] = GetValue(ordinal);
            }

            return count;
        }

        public override bool IsDBNull(int ordinal) =>
            ReferenceEquals(GetValue(ordinal), DBNull.Value);

        public override bool NextResult() => false;

        public override bool Read()
        {
            if (_rowIndex + 1 >= rows.Count)
            {
                return false;
            }

            _rowIndex++;
            return true;
        }

        public override Task<bool> ReadAsync(CancellationToken cancellationToken)
        {
            ReadCancellationTokens.Add(cancellationToken);
            return Task.FromResult(Read());
        }

        public override ValueTask DisposeAsync()
        {
            AsyncDisposed = true;
            _isClosed = true;
            return ValueTask.CompletedTask;
        }
    }
}
