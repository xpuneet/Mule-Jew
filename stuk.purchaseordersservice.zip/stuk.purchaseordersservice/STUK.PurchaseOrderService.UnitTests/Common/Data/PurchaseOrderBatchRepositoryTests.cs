using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class PurchaseOrderBatchRepositoryTests
{
    [Fact]
    public void Constructor_WhenExecutorIsNull_ThrowsArgumentNullException()
    {
        Assert.Throws<ArgumentNullException>(() => new PurchaseOrderBatchRepository(null!));
    }

    [Fact]
    public async Task RegisterBatchAsync_CreatesExactTypedCallMapsSingleResultAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var rowVersion = Bytes(8, 11);
        var command = new RegisterPurchaseOrderBatchCommand(
            Guid.Parse("a84c2534-f569-470d-b43f-b1e34538c01c"),
            "purchase-orders-20260729.csv",
            "purchase-orders/4b0f48d9.csv",
            128_456,
            Bytes(32, 31),
            null,
            new DateTimeOffset(2026, 7, 29, 8, 15, 16, TimeSpan.Zero),
            "relex-ingestion");
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchState>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchState> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                using var reader = CreateReader(
                    [
                        ("BatchId", typeof(Guid)),
                        ("Status", typeof(string)),
                        ("RowVersion", typeof(byte[]))
                    ],
                    command.BatchId,
                    "INGESTING",
                    rowVersion);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
        var repository = new PurchaseOrderBatchRepository(executor.Object);

        var result = await repository.RegisterBatchAsync(command, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_register_purchase_order_batch", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, command.BatchId),
            parameter => AssertParameter(parameter, "@originalFileName", SqlDbType.NVarChar, command.OriginalFileName, size: 260),
            parameter => AssertParameter(parameter, "@sourceFilePath", SqlDbType.NVarChar, command.SourceFilePath, size: 512),
            parameter => AssertParameter(parameter, "@fileContentLength", SqlDbType.BigInt, command.FileContentLength),
            parameter => AssertParameter(parameter, "@fileSha256", SqlDbType.Binary, command.FileSha256, size: 32),
            parameter => AssertParameter(parameter, "@expectedRowCount", SqlDbType.Int, DBNull.Value),
            parameter => AssertParameter(parameter, "@discoveredDateTime", SqlDbType.DateTimeOffset, command.DiscoveredDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@actor", SqlDbType.NVarChar, command.Actor, size: 256));
        Assert.Equal(command.BatchId, result.BatchId);
        Assert.Equal("INGESTING", result.Status);
        Assert.Equal(rowVersion, result.RowVersion);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public async Task AddCandidateAsync_CreatesExactTypedNonQueryCallAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new AddPurchaseOrderCandidateToBatchCommand(
            Guid.Parse("45af2fd3-1fa7-40cf-88fc-902405659cc8"),
            Guid.Parse("e3c6b43f-0f45-4272-ac40-571070fbcd54"),
            "BRIT186",
            "385",
            null,
            2,
            new DateTimeOffset(2026, 7, 29, 9, 10, 11, TimeSpan.Zero),
            "{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}",
            "relex-ingestion");
        executor
            .Setup(instance => instance.ExecuteNonQueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<CancellationToken>()))
            .Callback<StoredProcedureCall, CancellationToken>((call, token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
            })
            .ReturnsAsync(1);
        var repository = new PurchaseOrderBatchRepository(executor.Object);

        await repository.AddCandidateAsync(command, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_add_purchase_order_candidate_to_batch", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, command.BatchId),
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, command.CandidateId),
            parameter => AssertParameter(parameter, "@account", SqlDbType.NVarChar, command.Account, size: 50),
            parameter => AssertParameter(parameter, "@branch", SqlDbType.NVarChar, command.Branch, size: 20),
            parameter => AssertParameter(parameter, "@reference", SqlDbType.NVarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@sourceRowCount", SqlDbType.Int, command.SourceRowCount),
            parameter => AssertParameter(parameter, "@acceptedDateTime", SqlDbType.DateTimeOffset, command.AcceptedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@payloadJson", SqlDbType.NVarChar, command.PayloadJson, size: -1),
            parameter => AssertParameter(parameter, "@actor", SqlDbType.NVarChar, command.Actor, size: 256));
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public async Task CompleteBatchAsync_CreatesExactTypedCallMapsSingleResultAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var expectedRowVersion = Bytes(8, 41);
        var returnedRowVersion = Bytes(8, 51);
        var command = new CompletePurchaseOrderBatchCommand(
            Guid.Parse("0b99cebe-7d7e-49a2-8354-68dcf05d37c0"),
            17,
            23,
            new DateTimeOffset(2026, 7, 29, 10, 11, 12, TimeSpan.Zero),
            "relex-ingestion",
            expectedRowVersion);
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchPromotionResult>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchPromotionResult> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                using var reader = CreateReader(
                    [
                        ("BatchId", typeof(Guid)),
                        ("Status", typeof(string)),
                        ("PromotedCandidateCount", typeof(int)),
                        ("RowVersion", typeof(byte[]))
                    ],
                    command.BatchId,
                    "READY_FOR_SUBMISSION",
                    17,
                    returnedRowVersion);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
        var repository = new PurchaseOrderBatchRepository(executor.Object);

        var result = await repository.CompleteBatchAsync(command, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_complete_purchase_order_batch", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, command.BatchId),
            parameter => AssertParameter(parameter, "@expectedCandidateCount", SqlDbType.Int, command.ExpectedCandidateCount),
            parameter => AssertParameter(parameter, "@parsedRowCount", SqlDbType.Int, command.ParsedRowCount),
            parameter => AssertParameter(parameter, "@completedDateTime", SqlDbType.DateTimeOffset, command.CompletedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@actor", SqlDbType.NVarChar, command.Actor, size: 256),
            parameter => AssertParameter(parameter, "@expectedBatchRowVersion", SqlDbType.Binary, expectedRowVersion, size: 8));
        Assert.Equal(command.BatchId, result.BatchId);
        Assert.Equal("READY_FOR_SUBMISSION", result.Status);
        Assert.Equal(17, result.PromotedCandidateCount);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public async Task FailBatchAsync_CreatesExactTypedCallMapsSingleResultAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var returnedRowVersion = Bytes(8, 71);
        var command = new FailPurchaseOrderBatchCommand(
            Guid.Parse("cd6a8029-c045-4822-baae-3a0395a88bde"),
            "CSV_INVALID",
            "The supplied file could not be parsed.",
            new DateTimeOffset(2026, 7, 29, 11, 12, 13, TimeSpan.Zero),
            "relex-ingestion",
            Bytes(8, 61));
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchState>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchState> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                using var reader = CreateReader(
                    [
                        ("BatchId", typeof(Guid)),
                        ("Status", typeof(string)),
                        ("RowVersion", typeof(byte[]))
                    ],
                    command.BatchId,
                    "FAILED",
                    returnedRowVersion);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
        var repository = new PurchaseOrderBatchRepository(executor.Object);

        var result = await repository.FailBatchAsync(command, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_fail_purchase_order_batch", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, command.BatchId),
            parameter => AssertParameter(parameter, "@failureCode", SqlDbType.VarChar, command.FailureCode, size: 100),
            parameter => AssertParameter(parameter, "@failureDescription", SqlDbType.NVarChar, command.FailureDescription, size: 1000),
            parameter => AssertParameter(parameter, "@failedDateTime", SqlDbType.DateTimeOffset, command.FailedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@actor", SqlDbType.NVarChar, command.Actor, size: 256),
            parameter => AssertParameter(parameter, "@expectedBatchRowVersion", SqlDbType.Binary, command.ExpectedBatchRowVersion, size: 8));
        Assert.Equal(command.BatchId, result.BatchId);
        Assert.Equal("FAILED", result.Status);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public async Task GetBatchAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var batchId = Guid.Parse("63a79861-3964-4abf-9a9f-b5ae530c2b20");
        var fileHash = Bytes(32, 81);
        var rowVersion = Bytes(8, 91);
        var discovered = new DateTimeOffset(2026, 7, 29, 12, 13, 14, TimeSpan.Zero);
        var ingestionStarted = discovered.AddSeconds(1);
        var updated = discovered.AddMinutes(2);
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchDetails>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchDetails> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                using var reader = CreateReader(
                    [
                        ("BatchId", typeof(Guid)),
                        ("Source", typeof(string)),
                        ("OriginalFileName", typeof(string)),
                        ("SourceFilePath", typeof(string)),
                        ("FileContentLength", typeof(long)),
                        ("FileSha256", typeof(byte[])),
                        ("Status", typeof(string)),
                        ("ExpectedRowCount", typeof(int)),
                        ("ParsedRowCount", typeof(int)),
                        ("CandidateCount", typeof(int)),
                        ("FailureCode", typeof(string)),
                        ("FailureDescription", typeof(string)),
                        ("DiscoveredDateTime", typeof(DateTimeOffset)),
                        ("IngestionStartedDateTime", typeof(DateTimeOffset)),
                        ("CompletedDateTime", typeof(DateTimeOffset)),
                        ("CreatedBy", typeof(string)),
                        ("UpdatedDateTime", typeof(DateTimeOffset)),
                        ("RowVersion", typeof(byte[]))
                    ],
                    batchId,
                    "RELEX",
                    "purchase-orders-20260729.csv",
                    "purchase-orders/4b0f48d9.csv",
                    128_456L,
                    fileHash,
                    "INGESTING",
                    DBNull.Value,
                    5,
                    5,
                    DBNull.Value,
                    DBNull.Value,
                    discovered,
                    ingestionStarted,
                    DBNull.Value,
                    "relex-ingestion",
                    updated,
                    rowVersion);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
        var repository = new PurchaseOrderBatchRepository(executor.Object);

        var result = await repository.GetBatchAsync(batchId, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_get_purchase_order_batch", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, batchId));
        Assert.Equal(batchId, result.BatchId);
        Assert.Equal("RELEX", result.Source);
        Assert.Equal("purchase-orders-20260729.csv", result.OriginalFileName);
        Assert.Equal("purchase-orders/4b0f48d9.csv", result.SourceFilePath);
        Assert.Equal(128_456L, result.FileContentLength);
        Assert.Equal(fileHash, result.FileSha256);
        Assert.Equal("INGESTING", result.Status);
        Assert.Null(result.ExpectedRowCount);
        Assert.Equal(5, result.ParsedRowCount);
        Assert.Equal(5, result.CandidateCount);
        Assert.Null(result.FailureCode);
        Assert.Null(result.FailureDescription);
        Assert.Equal(discovered, result.DiscoveredDateTime);
        Assert.Equal(ingestionStarted, result.IngestionStartedDateTime);
        Assert.Null(result.CompletedDateTime);
        Assert.Equal("relex-ingestion", result.CreatedBy);
        Assert.Equal(updated, result.UpdatedDateTime);
        Assert.Equal(rowVersion, result.RowVersion);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public async Task GetBatchBySourceHashAsync_CreatesExactTypedCallMapsResultAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var batchId = Guid.Parse("136813a5-ca67-48de-858c-57e7bc0202d3");
        var fileHash = Bytes(32, 121);
        var rowVersion = Bytes(8, 131);
        var discovered = new DateTimeOffset(2026, 7, 29, 12, 30, 0, TimeSpan.Zero);
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchDetails>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchDetails> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                using var reader = CreateReader(
                    [
                        ("BatchId", typeof(Guid)),
                        ("Source", typeof(string)),
                        ("OriginalFileName", typeof(string)),
                        ("SourceFilePath", typeof(string)),
                        ("FileContentLength", typeof(long)),
                        ("FileSha256", typeof(byte[])),
                        ("Status", typeof(string)),
                        ("ExpectedRowCount", typeof(int)),
                        ("ParsedRowCount", typeof(int)),
                        ("CandidateCount", typeof(int)),
                        ("FailureCode", typeof(string)),
                        ("FailureDescription", typeof(string)),
                        ("DiscoveredDateTime", typeof(DateTimeOffset)),
                        ("IngestionStartedDateTime", typeof(DateTimeOffset)),
                        ("CompletedDateTime", typeof(DateTimeOffset)),
                        ("CreatedBy", typeof(string)),
                        ("UpdatedDateTime", typeof(DateTimeOffset)),
                        ("RowVersion", typeof(byte[]))
                    ],
                    batchId,
                    "Relex",
                    "SG_OrderProposal_20260729.csv",
                    "/data/input/SG_OrderProposal_20260729.csv",
                    1024L,
                    fileHash,
                    "INGESTING",
                    DBNull.Value,
                    0,
                    0,
                    DBNull.Value,
                    DBNull.Value,
                    discovered,
                    discovered,
                    DBNull.Value,
                    "relex-ingestion",
                    discovered,
                    rowVersion);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
        var repository = new PurchaseOrderBatchRepository(executor.Object);

        var result = await repository.GetBatchBySourceHashAsync(
            "Relex",
            fileHash,
            cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal(
            "po.sp_get_purchase_order_batch_by_source_hash",
            capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(
                parameter,
                "@source",
                SqlDbType.NVarChar,
                "Relex",
                size: 50),
            parameter => AssertParameter(
                parameter,
                "@fileSha256",
                SqlDbType.Binary,
                fileHash,
                size: 32));
        Assert.Equal(batchId, result.BatchId);
        Assert.Equal("/data/input/SG_OrderProposal_20260729.csv", result.SourceFilePath);
        Assert.Equal(fileHash, result.FileSha256);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public void PurchaseOrderBatchStatuses_MatchSqlContract()
    {
        Assert.Equal("INGESTING", PurchaseOrderBatchStatuses.Ingesting);
        Assert.Equal("COMPLETED", PurchaseOrderBatchStatuses.Completed);
        Assert.Equal("FAILED", PurchaseOrderBatchStatuses.Failed);
    }

    [Fact]
    public void BatchRepositoryContract_DoesNotExposeSubmissionOutcomeDrivenCompletion()
    {
        Assert.Null(typeof(IPurchaseOrderBatchRepository).GetMethod(
            "CompleteBatchProcessingAsync"));
    }

    [Fact]
    public async Task GetBatchOutcomesAsync_CreatesExactTypedCallMapsEveryResultFieldAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var batchId = Guid.Parse("211c2772-f5c6-4127-b04a-e11233547421");
        var candidateId = Guid.Parse("fe45906f-c4cf-46ca-8efe-24ea5fd44ab2");
        var accepted = new DateTimeOffset(2026, 7, 29, 14, 15, 16, TimeSpan.Zero);
        var updated = accepted.AddMinutes(1);
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchOutcome>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchOutcome> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                using var reader = CreateReader(
                    [
                        ("CandidateId", typeof(Guid)),
                        ("Account", typeof(string)),
                        ("Branch", typeof(string)),
                        ("Reference", typeof(string)),
                        ("Status", typeof(string)),
                        ("IconPurchaseOrderNumber", typeof(string)),
                        ("StatusReason", typeof(string)),
                        ("AcceptedDateTime", typeof(DateTimeOffset)),
                        ("UpdatedDateTime", typeof(DateTimeOffset))
                    ],
                    candidateId,
                    "BRIT186",
                    "385",
                    DBNull.Value,
                    "NON_RECOVERABLE_ERROR",
                    DBNull.Value,
                    "ICON rejected the candidate.",
                    accepted,
                    updated);
                Assert.True(reader.Read());
                IReadOnlyList<PurchaseOrderBatchOutcome> rows = [map(reader)];
                return Task.FromResult(rows);
            });
        var repository = new PurchaseOrderBatchRepository(executor.Object);

        var results = await repository.GetBatchOutcomesAsync(batchId, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_get_purchase_order_batch_outcomes", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, batchId));
        var result = Assert.Single(results);
        Assert.Equal(candidateId, result.CandidateId);
        Assert.Equal("BRIT186", result.Account);
        Assert.Equal("385", result.Branch);
        Assert.Null(result.Reference);
        Assert.Equal("NON_RECOVERABLE_ERROR", result.Status);
        Assert.Null(result.IconPurchaseOrderNumber);
        Assert.Equal("ICON rejected the candidate.", result.StatusReason);
        Assert.Equal(accepted, result.AcceptedDateTime);
        Assert.Equal(updated, result.UpdatedDateTime);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    private static DbDataReader CreateReader(
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        var table = new DataTable();
        foreach (var (name, type) in columns)
        {
            table.Columns.Add(name, type);
        }

        table.Rows.Add(values);
        return table.CreateDataReader();
    }

    private static byte[] Bytes(int length, byte seed) =>
        Enumerable.Range(0, length).Select(offset => unchecked((byte)(seed + offset))).ToArray();

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        if (ReferenceEquals(value, DBNull.Value))
        {
            Assert.Same(DBNull.Value, parameter.Value);
            return;
        }

        Assert.Equal(value, parameter.Value);
    }
}
