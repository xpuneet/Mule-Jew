using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class PurchaseOrderEmailNotificationRepositoryTests
{
    [Fact]
    public async Task EnqueueEmailNotificationAsync_CatchesBoundedJsonOrNullableMetadataParametersAndMapsAllCounters()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new EnqueuePurchaseOrderEmailNotificationCommand(
            Guid.Parse("14bea1e3-1366-4598-af1c-f99bed0a53f8"),
            null,
            "PURCHASE_ORDER_BATCH_COMPLETED",
            "batch-2026-09-18-001",
            1,
            "{\"schemaVersion\":1}",
            null,
            "purchase-order-operations",
            null,
            new DateTimeOffset(2026, 9, 18, 8, 1, 2, TimeSpan.Zero));
        var payloadSha256 = Bytes(32, 11);
        var rowVersion = Bytes(8, 51);
        SetupSingleResult<EnqueuedPurchaseOrderEmailNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("Status", typeof(string)),
                ("NextAttemptDateTime", typeof(DateTimeOffset)),
                ("AttemptCount", typeof(int)),
                ("FailureCount", typeof(int)),
                ("ThrottleCount", typeof(int)),
                ("PayloadSha256", typeof(byte[])),
                ("RowVersion", typeof(byte[]))
            ],
            command.NotificationId,
            "PENDING",
            command.CreatedDateTime,
            2,
            3,
            4,
            payloadSha256,
            rowVersion);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.EnqueueEmailNotificationAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_enqueue_purchase_order_email_notification",
            cancellationToken,
            parameter => AssertParameter(parameter, "@notificationId", SqlDbType.UniqueIdentifier, command.NotificationId),
            parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, DBNull.Value),
            parameter => AssertParameter(parameter, "@eventType", SqlDbType.VarChar, command.EventType, size: 100),
            parameter => AssertParameter(parameter, "@businessCorrelationId", SqlDbType.NVarChar, command.BusinessCorrelationId, size: 256),
            parameter => AssertParameter(parameter, "@emailEnvelopeVersion", SqlDbType.SmallInt, command.EmailEnvelopeVersion),
            parameter => AssertParameter(parameter, "@emailEnvelopeJson", SqlDbType.NVarChar, command.EmailEnvelopeJson, size: -1),
            parameter => AssertParameter(parameter, "@templateKey", SqlDbType.NVarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@recipientGroupKey", SqlDbType.NVarChar, command.RecipientGroupKey!, size: 100),
            parameter => AssertParameter(parameter, "@attachmentBlobName", SqlDbType.NVarChar, DBNull.Value, size: 512),
            parameter => AssertParameter(parameter, "@createdDateTime", SqlDbType.DateTimeOffset, command.CreatedDateTime, scale: 3));
        Assert.Equal(command.NotificationId, result.NotificationId);
        Assert.Equal("PENDING", result.Status);
        Assert.Equal(command.CreatedDateTime, result.NextAttemptDateTime);
        Assert.Equal(2, result.AttemptCount);
        Assert.Equal(3, result.FailureCount);
        Assert.Equal(4, result.ThrottleCount);
        Assert.Equal(32, result.PayloadSha256.Length);
        Assert.Equal(payloadSha256, result.PayloadSha256);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task ClaimDueEmailNotificationsAsync_CatchesSingleRowExecutionOrDroppedQuotaParametersAndMapsEveryClaimField()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new ClaimPurchaseOrderEmailNotificationsCommand(
            new DateTimeOffset(2026, 9, 18, 8, 2, 3, TimeSpan.Zero),
            90,
            15,
            60,
            500);
        var notificationId = Guid.Parse("aef71dc7-953e-44fa-867c-1d0616914027");
        var leaseId = Guid.Parse("d0e25242-7f12-47c2-948e-d15218957502");
        var leaseExpiresDateTime = command.AsOfDateTime.AddSeconds(command.LeaseDurationSeconds);
        var payloadSha256 = Bytes(32, 21);
        var rowVersion = Bytes(8, 61);
        SetupQueryResult<ClaimedPurchaseOrderEmailNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("EventType", typeof(string)),
                ("BusinessCorrelationId", typeof(string)),
                ("EmailEnvelopeVersion", typeof(short)),
                ("EmailEnvelopeJson", typeof(string)),
                ("PayloadSha256", typeof(byte[])),
                ("AttemptCount", typeof(int)),
                ("FailureCount", typeof(int)),
                ("ThrottleCount", typeof(int)),
                ("LeaseId", typeof(Guid)),
                ("LeaseExpiresDateTime", typeof(DateTimeOffset)),
                ("RowVersion", typeof(byte[]))
            ],
            [
                notificationId,
                "PURCHASE_ORDER_BATCH_COMPLETED",
                "batch-2026-09-18-002",
                (short)1,
                "{\"schemaVersion\":1}",
                payloadSha256,
                5,
                2,
                1,
                leaseId,
                leaseExpiresDateTime,
                rowVersion
            ]);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var results = await repository.ClaimDueEmailNotificationsAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_claim_purchase_order_email_notifications",
            cancellationToken,
            parameter => AssertParameter(parameter, "@asOfDateTime", SqlDbType.DateTimeOffset, command.AsOfDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@leaseDurationSeconds", SqlDbType.Int, command.LeaseDurationSeconds),
            parameter => AssertParameter(parameter, "@maxNotifications", SqlDbType.Int, command.MaxNotifications),
            parameter => AssertParameter(parameter, "@maxAttemptsPerMinute", SqlDbType.Int, command.MaxAttemptsPerMinute),
            parameter => AssertParameter(parameter, "@maxAttemptsPerHour", SqlDbType.Int, command.MaxAttemptsPerHour));
        var result = Assert.Single(results);
        Assert.Equal(notificationId, result.NotificationId);
        Assert.Equal("PURCHASE_ORDER_BATCH_COMPLETED", result.EventType);
        Assert.Equal("batch-2026-09-18-002", result.BusinessCorrelationId);
        Assert.Equal((short)1, result.EmailEnvelopeVersion);
        Assert.Equal("{\"schemaVersion\":1}", result.EmailEnvelopeJson);
        Assert.Equal(payloadSha256, result.PayloadSha256);
        Assert.Equal(5, result.AttemptCount);
        Assert.Equal(2, result.FailureCount);
        Assert.Equal(1, result.ThrottleCount);
        Assert.Equal(leaseId, result.LeaseId);
        Assert.Equal(leaseExpiresDateTime, result.LeaseExpiresDateTime);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task DeferEmailNotificationAsync_CatchesSwappedTimestampsOrUnboundedRowVersionAndMapsBothCounters()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new DeferPurchaseOrderEmailNotificationCommand(
            Guid.Parse("f11079a6-f016-4a89-811a-f14a4ed83315"),
            Guid.Parse("6b11bbc7-7d85-41c2-9865-7e328cde82ab"),
            new DateTimeOffset(2026, 9, 18, 8, 20, 0, TimeSpan.Zero),
            new DateTimeOffset(2026, 9, 18, 8, 4, 0, TimeSpan.Zero),
            Bytes(8, 31));
        var returnedRowVersion = Bytes(8, 71);
        SetupSingleResult<UpdatedPurchaseOrderEmailNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("Status", typeof(string)),
                ("NextAttemptDateTime", typeof(DateTimeOffset)),
                ("FailureCount", typeof(int)),
                ("ThrottleCount", typeof(int)),
                ("RowVersion", typeof(byte[]))
            ],
            command.NotificationId,
            "PENDING",
            command.NextAttemptDateTime,
            6,
            7,
            returnedRowVersion);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.DeferEmailNotificationAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_defer_purchase_order_email_notification",
            cancellationToken,
            parameter => AssertParameter(parameter, "@notificationId", SqlDbType.UniqueIdentifier, command.NotificationId),
            parameter => AssertParameter(parameter, "@leaseId", SqlDbType.UniqueIdentifier, command.LeaseId),
            parameter => AssertParameter(parameter, "@nextAttemptDateTime", SqlDbType.DateTimeOffset, command.NextAttemptDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@completedDateTime", SqlDbType.DateTimeOffset, command.CompletedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@expectedNotificationRowVersion", SqlDbType.Binary, command.ExpectedNotificationRowVersion, size: 8));
        Assert.Equal(command.NotificationId, result.NotificationId);
        Assert.Equal("PENDING", result.Status);
        Assert.Equal(command.NextAttemptDateTime, result.NextAttemptDateTime);
        Assert.Equal(6, result.FailureCount);
        Assert.Equal(7, result.ThrottleCount);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task RescheduleEmailNotificationAsync_CatchesWrongNullableErrorTypesOrMissingThrottleCountMapping()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new ReschedulePurchaseOrderEmailNotificationCommand(
            Guid.Parse("18ee4ce9-bf2f-485c-8597-bbd1b3bc3484"),
            Guid.Parse("62b56665-48dd-4cdd-97c2-65c146a5cd52"),
            "THROTTLED",
            "PROVIDER",
            null,
            null,
            429,
            new DateTimeOffset(2026, 9, 18, 8, 30, 0, TimeSpan.Zero),
            new DateTimeOffset(2026, 9, 18, 8, 5, 0, TimeSpan.Zero),
            Bytes(8, 41));
        var returnedRowVersion = Bytes(8, 81);
        SetupSingleResult<UpdatedPurchaseOrderEmailNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("Status", typeof(string)),
                ("NextAttemptDateTime", typeof(DateTimeOffset)),
                ("FailureCount", typeof(int)),
                ("ThrottleCount", typeof(int)),
                ("RowVersion", typeof(byte[]))
            ],
            command.NotificationId,
            "PENDING",
            command.NextAttemptDateTime,
            8,
            9,
            returnedRowVersion);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.RescheduleEmailNotificationAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_reschedule_purchase_order_email_notification",
            cancellationToken,
            parameter => AssertParameter(parameter, "@notificationId", SqlDbType.UniqueIdentifier, command.NotificationId),
            parameter => AssertParameter(parameter, "@leaseId", SqlDbType.UniqueIdentifier, command.LeaseId),
            parameter => AssertParameter(parameter, "@outcome", SqlDbType.VarChar, command.Outcome, size: 50),
            parameter => AssertParameter(parameter, "@failureCategory", SqlDbType.VarChar, command.FailureCategory, size: 50),
            parameter => AssertParameter(parameter, "@failureCode", SqlDbType.VarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@failureDescription", SqlDbType.NVarChar, DBNull.Value, size: 1000),
            parameter => AssertParameter(parameter, "@httpStatusCode", SqlDbType.SmallInt, command.HttpStatusCode!.Value),
            parameter => AssertParameter(parameter, "@nextAttemptDateTime", SqlDbType.DateTimeOffset, command.NextAttemptDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@completedDateTime", SqlDbType.DateTimeOffset, command.CompletedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@expectedNotificationRowVersion", SqlDbType.Binary, command.ExpectedNotificationRowVersion, size: 8));
        Assert.Equal(command.NotificationId, result.NotificationId);
        Assert.Equal("PENDING", result.Status);
        Assert.Equal(command.NextAttemptDateTime, result.NextAttemptDateTime);
        Assert.Equal(8, result.FailureCount);
        Assert.Equal(9, result.ThrottleCount);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task CompleteEmailNotificationAsync_CatchesMissingAttemptOutcomeFailureIncrementOrCompletionCounters()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var command = new CompletePurchaseOrderEmailNotificationCommand(
            Guid.Parse("04b2a3f3-4e70-4bfc-ab90-041d9d835f52"),
            Guid.Parse("8a06361e-142f-421d-868f-fdb403a4061a"),
            "FAILED",
            "TRANSIENT_FAILURE",
            true,
            null,
            "PROVIDER",
            null,
            null,
            null,
            new DateTimeOffset(2026, 9, 18, 8, 6, 0, TimeSpan.Zero),
            Bytes(8, 51));
        var returnedRowVersion = Bytes(8, 91);
        SetupSingleResult<CompletedPurchaseOrderEmailNotification>(
            executor,
            capture,
            [
                ("NotificationId", typeof(Guid)),
                ("Status", typeof(string)),
                ("SentDateTime", typeof(DateTimeOffset)),
                ("CompletedDateTime", typeof(DateTimeOffset)),
                ("FailureCount", typeof(int)),
                ("ThrottleCount", typeof(int)),
                ("RowVersion", typeof(byte[]))
            ],
            command.NotificationId,
            "FAILED",
            DBNull.Value,
            command.CompletedDateTime,
            10,
            11,
            returnedRowVersion);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.CompleteEmailNotificationAsync(command, cancellationToken);

        AssertCall(
            capture,
            "po.sp_complete_purchase_order_email_notification",
            cancellationToken,
            parameter => AssertParameter(parameter, "@notificationId", SqlDbType.UniqueIdentifier, command.NotificationId),
            parameter => AssertParameter(parameter, "@leaseId", SqlDbType.UniqueIdentifier, command.LeaseId),
            parameter => AssertParameter(parameter, "@status", SqlDbType.VarChar, command.Status, size: 50),
            parameter => AssertParameter(parameter, "@attemptOutcome", SqlDbType.VarChar, command.AttemptOutcome, size: 50),
            parameter => AssertParameter(parameter, "@incrementFailureCount", SqlDbType.Bit, command.IncrementFailureCount),
            parameter => AssertParameter(parameter, "@providerMessageId", SqlDbType.NVarChar, DBNull.Value, size: 256),
            parameter => AssertParameter(parameter, "@failureCategory", SqlDbType.VarChar, command.FailureCategory!, size: 50),
            parameter => AssertParameter(parameter, "@failureCode", SqlDbType.VarChar, DBNull.Value, size: 100),
            parameter => AssertParameter(parameter, "@failureDescription", SqlDbType.NVarChar, DBNull.Value, size: 1000),
            parameter => AssertParameter(parameter, "@httpStatusCode", SqlDbType.SmallInt, DBNull.Value),
            parameter => AssertParameter(parameter, "@completedDateTime", SqlDbType.DateTimeOffset, command.CompletedDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@expectedNotificationRowVersion", SqlDbType.Binary, command.ExpectedNotificationRowVersion, size: 8));
        Assert.Equal(command.NotificationId, result.NotificationId);
        Assert.Equal("FAILED", result.Status);
        Assert.Null(result.SentDateTime);
        Assert.Equal(command.CompletedDateTime, result.CompletedDateTime);
        Assert.Equal(10, result.FailureCount);
        Assert.Equal(11, result.ThrottleCount);
        Assert.Equal(returnedRowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task GetEmailNotificationQueueSummaryAsync_CatchesInt32ReadsOfSqlBigIntCountsAndMapsNullOldestTimestamp()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var capture = new CallCapture();
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var query = new GetPurchaseOrderEmailNotificationQueueSummaryQuery(
            new DateTimeOffset(2026, 9, 18, 8, 7, 0, TimeSpan.Zero),
            new DateTimeOffset(2026, 9, 17, 8, 7, 0, TimeSpan.Zero));
        SetupSingleResult<PurchaseOrderEmailNotificationQueueSummary>(
            executor,
            capture,
            [
                ("ClaimablePendingCount", typeof(long)),
                ("OldestClaimablePendingDateTime", typeof(DateTimeOffset)),
                ("DelayedPendingCount", typeof(long)),
                ("ActiveLeasedCount", typeof(long)),
                ("ExpiredLeasedCount", typeof(long)),
                ("UnsendableLegacyPendingCount", typeof(long)),
                ("TerminalFailureCount", typeof(long))
            ],
            12L,
            DBNull.Value,
            13L,
            14L,
            15L,
            16L,
            17L);
        var repository = new PurchaseOrderNotificationRepository(executor.Object);

        var result = await repository.GetEmailNotificationQueueSummaryAsync(query, cancellationToken);

        AssertCall(
            capture,
            "po.sp_get_purchase_order_email_notification_queue_summary",
            cancellationToken,
            parameter => AssertParameter(parameter, "@asOfDateTime", SqlDbType.DateTimeOffset, query.AsOfDateTime, scale: 3),
            parameter => AssertParameter(parameter, "@terminalFailureSinceDateTime", SqlDbType.DateTimeOffset, query.TerminalFailureSinceDateTime, scale: 3));
        Assert.Equal(12, result.ClaimablePendingCount);
        Assert.Null(result.OldestClaimablePendingDateTime);
        Assert.Equal(13, result.DelayedPendingCount);
        Assert.Equal(14, result.ActiveLeasedCount);
        Assert.Equal(15, result.ExpiredLeasedCount);
        Assert.Equal(16, result.UnsendableLegacyPendingCount);
        Assert.Equal(17, result.TerminalFailureCount);
        executor.VerifyAll();
    }

    private static void SetupSingleResult<T>(
        Mock<IStoredProcedureExecutor> executor,
        CallCapture capture,
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, T>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, T> map,
                CancellationToken cancellationToken) =>
            {
                capture.Call = call;
                capture.CancellationToken = cancellationToken;
                using var reader = CreateReader(columns, values);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
    }

    private static void SetupQueryResult<T>(
        Mock<IStoredProcedureExecutor> executor,
        CallCapture capture,
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[][] rows)
    {
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, T>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, T> map,
                CancellationToken cancellationToken) =>
            {
                capture.Call = call;
                capture.CancellationToken = cancellationToken;
                using var reader = CreateReader(columns, rows);
                var results = new List<T>();
                while (reader.Read())
                {
                    results.Add(map(reader));
                }

                return Task.FromResult<IReadOnlyList<T>>(results);
            });
    }

    private static DbDataReader CreateReader(
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[][] rows)
    {
        var table = new DataTable();
        foreach (var (name, type) in columns)
        {
            table.Columns.Add(name, type);
        }

        foreach (var row in rows)
        {
            table.Rows.Add(row);
        }

        return table.CreateDataReader();
    }

    private static DbDataReader CreateReader(
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values) =>
        CreateReader(columns, [values]);

    private static void AssertCall(
        CallCapture capture,
        string procedureName,
        CancellationToken cancellationToken,
        params Action<SqlParameter>[] parameterAssertions)
    {
        Assert.NotNull(capture.Call);
        Assert.Equal(procedureName, capture.Call.ProcedureName);
        Assert.Collection(capture.Call.Parameters, parameterAssertions);
        Assert.Equal(cancellationToken, capture.CancellationToken);
    }

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        if (ReferenceEquals(value, DBNull.Value))
        {
            Assert.Same(DBNull.Value, parameter.Value);
            return;
        }

        Assert.Equal(value, parameter.Value);
    }

    private static byte[] Bytes(int length, byte seed) =>
        Enumerable.Range(0, length).Select(offset => unchecked((byte)(seed + offset))).ToArray();

    private sealed class CallCapture
    {
        public StoredProcedureCall? Call { get; set; }

        public CancellationToken CancellationToken { get; set; }
    }
}
