using Microsoft.Data.SqlClient;
using Moq;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using System.Data;
using System.Data.Common;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class PurchaseOrderAdminRepositoryTests
{
    [Fact]
    public async Task GetStatusSummaryAsync_CreatesExactTypedCallMapsInt64CountsAndForwardsCancellation()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        CancellationToken capturedCancellationToken = default;
        using var cancellationSource = new CancellationTokenSource();
        var cancellationToken = cancellationSource.Token;
        var query = new PurchaseOrderStatusSummaryQuery(
            "Relex",
            new DateTimeOffset(2026, 8, 4, 12, 0, 0, TimeSpan.Zero),
            new DateTimeOffset(2026, 8, 5, 12, 0, 0, TimeSpan.Zero));
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderStatusCount>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderStatusCount> map,
                CancellationToken token) =>
            {
                capturedCall = call;
                capturedCancellationToken = token;
                var table = new DataTable();
                table.Columns.Add("Status", typeof(string));
                table.Columns.Add("CandidateCount", typeof(long));
                table.Rows.Add("RECOVERABLE_ERROR", 17L);
                using var reader = table.CreateDataReader();
                Assert.True(reader.Read());
                IReadOnlyList<PurchaseOrderStatusCount> result = [map(reader)];
                return Task.FromResult(result);
            });
        var repository = new PurchaseOrderAdminRepository(executor.Object);

        var result = await repository.GetStatusSummaryAsync(query, cancellationToken);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_get_purchase_order_candidate_summary", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@source", SqlDbType.NVarChar, query.Source, size: 50),
            parameter => AssertParameter(parameter, "@afterDateTimeUtc", SqlDbType.DateTimeOffset, query.AfterDateTimeUtc, scale: 3),
            parameter => AssertParameter(parameter, "@untilDateTimeUtc", SqlDbType.DateTimeOffset, query.UntilDateTimeUtc, scale: 3));
        var count = Assert.Single(result);
        Assert.Equal("RECOVERABLE_ERROR", count.Status);
        Assert.Equal(17L, count.CandidateCount);
        Assert.Equal(cancellationToken, capturedCancellationToken);
        executor.VerifyAll();
    }

    [Fact]
    public async Task GetCandidateAsync_CreatesExactTypedCallMapsNullableLeaseAndRowVersion()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        var candidateId = Guid.Parse("607a940c-a5cc-42b2-a7ab-1a91bbb44181");
        var batchId = Guid.Parse("09ed945e-10f5-4518-a3bc-a6059314e0a8");
        var statusDateTime = new DateTimeOffset(2026, 8, 5, 9, 45, 0, TimeSpan.Zero);
        var acceptedDateTime = statusDateTime.AddMinutes(-5);
        var rowVersion = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
        executor
            .Setup(instance => instance.QuerySingleAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderCandidateDetails>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderCandidateDetails> map,
                CancellationToken _) =>
            {
                capturedCall = call;
                using var reader = CreateCandidateReader(
                    candidateId,
                    batchId,
                    statusDateTime,
                    acceptedDateTime,
                    rowVersion);
                Assert.True(reader.Read());
                return Task.FromResult(map(reader));
            });
        var repository = new PurchaseOrderAdminRepository(executor.Object);

        var result = await repository.GetCandidateAsync(candidateId);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_get_purchase_order_candidate", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@candidateId", SqlDbType.UniqueIdentifier, candidateId));
        Assert.Equal(candidateId, result.CandidateId);
        Assert.Equal(batchId, result.BatchId);
        Assert.Equal("Relex", result.Source);
        Assert.Equal("RELEX", result.Kind);
        Assert.Equal("BRIT186", result.Account);
        Assert.Equal("385", result.Branch);
        Assert.Equal("PO-123", result.Reference);
        Assert.Equal("ICON-987", result.IconPurchaseOrderNumber);
        Assert.Equal("RECOVERABLE_ERROR", result.Status);
        Assert.Equal(statusDateTime, result.StatusDateTime);
        Assert.Equal("Retry is available.", result.StatusReason);
        Assert.Equal(42, result.ProcessBatchNo);
        Assert.Equal("ABC123", result.PayloadMd5);
        Assert.Equal("ICON_TIMEOUT", result.MessageCode);
        Assert.Equal("ICON timed out.", result.MessageDescription);
        Assert.Equal("VALIDATED", result.PreviousMessageCode);
        Assert.Equal("Candidate validated.", result.PreviousMessageDescription);
        Assert.Equal("{\"purchaseOrderHeader\":{}}", result.PayloadJson);
        Assert.Equal(acceptedDateTime, result.AcceptedDateTime);
        Assert.Equal(acceptedDateTime, result.CreatedDateTime);
        Assert.Equal(statusDateTime, result.UpdatedDateTime);
        Assert.Equal(statusDateTime, result.RefreshDateTime);
        Assert.Equal(2, result.PendingRetriesCount);
        Assert.Equal(1, result.ProcessingRetriesCount);
        Assert.Null(result.LeaseToken);
        Assert.Null(result.LeaseOwner);
        Assert.Null(result.LeaseAcquiredDateTime);
        Assert.Null(result.LeaseExpiresDateTime);
        Assert.Equal(rowVersion, result.RowVersion);
        executor.VerifyAll();
    }

    [Fact]
    public async Task GetBatchStatusSummaryAsync_CreatesExactTypedCallAndMapsInt64Count()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        var query = new PurchaseOrderBatchStatusSummaryQuery(
            "Relex",
            new DateTimeOffset(2026, 8, 24, 8, 0, 0, TimeSpan.Zero),
            new DateTimeOffset(2026, 8, 24, 12, 0, 0, TimeSpan.Zero));
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchStatusCount>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchStatusCount> map,
                CancellationToken _) =>
            {
                capturedCall = call;
                using var reader = CreateReader(
                    [("Status", typeof(string)), ("BatchCount", typeof(long))],
                    "PROCESSING",
                    7L);
                Assert.True(reader.Read());
                IReadOnlyList<PurchaseOrderBatchStatusCount> rows = [map(reader)];
                return Task.FromResult(rows);
            });
        var repository = new PurchaseOrderAdminRepository(executor.Object);

        var result = await repository.GetBatchStatusSummaryAsync(query);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_get_purchase_order_batch_summary", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@source", SqlDbType.NVarChar, query.Source, size: 50),
            parameter => AssertParameter(parameter, "@afterDateTimeUtc", SqlDbType.DateTimeOffset, query.AfterDateTimeUtc, scale: 3),
            parameter => AssertParameter(parameter, "@untilDateTimeUtc", SqlDbType.DateTimeOffset, query.UntilDateTimeUtc, scale: 3));
        var count = Assert.Single(result);
        Assert.Equal("PROCESSING", count.Status);
        Assert.Equal(7L, count.BatchCount);
        executor.VerifyAll();
    }

    [Fact]
    public async Task SearchBatchesAsync_CreatesExactTypedCallAndMapsNullableFields()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        StoredProcedureCall? capturedCall = null;
        var batchId = Guid.Parse("ad518cc8-ae91-4dd8-ab67-6620a6cc6364");
        var discovered = new DateTimeOffset(2026, 8, 24, 10, 0, 0, TimeSpan.Zero);
        var query = new PurchaseOrderBatchSearchQuery(
            "Relex",
            "proposal",
            "FAILED",
            discovered.AddDays(-1),
            discovered.AddDays(1),
            2,
            26);
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchSummary>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchSummary> map,
                CancellationToken _) =>
            {
                capturedCall = call;
                using var reader = CreateReader(
                    [
                        ("BatchId", typeof(Guid)),
                        ("Source", typeof(string)),
                        ("OriginalFileName", typeof(string)),
                        ("SourceFilePath", typeof(string)),
                        ("FileContentLength", typeof(long)),
                        ("Status", typeof(string)),
                        ("ExpectedRowCount", typeof(int)),
                        ("ParsedRowCount", typeof(int)),
                        ("CandidateCount", typeof(int)),
                        ("FailureCode", typeof(string)),
                        ("DiscoveredDateTime", typeof(DateTimeOffset)),
                        ("CompletedDateTime", typeof(DateTimeOffset)),
                        ("UpdatedDateTime", typeof(DateTimeOffset))
                    ],
                    batchId,
                    "Relex",
                    "SG_OrderProposal_failed.csv",
                    "/data/input/SG_OrderProposal_failed.csv",
                    1234L,
                    "FAILED",
                    DBNull.Value,
                    0,
                    0,
                    "RELEX_INVALID_HEADER",
                    discovered,
                    discovered.AddMinutes(1),
                    discovered.AddMinutes(1));
                Assert.True(reader.Read());
                IReadOnlyList<PurchaseOrderBatchSummary> rows = [map(reader)];
                return Task.FromResult(rows);
            });
        var repository = new PurchaseOrderAdminRepository(executor.Object);

        var result = await repository.SearchBatchesAsync(query);

        Assert.NotNull(capturedCall);
        Assert.Equal("po.sp_search_purchase_order_batches", capturedCall.ProcedureName);
        Assert.Collection(
            capturedCall.Parameters,
            parameter => AssertParameter(parameter, "@source", SqlDbType.NVarChar, query.Source, size: 50),
            parameter => AssertParameter(parameter, "@originalFileName", SqlDbType.NVarChar, query.OriginalFileName!, size: 260),
            parameter => AssertParameter(parameter, "@status", SqlDbType.VarChar, query.Status!, size: 50),
            parameter => AssertParameter(parameter, "@discoveredAfterDateTimeUtc", SqlDbType.DateTimeOffset, query.DiscoveredAfterDateTimeUtc, scale: 3),
            parameter => AssertParameter(parameter, "@discoveredUntilDateTimeUtc", SqlDbType.DateTimeOffset, query.DiscoveredUntilDateTimeUtc, scale: 3),
            parameter => AssertParameter(parameter, "@pageNumber", SqlDbType.Int, query.PageNumber),
            parameter => AssertParameter(parameter, "@pageSize", SqlDbType.Int, query.PageSize));
        var batch = Assert.Single(result);
        Assert.Equal(batchId, batch.BatchId);
        Assert.Null(batch.ExpectedRowCount);
        Assert.Equal("RELEX_INVALID_HEADER", batch.FailureCode);
        Assert.Equal(discovered.AddMinutes(1), batch.CompletedDateTime);
        executor.VerifyAll();
    }

    [Fact]
    public async Task BatchCandidateReads_UseSelectedBatchAndBoundedPaging()
    {
        var executor = new Mock<IStoredProcedureExecutor>(MockBehavior.Strict);
        var batchId = Guid.Parse("65737f99-6004-43e2-819d-f0cc151cc3f9");
        var candidateId = Guid.Parse("608b5a8c-70a4-4307-acd1-a459010d433b");
        var accepted = new DateTimeOffset(2026, 8, 24, 11, 0, 0, TimeSpan.Zero);
        var calls = new List<StoredProcedureCall>();
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderStatusCount>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderStatusCount> map,
                CancellationToken _) =>
            {
                calls.Add(call);
                using var reader = CreateReader(
                    [("Status", typeof(string)), ("CandidateCount", typeof(long))],
                    "COMPLETED",
                    5L);
                Assert.True(reader.Read());
                IReadOnlyList<PurchaseOrderStatusCount> rows = [map(reader)];
                return Task.FromResult(rows);
            });
        executor
            .Setup(instance => instance.QueryAsync(
                It.IsAny<StoredProcedureCall>(),
                It.IsAny<Func<DbDataReader, PurchaseOrderBatchOutcome>>(),
                It.IsAny<CancellationToken>()))
            .Returns((
                StoredProcedureCall call,
                Func<DbDataReader, PurchaseOrderBatchOutcome> map,
                CancellationToken _) =>
            {
                calls.Add(call);
                using var reader = CreateReader(
                    [
                        ("CandidateId", typeof(Guid)),
                        ("Account", typeof(string)),
                        ("Branch", typeof(string)),
                        ("Reference", typeof(string)),
                        ("Status", typeof(string)),
                        ("IconPurchaseOrderNumber", typeof(string)),
                        ("StatusReason", typeof(string)),
                        ("AcceptedDateTime", typeof(DateTimeOffset)),
                        ("UpdatedDateTime", typeof(DateTimeOffset))
                    ],
                    candidateId,
                    "BRIT186",
                    "385",
                    "PO-24",
                    "COMPLETED",
                    "ICON-24",
                    DBNull.Value,
                    accepted,
                    accepted.AddMinutes(2));
                Assert.True(reader.Read());
                IReadOnlyList<PurchaseOrderBatchOutcome> rows = [map(reader)];
                return Task.FromResult(rows);
            });
        var repository = new PurchaseOrderAdminRepository(executor.Object);

        var summary = await repository.GetBatchCandidateStatusSummaryAsync(batchId);
        var rows = await repository.SearchBatchCandidatesAsync(
            new PurchaseOrderBatchCandidateSearchQuery(batchId, "COMPLETED", 1, 26));

        Assert.Equal(5L, Assert.Single(summary).CandidateCount);
        Assert.Equal(candidateId, Assert.Single(rows).CandidateId);
        Assert.Collection(
            calls,
            call =>
            {
                Assert.Equal("po.sp_get_purchase_order_batch_candidate_summary", call.ProcedureName);
                Assert.Collection(call.Parameters, parameter =>
                    AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, batchId));
            },
            call =>
            {
                Assert.Equal("po.sp_search_purchase_order_batch_candidates", call.ProcedureName);
                Assert.Collection(
                    call.Parameters,
                    parameter => AssertParameter(parameter, "@batchId", SqlDbType.UniqueIdentifier, batchId),
                    parameter => AssertParameter(parameter, "@status", SqlDbType.VarChar, "COMPLETED", size: 50),
                    parameter => AssertParameter(parameter, "@pageNumber", SqlDbType.Int, 1),
                    parameter => AssertParameter(parameter, "@pageSize", SqlDbType.Int, 26));
            });
        executor.VerifyAll();
    }

    private static DbDataReader CreateCandidateReader(
        Guid candidateId,
        Guid batchId,
        DateTimeOffset statusDateTime,
        DateTimeOffset acceptedDateTime,
        byte[] rowVersion)
    {
        var table = new DataTable();
        table.Columns.Add("CandidateId", typeof(Guid));
        table.Columns.Add("BatchId", typeof(Guid));
        table.Columns.Add("Source", typeof(string));
        table.Columns.Add("Kind", typeof(string));
        table.Columns.Add("Account", typeof(string));
        table.Columns.Add("Branch", typeof(string));
        table.Columns.Add("Reference", typeof(string));
        table.Columns.Add("IconPurchaseOrderNumber", typeof(string));
        table.Columns.Add("Status", typeof(string));
        table.Columns.Add("StatusDateTime", typeof(DateTimeOffset));
        table.Columns.Add("StatusReason", typeof(string));
        table.Columns.Add("ProcessBatchNo", typeof(int));
        table.Columns.Add("PayloadMD5", typeof(string));
        table.Columns.Add("MessageCode", typeof(string));
        table.Columns.Add("MessageDescription", typeof(string));
        table.Columns.Add("PreviousMessageCode", typeof(string));
        table.Columns.Add("PreviousMessageDescription", typeof(string));
        table.Columns.Add("PayloadJson", typeof(string));
        table.Columns.Add("AcceptedDateTime", typeof(DateTimeOffset));
        table.Columns.Add("CreatedDateTime", typeof(DateTimeOffset));
        table.Columns.Add("UpdatedDateTime", typeof(DateTimeOffset));
        table.Columns.Add("RefreshDateTime", typeof(DateTimeOffset));
        table.Columns.Add("PendingRetriesCount", typeof(int));
        table.Columns.Add("ProcessingRetriesCount", typeof(int));
        table.Columns.Add("LeaseToken", typeof(Guid));
        table.Columns.Add("LeaseOwner", typeof(string));
        table.Columns.Add("LeaseAcquiredDateTime", typeof(DateTimeOffset));
        table.Columns.Add("LeaseExpiresDateTime", typeof(DateTimeOffset));
        table.Columns.Add("RowVersion", typeof(byte[]));
        table.Rows.Add(
            candidateId,
            batchId,
            "Relex",
            "RELEX",
            "BRIT186",
            "385",
            "PO-123",
            "ICON-987",
            "RECOVERABLE_ERROR",
            statusDateTime,
            "Retry is available.",
            42,
            "ABC123",
            "ICON_TIMEOUT",
            "ICON timed out.",
            "VALIDATED",
            "Candidate validated.",
            "{\"purchaseOrderHeader\":{}}",
            acceptedDateTime,
            acceptedDateTime,
            statusDateTime,
            statusDateTime,
            2,
            1,
            DBNull.Value,
            DBNull.Value,
            DBNull.Value,
            DBNull.Value,
            rowVersion);
        return table.CreateDataReader();
    }

    private static DbDataReader CreateReader(
        IReadOnlyList<(string Name, Type Type)> columns,
        params object[] values)
    {
        var table = new DataTable();
        foreach (var (name, type) in columns)
        {
            table.Columns.Add(name, type);
        }

        table.Rows.Add(values);
        return table.CreateDataReader();
    }

    private static void AssertParameter(
        SqlParameter parameter,
        string name,
        SqlDbType type,
        object value,
        int? size = null,
        byte? scale = null)
    {
        Assert.Equal(name, parameter.ParameterName);
        Assert.Equal(type, parameter.SqlDbType);
        if (size.HasValue)
        {
            Assert.Equal(size.Value, parameter.Size);
        }

        if (scale.HasValue)
        {
            Assert.Equal(scale.Value, parameter.Scale);
        }

        Assert.Equal(value, parameter.Value);
    }
}
