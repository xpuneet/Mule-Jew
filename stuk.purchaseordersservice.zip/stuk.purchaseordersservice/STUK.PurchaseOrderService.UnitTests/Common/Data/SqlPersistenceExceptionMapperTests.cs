using STUK.PurchaseOrderService.Common.Data.Sql;

namespace STUK.PurchaseOrderService.UnitTests.Common.Data;

public sealed class SqlPersistenceExceptionMapperTests
{
    [Theory]
    [InlineData(51001, PurchaseOrderPersistenceError.EntityNotFound)]
    [InlineData(51002, PurchaseOrderPersistenceError.ConcurrencyConflict)]
    [InlineData(51003, PurchaseOrderPersistenceError.LeaseConflict)]
    [InlineData(51004, PurchaseOrderPersistenceError.InvalidLifecycleTransition)]
    [InlineData(51005, PurchaseOrderPersistenceError.DuplicateSourceFile)]
    [InlineData(51006, PurchaseOrderPersistenceError.BatchValidationMismatch)]
    [InlineData(2601, PurchaseOrderPersistenceError.Unclassified)]
    public void Map_UsesOnlyTheSqlErrorNumber(
        int sqlErrorNumber,
        PurchaseOrderPersistenceError expectedError)
    {
        var exception = SqlPersistenceExceptionMapper.Map(sqlErrorNumber);

        Assert.Equal(expectedError, exception.Error);
        Assert.Equal(sqlErrorNumber, exception.SqlErrorNumber);
        Assert.Equal(ExpectedMessage(expectedError), exception.Message);
        Assert.Null(exception.InnerException);
        Assert.DoesNotContain(sqlErrorNumber.ToString(), exception.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void ErrorValues_MatchStableSqlErrorNumbers()
    {
        Assert.Equal(51001, (int)PurchaseOrderPersistenceError.EntityNotFound);
        Assert.Equal(51002, (int)PurchaseOrderPersistenceError.ConcurrencyConflict);
        Assert.Equal(51003, (int)PurchaseOrderPersistenceError.LeaseConflict);
        Assert.Equal(51004, (int)PurchaseOrderPersistenceError.InvalidLifecycleTransition);
        Assert.Equal(51005, (int)PurchaseOrderPersistenceError.DuplicateSourceFile);
        Assert.Equal(51006, (int)PurchaseOrderPersistenceError.BatchValidationMismatch);
        Assert.Equal(0, (int)PurchaseOrderPersistenceError.Unclassified);
    }

    private static string ExpectedMessage(PurchaseOrderPersistenceError error) => error switch
    {
        PurchaseOrderPersistenceError.EntityNotFound =>
            "The requested persistence entity was not found.",
        PurchaseOrderPersistenceError.ConcurrencyConflict =>
            "The persistence operation encountered a concurrency conflict.",
        PurchaseOrderPersistenceError.LeaseConflict =>
            "The persistence operation encountered a lease conflict.",
        PurchaseOrderPersistenceError.InvalidLifecycleTransition =>
            "The persistence operation requested an invalid lifecycle transition.",
        PurchaseOrderPersistenceError.DuplicateSourceFile =>
            "The source file has already been registered.",
        PurchaseOrderPersistenceError.BatchValidationMismatch =>
            "The persistence operation encountered a batch validation mismatch.",
        _ => "The persistence operation failed."
    };
}
