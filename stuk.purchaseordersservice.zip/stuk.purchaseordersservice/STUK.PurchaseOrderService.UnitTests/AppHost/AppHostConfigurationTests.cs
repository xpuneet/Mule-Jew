using System.Text.Json;
using System.Xml.Linq;

namespace STUK.PurchaseOrderService.UnitTests.AppHost;

public sealed class AppHostConfigurationTests
{
    [Fact]
    public void Project_PersistsAspireGeneratedSecrets()
    {
        var project = XDocument.Load(GetTestDataPath("STUK.PurchaseOrderService.AppHost.csproj"));
        var userSecretsId = project
            .Descendants("UserSecretsId")
            .Select(element => element.Value)
            .SingleOrDefault();

        Assert.False(
            string.IsNullOrWhiteSpace(userSecretsId),
            "Persistent Aspire resources require UserSecretsId so generated passwords survive restarts.");
    }

    [Fact]
    public void HttpLaunchProfile_AllowsUnsecuredTransport()
    {
        using var document = JsonDocument.Parse(
            File.ReadAllText(GetTestDataPath("launchSettings.json")));

        var environmentVariables = document.RootElement
            .GetProperty("profiles")
            .GetProperty("http")
            .GetProperty("environmentVariables");

        Assert.Equal(
            "true",
            environmentVariables
                .GetProperty("ASPIRE_ALLOW_UNSECURED_TRANSPORT")
                .GetString());
    }

    [Fact]
    public void Program_UsesAspireScopedSqlDataVolume()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));

        Assert.Contains(".WithDataVolume()", program, StringComparison.Ordinal);
        Assert.DoesNotContain(
            "stuk-purchase-orders-sql-data",
            program,
            StringComparison.Ordinal);
    }

    [Fact]
    public void Program_PurchaseOrderAdminReferencesAndWaitsForPurchaseOrdersDatabase()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));
        var purchaseOrderAdmin = System.Text.RegularExpressions.Regex.Match(
            program,
            @"AddProject<Projects\.STUK_PurchaseOrderService_PurchaseOrderAdmin>\(\""web-app\""\)(?<chain>.*?);",
            System.Text.RegularExpressions.RegexOptions.Singleline).Groups["chain"].Value;

        Assert.Contains(
            ".WithReference(purchaseOrdersDatabase)",
            purchaseOrderAdmin,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WaitFor(purchaseOrdersDatabase)",
            purchaseOrderAdmin,
            StringComparison.Ordinal);
    }

    [Fact]
    public void Program_PurchaseOrderAdminSuppliesCoreUiRouteConfiguration()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));

        Assert.Contains(
            "purchaseOrderAdmin.GetEndpoint(\"http\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(".WithEnvironment(\"HostURL\"", program, StringComparison.Ordinal);
        Assert.Contains(".WithEnvironment(\"AppURI\"", program, StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"WebApp__EnableLocalDevelopmentAuthentication\", \"true\")",
            program,
            StringComparison.Ordinal);
    }

    [Fact]
    public void Program_SuppliesSharedConfigurationReloadIntervalToBothWebHosts()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));

        Assert.Equal(
            2,
            program.Split(
                ".WithEnvironment(\"DatabaseConfigurationRefreshInterval\", \"60\")",
                StringSplitOptions.None).Length - 1);
    }

    [Fact]
    public void Program_ConfiguresLocalRelexFolderEmulationAndFastTimers()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));

        Assert.Contains(
            "Environment.GetEnvironmentVariable(\"STUK_RELEX_LOCAL_ROOT\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            "OperatingSystem.IsWindows()",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            "Path.Combine(Path.DirectorySeparatorChar.ToString(), \"tmp\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            "Path.Combine(localTempRoot, \"stuk-purchase-orders\", \"relex\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains("Path.Combine(\"data\", \"input\")", program, StringComparison.Ordinal);
        Assert.Contains(
            "Path.Combine(\"data\", \"output\", \"archive\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            "Path.Combine(\"data\", \"output\", \"error\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains("Directory.CreateDirectory", program, StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionCronExpression\", \"*/5 * * * * *\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionSettings__Provider\", \"Local\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionSettings__LocalRootPath\", relexLocalRoot)",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionSettings__InputPath\", \"/data/input\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionSettings__ArchivePath\", \"/data/output/archive\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionSettings__ErrorPath\", \"/data/output/error\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionSettings__FilePattern\", \"SG_OrderProposal*.csv\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"RelexIngestionSettings__MinimumFileAgeSeconds\", \"2\")",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            "Environment.GetEnvironmentVariable(\"STUK_PROCESSOR_SUBMISSION_ENABLED\") ?? \"true\"",
            program,
            StringComparison.Ordinal);
        Assert.Contains(
            ".WithEnvironment(\"BatchProcessorSettings__SubmissionEnabled\", submissionEnabled)",
            program,
            StringComparison.Ordinal);
    }

    [Fact]
    public void CreationScript_SeedsPoConfigurationAfterVerifiedDeployment()
    {
        var creationScript = File.ReadAllText(GetTestDataPath("PurchaseOrderCreationScript.cs"));

        Assert.DoesNotContain("orders-configuration", creationScript, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("local/001-po-configuration-seed.sql", creationScript, StringComparison.Ordinal);
        Assert.True(
            creationScript.IndexOf("purchase-order/100-verify.sql", StringComparison.Ordinal) <
            creationScript.IndexOf("local/001-po-configuration-seed.sql", StringComparison.Ordinal),
            "The local po configuration seed must run only after schema verification.");

        var localSeed = File.ReadAllText(GetTestDataPath("LocalSql", "001-po-configuration-seed.sql"));
        Assert.Contains("[po].[ApplicationSetting]", localSeed, StringComparison.Ordinal);
        Assert.DoesNotContain("[orders]", localSeed, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void CreationScript_DeploysWebAppProceduresBeforeSecurityAndVerification()
    {
        var creationScript = File.ReadAllText(GetTestDataPath("PurchaseOrderCreationScript.cs"));

        var supportIndex = creationScript.IndexOf(
            "purchase-order/080-support-notification-procedures.sql",
            StringComparison.Ordinal);
        var webAppIndex = creationScript.IndexOf(
            "purchase-order/085-webapp-procedures.sql",
            StringComparison.Ordinal);
        var securityIndex = creationScript.IndexOf(
            "purchase-order/090-security.sql",
            StringComparison.Ordinal);
        var verificationIndex = creationScript.IndexOf(
            "purchase-order/100-verify.sql",
            StringComparison.Ordinal);

        Assert.True(supportIndex < webAppIndex);
        Assert.True(webAppIndex < securityIndex);
        Assert.True(securityIndex < verificationIndex);
    }

    private static string GetTestDataPath(params string[] pathParts) => Path.Combine(
        AppContext.BaseDirectory,
        "TestData",
        "AppHost",
        Path.Combine(pathParts));
}
