using System.Text.Json;
using System.Xml.Linq;

namespace STUK.PurchaseOrderService.UnitTests.Deployment;

public sealed class ProcessorFunctionsDeploymentContractTests
{
    [Fact]
    public void FunctionsHost_UsesKeyVaultAndFailClosedDeploymentConfiguration()
    {
        var appSettingsText = Read(
            "STUK.PurchaseOrderService.Processor.Functions/appsettings.json");

        Assert.Contains("\"AzureKeyVaultUri\"", appSettingsText, StringComparison.Ordinal);

        using var document = JsonDocument.Parse(appSettingsText);
        var root = document.RootElement;

        Assert.Equal(string.Empty, root.GetProperty("AzureKeyVaultUri").GetString());
        Assert.Equal(
            string.Empty,
            root.GetProperty("ConnectionStrings")
                .GetProperty("PurchaseOrdersServiceDB")
                .GetString());
        Assert.Equal(
            "0 */15 * * * *",
            root.GetProperty("RelexIngestionCronExpression").GetString());
        Assert.Equal(
            "0 */1 * * * *",
            root.GetProperty("EmailNotificationSenderCronExpression").GetString());

        var emailSettings = root.GetProperty("EmailSender");
        Assert.False(emailSettings.GetProperty("SendingEnabled").GetBoolean());
        Assert.Equal(
            string.Empty,
            emailSettings.GetProperty("DefaultSenderAddress").GetString());
        Assert.False(emailSettings.TryGetProperty("AcsEndpoint", out _));
        var smtpSettings = emailSettings.GetProperty("Smtp");
        Assert.Equal(string.Empty, smtpSettings.GetProperty("Host").GetString());
        Assert.Equal(0, smtpSettings.GetProperty("Port").GetInt32());
        Assert.False(smtpSettings.GetProperty("UseStartTls").GetBoolean());
        Assert.Equal(string.Empty, smtpSettings.GetProperty("Username").GetString());
        Assert.Equal(string.Empty, smtpSettings.GetProperty("Password").GetString());
        Assert.Equal(10, emailSettings.GetProperty("ClaimBatchSize").GetInt32());
        Assert.Equal(4, emailSettings.GetProperty("MaxConcurrency").GetInt32());
        Assert.Equal(120, emailSettings.GetProperty("LeaseDurationSeconds").GetInt32());
        Assert.Equal(50, emailSettings.GetProperty("MaxRunDurationSeconds").GetInt32());
        Assert.Equal(
            30,
            emailSettings.GetProperty("ProviderOperationTimeoutSeconds").GetInt32());
        Assert.Equal(
            10,
            emailSettings.GetProperty("CompletionSafetyMarginSeconds").GetInt32());
        Assert.Equal(
            10,
            emailSettings.GetProperty("OutcomePersistenceTimeoutSeconds").GetInt32());
        Assert.Equal(8, emailSettings.GetProperty("MaxFailureCount").GetInt32());
        Assert.Equal(60, emailSettings.GetProperty("InitialRetryDelaySeconds").GetInt32());
        Assert.Equal(3600, emailSettings.GetProperty("MaxRetryDelaySeconds").GetInt32());
        Assert.Equal(10, emailSettings.GetProperty("RetryJitterSeconds").GetInt32());
        Assert.Equal(
            60,
            emailSettings.GetProperty("ThrottleFallbackDelaySeconds").GetInt32());
        var rateLimit = emailSettings.GetProperty("RateLimit");
        Assert.Equal(0, rateLimit.GetProperty("MaxAttemptsPerMinute").GetInt32());
        Assert.Equal(0, rateLimit.GetProperty("MaxAttemptsPerHour").GetInt32());

        var relexSettings = root.GetProperty("RelexIngestionSettings");
        Assert.Equal("Sftp", relexSettings.GetProperty("Provider").GetString());
        Assert.Equal("/data/input", relexSettings.GetProperty("InputPath").GetString());
        Assert.Equal(
            "/data/output/archive",
            relexSettings.GetProperty("ArchivePath").GetString());
        Assert.Equal(
            "/data/output/error",
            relexSettings.GetProperty("ErrorPath").GetString());
        Assert.Equal(
            "SG_OrderProposal*.csv",
            relexSettings.GetProperty("FilePattern").GetString());
        Assert.Equal(120, relexSettings.GetProperty("MinimumFileAgeSeconds").GetInt32());
        Assert.Equal(60, relexSettings.GetProperty("OperationTimeoutSeconds").GetInt32());
        foreach (var secretName in new[]
                 {
                     "SftpHost",
                     "SftpUsername",
                     "SftpPassword"
                 })
        {
            Assert.Equal(string.Empty, relexSettings.GetProperty(secretName).GetString());
        }
        Assert.False(relexSettings.TryGetProperty("SftpPrivateKey", out _));
        Assert.False(relexSettings.TryGetProperty("SftpPrivateKeyPassphrase", out _));
        Assert.False(relexSettings.TryGetProperty("SftpHostKeySha256", out _));

        var processorSettings = root.GetProperty("BatchProcessorSettings");
        Assert.False(processorSettings.GetProperty("SubmissionEnabled").GetBoolean());

        var iconSettings = root.GetProperty("IconSettings");
        Assert.True(iconSettings.GetProperty("HttpRequestTimeoutSeconds").GetInt32() > 0);
        Assert.Equal(
            "CF_ICXI0002",
            iconSettings.GetProperty("PurchaseOrderActivationOptionsReportName").GetString());
        Assert.Equal(string.Empty, iconSettings.GetProperty("K8_XI_AuthToken").GetString());
        Assert.Equal(string.Empty, iconSettings.GetProperty("ReportsAuthToken").GetString());
        Assert.Equal(string.Empty, iconSettings.GetProperty("PurchaseOrderAuthToken").GetString());

        var program = Read("STUK.PurchaseOrderService.Processor.Functions/Program.cs");
        Assert.Contains(
            "using Microsoft.Extensions.Configuration;",
            program,
            StringComparison.Ordinal);
        var keyVaultRegistration = program.IndexOf(
            "builder.Configuration.AddAzureKeyVault",
            StringComparison.Ordinal);
        var processorRegistration = program.IndexOf(
            "builder.Services.AddPurchaseOrderProcessor",
            StringComparison.Ordinal);

        Assert.True(keyVaultRegistration >= 0, "The Functions host must register Key Vault.");
        Assert.True(
            keyVaultRegistration < processorRegistration,
            "Key Vault must be loaded before processor services bind configuration.");
        Assert.Contains("DefaultAzureCredential", program, StringComparison.Ordinal);

        var emailFunction = Read(
            "STUK.PurchaseOrderService.Processor.Functions/Functions/" +
            "EmailNotificationSenderFunction.cs");
        Assert.Contains(
            "[TimerTrigger(\"%EmailNotificationSenderCronExpression%\")]",
            emailFunction,
            StringComparison.Ordinal);
        Assert.Contains("IEmailNotificationProcessor", emailFunction, StringComparison.Ordinal);
        Assert.Contains(
            "ILogger<EmailNotificationSenderFunction>",
            emailFunction,
            StringComparison.Ordinal);
        var constructorParameters = ExtractConstructorParameters(
            emailFunction,
            "EmailNotificationSenderFunction");
        Assert.Equal(2, constructorParameters.Split(',').Length);
        Assert.Contains("IEmailNotificationProcessor", constructorParameters, StringComparison.Ordinal);
        Assert.Contains(
            "ILogger<EmailNotificationSenderFunction>",
            constructorParameters,
            StringComparison.Ordinal);
        Assert.Contains("run started", emailFunction, StringComparison.Ordinal);
        Assert.DoesNotContain("run completed", emailFunction, StringComparison.Ordinal);
        Assert.DoesNotContain("Claimed={ClaimedCount}", emailFunction, StringComparison.Ordinal);
        Assert.DoesNotContain("EmailEnvelope", emailFunction, StringComparison.Ordinal);
        Assert.DoesNotContain("SenderAddress", emailFunction, StringComparison.Ordinal);

        var relexFunction = Read(
            "STUK.PurchaseOrderService.Processor.Functions/Functions/" +
            "RelexPurchaseOrderIngestionFunction.cs");
        Assert.Contains(
            "[TimerTrigger(\"%RelexIngestionCronExpression%\")]",
            relexFunction,
            StringComparison.Ordinal);
        Assert.Contains("IRelexIngestionService", relexFunction, StringComparison.Ordinal);
        Assert.DoesNotContain("IRelexFileStore", relexFunction, StringComparison.Ordinal);
        Assert.DoesNotContain("IPurchaseOrderBatchRepository", relexFunction, StringComparison.Ordinal);
        Assert.DoesNotContain("Icon", relexFunction, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("Email", relexFunction, StringComparison.OrdinalIgnoreCase);

        using var localSettings = JsonDocument.Parse(Read(
            "STUK.PurchaseOrderService.Processor.Functions/local.settings.json"));
        Assert.Equal(
            "0 */15 * * * *",
            localSettings.RootElement.GetProperty("Values")
                .GetProperty("RelexIngestionCronExpression")
                .GetString());
        Assert.Equal(
            "0 */1 * * * *",
            localSettings.RootElement.GetProperty("Values")
                .GetProperty("EmailNotificationSenderCronExpression")
                .GetString());
        Assert.Equal(
            "false",
            localSettings.RootElement.GetProperty("Values")
                .GetProperty("EmailSender__SendingEnabled")
                .GetString());
        Assert.Equal(
            string.Empty,
            localSettings.RootElement.GetProperty("Values")
                .GetProperty("EmailSender__Smtp__Host")
                .GetString());
        Assert.Equal(
            "0",
            localSettings.RootElement.GetProperty("Values")
                .GetProperty("EmailSender__Smtp__Port")
                .GetString());
        Assert.Equal(
            "false",
            localSettings.RootElement.GetProperty("Values")
                .GetProperty("EmailSender__Smtp__UseStartTls")
                .GetString());
        Assert.Equal(
            string.Empty,
            localSettings.RootElement.GetProperty("Values")
                .GetProperty("EmailSender__Smtp__Username")
                .GetString());
        Assert.False(localSettings.RootElement.GetProperty("Values")
            .TryGetProperty("EmailSender__Smtp__Password", out _));

        var project = Read(
            "STUK.PurchaseOrderService.Processor.Functions/" +
            "STUK.PurchaseOrderService.Processor.Functions.csproj");
        Assert.Contains(
            "Azure.Extensions.AspNetCore.Configuration.Secrets",
            project,
            StringComparison.Ordinal);
        Assert.Contains("Azure.Identity", project, StringComparison.Ordinal);
        Assert.Contains("CopyToPublishDirectory=\"Never\"", project, StringComparison.Ordinal);

        var processorProject = XDocument.Parse(Read(
            "STUK.PurchaseOrderService.Processor/" +
            "STUK.PurchaseOrderService.Processor.csproj"));
        var processorPackages = processorProject
            .Descendants("PackageReference")
            .Select(element => (string?)element.Attribute("Include"))
            .ToArray();
        Assert.DoesNotContain("Azure.Communication.Email", processorPackages);
        Assert.DoesNotContain("Azure.Identity", processorPackages);
    }

    [Fact]
    public void CiPipeline_BuildsDedicatedFunctionsArtifactFromDevelopmentAndReleaseBranches()
    {
        var ci = Read(
            "STUK.PurchaseOrderService.Processor.Functions/Deploy/azureDeploy-CI.yml");

        Assert.Contains("- development", ci, StringComparison.Ordinal);
        Assert.Contains("- release/*", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Processor.Functions/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Processor/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Common.Data/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Common.Contracts/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.UnitTests/**", ci, StringComparison.Ordinal);
        Assert.Contains("nugetConfigPath: 'nuget.config'", ci, StringComparison.Ordinal);
        Assert.Contains(
            "projects: 'STUK.PurchaseOrderService.sln'",
            ci,
            StringComparison.Ordinal);
        Assert.Contains(
            "projects: 'STUK.PurchaseOrderService.Processor.Functions/" +
            "STUK.PurchaseOrderService.Processor.Functions.csproj'",
            ci,
            StringComparison.Ordinal);
        Assert.Contains(
            "artifactName: 'STUK.PurchaseOrderService.Processor.Functions-functionapp'",
            ci,
            StringComparison.Ordinal);
        Assert.Contains(
            "condition: ne(variables['Build.Reason'], 'PullRequest')",
            ci,
            StringComparison.Ordinal);
        Assert.Contains("deploy-ready", ci, StringComparison.Ordinal);
        Assert.Contains("refs/heads/development", ci, StringComparison.Ordinal);
    }

    [Fact]
    public void CdPipeline_DeploysDevelopmentToDevAndManualReleaseThroughQaAndProd()
    {
        var cd = Read(
            "STUK.PurchaseOrderService.Processor.Functions/Deploy/azureDeploy-CD.yml");

        Assert.Contains("source: PurchaseOrderServiceFunctions-CI", cd, StringComparison.Ordinal);
        Assert.Contains("- deploy-ready", cd, StringComparison.Ordinal);
        Assert.Contains("refs/heads/development", cd, StringComparison.Ordinal);
        Assert.Contains("refs/heads/release/", cd, StringComparison.Ordinal);
        Assert.Contains("dependsOn: []", cd, StringComparison.Ordinal);
        Assert.Contains("dependsOn: QA", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-FunctionApp-PurchaseOrderService-DEV", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-FunctionApp-PurchaseOrderService-QA", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-FunctionApp-PurchaseOrderService-PROD", cd, StringComparison.Ordinal);
        Assert.Contains(
            "artifact: STUK.PurchaseOrderService.Processor.Functions-functionapp",
            cd,
            StringComparison.Ordinal);
        Assert.Contains(
            "STUK.PurchaseOrderService.Processor.Functions.zip",
            cd,
            StringComparison.Ordinal);
        Assert.Equal(
            6,
            cd.Split(
                "appName: $(PurchaseOrderFunctionAppName)",
                StringSplitOptions.None).Length - 1);
        Assert.Contains("sc-sub-starkuk-integration-services-dev", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-tst", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-prd", cd, StringComparison.Ordinal);
        Assert.Equal(
            3,
            cd.Split("task: FileTransform@2", StringSplitOptions.None).Length - 1);
        Assert.Equal(
            3,
            cd.Split("task: AzureFunctionApp@2", StringSplitOptions.None).Length - 1);
        Assert.Equal(
            3,
            cd.Split("appSettings: >", StringSplitOptions.None).Length - 1);
        foreach (var runtimeSetting in new[]
                 {
                     "-AZURE_CLIENT_ID \"$(AZURE_CLIENT_ID)\"",
                     "-ReadyCandidatesProcessorCronExpression \"$(ReadyCandidatesProcessorCronExpression)\"",
                     "-RelexIngestionCronExpression \"$(RelexIngestionCronExpression)\"",
                     "-BatchProcessorSettings__SubmissionEnabled \"$(BatchProcessorSettings.SubmissionEnabled)\""
                 })
        {
            Assert.Equal(
                3,
                cd.Split(runtimeSetting, StringSplitOptions.None).Length - 1);
        }

        var expectedSettings = new[]
        {
            "AzureKeyVaultUri",
            "EmailNotificationSenderCronExpression",
            "EmailSender__SendingEnabled",
            "EmailSender__Smtp__Host",
            "EmailSender__Smtp__Port",
            "EmailSender__Smtp__UseStartTls",
            "EmailSender__Smtp__Username",
            "EmailSender__DefaultSenderAddress",
            "EmailSender__ClaimBatchSize",
            "EmailSender__MaxConcurrency",
            "EmailSender__LeaseDurationSeconds",
            "EmailSender__MaxRunDurationSeconds",
            "EmailSender__ProviderOperationTimeoutSeconds",
            "EmailSender__CompletionSafetyMarginSeconds",
            "EmailSender__OutcomePersistenceTimeoutSeconds",
            "EmailSender__MaxFailureCount",
            "EmailSender__InitialRetryDelaySeconds",
            "EmailSender__MaxRetryDelaySeconds",
            "EmailSender__RetryJitterSeconds",
            "EmailSender__ThrottleFallbackDelaySeconds",
            "EmailSender__RateLimit__MaxAttemptsPerMinute",
            "EmailSender__RateLimit__MaxAttemptsPerHour"
        };
        Assert.DoesNotContain("EmailSender__AcsEndpoint", cd, StringComparison.Ordinal);
        Assert.DoesNotContain("EmailSender__Smtp__Password", cd, StringComparison.Ordinal);
        AssertStageEmailSettings(
            cd,
            "DEV",
            "QA",
            "sc-sub-starkuk-integration-services-dev",
            expectedSettings);
        AssertStageEmailSettings(
            cd,
            "QA",
            "PROD",
            "sc-sub-starkuk-integration-services-tst",
            expectedSettings);
        AssertStageEmailSettings(
            cd,
            "PROD",
            null,
            "sc-sub-starkuk-integration-services-prd",
            expectedSettings);

        var configurationDocumentation = Read(
            "docs/database/purchase-order-stored-procedures.md");
        Assert.Contains("`EmailSender:Smtp:Host`", configurationDocumentation, StringComparison.Ordinal);
        Assert.Contains("`EmailSender:Smtp:Port`", configurationDocumentation, StringComparison.Ordinal);
        Assert.Contains("`EmailSender:Smtp:UseStartTls`", configurationDocumentation, StringComparison.Ordinal);
        Assert.Contains("`EmailSender:Smtp:Username`", configurationDocumentation, StringComparison.Ordinal);
        Assert.Contains("`EmailSender:Smtp:Password`", configurationDocumentation, StringComparison.Ordinal);
        Assert.Contains(
            "`EmailSender--Smtp--Password`",
            configurationDocumentation,
            StringComparison.Ordinal);
        Assert.DoesNotContain(
            "`EmailSender:AcsEndpoint`",
            configurationDocumentation,
            StringComparison.Ordinal);
    }

    private static void AssertStageEmailSettings(
        string pipeline,
        string stageName,
        string? nextStageName,
        string serviceConnection,
        IReadOnlyList<string> expectedSettings)
    {
        var stageStart = pipeline.IndexOf($"  - stage: {stageName}", StringComparison.Ordinal);
        Assert.True(stageStart >= 0, $"Stage {stageName} was not found.");
        var stageEnd = nextStageName is null
            ? pipeline.Length
            : pipeline.IndexOf($"  - stage: {nextStageName}", stageStart, StringComparison.Ordinal);
        Assert.True(stageEnd > stageStart, $"Stage {stageName} boundary was not found.");
        var stage = pipeline[stageStart..stageEnd];

        const string settingsTask = "- task: AzureAppServiceSettings@1";
        const string deployTask = "- task: AzureFunctionApp@2";
        Assert.Equal(1, stage.Split(settingsTask, StringSplitOptions.None).Length - 1);
        var settingsTaskIndex = stage.IndexOf(settingsTask, StringComparison.Ordinal);
        var deployTaskIndex = stage.IndexOf(deployTask, StringComparison.Ordinal);
        Assert.True(settingsTaskIndex >= 0 && settingsTaskIndex < deployTaskIndex);
        Assert.DoesNotContain(
            "- task:",
            stage[(settingsTaskIndex + settingsTask.Length)..deployTaskIndex],
            StringComparison.Ordinal);
        Assert.Contains(
            "displayName: 'Apply Processor Function email settings'",
            stage,
            StringComparison.Ordinal);
        Assert.Contains(
            $"azureSubscription: '{serviceConnection}'",
            stage,
            StringComparison.Ordinal);
        Assert.Contains("appName: $(PurchaseOrderFunctionAppName)", stage, StringComparison.Ordinal);
        Assert.Contains(
            "resourceGroupName: $(PurchaseOrderFunctionAppResourceGroupName)",
            stage,
            StringComparison.Ordinal);

        foreach (var setting in expectedSettings)
        {
            var mapping =
                $"{{ \"name\": \"{setting}\", \"value\": \"$({setting})\", \"slotSetting\": false }}";
            Assert.Equal(1, stage.Split(mapping, StringSplitOptions.None).Length - 1);
        }
    }

    private static string ExtractConstructorParameters(string source, string typeName)
    {
        var constructorStart = source.IndexOf($"public {typeName}(", StringComparison.Ordinal);
        Assert.True(constructorStart >= 0, $"Constructor for {typeName} was not found.");
        var parametersStart = constructorStart + $"public {typeName}(".Length;
        var parametersEnd = source.IndexOf(')', parametersStart);
        Assert.True(parametersEnd > parametersStart, $"Constructor for {typeName} is incomplete.");
        return source[parametersStart..parametersEnd];
    }

    private static string Read(string relativePath)
    {
        var path = Path.Combine(
            FindRepositoryRoot(),
            relativePath.Replace('/', Path.DirectorySeparatorChar));
        Assert.True(File.Exists(path), $"Required repository file was not found: {relativePath}");
        return File.ReadAllText(path);
    }

    private static string FindRepositoryRoot()
    {
        foreach (var startPath in new[] { Directory.GetCurrentDirectory(), AppContext.BaseDirectory })
        {
            for (var directory = new DirectoryInfo(startPath);
                 directory is not null;
                 directory = directory.Parent)
            {
                if (File.Exists(Path.Combine(
                        directory.FullName,
                        "STUK.PurchaseOrderService.sln")))
                {
                    return directory.FullName;
                }
            }
        }

        throw new InvalidOperationException("The repository root could not be located.");
    }
}
