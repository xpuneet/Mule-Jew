using System.Text.Json;

namespace STUK.PurchaseOrderService.UnitTests.Deployment;

public sealed class WebApiDeploymentContractTests
{
    [Fact]
    public void WebApiHost_ProvidesFailClosedDeploymentPlaceholders()
    {
        var appSettingsText = Read("STUK.PurchaseOrderService.WebApi/appsettings.json");

        using var document = JsonDocument.Parse(appSettingsText);
        var root = document.RootElement;

        Assert.Equal(string.Empty, root.GetProperty("AzureKeyVaultUri").GetString());
        Assert.Equal(
            string.Empty,
            root.GetProperty("APPLICATIONINSIGHTS_CONNECTION_STRING").GetString());
        Assert.Equal(
            string.Empty,
            root.GetProperty("ConnectionStrings")
                .GetProperty("PurchaseOrdersServiceDB")
                .GetString());
        Assert.Equal(
            string.Empty,
            root.GetProperty("DatabaseConfigurationRefreshInterval").GetString());
        Assert.Equal(
            "PurchaseOrdersServiceUser",
            root.GetProperty("ApiSecuritySettings")
                .GetProperty("SchemeToScopeMappings")
                .GetProperty("User")
                .GetString());
        Assert.False(
            root.GetProperty("ApiSecuritySettings")
                .GetProperty("SchemeToScopeMappings")
                .TryGetProperty("Service", out _));

        var program = Read("STUK.PurchaseOrderService.WebApi/Program.cs");
        var keyVaultRegistration = program.IndexOf(
            "builder.Configuration.AddAzureKeyVault",
            StringComparison.Ordinal);
        var connectionStringRequirement = program.IndexOf(
            "PurchaseOrderDatabaseConfiguration.RequireConnectionString",
            StringComparison.Ordinal);

        Assert.True(keyVaultRegistration >= 0, "The Web API host must register Key Vault.");
        Assert.True(
            keyVaultRegistration < connectionStringRequirement,
            "Key Vault must be loaded before the database connection string is required.");
        Assert.Contains("DefaultAzureCredential", program, StringComparison.Ordinal);
    }

    [Fact]
    public void CiPipeline_BuildsDedicatedWebApiArtifactFromDevelopmentAndReleaseBranches()
    {
        var ci = Read("STUK.PurchaseOrderService.WebApi/Deploy/azureDeploy-CI.yml");

        Assert.Contains("- development", ci, StringComparison.Ordinal);
        Assert.Contains("- release/*", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.WebApi/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.WebApi.Domain/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Common.Data/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Common.Contracts/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.UnitTests/**", ci, StringComparison.Ordinal);
        Assert.Contains("nugetConfigPath: 'nuget.config'", ci, StringComparison.Ordinal);
        Assert.Contains("version: '8.0.423'", ci, StringComparison.Ordinal);
        Assert.DoesNotContain("version: '8.x'", ci, StringComparison.Ordinal);
        Assert.Contains("forceReinstallCredentialProvider: true", ci, StringComparison.Ordinal);
        Assert.DoesNotContain(
            "projects: 'STUK.PurchaseOrderService.sln'",
            ci,
            StringComparison.Ordinal);
        var buildProjects =
            "      projects: |" + Environment.NewLine +
            "        STUK.PurchaseOrderService.WebApi/" +
            "STUK.PurchaseOrderService.WebApi.csproj" + Environment.NewLine +
            "        STUK.PurchaseOrderService.UnitTests/" +
            "STUK.PurchaseOrderService.UnitTests.csproj";

        Assert.Equal(
            2,
            ci.Split(buildProjects, StringSplitOptions.None).Length - 1);
        Assert.Contains(
            "condition: and(succeeded(), ne(variables['Build.Reason'], 'PullRequest'))",
            ci,
            StringComparison.Ordinal);
        Assert.Contains(
            "projects: 'STUK.PurchaseOrderService.WebApi/" +
            "STUK.PurchaseOrderService.WebApi.csproj'",
            ci,
            StringComparison.Ordinal);
        Assert.Contains("artifactName: 'purchaseorderservice-webapp'", ci, StringComparison.Ordinal);
        Assert.Contains("deploy-ready", ci, StringComparison.Ordinal);
        Assert.Contains("refs/heads/development", ci, StringComparison.Ordinal);
    }

    [Fact]
    public void CdPipeline_DeploysOnlyDevelopmentToDevAndManualReleaseThroughQaAndProd()
    {
        var cd = Read("STUK.PurchaseOrderService.WebApi/Deploy/azureDeploy-CD.yml");

        Assert.Contains("source: PurchaseOrderService-CI", cd, StringComparison.Ordinal);
        Assert.Contains("- deploy-ready", cd, StringComparison.Ordinal);
        Assert.Contains(
            "condition: eq(variables['resources.pipeline.ciPipeline.sourceBranch'], " +
            "'refs/heads/development')",
            cd,
            StringComparison.Ordinal);
        Assert.DoesNotContain(
            "not(startsWith(variables['resources.pipeline.ciPipeline.sourceBranch']",
            cd,
            StringComparison.Ordinal);
        Assert.Contains("refs/heads/release/", cd, StringComparison.Ordinal);
        Assert.Contains("dependsOn: []", cd, StringComparison.Ordinal);
        Assert.Contains("dependsOn: QA", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-API-PurchaseOrderService-DEV", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-API-PurchaseOrderService-QA", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-API-PurchaseOrderService-PROD", cd, StringComparison.Ordinal);
        Assert.Contains("artifact: purchaseorderservice-webapp", cd, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.WebApi.zip", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-dev", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-tst", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-prd", cd, StringComparison.Ordinal);
        Assert.Equal(
            3,
            cd.Split("task: FileTransform@2", StringSplitOptions.None).Length - 1);
        Assert.Equal(
            3,
            cd.Split("task: AzureRmWebAppDeployment@4", StringSplitOptions.None).Length - 1);
        Assert.Equal(
            3,
            cd.Split("VirtualApplication: '/purchase-order'", StringSplitOptions.None).Length - 1);
        Assert.DoesNotContain("task: AzureAppServiceSettings@1", cd, StringComparison.Ordinal);
        Assert.DoesNotContain("ResourceGroupName", cd, StringComparison.Ordinal);
        Assert.DoesNotContain("ASPNETCORE_ENVIRONMENT", cd, StringComparison.Ordinal);
    }

    private static string Read(string relativePath)
    {
        var path = Path.Combine(
            FindRepositoryRoot(),
            relativePath.Replace('/', Path.DirectorySeparatorChar));
        Assert.True(File.Exists(path), $"Required repository file was not found: {relativePath}");
        return File.ReadAllText(path);
    }

    private static string FindRepositoryRoot()
    {
        foreach (var startPath in new[] { Directory.GetCurrentDirectory(), AppContext.BaseDirectory })
        {
            for (var directory = new DirectoryInfo(startPath);
                 directory is not null;
                 directory = directory.Parent)
            {
                if (File.Exists(Path.Combine(
                        directory.FullName,
                        "STUK.PurchaseOrderService.sln")))
                {
                    return directory.FullName;
                }
            }
        }

        throw new InvalidOperationException("The repository root could not be located.");
    }
}
