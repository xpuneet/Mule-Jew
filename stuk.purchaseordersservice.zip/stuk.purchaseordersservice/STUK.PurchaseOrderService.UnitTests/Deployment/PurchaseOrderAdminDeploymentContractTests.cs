using System.Text.Json;

namespace STUK.PurchaseOrderService.UnitTests.Deployment;

public sealed class PurchaseOrderAdminDeploymentContractTests
{
    private const string AdminProjectName =
        "STUK.PurchaseOrderService.PurchaseOrderAdmin";

    [Fact]
    public void PurchaseOrderAdminHost_ProvidesConfiguredDeploymentDefaultsAndLoadsKeyVaultFirst()
    {
        var appSettingsText = Read($"{AdminProjectName}/appsettings.json");

        using var document = JsonDocument.Parse(appSettingsText);
        var root = document.RootElement;

        Assert.False(root.TryGetProperty("AzureKeyVaultUri", out _));
        Assert.False(root.TryGetProperty("APPLICATIONINSIGHTS_CONNECTION_STRING", out _));
        Assert.Equal(
            "Server=(localdb)\\MSSQLLocalDB;Database=STUK.Apps_Core;" +
            "Trusted_Connection=true;TrustServerCertificate=True;",
            root.GetProperty("ConnectionStrings").GetProperty("Core").GetString());
        Assert.Equal(
            "Server=tcp:stukdpapsdev.database.windows.net,1433;" +
            "Initial Catalog=aps-sqldb-orders;Encrypt=True;" +
            "TrustServerCertificate=False;Connection Timeout=30;" +
            "Authentication=Active Directory Default;",
            root.GetProperty("ConnectionStrings")
                .GetProperty("PurchaseOrdersServiceDB")
                .GetString());
        Assert.Equal("900", root.GetProperty("DatabaseConfigurationRefreshInterval").GetString());
        Assert.Equal("https://localhost:44405/", root.GetProperty("HostURL").GetString());
        Assert.Equal("PurchaseOrderAdmin/", root.GetProperty("AppURI").GetString());
        Assert.Equal(string.Empty, root.GetProperty("ApiKey").GetString());

        var applicationInsights = root.GetProperty("ApplicationInsights");
        Assert.Equal(
            "d45f3cec-b55d-4533-ac4e-b464ae20cd8b",
            applicationInsights.GetProperty("InstrumentationKey").GetString());
        Assert.False(applicationInsights.GetProperty("EnableAdaptiveSampling").GetBoolean());

        var serilog = root.GetProperty("Serilog");
        Assert.Equal(
            "Server=(localdb)\\MSSQLLocalDB;Database=STUK.Apps_Core;" +
            "Trusted_Connection=true;TrustServerCertificate=True;",
            serilog.GetProperty("ConnectionString").GetString());
        Assert.Equal("Logs", serilog.GetProperty("LogTableName").GetString());
        Assert.Equal("Audits", serilog.GetProperty("AuditTableName").GetString());
        Assert.False(serilog.GetProperty("LogGets").GetBoolean());

        var azureAd = root.GetProperty("AzureAd");
        Assert.Equal(
            "https://login.microsoftonline.com/",
            azureAd.GetProperty("Instance").GetString());
        Assert.Equal("Stark Group", azureAd.GetProperty("Domain").GetString());
        Assert.Equal(
            "2e114308-14ec-4d77-b610-490324fa1844",
            azureAd.GetProperty("TenantId").GetString());
        Assert.Equal(
            "5a94b47b-82da-46b4-b476-8b6e6c998507",
            azureAd.GetProperty("ClientId").GetString());
        Assert.Equal("/signin-oidc", azureAd.GetProperty("CallbackPath").GetString());
        Assert.Equal("*", root.GetProperty("AllowedHosts").GetString());

        var program = Read($"{AdminProjectName}/Program.cs");
        var keyVaultRegistration = program.IndexOf(
            "builder.Configuration.AddAzureKeyVault",
            StringComparison.Ordinal);
        var coreUiRegistration = program.IndexOf(
            "builder.Services.AddCoreUI(builder.Configuration)",
            StringComparison.Ordinal);
        var persistenceRegistration = program.IndexOf(
            "builder.Services.AddPurchaseOrderPersistence(builder.Configuration)",
            StringComparison.Ordinal);

        Assert.True(
            keyVaultRegistration >= 0,
            "The Purchase Order Admin host must register Key Vault.");
        Assert.True(
            keyVaultRegistration < coreUiRegistration,
            "Key Vault must be loaded before CoreUI binds configuration.");
        Assert.True(
            keyVaultRegistration < persistenceRegistration,
            "Key Vault must be loaded before persistence requires its connection string.");
        Assert.Contains("DefaultAzureCredential", program, StringComparison.Ordinal);

        var project = Read($"{AdminProjectName}/{AdminProjectName}.csproj");
        Assert.Contains(
            "<AspNetCoreHostingModel>OutOfProcess</AspNetCoreHostingModel>",
            project,
            StringComparison.Ordinal);
        Assert.Contains(
            "Azure.Extensions.AspNetCore.Configuration.Secrets",
            project,
            StringComparison.Ordinal);
        Assert.Contains("Azure.Identity", project, StringComparison.Ordinal);
    }

    [Fact]
    public void CiPipeline_BuildsDedicatedPurchaseOrderAdminArtifactFromDevelopmentAndReleaseBranches()
    {
        var ci = Read("STUK.PurchaseOrderService.PurchaseOrderAdmin/Deploy/azureDeploy-CI.yml");

        Assert.Contains("- development", ci, StringComparison.Ordinal);
        Assert.Contains("- release/*", ci, StringComparison.Ordinal);
        Assert.Contains($"{AdminProjectName}/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Common.Data/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.Common.Contracts/**", ci, StringComparison.Ordinal);
        Assert.Contains("STUK.PurchaseOrderService.UnitTests/**", ci, StringComparison.Ordinal);
        Assert.Contains("nugetConfigPath: 'nuget.config'", ci, StringComparison.Ordinal);
        Assert.Contains("version: '8.0.423'", ci, StringComparison.Ordinal);
        Assert.Contains("forceReinstallCredentialProvider: true", ci, StringComparison.Ordinal);
        Assert.DoesNotContain(
            "projects: 'STUK.PurchaseOrderService.sln'",
            ci,
            StringComparison.Ordinal);

        var buildProjects =
            "      projects: |" + Environment.NewLine +
            $"        {AdminProjectName}/" +
            $"{AdminProjectName}.csproj" + Environment.NewLine +
            "        STUK.PurchaseOrderService.UnitTests/" +
            "STUK.PurchaseOrderService.UnitTests.csproj";

        Assert.Equal(2, ci.Split(buildProjects, StringSplitOptions.None).Length - 1);
        Assert.Contains(
            "condition: and(succeeded(), ne(variables['Build.Reason'], 'PullRequest'))",
            ci,
            StringComparison.Ordinal);
        Assert.Contains(
            $"projects: '{AdminProjectName}/" +
            $"{AdminProjectName}.csproj'",
            ci,
            StringComparison.Ordinal);
        Assert.Contains(
            "artifactName: 'stukapps.purchaseorderadmin-webapp'",
            ci,
            StringComparison.Ordinal);
        Assert.DoesNotContain("purchaseorderservice-webapp", ci, StringComparison.Ordinal);
        Assert.Contains("- powershell: |", ci, StringComparison.Ordinal);
        Assert.Contains(
            "Write-Host \"##vso[build.addbuildtag]deploy-ready\"",
            ci,
            StringComparison.Ordinal);
        Assert.DoesNotContain(
            "script: echo \"##vso[build.addbuildtag]deploy-ready\"",
            ci,
            StringComparison.Ordinal);
        Assert.Contains("refs/heads/development", ci, StringComparison.Ordinal);
    }

    [Fact]
    public void CdPipeline_DeploysPurchaseOrderAdminToInternalAppsVirtualApplication()
    {
        var cd = Read("STUK.PurchaseOrderService.PurchaseOrderAdmin/Deploy/azureDeploy-CD.yml");

        Assert.Contains(
            "source: StukApps.PurchaseOrdersAdmin-CI",
            cd,
            StringComparison.Ordinal);
        Assert.Contains("        tags:", cd, StringComparison.Ordinal);
        Assert.Contains("- deploy-ready", cd, StringComparison.Ordinal);
        Assert.Contains(
            "condition: eq(variables['resources.pipeline.ciPipeline.sourceBranch'], " +
            "'refs/heads/development')",
            cd,
            StringComparison.Ordinal);
        Assert.Contains("refs/heads/release/", cd, StringComparison.Ordinal);
        Assert.Contains("dependsOn: []", cd, StringComparison.Ordinal);
        Assert.Contains("dependsOn: QA", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-Internal-Apps-SgbdApps.Common-DEV", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-Internal-Apps-SgbdApps.Common-QA", cd, StringComparison.Ordinal);
        Assert.Contains("AZ-Internal-Apps-SgbdApps.Common-PROD", cd, StringComparison.Ordinal);
        Assert.Contains(
            "AZ-Internal-Apps-PurchaseOrderService.WebApp-DEV",
            cd,
            StringComparison.Ordinal);
        Assert.Contains(
            "AZ-Internal-Apps-PurchaseOrderService.WebApp-QA",
            cd,
            StringComparison.Ordinal);
        Assert.Contains(
            "AZ-Internal-Apps-PurchaseOrderService.WebApp-PROD",
            cd,
            StringComparison.Ordinal);
        Assert.Contains("environment: AZ-Internal-Apps-DEV", cd, StringComparison.Ordinal);
        Assert.Contains("environment: AZ-Internal-Apps-QA", cd, StringComparison.Ordinal);
        Assert.Contains("environment: AZ-Internal-Apps-PROD", cd, StringComparison.Ordinal);
        Assert.DoesNotContain("environment: AZ-API-", cd, StringComparison.Ordinal);
        Assert.Equal(
            3,
            cd.Split(
                "artifact: stukapps.purchaseorderadmin-webapp",
                StringSplitOptions.None).Length - 1);
        Assert.Equal(
            6,
            cd.Split(
                "/ciPipeline/stukapps.purchaseorderadmin-webapp/",
                StringSplitOptions.None).Length - 1);
        Assert.DoesNotContain("purchaseorderservice-webapp", cd, StringComparison.Ordinal);
        Assert.Contains($"{AdminProjectName}.zip", cd, StringComparison.Ordinal);
        Assert.Equal(
            3,
            cd.Split("WebAppName: $(WebAppName)", StringSplitOptions.None).Length - 1);
        Assert.DoesNotContain("WebAppName: 'app-stuk-ais-apps-", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-dev", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-tst", cd, StringComparison.Ordinal);
        Assert.Contains("sc-sub-starkuk-integration-services-prd", cd, StringComparison.Ordinal);
        Assert.Equal(3, cd.Split("appType: 'webApp'", StringSplitOptions.None).Length - 1);
        Assert.Equal(3, cd.Split("task: FileTransform@2", StringSplitOptions.None).Length - 1);
        Assert.Equal(
            3,
            cd.Split("task: AzureRmWebAppDeployment@4", StringSplitOptions.None).Length - 1);
        Assert.Equal(
            3,
            cd.Split(
                "VirtualApplication: '/PurchaseOrderAdmin'",
                StringSplitOptions.None).Length - 1);
        Assert.DoesNotContain("task: AzureAppServiceSettings@1", cd, StringComparison.Ordinal);
    }

    private static string Read(string relativePath)
    {
        var path = Path.Combine(
            FindRepositoryRoot(),
            relativePath.Replace('/', Path.DirectorySeparatorChar));
        Assert.True(File.Exists(path), $"Required repository file was not found: {relativePath}");
        return File.ReadAllText(path);
    }

    private static string FindRepositoryRoot()
    {
        foreach (var startPath in new[] { Directory.GetCurrentDirectory(), AppContext.BaseDirectory })
        {
            for (var directory = new DirectoryInfo(startPath);
                 directory is not null;
                 directory = directory.Parent)
            {
                if (File.Exists(Path.Combine(
                        directory.FullName,
                        "STUK.PurchaseOrderService.sln")))
                {
                    return directory.FullName;
                }
            }
        }

        throw new InvalidOperationException("The repository root could not be located.");
    }
}
