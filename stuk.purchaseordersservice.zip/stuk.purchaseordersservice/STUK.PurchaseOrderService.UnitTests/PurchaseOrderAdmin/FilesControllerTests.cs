using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Moq;
using SgBdApps.Core.Attributes;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Controllers;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;
using System.Reflection;

namespace STUK.PurchaseOrderService.UnitTests.PurchaseOrderAdmin;

public sealed class FilesControllerTests
{
    [Fact]
    public void Controller_RequiresCoreUiUserAndPurchaseOrderReaderPolicy()
    {
        Assert.NotNull(typeof(FilesController).GetCustomAttribute<AuthorizeUserAttribute>());
        Assert.Contains(
            typeof(FilesController).GetCustomAttributes<AuthorizeAttribute>(),
            authorize => authorize.Policy == Policies.PurchaseOrderReader);
    }

    [Fact]
    public async Task Index_ReturnsServiceModel()
    {
        var service = new Mock<IPurchaseOrderAdminService>(MockBehavior.Strict);
        var request = new PurchaseOrderFilesRequest();
        var expected = new PurchaseOrderFilesViewModel
        {
            Request = request,
            Range = new PurchaseOrderDateRange(default, default),
            StatusCards = [],
            Results = [],
            PageSize = 25,
            HasPreviousPage = false,
            HasNextPage = false
        };
        service
            .Setup(instance => instance.GetFilesAsync(
                request,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(expected);
        var controller = new FilesController(service.Object);

        var result = await controller.Index(request, CancellationToken.None);

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(expected, view.Model);
        service.VerifyAll();
    }

    [Fact]
    public async Task Details_MissingBatchReturnsSanitizedNotFound()
    {
        var service = new Mock<IPurchaseOrderAdminService>(MockBehavior.Strict);
        var batchId = Guid.Parse("4fd5dd09-f5eb-48b9-a7c1-666bc592fe33");
        var request = new PurchaseOrderFileDetailsRequest();
        service
            .Setup(instance => instance.GetFileDetailsAsync(
                batchId,
                request,
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(SqlPersistenceExceptionMapper.Map(
                (int)PurchaseOrderPersistenceError.EntityNotFound));
        var controller = new FilesController(service.Object);

        var result = await controller.Details(
            batchId,
            request,
            CancellationToken.None);

        var objectResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(404, objectResult.StatusCode);
        var problem = Assert.IsType<ProblemDetails>(objectResult.Value);
        Assert.Equal("Purchase Order file not found", problem.Title);
        Assert.DoesNotContain("sp_", problem.Detail ?? string.Empty, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("sql", problem.Detail ?? string.Empty, StringComparison.OrdinalIgnoreCase);
        service.VerifyAll();
    }
}
