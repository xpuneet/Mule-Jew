namespace STUK.PurchaseOrderService.UnitTests.PurchaseOrderAdmin;

public sealed class PurchaseOrderAdminViewContractTests
{
    private static readonly string[] SerializedStatuses =
    [
        "DRAFT",
        "READY_FOR_SUBMISSION",
        "SUBMISSION_IN_PROGRESS",
        "RECOVERABLE_ERROR",
        "NON_RECOVERABLE_ERROR",
        "RETRY_REQUESTED",
        "COMPLETED",
        "CANCELLED"
    ];

    [Fact]
    public void OperationsView_ContainsLifecycleRangeSearchDetailsAndPagingContracts()
    {
        var view = Read("Views", "Home", "Index.cshtml");

        foreach (var status in SerializedStatuses)
        {
            Assert.Contains(status, view, StringComparison.Ordinal);
        }

        foreach (var control in new[]
                 {
                     "Source",
                     "RangePreset",
                     "CustomAfterDateTimeUtc",
                     "CustomUntilDateTimeUtc",
                     "Account",
                     "Branch",
                     "Reference",
                     "IconPurchaseOrderNumber",
                     "Status"
                 })
        {
            Assert.Contains(control, view, StringComparison.Ordinal);
        }

        Assert.Contains("asp-controller=\"PurchaseOrders\"", view, StringComparison.Ordinal);
        Assert.Contains("asp-action=\"Details\"", view, StringComparison.Ordinal);
        Assert.Contains("Previous", view, StringComparison.Ordinal);
        Assert.Contains("Next", view, StringComparison.Ordinal);
        Assert.Contains("Clear filters", view, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void OperationsView_CustomUtcFieldsUseApplicationSpecificClassName()
    {
        var view = Read("Views", "Home", "Index.cshtml");
        var styles = Read("wwwroot", "css", "site.css");

        Assert.Contains("class=\"utc-range-fields\"", view, StringComparison.Ordinal);
        Assert.Contains(".utc-range-fields", styles, StringComparison.Ordinal);
        Assert.DoesNotContain("class=\"custom-range\"", view, StringComparison.Ordinal);
    }

    [Fact]
    public void DetailsView_EncodesPayloadAndKeepsActorOutOfManagerForms()
    {
        var view = Read("Views", "PurchaseOrders", "Details.cshtml");

        Assert.DoesNotContain("Html.Raw", view, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("<pre", view, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("<code", view, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("@Html.AntiForgeryToken()", view, StringComparison.Ordinal);
        Assert.Contains("User.HasRole(Roles.PurchaseOrderManager)", view, StringComparison.Ordinal);
        Assert.Contains("name=\"CandidateId\"", view, StringComparison.Ordinal);
        Assert.Contains("name=\"RowVersionBase64\"", view, StringComparison.Ordinal);
        Assert.Contains("name=\"Reason\"", view, StringComparison.Ordinal);
        Assert.DoesNotContain("name=\"Actor\"", view, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void ClientScripts_UseSafeTextAndHandleKnownStatuses()
    {
        var operations = Read("wwwroot", "js", "purchase-orders", "operations.js");
        var details = Read("wwwroot", "js", "purchase-orders", "details.js");
        var combined = operations + Environment.NewLine + details;

        Assert.DoesNotContain("innerHTML", combined, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("textContent", details, StringComparison.Ordinal);
        Assert.Contains("response.status === 400", details, StringComparison.Ordinal);
        Assert.Contains("response.status === 404", details, StringComparison.Ordinal);
        Assert.Contains("response.status === 409", details, StringComparison.Ordinal);
        Assert.Contains("toISOString", operations, StringComparison.Ordinal);
    }

    [Fact]
    public void Layout_ContainsOperationsAndFilesNavigationOnly()
    {
        var layout = Read("Views", "Shared", "_PurchaseOrdersAdminLayout.cshtml");

        Assert.Contains("Operations", layout, StringComparison.Ordinal);
        Assert.Contains("asp-controller=\"Files\"", layout, StringComparison.Ordinal);
        Assert.Contains("Files", layout, StringComparison.Ordinal);
        Assert.DoesNotContain("Settings", layout, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void FilesIndex_ContainsRangeStatusSearchDetailsAndPagingContracts()
    {
        var view = Read("Views", "Files", "Index.cshtml");

        foreach (var status in new[] { "PROCESSING", "COMPLETED", "FAILED" })
        {
            Assert.Contains(status, view, StringComparison.Ordinal);
        }

        foreach (var control in new[]
                 {
                     "RangePreset",
                     "CustomAfterDateTimeUtc",
                     "CustomUntilDateTimeUtc",
                     "OriginalFileName",
                     "Status"
                 })
        {
            Assert.Contains(control, view, StringComparison.Ordinal);
        }

        Assert.Contains("asp-controller=\"Files\"", view, StringComparison.Ordinal);
        Assert.Contains("asp-action=\"Details\"", view, StringComparison.Ordinal);
        Assert.Contains("Previous", view, StringComparison.Ordinal);
        Assert.Contains("Next", view, StringComparison.Ordinal);
        Assert.Contains("Clear filters", view, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void FileDetails_ContainsMetadataFailureTimingAndLinkedOrders()
    {
        var view = Read("Views", "Files", "Details.cshtml");

        foreach (var label in new[]
                 {
                     "File name",
                     "Batch ID",
                     "Source path",
                     "SHA-256",
                     "Failure code",
                     "Failure description",
                     "Discovered UTC",
                     "Ingestion started UTC",
                     "Completed UTC",
                     "Parsed rows",
                     "Purchase Orders"
                 })
        {
            Assert.Contains(label, view, StringComparison.Ordinal);
        }

        foreach (var status in SerializedStatuses)
        {
            Assert.Contains(status, view, StringComparison.Ordinal);
        }

        Assert.Contains("asp-controller=\"PurchaseOrders\"", view, StringComparison.Ordinal);
        Assert.Contains("asp-action=\"Details\"", view, StringComparison.Ordinal);
        Assert.DoesNotContain("Html.Raw", view, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void FilesScript_UsesUtcIsoValuesWithoutUnsafeHtml()
    {
        var script = Read("wwwroot", "js", "purchase-orders", "files.js");

        Assert.Contains("toISOString", script, StringComparison.Ordinal);
        Assert.DoesNotContain("innerHTML", script, StringComparison.OrdinalIgnoreCase);
    }

    private static string Read(params string[] segments) => File.ReadAllText(
        Path.Combine([AppContext.BaseDirectory, "TestData", "PurchaseOrderAdmin", .. segments]));
}
