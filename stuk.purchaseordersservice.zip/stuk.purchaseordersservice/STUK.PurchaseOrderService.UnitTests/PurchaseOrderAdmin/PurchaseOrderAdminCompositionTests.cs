using SgBdApps.Core.Attributes;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Controllers;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;

namespace STUK.PurchaseOrderService.UnitTests.PurchaseOrderAdmin;

public sealed class PurchaseOrderAdminCompositionTests
{
    [Fact]
    public void ErrorController_UsesApplicationLevelCoreUiAuthorization()
    {
        var attributes = typeof(ErrorController)
            .GetCustomAttributes(typeof(AuthorizeUserAttribute), inherit: true);

        Assert.Single(attributes);
    }

    [Fact]
    public void Program_ComposesPersistenceCoreUiReaderPolicyAndMvcWithConfiguredDevDefaults()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));
        var settings = File.ReadAllText(GetTestDataPath("appsettings.json"));

        Assert.Contains("AddPurchaseOrderPersistence", program, StringComparison.Ordinal);
        Assert.Contains("AddCoreUI", program, StringComparison.Ordinal);
        Assert.Contains("AddCoreUIFilters", program, StringComparison.Ordinal);
        Assert.Contains("Policies.PurchaseOrderReader", program, StringComparison.Ordinal);
        Assert.Contains("RoleMembershipRequirement", program, StringComparison.Ordinal);
        Assert.Contains("Roles.PurchaseOrderViewer", program, StringComparison.Ordinal);
        Assert.Contains("Roles.PurchaseOrderManager", program, StringComparison.Ordinal);
        Assert.Contains("UseCoreUIMiddleware", program, StringComparison.Ordinal);
        Assert.Contains("MapControllerRoute", program, StringComparison.Ordinal);
        Assert.Contains("app.MapRazorPages()", program, StringComparison.Ordinal);
        Assert.Contains(
            "public partial class PurchaseOrderAdminProgram",
            program,
            StringComparison.Ordinal);

        Assert.Contains(
            "\"TenantId\": \"2e114308-14ec-4d77-b610-490324fa1844\"",
            settings,
            StringComparison.Ordinal);
        Assert.Contains(
            "\"ClientId\": \"5a94b47b-82da-46b4-b476-8b6e6c998507\"",
            settings,
            StringComparison.Ordinal);
        Assert.Contains("\"ApiKey\": \"\"", settings, StringComparison.Ordinal);
        var combined = program + Environment.NewLine + settings;
        Assert.DoesNotContain("Password=", combined, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("User ID=", combined, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void SecurityDefinitions_ExposeDistinctViewerAndManagerRoles()
    {
        Assert.Equal("PurchaseOrderViewer", Roles.PurchaseOrderViewer);
        Assert.Equal("PurchaseOrderManager", Roles.PurchaseOrderManager);
        Assert.NotEqual(Roles.PurchaseOrderViewer, Roles.PurchaseOrderManager);
        Assert.Equal("PurchaseOrderReader", Policies.PurchaseOrderReader);
    }

    [Fact]
    public void Program_LocalDevelopmentAuthenticationIsExplicitAndEnvironmentGated()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));

        Assert.Contains("builder.Environment.IsDevelopment()", program, StringComparison.Ordinal);
        Assert.Contains(
            "WebApp:EnableLocalDevelopmentAuthentication",
            program,
            StringComparison.Ordinal);
        Assert.Contains("LocalDevelopmentAuthenticationHandler", program, StringComparison.Ordinal);
        Assert.Contains("options.DefaultAuthenticateScheme", program, StringComparison.Ordinal);
        Assert.Contains("options.DefaultChallengeScheme", program, StringComparison.Ordinal);
        Assert.Contains("options.DefaultForbidScheme", program, StringComparison.Ordinal);
        Assert.Contains("policy.RequireAuthenticatedUser()", program, StringComparison.Ordinal);
        Assert.Contains("policy.RequireRole", program, StringComparison.Ordinal);
        Assert.Contains("app.UseAuthentication()", program, StringComparison.Ordinal);
        Assert.Contains("if (!useLocalDevelopmentAuthentication)", program, StringComparison.Ordinal);

        var coreUiRegistrationIndex = program.IndexOf(
            "builder.Services.AddCoreUI(builder.Configuration)",
            StringComparison.Ordinal);
        var authenticationBranchIndex = program.IndexOf(
            "if (useLocalDevelopmentAuthentication)",
            StringComparison.Ordinal);
        Assert.True(coreUiRegistrationIndex > authenticationBranchIndex);
    }

    [Fact]
    public void PurchaseOrdersLayout_UsesAnIsolatedDevelopmentShell()
    {
        var layout = File.ReadAllText(GetTestDataPath(
            "Views",
            "Shared",
            "_PurchaseOrdersAdminLayout.cshtml"));
        var localLayout = File.ReadAllText(GetTestDataPath(
            "Views",
            "Shared",
            "_LocalDevelopmentLayout.cshtml"));

        Assert.Contains(
            "Configuration.GetValue<bool>(\"WebApp:EnableLocalDevelopmentAuthentication\")",
            layout,
            StringComparison.Ordinal);
        Assert.Contains("? \"_LocalDevelopmentLayout\" : \"_Layout\"", layout, StringComparison.Ordinal);
        Assert.Contains("<!DOCTYPE html>", localLayout, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("@RenderBody()", localLayout, StringComparison.Ordinal);
        Assert.Contains("Local development", localLayout, StringComparison.Ordinal);
        Assert.Contains("bootstrap.min.css", localLayout, StringComparison.Ordinal);
        Assert.Contains("css/style.min.css", localLayout, StringComparison.Ordinal);
    }

    [Fact]
    public void PortalStyles_NormalizeTheLocalShellAndKeepStatusCardsVisible()
    {
        var styles = File.ReadAllText(GetTestDataPath("wwwroot", "css", "site.css"));

        Assert.Contains("padding-top: 0", styles, StringComparison.Ordinal);
        Assert.Contains(".validation-summary-valid", styles, StringComparison.Ordinal);
        Assert.Contains("minmax(7.5rem, 1fr)", styles, StringComparison.Ordinal);
        Assert.Contains("overflow-wrap: anywhere", styles, StringComparison.Ordinal);
        Assert.Contains("position: fixed", styles, StringComparison.Ordinal);
    }

    [Fact]
    public void PortalStyles_AlignTheCoreUiBodyWithTheFixedNavigation()
    {
        var styles = File.ReadAllText(GetTestDataPath("wwwroot", "css", "site.css"));

        Assert.Contains("body.has-left-navigation", styles, StringComparison.Ordinal);
        Assert.Contains("padding-top: 75px", styles, StringComparison.Ordinal);
    }

    [Fact]
    public void Program_RegistersThePurchaseOrdersAdminApplicationIcon()
    {
        var program = File.ReadAllText(GetTestDataPath("Program.cs"));
        var project = File.ReadAllText(GetTestDataPath(
            "STUK.PurchaseOrderService.PurchaseOrderAdmin.csproj"));

        Assert.Contains(
            "options.Icon = STUK.PurchaseOrderService.PurchaseOrderAdmin.Properties.Resources.Icon;",
            program,
            StringComparison.Ordinal);
        Assert.Contains(@"Resources\purchaseOrdersIcon.png", project, StringComparison.Ordinal);
        Assert.Contains("Properties\\Resources.resx", project, StringComparison.Ordinal);
    }

    [Fact]
    public void ApplicationIcon_IsAnEmbeddedThreeHundredByTwoHundredTwentySixPng()
    {
        var resources = new System.Resources.ResourceManager(
            "STUK.PurchaseOrderService.PurchaseOrderAdmin.Properties.Resources",
            typeof(PurchaseOrderAdminProgram).Assembly);

        var icon = Assert.IsType<byte[]>(resources.GetObject("Icon"));

        Assert.True(icon.Length > 24);
        Assert.Equal(
            new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 },
            icon[..8]);
        Assert.Equal(300, ReadBigEndianInt32(icon, 16));
        Assert.Equal(226, ReadBigEndianInt32(icon, 20));
    }

    private static int ReadBigEndianInt32(byte[] bytes, int offset) =>
        (bytes[offset] << 24)
        | (bytes[offset + 1] << 16)
        | (bytes[offset + 2] << 8)
        | bytes[offset + 3];

    private static string GetTestDataPath(params string[] segments) => Path.Combine(
        [
        AppContext.BaseDirectory,
        "TestData",
        "PurchaseOrderAdmin",
        .. segments,
        ]);
}
