using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using SgBdApps.Core.Attributes;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Controllers;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;
using System.Reflection;
using System.Security.Claims;

namespace STUK.PurchaseOrderService.UnitTests.PurchaseOrderAdmin;

public sealed class PurchaseOrdersControllerTests
{
    [Theory]
    [InlineData(typeof(HomeController))]
    [InlineData(typeof(PurchaseOrdersController))]
    public void ReadController_RequiresCoreUiUserAndPurchaseOrderReaderPolicy(Type controllerType)
    {
        Assert.NotNull(controllerType.GetCustomAttribute<AuthorizeUserAttribute>());
        Assert.Contains(
            controllerType.GetCustomAttributes<AuthorizeAttribute>(),
            authorize => authorize.Policy == Policies.PurchaseOrderReader);
    }

    [Theory]
    [InlineData(nameof(PurchaseOrdersController.Retry))]
    [InlineData(nameof(PurchaseOrdersController.Cancel))]
    public void MutationAction_RequiresPostAntiforgeryAndManagerRole(string actionName)
    {
        var method = typeof(PurchaseOrdersController).GetMethod(actionName);

        Assert.NotNull(method);
        Assert.NotNull(method.GetCustomAttribute<HttpPostAttribute>());
        Assert.NotNull(method.GetCustomAttribute<ValidateAntiForgeryTokenAttribute>());
        var roleAttribute = Assert.Single(
            method.GetCustomAttributesData(),
            attribute => attribute.AttributeType == typeof(AuthorizeRolesAttribute));
        var configuredRoles = roleAttribute.ConstructorArguments
            .SelectMany(argument => argument.Value as IReadOnlyCollection<CustomAttributeTypedArgument>
                ?? [argument])
            .Select(argument => argument.Value?.ToString())
            .ToArray();
        Assert.Contains(Roles.PurchaseOrderManager, configuredRoles);
    }

    [Fact]
    public async Task Retry_UsesAuthenticatedIdentityAsActor()
    {
        var service = new Mock<IPurchaseOrderAdminService>(MockBehavior.Strict);
        var request = ValidActionRequest();
        using var cancellationSource = new CancellationTokenSource();
        service
            .Setup(instance => instance.RequestRetryAsync(
                request,
                "manager@stark.dk",
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
        var controller = CreateController(service.Object, "manager@stark.dk");

        var result = await controller.Retry(request, cancellationSource.Token);

        Assert.IsType<OkResult>(result);
        service.VerifyAll();
    }

    [Theory]
    [InlineData(PurchaseOrderPersistenceError.EntityNotFound, 404)]
    [InlineData(PurchaseOrderPersistenceError.ConcurrencyConflict, 409)]
    [InlineData(PurchaseOrderPersistenceError.LeaseConflict, 409)]
    [InlineData(PurchaseOrderPersistenceError.InvalidLifecycleTransition, 409)]
    public async Task Retry_KnownPersistenceError_ReturnsSanitizedStatus(
        PurchaseOrderPersistenceError error,
        int expectedStatus)
    {
        var service = new Mock<IPurchaseOrderAdminService>(MockBehavior.Strict);
        var request = ValidActionRequest();
        service
            .Setup(instance => instance.RequestRetryAsync(
                request,
                "manager@stark.dk",
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(SqlPersistenceExceptionMapper.Map((int)error));
        var controller = CreateController(service.Object, "manager@stark.dk");

        var result = await controller.Retry(request, CancellationToken.None);

        var objectResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(expectedStatus, objectResult.StatusCode);
        var problem = Assert.IsType<ProblemDetails>(objectResult.Value);
        Assert.DoesNotContain("sp_", problem.Detail ?? string.Empty, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("sql", problem.Detail ?? string.Empty, StringComparison.OrdinalIgnoreCase);
        service.VerifyAll();
    }

    private static PurchaseOrdersController CreateController(
        IPurchaseOrderAdminService service,
        string actor)
    {
        var controller = new PurchaseOrdersController(
            service,
            NullLogger<PurchaseOrdersController>.Instance)
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(
                        new ClaimsIdentity(
                            [new Claim(ClaimTypes.Name, actor)],
                            "Test"))
                }
            }
        };
        return controller;
    }

    private static PurchaseOrderSupportActionRequest ValidActionRequest() => new()
    {
        CandidateId = Guid.Parse("a646780a-d183-4cc8-90e6-3715f5cd7a6d"),
        Reason = "Reviewed by support",
        RowVersionBase64 = Convert.ToBase64String(new byte[8])
    };
}
