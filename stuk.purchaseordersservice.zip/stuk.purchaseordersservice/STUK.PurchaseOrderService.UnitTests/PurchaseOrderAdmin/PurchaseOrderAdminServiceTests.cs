using Microsoft.Extensions.Options;
using Moq;
using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Configuration;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;

namespace STUK.PurchaseOrderService.UnitTests.PurchaseOrderAdmin;

public sealed class PurchaseOrderAdminServiceTests
{
    private static readonly DateTimeOffset Now =
        new(2026, 8, 5, 12, 0, 0, TimeSpan.Zero);

    [Fact]
    public async Task GetOperationsAsync_FillsAllStatusesAndUsesSameSourceAndRange()
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        PurchaseOrderStatusSummaryQuery? capturedSummary = null;
        PurchaseOrderSearchCriteria? capturedSearch = null;
        adminRepository
            .Setup(repository => repository.GetStatusSummaryAsync(
                It.IsAny<PurchaseOrderStatusSummaryQuery>(),
                It.IsAny<CancellationToken>()))
            .Callback<PurchaseOrderStatusSummaryQuery, CancellationToken>((query, _) =>
                capturedSummary = query)
            .ReturnsAsync([new PurchaseOrderStatusCount("COMPLETED", 3)]);
        ordersRepository
            .Setup(repository => repository.SearchCandidates(
                It.IsAny<PurchaseOrderSearchCriteria>(),
                It.IsAny<CancellationToken>()))
            .Callback<PurchaseOrderSearchCriteria, CancellationToken>((criteria, _) =>
                capturedSearch = criteria)
            .ReturnsAsync(Array.Empty<PurchaseOrderSummary>());
        var service = CreateService(adminRepository, ordersRepository, supportRepository);
        var request = new PurchaseOrderOperationsRequest
        {
            Source = "Relex",
            RangePreset = "6h",
            PageNumber = 1
        };

        var result = await service.GetOperationsAsync(request);

        Assert.Equal(8, result.StatusCards.Count);
        Assert.Equal(
            Enum.GetValues<PurchaseOrderCandidateStatus>(),
            result.StatusCards.Select(card => card.Status));
        Assert.Equal(3, result.StatusCards.Single(card => card.SerializedStatus == "COMPLETED").Count);
        Assert.All(
            result.StatusCards.Where(card => card.SerializedStatus != "COMPLETED"),
            card => Assert.Equal(0, card.Count));
        Assert.NotNull(capturedSummary);
        Assert.NotNull(capturedSearch);
        Assert.Equal(capturedSummary.Source, capturedSearch.Source);
        Assert.Equal(capturedSummary.AfterDateTimeUtc, capturedSearch.AcceptedAfterDateTimeUtc);
        Assert.Equal(capturedSummary.UntilDateTimeUtc, capturedSearch.AcceptedUntilDateTimeUtc);
        Assert.Equal(Now.AddHours(-6), capturedSummary.AfterDateTimeUtc);
        Assert.Equal(Now, capturedSummary.UntilDateTimeUtc);
        Assert.Equal(26, capturedSearch.PageSize);
        Assert.False(result.HasPreviousPage);
        Assert.False(result.HasNextPage);
        adminRepository.VerifyAll();
        ordersRepository.VerifyAll();
        supportRepository.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task GetOperationsAsync_NormalizesConfiguredSourcesBeforeRendering()
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        adminRepository
            .Setup(repository => repository.GetStatusSummaryAsync(
                It.IsAny<PurchaseOrderStatusSummaryQuery>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Array.Empty<PurchaseOrderStatusCount>());
        ordersRepository
            .Setup(repository => repository.SearchCandidates(
                It.IsAny<PurchaseOrderSearchCriteria>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Array.Empty<PurchaseOrderSummary>());
        var settings = new WebAppSettings
        {
            AllowedSources = ["API", "Relex", "API", "Relex "],
            DefaultSource = " Relex "
        };
        var service = CreateService(
            adminRepository,
            ordersRepository,
            supportRepository,
            settings);

        var result = await service.GetOperationsAsync(new PurchaseOrderOperationsRequest());

        Assert.Equal(["API", "Relex"], result.AllowedSources);
        Assert.Equal("Relex", result.Request.Source);
        adminRepository.VerifyAll();
        ordersRepository.VerifyAll();
        supportRepository.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task GetFilesAsync_UsesRelexRangeThreeFileStatusesAndBoundedPaging()
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        PurchaseOrderBatchStatusSummaryQuery? capturedSummary = null;
        PurchaseOrderBatchSearchQuery? capturedSearch = null;
        adminRepository
            .Setup(repository => repository.GetBatchStatusSummaryAsync(
                It.IsAny<PurchaseOrderBatchStatusSummaryQuery>(),
                It.IsAny<CancellationToken>()))
            .Callback<PurchaseOrderBatchStatusSummaryQuery, CancellationToken>((query, _) =>
                capturedSummary = query)
            .ReturnsAsync([new PurchaseOrderBatchStatusCount("COMPLETED", 12)]);
        adminRepository
            .Setup(repository => repository.SearchBatchesAsync(
                It.IsAny<PurchaseOrderBatchSearchQuery>(),
                It.IsAny<CancellationToken>()))
            .Callback<PurchaseOrderBatchSearchQuery, CancellationToken>((query, _) =>
                capturedSearch = query)
            .ReturnsAsync(Enumerable.Range(1, 26)
                .Select(index => CreateBatchSummary(index))
                .ToArray());
        var service = CreateService(adminRepository, ordersRepository, supportRepository);
        var request = new PurchaseOrderFilesRequest
        {
            RangePreset = "6h",
            OriginalFileName = "  proposal  ",
            Status = "completed",
            PageNumber = 2
        };

        var result = await service.GetFilesAsync(request);

        Assert.Equal(
            new[] { "PROCESSING", "COMPLETED", "FAILED" },
            result.StatusCards.Select(card => card.Status));
        Assert.Equal(12, result.StatusCards.Single(card => card.Status == "COMPLETED").Count);
        Assert.All(
            result.StatusCards.Where(card => card.Status != "COMPLETED"),
            card => Assert.Equal(0, card.Count));
        Assert.Equal(25, result.Results.Count);
        Assert.True(result.HasPreviousPage);
        Assert.True(result.HasNextPage);
        Assert.NotNull(capturedSummary);
        Assert.NotNull(capturedSearch);
        Assert.Equal("Relex", capturedSummary.Source);
        Assert.Equal(Now.AddHours(-6), capturedSummary.AfterDateTimeUtc);
        Assert.Equal(Now, capturedSummary.UntilDateTimeUtc);
        Assert.Equal(capturedSummary.Source, capturedSearch.Source);
        Assert.Equal("proposal", capturedSearch.OriginalFileName);
        Assert.Equal("COMPLETED", capturedSearch.Status);
        Assert.Equal(26, capturedSearch.PageSize);
        Assert.Equal(2, capturedSearch.PageNumber);
        adminRepository.VerifyAll();
        ordersRepository.VerifyNoOtherCalls();
        supportRepository.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task GetFileDetailsAsync_KeepsCompletedFileIndependentFromOrderFailures()
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        var details = CreateBatchDetails("COMPLETED");
        PurchaseOrderBatchCandidateSearchQuery? capturedSearch = null;
        adminRepository
            .Setup(repository => repository.GetBatchAsync(
                details.BatchId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(details);
        adminRepository
            .Setup(repository => repository.GetBatchCandidateStatusSummaryAsync(
                details.BatchId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(
            [
                new PurchaseOrderStatusCount("COMPLETED", 4),
                new PurchaseOrderStatusCount("RECOVERABLE_ERROR", 1)
            ]);
        adminRepository
            .Setup(repository => repository.SearchBatchCandidatesAsync(
                It.IsAny<PurchaseOrderBatchCandidateSearchQuery>(),
                It.IsAny<CancellationToken>()))
            .Callback<PurchaseOrderBatchCandidateSearchQuery, CancellationToken>((query, _) =>
                capturedSearch = query)
            .ReturnsAsync(Enumerable.Range(1, 26)
                .Select(index => CreateBatchOutcome(index))
                .ToArray());
        var service = CreateService(adminRepository, ordersRepository, supportRepository);
        var request = new PurchaseOrderFileDetailsRequest
        {
            Status = "recoverable_error",
            PageNumber = 1
        };

        var result = await service.GetFileDetailsAsync(details.BatchId, request);

        Assert.Equal("COMPLETED", result.Details.Status);
        Assert.Equal(8, result.StatusCards.Count);
        Assert.Equal(
            1,
            result.StatusCards.Single(card => card.SerializedStatus == "RECOVERABLE_ERROR").Count);
        Assert.Equal(25, result.Orders.Count);
        Assert.True(result.HasNextPage);
        Assert.NotNull(capturedSearch);
        Assert.Equal(details.BatchId, capturedSearch.BatchId);
        Assert.Equal("RECOVERABLE_ERROR", capturedSearch.Status);
        Assert.Equal(26, capturedSearch.PageSize);
        adminRepository.VerifyAll();
        ordersRepository.VerifyNoOtherCalls();
        supportRepository.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task GetDetailsAsync_ReturnsPrettyPayloadAuditRowVersionAndEligibility()
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        var details = CreateDetails("RECOVERABLE_ERROR");
        var audit = new PurchaseOrderAuditEntry(
            "FAIL",
            "PROCESSOR",
            "worker-01",
            "Timeout",
            "SUBMISSION_IN_PROGRESS",
            "RECOVERABLE_ERROR",
            null,
            null,
            null,
            details.CandidateId,
            Now.AddMinutes(-1));
        adminRepository
            .Setup(repository => repository.GetCandidateAsync(details.CandidateId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(details);
        supportRepository
            .Setup(repository => repository.GetAuditAsync(
                new GetPurchaseOrderAuditQuery(details.CandidateId, 1, 50),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync([audit]);
        var service = CreateService(adminRepository, ordersRepository, supportRepository);

        var result = await service.GetDetailsAsync(details.CandidateId);

        Assert.Contains(Environment.NewLine, result.PrettyPayloadJson, StringComparison.Ordinal);
        Assert.Equal(Convert.ToBase64String(details.RowVersion), result.RowVersionBase64);
        Assert.Equal(audit, Assert.Single(result.AuditEntries));
        Assert.True(result.CanRetry);
        Assert.True(result.CanCancel);
        adminRepository.VerifyAll();
        supportRepository.VerifyAll();
        ordersRepository.VerifyNoOtherCalls();
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public async Task RequestRetryAsync_BlankActorOrReason_RejectsBeforePersistence(string blank)
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        var service = CreateService(adminRepository, ordersRepository, supportRepository);
        var request = new PurchaseOrderSupportActionRequest
        {
            CandidateId = Guid.NewGuid(),
            Reason = blank,
            RowVersionBase64 = Convert.ToBase64String(new byte[8])
        };

        await Assert.ThrowsAsync<ArgumentException>(() => service.RequestRetryAsync(request, "manager"));
        request.Reason = "Retry after investigation";
        await Assert.ThrowsAsync<ArgumentException>(() => service.RequestRetryAsync(request, blank));

        supportRepository.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task CancelAsync_InvalidRowVersion_RejectsBeforePersistence()
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        var service = CreateService(adminRepository, ordersRepository, supportRepository);
        var request = new PurchaseOrderSupportActionRequest
        {
            CandidateId = Guid.NewGuid(),
            Reason = "Duplicate order",
            RowVersionBase64 = "not-base64"
        };

        await Assert.ThrowsAsync<ArgumentException>(() => service.CancelAsync(request, "manager"));

        supportRepository.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task SupportActions_UseAuthenticatedActorCurrentUtcAndDecodedRowVersion()
    {
        var adminRepository = new Mock<IPurchaseOrderAdminRepository>(MockBehavior.Strict);
        var ordersRepository = new Mock<IPurchaseOrdersRepository>(MockBehavior.Strict);
        var supportRepository = new Mock<IPurchaseOrderSupportRepository>(MockBehavior.Strict);
        var candidateId = Guid.NewGuid();
        var rowVersion = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
        RequestPurchaseOrderRetryCommand? retry = null;
        CancelPurchaseOrderCandidateCommand? cancel = null;
        supportRepository
            .Setup(repository => repository.RequestRetryAsync(
                It.IsAny<RequestPurchaseOrderRetryCommand>(),
                It.IsAny<CancellationToken>()))
            .Callback<RequestPurchaseOrderRetryCommand, CancellationToken>((command, _) => retry = command)
            .ReturnsAsync(new PurchaseOrderSupportActionResult(candidateId, "RETRY_REQUESTED", rowVersion));
        supportRepository
            .Setup(repository => repository.CancelCandidateAsync(
                It.IsAny<CancelPurchaseOrderCandidateCommand>(),
                It.IsAny<CancellationToken>()))
            .Callback<CancelPurchaseOrderCandidateCommand, CancellationToken>((command, _) => cancel = command)
            .ReturnsAsync(new PurchaseOrderSupportActionResult(candidateId, "CANCELLED", rowVersion));
        var service = CreateService(adminRepository, ordersRepository, supportRepository);
        var request = new PurchaseOrderSupportActionRequest
        {
            CandidateId = candidateId,
            Reason = "Reviewed by support",
            RowVersionBase64 = Convert.ToBase64String(rowVersion)
        };

        await service.RequestRetryAsync(request, "manager@stark.dk");
        await service.CancelAsync(request, "manager@stark.dk");

        Assert.NotNull(retry);
        Assert.NotNull(cancel);
        Assert.Equal("manager@stark.dk", retry.Actor);
        Assert.Equal("manager@stark.dk", cancel.Actor);
        Assert.Equal(Now, retry.RequestedDateTime);
        Assert.Equal(Now, cancel.CancelledDateTime);
        Assert.Equal(rowVersion, retry.ExpectedCandidateRowVersion);
        Assert.Equal(rowVersion, cancel.ExpectedCandidateRowVersion);
        supportRepository.VerifyAll();
    }

    private static PurchaseOrderAdminService CreateService(
        Mock<IPurchaseOrderAdminRepository> adminRepository,
        Mock<IPurchaseOrdersRepository> ordersRepository,
        Mock<IPurchaseOrderSupportRepository> supportRepository,
        WebAppSettings? settings = null) => new(
            adminRepository.Object,
            ordersRepository.Object,
            supportRepository.Object,
            Options.Create(settings ?? new WebAppSettings()),
            new FixedTimeProvider(Now));

    private static PurchaseOrderCandidateDetails CreateDetails(string status) => new(
        Guid.Parse("941b6cac-295a-4130-bc76-c0e12ad51a9a"),
        null,
        "Relex",
        "RELEX",
        "BRIT186",
        "385",
        "PO-123",
        null,
        status,
        Now.AddMinutes(-1),
        "Status reason",
        null,
        null,
        null,
        null,
        null,
        null,
        "{\"purchaseOrderHeader\":{},\"purchaseOrderLines\":[]}",
        Now.AddHours(-1),
        Now.AddHours(-1),
        Now.AddMinutes(-1),
        Now.AddMinutes(-1),
        1,
        0,
        null,
        null,
        null,
        null,
        new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 });

    private static PurchaseOrderBatchSummary CreateBatchSummary(int index) => new(
        Guid.Parse($"00000000-0000-4000-8000-{index:D12}"),
        "Relex",
        $"SG_OrderProposal_{index:D2}.csv",
        $"/data/input/SG_OrderProposal_{index:D2}.csv",
        1024 + index,
        "COMPLETED",
        6,
        6,
        5,
        null,
        Now.AddMinutes(-index),
        Now.AddMinutes(-index + 1),
        Now.AddMinutes(-index + 1));

    private static PurchaseOrderBatchDetails CreateBatchDetails(string status) => new(
        Guid.Parse("63a79861-3964-4abf-9a9f-b5ae530c2b20"),
        "Relex",
        "SG_OrderProposal_20260824.csv",
        "/data/input/SG_OrderProposal_20260824.csv",
        2048,
        Enumerable.Range(1, 32).Select(value => (byte)value).ToArray(),
        status,
        6,
        6,
        5,
        null,
        null,
        Now.AddMinutes(-10),
        Now.AddMinutes(-9),
        Now.AddMinutes(-8),
        "relex-ingestion",
        Now.AddMinutes(-8),
        new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 });

    private static PurchaseOrderBatchOutcome CreateBatchOutcome(int index) => new(
        Guid.Parse($"10000000-0000-4000-8000-{index:D12}"),
        "BRIT186",
        "385",
        $"PO-{index:D2}",
        index == 1 ? "RECOVERABLE_ERROR" : "COMPLETED",
        index == 1 ? null : $"ICON-{index:D2}",
        index == 1 ? "ICON timeout" : null,
        Now.AddMinutes(-index),
        Now.AddMinutes(-index + 1));

    private sealed class FixedTimeProvider(DateTimeOffset now) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => now;
    }
}
