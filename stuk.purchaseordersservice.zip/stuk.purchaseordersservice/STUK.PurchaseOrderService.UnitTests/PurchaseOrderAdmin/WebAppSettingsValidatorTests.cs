using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Configuration;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

namespace STUK.PurchaseOrderService.UnitTests.PurchaseOrderAdmin;

public sealed class WebAppSettingsValidatorTests
{
    [Fact]
    public void Validate_DefaultSettings_Succeeds()
    {
        var result = new WebAppSettingsValidator().Validate(null, new WebAppSettings());

        Assert.Equal(ValidateOptionsResult.Success, result);
    }

    [Fact]
    public void Defaults_ExposeApiAndRelexWithRelexSelected()
    {
        var settings = new WebAppSettings();

        Assert.Equal(
            [PurchaseOrderSources.Api, PurchaseOrderSources.Relex],
            settings.AllowedSources);
        Assert.Equal(PurchaseOrderSources.Relex, settings.DefaultSource);
    }

    [Theory]
    [MemberData(nameof(InvalidSettings))]
    public void Validate_InvalidSettings_Fails(WebAppSettings settings)
    {
        var result = new WebAppSettingsValidator().Validate(null, settings);

        Assert.True(result.Failed);
    }

    public static TheoryData<WebAppSettings> InvalidSettings => new()
    {
        new WebAppSettings { AllowedSources = [] },
        new WebAppSettings { AllowedSources = ["Relex"], DefaultSource = "Api" },
        new WebAppSettings { DefaultPageSize = 0 },
        new WebAppSettings { DefaultPageSize = 25, MaxPageSize = 51 },
        new WebAppSettings { DefaultPageSize = 25, MaxPageSize = 25 }
    };

    [Theory]
    [InlineData("1h", 1)]
    [InlineData("6h", 6)]
    [InlineData("24h", 24)]
    [InlineData("7d", 168)]
    public void ResolveRange_PresetProducesHalfOpenUtcRange(string preset, int hours)
    {
        var now = new DateTimeOffset(2026, 8, 5, 12, 0, 0, TimeSpan.Zero);

        var range = PurchaseOrderOperationsRequest.ResolveRange(preset, null, null, now);

        Assert.Equal(now.AddHours(-hours), range.AfterDateTimeUtc);
        Assert.Equal(now, range.UntilDateTimeUtc);
    }

    [Fact]
    public void ResolveRange_CustomRangeReturnsExplicitUtcBounds()
    {
        var after = new DateTimeOffset(2026, 8, 1, 0, 0, 0, TimeSpan.Zero);
        var until = after.AddDays(2);

        var range = PurchaseOrderOperationsRequest.ResolveRange(
            "custom",
            after,
            until,
            until.AddDays(1));

        Assert.Equal(after, range.AfterDateTimeUtc);
        Assert.Equal(until, range.UntilDateTimeUtc);
    }

    [Theory]
    [InlineData(true, false)]
    [InlineData(false, true)]
    public void ResolveRange_CustomMissingBound_Throws(bool includeAfter, bool includeUntil)
    {
        var utc = new DateTimeOffset(2026, 8, 5, 12, 0, 0, TimeSpan.Zero);

        Assert.Throws<ArgumentException>(() => PurchaseOrderOperationsRequest.ResolveRange(
            "custom",
            includeAfter ? utc.AddHours(-1) : null,
            includeUntil ? utc : null,
            utc));
    }

    [Fact]
    public void ResolveRange_CustomNonUtcOffset_Throws()
    {
        var after = new DateTimeOffset(2026, 8, 5, 10, 0, 0, TimeSpan.FromHours(2));
        var until = new DateTimeOffset(2026, 8, 5, 12, 0, 0, TimeSpan.Zero);

        Assert.Throws<ArgumentException>(() => PurchaseOrderOperationsRequest.ResolveRange(
            "custom",
            after,
            until,
            until));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    public void ResolveRange_CustomStartNotBeforeEnd_Throws(int startOffsetHours)
    {
        var until = new DateTimeOffset(2026, 8, 5, 12, 0, 0, TimeSpan.Zero);

        Assert.Throws<ArgumentException>(() => PurchaseOrderOperationsRequest.ResolveRange(
            "custom",
            until.AddHours(startOffsetHours),
            until,
            until));
    }
}
