using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;

public interface IPurchaseOrderAdminService
{
    Task<PurchaseOrderOperationsViewModel> GetOperationsAsync(
        PurchaseOrderOperationsRequest request,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderDetailsViewModel> GetDetailsAsync(
        Guid candidateId,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderFilesViewModel> GetFilesAsync(
        PurchaseOrderFilesRequest request,
        CancellationToken cancellationToken = default);

    Task<PurchaseOrderFileDetailsViewModel> GetFileDetailsAsync(
        Guid batchId,
        PurchaseOrderFileDetailsRequest request,
        CancellationToken cancellationToken = default);

    Task RequestRetryAsync(
        PurchaseOrderSupportActionRequest request,
        string actor,
        CancellationToken cancellationToken = default);

    Task CancelAsync(
        PurchaseOrderSupportActionRequest request,
        string actor,
        CancellationToken cancellationToken = default);
}
