using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Serialization;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Configuration;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using System.Text.Json;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;

public sealed class PurchaseOrderAdminService : IPurchaseOrderAdminService
{
    private const int AuditPageSize = 50;
    private const string RelexSource = "Relex";
    private static readonly (string Status, string Label)[] FileStatuses =
    [
        ("PROCESSING", "Processing"),
        ("COMPLETED", "Completed"),
        ("FAILED", "Failed")
    ];

    private readonly IPurchaseOrderAdminRepository _adminRepository;
    private readonly IPurchaseOrdersRepository _ordersRepository;
    private readonly IPurchaseOrderSupportRepository _supportRepository;
    private readonly WebAppSettings _settings;
    private readonly string[] _allowedSources;
    private readonly string _defaultSource;
    private readonly TimeProvider _timeProvider;

    public PurchaseOrderAdminService(
        IPurchaseOrderAdminRepository adminRepository,
        IPurchaseOrdersRepository ordersRepository,
        IPurchaseOrderSupportRepository supportRepository,
        IOptions<WebAppSettings> settings,
        TimeProvider timeProvider)
    {
        ArgumentNullException.ThrowIfNull(adminRepository);
        ArgumentNullException.ThrowIfNull(ordersRepository);
        ArgumentNullException.ThrowIfNull(supportRepository);
        ArgumentNullException.ThrowIfNull(settings);
        ArgumentNullException.ThrowIfNull(timeProvider);
        _adminRepository = adminRepository;
        _ordersRepository = ordersRepository;
        _supportRepository = supportRepository;
        _settings = settings.Value;
        _allowedSources = _settings.AllowedSources
            .Where(source => !string.IsNullOrWhiteSpace(source))
            .Select(source => source.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();
        _defaultSource = _settings.DefaultSource.Trim();
        _timeProvider = timeProvider;
    }

    public async Task<PurchaseOrderOperationsViewModel> GetOperationsAsync(
        PurchaseOrderOperationsRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        var requestedSource = string.IsNullOrWhiteSpace(request.Source)
            ? _defaultSource
            : request.Source.Trim();
        var source = _allowedSources.FirstOrDefault(
            allowedSource => string.Equals(
                allowedSource,
                requestedSource,
                StringComparison.OrdinalIgnoreCase));
        if (source is null)
        {
            throw new ArgumentException("The selected source is not allowed.", nameof(request));
        }

        var range = PurchaseOrderOperationsRequest.ResolveRange(
            request.RangePreset,
            request.CustomAfterDateTimeUtc,
            request.CustomUntilDateTimeUtc,
            _timeProvider.GetUtcNow());
        var pageNumber = request.PageNumber < 1 ? 1 : request.PageNumber;
        var pageSize = request.PageSize ?? _settings.DefaultPageSize;
        if (pageSize < 1 || pageSize >= _settings.MaxPageSize)
        {
            throw new ArgumentException(
                $"The page size must be between 1 and {_settings.MaxPageSize - 1}.",
                nameof(request));
        }

        var status = ParseStatus(request.Status);
        var summaryTask = _adminRepository.GetStatusSummaryAsync(
            new PurchaseOrderStatusSummaryQuery(
                source,
                range.AfterDateTimeUtc,
                range.UntilDateTimeUtc),
            cancellationToken);
        var searchTask = _ordersRepository.SearchCandidates(
            new PurchaseOrderSearchCriteria
            {
                Source = source,
                Account = NullIfWhiteSpace(request.Account),
                Branch = NullIfWhiteSpace(request.Branch),
                Reference = NullIfWhiteSpace(request.Reference),
                IconPurchaseOrderNumber = NullIfWhiteSpace(request.IconPurchaseOrderNumber),
                Status = status,
                AcceptedAfterDateTimeUtc = range.AfterDateTimeUtc,
                AcceptedUntilDateTimeUtc = range.UntilDateTimeUtc,
                PageNumber = pageNumber,
                PageSize = pageSize + 1
            },
            cancellationToken);

        await Task.WhenAll(summaryTask, searchTask);
        var counts = summaryTask.Result.ToDictionary(
            item => item.Status,
            item => item.CandidateCount,
            StringComparer.OrdinalIgnoreCase);
        var cards = Enum.GetValues<PurchaseOrderCandidateStatus>()
            .Select(candidateStatus =>
            {
                var serializedStatus = EnumMemberValue.GetSerializedValue(candidateStatus);
                return new PurchaseOrderStatusCard(
                    candidateStatus,
                    serializedStatus,
                    counts.GetValueOrDefault(serializedStatus));
            })
            .ToArray();
        var rows = searchTask.Result.ToArray();

        request.Source = source;
        request.PageNumber = pageNumber;
        request.PageSize = pageSize;
        return new PurchaseOrderOperationsViewModel
        {
            Request = request,
            Range = range,
            AllowedSources = _allowedSources,
            StatusCards = cards,
            Results = rows.Take(pageSize).ToArray(),
            PageSize = pageSize,
            HasPreviousPage = pageNumber > 1,
            HasNextPage = rows.Length > pageSize
        };
    }

    public async Task<PurchaseOrderDetailsViewModel> GetDetailsAsync(
        Guid candidateId,
        CancellationToken cancellationToken = default)
    {
        if (candidateId == Guid.Empty)
        {
            throw new ArgumentException("A candidate ID is required.", nameof(candidateId));
        }

        var detailsTask = _adminRepository.GetCandidateAsync(candidateId, cancellationToken);
        var auditTask = _supportRepository.GetAuditAsync(
            new GetPurchaseOrderAuditQuery(candidateId, 1, AuditPageSize),
            cancellationToken);
        await Task.WhenAll(detailsTask, auditTask);
        var details = detailsTask.Result;
        var hasLease = details.LeaseToken.HasValue;

        return new PurchaseOrderDetailsViewModel
        {
            Details = details,
            PrettyPayloadJson = PrettyPrintJson(details.PayloadJson),
            RowVersionBase64 = Convert.ToBase64String(details.RowVersion),
            AuditEntries = auditTask.Result,
            CanRetry = !hasLease
                && details.Status is "RECOVERABLE_ERROR" or "NON_RECOVERABLE_ERROR",
            CanCancel = !hasLease
                && details.Status is not "COMPLETED" and not "CANCELLED"
        };
    }

    public async Task<PurchaseOrderFilesViewModel> GetFilesAsync(
        PurchaseOrderFilesRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        var range = PurchaseOrderOperationsRequest.ResolveRange(
            request.RangePreset,
            request.CustomAfterDateTimeUtc,
            request.CustomUntilDateTimeUtc,
            _timeProvider.GetUtcNow());
        var pageNumber = request.PageNumber < 1 ? 1 : request.PageNumber;
        var pageSize = ResolvePageSize(request.PageSize, request);
        var status = ParseFileStatus(request.Status);
        var originalFileName = NullIfWhiteSpace(request.OriginalFileName);

        var summaryTask = _adminRepository.GetBatchStatusSummaryAsync(
            new PurchaseOrderBatchStatusSummaryQuery(
                RelexSource,
                range.AfterDateTimeUtc,
                range.UntilDateTimeUtc),
            cancellationToken);
        var searchTask = _adminRepository.SearchBatchesAsync(
            new PurchaseOrderBatchSearchQuery(
                RelexSource,
                originalFileName,
                status,
                range.AfterDateTimeUtc,
                range.UntilDateTimeUtc,
                pageNumber,
                pageSize + 1),
            cancellationToken);

        await Task.WhenAll(summaryTask, searchTask);
        var counts = summaryTask.Result.ToDictionary(
            item => item.Status,
            item => item.BatchCount,
            StringComparer.OrdinalIgnoreCase);
        var rows = searchTask.Result.ToArray();

        request.OriginalFileName = originalFileName;
        request.Status = status;
        request.PageNumber = pageNumber;
        request.PageSize = pageSize;
        return new PurchaseOrderFilesViewModel
        {
            Request = request,
            Range = range,
            StatusCards = FileStatuses
                .Select(item => new PurchaseOrderFileStatusCard(
                    item.Status,
                    item.Label,
                    counts.GetValueOrDefault(item.Status)))
                .ToArray(),
            Results = rows.Take(pageSize).ToArray(),
            PageSize = pageSize,
            HasPreviousPage = pageNumber > 1,
            HasNextPage = rows.Length > pageSize
        };
    }

    public async Task<PurchaseOrderFileDetailsViewModel> GetFileDetailsAsync(
        Guid batchId,
        PurchaseOrderFileDetailsRequest request,
        CancellationToken cancellationToken = default)
    {
        if (batchId == Guid.Empty)
        {
            throw new ArgumentException("A batch ID is required.", nameof(batchId));
        }

        ArgumentNullException.ThrowIfNull(request);
        var pageNumber = request.PageNumber < 1 ? 1 : request.PageNumber;
        var pageSize = ResolvePageSize(request.PageSize, request);
        var status = ParseStatus(request.Status);
        var serializedStatus = status.HasValue
            ? EnumMemberValue.GetSerializedValue(status.Value)
            : null;

        var detailsTask = _adminRepository.GetBatchAsync(batchId, cancellationToken);
        var summaryTask = _adminRepository.GetBatchCandidateStatusSummaryAsync(
            batchId,
            cancellationToken);
        var searchTask = _adminRepository.SearchBatchCandidatesAsync(
            new PurchaseOrderBatchCandidateSearchQuery(
                batchId,
                serializedStatus,
                pageNumber,
                pageSize + 1),
            cancellationToken);

        await Task.WhenAll(detailsTask, summaryTask, searchTask);
        var counts = summaryTask.Result.ToDictionary(
            item => item.Status,
            item => item.CandidateCount,
            StringComparer.OrdinalIgnoreCase);
        var cards = Enum.GetValues<PurchaseOrderCandidateStatus>()
            .Select(candidateStatus =>
            {
                var candidateSerializedStatus =
                    EnumMemberValue.GetSerializedValue(candidateStatus);
                return new PurchaseOrderStatusCard(
                    candidateStatus,
                    candidateSerializedStatus,
                    counts.GetValueOrDefault(candidateSerializedStatus));
            })
            .ToArray();
        var rows = searchTask.Result.ToArray();

        request.Status = serializedStatus;
        request.PageNumber = pageNumber;
        request.PageSize = pageSize;
        return new PurchaseOrderFileDetailsViewModel
        {
            Details = detailsTask.Result,
            Request = request,
            StatusCards = cards,
            Orders = rows.Take(pageSize).ToArray(),
            PageSize = pageSize,
            HasPreviousPage = pageNumber > 1,
            HasNextPage = rows.Length > pageSize
        };
    }

    public async Task RequestRetryAsync(
        PurchaseOrderSupportActionRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        var rowVersion = ValidateSupportAction(request, actor);
        await _supportRepository.RequestRetryAsync(
            new RequestPurchaseOrderRetryCommand(
                request.CandidateId,
                actor.Trim(),
                request.Reason.Trim(),
                _timeProvider.GetUtcNow(),
                rowVersion),
            cancellationToken);
    }

    public async Task CancelAsync(
        PurchaseOrderSupportActionRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        var rowVersion = ValidateSupportAction(request, actor);
        await _supportRepository.CancelCandidateAsync(
            new CancelPurchaseOrderCandidateCommand(
                request.CandidateId,
                actor.Trim(),
                request.Reason.Trim(),
                _timeProvider.GetUtcNow(),
                rowVersion),
            cancellationToken);
    }

    private static PurchaseOrderCandidateStatus? ParseStatus(string? serializedStatus)
    {
        if (string.IsNullOrWhiteSpace(serializedStatus))
        {
            return null;
        }

        var match = Enum.GetValues<PurchaseOrderCandidateStatus>()
            .Cast<PurchaseOrderCandidateStatus?>()
            .SingleOrDefault(status => string.Equals(
                EnumMemberValue.GetSerializedValue(status!.Value),
                serializedStatus.Trim(),
                StringComparison.OrdinalIgnoreCase));
        return match ?? throw new ArgumentException("The selected status is invalid.");
    }

    private static string? ParseFileStatus(string? status)
    {
        if (string.IsNullOrWhiteSpace(status))
        {
            return null;
        }

        var normalized = status.Trim().ToUpperInvariant();
        return FileStatuses.Any(item => item.Status == normalized)
            ? normalized
            : throw new ArgumentException("The selected file status is invalid.");
    }

    private int ResolvePageSize(int? requestedPageSize, object request)
    {
        var pageSize = requestedPageSize ?? _settings.DefaultPageSize;
        if (pageSize < 1 || pageSize >= _settings.MaxPageSize)
        {
            throw new ArgumentException(
                $"The page size must be between 1 and {_settings.MaxPageSize - 1}.",
                nameof(request));
        }

        return pageSize;
    }

    private static byte[] ValidateSupportAction(
        PurchaseOrderSupportActionRequest request,
        string actor)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (request.CandidateId == Guid.Empty)
        {
            throw new ArgumentException("A candidate ID is required.", nameof(request));
        }

        if (string.IsNullOrWhiteSpace(actor))
        {
            throw new ArgumentException("An authenticated actor is required.", nameof(actor));
        }

        if (string.IsNullOrWhiteSpace(request.Reason) || request.Reason.Trim().Length > 1000)
        {
            throw new ArgumentException("A reason of at most 1000 characters is required.", nameof(request));
        }

        byte[] rowVersion;
        try
        {
            rowVersion = Convert.FromBase64String(request.RowVersionBase64);
        }
        catch (FormatException exception)
        {
            throw new ArgumentException("The candidate version is invalid.", nameof(request), exception);
        }

        if (rowVersion.Length != 8)
        {
            throw new ArgumentException("The candidate version is invalid.", nameof(request));
        }

        return rowVersion;
    }

    private static string PrettyPrintJson(string payloadJson)
    {
        using var document = JsonDocument.Parse(payloadJson);
        return JsonSerializer.Serialize(
            document.RootElement,
            new JsonSerializerOptions { WriteIndented = true });
    }

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
