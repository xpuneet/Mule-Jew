using Azure.Identity;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using SgBdApps.Core.Middleware;
using SgBdApps.Core.Security;
using STUK.ConfigurationProviders;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Configuration;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;

var builder = WebApplication.CreateBuilder(args);
var azureKeyVaultUri = builder.Configuration[ConfigConstants.AzureKeyVaultUriSettingKey];
if (!string.IsNullOrWhiteSpace(azureKeyVaultUri))
{
    builder.Configuration.AddAzureKeyVault(
        new Uri(azureKeyVaultUri),
        new DefaultAzureCredential());
}

builder.Configuration.AddSqlServerConfiguration(
    ConfigConstants.PurchaseOrdersDbConnectionStringName,
    "po.sp_get_application_settings",
    ConfigConstants.DatabaseConfigurationRefreshInterval,
    [
        ConfigConstants.DatabaseAppSettingCommonContext,
        ConfigConstants.DatabaseAppSettingWebAppContext
    ]);

var useLocalDevelopmentAuthentication =
    builder.Environment.IsDevelopment()
    && builder.Configuration.GetValue<bool>(
        "WebApp:EnableLocalDevelopmentAuthentication");

builder.Services.Configure<CookiePolicyOptions>(options =>
{
    options.CheckConsentNeeded = _ => true;
    options.MinimumSameSitePolicy = SameSiteMode.None;
});
var mvc = builder.Services.AddControllersWithViews();
if (useLocalDevelopmentAuthentication)
{
    builder.Services
        .AddAuthentication(options =>
        {
            options.DefaultScheme = LocalDevelopmentAuthenticationHandler.SchemeName;
            options.DefaultAuthenticateScheme = LocalDevelopmentAuthenticationHandler.SchemeName;
            options.DefaultChallengeScheme = LocalDevelopmentAuthenticationHandler.SchemeName;
            options.DefaultForbidScheme = LocalDevelopmentAuthenticationHandler.SchemeName;
        })
        .AddScheme<AuthenticationSchemeOptions, LocalDevelopmentAuthenticationHandler>(
            LocalDevelopmentAuthenticationHandler.SchemeName,
            _ => { });
    builder.Services.AddAuthorization(options =>
    {
        options.AddPolicy("User", policy => policy.RequireAuthenticatedUser());
        options.AddPolicy(
            Policies.PurchaseOrderReader,
            policy => policy.RequireRole(
                Roles.PurchaseOrderViewer,
                Roles.PurchaseOrderManager));
    });
}
else
{
    mvc.AddCoreUIFilters();
    builder.Services.AddCoreUI(builder.Configuration);
    builder.Services.AddAuthorization(options =>
    {
        options.CoreUIOptions();
        options.AddPolicy(
            Policies.PurchaseOrderReader,
            policy => policy.AddRequirements(new RoleMembershipRequirement(
                Roles.PurchaseOrderViewer,
                Roles.PurchaseOrderManager)));
    });
}
builder.Services.AddSingleton<IValidateOptions<WebAppSettings>, WebAppSettingsValidator>();
builder.Services
    .AddOptions<WebAppSettings>()
    .Bind(builder.Configuration.GetSection(WebAppSettings.SectionName))
    .ValidateOnStart();
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddPurchaseOrderPersistence(builder.Configuration);
builder.Services.AddScoped<IPurchaseOrderAdminService, PurchaseOrderAdminService>();
if (!string.IsNullOrWhiteSpace(
        builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"]))
{
    builder.Services.AddApplicationInsightsTelemetry();
}

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

if (!useLocalDevelopmentAuthentication)
{
    app.UseCoreUIMiddleware(builder.Configuration, app.Environment, options =>
    {
        options.MenuName = "Purchase Orders Admin";
        options.Description = "Monitor and support Purchase Orders";
        options.Icon = STUK.PurchaseOrderService.PurchaseOrderAdmin.Properties.Resources.Icon;
    });
}
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseCookiePolicy();
app.UseRouting();
if (useLocalDevelopmentAuthentication)
{
    app.UseAuthentication();
}
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

app.Run();

public partial class PurchaseOrderAdminProgram;
