(() => {
    "use strict";

    const message = document.getElementById("support-action-message");
    const refresh = document.getElementById("refresh-details");

    document.querySelectorAll("[data-open-dialog]").forEach(button => {
        button.addEventListener("click", () => {
            const dialog = document.getElementById(button.dataset.openDialog);
            dialog?.showModal();
        });
    });

    document.querySelectorAll("[data-close-dialog]").forEach(button => {
        button.addEventListener("click", () => button.closest("dialog")?.close());
    });

    refresh?.addEventListener("click", () => window.location.reload());

    const showMessage = (text, kind, allowRefresh) => {
        if (!message) {
            return;
        }

        message.textContent = text;
        message.className = `alert alert-${kind}`;
        message.hidden = false;
        if (refresh) {
            refresh.hidden = !allowRefresh;
        }
    };

    document.querySelectorAll(".support-action-form").forEach(form => {
        form.addEventListener("submit", async event => {
            event.preventDefault();
            const submit = form.querySelector("button[type='submit']");
            if (submit) {
                submit.disabled = true;
            }

            try {
                const response = await fetch(form.action, {
                    method: "POST",
                    body: new FormData(form),
                    headers: { "X-Requested-With": "XMLHttpRequest" }
                });

                if (response.ok) {
                    window.location.reload();
                    return;
                }

                form.closest("dialog")?.close();
                if (response.status === 400) {
                    showMessage("Check the reason and refresh the page before trying again.", "danger", false);
                } else if (response.status === 404) {
                    showMessage("This candidate no longer exists. Return to Operations or refresh.", "warning", true);
                } else if (response.status === 409) {
                    showMessage("The candidate state changed. Refresh details before taking another action.", "warning", true);
                } else {
                    showMessage("The action could not be completed. Contact support if it continues.", "danger", false);
                }
            } catch {
                showMessage("The action could not be completed. Check your connection and try again.", "danger", false);
            } finally {
                if (submit) {
                    submit.disabled = false;
                }
            }
        });
    });
})();
