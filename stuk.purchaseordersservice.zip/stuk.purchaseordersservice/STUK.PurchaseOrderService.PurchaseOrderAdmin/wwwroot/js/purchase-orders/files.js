(() => {
    "use strict";

    const form = document.getElementById("files-form");
    const preset = document.getElementById("files-range-preset");
    const customRange = document.getElementById("files-custom-range");
    const afterLocal = document.getElementById("files-custom-after-local");
    const untilLocal = document.getElementById("files-custom-until-local");
    const afterUtc = document.getElementById("files-custom-after-utc");
    const untilUtc = document.getElementById("files-custom-until-utc");
    const validation = document.getElementById("files-range-validation");

    if (!form || !preset || !customRange || !afterLocal || !untilLocal || !afterUtc || !untilUtc || !validation) {
        return;
    }

    const setVisibleUtcValue = (input, isoValue) => {
        if (!isoValue) {
            return;
        }

        const parsed = new Date(isoValue);
        if (!Number.isNaN(parsed.getTime())) {
            input.value = parsed.toISOString().slice(0, 16);
        }
    };

    const parseUtcInput = value => {
        if (!value) {
            return null;
        }

        const parsed = new Date(`${value}Z`);
        return Number.isNaN(parsed.getTime()) ? null : parsed;
    };

    const updateCustomVisibility = () => {
        customRange.hidden = preset.value !== "custom";
        validation.hidden = true;
    };

    setVisibleUtcValue(afterLocal, afterUtc.value);
    setVisibleUtcValue(untilLocal, untilUtc.value);
    updateCustomVisibility();
    preset.addEventListener("change", updateCustomVisibility);

    form.addEventListener("submit", event => {
        if (preset.value !== "custom") {
            afterUtc.value = "";
            untilUtc.value = "";
            return;
        }

        const after = parseUtcInput(afterLocal.value);
        const until = parseUtcInput(untilLocal.value);
        if (!after || !until || after.getTime() >= until.getTime()) {
            event.preventDefault();
            validation.textContent = "Choose a valid UTC start and end, with the start before the end.";
            validation.hidden = false;
            return;
        }

        afterUtc.value = after.toISOString();
        untilUtc.value = until.toISOString();
        validation.hidden = true;
    });
})();
