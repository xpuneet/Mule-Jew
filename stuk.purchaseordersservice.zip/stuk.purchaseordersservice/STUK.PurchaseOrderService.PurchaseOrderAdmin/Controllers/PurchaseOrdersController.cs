using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SgBdApps.Core.Attributes;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Controllers;

[AuthorizeUser]
[Authorize(Policy = Policies.PurchaseOrderReader)]
public sealed class PurchaseOrdersController : Controller
{
    private readonly IPurchaseOrderAdminService _adminService;
    private readonly ILogger<PurchaseOrdersController> _logger;

    public PurchaseOrdersController(
        IPurchaseOrderAdminService adminService,
        ILogger<PurchaseOrdersController> logger)
    {
        ArgumentNullException.ThrowIfNull(adminService);
        ArgumentNullException.ThrowIfNull(logger);
        _adminService = adminService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<IActionResult> Details(
        Guid id,
        CancellationToken cancellationToken)
    {
        try
        {
            return View(await _adminService.GetDetailsAsync(id, cancellationToken));
        }
        catch (PurchaseOrderPersistenceException exception)
            when (exception.Error == PurchaseOrderPersistenceError.EntityNotFound)
        {
            return NotFoundProblem();
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [AuthorizeRoles(Roles.PurchaseOrderManager)]
    public Task<IActionResult> Retry(
        PurchaseOrderSupportActionRequest request,
        CancellationToken cancellationToken) => ExecuteSupportActionAsync(
            request,
            "retry",
            (actor, token) => _adminService.RequestRetryAsync(request, actor, token),
            cancellationToken);

    [HttpPost]
    [ValidateAntiForgeryToken]
    [AuthorizeRoles(Roles.PurchaseOrderManager)]
    public Task<IActionResult> Cancel(
        PurchaseOrderSupportActionRequest request,
        CancellationToken cancellationToken) => ExecuteSupportActionAsync(
            request,
            "cancel",
            (actor, token) => _adminService.CancelAsync(request, actor, token),
            cancellationToken);

    private async Task<IActionResult> ExecuteSupportActionAsync(
        PurchaseOrderSupportActionRequest request,
        string action,
        Func<string, CancellationToken, Task> execute,
        CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var actor = User.Identity?.Name;
        if (string.IsNullOrWhiteSpace(actor))
        {
            return Unauthorized();
        }

        try
        {
            await execute(actor, cancellationToken);
            return Ok();
        }
        catch (ArgumentException)
        {
            return Problem(
                statusCode: StatusCodes.Status400BadRequest,
                title: "Invalid support action",
                detail: "The submitted support action is invalid.");
        }
        catch (PurchaseOrderPersistenceException exception)
        {
            return MapPersistenceFailure(exception);
        }
        catch (Exception exception)
        {
            var traceId = HttpContext.TraceIdentifier;
            _logger.LogError(
                exception,
                "Purchase Order support action {Action} failed for candidate {CandidateId}, actor {Actor}, trace {TraceId}.",
                action,
                request.CandidateId,
                actor,
                traceId);
            var problem = new ProblemDetails
            {
                Status = StatusCodes.Status500InternalServerError,
                Title = "Purchase Order action failed",
                Detail = "The action could not be completed. Use the correlation ID when contacting support."
            };
            problem.Extensions["traceId"] = traceId;
            return StatusCode(StatusCodes.Status500InternalServerError, problem);
        }
    }

    private IActionResult MapPersistenceFailure(PurchaseOrderPersistenceException exception) =>
        exception.Error switch
        {
            PurchaseOrderPersistenceError.EntityNotFound => NotFoundProblem(),
            PurchaseOrderPersistenceError.ConcurrencyConflict
                or PurchaseOrderPersistenceError.LeaseConflict
                or PurchaseOrderPersistenceError.InvalidLifecycleTransition => Problem(
                    statusCode: StatusCodes.Status409Conflict,
                    title: "Purchase Order state changed",
                    detail: "The candidate changed or the action is no longer available. Refresh the details and try again."),
            _ => GenericPersistenceProblem()
        };

    private ObjectResult NotFoundProblem() => Problem(
        statusCode: StatusCodes.Status404NotFound,
        title: "Purchase Order candidate not found",
        detail: "The requested Purchase Order candidate was not found.");

    private ObjectResult GenericPersistenceProblem()
    {
        var traceId = HttpContext.TraceIdentifier;
        var problem = new ProblemDetails
        {
            Status = StatusCodes.Status500InternalServerError,
            Title = "Purchase Order action failed",
            Detail = "The action could not be completed. Use the correlation ID when contacting support."
        };
        problem.Extensions["traceId"] = traceId;
        return StatusCode(StatusCodes.Status500InternalServerError, problem);
    }
}
