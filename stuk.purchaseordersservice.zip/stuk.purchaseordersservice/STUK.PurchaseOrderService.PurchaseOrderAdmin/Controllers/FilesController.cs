using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SgBdApps.Core.Attributes;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Controllers;

[AuthorizeUser]
[Authorize(Policy = Policies.PurchaseOrderReader)]
public sealed class FilesController : Controller
{
    private readonly IPurchaseOrderAdminService _adminService;

    public FilesController(IPurchaseOrderAdminService adminService)
    {
        ArgumentNullException.ThrowIfNull(adminService);
        _adminService = adminService;
    }

    [HttpGet]
    public async Task<IActionResult> Index(
        PurchaseOrderFilesRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            return View(await _adminService.GetFilesAsync(request, cancellationToken));
        }
        catch (ArgumentException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            return View(new PurchaseOrderFilesViewModel
            {
                Request = request,
                Range = new PurchaseOrderDateRange(default, default),
                StatusCards = [],
                Results = [],
                PageSize = 0,
                HasPreviousPage = false,
                HasNextPage = false
            });
        }
    }

    [HttpGet]
    public async Task<IActionResult> Details(
        Guid id,
        PurchaseOrderFileDetailsRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            return View(await _adminService.GetFileDetailsAsync(
                id,
                request,
                cancellationToken));
        }
        catch (PurchaseOrderPersistenceException exception)
            when (exception.Error == PurchaseOrderPersistenceError.EntityNotFound)
        {
            return NotFoundProblem();
        }
        catch (ArgumentException)
        {
            return Problem(
                statusCode: StatusCodes.Status400BadRequest,
                title: "Invalid Purchase Order file request",
                detail: "The requested file view is invalid.");
        }
    }

    private ObjectResult NotFoundProblem() => Problem(
        statusCode: StatusCodes.Status404NotFound,
        title: "Purchase Order file not found",
        detail: "The requested Purchase Order file was not found.");
}
