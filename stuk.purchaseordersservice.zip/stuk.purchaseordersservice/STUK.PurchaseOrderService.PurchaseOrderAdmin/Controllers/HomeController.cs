using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SgBdApps.Core.Attributes;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Services;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Controllers;

[AuthorizeUser]
[Authorize(Policy = Policies.PurchaseOrderReader)]
public sealed class HomeController : Controller
{
    private readonly IPurchaseOrderAdminService _adminService;

    public HomeController(IPurchaseOrderAdminService adminService)
    {
        ArgumentNullException.ThrowIfNull(adminService);
        _adminService = adminService;
    }

    [HttpGet]
    public async Task<IActionResult> Index(
        PurchaseOrderOperationsRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            return View(await _adminService.GetOperationsAsync(request, cancellationToken));
        }
        catch (ArgumentException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            return View(new PurchaseOrderOperationsViewModel
            {
                Request = request,
                Range = new PurchaseOrderDateRange(default, default),
                AllowedSources = [],
                StatusCards = [],
                Results = [],
                PageSize = 0,
                HasPreviousPage = false,
                HasNextPage = false
            });
        }
    }
}
