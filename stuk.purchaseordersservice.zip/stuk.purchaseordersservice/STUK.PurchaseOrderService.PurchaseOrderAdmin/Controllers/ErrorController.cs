using Microsoft.AspNetCore.Mvc;
using SgBdApps.Core.Attributes;
using STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;
using System.Diagnostics;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Controllers;

[AuthorizeUser]
public sealed class ErrorController : Controller
{
    [Route("/Error")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Index() => View("Error", new ErrorViewModel
    {
        RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
    });
}
