using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

public sealed class PurchaseOrderDetailsViewModel
{
    public required PurchaseOrderCandidateDetails Details { get; init; }

    public required string PrettyPayloadJson { get; init; }

    public required string RowVersionBase64 { get; init; }

    public required IReadOnlyList<PurchaseOrderAuditEntry> AuditEntries { get; init; }

    public required bool CanRetry { get; init; }

    public required bool CanCancel { get; init; }
}
