using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

public sealed class PurchaseOrderOperationsRequest
{
    public string? Source { get; set; }

    public string RangePreset { get; set; } = "24h";

    public DateTimeOffset? CustomAfterDateTimeUtc { get; set; }

    public DateTimeOffset? CustomUntilDateTimeUtc { get; set; }

    public string? Account { get; set; }

    public string? Branch { get; set; }

    public string? Reference { get; set; }

    public string? IconPurchaseOrderNumber { get; set; }

    public string? Status { get; set; }

    public int PageNumber { get; set; } = 1;

    public int? PageSize { get; set; }

    public static PurchaseOrderDateRange ResolveRange(
        string? preset,
        DateTimeOffset? customAfterDateTimeUtc,
        DateTimeOffset? customUntilDateTimeUtc,
        DateTimeOffset nowUtc)
    {
        if (nowUtc.Offset != TimeSpan.Zero)
        {
            throw new ArgumentException("The current timestamp must use the UTC offset.", nameof(nowUtc));
        }

        var normalizedPreset = string.IsNullOrWhiteSpace(preset)
            ? "24h"
            : preset.Trim().ToLowerInvariant();
        if (normalizedPreset == "custom")
        {
            if (!customAfterDateTimeUtc.HasValue || !customUntilDateTimeUtc.HasValue)
            {
                throw new ArgumentException("Both custom UTC range bounds are required.");
            }

            if (customAfterDateTimeUtc.Value.Offset != TimeSpan.Zero
                || customUntilDateTimeUtc.Value.Offset != TimeSpan.Zero)
            {
                throw new ArgumentException("Custom range bounds must use the UTC offset.");
            }

            if (customAfterDateTimeUtc.Value >= customUntilDateTimeUtc.Value)
            {
                throw new ArgumentException("The custom range start must be before the end.");
            }

            return new PurchaseOrderDateRange(
                customAfterDateTimeUtc.Value,
                customUntilDateTimeUtc.Value);
        }

        var hours = normalizedPreset switch
        {
            "1h" => 1,
            "6h" => 6,
            "24h" => 24,
            "7d" => 168,
            _ => throw new ArgumentException("The selected time range is not supported.", nameof(preset))
        };

        return new PurchaseOrderDateRange(nowUtc.AddHours(-hours), nowUtc);
    }
}

public sealed record PurchaseOrderDateRange(
    DateTimeOffset AfterDateTimeUtc,
    DateTimeOffset UntilDateTimeUtc);
