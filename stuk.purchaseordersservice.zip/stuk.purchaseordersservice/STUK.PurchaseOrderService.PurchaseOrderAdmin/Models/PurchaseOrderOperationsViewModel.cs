using STUK.PurchaseOrderService.Common.Contracts.ApiModels.V1;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

public sealed class PurchaseOrderOperationsViewModel
{
    public required PurchaseOrderOperationsRequest Request { get; init; }

    public required PurchaseOrderDateRange Range { get; init; }

    public required IReadOnlyList<string> AllowedSources { get; init; }

    public required IReadOnlyList<PurchaseOrderStatusCard> StatusCards { get; init; }

    public required IReadOnlyList<PurchaseOrderSummary> Results { get; init; }

    public required int PageSize { get; init; }

    public required bool HasPreviousPage { get; init; }

    public required bool HasNextPage { get; init; }
}

public sealed record PurchaseOrderStatusCard(
    PurchaseOrderCandidateStatus Status,
    string SerializedStatus,
    long Count);
