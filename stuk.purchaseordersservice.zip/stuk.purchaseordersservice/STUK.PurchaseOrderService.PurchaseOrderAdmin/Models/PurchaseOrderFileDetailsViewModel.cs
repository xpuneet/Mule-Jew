using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

public sealed class PurchaseOrderFileDetailsViewModel
{
    public required PurchaseOrderBatchDetails Details { get; init; }

    public required PurchaseOrderFileDetailsRequest Request { get; init; }

    public required IReadOnlyList<PurchaseOrderStatusCard> StatusCards { get; init; }

    public required IReadOnlyList<PurchaseOrderBatchOutcome> Orders { get; init; }

    public required int PageSize { get; init; }

    public required bool HasPreviousPage { get; init; }

    public required bool HasNextPage { get; init; }
}
