using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

public sealed class PurchaseOrderFilesViewModel
{
    public required PurchaseOrderFilesRequest Request { get; init; }

    public required PurchaseOrderDateRange Range { get; init; }

    public required IReadOnlyList<PurchaseOrderFileStatusCard> StatusCards { get; init; }

    public required IReadOnlyList<PurchaseOrderBatchSummary> Results { get; init; }

    public required int PageSize { get; init; }

    public required bool HasPreviousPage { get; init; }

    public required bool HasNextPage { get; init; }
}

public sealed record PurchaseOrderFileStatusCard(
    string Status,
    string Label,
    long Count);
