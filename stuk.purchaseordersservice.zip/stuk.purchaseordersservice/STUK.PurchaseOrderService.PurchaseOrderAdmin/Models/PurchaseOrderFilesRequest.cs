namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

public sealed class PurchaseOrderFilesRequest
{
    public string RangePreset { get; set; } = "24h";

    public DateTimeOffset? CustomAfterDateTimeUtc { get; set; }

    public DateTimeOffset? CustomUntilDateTimeUtc { get; set; }

    public string? OriginalFileName { get; set; }

    public string? Status { get; set; }

    public int PageNumber { get; set; } = 1;

    public int? PageSize { get; set; }
}

public sealed class PurchaseOrderFileDetailsRequest
{
    public string? Status { get; set; }

    public int PageNumber { get; set; } = 1;

    public int? PageSize { get; set; }
}
