using System.ComponentModel.DataAnnotations;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Models;

public sealed class PurchaseOrderSupportActionRequest
{
    public Guid CandidateId { get; set; }

    [Required]
    public string RowVersionBase64 { get; set; } = string.Empty;

    [Required]
    [StringLength(1000)]
    public string Reason { get; set; } = string.Empty;
}
