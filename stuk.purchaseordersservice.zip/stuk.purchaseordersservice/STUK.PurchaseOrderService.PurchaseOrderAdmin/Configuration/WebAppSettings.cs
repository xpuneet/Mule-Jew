using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Configuration;

public sealed class WebAppSettings
{
    public const string SectionName = "WebApp";

    public string[] AllowedSources { get; init; } =
        [PurchaseOrderSources.Api, PurchaseOrderSources.Relex];

    public string DefaultSource { get; init; } = PurchaseOrderSources.Relex;

    public int DefaultPageSize { get; init; } = 25;

    public int MaxPageSize { get; init; } = 50;

    public bool EnableLocalDevelopmentAuthentication { get; init; }
}
