using Microsoft.Extensions.Options;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Configuration;

public sealed class WebAppSettingsValidator : IValidateOptions<WebAppSettings>
{
    public ValidateOptionsResult Validate(string? name, WebAppSettings options)
    {
        ArgumentNullException.ThrowIfNull(options);
        var failures = new List<string>();
        var sources = options.AllowedSources
            .Where(source => !string.IsNullOrWhiteSpace(source))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        if (sources.Length == 0)
        {
            failures.Add("At least one allowed Purchase Order source is required.");
        }

        if (string.IsNullOrWhiteSpace(options.DefaultSource)
            || !sources.Contains(options.DefaultSource, StringComparer.OrdinalIgnoreCase))
        {
            failures.Add("The default source must be included in the allowed sources.");
        }

        if (options.DefaultPageSize < 1)
        {
            failures.Add("The default page size must be positive.");
        }

        if (options.MaxPageSize is < 2 or > 50)
        {
            failures.Add("The maximum page size must be between 2 and 50.");
        }

        if (options.DefaultPageSize >= options.MaxPageSize)
        {
            failures.Add("The default page size must be smaller than the maximum page size.");
        }

        return failures.Count == 0
            ? ValidateOptionsResult.Success
            : ValidateOptionsResult.Fail(failures);
    }
}
