namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;

public static class Policies
{
    public const string PurchaseOrderReader = "PurchaseOrderReader";
}
