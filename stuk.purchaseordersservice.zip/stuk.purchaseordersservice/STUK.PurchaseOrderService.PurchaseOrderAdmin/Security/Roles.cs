using SgBdApps.Core.Attributes;

namespace STUK.PurchaseOrderService.PurchaseOrderAdmin.Security;

[RoleDefinitions]
public static class Roles
{
    public const string PurchaseOrderViewer = "PurchaseOrderViewer";

    public const string PurchaseOrderManager = "PurchaseOrderManager";
}
