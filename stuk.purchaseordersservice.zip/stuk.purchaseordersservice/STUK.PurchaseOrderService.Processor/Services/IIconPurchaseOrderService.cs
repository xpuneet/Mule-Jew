using STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Reports;
using STUK.IconIntegration.Reports.Account;

namespace STUK.PurchaseOrderService.Processor.Services;

public interface IIconPurchaseOrderService
{
    Task<IconCreatePurchaseOrderResponse> CreatePurchaseOrderAsync(
        IconCreatePurchaseOrderRequest request,
        CancellationToken cancellationToken = default);

    Task<IconReportResponse<PurchaseOrderActivationOptionsResult>>
        GetPurchaseOrderActivationOptions(
            string account,
            CancellationToken cancellationToken = default);
}
