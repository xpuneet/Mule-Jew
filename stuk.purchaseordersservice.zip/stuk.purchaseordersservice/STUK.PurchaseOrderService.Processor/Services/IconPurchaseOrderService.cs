using Microsoft.Extensions.Options;
using STUK.IconIntegration.Configuration;
using STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Reports;
using STUK.IconIntegration.Reports.Account;

namespace STUK.PurchaseOrderService.Processor.Services;

public sealed class IconPurchaseOrderService : IIconPurchaseOrderService
{
    private readonly IconSettings _iconSettings;
    private readonly IIconHttpClient _iconHttpClient;

    public IconPurchaseOrderService(
        IOptions<IconSettings> iconSettings,
        IIconHttpClient iconHttpClient)
    {
        _iconSettings = iconSettings.Value;
        _iconHttpClient = iconHttpClient;
    }

    public Task<IconCreatePurchaseOrderResponse> CreatePurchaseOrderAsync(
        IconCreatePurchaseOrderRequest request,
        CancellationToken cancellationToken = default)
    {
        return _iconHttpClient.POST_CreatePurchaseOrderAsync(
            request,
            _iconSettings.PurchaseOrderAuthToken!,
            cancellationToken);
    }

    public async Task<IconReportResponse<PurchaseOrderActivationOptionsResult>>
        GetPurchaseOrderActivationOptions(
            string account,
            CancellationToken cancellationToken = default)
    {
        var request = new PurchaseOrderActivationOptionsRequest
        {
            Account = account
        };

        var response = await _iconHttpClient.Reports
            .POST_PurchaseOrderActivationOptionsAsync(
                request,
                _iconHttpClient.IconSettings.ReportsAuthToken,
                _iconHttpClient.IconSettings.PurchaseOrderActivationOptionsReportName)
            .WaitAsync(cancellationToken);

        return response;
    }
}
