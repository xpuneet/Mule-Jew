using STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Processor.Mapping;

public interface IPurchaseOrderIconMapper
{
    IconCreatePurchaseOrderRequest Map(
        PurchaseOrder purchaseOrder,
        PurchaseOrderActivationOptionsResult activationOptions);
}
