namespace STUK.PurchaseOrderService.Processor.Mapping;

public sealed class PurchaseOrderIconMappingException : Exception
{
    public PurchaseOrderIconMappingException(string path, string message)
        : base($"{path}: {message}")
    {
        Path = path;
    }

    public string Path { get; }
}
