using System.Globalization;
using Icon = STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Processor.Mapping;

public sealed class PurchaseOrderIconMapper : IPurchaseOrderIconMapper
{
    public Icon.IconCreatePurchaseOrderRequest Map(
        PurchaseOrder purchaseOrder,
        PurchaseOrderActivationOptionsResult activationOptions)
    {
        ArgumentNullException.ThrowIfNull(purchaseOrder);
        ArgumentNullException.ThrowIfNull(activationOptions);

        var header = purchaseOrder.PurchaseOrderHeader
            ?? throw MappingError("purchaseOrderHeader", "A purchase order header is required.");
        var lines = purchaseOrder.PurchaseOrderLines;
        if (lines is null || lines.Count == 0)
        {
            throw MappingError("purchaseOrderLines", "At least one purchase order line is required.");
        }

        var supplierContact = SelectContact(header.Contacts, PurchaseOrderPartyType.Supplier);
        var invoiceContact = SelectContact(header.Contacts, PurchaseOrderPartyType.Invoice);
        var supplierAddress = SelectAddress(header.Addresses, PurchaseOrderPartyType.Supplier);
        var invoiceAddress = SelectAddress(header.Addresses, PurchaseOrderPartyType.Invoice);

        return new Icon.IconCreatePurchaseOrderRequest
        {
            Header = new Icon.PurchaseOrderHeader
            {
                Account = header.Account,
                Branch = header.Branch,
                Location = header.StockClass,
                CreateUser = header.CreateUser,
                Reference = header.Reference,
                DateExpected = FormatDate(header.DateExpected),
                Bypass = activationOptions.Bypass,
                PackIgnore = ParsePackIgnore(header.ExtensionAttributes),
                Name = supplierContact?.Name,
                Address = MapAddress(supplierAddress),
                CountryOfOrigin = ResolveCountry(supplierAddress, invoiceAddress),
                InvoiceName = invoiceContact?.Name,
                InvoiceAddress = MapInvoiceAddress(invoiceAddress),
                Instructions = header.Instructions,
                Narrative = header.Narrative,
                SuspendOrder = header.SuspendOrder,
                OrderType = MapOrderType(header.OrderType),
                ActivateAction = activationOptions.ActivateAction,
                DeliveryMethod = MapDeliveryMethod(header.DeliveryMethod),
                ContactID = ParseContactId(supplierContact?.Contact),
                ExtOrderRef = header.ExtOrderRef,
                Email = supplierContact?.Email,
                Reason = header.ReasonReturn,
                ReasonPurc = header.ReasonPurchase
            },
            Lines = new Icon.PurchaseOrderLines
            {
                Line = lines.Select(MapLine).ToList()
            }
        };
    }

    private static PurchaseOrderContact? SelectContact(
        IEnumerable<PurchaseOrderContact>? contacts,
        PurchaseOrderPartyType type)
    {
        var matches = contacts?.Where(contact => contact.Type == type).ToList() ?? [];
        if (matches.Count > 1)
        {
            throw MappingError(
                $"purchaseOrderHeader.contacts[{PartyPath(type)}]",
                "Only one contact is allowed for each party type.");
        }

        return matches.SingleOrDefault();
    }

    private static PurchaseOrderAddress? SelectAddress(
        IEnumerable<PurchaseOrderAddress>? addresses,
        PurchaseOrderPartyType type)
    {
        var matches = addresses?.Where(address => address.Type == type).ToList() ?? [];
        if (matches.Count > 1)
        {
            throw MappingError(
                $"purchaseOrderHeader.addresses[{PartyPath(type)}]",
                "Only one address is allowed for each party type.");
        }

        return matches.SingleOrDefault();
    }

    private static Icon.PurchaseOrderAddress? MapAddress(PurchaseOrderAddress? address) =>
        address is null
            ? null
            : new Icon.PurchaseOrderAddress
            {
                Line = address.Lines.ToList(),
                PostCode = address.PostCode
            };

    private static Icon.PurchaseOrderInvoiceAddress? MapInvoiceAddress(
        PurchaseOrderAddress? address) =>
        address is null
            ? null
            : new Icon.PurchaseOrderInvoiceAddress
            {
                Line = address.Lines.ToList(),
                Postcode = address.PostCode
            };

    private static string? ResolveCountry(
        PurchaseOrderAddress? supplierAddress,
        PurchaseOrderAddress? invoiceAddress)
    {
        var supplierCountry = NullIfWhiteSpace(supplierAddress?.Country);
        var invoiceCountry = NullIfWhiteSpace(invoiceAddress?.Country);
        if (supplierCountry is not null
            && invoiceCountry is not null
            && !string.Equals(supplierCountry, invoiceCountry, StringComparison.OrdinalIgnoreCase))
        {
            throw MappingError(
                "purchaseOrderHeader.addresses",
                "Supplier and invoice countries must match when both are provided.");
        }

        return supplierCountry ?? invoiceCountry;
    }

    private static bool? ParsePackIgnore(
        IEnumerable<PurchaseOrderExtensionAttribute>? extensionAttributes)
    {
        var matches = extensionAttributes?
            .Where(attribute => string.Equals(
                attribute.Name,
                "packIgnore",
                StringComparison.OrdinalIgnoreCase))
            .ToList() ?? [];
        if (matches.Count > 1)
        {
            throw MappingError(
                "purchaseOrderHeader.extensionAttributes[packIgnore]",
                "Only one packIgnore extension attribute is allowed.");
        }

        var value = matches.SingleOrDefault()?.Value;
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        if (!bool.TryParse(value, out var parsed))
        {
            throw MappingError(
                "purchaseOrderHeader.extensionAttributes[packIgnore].value",
                "The value must be true or false.");
        }

        return parsed;
    }

    private static uint? ParseContactId(string? contact)
    {
        if (string.IsNullOrWhiteSpace(contact))
        {
            return null;
        }

        if (!uint.TryParse(
                contact,
                NumberStyles.None,
                CultureInfo.InvariantCulture,
                out var contactId))
        {
            throw MappingError(
                "purchaseOrderHeader.contacts[supplier].contact",
                "The value must be an unsigned 32-bit integer without formatting.");
        }

        return contactId;
    }

    private static Icon.PurchaseOrderHeaderOrderType? MapOrderType(PurchaseOrderType? orderType) =>
        orderType switch
        {
            null => null,
            PurchaseOrderType.Stock => Icon.PurchaseOrderHeaderOrderType.Stock,
            PurchaseOrderType.Ibt => Icon.PurchaseOrderHeaderOrderType.Ibt,
            PurchaseOrderType.Ict => Icon.PurchaseOrderHeaderOrderType.Ict,
            PurchaseOrderType.Emergency => Icon.PurchaseOrderHeaderOrderType.Emergency,
            PurchaseOrderType.Direct => Icon.PurchaseOrderHeaderOrderType.Direct,
            PurchaseOrderType.Return => Icon.PurchaseOrderHeaderOrderType.Return,
            PurchaseOrderType.Link => Icon.PurchaseOrderHeaderOrderType.Link,
            _ => throw MappingError(
                "purchaseOrderHeader.orderType",
                $"Unsupported purchase order type value {(int)orderType.Value}.")
        };

    private static Icon.PurchaseOrderDeliveryMethod? MapDeliveryMethod(
        PurchaseOrderDeliveryMethod? deliveryMethod) =>
        deliveryMethod switch
        {
            null => null,
            PurchaseOrderDeliveryMethod.Collection => Icon.PurchaseOrderDeliveryMethod.Collected,
            PurchaseOrderDeliveryMethod.Delivery => Icon.PurchaseOrderDeliveryMethod.Delivered,
            _ => throw MappingError(
                "purchaseOrderHeader.deliveryMethod",
                $"Unsupported delivery method value {(int)deliveryMethod.Value}.")
        };

    private static Icon.PurchaseOrderLine MapLine(PurchaseOrderLine line) => new()
    {
        Product = line.ProductId,
        Manufact = line.Manufacturer,
        Location = line.StockClass,
        ExtendedDescription = line.ProductDescription,
        Quantity = line.Quantity,
        Unit = line.Unit,
        DateExpected = FormatDate(line.DateExpected),
        SpecialInstructions = line.SpecialInstructions,
        InternalInstructions = line.InternalInstructions,
        Price = line.Pricing is null ? null : (decimal)line.Pricing.Price,
        PriceUnit = line.Pricing?.Unit,
        Tally = line.Tally.Count == 0
            ? null
            : new Icon.PurchaseOrderTally
            {
                TallyItem = line.Tally.Select(item => new Icon.PurchaseOrderTallyItem
                {
                    Quantity = item.Quantity,
                    Length = item.Length,
                    Width = item.Width
                }).ToList()
            }
    };

    private static string? FormatDate(DateOnly? date) =>
        date?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

    private static string PartyPath(PurchaseOrderPartyType type) =>
        type == PurchaseOrderPartyType.Supplier ? "supplier" : "invoice";

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value;

    private static PurchaseOrderIconMappingException MappingError(string path, string message) =>
        new(path, message);
}
