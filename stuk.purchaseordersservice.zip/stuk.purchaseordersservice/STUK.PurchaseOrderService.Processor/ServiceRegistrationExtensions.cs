using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.IconIntegration.DependencyInjection;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data;
using STUK.PurchaseOrderService.Processor.Email.Configuration;
using STUK.PurchaseOrderService.Processor.Email.Delivery;
using STUK.PurchaseOrderService.Processor.Email.Outbox;
using STUK.PurchaseOrderService.Processor.Email.Processing;
using STUK.PurchaseOrderService.Processor.Email.Relex;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;
using STUK.PurchaseOrderService.Processor.Mapping;
using STUK.PurchaseOrderService.Processor.Processing;
using STUK.PurchaseOrderService.Processor.Relex.Configuration;
using STUK.PurchaseOrderService.Processor.Relex.Files;
using STUK.PurchaseOrderService.Processor.Relex.Parsing;
using STUK.PurchaseOrderService.Processor.Relex.Processing;
using STUK.PurchaseOrderService.Processor.Services;

namespace STUK.PurchaseOrderService.Processor;

public static class ServiceRegistrationExtensions
{
    public static IServiceCollection AddPurchaseOrderProcessor(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddPurchaseOrderPersistence(configuration);

        var iconConfigurationBuilder = new ConfigurationBuilder()
            .AddConfiguration(configuration);

        services.Configure<CommonSettings>(configuration.GetSection(nameof(CommonSettings)));
        services.AddOptions<BatchProcessorSettings>()
            .Bind(configuration.GetSection(nameof(BatchProcessorSettings)))
            .Validate(
                settings => settings.LeaseDurationSeconds is > 0 and <= 3600,
                $"{nameof(BatchProcessorSettings.LeaseDurationSeconds)} must be between 1 and 3600 seconds.")
            .Validate(
                settings => settings.OutcomePersistenceTimeoutSeconds is > 0 and <= 300,
                $"{nameof(BatchProcessorSettings.OutcomePersistenceTimeoutSeconds)} must be between 1 and 300 seconds.");
        services.AddIconIntegration(iconConfigurationBuilder);
        services.AddScoped<IPurchaseOrderIconMapper, PurchaseOrderIconMapper>();
        services.AddScoped<IPurchaseOrderProcessor, PurchaseOrderProcessor>();
        services.AddScoped<IIconPurchaseOrderService, IconPurchaseOrderService>();

        services.AddSingleton<IValidateOptions<RelexIngestionSettings>,
            RelexIngestionSettingsValidator>();
        services.AddOptions<RelexIngestionSettings>()
            .Bind(configuration.GetSection(RelexIngestionSettings.SectionName))
            .ValidateOnStart();

        services.AddSingleton<IValidateOptions<EmailSenderSettings>,
            EmailSenderSettingsValidator>();
        services.AddOptions<EmailSenderSettings>()
            .Bind(configuration.GetSection(EmailSenderSettings.SectionName))
            .ValidateOnStart();
        services.AddSingleton<IValidateOptions<EmailNotificationScheduleSettings>,
            EmailNotificationScheduleSettingsValidator>();
        services.AddOptions<EmailNotificationScheduleSettings>()
            .Configure(settings => settings.CronExpression =
                configuration[ConfigConstants.EmailNotificationSenderCronExpressionSettingKey]
                ?? string.Empty)
            .ValidateOnStart();

        services.AddSingleton<IValidateOptions<RelexNotificationSettings>, RelexNotificationSettingsValidator>();
        services.AddOptions<RelexNotificationSettings>()
            .Bind(configuration.GetSection(RelexNotificationSettings.SectionName))
            .Configure(options => options.CronExpression = configuration[ConfigConstants.RelexNotificationProducerCronExpressionSettingKey]
                ?? "0 * * * * *")
            .ValidateOnStart();
        services.AddSingleton<RelexEmailComposer>();
        services.AddScoped<IRelexNotificationProducer, RelexNotificationProducer>();

        services.TryAddSingleton(TimeProvider.System);
        services.AddSingleton<IEmailEnvelopeSerializer, EmailEnvelopeSerializer>();
        services.AddSingleton<IEmailRequestSizeCalculator, AcsSmtpMessageSizeCalculator>();
        services.AddSingleton<IEmailEnvelopeValidator, EmailEnvelopeValidator>();
        services.AddSingleton<IEmailJitterProvider, SystemEmailJitterProvider>();
        services.AddSingleton<IEmailRetryDelayCalculator, EmailRetryDelayCalculator>();
        services.AddSingleton<AcsEmailMessageMapper>();
        services.AddSingleton<IAcsSmtpClient, AcsSmtpClient>();
        services.AddSingleton<IEmailDeliveryClient, AcsEmailDeliveryClient>();
        services.AddScoped<IEmailNotificationOutbox, EmailNotificationOutbox>();
        services.AddScoped<IEmailNotificationProcessor, EmailNotificationProcessor>();

        services.AddSingleton<IRelexPurchaseOrderSerializer,
            RelexPurchaseOrderSerializer>();
        services.AddSingleton<IRelexTemporaryFileFactory,
            RelexTemporaryFileFactory>();
        services.AddScoped<IRelexPurchaseOrderFileProcessor,
            RelexPurchaseOrderFileProcessor>();
        services.AddScoped<IRelexFileStore>(serviceProvider =>
        {
            var settings = serviceProvider
                .GetRequiredService<IOptions<RelexIngestionSettings>>()
                .Value;
            return settings.Provider switch
            {
                RelexFileStoreProvider.Local =>
                    new LocalRelexFileStore(settings.LocalRootPath!),
                RelexFileStoreProvider.Sftp =>
                    new SftpRelexFileStore(settings),
                _ => throw new InvalidOperationException(
                    "The configured Relex file store provider is not supported.")
            };
        });
        services.AddScoped<IRelexIngestionService>(serviceProvider =>
        {
            var settings = serviceProvider
                .GetRequiredService<IOptions<RelexIngestionSettings>>()
                .Value;
            return new RelexIngestionService(
                serviceProvider.GetRequiredService<IRelexFileStore>(),
                settings,
                serviceProvider.GetRequiredService<TimeProvider>(),
                serviceProvider.GetRequiredService<ILogger<RelexIngestionService>>(),
                serviceProvider.GetRequiredService<IRelexPurchaseOrderFileProcessor>(),
                serviceProvider.GetRequiredService<
                    Common.Data.Repositories.IPurchaseOrderBatchRepository>(),
                serviceProvider.GetRequiredService<IRelexPurchaseOrderSerializer>(),
                serviceProvider.GetRequiredService<IRelexTemporaryFileFactory>());
        });

        return services;
    }
}
