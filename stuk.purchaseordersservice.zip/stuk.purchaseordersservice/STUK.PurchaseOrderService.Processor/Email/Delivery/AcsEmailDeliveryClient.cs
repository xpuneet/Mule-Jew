using System.Net.Mail;
using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Delivery;

internal sealed class AcsEmailDeliveryClient : IEmailDeliveryClient
{
    private readonly AcsEmailMessageMapper _mapper;
    private readonly IAcsSmtpClient _smtpClient;
    private readonly ILogger<AcsEmailDeliveryClient> _logger;

    public AcsEmailDeliveryClient(
        AcsEmailMessageMapper mapper,
        IAcsSmtpClient smtpClient,
        ILogger<AcsEmailDeliveryClient> logger)
    {
        ArgumentNullException.ThrowIfNull(mapper);
        ArgumentNullException.ThrowIfNull(smtpClient);
        ArgumentNullException.ThrowIfNull(logger);

        _mapper = mapper;
        _smtpClient = smtpClient;
        _logger = logger;
    }

    public async Task<EmailDeliveryResult> SendAsync(
        EmailEnvelopeV1 envelope,
        CancellationToken cancellationToken = default)
    {
        try
        {
            using var message = _mapper.Map(envelope);
            await _smtpClient.SendAsync(message, cancellationToken);

            return new EmailDeliveryResult(
                EmailDeliveryOutcome.Succeeded,
                null,
                null,
                null,
                null,
                null,
                null);
        }
        catch (SmtpException exception)
        {
            return LogAndReturn(
                envelope.NotificationId,
                ClassifySmtpFailure(exception));
        }
        catch (AcsEmailPayloadIntegrityException)
        {
            return LogAndReturn(
                envelope.NotificationId,
                Failure(
                    EmailDeliveryOutcome.PermanentFailure,
                    "INTEGRITY",
                    "EMAIL_ATTACHMENT_CONTENT_INVALID",
                    "The persisted email attachment content is invalid."));
        }
        catch (ArgumentException)
        {
            return LogAndReturn(
                envelope.NotificationId,
                Failure(
                    EmailDeliveryOutcome.PermanentFailure,
                    "VALIDATION",
                    "EMAIL_ENVELOPE_INVALID",
                    "The persisted email envelope is invalid."));
        }
    }

    private static EmailDeliveryResult ClassifySmtpFailure(SmtpException exception)
    {
        if (exception is SmtpFailedRecipientsException
            {
                InnerExceptions.Length: > 0
            } failedRecipients)
        {
            var allPermanent = true;
            foreach (var failedRecipient in failedRecipients.InnerExceptions)
            {
                var recipientStatus = (int)failedRecipient.StatusCode;
                if (recipientStatus is < 500 or > 599)
                {
                    allPermanent = false;
                    break;
                }
            }

            return allPermanent
                ? Failure(
                    EmailDeliveryOutcome.PermanentFailure,
                    "PROVIDER",
                    "ACS_SMTP_RECIPIENTS_REJECTED",
                    "ACS SMTP permanently rejected all failed recipients.")
                : Failure(
                    EmailDeliveryOutcome.TransientFailure,
                    "TRANSPORT",
                    "ACS_SMTP_RECIPIENTS_RETRYABLE",
                    "ACS SMTP reported at least one retryable or unclassified recipient failure.");
        }

        return ClassifySmtpStatus(exception.StatusCode);
    }

    private static EmailDeliveryResult ClassifySmtpStatus(SmtpStatusCode statusCode)
    {
        var numericStatus = (int)statusCode;
        if (numericStatus is >= 500 and <= 599)
        {
            return Failure(
                EmailDeliveryOutcome.PermanentFailure,
                "PROVIDER",
                $"ACS_SMTP_{numericStatus}",
                "ACS SMTP permanently rejected the email message.");
        }

        if (numericStatus is >= 400 and <= 499)
        {
            return Failure(
                EmailDeliveryOutcome.TransientFailure,
                "TRANSPORT",
                $"ACS_SMTP_{numericStatus}",
                "ACS SMTP temporarily rejected the email message.");
        }

        return Failure(
            EmailDeliveryOutcome.TransientFailure,
            "TRANSPORT",
            "ACS_SMTP_ERROR",
            "The ACS SMTP send attempt failed without a classified status.");
    }

    private EmailDeliveryResult LogAndReturn(
        Guid notificationId,
        EmailDeliveryResult result)
    {
        _logger.LogWarning(
            "ACS email delivery did not succeed. NotificationId={NotificationId}, "
            + "Outcome={Outcome}, Category={FailureCategory}, Code={FailureCode}.",
            notificationId,
            result.Outcome,
            result.FailureCategory,
            result.FailureCode);
        return result;
    }

    private static EmailDeliveryResult Failure(
        EmailDeliveryOutcome outcome,
        string category,
        string code,
        string description) => new(
        outcome,
        null,
        null,
        null,
        category,
        code,
        description);
}
