using System.Net.Mail;
using System.Net.Mime;
using System.Security.Cryptography;
using System.Text;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.Processor.Email.Delivery;

internal sealed class AcsEmailMessageMapper
{
    private readonly IEmailEnvelopeValidator _validator;

    public AcsEmailMessageMapper(IEmailEnvelopeValidator validator)
    {
        ArgumentNullException.ThrowIfNull(validator);
        _validator = validator;
    }

    public MailMessage Map(EmailEnvelopeV1 envelope)
    {
        ValidateAttachmentIntegrity(envelope);
        _validator.Validate(envelope);

        var message = new MailMessage
        {
            From = MapMailbox(new EmailMailbox(envelope.SenderAddress, null)),
            Subject = envelope.Subject,
            SubjectEncoding = Encoding.UTF8,
            BodyEncoding = Encoding.UTF8
        };

        try
        {
            AddMailboxes(message.To, envelope.To);
            AddMailboxes(message.CC, envelope.Cc);
            AddMailboxes(message.Bcc, envelope.Bcc);
            AddMailboxes(message.ReplyToList, envelope.ReplyTo);
            AddBody(message, envelope);
            AddAttachments(message, envelope.Attachments);
            return message;
        }
        catch
        {
            message.Dispose();
            throw;
        }
    }

    private static void AddMailboxes(
        MailAddressCollection destination,
        IEnumerable<EmailMailbox> mailboxes)
    {
        foreach (var mailbox in mailboxes)
        {
            destination.Add(MapMailbox(mailbox));
        }
    }

    private static void AddBody(MailMessage message, EmailEnvelopeV1 envelope)
    {
        if (envelope.PlainTextBody is not null)
        {
            message.Body = envelope.PlainTextBody;
            message.IsBodyHtml = false;
            if (envelope.HtmlBody is not null)
            {
                message.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(
                    envelope.HtmlBody,
                    Encoding.UTF8,
                    MediaTypeNames.Text.Html));
            }

            return;
        }

        message.Body = envelope.HtmlBody ?? string.Empty;
        message.IsBodyHtml = envelope.HtmlBody is not null;
    }

    private static void AddAttachments(
        MailMessage message,
        IEnumerable<EmailAttachmentV1> attachments)
    {
        foreach (var attachment in attachments)
        {
            var content = new MemoryStream(
                Convert.FromBase64String(attachment.Base64Content),
                writable: false);
            try
            {
                message.Attachments.Add(new Attachment(
                    content,
                    attachment.FileName,
                    attachment.ContentType));
            }
            catch
            {
                content.Dispose();
                throw;
            }
        }
    }

    private static MailAddress MapMailbox(EmailMailbox mailbox) =>
        new(mailbox.Address, mailbox.DisplayName, Encoding.UTF8);

    private static void ValidateAttachmentIntegrity(EmailEnvelopeV1 envelope)
    {
        ArgumentNullException.ThrowIfNull(envelope);

        foreach (var attachment in envelope.Attachments)
        {
            if (attachment is null || string.IsNullOrWhiteSpace(attachment.Sha256))
            {
                continue;
            }

            byte[] content;
            try
            {
                content = Convert.FromBase64String(attachment.Base64Content);
            }
            catch (FormatException exception)
            {
                throw new AcsEmailPayloadIntegrityException(exception);
            }

            if (attachment.Sha256.Length != 64
                || attachment.Sha256.Any(character =>
                    !char.IsAsciiHexDigit(character) || char.IsUpper(character)))
            {
                continue;
            }

            var actualHash = SHA256.HashData(content);
            var expectedHash = Convert.FromHexString(attachment.Sha256);
            if (!CryptographicOperations.FixedTimeEquals(actualHash, expectedHash))
            {
                throw new AcsEmailPayloadIntegrityException();
            }
        }
    }
}

internal sealed class AcsEmailPayloadIntegrityException : Exception
{
    public AcsEmailPayloadIntegrityException()
        : base("The persisted email attachment content failed its integrity check.")
    {
    }

    public AcsEmailPayloadIntegrityException(Exception innerException)
        : base("The persisted email attachment content failed its integrity check.", innerException)
    {
    }
}
