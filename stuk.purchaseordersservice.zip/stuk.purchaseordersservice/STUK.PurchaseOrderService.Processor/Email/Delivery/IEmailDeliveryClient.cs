using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Delivery;

public interface IEmailDeliveryClient
{
    Task<EmailDeliveryResult> SendAsync(
        EmailEnvelopeV1 envelope,
        CancellationToken cancellationToken = default);
}
