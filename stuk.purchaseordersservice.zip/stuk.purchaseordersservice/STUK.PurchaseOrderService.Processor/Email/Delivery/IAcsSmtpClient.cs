using System.Net.Mail;

namespace STUK.PurchaseOrderService.Processor.Email.Delivery;

internal interface IAcsSmtpClient
{
    Task SendAsync(MailMessage message, CancellationToken cancellationToken);
}
