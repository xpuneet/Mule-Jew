namespace STUK.PurchaseOrderService.Processor.Email.Delivery;

public enum EmailDeliveryOutcome
{
    Succeeded,
    TransientFailure,
    Throttled,
    PermanentFailure
}

public sealed record EmailDeliveryResult(
    EmailDeliveryOutcome Outcome,
    string? ProviderMessageId,
    short? HttpStatusCode,
    TimeSpan? RetryAfter,
    string? FailureCategory,
    string? FailureCode,
    string? FailureDescription);
