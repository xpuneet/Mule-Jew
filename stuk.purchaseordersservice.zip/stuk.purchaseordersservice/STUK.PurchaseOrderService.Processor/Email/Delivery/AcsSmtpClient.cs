using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Email.Delivery;

internal sealed class AcsSmtpClient : IAcsSmtpClient
{
    private readonly EmailSmtpSettings _settings;
    private readonly Func<SmtpClient> _clientFactory;
    private readonly Func<SmtpClient, MailMessage, CancellationToken, Task> _sendAsync;

    public AcsSmtpClient(IOptions<EmailSenderSettings> settings)
        : this(
            settings,
            static () => new SmtpClient(),
            static (client, message, cancellationToken) =>
                client.SendMailAsync(message, cancellationToken))
    {
    }

    internal AcsSmtpClient(
        IOptions<EmailSenderSettings> settings,
        Func<SmtpClient> clientFactory,
        Func<SmtpClient, MailMessage, CancellationToken, Task> sendAsync)
    {
        ArgumentNullException.ThrowIfNull(settings);
        ArgumentNullException.ThrowIfNull(clientFactory);
        ArgumentNullException.ThrowIfNull(sendAsync);

        _settings = settings.Value.Smtp;
        _clientFactory = clientFactory;
        _sendAsync = sendAsync;
    }

    public async Task SendAsync(
        MailMessage message,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(message);

        using var client = _clientFactory();
        client.Host = _settings.Host;
        client.Port = _settings.Port;
        client.EnableSsl = _settings.UseStartTls;
        client.UseDefaultCredentials = false;
        client.Credentials = new NetworkCredential(
            _settings.Username,
            _settings.Password);

        await _sendAsync(client, message, cancellationToken);
    }
}
