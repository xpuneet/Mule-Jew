using Microsoft.Extensions.Options;
using NCrontab;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Email.Configuration;

public sealed class EmailNotificationScheduleSettingsValidator
    : IValidateOptions<EmailNotificationScheduleSettings>
{
    public ValidateOptionsResult Validate(
        string? name,
        EmailNotificationScheduleSettings options)
    {
        CrontabSchedule? schedule;
        try
        {
            schedule = CrontabSchedule.TryParse(
                options.CronExpression,
                new CrontabSchedule.ParseOptions { IncludingSeconds = true });
        }
        catch (CrontabException)
        {
            schedule = null;
        }

        return schedule is null
            ? ValidateOptionsResult.Fail(
                "EmailNotificationSenderCronExpression must be a valid six-field NCRONTAB expression.")
            : ValidateOptionsResult.Success;
    }
}
