using System.Net.Mail;
using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Email.Configuration;

public sealed class EmailSenderSettingsValidator : IValidateOptions<EmailSenderSettings>
{
    private const string AcsSmtpHost = "smtp.azurecomm.net";
    private const int AcsSmtpSubmissionPort = 587;

    public ValidateOptionsResult Validate(string? name, EmailSenderSettings options)
    {
        if (!options.SendingEnabled)
        {
            return ValidateOptionsResult.Success;
        }

        var failures = new List<string>();
        if (options.Smtp is null
            || !string.Equals(
                options.Smtp.Host,
                AcsSmtpHost,
                StringComparison.OrdinalIgnoreCase))
        {
            failures.Add($"EmailSender:Smtp:Host must be {AcsSmtpHost}.");
        }

        if (options.Smtp is null || options.Smtp.Port != AcsSmtpSubmissionPort)
        {
            failures.Add($"EmailSender:Smtp:Port must be {AcsSmtpSubmissionPort}.");
        }

        if (options.Smtp is null || !options.Smtp.UseStartTls)
        {
            failures.Add("EmailSender:Smtp:UseStartTls must be enabled.");
        }

        if (options.Smtp is null || string.IsNullOrWhiteSpace(options.Smtp.Username))
        {
            failures.Add("EmailSender:Smtp:Username must be provided.");
        }

        if (options.Smtp is null || string.IsNullOrWhiteSpace(options.Smtp.Password))
        {
            failures.Add("EmailSender:Smtp:Password must be provided.");
        }

        if (!IsCanonicalAddress(options.DefaultSenderAddress))
        {
            failures.Add("EmailSender:DefaultSenderAddress must be a valid email address.");
        }

        if (options.ClaimBatchSize is < 1 or > 100)
        {
            failures.Add("EmailSender:ClaimBatchSize must be between 1 and 100.");
        }

        if (options.MaxConcurrency is < 1 or > 20)
        {
            failures.Add("EmailSender:MaxConcurrency must be between 1 and 20.");
        }

        if (options.MaxFailureCount is < 1 or > 20)
        {
            failures.Add("EmailSender:MaxFailureCount must be between 1 and 20.");
        }

        if (options.RateLimit is null
            || options.RateLimit.MaxAttemptsPerMinute <= 0
            || options.RateLimit.MaxAttemptsPerHour <= 0)
        {
            failures.Add("EmailSender rate limits must both be positive.");
        }

        ValidateDurations(options, failures);

        return failures.Count == 0
            ? ValidateOptionsResult.Success
            : ValidateOptionsResult.Fail(failures);
    }

    private static void ValidateDurations(
        EmailSenderSettings options,
        ICollection<string> failures)
    {
        if (options.ProviderOperationTimeoutSeconds <= 0
            || options.CompletionSafetyMarginSeconds <= 0
            || options.OutcomePersistenceTimeoutSeconds <= 0)
        {
            failures.Add("EmailSender provider, margin, and persistence durations must be positive.");
        }

        var providerAndMargin = (long)options.ProviderOperationTimeoutSeconds
            + options.CompletionSafetyMarginSeconds;
        if (options.LeaseDurationSeconds <= providerAndMargin)
        {
            failures.Add(
                "EmailSender:LeaseDurationSeconds must exceed provider timeout plus completion margin.");
        }

        if (options.MaxRunDurationSeconds <= providerAndMargin)
        {
            failures.Add(
                "EmailSender:MaxRunDurationSeconds must exceed provider timeout plus completion margin.");
        }

        if (options.OutcomePersistenceTimeoutSeconds > options.CompletionSafetyMarginSeconds)
        {
            failures.Add(
                "EmailSender:OutcomePersistenceTimeoutSeconds must not exceed the completion margin.");
        }

        if (options.InitialRetryDelaySeconds is < 0 or > 3600
            || options.MaxRetryDelaySeconds is < 0 or > 3600
            || options.RetryJitterSeconds is < 0 or > 3600
            || options.ThrottleFallbackDelaySeconds is < 0 or > 3600)
        {
            failures.Add("EmailSender retry and throttle delays must be between 0 and 3600 seconds.");
        }

        if (options.InitialRetryDelaySeconds > options.MaxRetryDelaySeconds)
        {
            failures.Add(
                "EmailSender:InitialRetryDelaySeconds must not exceed MaxRetryDelaySeconds.");
        }
    }

    private static bool IsCanonicalAddress(string? address) =>
        !string.IsNullOrWhiteSpace(address)
        && MailAddress.TryCreate(address, out var parsedAddress)
        && string.Equals(parsedAddress.Address, address, StringComparison.Ordinal);
}
