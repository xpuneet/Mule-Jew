using System.Text;
using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Validation;

public sealed class AcsSmtpMessageSizeCalculator : IEmailRequestSizeCalculator
{
    // System.Net.Mail Base64-encodes the UTF-8 body and MIME attachments. This calculator
    // deliberately estimates an upper bound without materialising the encoded message.
    private const int ConservativeBase64LineLength = 64;
    private const int CrLfByteCount = 2;
    private const int FixedMessageOverhead = 8 * 1024;
    private const int MailboxOverhead = 512;
    private const int MimePartOverhead = 1024;

    public long CalculateUpperBoundByteCount(EmailEnvelopeV1 envelope)
    {
        ArgumentNullException.ThrowIfNull(envelope);

        var byteCount = (long)FixedMessageOverhead;
        byteCount += EstimateHeaderText(envelope.SenderAddress);
        byteCount += EstimateHeaderText(envelope.Subject);

        byteCount += EstimateMailboxes(envelope.To);
        byteCount += EstimateMailboxes(envelope.Cc);
        byteCount += EstimateMailboxes(envelope.Bcc);
        byteCount += EstimateMailboxes(envelope.ReplyTo);

        if (envelope.PlainTextBody is not null)
        {
            byteCount += MimePartOverhead;
            byteCount += EstimateWrappedBase64FromSourceByteCount(
                Encoding.UTF8.GetByteCount(envelope.PlainTextBody));
        }

        if (envelope.HtmlBody is not null)
        {
            byteCount += MimePartOverhead;
            byteCount += EstimateWrappedBase64FromSourceByteCount(
                Encoding.UTF8.GetByteCount(envelope.HtmlBody));
        }

        foreach (var attachment in envelope.Attachments)
        {
            byteCount += MimePartOverhead;
            byteCount += EstimateHeaderText(attachment.FileName);
            byteCount += EstimateHeaderText(attachment.ContentType);
            byteCount += EstimateWrappedBase64CharacterCount(attachment.Base64Content.Length);
        }

        return byteCount;
    }

    private static long EstimateMailboxes(IReadOnlyList<EmailMailbox> mailboxes)
    {
        var byteCount = 0L;
        foreach (var mailbox in mailboxes)
        {
            byteCount += MailboxOverhead;
            byteCount += EstimateHeaderText(mailbox.Address);
            byteCount += EstimateHeaderText(mailbox.DisplayName);
        }

        return byteCount;
    }

    private static long EstimateHeaderText(string? value) => value is null
        ? 0
        : (long)Encoding.UTF8.GetByteCount(value) * 4;

    private static long EstimateWrappedBase64FromSourceByteCount(long sourceByteCount)
    {
        var encodedCharacterCount = ((sourceByteCount + 2) / 3) * 4;
        return EstimateWrappedBase64CharacterCount(encodedCharacterCount);
    }

    private static long EstimateWrappedBase64CharacterCount(long encodedCharacterCount)
    {
        if (encodedCharacterCount == 0)
        {
            return CrLfByteCount;
        }

        var lineCount =
            (encodedCharacterCount + ConservativeBase64LineLength - 1)
            / ConservativeBase64LineLength;
        return encodedCharacterCount + (lineCount * CrLfByteCount);
    }
}
