using System.Net.Mail;
using System.Net.Mime;
using System.Security.Cryptography;
using System.Text;
using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Validation;

public sealed class EmailEnvelopeValidator(IEmailRequestSizeCalculator requestSizeCalculator)
    : IEmailEnvelopeValidator
{
    private const int SupportedSchemaVersion = 1;
    private const int MaximumRecipientCount = 50;
    private const int MaximumSmtpMessageSize = 10_000_000;

    public void Validate(EmailEnvelopeV1 envelope)
    {
        ArgumentNullException.ThrowIfNull(envelope);

        if (envelope.SchemaVersion != SupportedSchemaVersion)
        {
            throw new ArgumentException("The email envelope schema version is not supported.");
        }

        if (envelope.NotificationId == Guid.Empty)
        {
            throw new ArgumentException("The email notification ID must not be empty.");
        }

        RequireText(envelope.BusinessCorrelationId, "business correlation ID");
        RequireCanonicalAddress(envelope.SenderAddress, "sender address");
        RequireText(envelope.Subject, "subject");

        if (string.IsNullOrWhiteSpace(envelope.HtmlBody)
            && string.IsNullOrWhiteSpace(envelope.PlainTextBody))
        {
            throw new ArgumentException("The email envelope requires HTML or plain-text content.");
        }

        var to = RequireCollection(envelope.To, "to");
        var cc = RequireCollection(envelope.Cc, "cc");
        var bcc = RequireCollection(envelope.Bcc, "bcc");
        var replyTo = RequireCollection(envelope.ReplyTo, "reply-to");
        var recipientCount = to.Count + cc.Count + bcc.Count;
        if (recipientCount is < 1 or > MaximumRecipientCount)
        {
            throw new ArgumentException(
                $"The email envelope must contain between 1 and {MaximumRecipientCount} recipients.");
        }

        ValidateMailboxes(to, "to");
        ValidateMailboxes(cc, "cc");
        ValidateMailboxes(bcc, "bcc");
        ValidateMailboxes(replyTo, "reply-to");

        foreach (var attachment in RequireCollection(envelope.Attachments, "attachments"))
        {
            ValidateAttachment(attachment);
        }

        if (requestSizeCalculator.CalculateUpperBoundByteCount(envelope)
            > MaximumSmtpMessageSize)
        {
            throw new ArgumentException("The SMTP MIME message exceeds 10 MB.");
        }
    }

    private static void ValidateMailboxes(
        IReadOnlyList<EmailMailbox> mailboxes,
        string collectionName)
    {
        foreach (var mailbox in mailboxes)
        {
            if (mailbox is null)
            {
                throw new ArgumentException(
                    $"The email envelope {collectionName} collection contains a null mailbox.");
            }

            RequireCanonicalAddress(mailbox.Address, $"{collectionName} address");
        }
    }

    private static void ValidateAttachment(EmailAttachmentV1 attachment)
    {
        if (attachment is null)
        {
            throw new ArgumentException("The email envelope contains a null attachment.");
        }

        RequireText(attachment.FileName, "attachment file name");
        RequireText(attachment.ContentType, "attachment content type");
        try
        {
            _ = new ContentType(attachment.ContentType);
        }
        catch (FormatException exception)
        {
            throw new ArgumentException(
                "The attachment content type is not a valid MIME content type.",
                nameof(attachment),
                exception);
        }

        if (string.IsNullOrWhiteSpace(attachment.Sha256)
            || attachment.Sha256.Length != 64
            || attachment.Sha256.Any(character =>
                !char.IsAsciiHexDigit(character) || char.IsUpper(character)))
        {
            throw new ArgumentException(
                "The attachment SHA-256 must be 64 lowercase hexadecimal characters.");
        }

        byte[] content;
        try
        {
            content = Convert.FromBase64String(attachment.Base64Content);
        }
        catch (FormatException exception)
        {
            throw new ArgumentException(
                "The attachment content is not valid Base64.",
                nameof(attachment),
                exception);
        }

        var actualHash = SHA256.HashData(content);
        var actualLowercaseHex = Convert.ToHexString(actualHash).ToLowerInvariant();
        var actualHashBytes = Encoding.ASCII.GetBytes(actualLowercaseHex);
        var expectedHashBytes = Encoding.ASCII.GetBytes(attachment.Sha256);
        if (!CryptographicOperations.FixedTimeEquals(actualHashBytes, expectedHashBytes))
        {
            throw new ArgumentException("The attachment SHA-256 does not match its content.");
        }
    }

    private static IReadOnlyList<T> RequireCollection<T>(
        IReadOnlyList<T>? collection,
        string collectionName) => collection ?? throw new ArgumentException(
        $"The email envelope {collectionName} collection must not be null.");

    private static void RequireText(string? value, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException($"The email envelope {fieldName} must not be blank.");
        }
    }

    private static void RequireCanonicalAddress(string? address, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(address)
            || !MailAddress.TryCreate(address, out var parsedAddress)
            || !string.Equals(parsedAddress.Address, address, StringComparison.Ordinal))
        {
            throw new ArgumentException(
                $"The email envelope {fieldName} must be a valid canonical email address.");
        }
    }
}
