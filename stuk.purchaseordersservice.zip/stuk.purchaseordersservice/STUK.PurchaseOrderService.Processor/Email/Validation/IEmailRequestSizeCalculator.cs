using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Validation;

public interface IEmailRequestSizeCalculator
{
    long CalculateUpperBoundByteCount(EmailEnvelopeV1 envelope);
}
