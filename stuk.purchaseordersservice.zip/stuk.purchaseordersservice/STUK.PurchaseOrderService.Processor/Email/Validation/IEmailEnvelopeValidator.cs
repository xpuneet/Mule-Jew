using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Validation;

public interface IEmailEnvelopeValidator
{
    void Validate(EmailEnvelopeV1 envelope);
}
