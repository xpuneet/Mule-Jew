namespace STUK.PurchaseOrderService.Processor.Email.Contracts;

public sealed record EmailMailbox(string Address, string? DisplayName);

public sealed record EmailAttachmentV1(
    string FileName,
    string ContentType,
    string Sha256,
    string Base64Content);

public sealed record EmailEnvelopeV1
{
    public EmailEnvelopeV1(
        int SchemaVersion,
        Guid NotificationId,
        string BusinessCorrelationId,
        string SenderAddress,
        IReadOnlyList<EmailMailbox> To,
        IReadOnlyList<EmailMailbox> Cc,
        IReadOnlyList<EmailMailbox> Bcc,
        IReadOnlyList<EmailMailbox> ReplyTo,
        string Subject,
        string? HtmlBody,
        string? PlainTextBody,
        IReadOnlyList<EmailAttachmentV1> Attachments)
    {
        this.SchemaVersion = SchemaVersion;
        this.NotificationId = NotificationId;
        this.BusinessCorrelationId = BusinessCorrelationId;
        this.SenderAddress = SenderAddress;
        this.To = To;
        this.Cc = Cc;
        this.Bcc = Bcc;
        this.ReplyTo = ReplyTo;
        this.Subject = Subject;
        this.HtmlBody = HtmlBody;
        this.PlainTextBody = PlainTextBody;
        this.Attachments = Attachments;
    }

    public int SchemaVersion { get; init; }
    public Guid NotificationId { get; init; }
    public string BusinessCorrelationId { get; init; }
    public string SenderAddress { get; init; }
    public IReadOnlyList<EmailMailbox> To
    {
        get => _to;
        init => _to = Freeze(value, nameof(To));
    }

    public IReadOnlyList<EmailMailbox> Cc
    {
        get => _cc;
        init => _cc = Freeze(value, nameof(Cc));
    }

    public IReadOnlyList<EmailMailbox> Bcc
    {
        get => _bcc;
        init => _bcc = Freeze(value, nameof(Bcc));
    }

    public IReadOnlyList<EmailMailbox> ReplyTo
    {
        get => _replyTo;
        init => _replyTo = Freeze(value, nameof(ReplyTo));
    }

    public string Subject { get; init; }
    public string? HtmlBody { get; init; }
    public string? PlainTextBody { get; init; }
    public IReadOnlyList<EmailAttachmentV1> Attachments
    {
        get => _attachments;
        init => _attachments = Freeze(value, nameof(Attachments));
    }

    private IReadOnlyList<EmailMailbox> _to = Array.Empty<EmailMailbox>();
    private IReadOnlyList<EmailMailbox> _cc = Array.Empty<EmailMailbox>();
    private IReadOnlyList<EmailMailbox> _bcc = Array.Empty<EmailMailbox>();
    private IReadOnlyList<EmailMailbox> _replyTo = Array.Empty<EmailMailbox>();
    private IReadOnlyList<EmailAttachmentV1> _attachments =
        Array.Empty<EmailAttachmentV1>();

    private static IReadOnlyList<T> Freeze<T>(IReadOnlyList<T> value, string parameterName)
    {
        ArgumentNullException.ThrowIfNull(value, parameterName);
        return Array.AsReadOnly(value.ToArray());
    }
}
