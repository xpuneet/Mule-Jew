namespace STUK.PurchaseOrderService.Processor.Email.Contracts;

public sealed record EmailNotificationRequest(
    Guid NotificationId,
    string BusinessCorrelationId,
    IReadOnlyList<EmailMailbox> To,
    IReadOnlyList<EmailMailbox> Cc,
    IReadOnlyList<EmailMailbox> Bcc,
    IReadOnlyList<EmailMailbox> ReplyTo,
    string Subject,
    string? HtmlBody,
    string? PlainTextBody,
    IReadOnlyList<EmailAttachmentV1> Attachments);

public sealed record EmailNotificationMetadata(
    Guid? BatchId,
    string EventType,
    string? TemplateKey,
    string? RecipientGroupKey,
    string? AttachmentBlobName,
    DateTimeOffset CreatedDateTime);
