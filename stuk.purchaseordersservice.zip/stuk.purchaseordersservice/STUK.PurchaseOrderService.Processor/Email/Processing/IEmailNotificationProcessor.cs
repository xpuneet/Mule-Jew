namespace STUK.PurchaseOrderService.Processor.Email.Processing;

public interface IEmailNotificationProcessor
{
    Task<EmailNotificationRunResult> ProcessAsync(
        CancellationToken cancellationToken = default);
}
