namespace STUK.PurchaseOrderService.Processor.Email.Processing;

public interface IEmailRetryDelayCalculator
{
    TimeSpan Calculate(int nextFailureCount);
}
