using STUK.PurchaseOrderService.Common.Data.Repositories.Models;

namespace STUK.PurchaseOrderService.Processor.Email.Processing;

public sealed record EmailNotificationRunResult(
    int ClaimedCount,
    int SentCount,
    int RescheduledCount,
    int FailedCount,
    int ThrottledCount,
    int DeferredCount,
    PurchaseOrderEmailNotificationQueueSummary QueueSummary);
