using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Delivery;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.Processor.Email.Processing;

public sealed class EmailNotificationProcessor(
    IPurchaseOrderNotificationRepository repository,
    IEmailEnvelopeSerializer serializer,
    IEmailEnvelopeValidator validator,
    IEmailDeliveryClient deliveryClient,
    IEmailRetryDelayCalculator retryDelay,
    IOptionsMonitor<EmailSenderSettings> settings,
    TimeProvider timeProvider,
    ILogger<EmailNotificationProcessor> logger) : IEmailNotificationProcessor
{
    private static readonly DateTimeOffset MaximumSqlDateTimeUtc = new(
        9999,
        12,
        31,
        23,
        59,
        59,
        999,
        TimeSpan.Zero);

    private static readonly PurchaseOrderEmailNotificationQueueSummary EmptyQueueSummary = new(
        0,
        null,
        0,
        0,
        0,
        0,
        0);

    public async Task<EmailNotificationRunResult> ProcessAsync(
        CancellationToken cancellationToken = default)
    {
        var currentSettings = settings.CurrentValue;
        if (!currentSettings.SendingEnabled)
        {
            return new EmailNotificationRunResult(
                0,
                0,
                0,
                0,
                0,
                0,
                EmptyQueueSummary);
        }

        var runStartedAt = timeProvider.GetUtcNow();
        var runDeadline = runStartedAt.AddSeconds(currentSettings.MaxRunDurationSeconds);
        var requiredSafeTime = TimeSpan.FromSeconds(
            (long)currentSettings.ProviderOperationTimeoutSeconds
            + currentSettings.CompletionSafetyMarginSeconds);
        var counters = new RunCounters();
        var stopClaiming = 0;

        while (Volatile.Read(ref stopClaiming) == 0)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var claimTime = timeProvider.GetUtcNow();
            if (!HasSafeTime(runDeadline, claimTime, requiredSafeTime))
            {
                break;
            }

            var claimedNotifications = await repository.ClaimDueEmailNotificationsAsync(
                new ClaimPurchaseOrderEmailNotificationsCommand(
                    claimTime,
                    currentSettings.LeaseDurationSeconds,
                    Math.Min(
                        currentSettings.ClaimBatchSize,
                        currentSettings.MaxConcurrency),
                    currentSettings.RateLimit.MaxAttemptsPerMinute,
                    currentSettings.RateLimit.MaxAttemptsPerHour),
                cancellationToken);
            if (claimedNotifications.Count == 0)
            {
                break;
            }

            Interlocked.Add(ref counters.ClaimedCount, claimedNotifications.Count);
            await Parallel.ForEachAsync(
                claimedNotifications,
                new ParallelOptions
                {
                    CancellationToken = cancellationToken,
                    MaxDegreeOfParallelism = currentSettings.MaxConcurrency
                },
                async (claimed, _) => await ProcessClaimedAsync(
                    claimed,
                    currentSettings,
                    runDeadline,
                    requiredSafeTime,
                    counters,
                    () => Interlocked.Exchange(ref stopClaiming, 1),
                    cancellationToken));
        }

        var summaryTime = timeProvider.GetUtcNow();
        var queueSummary = await repository.GetEmailNotificationQueueSummaryAsync(
            new GetPurchaseOrderEmailNotificationQueueSummaryQuery(
                summaryTime,
                summaryTime.AddHours(-1)),
            cancellationToken);
        var result = new EmailNotificationRunResult(
            counters.ClaimedCount,
            counters.SentCount,
            counters.RescheduledCount,
            counters.FailedCount,
            counters.ThrottledCount,
            counters.DeferredCount,
            queueSummary);
        var oldestPendingAgeSeconds = queueSummary.OldestClaimablePendingDateTime is { } oldest
            ? Math.Max(0, (long)(summaryTime - oldest).TotalSeconds)
            : (long?)null;

        logger.LogInformation(
            "Email notification processing completed. Claimed={ClaimedCount}, Sent={SentCount}, Rescheduled={RescheduledCount}, Failed={FailedCount}, Throttled={ThrottledCount}, Deferred={DeferredCount}, ClaimablePending={ClaimablePendingCount}, DelayedPending={DelayedPendingCount}, Sending={ActiveLeasedCount}, ExpiredLeases={ExpiredLeasedCount}, LegacyUnsendable={UnsendableLegacyPendingCount}, RecentTerminalFailures={TerminalFailureCount}, OldestPendingAt={OldestClaimablePendingDateTime}, OldestPendingAgeSeconds={OldestClaimablePendingAgeSeconds}.",
            result.ClaimedCount,
            result.SentCount,
            result.RescheduledCount,
            result.FailedCount,
            result.ThrottledCount,
            result.DeferredCount,
            queueSummary.ClaimablePendingCount,
            queueSummary.DelayedPendingCount,
            queueSummary.ActiveLeasedCount,
            queueSummary.ExpiredLeasedCount,
            queueSummary.UnsendableLegacyPendingCount,
            queueSummary.TerminalFailureCount,
            queueSummary.OldestClaimablePendingDateTime,
            oldestPendingAgeSeconds);
        return result;
    }

    private async Task ProcessClaimedAsync(
        ClaimedPurchaseOrderEmailNotification claimed,
        EmailSenderSettings currentSettings,
        DateTimeOffset runDeadline,
        TimeSpan requiredSafeTime,
        RunCounters counters,
        Action stopClaiming,
        CancellationToken hostCancellationToken)
    {
        var (envelope, localFailure) = ReadEnvelope(claimed);
        if (localFailure is not null)
        {
            await PersistDeliveryAsync(
                claimed,
                localFailure,
                currentSettings,
                counters);
            return;
        }

        var providerStartTime = timeProvider.GetUtcNow();
        if (!HasSafeTime(runDeadline, providerStartTime, requiredSafeTime)
            || !HasSafeTime(
                claimed.LeaseExpiresDateTime,
                providerStartTime,
                requiredSafeTime))
        {
            stopClaiming();
            using var persistenceSource = CreatePersistenceSource(currentSettings);
            await repository.DeferEmailNotificationAsync(
                new DeferPurchaseOrderEmailNotificationCommand(
                    claimed.NotificationId,
                    claimed.LeaseId,
                    providerStartTime,
                    providerStartTime,
                    claimed.RowVersion),
                persistenceSource.Token);
            Interlocked.Increment(ref counters.DeferredCount);
            return;
        }

        EmailDeliveryResult delivery;
        using (var providerSource = CancellationTokenSource.CreateLinkedTokenSource(
                   hostCancellationToken))
        {
            providerSource.CancelAfter(TimeSpan.FromSeconds(
                currentSettings.ProviderOperationTimeoutSeconds));
            try
            {
                delivery = await deliveryClient.SendAsync(
                    envelope!,
                    providerSource.Token);
            }
            catch (OperationCanceledException) when (
                hostCancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (OperationCanceledException) when (
                providerSource.IsCancellationRequested)
            {
                delivery = new EmailDeliveryResult(
                    EmailDeliveryOutcome.TransientFailure,
                    null,
                    null,
                    null,
                    "TRANSPORT",
                    "PROVIDER_TIMEOUT",
                    "The email provider operation timed out.");
            }
        }

        await PersistDeliveryAsync(
            claimed,
            delivery,
            currentSettings,
            counters);
    }

    private (EmailEnvelopeV1? Envelope, EmailDeliveryResult? Failure) ReadEnvelope(
        ClaimedPurchaseOrderEmailNotification claimed)
    {
        var actualHash = SHA256.HashData(
            Encoding.Unicode.GetBytes(claimed.EmailEnvelopeJson));
        if (claimed.PayloadSha256.Length != actualHash.Length
            || !CryptographicOperations.FixedTimeEquals(
                claimed.PayloadSha256,
                actualHash))
        {
            return (null, PermanentLocalFailure(
                "INTEGRITY",
                "PAYLOAD_HASH_MISMATCH",
                "The persisted email payload hash did not match."));
        }

        try
        {
            var envelope = serializer.Deserialize(claimed.EmailEnvelopeJson);
            validator.Validate(envelope);
            return (envelope, null);
        }
        catch (Exception exception) when (
            exception is JsonException
                or ArgumentException
                or FormatException)
        {
            return (null, PermanentLocalFailure(
                "VALIDATION",
                "INVALID_EMAIL_ENVELOPE",
                "The persisted email envelope was invalid."));
        }
    }

    private async Task PersistDeliveryAsync(
        ClaimedPurchaseOrderEmailNotification claimed,
        EmailDeliveryResult delivery,
        EmailSenderSettings currentSettings,
        RunCounters counters)
    {
        using var persistenceSource = CreatePersistenceSource(currentSettings);
        var persistenceToken = persistenceSource.Token;
        var completedAt = timeProvider.GetUtcNow();

        switch (delivery.Outcome)
        {
            case EmailDeliveryOutcome.Succeeded:
                await repository.CompleteEmailNotificationAsync(
                    CreateCompleteCommand(
                        claimed,
                        delivery,
                        "SENT",
                        "SUCCEEDED",
                        false,
                        completedAt),
                    persistenceToken);
                Interlocked.Increment(ref counters.SentCount);
                break;

            case EmailDeliveryOutcome.TransientFailure:
                var nextFailureCount = claimed.FailureCount + 1;
                if (nextFailureCount >= currentSettings.MaxFailureCount)
                {
                    var completed = await repository.CompleteEmailNotificationAsync(
                        CreateCompleteCommand(
                            claimed,
                            delivery,
                            "FAILED",
                            "TRANSIENT_FAILURE",
                            true,
                            completedAt),
                        persistenceToken);
                    if (completed.FailureCount != nextFailureCount)
                    {
                        throw new InvalidOperationException(
                            "The terminal email failure count did not match the requested transition.");
                    }

                    Interlocked.Increment(ref counters.FailedCount);
                    break;
                }

                await repository.RescheduleEmailNotificationAsync(
                    CreateRescheduleCommand(
                        claimed,
                        delivery,
                        "TRANSIENT_FAILURE",
                        completedAt + retryDelay.Calculate(nextFailureCount),
                        completedAt),
                    persistenceToken);
                Interlocked.Increment(ref counters.RescheduledCount);
                break;

            case EmailDeliveryOutcome.Throttled:
                var throttleDelay = delivery.RetryAfter
                    ?? TimeSpan.FromSeconds(
                        currentSettings.ThrottleFallbackDelaySeconds);
                await repository.RescheduleEmailNotificationAsync(
                    CreateRescheduleCommand(
                        claimed,
                        delivery,
                        "THROTTLED",
                        AddWithSqlDateTimeSaturation(completedAt, throttleDelay),
                        completedAt),
                    persistenceToken);
                Interlocked.Increment(ref counters.RescheduledCount);
                Interlocked.Increment(ref counters.ThrottledCount);
                break;

            case EmailDeliveryOutcome.PermanentFailure:
                await repository.CompleteEmailNotificationAsync(
                    CreateCompleteCommand(
                        claimed,
                        delivery,
                        "FAILED",
                        "PERMANENT_FAILURE",
                        false,
                        completedAt),
                    persistenceToken);
                Interlocked.Increment(ref counters.FailedCount);
                break;

            default:
                throw new ArgumentOutOfRangeException(
                    nameof(delivery),
                    delivery.Outcome,
                    "The email delivery outcome is not supported.");
        }
    }

    private static CompletePurchaseOrderEmailNotificationCommand CreateCompleteCommand(
        ClaimedPurchaseOrderEmailNotification claimed,
        EmailDeliveryResult delivery,
        string status,
        string attemptOutcome,
        bool incrementFailureCount,
        DateTimeOffset completedAt) => new(
        claimed.NotificationId,
        claimed.LeaseId,
        status,
        attemptOutcome,
        incrementFailureCount,
        Bound(delivery.ProviderMessageId, 256),
        Bound(delivery.FailureCategory, 50),
        Bound(delivery.FailureCode, 100),
        Bound(delivery.FailureDescription, 1000),
        delivery.HttpStatusCode,
        completedAt,
        claimed.RowVersion);

    private static ReschedulePurchaseOrderEmailNotificationCommand CreateRescheduleCommand(
        ClaimedPurchaseOrderEmailNotification claimed,
        EmailDeliveryResult delivery,
        string outcome,
        DateTimeOffset nextAttemptAt,
        DateTimeOffset completedAt) => new(
        claimed.NotificationId,
        claimed.LeaseId,
        outcome,
        Bound(delivery.FailureCategory, 50) ?? FailureCategoryFor(outcome),
        Bound(delivery.FailureCode, 100),
        Bound(delivery.FailureDescription, 1000),
        delivery.HttpStatusCode,
        nextAttemptAt,
        completedAt,
        claimed.RowVersion);

    private static EmailDeliveryResult PermanentLocalFailure(
        string category,
        string code,
        string description) => new(
        EmailDeliveryOutcome.PermanentFailure,
        null,
        null,
        null,
        category,
        code,
        description);

    private static string FailureCategoryFor(string outcome) =>
        outcome == "THROTTLED" ? "CAPACITY" : "TRANSPORT";

    private static string? Bound(string? value, int maximumLength) =>
        value is null || value.Length <= maximumLength
            ? value
            : value[..maximumLength];

    private static bool HasSafeTime(
        DateTimeOffset deadline,
        DateTimeOffset now,
        TimeSpan requiredSafeTime) => deadline - now > requiredSafeTime;

    private static DateTimeOffset AddWithSqlDateTimeSaturation(
        DateTimeOffset timestamp,
        TimeSpan delay)
    {
        var utcTimestamp = timestamp.ToUniversalTime();
        if (delay <= TimeSpan.Zero)
        {
            return utcTimestamp;
        }

        return delay >= MaximumSqlDateTimeUtc - utcTimestamp
            ? MaximumSqlDateTimeUtc
            : utcTimestamp + delay;
    }

    private static CancellationTokenSource CreatePersistenceSource(
        EmailSenderSettings currentSettings) => new(
        TimeSpan.FromSeconds(currentSettings.OutcomePersistenceTimeoutSeconds));

    private sealed class RunCounters
    {
        public int ClaimedCount;
        public int SentCount;
        public int RescheduledCount;
        public int FailedCount;
        public int ThrottledCount;
        public int DeferredCount;
    }
}
