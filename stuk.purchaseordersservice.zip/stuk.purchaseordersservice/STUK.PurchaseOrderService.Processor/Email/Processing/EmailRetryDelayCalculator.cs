using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Email.Processing;

public sealed class EmailRetryDelayCalculator(
    IOptionsMonitor<EmailSenderSettings> settings,
    IEmailJitterProvider jitterProvider) : IEmailRetryDelayCalculator
{
    public TimeSpan Calculate(int nextFailureCount)
    {
        if (nextFailureCount <= 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(nextFailureCount),
                "The next failure count must be positive.");
        }

        var currentSettings = settings.CurrentValue;
        var maximumSeconds = (long)currentSettings.MaxRetryDelaySeconds;
        var jitterBound = currentSettings.RetryJitterSeconds;
        var maximumRelevantBase = maximumSeconds + jitterBound + 1L;
        var exponentialSeconds = (long)currentSettings.InitialRetryDelaySeconds;

        for (var exponent = 1;
             exponentialSeconds > 0
             && exponent < nextFailureCount
             && exponentialSeconds < maximumRelevantBase;
             exponent++)
        {
            exponentialSeconds = exponentialSeconds > maximumRelevantBase / 2
                ? maximumRelevantBase
                : Math.Min(exponentialSeconds * 2, maximumRelevantBase);
        }

        var jitterSeconds = jitterProvider.NextInclusive(-jitterBound, jitterBound);
        var finalSeconds = Math.Clamp(
            exponentialSeconds + jitterSeconds,
            0L,
            maximumSeconds);
        return TimeSpan.FromSeconds(finalSeconds);
    }
}
