namespace STUK.PurchaseOrderService.Processor.Email.Processing;

public sealed class SystemEmailJitterProvider : IEmailJitterProvider
{
    public int NextInclusive(int minimum, int maximum)
    {
        if (minimum > maximum)
        {
            throw new ArgumentOutOfRangeException(
                nameof(minimum),
                "The minimum jitter must not exceed the maximum jitter.");
        }

        return (int)Random.Shared.NextInt64(minimum, (long)maximum + 1);
    }
}
