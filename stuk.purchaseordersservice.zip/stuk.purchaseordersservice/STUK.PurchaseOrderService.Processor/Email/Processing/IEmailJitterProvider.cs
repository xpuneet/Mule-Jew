namespace STUK.PurchaseOrderService.Processor.Email.Processing;

public interface IEmailJitterProvider
{
    int NextInclusive(int minimum, int maximum);
}
