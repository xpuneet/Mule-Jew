using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization.Metadata;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.Processor.Email.Serialization;

public sealed class EmailEnvelopeSerializer(IEmailEnvelopeValidator validator)
    : IEmailEnvelopeSerializer
{
    public string Serialize(EmailEnvelopeV1 envelope)
    {
        ArgumentNullException.ThrowIfNull(envelope);
        return JsonSerializer.Serialize(envelope, EmailJsonSerializerOptions.Instance);
    }

    public EmailEnvelopeV1 Deserialize(string envelopeJson)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(envelopeJson);
        var envelope = JsonSerializer.Deserialize<EmailEnvelopeV1>(
            envelopeJson,
            EmailJsonSerializerOptions.Instance) ?? throw new ArgumentException(
                "The email envelope JSON did not contain an envelope.",
                nameof(envelopeJson));

        validator.Validate(envelope);
        return envelope;
    }

}

internal static class EmailJsonSerializerOptions
{
    internal static JsonSerializerOptions Instance { get; } = Create();

    private static JsonSerializerOptions Create()
    {
        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false,
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            TypeInfoResolver = new DefaultJsonTypeInfoResolver()
        };
        options.MakeReadOnly();
        return options;
    }
}
