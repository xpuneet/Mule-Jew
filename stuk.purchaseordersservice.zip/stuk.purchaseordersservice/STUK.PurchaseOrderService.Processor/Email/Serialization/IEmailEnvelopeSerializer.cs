using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Serialization;

public interface IEmailEnvelopeSerializer
{
    string Serialize(EmailEnvelopeV1 envelope);
    EmailEnvelopeV1 Deserialize(string envelopeJson);
}
