using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Outbox;

public interface IEmailNotificationOutbox
{
    Task<EnqueuedPurchaseOrderEmailNotification> EnqueueSnapshotAsync(
        string envelopeJson,
        EmailNotificationMetadata metadata,
        CancellationToken cancellationToken = default);

    Task<EnqueuedPurchaseOrderEmailNotification> EnqueueAsync(
        EmailNotificationRequest request,
        EmailNotificationMetadata metadata,
        CancellationToken cancellationToken = default);
}
