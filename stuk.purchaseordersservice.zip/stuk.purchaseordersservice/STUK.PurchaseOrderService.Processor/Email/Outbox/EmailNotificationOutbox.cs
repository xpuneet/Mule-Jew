using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.Processor.Email.Outbox;

public sealed class EmailNotificationOutbox(
    IPurchaseOrderNotificationRepository repository,
    IEmailEnvelopeValidator validator,
    IEmailEnvelopeSerializer serializer,
    IOptionsMonitor<EmailSenderSettings> settings) : IEmailNotificationOutbox
{
    public async Task<EnqueuedPurchaseOrderEmailNotification> EnqueueAsync(
        EmailNotificationRequest request,
        EmailNotificationMetadata metadata,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentNullException.ThrowIfNull(metadata);

        var envelope = new EmailEnvelopeV1(
            1,
            request.NotificationId,
            request.BusinessCorrelationId,
            settings.CurrentValue.DefaultSenderAddress,
            request.To,
            request.Cc,
            request.Bcc,
            request.ReplyTo,
            request.Subject,
            request.HtmlBody,
            request.PlainTextBody,
            request.Attachments);

        validator.Validate(envelope);
        var envelopeJson = serializer.Serialize(envelope);
        return await PersistAsync(envelope, envelopeJson, metadata, cancellationToken);
    }

    public Task<EnqueuedPurchaseOrderEmailNotification> EnqueueSnapshotAsync(
        string envelopeJson,
        EmailNotificationMetadata metadata,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(metadata);
        // Keep the saved bytes: re-serializing after a deployment could break SQL idempotency.
        var envelope = serializer.Deserialize(envelopeJson);
        return PersistAsync(envelope, envelopeJson, metadata, cancellationToken);
    }

    private async Task<EnqueuedPurchaseOrderEmailNotification> PersistAsync(
        EmailEnvelopeV1 envelope, string envelopeJson, EmailNotificationMetadata metadata,
        CancellationToken cancellationToken)
    {
        var result = await repository.EnqueueEmailNotificationAsync(
            new EnqueuePurchaseOrderEmailNotificationCommand(
                envelope.NotificationId,
                metadata.BatchId,
                metadata.EventType,
                envelope.BusinessCorrelationId,
                (short)envelope.SchemaVersion,
                envelopeJson,
                metadata.TemplateKey,
                metadata.RecipientGroupKey,
                metadata.AttachmentBlobName,
                metadata.CreatedDateTime.ToUniversalTime()),
            cancellationToken);

        var expectedHash = SHA256.HashData(Encoding.Unicode.GetBytes(envelopeJson));
        if (!CryptographicOperations.FixedTimeEquals(expectedHash, result.PayloadSha256))
        {
            throw new InvalidOperationException(
                "The persisted email envelope hash does not match the submitted snapshot.");
        }

        return result;
    }
}
