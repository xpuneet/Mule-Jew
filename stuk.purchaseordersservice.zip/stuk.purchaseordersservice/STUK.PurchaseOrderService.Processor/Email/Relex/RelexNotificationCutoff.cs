using System.Globalization;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Email.Relex;

public sealed record RelexNotificationCutoff(DateTimeOffset CutoffUtc, DateTimeOffset FreshSinceUtc, string EventKey)
{
    public static RelexNotificationCutoff? GetDue(RelexNotificationSettings settings, DateTimeOffset now)
    {
        if (!settings.MissingProposalEnabled) return null;
        var zone = TimeZoneInfo.FindSystemTimeZoneById(settings.TimeZoneId);
        var localNow = TimeZoneInfo.ConvertTime(now, zone);
        var allowedDays = settings.MissingProposalDays.Split(',', StringSplitOptions.TrimEntries);
        var time = TimeOnly.ParseExact(settings.MissingProposalCutoffLocalTime, "HH:mm", CultureInfo.InvariantCulture);
        // Catch-up is at most twelve hours, so only today's and yesterday's cutoff can be due.
        for (var daysBack = 0; daysBack <= 1; daysBack++)
        {
            var day = DateOnly.FromDateTime(localNow.DateTime).AddDays(-daysBack);
            if (!allowedDays.Contains(day.DayOfWeek.ToString(), StringComparer.OrdinalIgnoreCase)) continue;
            var localCutoff = day.ToDateTime(time, DateTimeKind.Unspecified);
            // An invalid local time has no real instant. For a repeated time, use its first occurrence.
            if (zone.IsInvalidTime(localCutoff)) continue;
            var offset = zone.IsAmbiguousTime(localCutoff)
                ? zone.GetAmbiguousTimeOffsets(localCutoff).Max() : zone.GetUtcOffset(localCutoff);
            var cutoff = new DateTimeOffset(localCutoff, offset).ToUniversalTime();
            if (now < cutoff || now >= cutoff.AddMinutes(settings.MissingProposalCatchUpMinutes)) continue;
            return new(cutoff, cutoff.AddHours(-settings.MissingProposalLookbackHours),
                $"RELEX_MISSING:{localCutoff.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)}");
        }
        return null;
    }
}
