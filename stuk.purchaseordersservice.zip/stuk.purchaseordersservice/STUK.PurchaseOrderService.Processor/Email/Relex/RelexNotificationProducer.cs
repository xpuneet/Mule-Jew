using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;
using STUK.PurchaseOrderService.Processor.Email.Outbox;
using STUK.PurchaseOrderService.Processor.Email.Serialization;
using STUK.PurchaseOrderService.Processor.Email.Validation;

namespace STUK.PurchaseOrderService.Processor.Email.Relex;

public sealed class RelexNotificationProducer(
    IRelexNotificationRepository repository,
    RelexEmailComposer composer,
    IEmailEnvelopeSerializer serializer,
    IEmailEnvelopeValidator validator,
    IEmailNotificationOutbox outbox,
    IOptionsMonitor<RelexNotificationSettings> settings,
    IOptionsMonitor<EmailSenderSettings> senderSettings,
    TimeProvider timeProvider,
    ILogger<RelexNotificationProducer> logger) : IRelexNotificationProducer
{
    private static readonly JsonSerializerOptions SnapshotJson = new(JsonSerializerDefaults.Web);

    public async Task<RelexNotificationProducerResult> ProcessAsync(CancellationToken cancellationToken = default)
    {
        var options = settings.CurrentValue;
        if (!options.ResultsEnabled && !options.MissingProposalEnabled) return new(0, 0, 0);
        var senderAddress = senderSettings.CurrentValue.DefaultSenderAddress;
        // Both option sets can reload independently. Reject invalid current configuration before
        // freezing durable events, even when SMTP delivery (and its sender validation) is disabled.
        var validation = RelexNotificationSettingsValidator.ValidateCurrent(options, senderAddress);
        if (validation.Failed)
            throw new OptionsValidationException(RelexNotificationSettings.SectionName,
                typeof(RelexNotificationSettings), validation.Failures!);
        var startedAt = timeProvider.GetUtcNow();
        var cutoff = RelexNotificationCutoff.GetDue(options, startedAt);
        var snapshot = new RelexEmailCompositionSnapshot(1, options.EnvironmentName,
            options.GetRecipients(), senderAddress);
        using var runTimeout = new CancellationTokenSource(TimeSpan.FromSeconds(options.MaxRunDurationSeconds), timeProvider);
        using var runCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, runTimeout.Token);
        var token = runCancellation.Token;
        IReadOnlyList<RelexNotificationEvent> notifications;
        try
        {
            notifications = await repository.PrepareAndClaimAsync(new(
                startedAt, options.MaxEventsPerRun, options.LeaseDurationSeconds, options.ResultsEnabled,
                JsonSerializer.Serialize(snapshot, SnapshotJson), options.ResultsNotBeforeUtc?.ToUniversalTime(),
                cutoff?.CutoffUtc, cutoff?.FreshSinceUtc, cutoff?.EventKey), token);
        }
        catch (OperationCanceledException) when (runTimeout.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
        {
            logger.LogWarning("Relex notification preparation exceeded its run budget; leases will recover on a later run.");
            return new(0, 0, 0);
        }

        var enqueued = 0;
        var failed = 0;
        foreach (var notification in notifications)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (token.IsCancellationRequested
                || timeProvider.GetUtcNow() >= startedAt.AddSeconds(options.MaxRunDurationSeconds)) break;
            var composing = true;
            try
            {
                var json = notification.EmailEnvelopeJson;
                if (json is null)
                {
                    var envelope = composer.Compose(notification);
                    validator.Validate(envelope);
                    json = serializer.Serialize(envelope);
                    composing = false;
                    json = await repository.SaveEnvelopeAsync(new(notification.NotificationId, notification.LeaseId, json), token);
                }

                composing = true;
                var savedEnvelope = serializer.Deserialize(json);
                if (savedEnvelope.NotificationId != notification.NotificationId
                    || savedEnvelope.BusinessCorrelationId != notification.BusinessCorrelationId)
                    throw new InvalidOperationException("The saved envelope identity does not match its Relex event.");
                var templateKey = notification.EventType switch
                {
                    "RELEX_RESULTS" => "relex-results-v1",
                    "RELEX_MISSING" => "relex-missing-v1",
                    _ => throw new InvalidOperationException("The Relex event type is unsupported.")
                };
                composing = false;
                await outbox.EnqueueSnapshotAsync(json, new EmailNotificationMetadata(
                    notification.BatchId, notification.EventType, templateKey,
                    "relex-support", null, notification.CreatedDateTime), token);
                await repository.CompleteAsync(new(notification.NotificationId, notification.LeaseId,
                    true, false, timeProvider.GetUtcNow(), null, null, options.MaxFailureCount), token);
                enqueued++;
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested)
            {
                // The outbox may already exist. Keep the immutable snapshot and recover using its lease.
                cancellationToken.ThrowIfCancellationRequested();
                break;
            }
            catch (Exception exception)
            {
                var permanent = composing && exception is ArgumentException or JsonException or InvalidOperationException;
                failed++;
                var code = permanent ? "INVALID_RELEX_SNAPSHOT" : "RELEX_PRODUCER_PERSISTENCE_FAILED";
                // Exception messages can contain SQL parameters, message bodies or addresses.
                logger.LogWarning("Relex notification {NotificationId} failed with {FailureCode}; exception type {ExceptionType}.",
                    notification.NotificationId, code, exception.GetType().Name);
                using var persistenceTimeout = new CancellationTokenSource(
                    TimeSpan.FromSeconds(options.OutcomePersistenceTimeoutSeconds), timeProvider);
                try
                {
                    var now = timeProvider.GetUtcNow();
                    await repository.CompleteAsync(new(notification.NotificationId, notification.LeaseId,
                        false, permanent, now, permanent ? null : now.AddSeconds(options.RetryDelaySeconds),
                        code, options.MaxFailureCount), persistenceTimeout.Token);
                }
                catch (Exception persistenceException)
                {
                    logger.LogWarning("Relex notification {NotificationId} outcome was not persisted; lease recovery required. Exception type {ExceptionType}.",
                        notification.NotificationId, persistenceException.GetType().Name);
                }
            }
        }

        return new(notifications.Count, enqueued, failed);
    }
}
