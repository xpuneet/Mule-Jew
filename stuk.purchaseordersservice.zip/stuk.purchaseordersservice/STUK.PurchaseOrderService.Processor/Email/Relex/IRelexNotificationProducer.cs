namespace STUK.PurchaseOrderService.Processor.Email.Relex;

public interface IRelexNotificationProducer
{
    Task<RelexNotificationProducerResult> ProcessAsync(CancellationToken cancellationToken = default);
}

public sealed record RelexNotificationProducerResult(int ClaimedCount, int EnqueuedCount, int FailedCount);
