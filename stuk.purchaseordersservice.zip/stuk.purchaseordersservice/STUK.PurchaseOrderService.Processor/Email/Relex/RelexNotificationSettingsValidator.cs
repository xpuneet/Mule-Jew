using System.Globalization;
using System.Net.Mail;
using Microsoft.Extensions.Options;
using NCrontab;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Email.Relex;

public sealed class RelexNotificationSettingsValidator(IOptions<EmailSenderSettings> senderSettings)
    : IValidateOptions<RelexNotificationSettings>
{
    public ValidateOptionsResult Validate(string? name, RelexNotificationSettings options)
        => ValidateCurrent(options, options.ResultsEnabled || options.MissingProposalEnabled
            ? senderSettings.Value.DefaultSenderAddress : string.Empty);

    public static ValidateOptionsResult ValidateCurrent(RelexNotificationSettings options, string senderAddress)
    {
        var errors = new List<string>();
        try
        {
            if (CrontabSchedule.TryParse(options.CronExpression,
                    new CrontabSchedule.ParseOptions { IncludingSeconds = true }) is null)
                errors.Add("RelexNotificationProducerCronExpression must be a six-field NCRONTAB expression.");
        }
        catch (CrontabException)
        {
            errors.Add("RelexNotificationProducerCronExpression must be a six-field NCRONTAB expression.");
        }

        if (!options.ResultsEnabled && !options.MissingProposalEnabled)
            return Result(errors);

        if (string.IsNullOrWhiteSpace(options.EnvironmentName) || options.EnvironmentName.Length > 64
            || options.EnvironmentName.Any(char.IsControl))
            errors.Add("RelexNotifications:EnvironmentName must be 1-64 printable characters.");
        var recipients = options.GetRecipients();
        if (recipients.Length is < 1 or > 50 || recipients.Any(address => !ValidAddress(address)))
            errors.Add("RelexNotifications:Recipients must contain 1-50 canonical email addresses.");
        if (!ValidAddress(senderAddress))
            errors.Add("EmailSender:DefaultSenderAddress is required when Relex notifications are enabled.");
        if (options.ResultsEnabled && options.ResultsNotBeforeUtc is null)
            errors.Add("RelexNotifications:ResultsNotBeforeUtc is required when results are enabled.");
        if (!TimeOnly.TryParseExact(options.MissingProposalCutoffLocalTime, "HH:mm",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
            errors.Add("RelexNotifications:MissingProposalCutoffLocalTime must use HH:mm.");
        try { TimeZoneInfo.FindSystemTimeZoneById(options.TimeZoneId); }
        catch (Exception exception) when (exception is TimeZoneNotFoundException or InvalidTimeZoneException or ArgumentException)
        { errors.Add("RelexNotifications:TimeZoneId must identify an installed time zone."); }
        var days = (options.MissingProposalDays ?? string.Empty)
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (days.Length == 0 || days.Any(day => !Enum.GetNames<DayOfWeek>().Contains(day, StringComparer.OrdinalIgnoreCase)))
            errors.Add("RelexNotifications:MissingProposalDays must contain named weekdays.");
        if (options.MaxEventsPerRun is < 1 or > 100)
            errors.Add("RelexNotifications:MaxEventsPerRun must be between 1 and 100.");
        if (options.MaxRunDurationSeconds is < 1 or > 300
            || options.OutcomePersistenceTimeoutSeconds is < 1 or > 30
            || options.LeaseDurationSeconds is < 30 or > 3600
            || options.LeaseDurationSeconds <= (long)options.MaxRunDurationSeconds + options.OutcomePersistenceTimeoutSeconds)
            errors.Add("Relex notification lease must exceed bounded run plus outcome persistence time.");
        if (options.MissingProposalLookbackHours is < 1 or > 168
            || options.MissingProposalCatchUpMinutes is < 1 or > 720)
            errors.Add("Relex missing-proposal lookback must be 1-168 hours and catch-up 1-720 minutes.");
        if (options.RetryDelaySeconds is < 1 or > 3600 || options.MaxFailureCount is < 1 or > 20)
            errors.Add("Relex notification retry delay must be 1-3600 seconds and failure count 1-20.");
        return Result(errors);
    }

    private static bool ValidAddress(string? address) => !string.IsNullOrWhiteSpace(address)
        && !address.Any(char.IsControl) && MailAddress.TryCreate(address, out var parsed)
        && string.Equals(address, parsed.Address, StringComparison.Ordinal);

    private static ValidateOptionsResult Result(List<string> errors) => errors.Count == 0
        ? ValidateOptionsResult.Success : ValidateOptionsResult.Fail(errors);
}
