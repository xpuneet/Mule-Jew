namespace STUK.PurchaseOrderService.Processor.Email.Relex;

public sealed record RelexNotificationOutcomeRow(
    int Counter,
    string Branch,
    string Supplier,
    string? OrderNumber,
    string? CreateStatus,
    bool? Suspended,
    string? SuspendedMessage,
    bool? Bypass,
    string? DeliveryMode,
    string? ApiUser,
    string CandidateStatus);
