namespace STUK.PurchaseOrderService.Processor.Email.Relex;

public sealed record RelexEmailCompositionSnapshot(
    int SchemaVersion,
    string EnvironmentName,
    IReadOnlyList<string> Recipients,
    string SenderAddress);
