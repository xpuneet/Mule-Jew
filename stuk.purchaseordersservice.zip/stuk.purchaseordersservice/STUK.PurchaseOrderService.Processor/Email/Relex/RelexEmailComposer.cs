using System.Globalization;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Email.Contracts;

namespace STUK.PurchaseOrderService.Processor.Email.Relex;

public sealed class RelexEmailComposer
{
    private const int SupportedSchemaVersion = 1;
    private const int MaximumCsvByteCount = 6 * 1024 * 1024;
    private const int MaximumOutcomeJsonCharacterCount = 32 * 1024 * 1024;
    private const string CsvHeaderV1 = "counter,branch,supplier,order number,create status,suspended status,suspended message,bypass flag status,delivery mode,api user\r\n";
    private const string ResultsHtmlStartV1 = "<html>\n<body bgcolor=\"White\" text=\"Black\">\n<p>CSV attached\n<br><br> \n";
    private const string ResultsHtmlEndV1 = "\n</p>\n</body>\n</html>";
    private const string ResultsFailureTextV1 = "Failed Purchase Orders are included in the attached CSV.";
    private const string MissingHtmlV1 = "<html>\n<body bgcolor=\"White\" text=\"Black\">\n<p>No recent Purchase Order proposals have been processed by the agreed cut off time.<br><br> Please investigate with Relex, CSD and the Integration team. </p>\n</body>\n</html>";
    private static readonly UTF8Encoding CsvEncoding = new(false);

    public EmailEnvelopeV1 Compose(RelexNotificationEvent notification)
    {
        ArgumentNullException.ThrowIfNull(notification);
        if (notification.NotificationId == Guid.Empty
            || string.IsNullOrWhiteSpace(notification.BusinessCorrelationId))
        {
            throw new InvalidOperationException("The Relex notification identity is invalid.");
        }

        var snapshot = ReadSnapshot(notification.CompositionSettingsJson);
        return notification.EventType switch
        {
            "RELEX_RESULTS" => ComposeResults(notification, snapshot),
            "RELEX_MISSING" => CreateEnvelope(
                notification,
                snapshot,
                "Relex - No order proposal notification | Environment - ",
                MissingHtmlV1,
                []),
            _ => throw new InvalidOperationException("The Relex notification event type is not supported.")
        };
    }

    private static RelexEmailCompositionSnapshot ReadSnapshot(string json)
    {
        var snapshot = ReadJson<RelexEmailCompositionSnapshot>(json);
        if (snapshot.SchemaVersion != SupportedSchemaVersion
            || string.IsNullOrWhiteSpace(snapshot.EnvironmentName)
            || snapshot.EnvironmentName.Any(char.IsControl)
            || snapshot.Recipients is null
            || snapshot.Recipients.Count is < 1 or > 50
            || snapshot.Recipients.Any(address => !IsCanonicalAddress(address))
            || !IsCanonicalAddress(snapshot.SenderAddress))
        {
            throw new InvalidOperationException("The Relex notification composition snapshot is invalid or unsupported.");
        }

        return snapshot;
    }

    private static EmailEnvelopeV1 ComposeResults(
        RelexNotificationEvent notification,
        RelexEmailCompositionSnapshot snapshot)
    {
        RequireSafeAttachmentName(notification.OriginalFileName);
        if (notification.OutcomeRowsJson is null
            || notification.OutcomeRowsJson.Length > MaximumOutcomeJsonCharacterCount)
        {
            throw new InvalidOperationException("The Relex notification outcome snapshot exceeds the composition limit.");
        }

        var rows = ReadJson<List<RelexNotificationOutcomeRow>>(notification.OutcomeRowsJson);
        if (rows.Count == 0
            || rows.Any(row => row is null || row.Counter < 1 || !IsTerminalStatus(row.CandidateStatus)))
        {
            throw new InvalidOperationException("The Relex results notification requires non-empty terminal outcomes.");
        }

        var csv = RenderCsv(rows);
        var attachment = new EmailAttachmentV1(
            notification.OriginalFileName!,
            "application/octet-stream",
            Convert.ToHexString(SHA256.HashData(csv)).ToLowerInvariant(),
            Convert.ToBase64String(csv));
        var hasFailures = rows.Any(row => row.CandidateStatus != "COMPLETED");
        var html = ResultsHtmlStartV1
            + (hasFailures ? ResultsFailureTextV1 : string.Empty)
            + ResultsHtmlEndV1;

        return CreateEnvelope(notification, snapshot, "Relex PO Results | Environment - ", html, [attachment]);
    }

    private static EmailEnvelopeV1 CreateEnvelope(
        RelexNotificationEvent notification,
        RelexEmailCompositionSnapshot snapshot,
        string subjectPrefix,
        string html,
        IReadOnlyList<EmailAttachmentV1> attachments) => new(
        SupportedSchemaVersion,
        notification.NotificationId,
        notification.BusinessCorrelationId,
        snapshot.SenderAddress,
        snapshot.Recipients.Select(address => new EmailMailbox(address, null)).ToArray(),
        [],
        [],
        [],
        subjectPrefix + snapshot.EnvironmentName,
        html,
        null,
        attachments);

    private static byte[] RenderCsv(IReadOnlyList<RelexNotificationOutcomeRow> rows)
    {
        using var stream = new BoundedCsvStream();
        using (var writer = new StreamWriter(stream, CsvEncoding, 4096, leaveOpen: true))
        {
            writer.Write(CsvHeaderV1);
            foreach (var row in rows)
            {
                var hasOrderNumber = !string.IsNullOrWhiteSpace(row.OrderNumber);
                WriteCell(writer, row.Counter.ToString(CultureInfo.InvariantCulture));
                writer.Write(',');
                WriteCell(writer, row.Branch);
                writer.Write(',');
                WriteCell(writer, row.Supplier);
                writer.Write(',');
                WriteCell(writer, hasOrderNumber ? row.OrderNumber : "0");
                writer.Write(',');
                WriteCell(writer, row.CreateStatus ?? "Purchase Order timed out", flattenNewlines: true);
                writer.Write(',');
                WriteCell(writer, row.Suspended == true ? "true" : "false");
                writer.Write(',');
                WriteCell(writer, hasOrderNumber ? row.SuspendedMessage : "check ICON");
                writer.Write(',');
                WriteCell(writer, row.Bypass is null ? null : row.Bypass.Value ? "true" : "false");
                writer.Write(',');
                WriteCell(writer, row.DeliveryMode);
                writer.Write(',');
                WriteCell(writer, row.ApiUser);
                writer.Write("\r\n");
            }
        }

        return stream.ToArray();
    }

    private static void WriteCell(TextWriter writer, string? value, bool flattenNewlines = false)
    {
        if (string.IsNullOrEmpty(value))
        {
            return;
        }

        var quoted = value.Any(character => character is ',' or '"'
            || (!flattenNewlines && character is '\r' or '\n'));
        if (quoted)
        {
            writer.Write('"');
        }

        if (NeedsFormulaProtection(value, flattenNewlines))
        {
            writer.Write('\'');
        }

        foreach (var character in value)
        {
            if (flattenNewlines && character is '\r' or '\n')
            {
                continue;
            }

            if (character == '"')
            {
                writer.Write('"');
            }

            writer.Write(character);
        }

        if (quoted)
        {
            writer.Write('"');
        }
    }

    private static bool NeedsFormulaProtection(string value, bool flattenNewlines)
    {
        var firstIndex = 0;
        while (firstIndex < value.Length)
        {
            var character = value[firstIndex];
            if (flattenNewlines && character is '\r' or '\n')
            {
                firstIndex++;
                continue;
            }

            if (character is '\t' or '\r' or '\n')
            {
                return true;
            }

            if (char.IsWhiteSpace(character) || char.GetUnicodeCategory(character) == UnicodeCategory.Format)
            {
                firstIndex++;
                continue;
            }

            break;
        }

        if (firstIndex == value.Length || value[firstIndex] is not ('=' or '+' or '-' or '@'))
        {
            return false;
        }

        return firstIndex != 0 || !decimal.TryParse(
            value,
            NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowExponent,
            CultureInfo.InvariantCulture,
            out _);
    }

    private static T ReadJson<T>(string? json) where T : class
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            throw new InvalidOperationException("The Relex notification snapshot is missing.");
        }

        try
        {
            return JsonSerializer.Deserialize<T>(json, JsonSerializerOptions.Web)
                ?? throw new InvalidOperationException("The Relex notification snapshot is missing.");
        }
        catch (JsonException)
        {
            throw new InvalidOperationException("The Relex notification snapshot contains invalid JSON.");
        }
    }

    private static bool IsCanonicalAddress(string? address) =>
        !string.IsNullOrWhiteSpace(address)
        && !address.Any(char.IsControl)
        && MailAddress.TryCreate(address, out var parsed)
        && string.Equals(parsed.Address, address, StringComparison.Ordinal);

    private static bool IsTerminalStatus(string? status) => status is
        "COMPLETED" or "RECOVERABLE_ERROR" or "NON_RECOVERABLE_ERROR" or "CANCELLED";

    private static void RequireSafeAttachmentName(string? fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName)
            || fileName is "." or ".."
            || fileName.Length > 255
            || fileName.Any(character => char.IsControl(character) || character is '/' or '\\' or ':'))
        {
            throw new InvalidOperationException("The Relex notification requires a safe original file name.");
        }
    }

    private sealed class BoundedCsvStream : MemoryStream
    {
        public override void Write(byte[] buffer, int offset, int count)
        {
            RequireCapacity(count);
            base.Write(buffer, offset, count);
        }

        public override void Write(ReadOnlySpan<byte> buffer)
        {
            RequireCapacity(buffer.Length);
            base.Write(buffer);
        }

        public override void WriteByte(byte value)
        {
            RequireCapacity(1);
            base.WriteByte(value);
        }

        private void RequireCapacity(int count)
        {
            if (Position > MaximumCsvByteCount - count)
            {
                throw new InvalidOperationException("The Relex results CSV exceeds the message safety budget.");
            }
        }
    }
}
