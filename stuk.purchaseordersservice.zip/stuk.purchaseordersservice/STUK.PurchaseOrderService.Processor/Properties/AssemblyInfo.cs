using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("STUK.PurchaseOrderService.UnitTests")]
