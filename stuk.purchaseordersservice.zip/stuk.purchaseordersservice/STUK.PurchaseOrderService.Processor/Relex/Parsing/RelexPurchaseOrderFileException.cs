namespace STUK.PurchaseOrderService.Processor.Relex.Parsing;

public sealed class RelexPurchaseOrderFileException : Exception
{
    public RelexPurchaseOrderFileException(
        string code,
        string message,
        int? recordNumber = null,
        string? fieldName = null,
        Exception? innerException = null)
        : base(message, innerException)
    {
        Code = code;
        RecordNumber = recordNumber;
        FieldName = fieldName;
    }

    public string Code { get; }

    public int? RecordNumber { get; }

    public string? FieldName { get; }
}
