namespace STUK.PurchaseOrderService.Processor.Relex.Parsing;

public interface IRelexPurchaseOrderFileProcessor
{
    RelexFileProcessingResult Process(
        Stream csvStream,
        CancellationToken cancellationToken = default);
}
