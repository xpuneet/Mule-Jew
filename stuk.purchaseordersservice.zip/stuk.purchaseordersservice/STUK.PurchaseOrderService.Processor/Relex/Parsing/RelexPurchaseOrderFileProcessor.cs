using System.Globalization;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Processor.Relex.Parsing;

public sealed class RelexPurchaseOrderFileProcessor : IRelexPurchaseOrderFileProcessor
{
    private const string EmptyFileCode = "RELEX_EMPTY_FILE";
    private const string NoDataRowsCode = "RELEX_NO_DATA_ROWS";
    private const string MalformedCsvCode = "RELEX_MALFORMED_CSV";
    private const string MissingHeaderCode = "RELEX_MISSING_HEADER";
    private const string DuplicateHeaderCode = "RELEX_DUPLICATE_HEADER";
    private const string MissingValueCode = "RELEX_MISSING_VALUE";
    private const string InvalidValueCode = "RELEX_INVALID_VALUE";
    private const string InconsistentOrderCode = "RELEX_INCONSISTENT_ORDER";

    private static readonly string[] RequiredHeaders =
    [
        "order_number",
        "supplier",
        "location",
        "product",
        "effective_quantity"
    ];

    private static readonly HashSet<string> KnownHeaders = CreateKnownHeaders();

    public RelexFileProcessingResult Process(
        Stream csvStream,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(csvStream);
        if (!csvStream.CanRead)
        {
            throw new ArgumentException("The CSV stream must be readable.", nameof(csvStream));
        }

        using var parser = new TextFieldParser(
            csvStream,
            Encoding.UTF8,
            detectEncoding: true,
            leaveOpen: true)
        {
            HasFieldsEnclosedInQuotes = true,
            TrimWhiteSpace = false
        };
        parser.SetDelimiters(",");

        if (parser.EndOfData)
        {
            throw Error(EmptyFileCode, "Relex CSV file is empty.");
        }

        var headerFields = ReadFields(parser, recordNumber: 1);
        if (headerFields is null)
        {
            throw Error(EmptyFileCode, "Relex CSV file is empty.");
        }

        var headerIndexes = BuildHeaderIndexes(headerFields);
        var accumulators = new Dictionary<string, OrderAccumulator>(StringComparer.Ordinal);
        var accumulatorOrder = new List<OrderAccumulator>();
        var parsedRowCount = 0;
        var recordNumber = 2;

        while (!parser.EndOfData)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var fields = ReadFields(parser, recordNumber);
            if (fields is null)
            {
                break;
            }

            if (fields.Length != headerFields.Length)
            {
                throw Error(
                    MalformedCsvCode,
                    "Relex CSV record is malformed.",
                    recordNumber);
            }

            var record = ParseRecord(fields, headerIndexes, recordNumber);
            if (!accumulators.TryGetValue(record.OrderNumber, out var accumulator))
            {
                accumulator = new OrderAccumulator(record);
                accumulators.Add(record.OrderNumber, accumulator);
                accumulatorOrder.Add(accumulator);
            }
            else
            {
                accumulator.Add(record, recordNumber);
            }

            parsedRowCount++;
            recordNumber++;
        }

        if (parsedRowCount == 0)
        {
            throw Error(NoDataRowsCode, "Relex CSV file has no data rows.");
        }

        return new RelexFileProcessingResult(
            parsedRowCount,
            accumulatorOrder.Select(accumulator => accumulator.ToResult()).ToArray());
    }

    private static string[]? ReadFields(TextFieldParser parser, int recordNumber)
    {
        try
        {
            return parser.ReadFields();
        }
        catch (MalformedLineException exception)
        {
            throw Error(
                MalformedCsvCode,
                "Relex CSV record is malformed.",
                recordNumber,
                innerException: exception);
        }
    }

    private static Dictionary<string, int> BuildHeaderIndexes(string[] fields)
    {
        var indexes = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        for (var index = 0; index < fields.Length; index++)
        {
            var header = fields[index].Trim();
            if (!KnownHeaders.Contains(header))
            {
                continue;
            }

            if (!indexes.TryAdd(header, index))
            {
                throw Error(
                    DuplicateHeaderCode,
                    "A Relex CSV header is duplicated.",
                    recordNumber: 1,
                    fieldName: header.ToLowerInvariant());
            }
        }

        foreach (var requiredHeader in RequiredHeaders)
        {
            if (!indexes.ContainsKey(requiredHeader))
            {
                throw Error(
                    MissingHeaderCode,
                    "A required Relex CSV header is missing.",
                    recordNumber: 1,
                    fieldName: requiredHeader);
            }
        }

        return indexes;
    }

    private static RelexOrderProposalRecord ParseRecord(
        string[] fields,
        IReadOnlyDictionary<string, int> indexes,
        int recordNumber)
    {
        var orderNumber = RequiredString(
            fields,
            indexes,
            "order_number",
            recordNumber);
        var supplier = RequiredString(fields, indexes, "supplier", recordNumber);
        var location = PositiveOrAnyInteger(
            RequiredString(fields, indexes, "location", recordNumber),
            "location",
            recordNumber,
            mustBePositive: false);
        var product = RequiredString(fields, indexes, "product", recordNumber);
        var quantity = PositiveOrAnyInteger(
            RequiredString(fields, indexes, "effective_quantity", recordNumber),
            "effective_quantity",
            recordNumber,
            mustBePositive: true);
        var sendRunId = OptionalString(fields, indexes, "send_run_id");
        var deliveryDate = OptionalDate(
            OptionalString(fields, indexes, "delivery_date"),
            "delivery_date",
            recordNumber);
        var coordinationDescription = OptionalString(
            fields,
            indexes,
            "coordination_group_description");
        var comment = OptionalString(fields, indexes, "comment_1");
        var uom = OptionalString(fields, indexes, "uom");
        var purchasePrice = OptionalPrice(
            OptionalString(fields, indexes, "purchase_price"),
            recordNumber);
        var normalizedOrderType = OptionalString(fields, indexes, "order_type")
            ?.ToUpperInvariant();
        var orderType = ParseOrderType(normalizedOrderType, recordNumber);
        var tally = ParseTally(fields, indexes, recordNumber);

        return new RelexOrderProposalRecord(
            orderNumber,
            supplier,
            location,
            product,
            quantity,
            sendRunId,
            deliveryDate,
            coordinationDescription,
            comment,
            uom,
            purchasePrice,
            normalizedOrderType,
            orderType,
            tally);
    }

    private static string RequiredString(
        string[] fields,
        IReadOnlyDictionary<string, int> indexes,
        string fieldName,
        int recordNumber)
    {
        var value = OptionalString(fields, indexes, fieldName);
        if (value is null)
        {
            throw Error(
                MissingValueCode,
                "A required Relex CSV value is missing.",
                recordNumber,
                fieldName);
        }

        return value;
    }

    private static string? OptionalString(
        string[] fields,
        IReadOnlyDictionary<string, int> indexes,
        string fieldName)
    {
        if (!indexes.TryGetValue(fieldName, out var index))
        {
            return null;
        }

        var value = fields[index].Trim();
        return string.IsNullOrWhiteSpace(value) ? null : value;
    }

    private static int PositiveOrAnyInteger(
        string value,
        string fieldName,
        int recordNumber,
        bool mustBePositive)
    {
        if (!int.TryParse(
                value,
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out var result)
            || mustBePositive && result <= 0)
        {
            throw Error(
                InvalidValueCode,
                "A Relex CSV value is invalid.",
                recordNumber,
                fieldName);
        }

        return result;
    }

    private static DateOnly? OptionalDate(
        string? value,
        string fieldName,
        int recordNumber)
    {
        if (value is null)
        {
            return null;
        }

        if (!DateOnly.TryParseExact(
                value,
                ["dd/MM/yyyy", "yyyy-MM-dd"],
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out var date))
        {
            throw Error(
                InvalidValueCode,
                "A Relex CSV value is invalid.",
                recordNumber,
                fieldName);
        }

        return date;
    }

    private static float? OptionalPrice(string? value, int recordNumber)
    {
        if (value is null)
        {
            return null;
        }

        if (!float.TryParse(
                value,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out var price)
            || !float.IsFinite(price))
        {
            throw Error(
                InvalidValueCode,
                "A Relex CSV value is invalid.",
                recordNumber,
                "purchase_price");
        }

        return price;
    }

    private static PurchaseOrderType ParseOrderType(
        string? normalizedOrderType,
        int recordNumber)
    {
        if (normalizedOrderType is null or "NORMAL")
        {
            return PurchaseOrderType.Stock;
        }

        throw Error(
            InvalidValueCode,
            "A Relex CSV value is invalid.",
            recordNumber,
            "order_type");
    }

    private static List<PurchaseOrderTallyItem> ParseTally(
        string[] fields,
        IReadOnlyDictionary<string, int> indexes,
        int recordNumber)
    {
        var tally = new List<PurchaseOrderTallyItem>();
        for (var index = 1; index <= 21; index++)
        {
            var quantityField = $"tally_q_{index}";
            var lengthField = $"tally_l_{index}";
            var quantityValue = OptionalString(fields, indexes, quantityField);
            var lengthValue = OptionalString(fields, indexes, lengthField);

            if (quantityValue is null && lengthValue is null)
            {
                continue;
            }

            if (quantityValue is null)
            {
                throw Error(
                    MissingValueCode,
                    "A required Relex CSV value is missing.",
                    recordNumber,
                    quantityField);
            }

            if (lengthValue is null)
            {
                throw Error(
                    MissingValueCode,
                    "A required Relex CSV value is missing.",
                    recordNumber,
                    lengthField);
            }

            tally.Add(new PurchaseOrderTallyItem
            {
                Quantity = PositiveOrAnyInteger(
                    quantityValue,
                    quantityField,
                    recordNumber,
                    mustBePositive: true),
                Length = PositiveOrAnyInteger(
                    lengthValue,
                    lengthField,
                    recordNumber,
                    mustBePositive: true),
                Width = 0
            });
        }

        return tally;
    }

    private static HashSet<string> CreateKnownHeaders()
    {
        var headers = new HashSet<string>(
            RequiredHeaders,
            StringComparer.OrdinalIgnoreCase)
        {
            "send_run_id",
            "delivery_date",
            "coordination_group_description",
            "comment_1",
            "uom",
            "purchase_price",
            "order_type",
            "order_date"
        };

        for (var index = 1; index <= 21; index++)
        {
            headers.Add($"tally_q_{index}");
            headers.Add($"tally_l_{index}");
        }

        return headers;
    }

    private static RelexPurchaseOrderFileException Error(
        string code,
        string message,
        int? recordNumber = null,
        string? fieldName = null,
        Exception? innerException = null) =>
        new(code, message, recordNumber, fieldName, innerException);

    private sealed record RelexOrderProposalRecord(
        string OrderNumber,
        string Supplier,
        int Location,
        string Product,
        int Quantity,
        string? SendRunId,
        DateOnly? DeliveryDate,
        string? CoordinationDescription,
        string? Comment,
        string? Uom,
        float? PurchasePrice,
        string? NormalizedOrderType,
        PurchaseOrderType OrderType,
        List<PurchaseOrderTallyItem> Tally);

    private sealed class OrderAccumulator
    {
        private readonly string _orderNumber;
        private readonly string _supplier;
        private readonly int _location;
        private readonly string? _sendRunId;
        private readonly DateOnly? _deliveryDate;
        private readonly string? _coordinationDescription;
        private readonly string? _comment;
        private readonly string? _normalizedOrderType;
        private readonly PurchaseOrderType _orderType;
        private readonly List<PurchaseOrderLine> _lines = [];

        public OrderAccumulator(RelexOrderProposalRecord record)
        {
            _orderNumber = record.OrderNumber;
            _supplier = record.Supplier;
            _location = record.Location;
            _sendRunId = record.SendRunId;
            _deliveryDate = record.DeliveryDate;
            _coordinationDescription = record.CoordinationDescription;
            _comment = record.Comment;
            _normalizedOrderType = record.NormalizedOrderType;
            _orderType = record.OrderType;
            _lines.Add(CreateLine(record));
        }

        public void Add(RelexOrderProposalRecord record, int recordNumber)
        {
            EnsureConsistent(_supplier, record.Supplier, "supplier", recordNumber);
            EnsureConsistent(_location, record.Location, "location", recordNumber);
            EnsureConsistent(_sendRunId, record.SendRunId, "send_run_id", recordNumber);
            EnsureConsistent(
                _deliveryDate,
                record.DeliveryDate,
                "delivery_date",
                recordNumber);
            EnsureConsistent(
                _coordinationDescription,
                record.CoordinationDescription,
                "coordination_group_description",
                recordNumber);
            EnsureConsistent(_comment, record.Comment, "comment_1", recordNumber);
            EnsureConsistent(
                _normalizedOrderType,
                record.NormalizedOrderType,
                "order_type",
                recordNumber);
            _lines.Add(CreateLine(record));
        }

        public ParsedRelexPurchaseOrder ToResult()
        {
            var header = new PurchaseOrderHeader
            {
                Account = _supplier,
                Branch = _location,
                StockClass = 1,
                CreateUser = "APIRELEX_User",
                Reference = _orderNumber,
                DateExpected = _deliveryDate,
                Instructions = _coordinationDescription,
                Narrative = _comment,
                OrderType = _orderType,
                DeliveryMethod = PurchaseOrderDeliveryMethod.Delivery,
                SuspendOrder = true,
                ExtOrderRef = _sendRunId,
                ExtensionAttributes =
                [
                    new PurchaseOrderExtensionAttribute
                    {
                        Name = "packIgnore",
                        Value = "true"
                    }
                ]
            };

            return new ParsedRelexPurchaseOrder(
                new PurchaseOrder
                {
                    PurchaseOrderHeader = header,
                    PurchaseOrderLines = _lines
                },
                _lines.Count);
        }

        private static PurchaseOrderLine CreateLine(RelexOrderProposalRecord record) =>
            new()
            {
                ProductId = record.Product,
                StockClass = 1,
                Quantity = record.Quantity,
                Unit = record.Uom,
                DateExpected = record.DeliveryDate,
                SpecialInstructions = record.CoordinationDescription,
                Pricing = record.PurchasePrice is null
                    ? null
                    : new PurchaseOrderPricing { Price = record.PurchasePrice.Value },
                Tally = record.Tally
            };

        private static void EnsureConsistent<T>(
            T expected,
            T actual,
            string fieldName,
            int recordNumber)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
            {
                throw Error(
                    InconsistentOrderCode,
                    "Rows for one Relex order have inconsistent header values.",
                    recordNumber,
                    fieldName);
            }
        }
    }
}
