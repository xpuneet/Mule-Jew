using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Processor.Relex.Parsing;

public sealed record ParsedRelexPurchaseOrder(
    PurchaseOrder PurchaseOrder,
    int SourceRowCount);

public sealed record RelexFileProcessingResult(
    int ParsedRowCount,
    IReadOnlyList<ParsedRelexPurchaseOrder> PurchaseOrders);
