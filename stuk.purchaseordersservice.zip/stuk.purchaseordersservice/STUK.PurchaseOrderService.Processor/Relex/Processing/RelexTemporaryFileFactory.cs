namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

internal sealed class RelexTemporaryFileFactory : IRelexTemporaryFileFactory
{
    private const UnixFileMode UserReadWrite =
        UnixFileMode.UserRead | UnixFileMode.UserWrite;

    private readonly string _rootPath;

    public RelexTemporaryFileFactory()
        : this(Path.GetTempPath())
    {
    }

    internal RelexTemporaryFileFactory(string rootPath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(rootPath);
        _rootPath = Path.GetFullPath(rootPath);
    }

    public async ValueTask<RelexTemporaryFile> CreateAsync(
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var path = Path.Combine(
            _rootPath,
            $"stuk-relex-{Guid.NewGuid():N}.tmp");
        var options = new FileStreamOptions
        {
            Mode = FileMode.CreateNew,
            Access = FileAccess.ReadWrite,
            Share = FileShare.None,
            Options = FileOptions.Asynchronous | FileOptions.SequentialScan
        };
        if (!OperatingSystem.IsWindows())
        {
            options.UnixCreateMode = UserReadWrite;
        }

        try
        {
            await using var stream = new FileStream(path, options);
            await stream.FlushAsync(cancellationToken);
            return new RelexTemporaryFile(path);
        }
        catch
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }

            throw;
        }
    }
}
