namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

public interface IRelexIngestionService
{
    Task<RelexIngestionRunResult> RunAsync(
        CancellationToken cancellationToken = default);
}
