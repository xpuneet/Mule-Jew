using System.Text.Json;
using System.Text.Json.Serialization;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

internal sealed class RelexPurchaseOrderSerializer : IRelexPurchaseOrderSerializer
{
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web)
    {
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public string Serialize(PurchaseOrder purchaseOrder) =>
        JsonSerializer.Serialize(purchaseOrder, Options);
}
