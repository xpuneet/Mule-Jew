namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

internal interface IRelexTemporaryFileFactory
{
    ValueTask<RelexTemporaryFile> CreateAsync(
        CancellationToken cancellationToken);
}

internal sealed class RelexTemporaryFile : IAsyncDisposable
{
    public RelexTemporaryFile(string path)
    {
        Path = path;
    }

    public string Path { get; }

    public ValueTask DisposeAsync()
    {
        if (File.Exists(Path))
        {
            File.Delete(Path);
        }

        return ValueTask.CompletedTask;
    }
}
