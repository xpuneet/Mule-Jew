using System.IO.Enumeration;
using System.Globalization;
using System.Security.Cryptography;
using Microsoft.Extensions.Logging;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Common.Data.Sql;
using STUK.PurchaseOrderService.Processor.Relex.Files;
using STUK.PurchaseOrderService.Processor.Relex.Parsing;

namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

internal enum RelexFileProcessingOutcome
{
    Archived,
    FailedFile
}

internal delegate Task<RelexFileProcessingOutcome> RelexFileProcessor(
    RelexFileMetadata file,
    DateTimeOffset scanStartedUtc,
    CancellationToken cancellationToken);

internal sealed class RelexIngestionService : IRelexIngestionService
{
    private readonly IRelexFileStore _fileStore;
    private readonly RelexIngestionSettings _settings;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<RelexIngestionService> _logger;
    private readonly RelexFileProcessor _processFile;
    private readonly IRelexPurchaseOrderFileProcessor? _fileProcessor;
    private readonly IPurchaseOrderBatchRepository? _repository;
    private readonly IRelexPurchaseOrderSerializer? _serializer;
    private readonly IRelexTemporaryFileFactory? _temporaryFileFactory;

    internal RelexIngestionService(
        IRelexFileStore fileStore,
        RelexIngestionSettings settings,
        TimeProvider timeProvider,
        ILogger<RelexIngestionService> logger,
        IRelexPurchaseOrderFileProcessor fileProcessor,
        IPurchaseOrderBatchRepository repository,
        IRelexPurchaseOrderSerializer serializer,
        IRelexTemporaryFileFactory temporaryFileFactory)
    {
        _fileStore = fileStore ?? throw new ArgumentNullException(nameof(fileStore));
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _fileProcessor = fileProcessor ?? throw new ArgumentNullException(nameof(fileProcessor));
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _serializer = serializer ?? throw new ArgumentNullException(nameof(serializer));
        _temporaryFileFactory = temporaryFileFactory
            ?? throw new ArgumentNullException(nameof(temporaryFileFactory));
        _processFile = ProcessFileAsync;
    }

    internal RelexIngestionService(
        IRelexFileStore fileStore,
        RelexIngestionSettings settings,
        TimeProvider timeProvider,
        ILogger<RelexIngestionService> logger,
        RelexFileProcessor processFile)
    {
        _fileStore = fileStore ?? throw new ArgumentNullException(nameof(fileStore));
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _processFile = processFile ?? throw new ArgumentNullException(nameof(processFile));
    }

    public async Task<RelexIngestionRunResult> RunAsync(
        CancellationToken cancellationToken = default)
    {
        var scanStartedUtc = _timeProvider.GetUtcNow();
        var listedFiles = (await _fileStore.ListFilesAsync(
                _settings.InputPath,
                cancellationToken))
            .ToArray();
        var minimumLastModifiedUtc = scanStartedUtc.AddSeconds(
            -_settings.MinimumFileAgeSeconds);
        var eligibleFiles = new List<RelexFileMetadata>();
        var deferred = 0;
        var ignored = 0;

        foreach (var file in listedFiles)
        {
            if (!FileSystemName.MatchesSimpleExpression(
                    _settings.FilePattern,
                    file.Name,
                    ignoreCase: true))
            {
                ignored++;
                _logger.LogDebug(
                    "Relex input file ignored. FileName={FileName}, ResultCode={ResultCode}.",
                    file.Name,
                    "FILE_PATTERN_MISMATCH");
                continue;
            }

            if (file.LastModifiedUtc > minimumLastModifiedUtc)
            {
                deferred++;
                continue;
            }

            eligibleFiles.Add(file);
        }

        var orderedSnapshot = eligibleFiles
            .OrderBy(file => file.LastModifiedUtc)
            .ThenBy(file => file.Name, StringComparer.Ordinal)
            .ToArray();
        var archived = 0;
        var failedFiles = 0;
        var transientFailures = 0;

        foreach (var file in orderedSnapshot)
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                var outcome = await _processFile(
                    file,
                    scanStartedUtc,
                    cancellationToken);
                if (outcome == RelexFileProcessingOutcome.Archived)
                {
                    archived++;
                }
                else
                {
                    failedFiles++;
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception exception)
            {
                transientFailures++;
                _logger.LogError(
                    "Relex input file processing failed. FileName={FileName}, FilePath={FilePath}, ResultCode={ResultCode}, FailureType={FailureType}.",
                    file.Name,
                    file.Path,
                    "TRANSIENT_FAILURE",
                    exception.GetType().Name);
            }
        }

        return new RelexIngestionRunResult(
            listedFiles.Length,
            deferred,
            ignored,
            archived,
            failedFiles,
            transientFailures);
    }

    private async Task<RelexFileProcessingOutcome> ProcessFileAsync(
        RelexFileMetadata file,
        DateTimeOffset scanStartedUtc,
        CancellationToken cancellationToken)
    {
        var startedTimestamp = _timeProvider.GetTimestamp();
        await using var temporaryFile = await _temporaryFileFactory!.CreateAsync(
            cancellationToken);
        await using var scratchStream = new FileStream(
            temporaryFile.Path,
            FileMode.Open,
            FileAccess.ReadWrite,
            FileShare.None,
            bufferSize: 81920,
            FileOptions.Asynchronous | FileOptions.SequentialScan);

        await _fileStore.DownloadAsync(file.Path, scratchStream, cancellationToken);
        await scratchStream.FlushAsync(cancellationToken);
        scratchStream.Position = 0;
        var fileSha256 = await SHA256.HashDataAsync(
            scratchStream,
            cancellationToken);
        var fileLength = scratchStream.Length;
        var hashPrefix = Convert.ToHexString(fileSha256.AsSpan(0, 4))
            .ToLowerInvariant();

        _logger.LogInformation(
            "Relex input file staged. FileName={FileName}, FilePath={FilePath}, HashPrefix={HashPrefix}, FileLength={FileLength}, ResultCode={ResultCode}.",
            file.Name,
            file.Path,
            hashPrefix,
            fileLength,
            "STAGED");

        var batch = await RegisterOrGetBatchAsync(
            file,
            fileLength,
            fileSha256,
            scanStartedUtc,
            cancellationToken);

        if (IsArchivable(batch.Status))
        {
            await MoveToDestinationAsync(
                file,
                _settings.ArchivePath,
                fileSha256,
                batch.BatchId,
                "ARCHIVED_RECONCILED",
                startedTimestamp,
                cancellationToken);
            return RelexFileProcessingOutcome.Archived;
        }

        if (string.Equals(
                batch.Status,
                PurchaseOrderBatchStatuses.Failed,
                StringComparison.Ordinal))
        {
            await MoveToDestinationAsync(
                file,
                _settings.ErrorPath,
                fileSha256,
                batch.BatchId,
                "ERROR_RECONCILED",
                startedTimestamp,
                cancellationToken);
            return RelexFileProcessingOutcome.FailedFile;
        }

        if (!string.Equals(
                batch.Status,
                PurchaseOrderBatchStatuses.Ingesting,
                StringComparison.Ordinal))
        {
            throw new InvalidOperationException(
                $"Relex batch has unsupported status '{batch.Status}'.");
        }

        RelexFileProcessingResult parsed;
        try
        {
            scratchStream.Position = 0;
            parsed = _fileProcessor!.Process(scratchStream, cancellationToken);
        }
        catch (RelexPurchaseOrderFileException exception)
        {
            var errorPath = await MoveToDestinationAsync(
                file,
                _settings.ErrorPath,
                fileSha256,
                batch.BatchId,
                exception.Code,
                startedTimestamp,
                cancellationToken);

            try
            {
                await _repository!.FailBatchAsync(
                    new FailPurchaseOrderBatchCommand(
                        batch.BatchId,
                        exception.Code,
                        exception.Message,
                        _timeProvider.GetUtcNow(),
                        _settings.Actor,
                        batch.RowVersion),
                    cancellationToken);
            }
            catch (Exception persistenceException)
            {
                await RestoreInputAfterPersistenceFailureAsync(
                    file,
                    errorPath,
                    batch.BatchId,
                    persistenceException);
                throw;
            }

            return RelexFileProcessingOutcome.FailedFile;
        }

        foreach (var parsedOrder in parsed.PurchaseOrders)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var header = parsedOrder.PurchaseOrder.PurchaseOrderHeader
                ?? throw new InvalidOperationException(
                    "Relex parser returned an order without a header.");
            var account = header.Account
                ?? throw new InvalidOperationException(
                    "Relex parser returned an order without an account.");
            var reference = header.Reference
                ?? throw new InvalidOperationException(
                    "Relex parser returned an order without a reference.");

            await _repository!.AddCandidateAsync(
                new AddPurchaseOrderCandidateToBatchCommand(
                    batch.BatchId,
                    RelexCandidateId.Create(batch.BatchId, reference),
                    account,
                    header.Branch.ToString(CultureInfo.InvariantCulture),
                    reference,
                    parsedOrder.SourceRowCount,
                    _timeProvider.GetUtcNow(),
                    _serializer!.Serialize(parsedOrder.PurchaseOrder),
                    _settings.Actor),
                cancellationToken);
        }

        var latestBatch = await _repository!.GetBatchAsync(
            batch.BatchId,
            cancellationToken);
        var archivePath = await MoveToDestinationAsync(
            file,
            _settings.ArchivePath,
            fileSha256,
            batch.BatchId,
            "ARCHIVED",
            startedTimestamp,
            cancellationToken);

        try
        {
            await _repository.CompleteBatchAsync(
                new CompletePurchaseOrderBatchCommand(
                    batch.BatchId,
                    parsed.PurchaseOrders.Count,
                    parsed.ParsedRowCount,
                    _timeProvider.GetUtcNow(),
                    _settings.Actor,
                    latestBatch.RowVersion),
                cancellationToken);
        }
        catch (Exception persistenceException)
        {
            await RestoreInputAfterPersistenceFailureAsync(
                file,
                archivePath,
                batch.BatchId,
                persistenceException);
            throw;
        }

        _logger.LogInformation(
            "Relex input file persisted. FileName={FileName}, FilePath={FilePath}, BatchId={BatchId}, HashPrefix={HashPrefix}, FileLength={FileLength}, ParsedRowCount={ParsedRowCount}, CandidateCount={CandidateCount}, ResultCode={ResultCode}.",
            file.Name,
            file.Path,
            batch.BatchId,
            hashPrefix,
            fileLength,
            parsed.ParsedRowCount,
            parsed.PurchaseOrders.Count,
            "PERSISTED");
        return RelexFileProcessingOutcome.Archived;
    }

    private async Task<RelexBatchSnapshot> RegisterOrGetBatchAsync(
        RelexFileMetadata file,
        long fileLength,
        byte[] fileSha256,
        DateTimeOffset scanStartedUtc,
        CancellationToken cancellationToken)
    {
        try
        {
            var registered = await _repository!.RegisterBatchAsync(
                new RegisterPurchaseOrderBatchCommand(
                    Guid.NewGuid(),
                    file.Name,
                    file.Path,
                    fileLength,
                    fileSha256,
                    null,
                    scanStartedUtc,
                    _settings.Actor),
                cancellationToken);
            return new RelexBatchSnapshot(
                registered.BatchId,
                registered.Status,
                registered.RowVersion);
        }
        catch (PurchaseOrderPersistenceException exception)
            when (exception.Error == PurchaseOrderPersistenceError.DuplicateSourceFile)
        {
            var existing = await _repository!.GetBatchBySourceHashAsync(
                PurchaseOrderSources.Relex,
                fileSha256,
                cancellationToken);
            return new RelexBatchSnapshot(
                existing.BatchId,
                existing.Status,
                existing.RowVersion);
        }
    }

    private async Task<string> MoveToDestinationAsync(
        RelexFileMetadata file,
        string destinationDirectory,
        byte[] fileSha256,
        Guid batchId,
        string resultCode,
        long startedTimestamp,
        CancellationToken cancellationToken)
    {
        var destinationPath = await ResolveDestinationPathAsync(
            destinationDirectory,
            file.Name,
            fileSha256,
            cancellationToken);
        await _fileStore.MoveAsync(
            file.Path,
            destinationPath,
            cancellationToken);

        _logger.LogInformation(
            "Relex input file moved. FileName={FileName}, FilePath={FilePath}, BatchId={BatchId}, HashPrefix={HashPrefix}, Destination={Destination}, ResultCode={ResultCode}, ElapsedMilliseconds={ElapsedMilliseconds}.",
            file.Name,
            file.Path,
            batchId,
            Convert.ToHexString(fileSha256.AsSpan(0, 4)).ToLowerInvariant(),
            destinationPath,
            resultCode,
            _timeProvider.GetElapsedTime(startedTimestamp).TotalMilliseconds);

        return destinationPath;
    }

    private async Task RestoreInputAfterPersistenceFailureAsync(
        RelexFileMetadata file,
        string movedPath,
        Guid batchId,
        Exception persistenceException)
    {
        try
        {
            await _fileStore.MoveAsync(
                movedPath,
                file.Path,
                CancellationToken.None);

            _logger.LogWarning(
                "Relex input file move compensated after persistence failure. FileName={FileName}, FilePath={FilePath}, BatchId={BatchId}, MovedPath={MovedPath}, ResultCode={ResultCode}, FailureType={FailureType}.",
                file.Name,
                file.Path,
                batchId,
                movedPath,
                "MOVE_COMPENSATED",
                persistenceException.GetType().Name);
        }
        catch (Exception compensationException)
        {
            throw new AggregateException(
                "Relex persistence and compensating file move both failed.",
                persistenceException,
                compensationException);
        }
    }

    private async Task<string> ResolveDestinationPathAsync(
        string destinationDirectory,
        string fileName,
        byte[] fileSha256,
        CancellationToken cancellationToken)
    {
        var originalDestination = RelexFilePath.Combine(
            destinationDirectory,
            fileName);
        if (!await _fileStore.ExistsAsync(originalDestination, cancellationToken))
        {
            return originalDestination;
        }

        var hashPrefix = Convert.ToHexString(fileSha256.AsSpan(0, 4))
            .ToLowerInvariant();
        var hashQualifiedName = string.Concat(
            Path.GetFileNameWithoutExtension(fileName),
            "-",
            hashPrefix,
            Path.GetExtension(fileName));
        var hashQualifiedDestination = RelexFilePath.Combine(
            destinationDirectory,
            hashQualifiedName);
        if (!await _fileStore.ExistsAsync(
                hashQualifiedDestination,
                cancellationToken))
        {
            return hashQualifiedDestination;
        }

        throw new IOException(
            "A Relex destination already exists for both the original and content-qualified file names.");
    }

    private static bool IsArchivable(string status) =>
        string.Equals(
            status,
            PurchaseOrderBatchStatuses.Completed,
            StringComparison.Ordinal);

    private sealed record RelexBatchSnapshot(
        Guid BatchId,
        string Status,
        byte[] RowVersion);
}
