using System.Security.Cryptography;
using System.Text;

namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

internal static class RelexCandidateId
{
    public static Guid Create(Guid batchId, string orderNumber)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(orderNumber);
        var input = $"{batchId:N}:{orderNumber.Trim()}";
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return new Guid(hash.AsSpan(0, 16));
    }
}
