using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

internal interface IRelexPurchaseOrderSerializer
{
    string Serialize(PurchaseOrder purchaseOrder);
}
