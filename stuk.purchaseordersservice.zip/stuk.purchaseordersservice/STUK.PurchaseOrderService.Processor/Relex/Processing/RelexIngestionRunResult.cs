namespace STUK.PurchaseOrderService.Processor.Relex.Processing;

public sealed record RelexIngestionRunResult(
    int Discovered,
    int Deferred,
    int Ignored,
    int Archived,
    int FailedFiles,
    int TransientFailures);
