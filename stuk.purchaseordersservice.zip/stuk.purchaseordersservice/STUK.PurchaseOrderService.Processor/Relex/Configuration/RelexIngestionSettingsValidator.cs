using Microsoft.Extensions.Options;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Relex.Configuration;

public sealed class RelexIngestionSettingsValidator : IValidateOptions<RelexIngestionSettings>
{
    public ValidateOptionsResult Validate(string? name, RelexIngestionSettings options)
    {
        var failures = new List<string>();

        ValidateLogicalPath(options.InputPath, nameof(options.InputPath), failures);
        ValidateLogicalPath(options.ArchivePath, nameof(options.ArchivePath), failures);
        ValidateLogicalPath(options.ErrorPath, nameof(options.ErrorPath), failures);

        if (LogicalPathsOverlap(
                options.InputPath,
                options.ArchivePath,
                options.ErrorPath))
        {
            failures.Add("RelexIngestionSettings logical paths must not overlap.");
        }

        if (string.IsNullOrWhiteSpace(options.FilePattern)
            || options.FilePattern.Contains('/')
            || options.FilePattern.Contains('\\'))
        {
            failures.Add(
                "RelexIngestionSettings:FilePattern must be a file-name pattern without path separators.");
        }

        if (options.MinimumFileAgeSeconds < 0)
        {
            failures.Add(
                "RelexIngestionSettings:MinimumFileAgeSeconds cannot be negative.");
        }

        if (string.IsNullOrWhiteSpace(options.Actor))
        {
            failures.Add("RelexIngestionSettings:Actor must not be blank.");
        }

        if (options.OperationTimeoutSeconds is < 1 or > 300)
        {
            failures.Add(
                "RelexIngestionSettings:OperationTimeoutSeconds must be between 1 and 300.");
        }

        switch (options.Provider)
        {
            case RelexFileStoreProvider.Local:
                ValidateLocal(options, failures);
                break;
            case RelexFileStoreProvider.Sftp:
                ValidateSftp(options, failures);
                break;
            default:
                failures.Add("RelexIngestionSettings:Provider is not supported.");
                break;
        }

        return failures.Count == 0
            ? ValidateOptionsResult.Success
            : ValidateOptionsResult.Fail(failures);
    }

    private static void ValidateLocal(
        RelexIngestionSettings options,
        ICollection<string> failures)
    {
        if (string.IsNullOrWhiteSpace(options.LocalRootPath)
            || !Path.IsPathFullyQualified(options.LocalRootPath))
        {
            failures.Add(
                "RelexIngestionSettings:LocalRootPath must be fully qualified for the Local provider.");
        }
    }

    private static void ValidateSftp(
        RelexIngestionSettings options,
        ICollection<string> failures)
    {
        if (string.IsNullOrWhiteSpace(options.SftpHost))
        {
            failures.Add("RelexIngestionSettings:SftpHost is required for the Sftp provider.");
        }

        if (options.SftpPort is < 1 or > 65535)
        {
            failures.Add("RelexIngestionSettings:SftpPort must be between 1 and 65535.");
        }

        if (string.IsNullOrWhiteSpace(options.SftpUsername))
        {
            failures.Add(
                "RelexIngestionSettings:SftpUsername is required for the Sftp provider.");
        }

        if (string.IsNullOrWhiteSpace(options.SftpPassword))
        {
            failures.Add(
                "RelexIngestionSettings:SftpPassword is required for the Sftp provider.");
        }
    }

    private static void ValidateLogicalPath(
        string? value,
        string propertyName,
        ICollection<string> failures)
    {
        if (!IsSafeLogicalPath(value))
        {
            failures.Add(
                $"RelexIngestionSettings:{propertyName} must be an absolute logical path without dot segments.");
        }
    }

    private static bool IsSafeLogicalPath(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) || !value.StartsWith('/'))
        {
            return false;
        }

        return value
            .Split('/', StringSplitOptions.RemoveEmptyEntries)
            .All(segment => segment is not "." and not "..");
    }

    private static bool LogicalPathsOverlap(params string?[] paths)
    {
        var safePaths = paths
            .Where(IsSafeLogicalPath)
            .Select(path => path!.TrimEnd('/'))
            .ToArray();

        for (var leftIndex = 0; leftIndex < safePaths.Length; leftIndex++)
        {
            for (var rightIndex = leftIndex + 1; rightIndex < safePaths.Length; rightIndex++)
            {
                var left = safePaths[leftIndex];
                var right = safePaths[rightIndex];
                if (string.Equals(left, right, StringComparison.Ordinal)
                    || left.StartsWith($"{right}/", StringComparison.Ordinal)
                    || right.StartsWith($"{left}/", StringComparison.Ordinal))
                {
                    return true;
                }
            }
        }

        return false;
    }
}
