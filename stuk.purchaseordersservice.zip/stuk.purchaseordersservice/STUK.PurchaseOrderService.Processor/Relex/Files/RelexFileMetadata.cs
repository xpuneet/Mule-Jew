namespace STUK.PurchaseOrderService.Processor.Relex.Files;

public sealed record RelexFileMetadata(
    string Path,
    string Name,
    long Length,
    DateTimeOffset LastModifiedUtc);
