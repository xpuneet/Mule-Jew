namespace STUK.PurchaseOrderService.Processor.Relex.Files;

public interface IRelexFileStore
{
    Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
        string directoryPath,
        CancellationToken cancellationToken);

    Task DownloadAsync(
        string sourcePath,
        Stream destination,
        CancellationToken cancellationToken);

    Task<bool> ExistsAsync(
        string path,
        CancellationToken cancellationToken);

    Task MoveAsync(
        string sourcePath,
        string destinationPath,
        CancellationToken cancellationToken);
}
