namespace STUK.PurchaseOrderService.Processor.Relex.Files;

public sealed class LocalRelexFileStore : IRelexFileStore
{
    private readonly string _normalizedRoot;
    private readonly string _normalizedRootWithSeparator;
    private readonly StringComparison _pathComparison;

    public LocalRelexFileStore(string rootPath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(rootPath);

        _normalizedRoot = Path.TrimEndingDirectorySeparator(
            Path.GetFullPath(rootPath));
        _normalizedRootWithSeparator = _normalizedRoot + Path.DirectorySeparatorChar;
        _pathComparison = OperatingSystem.IsWindows()
            ? StringComparison.OrdinalIgnoreCase
            : StringComparison.Ordinal;
    }

    public Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
        string directoryPath,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var physicalDirectoryPath = MapToPhysicalPath(directoryPath);

        IReadOnlyList<RelexFileMetadata> files = Directory
            .EnumerateFiles(
                physicalDirectoryPath,
                "*",
                SearchOption.TopDirectoryOnly)
            .Select(path =>
            {
                cancellationToken.ThrowIfCancellationRequested();
                var file = new FileInfo(path);
                return new RelexFileMetadata(
                    RelexFilePath.Combine(directoryPath, file.Name),
                    file.Name,
                    file.Length,
                    new DateTimeOffset(file.LastWriteTimeUtc, TimeSpan.Zero));
            })
            .ToArray();

        return Task.FromResult(files);
    }

    public async Task DownloadAsync(
        string sourcePath,
        Stream destination,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(destination);
        var physicalSourcePath = MapToPhysicalPath(sourcePath);

        await using var source = new FileStream(
            physicalSourcePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            bufferSize: 81920,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
        await source.CopyToAsync(destination, cancellationToken);
    }

    public Task<bool> ExistsAsync(
        string path,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(File.Exists(MapToPhysicalPath(path)));
    }

    public Task MoveAsync(
        string sourcePath,
        string destinationPath,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        File.Move(
            MapToPhysicalPath(sourcePath),
            MapToPhysicalPath(destinationPath),
            overwrite: false);
        return Task.CompletedTask;
    }

    private string MapToPhysicalPath(string logicalPath)
    {
        RelexFilePath.Validate(logicalPath, nameof(logicalPath));
        var relativePath = logicalPath[1..]
            .Replace('/', Path.DirectorySeparatorChar);
        var physicalPath = Path.GetFullPath(
            Path.Combine(_normalizedRoot, relativePath));

        if (!physicalPath.StartsWith(
                _normalizedRootWithSeparator,
                _pathComparison))
        {
            throw new ArgumentException(
                "The Relex path resolves outside the configured local root.",
                nameof(logicalPath));
        }

        return physicalPath;
    }
}
