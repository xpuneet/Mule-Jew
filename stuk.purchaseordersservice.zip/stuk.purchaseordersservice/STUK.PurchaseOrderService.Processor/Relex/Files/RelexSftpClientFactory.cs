using Renci.SshNet;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Relex.Files;

internal interface IRelexSftpClientFactory
{
    RelexSftpClientLease Create();
}

internal sealed class RelexSftpClientFactory : IRelexSftpClientFactory
{
    private readonly RelexIngestionSettings _settings;

    public RelexSftpClientFactory(RelexIngestionSettings settings)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
    }

    public RelexSftpClientLease Create()
    {
        var ownedResources = new List<IDisposable>();

        try
        {
            var authenticationMethod = CreateAuthenticationMethod(ownedResources);
            var connectionInfo = new ConnectionInfo(
                _settings.SftpHost
                ?? throw new InvalidOperationException("SFTP settings are incomplete."),
                _settings.SftpPort,
                _settings.SftpUsername
                ?? throw new InvalidOperationException("SFTP settings are incomplete."),
                authenticationMethod)
            {
                Timeout = TimeSpan.FromSeconds(_settings.OperationTimeoutSeconds)
            };

            var client = new SftpClient(connectionInfo)
            {
                OperationTimeout = TimeSpan.FromSeconds(_settings.OperationTimeoutSeconds)
            };

            return new RelexSftpClientLease(client, ownedResources);
        }
        catch
        {
            DisposeResources(ownedResources);
            throw;
        }
    }

    private AuthenticationMethod CreateAuthenticationMethod(
        ICollection<IDisposable> ownedResources)
    {
        var username = _settings.SftpUsername
            ?? throw new InvalidOperationException("SFTP settings are incomplete.");

        var passwordAuthentication = new PasswordAuthenticationMethod(
            username,
            _settings.SftpPassword
            ?? throw new InvalidOperationException("SFTP settings are incomplete."));
        ownedResources.Add(passwordAuthentication);
        return passwordAuthentication;
    }

    private static void DisposeResources(IEnumerable<IDisposable> resources)
    {
        foreach (var resource in resources.Reverse())
        {
            resource.Dispose();
        }
    }
}

internal sealed class RelexSftpClientLease : IDisposable
{
    private readonly IReadOnlyList<IDisposable> _ownedResources;

    public RelexSftpClientLease(
        SftpClient client,
        IReadOnlyList<IDisposable> ownedResources)
    {
        Client = client;
        _ownedResources = ownedResources;
    }

    public SftpClient Client { get; }

    public void Dispose()
    {
        Client.Dispose();
        foreach (var resource in _ownedResources.Reverse())
        {
            resource.Dispose();
        }
    }
}
