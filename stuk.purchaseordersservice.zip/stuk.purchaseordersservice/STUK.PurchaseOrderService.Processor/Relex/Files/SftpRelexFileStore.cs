using Renci.SshNet.Common;
using STUK.PurchaseOrderService.Common.Contracts.Config;

namespace STUK.PurchaseOrderService.Processor.Relex.Files;

public sealed class SftpRelexFileStore : IRelexFileStore
{
    private readonly IRelexSftpClientFactory _clientFactory;

    public SftpRelexFileStore(RelexIngestionSettings settings)
        : this(new RelexSftpClientFactory(settings))
    {
    }

    internal SftpRelexFileStore(IRelexSftpClientFactory clientFactory)
    {
        _clientFactory = clientFactory;
    }

    public async Task<IReadOnlyList<RelexFileMetadata>> ListFilesAsync(
        string directoryPath,
        CancellationToken cancellationToken)
    {
        RelexFilePath.Validate(directoryPath, nameof(directoryPath));
        using var lease = _clientFactory.Create();
        await lease.Client.ConnectAsync(cancellationToken);

        var files = new List<RelexFileMetadata>();
        await foreach (var entry in lease.Client.ListDirectoryAsync(
                           directoryPath,
                           cancellationToken))
        {
            if (entry.IsRegularFile)
            {
                files.Add(new RelexFileMetadata(
                    entry.FullName,
                    entry.Name,
                    entry.Attributes.Size,
                    new DateTimeOffset(entry.LastWriteTimeUtc, TimeSpan.Zero)));
            }
        }

        return files;
    }

    public async Task DownloadAsync(
        string sourcePath,
        Stream destination,
        CancellationToken cancellationToken)
    {
        RelexFilePath.Validate(sourcePath, nameof(sourcePath));
        ArgumentNullException.ThrowIfNull(destination);
        using var lease = _clientFactory.Create();
        await lease.Client.ConnectAsync(cancellationToken);
        await lease.Client.DownloadFileAsync(
            sourcePath,
            destination,
            cancellationToken);
    }

    public async Task<bool> ExistsAsync(
        string path,
        CancellationToken cancellationToken)
    {
        RelexFilePath.Validate(path, nameof(path));
        using var lease = _clientFactory.Create();
        await lease.Client.ConnectAsync(cancellationToken);

        try
        {
            await lease.Client.GetAttributesAsync(path, cancellationToken);
            return true;
        }
        catch (SftpPathNotFoundException)
        {
            return false;
        }
    }

    public async Task MoveAsync(
        string sourcePath,
        string destinationPath,
        CancellationToken cancellationToken)
    {
        RelexFilePath.Validate(sourcePath, nameof(sourcePath));
        RelexFilePath.Validate(destinationPath, nameof(destinationPath));
        using var lease = _clientFactory.Create();
        await lease.Client.ConnectAsync(cancellationToken);
        await lease.Client.RenameFileAsync(
            sourcePath,
            destinationPath,
            cancellationToken);
    }
}
