namespace STUK.PurchaseOrderService.Processor.Relex.Files;

internal static class RelexFilePath
{
    public static string Validate(string path, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(path)
            || path[0] != '/'
            || path.Contains('\\'))
        {
            throw new ArgumentException(
                "A Relex path must be absolute and use forward slashes.",
                parameterName);
        }

        var segments = path[1..].Split('/');
        if (segments.Any(segment =>
                string.IsNullOrEmpty(segment)
                || segment is "." or ".."))
        {
            throw new ArgumentException(
                "A Relex path must not contain empty or dot segments.",
                parameterName);
        }

        return path;
    }

    public static string Combine(string directoryPath, string fileName)
    {
        Validate(directoryPath, nameof(directoryPath));

        if (string.IsNullOrWhiteSpace(fileName)
            || fileName is "." or ".."
            || fileName.Contains('/')
            || fileName.Contains('\\'))
        {
            throw new ArgumentException(
                "A Relex file name must not be empty or contain path separators.",
                nameof(fileName));
        }

        return $"{directoryPath}/{fileName}";
    }
}
