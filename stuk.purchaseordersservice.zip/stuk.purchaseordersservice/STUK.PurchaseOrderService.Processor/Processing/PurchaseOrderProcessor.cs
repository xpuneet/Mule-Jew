using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Icon = STUK.IconIntegration.IconClient;
using STUK.IconIntegration.Configuration;
using STUK.IconIntegration.Reports.Account;
using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;
using STUK.PurchaseOrderService.Common.Contracts.Config;
using STUK.PurchaseOrderService.Common.Data.Repositories;
using STUK.PurchaseOrderService.Common.Data.Repositories.Models;
using STUK.PurchaseOrderService.Processor.Mapping;
using STUK.PurchaseOrderService.Processor.Services;
using System.Globalization;
using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace STUK.PurchaseOrderService.Processor.Processing;

public sealed class PurchaseOrderProcessor : IPurchaseOrderProcessor
{
    private const short ClaimSize = 1;
    private const string RecoverableErrorStatus = "RECOVERABLE_ERROR";
    private const string NonRecoverableErrorStatus = "NON_RECOVERABLE_ERROR";

    private static readonly JsonSerializerOptions CanonicalSerializerOptions =
        new(JsonSerializerDefaults.Web);

    private readonly BatchProcessorSettings _settings;
    private readonly IconSettings _iconSettings;
    private readonly IPurchaseOrderProcessingRepository _repository;
    private readonly IIconPurchaseOrderService _iconService;
    private readonly IPurchaseOrderIconMapper _mapper;
    private readonly ILogger<PurchaseOrderProcessor> _logger;
    private readonly string _workerId;

    public PurchaseOrderProcessor(
        IOptions<BatchProcessorSettings> settings,
        IOptions<IconSettings> iconSettings,
        IPurchaseOrderProcessingRepository repository,
        IIconPurchaseOrderService iconService,
        IPurchaseOrderIconMapper mapper,
        ILogger<PurchaseOrderProcessor> logger)
    {
        ArgumentNullException.ThrowIfNull(settings);
        ArgumentNullException.ThrowIfNull(iconSettings);
        ArgumentNullException.ThrowIfNull(repository);
        ArgumentNullException.ThrowIfNull(iconService);
        ArgumentNullException.ThrowIfNull(mapper);
        ArgumentNullException.ThrowIfNull(logger);

        _settings = settings.Value;
        _iconSettings = iconSettings.Value;
        _repository = repository;
        _iconService = iconService;
        _mapper = mapper;
        _logger = logger;
        _workerId = BuildWorkerId();
    }

    public async Task<ProcessingResult> ProcessReadyCandidatesAsync(
        CancellationToken cancellationToken = default)
    {
        if (!_settings.SubmissionEnabled)
        {
            _logger.LogInformation("Purchase order submission is disabled.");
            return new ProcessingResult(0, 0, 0);
        }

        await _repository.ExpireClaimsAsync(
            new ExpirePurchaseOrderClaimsCommand(_workerId),
            cancellationToken);

        var candidates = await _repository.ClaimCandidatesAsync(
            new ClaimPurchaseOrderCandidatesCommand(
                _workerId,
                ClaimSize,
                _settings.LeaseDurationSeconds),
            cancellationToken);

        if (candidates.Count == 0)
        {
            return new ProcessingResult(0, 0, 0);
        }

        if (candidates.Count != 1)
        {
            throw new InvalidOperationException(
                $"The claim procedure returned {candidates.Count} candidates for a claim size of one.");
        }

        return await ProcessCandidateAsync(candidates[0], cancellationToken);
    }

    private async Task<ProcessingResult> ProcessCandidateAsync(
        ClaimedPurchaseOrderCandidate candidate,
        CancellationToken cancellationToken)
    {
        PurchaseOrder purchaseOrder;
        try
        {
            purchaseOrder = System.Text.Json.JsonSerializer.Deserialize<PurchaseOrder>(
                    candidate.PayloadJson,
                    CanonicalSerializerOptions)
                ?? throw new System.Text.Json.JsonException(
                    "The canonical purchase order payload deserialized to null.");
        }
        catch (Exception exception) when (
            exception is System.Text.Json.JsonException or NotSupportedException)
        {
            return await FailBeforeDispatchAsync(
                candidate,
                NonRecoverableErrorStatus,
                "CANONICAL_DESERIALIZATION",
                "CANONICAL_DESERIALIZATION_FAILED",
                exception.Message);
        }

        var account = purchaseOrder.PurchaseOrderHeader?.Account;
        if (string.IsNullOrWhiteSpace(account))
        {
            return await FailBeforeDispatchAsync(
                candidate,
                NonRecoverableErrorStatus,
                "CANONICAL_DESERIALIZATION",
                "CANONICAL_ACCOUNT_MISSING",
                "The canonical purchase order header account is required.");
        }

        PurchaseOrderActivationOptionsResult activationOptions;
        try
        {
            var activationResponse = await _iconService.GetPurchaseOrderActivationOptions(
                account,
                cancellationToken);
            var matchingResults = activationResponse.Response?.Results?
                .Where(result => string.Equals(
                    result.Account,
                    account,
                    StringComparison.OrdinalIgnoreCase))
                .ToList() ?? [];

            if (matchingResults.Count != 1)
            {
                return await FailBeforeDispatchAsync(
                    candidate,
                    NonRecoverableErrorStatus,
                    "ACTIVATION_OPTIONS",
                    "ACTIVATION_OPTIONS_INVALID",
                    $"Expected one activation result for the candidate account but received {matchingResults.Count}.");
            }

            activationOptions = matchingResults[0];
        }
        catch (Exception exception) when (
            exception is HttpRequestException
                or OperationCanceledException
                or Icon.ApiException)
        {
            return await FailBeforeDispatchAsync(
                candidate,
                RecoverableErrorStatus,
                "ACTIVATION_TRANSPORT",
                "ACTIVATION_REQUEST_FAILED",
                exception.Message);
        }

        Icon.IconCreatePurchaseOrderRequest iconRequest;
        try
        {
            iconRequest = _mapper.Map(purchaseOrder, activationOptions);
            Icon.PurchaseOrderRequestValidator.ValidateAndThrow(iconRequest);
        }
        catch (Exception exception) when (
            exception is PurchaseOrderIconMappingException
                or Icon.PurchaseOrderValidationException)
        {
            return await FailBeforeDispatchAsync(
                candidate,
                NonRecoverableErrorStatus,
                "ICON_MAPPING",
                "ICON_MAPPING_FAILED",
                exception.Message);
        }

        string requestPayloadJson;
        try
        {
            requestPayloadJson = JsonConvert.SerializeObject(iconRequest);
        }
        catch (JsonSerializationException exception)
        {
            return await FailBeforeDispatchAsync(
                candidate,
                NonRecoverableErrorStatus,
                "ICON_MAPPING",
                "ICON_REQUEST_SERIALIZATION_FAILED",
                exception.Message);
        }

        var requiredLeaseDurationSeconds = checked(
            _iconSettings.HttpRequestTimeoutSeconds
            + _settings.OutcomePersistenceTimeoutSeconds
            + 1);
        await _repository.RenewClaimAsync(
            new RenewPurchaseOrderClaimCommand(
                candidate.CandidateId,
                candidate.LeaseToken,
                _workerId,
                requiredLeaseDurationSeconds),
            cancellationToken);

        var attemptId = Guid.NewGuid();
        await _repository.BeginSubmissionAttemptAsync(
            new BeginPurchaseOrderSubmissionAttemptCommand(
                attemptId,
                candidate.CandidateId,
                candidate.LeaseToken,
                _workerId,
                requestPayloadJson),
            cancellationToken);

        Icon.IconCreatePurchaseOrderResponse response;
        try
        {
            response = await _iconService.CreatePurchaseOrderAsync(
                iconRequest,
                cancellationToken);
        }
        catch (Icon.ApiException exception) when (IsUnambiguousClientFailure(exception.StatusCode))
        {
            return await FailAfterDispatchAsync(
                candidate,
                attemptId,
                "ICON_HTTP_ERROR",
                $"ICON_HTTP_{exception.StatusCode}",
                exception.Message,
                checked((short)exception.StatusCode),
                NormalizeResponsePayload(exception.Response),
                attemptStatus: "FAILED");
        }
        catch (OperationCanceledException exception)
        {
            return await FailAfterDispatchAsync(
                candidate,
                attemptId,
                "ICON_UNKNOWN_OUTCOME",
                "ICON_DISPATCH_CANCELLED",
                exception.Message,
                null,
                null,
                attemptStatus: "UNKNOWN_OUTCOME");
        }
        catch (HttpRequestException exception)
        {
            return await FailAfterDispatchAsync(
                candidate,
                attemptId,
                "ICON_UNKNOWN_OUTCOME",
                "ICON_TRANSPORT_FAILED",
                exception.Message,
                null,
                null,
                attemptStatus: "UNKNOWN_OUTCOME");
        }
        catch (Icon.ApiException exception)
        {
            return await FailAfterDispatchAsync(
                candidate,
                attemptId,
                "ICON_UNKNOWN_OUTCOME",
                $"ICON_HTTP_{exception.StatusCode}",
                exception.Message,
                ToNullableSmallInt(exception.StatusCode),
                NormalizeResponsePayload(exception.Response),
                attemptStatus: "UNKNOWN_OUTCOME");
        }

        if (!TryValidateResponse(response, out var validationMessage))
        {
            return await FailAfterDispatchAsync(
                candidate,
                attemptId,
                "ICON_UNKNOWN_OUTCOME",
                "ICON_RESPONSE_INVALID",
                validationMessage,
                null,
                SerializePayloadOrNull(response),
                attemptStatus: "UNKNOWN_OUTCOME");
        }

        var responsePayloadJson = SerializePayloadOrNull(response);
        using var cleanupCancellation = CreateCleanupCancellation();
        await _repository.CompleteSubmissionAsync(
            new CompletePurchaseOrderSubmissionCommand(
                attemptId,
                candidate.CandidateId,
                candidate.LeaseToken,
                _workerId,
                response.Body!.OrderNo!.Value.ToString(CultureInfo.InvariantCulture),
                GetCreatedStatusWireValue(response.Body.CreatedStatus!.Value),
                response.Body.Suspended!.Value,
                Sanitize(response.Body.SuspendMessage),
                responsePayloadJson),
            cleanupCancellation.Token);

        _logger.LogInformation(
            "Purchase order candidate {CandidateId} completed through ICON attempt {AttemptId}.",
            candidate.CandidateId,
            attemptId);
        return new ProcessingResult(1, 1, 0);
    }

    private async Task<ProcessingResult> FailBeforeDispatchAsync(
        ClaimedPurchaseOrderCandidate candidate,
        string candidateStatus,
        string failureCategory,
        string messageCode,
        string? messageDescription)
    {
        using var cleanupCancellation = CreateCleanupCancellation();
        await _repository.FailCandidatePreDispatchAsync(
            new FailPurchaseOrderCandidatePreDispatchCommand(
                candidate.CandidateId,
                candidate.LeaseToken,
                _workerId,
                candidateStatus,
                failureCategory,
                messageCode,
                Sanitize(messageDescription)),
            cleanupCancellation.Token);

        _logger.LogWarning(
            "Purchase order candidate {CandidateId} failed before dispatch. Category={FailureCategory}, Code={MessageCode}.",
            candidate.CandidateId,
            failureCategory,
            messageCode);
        return new ProcessingResult(1, 0, 1);
    }

    private async Task<ProcessingResult> FailAfterDispatchAsync(
        ClaimedPurchaseOrderCandidate candidate,
        Guid attemptId,
        string failureCategory,
        string messageCode,
        string? messageDescription,
        short? httpStatusCode,
        string? responsePayloadJson,
        string attemptStatus)
    {
        using var cleanupCancellation = CreateCleanupCancellation();
        await _repository.FailSubmissionAsync(
            new FailPurchaseOrderSubmissionCommand(
                attemptId,
                candidate.CandidateId,
                candidate.LeaseToken,
                _workerId,
                NonRecoverableErrorStatus,
                failureCategory,
                messageCode,
                Sanitize(messageDescription),
                httpStatusCode,
                responsePayloadJson,
                attemptStatus),
            cleanupCancellation.Token);

        _logger.LogWarning(
            "Purchase order candidate {CandidateId} failed after dispatch attempt {AttemptId}. Category={FailureCategory}, Code={MessageCode}, AttemptStatus={AttemptStatus}.",
            candidate.CandidateId,
            attemptId,
            failureCategory,
            messageCode,
            attemptStatus);
        return new ProcessingResult(1, 0, 1);
    }

    private CancellationTokenSource CreateCleanupCancellation() =>
        new(TimeSpan.FromSeconds(_settings.OutcomePersistenceTimeoutSeconds));

    private static bool TryValidateResponse(
        Icon.IconCreatePurchaseOrderResponse? response,
        out string validationMessage)
    {
        if (response?.Body is null)
        {
            validationMessage = "ICON returned an empty purchase order response body.";
            return false;
        }

        if (response.Body.OrderNo is null or 0)
        {
            validationMessage = "ICON returned no valid purchase order number.";
            return false;
        }

        if (!response.Body.CreatedStatus.HasValue
            || !Enum.IsDefined(response.Body.CreatedStatus.Value))
        {
            validationMessage = "ICON returned no valid created status.";
            return false;
        }

        if (!response.Body.Suspended.HasValue)
        {
            validationMessage = "ICON returned no suspended state.";
            return false;
        }

        validationMessage = string.Empty;
        return true;
    }

    private static string GetCreatedStatusWireValue(Icon.PurchaseOrderCreatedStatus status) =>
        status switch
        {
            Icon.PurchaseOrderCreatedStatus.Undefined => "undefined",
            Icon.PurchaseOrderCreatedStatus.NotActivated => "notactivated",
            Icon.PurchaseOrderCreatedStatus.Activated => "activated",
            Icon.PurchaseOrderCreatedStatus.Received => "received",
            _ => throw new ArgumentOutOfRangeException(nameof(status), status, "Unsupported ICON created status.")
        };

    private static bool IsUnambiguousClientFailure(int statusCode) =>
        statusCode is >= 400 and <= 499 and not 408;

    private static short? ToNullableSmallInt(int statusCode) =>
        statusCode is >= 100 and <= 599 ? checked((short)statusCode) : null;

    private static string? Sanitize(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        var sanitized = string.Concat(value.Select(character =>
            char.IsControl(character) ? ' ' : character)).Trim();
        return sanitized.Length <= 1000 ? sanitized : sanitized[..1000];
    }

    private static string? NormalizeResponsePayload(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return null;
        }

        const int maximumLength = 16 * 1024;
        if (value.Length <= maximumLength && IsJsonObjectOrArray(value))
        {
            return value;
        }

        var lowerBound = 0;
        var upperBound = Math.Min(value.Length, maximumLength);
        var bestEnvelope = JsonConvert.SerializeObject(new
        {
            rawResponse = string.Empty,
            truncated = value.Length > 0
        });

        while (lowerBound <= upperBound)
        {
            var candidateLength = lowerBound + ((upperBound - lowerBound) / 2);
            var previewLength = candidateLength;
            if (previewLength > 0
                && previewLength < value.Length
                && char.IsHighSurrogate(value[previewLength - 1])
                && char.IsLowSurrogate(value[previewLength]))
            {
                previewLength--;
            }

            var envelope = JsonConvert.SerializeObject(new
            {
                rawResponse = value[..previewLength],
                truncated = previewLength < value.Length
            });
            if (envelope.Length <= maximumLength)
            {
                bestEnvelope = envelope;
                lowerBound = candidateLength + 1;
            }
            else
            {
                upperBound = candidateLength - 1;
            }
        }

        return bestEnvelope;
    }

    private static bool IsJsonObjectOrArray(string value)
    {
        try
        {
            using var document = JsonDocument.Parse(value);
            return document.RootElement.ValueKind is JsonValueKind.Object or JsonValueKind.Array;
        }
        catch (System.Text.Json.JsonException)
        {
            return false;
        }
    }

    private static string? SerializePayloadOrNull(object value)
    {
        try
        {
            return NormalizeResponsePayload(JsonConvert.SerializeObject(value));
        }
        catch (JsonSerializationException)
        {
            return null;
        }
    }

    private static string BuildWorkerId()
    {
        var workerId = $"{Environment.MachineName}:{Environment.ProcessId}:{Guid.NewGuid():N}";
        return workerId.Length <= 256 ? workerId : workerId[..256];
    }
}
