namespace STUK.PurchaseOrderService.Processor.Processing;

public interface IPurchaseOrderProcessor
{
    Task<ProcessingResult> ProcessReadyCandidatesAsync(CancellationToken cancellationToken = default);
}
