namespace STUK.PurchaseOrderService.Processor.Processing;

public sealed record ProcessingResult(int ProcessedCount, int SubmittedCount, int FailedCount);
