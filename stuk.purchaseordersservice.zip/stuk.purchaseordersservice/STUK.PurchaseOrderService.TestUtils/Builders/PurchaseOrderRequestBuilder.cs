using STUK.PurchaseOrderService.Common.Contracts.CanonicalDataModels;

namespace STUK.PurchaseOrderService.TestUtils.Builders;

public static class PurchaseOrderRequestBuilder
{
    public static PurchaseOrder ValidPurchaseOrder()
    {
        return new PurchaseOrder
        {
            PurchaseOrderHeader = new PurchaseOrderHeader
            {
                Account = "BRIT186",
                Branch = 385,
                StockClass = 1,
                CreateUser = "caller-supplied-value",
                Reference = "20211108",
                DateExpected = new DateOnly(2026, 7, 9),
                Contacts =
                [
                    new PurchaseOrderContact
                    {
                        Type = PurchaseOrderPartyType.Supplier,
                        Name = "Supplier Contact",
                        Contact = "1",
                        Phone = "+44 1488 662000",
                        Email = "supplier@example.test"
                    }
                ],
                Addresses =
                [
                    new PurchaseOrderAddress
                    {
                        Type = PurchaseOrderPartyType.Supplier,
                        Lines = ["Supplier address"],
                        PostCode = "RG17 0YU",
                        Country = "GB"
                    }
                ],
                OrderType = PurchaseOrderType.Stock,
                DeliveryMethod = PurchaseOrderDeliveryMethod.Delivery,
                SuspendOrder = true,
                ExtensionAttributes =
                [
                    new PurchaseOrderExtensionAttribute { Name = "bypass", Value = "placeholder" },
                    new PurchaseOrderExtensionAttribute { Name = "activateAction", Value = "placeholder" },
                    new PurchaseOrderExtensionAttribute { Name = "packIgnore", Value = "true" }
                ]
            },
            PurchaseOrderLines =
            [
                new PurchaseOrderLine
                {
                    ProductId = "A0000201",
                    Manufacturer = string.Empty,
                    StockClass = 1,
                    ProductDescription = "Red Brick",
                    Quantity = 5,
                    Unit = "EA",
                    DateExpected = new DateOnly(2026, 7, 9),
                    Pricing = new PurchaseOrderPricing { Unit = "EA", Price = 8.45f },
                    Tally = [new PurchaseOrderTallyItem { Quantity = 0, Length = 0, Width = 0 }]
                }
            ]
        };
    }
}
