# STUK Purchase Order Service

.NET 8 service for accepting canonical purchase orders, persisting them to SQL, and processing them asynchronously outside the public API.

## Solution Layout

- `STUK.PurchaseOrderService.Common.Contracts`: canonical request, response, status, and configuration contracts.
- `STUK.PurchaseOrderService.Common.Data`: stored-procedure repositories and SQL-backed configuration.
- `STUK.PurchaseOrderService.WebApi`: authenticated HTTP endpoints and request guards.
- `STUK.PurchaseOrderService.WebApi.Domain`: validation, server normalization, and application services.
- `STUK.PurchaseOrderService.PurchaseOrderAdmin`: CoreUI operations portal for lifecycle summary, bounded search, candidate details, audit, retry, and cancellation.
- `STUK.PurchaseOrderService.Processor*`: private processor hosts and the `STUK.IconIntegration` gateway.
- `STUK.PurchaseOrderService.AppHost`: one-command local orchestration and SQL creation for SQL Server, Azurite, application hosts, and the ICON mock.
- `STUK.PurchaseOrderService.IconMock`: deterministic local-purpose ICON activation and Create Purchase Order mock.
- `STUK.PurchaseOrderService.*Tests`: unit and contract tests.
- `docs/product`: PRD, Russian review copy, and the normative canonical JSON example.

## Implemented API Slice

`POST /PurchaseOrderService/PurchaseOrders/v1` accepts one JSON object with `purchaseOrderHeader` and `purchaseOrderLines`. The API assigns `Source = "API"` and the server-owned `WebApiSettings:ApiCreateUser`; callers do not provide a source header. The service creates `candidateStatus` on the persisted `PurchaseOrderCandidate`, outside the submitted order payload.

The POST endpoint requires `Content-Length`, accepts JSON only, rejects bodies over 10 KB, and rejects array/bulk requests. A valid request is persisted through `po.sp_create_purchase_order_candidate` as business-only canonical JSON plus candidate lifecycle and selected query fields. Repeated requests create separate candidates; no idempotency claim is made.

`GET /PurchaseOrderService/PurchaseOrders/v1` supports bounded search by source, account, branch, reference, ICON purchase-order number, and candidate status.

Source normalization applies to newly ingested orders only; existing persisted rows are not rewritten.

Search page size is capped at 50 in API validation and SQL. A successful search with no matching candidates returns a sanitized HTTP 404 response.

The public API has no `STUK.IconIntegration` reference and never calls ICON. `Common.Data` uses a typed stored-procedure executor and repositories for API, batch ingestion, processing, support, and notification persistence. The Processor implements single-candidate claiming, activation lookup, CDM-to-ICON mapping, durable dispatch, and terminal outcome persistence. Submission remains fail-closed in normal checked-in settings and automatic retries are not enabled; only the local Aspire AppHost enables submission against the deterministic ICON mock.

The complete SQL Server/Azure SQL package is available through [`database/purchase-order/000-deploy.sql`](database/purchase-order/000-deploy.sql). It creates one isolated `po.ApplicationSetting` table plus seven operational tables, 38 stored procedures, and named lifecycle `CHECK` constraints; there are no status lookup tables. The package is proposed, has not been deployed or live-verified, and requires database-team review and environment acceptance. The portal change does not activate external submission or authorize a production deployment. Environment-specific non-secret settings are loaded separately with a reviewed copy of [`110-application-settings-seed.template.sql`](database/purchase-order/110-application-settings-seed.template.sql). Send [`docs/database/purchase-order-db-team-change-request.md`](docs/database/purchase-order-db-team-change-request.md) to the database team for prerequisites, exact objects and grants, ordered execution, acceptance, evidence, and recovery guidance. Guarded non-production acceptance instructions are in [`database/purchase-order/tests/README.md`](database/purchase-order/tests/README.md).

## Relex Email Notifications

The private `RelexNotificationProducerFunction` creates one consolidated result email for each non-empty Relex batch after all candidates reach terminal outcomes, and a separate missing-proposal alert at the configured business cutoff. Durable events and immutable envelopes feed the existing ACS SMTP outbox and sender. Both producer paths and SMTP sending are disabled by default. See [Relex email notifications](docs/email-notifications.md) for exact Library keys, the required result-history cutoff, full database deployment, activation checks, monitoring, and recovery limits. ICON-to-Relex file alerts remain part of the separate File Integration workstream.

## Operations Portal

`STUK.PurchaseOrderService.PurchaseOrderAdmin` follows the Sale Orders CoreUI portal pattern. `PurchaseOrderViewer` may open the dashboard, search the selected source and accepted-time range, and inspect candidate details, canonical payload, and audit history. `PurchaseOrderManager` adds rowversion-protected retry and cancellation with a required reason. The dashboard reports the eight persisted candidate lifecycle statuses; it does not poll ICON after a candidate reaches `COMPLETED`.

The Aspire AppHost explicitly enables a synthetic local viewer/manager identity for the portal. That switch is honored only when Purchase Order Admin runs in `Development`; normal environment startup keeps the CoreUI authentication, authorization, and layout path and requires its external configuration.

## Local Commands

The complete local SQL/API/Processor/mocked-ICON happy path, prerequisites, and platform-specific instructions are documented in [`docs/local-development.md`](docs/local-development.md). Azure Functions Core Tools 4 must be available on `PATH`, and Docker Desktop must be configured for the `linux/amd64` SQL Server container.

From a terminal, start the complete environment with:

```console
dotnet run --project STUK.PurchaseOrderService.AppHost
```

On Windows x64, use Docker Desktop with the WSL 2 engine and Linux containers. Open `STUK.PurchaseOrderService.sln` in Visual Studio with the ASP.NET and web development workload and .NET Aspire tooling installed, set `STUK.PurchaseOrderService.AppHost` as the startup project, select its `http` launch profile, and press **F5** or **Ctrl+F5**. Windows ARM64 is not covered by the local guide.

Aspire persists its generated SQL password in AppHost user secrets and scopes the interactive SQL volume to this AppHost. Older checkouts may have left the legacy `stuk-purchase-orders-sql-data` volume behind; the current AppHost does not reuse or delete it. See the local-development guide before resetting any local database volume.

The Docker-backed E2E project remains outside the solution and must be run explicitly as described in the local-development guide. On Windows, run it from the Visual Studio terminal rather than Test Explorer.

```bash
dotnet restore STUK.PurchaseOrderService.sln
dotnet build STUK.PurchaseOrderService.sln --configuration Release --no-restore
dotnet test STUK.PurchaseOrderService.sln --configuration Release --no-build
```

Do not run live SQL or ICON calls without approved local configuration. Development authentication is relaxed only when `ASPNETCORE_ENVIRONMENT=Development` and no STUK-IDS authority is configured; non-development startup rejects incomplete security settings.

## Continuous Integration

The root [`azure-pipelines.yml`](azure-pipelines.yml) runs for `master` and `feature/*` branches on `ubuntu-latest` with the .NET 8 SDK. It authenticates internal NuGet feeds, restores the solution through the repository `nuget.config`, builds in `Release`, and runs the solution tests with XPlat Code Coverage.

After validation, the pipeline publishes zipped outputs for the Web API, Processor Functions, and Purchase Order Admin under the `WebApi`, `Processor.Functions`, and `PurchaseOrderAdmin` staging folders. Azure DevOps publishes the combined output as the `PurchaseOrderService` artifact. The root pipeline builds and packages these deployables; it does not deploy them to an environment.

## Configuration

The API validates `WebApiSettings` at startup. `ApiCreateUser` must be non-empty, `AllowedSources` controls GET search values, and `PurchaseOrdersMaxPageSize` must be between 1 and 50. The Web API and Purchase Order Admin use `STUK.ConfigurationProviders` with `po.sp_get_application_settings` and fail fast when `ConnectionStrings:PurchaseOrdersServiceDB` or `DatabaseConfigurationRefreshInterval` is absent or invalid. Relex batch procedures assign `Source = "Relex"`; the portal exposes both `API` and `Relex` as source filters. The portal validates its allowed sources and bounded page sizes at startup. SQL-backed settings use the `Common`, `WebApi`, `BatchProcessor`, and externally retained `WebApp` contexts. Secrets belong in Key Vault or local user secrets, never repository settings.

The next persistence step is database-team review, non-production execution, verification, and acceptance of the proposed package. Applying the package does not authorize scheduled external processing.
